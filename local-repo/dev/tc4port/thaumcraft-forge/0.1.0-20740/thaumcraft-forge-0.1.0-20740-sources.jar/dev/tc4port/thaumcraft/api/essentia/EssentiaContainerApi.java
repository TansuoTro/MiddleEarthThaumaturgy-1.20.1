package dev.tc4port.thaumcraft.api.essentia;

import dev.tc4port.thaumcraft.util.RuntimeWarnings;
import dev.tc4port.thaumcraft.api.aspect.AspectApi;
import dev.tc4port.thaumcraft.api.aspect.AspectAmounts;
import dev.tc4port.thaumcraft.api.aspect.AspectId;
import dev.tc4port.thaumcraft.data.AspectStackData;
import dev.tc4port.thaumcraft.item.EssencePhialItem;
import dev.tc4port.thaumcraft.item.WardedJarBlockItem;
import dev.tc4port.thaumcraft.state.TCItemState;
import java.util.Map;
import java.util.Objects;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

/**
 * Native phial/jar transactions. Callers own stack splitting, placement and synchronization.
 */
public final class EssentiaContainerApi {

    private EssentiaContainerApi() {
    }

    /**
     * Label filter identity; an empty label has no aspect and stores no essentia.
     */
    public static boolean isLabel(ItemStack stack) {
        return stack.is(dev.tc4port.thaumcraft.registry.TCItems.JAR_LABEL.get());
    }

    public static java.util.Optional<AspectId> labelAspect(ItemStack stack) {
        return isLabel(stack) ? java.util.Optional.ofNullable((switch(0) {
            default ->
                {
                    dev.tc4port.thaumcraft.api.data.ItemStateKey<dev.tc4port.thaumcraft.api.aspect.AspectId> native$receiver$485 = TCItemState.JAR_FILTER;
                    net.minecraft.world.item.ItemStack native$argument$486 = stack;
                    java.util.Objects.requireNonNull(native$receiver$485);
                    yield dev.tc4port.thaumcraft.api.item.ItemStatePlatform.get(native$argument$486, native$receiver$485);
                }
        })) : java.util.Optional.empty();
    }

    /**
     * Return an independently owned jar or label; invalid filter requests return EMPTY without changing the source.
     */
    public static ItemStack withFilter(ItemStack source, @javax.annotation.Nullable AspectId aspect) {
        if (source == null || !isLabel(source) && !WardedJarBlockItem.isJar(source) || aspect != null && AspectApi.registry().get(aspect).isEmpty()) {
            RuntimeWarnings.warnOnce("essentia-filter", "Ignoring unsupported jar filter request");
            return ItemStack.EMPTY;
        }
        var amounts = contents(source).amounts();
        if (aspect != null && amounts.keySet().stream().anyMatch(value -> !value.equals(aspect))) {
            RuntimeWarnings.warnOnce("essentia-filter-conflict", "Ignoring jar filter that conflicts with stored essentia");
            return ItemStack.EMPTY;
        }
        ItemStack result = source.copy();
        if (aspect == null) {
            dev.tc4port.thaumcraft.api.data.ItemStateKey<dev.tc4port.thaumcraft.api.aspect.AspectId> native$receiver$789 = TCItemState.JAR_FILTER;
            net.minecraft.world.item.ItemStack native$argument$790 = result;
            java.util.Objects.requireNonNull(native$receiver$789);
            dev.tc4port.thaumcraft.api.item.ItemStatePlatform.remove(native$argument$790, native$receiver$789);
        } else {
            dev.tc4port.thaumcraft.api.data.ItemStateKey<dev.tc4port.thaumcraft.api.aspect.AspectId> native$receiver$791 = TCItemState.JAR_FILTER;
            net.minecraft.world.item.ItemStack native$argument$792 = result;
            dev.tc4port.thaumcraft.api.aspect.AspectId native$argument$793 = aspect;
            java.util.Objects.requireNonNull(native$receiver$791);
            dev.tc4port.thaumcraft.api.item.ItemStatePlatform.set(native$argument$792, native$receiver$791, java.util.Objects.requireNonNull(native$argument$793, "value"));
        }
        return result;
    }

    /**
     * Server-side capacity of one carrier, or zero for unsupported items.
     */
    public static int capacity(ItemStack stack) {
        return capacity(stack, false);
    }

    /**
     * Use the synchronized snapshot for client-side inspection.
     */
    public static int capacity(ItemStack stack, boolean clientSide) {
        return stack.isEmpty() ? 0 : stack.getItem() instanceof EssencePhialItem ? EssencePhialItem.capacity(clientSide) : FilledJarEssentiaApi.capacity(stack, clientSide);
    }

    /**
     * Stored contents only; aspect scan values and jar labels are never treated as storage.
     */
    public static AspectAmounts contents(ItemStack stack) {
        if (stack.isEmpty() || !(stack.getItem() instanceof EssencePhialItem) && !WardedJarBlockItem.isJar(stack))
            return AspectAmounts.EMPTY;
        return new AspectAmounts((switch(0) {
            default ->
                {
                    dev.tc4port.thaumcraft.api.data.ItemStateKey<dev.tc4port.thaumcraft.data.AspectStackData> native$receiver$487 = TCItemState.ASPECTS;
                    net.minecraft.world.item.ItemStack native$argument$488 = stack;
                    dev.tc4port.thaumcraft.data.AspectStackData native$argument$489 = AspectStackData.EMPTY;
                    java.util.Objects.requireNonNull(native$receiver$487);
                    yield dev.tc4port.thaumcraft.api.item.ItemStatePlatform.getOrDefault(native$argument$488, native$receiver$487, native$argument$489);
                }
        }).aspects());
    }

    public static int insert(Level level, ItemStack stack, AspectId aspect, int amount, EssentiaTransferMode mode) {
        return transfer(level, stack, aspect, amount, mode, true);
    }

    public static int extract(Level level, ItemStack stack, AspectId aspect, int amount, EssentiaTransferMode mode) {
        return transfer(level, stack, aspect, amount, mode, false);
    }

    /**
     * Partial jars are allowed; empty phials fill to capacity and filled phials empty entirely. EXECUTE requires a single stack on the server thread.
     */
    private static int transfer(Level level, ItemStack stack, AspectId aspect, int amount, EssentiaTransferMode mode, boolean insert) {
        Objects.requireNonNull(level);
        Objects.requireNonNull(aspect);
        Objects.requireNonNull(mode);
        int capacity = capacity(stack, level.isClientSide);
        if (capacity == 0 || stack.getCount() != 1 || amount <= 0 || AspectApi.registry().get(aspect).isEmpty())
            return 0;
        var contents = contents(stack).amounts();
        if (contents.size() > 1 || (!contents.isEmpty() && !contents.containsKey(aspect)))
            return 0;
        AspectId filter = (switch(0) {
            default ->
                {
                    dev.tc4port.thaumcraft.api.data.ItemStateKey<dev.tc4port.thaumcraft.api.aspect.AspectId> native$receiver$490 = TCItemState.JAR_FILTER;
                    net.minecraft.world.item.ItemStack native$argument$491 = stack;
                    java.util.Objects.requireNonNull(native$receiver$490);
                    yield dev.tc4port.thaumcraft.api.item.ItemStatePlatform.get(native$argument$491, native$receiver$490);
                }
        });
        if (insert && filter != null && !filter.equals(aspect))
            return 0;
        int current = contents.getOrDefault(aspect, 0);
        boolean phial = stack.getItem() instanceof EssencePhialItem;
        if (current < 0)
            return 0;
        int moved;
        if (phial) {
            // Reload changes new fills only. Never top up or partially empty a bottle.
            if (insert) {
                if (current != 0 || amount < capacity)
                    return 0;
                moved = capacity;
            } else {
                if (current == 0 || amount < current)
                    return 0;
                moved = current;
            }
        } else {
            int space = Math.max(0, capacity - current);
            moved = Math.min(amount, insert ? space : current);
        }
        if (moved == 0)
            return 0;
        if (!mode.executes())
            return moved;
        if (!(level instanceof ServerLevel server) || !server.getServer().isSameThread())
            return 0;
        int remaining = insert ? current + moved : current - moved;
        if (remaining == 0) {
            dev.tc4port.thaumcraft.api.data.ItemStateKey<dev.tc4port.thaumcraft.data.AspectStackData> native$receiver$794 = TCItemState.ASPECTS;
            net.minecraft.world.item.ItemStack native$argument$795 = stack;
            java.util.Objects.requireNonNull(native$receiver$794);
            dev.tc4port.thaumcraft.api.item.ItemStatePlatform.remove(native$argument$795, native$receiver$794);
        } else {
            dev.tc4port.thaumcraft.api.data.ItemStateKey<dev.tc4port.thaumcraft.data.AspectStackData> native$receiver$796 = TCItemState.ASPECTS;
            net.minecraft.world.item.ItemStack native$argument$797 = stack;
            dev.tc4port.thaumcraft.data.AspectStackData native$argument$798 = new AspectStackData(Map.of(aspect, remaining));
            java.util.Objects.requireNonNull(native$receiver$796);
            dev.tc4port.thaumcraft.api.item.ItemStatePlatform.set(native$argument$797, native$receiver$796, java.util.Objects.requireNonNull(native$argument$798, "value"));
        }
        return moved;
    }
}
