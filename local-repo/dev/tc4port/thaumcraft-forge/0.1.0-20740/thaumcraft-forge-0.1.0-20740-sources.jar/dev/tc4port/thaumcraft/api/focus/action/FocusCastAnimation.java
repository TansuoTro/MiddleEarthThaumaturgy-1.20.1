package dev.tc4port.thaumcraft.api.focus.action;

/**
 * Wand presentation used by a registered focus action.
 *
 * <p>This is declarative presentation metadata, not an execution callback.
 * Thaumcraft uses it to select the same held-use and successful-cast animation
 * paths as its built-in foci.</p>
 */
public enum FocusCastAnimation {

    /**
     * No casting pose is owned by this action.
     */
    NONE,
    /**
     * One activation attempt uses TC4's ordinary predicted wand swing.
     */
    INSTANT,
    /**
     * The wand remains in TC4's held-use WAVE while the action is active.
     */
    CONTINUOUS
}
