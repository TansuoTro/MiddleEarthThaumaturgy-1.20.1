package dev.tc4port.thaumcraft.block;

import dev.tc4port.thaumcraft.common.MultiblockFormation;
import dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult;
import com.mojang.serialization.MapCodec;
import dev.tc4port.thaumcraft.api.ThaumcraftApiHelper;
import dev.tc4port.thaumcraft.api.aspect.VisAction;
import dev.tc4port.thaumcraft.api.aspect.VisPaymentResult;
import dev.tc4port.thaumcraft.common.CompoundBlueprintCatalog;
import dev.tc4port.thaumcraft.common.PlayerKnowledgeService;
import dev.tc4port.thaumcraft.common.WandVis;
import dev.tc4port.thaumcraft.api.wand.WandCarrierItem;
import dev.tc4port.thaumcraft.network.BlockSparklePayload;
import dev.tc4port.thaumcraft.registry.TCBlocks;
import dev.tc4port.thaumcraft.registry.TCSounds;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.Vec3;
import dev.tc4port.thaumcraft.nativeimpl.ClientExtensionTarget;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.level.pathfinder.PathComputationType;
import net.minecraft.world.phys.HitResult;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.Explosion;
import net.minecraft.world.level.BlockGetter;

/**
 * The unformed metadata-nine alchemical construct.
 *
 * <p>TC4 forms two vertically stacked constructs above a crucible when a
 * researched player taps either construct with a wand. The clicked face is
 * retained as the thaumatorium's output face; top/bottom clicks use the
 * player's horizontal facing instead.</p>
 */
public final class AlchemicalConstructBlock extends net.minecraft.world.level.block.Block implements dev.tc4port.thaumcraft.nativeimpl.ClientExtensionTarget {

    // Forge calls initializeClient from the native superclass constructor. Do not add a field initializer.
    private java.util.function.Consumer<net.minecraftforge.client.extensions.common.IClientBlockExtensions> platform$clientInstaller;

    public static final MapCodec<AlchemicalConstructBlock> CODEC = AlchemicalConstructBlock.native$BlockCodecPlatform$simple(AlchemicalConstructBlock::new);

    public AlchemicalConstructBlock(BlockBehaviour.Properties properties) {
        this(properties, properties, true);
    }

    protected MapCodec<AlchemicalConstructBlock> codec() {
        return CODEC;
    }

    protected ItemUseResult interactWithItem(ItemStack stack, BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
        if (!(stack.getItem() instanceof dev.tc4port.thaumcraft.api.wand.WandCarrierItem)) {
            return dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
        }
        dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult advanced = dev.tc4port.thaumcraft.block.AdvancedAlchemyFurnaceBlock.tryForm(level, pos, player, hand, stack, hit.getDirection());
        if (advanced != dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION) {
            return advanced;
        }
        if (!dev.tc4port.thaumcraft.common.CompoundBlueprintCatalog.isTrigger(dev.tc4port.thaumcraft.common.CompoundBlueprintCatalog.THAUMATORIUM, state)) {
            return dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
        }
        net.minecraft.core.BlockPos lower = findLowerConstruct(level, pos);
        var blueprint = dev.tc4port.thaumcraft.common.CompoundBlueprintCatalog.require(dev.tc4port.thaumcraft.common.CompoundBlueprintCatalog.THAUMATORIUM);
        if (lower == null || !dev.tc4port.thaumcraft.common.PlayerKnowledgeService.get(player).hasCompletedResearch(blueprint.research())) {
            return dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.FAIL;
        }
        var cost = dev.tc4port.thaumcraft.common.WandVis.craftingCost(stack, player, blueprint.aspects());
        if (dev.tc4port.thaumcraft.api.ThaumcraftApiHelper.consumeExactVisFromWand(stack, player, cost, dev.tc4port.thaumcraft.api.aspect.VisAction.SIMULATE) != dev.tc4port.thaumcraft.api.aspect.VisPaymentResult.AVAILABLE) {
            return dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.FAIL;
        }
        if (!level.isClientSide) {
            net.minecraft.core.Direction facing = hit.getDirection().getAxis().isVertical() ? player.getDirection().getOpposite() : hit.getDirection();
            if (!dev.tc4port.thaumcraft.common.MultiblockFormation.convert((net.minecraft.server.level.ServerLevel) level, player, hit.getDirection(), stack, cost, () -> level.setBlock(lower, dev.tc4port.thaumcraft.registry.TCBlocks.THAUMATORIUM.get().defaultBlockState().setValue(dev.tc4port.thaumcraft.block.ThaumatoriumBlock.FACING, facing), net.minecraft.world.level.block.Block.UPDATE_CLIENTS) && level.setBlock(lower.above(), dev.tc4port.thaumcraft.registry.TCBlocks.THAUMATORIUM_TOP.get().defaultBlockState().setValue(dev.tc4port.thaumcraft.block.ThaumatoriumTopBlock.FACING, facing), net.minecraft.world.level.block.Block.UPDATE_CLIENTS), () -> formationEffects((net.minecraft.server.level.ServerLevel) level, lower))) {
                return dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.FAIL;
            }
        }
        player.swing(hand);
        return dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.sidedSuccess(level.isClientSide);
    }

    private static void formationEffects(ServerLevel level, BlockPos lower) {
        level.updateNeighborsAt(lower, TCBlocks.THAUMATORIUM.get());
        level.updateNeighborsAt(lower.above(), TCBlocks.THAUMATORIUM_TOP.get());
        sendSparkles(level, lower);
        sendSparkles(level, lower.above());
        level.playSound(null, lower, TCSounds.WAND.get(), SoundSource.BLOCKS, 1.0F, 1.0F);
    }

    private static BlockPos findLowerConstruct(Level level, BlockPos clicked) {
        if (CompoundBlueprintCatalog.matchesFormation(CompoundBlueprintCatalog.THAUMATORIUM, level, clicked.above())) {
            return clicked;
        }
        if (CompoundBlueprintCatalog.matchesFormation(CompoundBlueprintCatalog.THAUMATORIUM, level, clicked)) {
            return clicked.below();
        }
        return null;
    }

    private static void sendSparkles(ServerLevel level, BlockPos target) {
        BlockSparklePayload payload = new BlockSparklePayload(target, -9999, 7);
        Vec3 center = Vec3.atCenterOf(target);
        for (ServerPlayer targetPlayer : level.players()) {
            if (targetPlayer.distanceToSqr(center) <= 32.0 * 32.0) {
                dev.tc4port.thaumcraft.network.TCPayloads.CHANNEL.sendToPlayer(targetPlayer, payload);
            }
        }
    }

    private AlchemicalConstructBlock(net.minecraft.world.level.block.state.BlockBehaviour.Properties native$NativeBlock$arg0, BlockBehaviour.Properties properties, boolean native$NativeBlock$captured) {
        super(native$NativeBlock$arg0);
    }

    @Override
    public void initializeClient(java.util.function.Consumer<net.minecraftforge.client.extensions.common.IClientBlockExtensions> installer) {
        platform$clientInstaller = installer;
        super.initializeClient(installer);
    }

    @Override
    public void platform$clientExtension(Object extension) {
        java.util.Objects.requireNonNull(platform$clientInstaller, "Forge initializeClient must run before client extension registration").accept((net.minecraftforge.client.extensions.common.IClientBlockExtensions) extension);
    }

    @Override
    public InteractionResult use(BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
        ItemUseResult result = (switch(0) {
            default ->
                {
                    net.minecraft.world.item.ItemStack native$bodyOperand$4045 = player.getItemInHand(hand);
                    net.minecraft.world.level.block.state.BlockState native$bodyOperand$4046 = state;
                    net.minecraft.world.level.Level native$bodyOperand$4047 = level;
                    net.minecraft.core.BlockPos native$bodyOperand$4048 = pos;
                    net.minecraft.world.entity.player.Player native$bodyOperand$4049 = player;
                    net.minecraft.world.InteractionHand native$bodyOperand$4050 = hand;
                    net.minecraft.world.phys.BlockHitResult native$bodyOperand$4051 = hit;
                    dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult native$bodyResult$4057 = null;
                    native$bodyReturn$4058: {
                        if (true) {
                            if (!(native$bodyOperand$4045.getItem() instanceof dev.tc4port.thaumcraft.api.wand.WandCarrierItem)) {
                                {
                                    native$bodyResult$4057 = dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
                                    break native$bodyReturn$4058;
                                }
                            }
                            dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult native$bodyBinding$4052 = dev.tc4port.thaumcraft.block.AdvancedAlchemyFurnaceBlock.tryForm(native$bodyOperand$4047, native$bodyOperand$4048, native$bodyOperand$4049, native$bodyOperand$4050, native$bodyOperand$4045, native$bodyOperand$4051.getDirection());
                            if (native$bodyBinding$4052 != dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION) {
                                {
                                    native$bodyResult$4057 = native$bodyBinding$4052;
                                    break native$bodyReturn$4058;
                                }
                            }
                            if (!dev.tc4port.thaumcraft.common.CompoundBlueprintCatalog.isTrigger(dev.tc4port.thaumcraft.common.CompoundBlueprintCatalog.THAUMATORIUM, native$bodyOperand$4046)) {
                                {
                                    native$bodyResult$4057 = dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
                                    break native$bodyReturn$4058;
                                }
                            }
                            net.minecraft.core.BlockPos native$bodyBinding$4053 = findLowerConstruct(native$bodyOperand$4047, native$bodyOperand$4048);
                            var native$bodyBinding$4054 = dev.tc4port.thaumcraft.common.CompoundBlueprintCatalog.require(dev.tc4port.thaumcraft.common.CompoundBlueprintCatalog.THAUMATORIUM);
                            if (native$bodyBinding$4053 == null || !dev.tc4port.thaumcraft.common.PlayerKnowledgeService.get(native$bodyOperand$4049).hasCompletedResearch(native$bodyBinding$4054.research())) {
                                {
                                    native$bodyResult$4057 = dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.FAIL;
                                    break native$bodyReturn$4058;
                                }
                            }
                            var native$bodyBinding$4055 = dev.tc4port.thaumcraft.common.WandVis.craftingCost(native$bodyOperand$4045, native$bodyOperand$4049, native$bodyBinding$4054.aspects());
                            if (dev.tc4port.thaumcraft.api.ThaumcraftApiHelper.consumeExactVisFromWand(native$bodyOperand$4045, native$bodyOperand$4049, native$bodyBinding$4055, dev.tc4port.thaumcraft.api.aspect.VisAction.SIMULATE) != dev.tc4port.thaumcraft.api.aspect.VisPaymentResult.AVAILABLE) {
                                {
                                    native$bodyResult$4057 = dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.FAIL;
                                    break native$bodyReturn$4058;
                                }
                            }
                            if (!native$bodyOperand$4047.isClientSide) {
                                net.minecraft.core.Direction native$bodyBinding$4056 = native$bodyOperand$4051.getDirection().getAxis().isVertical() ? native$bodyOperand$4049.getDirection().getOpposite() : native$bodyOperand$4051.getDirection();
                                if (!dev.tc4port.thaumcraft.common.MultiblockFormation.convert((net.minecraft.server.level.ServerLevel) native$bodyOperand$4047, native$bodyOperand$4049, native$bodyOperand$4051.getDirection(), native$bodyOperand$4045, native$bodyBinding$4055, () -> native$bodyOperand$4047.setBlock(native$bodyBinding$4053, dev.tc4port.thaumcraft.registry.TCBlocks.THAUMATORIUM.get().defaultBlockState().setValue(dev.tc4port.thaumcraft.block.ThaumatoriumBlock.FACING, native$bodyBinding$4056), net.minecraft.world.level.block.Block.UPDATE_CLIENTS) && native$bodyOperand$4047.setBlock(native$bodyBinding$4053.above(), dev.tc4port.thaumcraft.registry.TCBlocks.THAUMATORIUM_TOP.get().defaultBlockState().setValue(dev.tc4port.thaumcraft.block.ThaumatoriumTopBlock.FACING, native$bodyBinding$4056), net.minecraft.world.level.block.Block.UPDATE_CLIENTS), () -> formationEffects((net.minecraft.server.level.ServerLevel) native$bodyOperand$4047, native$bodyBinding$4053))) {
                                    {
                                        native$bodyResult$4057 = dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.FAIL;
                                        break native$bodyReturn$4058;
                                    }
                                }
                            }
                            native$bodyOperand$4049.swing(native$bodyOperand$4050);
                            {
                                native$bodyResult$4057 = dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.sidedSuccess(native$bodyOperand$4047.isClientSide);
                                break native$bodyReturn$4058;
                            }
                        }
                    }
                    yield native$bodyResult$4057;
                }
        });
        return result == ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION ? (hand == InteractionHand.MAIN_HAND ? (switch(0) {
            default ->
                {
                    net.minecraft.world.level.block.state.BlockState native$bodyOperand$3415 = state;
                    net.minecraft.world.level.Level native$bodyOperand$3416 = level;
                    net.minecraft.core.BlockPos native$bodyOperand$3417 = pos;
                    net.minecraft.world.entity.player.Player native$bodyOperand$3418 = player;
                    net.minecraft.world.phys.BlockHitResult native$bodyOperand$3419 = hit;
                    net.minecraft.world.InteractionResult native$bodyResult$3420 = null;
                    native$bodyReturn$3421: {
                        if (true) {
                            {
                                native$bodyResult$3420 = super.use(native$bodyOperand$3415, native$bodyOperand$3416, native$bodyOperand$3417, native$bodyOperand$3418, net.minecraft.world.InteractionHand.MAIN_HAND, native$bodyOperand$3419);
                                break native$bodyReturn$3421;
                            }
                        }
                    }
                    yield native$bodyResult$3420;
                }
        }) : InteractionResult.PASS) : result.result();
    }

    protected InteractionResult interactWithoutItem(BlockState state, Level level, BlockPos pos, Player player, BlockHitResult hit) {
        return super.use(state, level, pos, player, net.minecraft.world.InteractionHand.MAIN_HAND, hit);
    }

    @Override
    public void playerWillDestroy(Level level, BlockPos pos, BlockState state, Player player) {
        {
            net.minecraft.world.level.Level native$bodyOperand$5614 = level;
            net.minecraft.core.BlockPos native$bodyOperand$5615 = pos;
            net.minecraft.world.level.block.state.BlockState native$bodyOperand$5616 = state;
            net.minecraft.world.entity.player.Player native$bodyOperand$5617 = player;
            net.minecraft.world.level.block.state.BlockState native$bodyResult$5618 = null;
            native$bodyReturn$5619: {
                if (true) {
                    super.playerWillDestroy(native$bodyOperand$5614, native$bodyOperand$5615, native$bodyOperand$5616, native$bodyOperand$5617);
                    {
                        native$bodyResult$5618 = native$bodyOperand$5616;
                        break native$bodyReturn$5619;
                    }
                }
            }
        }
    }

    public BlockState beforePlayerDestroy(Level level, BlockPos pos, BlockState state, Player player) {
        super.playerWillDestroy(level, pos, state, player);
        return state;
    }

    protected boolean survivesSharedExplosion() {
        return false;
    }

    public int getExpDrop(net.minecraft.world.level.block.state.BlockState native$callbackInput$1145, net.minecraft.world.level.LevelReader native$callbackInput$1146, net.minecraft.util.RandomSource native$callbackInput$1147, net.minecraft.core.BlockPos native$callbackInput$1148, int native$callbackInput$1149, int native$callbackInput$1150) {
        net.minecraft.world.level.block.state.BlockState state = native$callbackInput$1145;
        net.minecraft.util.RandomSource random = native$callbackInput$1147;
        return 0;
    }

    @Override
    public void onBlockExploded(BlockState state, Level level, BlockPos pos, Explosion explosion) {
        if (!(switch(0) {
            default ->
                {
                    boolean native$bodyResult$5201 = false;
                    native$bodyReturn$5202: {
                        if (true) {
                            {
                                native$bodyResult$5201 = false;
                                break native$bodyReturn$5202;
                            }
                        }
                    }
                    yield native$bodyResult$5201;
                }
        }))
            super.onBlockExploded(state, level, pos, explosion);
    }

    @Override
    public boolean canDropFromExplosion(BlockState state, BlockGetter level, BlockPos pos, Explosion explosion) {
        return !(switch(0) {
            default ->
                {
                    boolean native$bodyResult$4059 = false;
                    native$bodyReturn$4060: {
                        if (true) {
                            {
                                native$bodyResult$4059 = false;
                                break native$bodyReturn$4060;
                            }
                        }
                    }
                    yield native$bodyResult$4059;
                }
        }) && super.canDropFromExplosion(state, level, pos, explosion);
    }

    static private <B extends net.minecraft.world.level.block.Block> com.mojang.serialization.MapCodec<B> native$BlockCodecPlatform$simple(java.util.function.Function<net.minecraft.world.level.block.state.BlockBehaviour.Properties, B> factory) {
        // Vanilla 1.21's Properties codec is a unit codec. Retain that schema for shared block definitions.
        return com.mojang.serialization.codecs.RecordCodecBuilder.mapCodec(instance -> instance.group(com.mojang.serialization.Codec.unit(net.minecraft.world.level.block.state.BlockBehaviour.Properties::of).fieldOf("properties").forGetter((B block) -> net.minecraft.world.level.block.state.BlockBehaviour.Properties.copy(block))).apply(instance, factory));
    }
}
