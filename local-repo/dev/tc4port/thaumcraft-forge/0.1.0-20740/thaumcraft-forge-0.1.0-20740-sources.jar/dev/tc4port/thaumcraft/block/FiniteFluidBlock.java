package dev.tc4port.thaumcraft.block;

import dev.tc4port.thaumcraft.block.entity.MagicFluidBlockEntity;
import dev.tc4port.thaumcraft.fluid.BlockBackedFluid;
import java.util.function.Supplier;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.RandomSource;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.HalfTransparentBlock;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.IntegerProperty;
import net.minecraft.world.level.material.Fluid;
import net.minecraft.world.level.material.FluidState;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;

/**
 * The world-state and rendering block for TC4's finite fluids. Its native
 * {@link BlockBackedFluid} owns flow scheduling, volume distribution and
 * displacement; the block retains the legacy metadata representation.
 */
public abstract class FiniteFluidBlock extends HalfTransparentBlock implements MetadataFluidRenderBlock {

    public static final IntegerProperty LEVEL = IntegerProperty.create("level", 0, 8);

    private final Supplier<? extends BlockBackedFluid> nativeFluid;

    protected FiniteFluidBlock(BlockBehaviour.Properties properties, Supplier<? extends BlockBackedFluid> nativeFluid) {
        super(properties);
        this.nativeFluid = nativeFluid;
        this.registerDefaultState(this.stateDefinition.any().setValue(LEVEL, 0));
    }

    public final int quantaPerBlock() {
        return this.nativeFluid.get().quantaPerBlock();
    }

    public final boolean flowsUpward() {
        return this.nativeFluid.get().flowsUpward();
    }

    /**
     * Preserves the original asymmetric rendering of vertical fluid columns.
     */
    public final boolean hasContinuousRenderOrigin(BlockState origin) {
        if (origin.is(this)) {
            return true;
        }
        if (origin.getBlock() instanceof PurifyingFluidBlock || origin.getBlock() instanceof LiquidDeathBlock) {
            return true;
        }
        if (origin.getBlock() instanceof FiniteFluidBlock) {
            return !this.flowsUpward();
        }
        return !origin.getFluidState().isEmpty();
    }

    public final int amount(BlockState state) {
        if (!state.is(this)) {
            return 0;
        }
        int amount = state.getValue(LEVEL) + 1;
        int capacity = this.quantaPerBlock();
        return capacity == 8 ? amount : Math.min(capacity, amount);
    }

    public final float filledPercentage(BlockState state) {
        return Math.min(1.0F, this.amount(state) / (float) this.quantaPerBlock());
    }

    public final BlockState stateForAmount(int amount) {
        int capacity = this.quantaPerBlock();
        int maximum = capacity == 8 ? capacity + 1 : capacity;
        int clamped = Math.max(1, Math.min(maximum, amount));
        return this.defaultBlockState().setValue(LEVEL, clamped - 1);
    }

    /**
     * The nine-quanta placement state is retained until the first flow tick.
     */
    public final BlockState overfullState() {
        return this.defaultBlockState().setValue(LEVEL, 8);
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(LEVEL);
    }

    @Override
    public FluidState getFluidState(BlockState state) {
        int capacity = this.quantaPerBlock();
        int scaledAmount = (this.amount(state) * 8 + capacity - 1) / capacity;
        return this.nativeFluid.get().stateForAmount(scaledAmount);
    }

    @Override
    public VoxelShape getCollisionShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
        return Shapes.empty();
    }

    @Override
    public VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
        return Shapes.empty();
    }

    @Override
    public boolean canBeReplaced(BlockState state, BlockPlaceContext context) {
        return state.getValue(LEVEL) < 2;
    }

    @Override
    public boolean canBeReplaced(BlockState state, Fluid fluid) {
        return state.getValue(LEVEL) < 2;
    }

    @Override
    public void onPlace(BlockState state, Level level, BlockPos pos, BlockState oldState, boolean movedByPiston) {
        if (!level.isClientSide) {
            if (oldState.is(this) && level.getBlockEntity(pos) instanceof MagicFluidBlockEntity stored) {
                stored.onLayerChange(oldState, state);
            }
            this.nativeFluid.get().schedule(level, pos);
        }
    }

    @Override
    public void neighborChanged(BlockState state, Level level, BlockPos pos, Block neighborBlock, BlockPos neighborPos, boolean movedByPiston) {
        if (!level.isClientSide) {
            this.nativeFluid.get().schedule(level, pos);
        }
    }

    @Override
    public void randomTick(BlockState state, ServerLevel level, BlockPos pos, RandomSource random) {
        state.getFluidState().tick(level, pos);
    }

    protected final void clear(Level level, BlockPos pos) {
        level.setBlock(pos, Blocks.AIR.defaultBlockState(), 3);
    }
}
