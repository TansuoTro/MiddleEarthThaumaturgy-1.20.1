package dev.tc4port.thaumcraft.api.data;

import com.mojang.serialization.Codec;
import java.util.Map;
import java.util.Objects;
import java.util.function.BinaryOperator;
import net.minecraft.core.Holder;
import net.minecraft.core.Registry;
import net.minecraft.core.RegistryAccess;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import org.jetbrains.annotations.Nullable;

/**
 * Typed declaration of one current registry data map, shared by both native backends.
 */
public class RegistryDataMapKey<R, T> {

    private final ResourceLocation id;

    private final ResourceKey<Registry<R>> registry;

    private final Codec<T> codec;

    private final boolean synced;

    private final boolean advanced;

    private final BinaryOperator<T> merger;

    public interface Access {

        <R, T> Map<ResourceKey<R>, T> values(RegistryDataMapKey<R, T> key);

        <R, T> T get(RegistryDataMapKey<R, T> key, Holder<R> holder);
    }

    private final Access access;

    public RegistryDataMapKey(Access access, ResourceLocation id, ResourceKey<Registry<R>> registry, Codec<T> codec, boolean synced, boolean advanced, BinaryOperator<T> merger) {
        this.access = Objects.requireNonNull(access);
        this.id = Objects.requireNonNull(id);
        this.registry = Objects.requireNonNull(registry);
        this.codec = Objects.requireNonNull(codec);
        this.synced = synced;
        this.advanced = advanced;
        this.merger = Objects.requireNonNull(merger);
    }

    public ResourceLocation id() {
        return id;
    }

    public ResourceKey<Registry<R>> registry() {
        return registry;
    }

    public Codec<T> codec() {
        return codec;
    }

    public boolean synced() {
        return synced;
    }

    public boolean advanced() {
        return advanced;
    }

    public T merge(T older, T newer) {
        return merger.apply(older, newer);
    }

    /**
     * Enumerates a built-in registry's current values; dynamic registries require world context.
     */
    public Map<ResourceKey<R>, T> values() {
        return access.values(this);
    }

    /**
     * Enumerates the current values in the supplied world's registry access, including dynamic registries.
     */
    public Map<ResourceKey<R>, T> values(RegistryAccess registries) {
        registries.registryOrThrow(registry);
        return access.values(this);
    }

    @Nullable
    public T get(Holder<R> holder) {
        return access.get(this, holder);
    }
}
