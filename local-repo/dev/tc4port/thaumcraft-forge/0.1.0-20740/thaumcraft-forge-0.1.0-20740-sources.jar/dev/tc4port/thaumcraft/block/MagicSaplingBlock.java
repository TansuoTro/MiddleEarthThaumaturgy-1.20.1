package dev.tc4port.thaumcraft.block;

import com.mojang.serialization.MapCodec;
import dev.tc4port.thaumcraft.registry.MagicTrees;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelReader;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.feature.configurations.NoneFeatureConfiguration;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.VoxelShape;
import dev.tc4port.thaumcraft.nativeimpl.ClientExtensionTarget;
import net.minecraft.world.level.block.BonemealableBlock;

public final class MagicSaplingBlock extends net.minecraft.world.level.block.BushBlock implements BonemealableBlock, dev.tc4port.thaumcraft.nativeimpl.ClientExtensionTarget {

    // Forge calls initializeClient from the native superclass constructor. Do not add a field initializer.
    private java.util.function.Consumer<net.minecraftforge.client.extensions.common.IClientBlockExtensions> platform$clientInstaller;

    public enum Kind {

        GREATWOOD(25), SILVERWOOD(50);

        private final int naturalGrowthChance;

        Kind(int naturalGrowthChance) {
            this.naturalGrowthChance = naturalGrowthChance;
        }
    }

    private static final VoxelShape SHAPE = TCPlantBlock.SHAPE;

    private final Kind kind;

    public MagicSaplingBlock(Kind kind, BlockBehaviour.Properties properties) {
        this(properties, kind, properties, true);
    }

    @Override
    public void randomTick(BlockState state, ServerLevel level, BlockPos pos, RandomSource random) {
        if (level.isAreaLoaded(pos, 1) && level.getMaxLocalRawBrightness(pos.above()) >= 9 && random.nextInt(this.kind.naturalGrowthChance) == 0) {
            this.grow(level, pos, state, random);
        }
    }

    private void grow(ServerLevel level, BlockPos pos, BlockState originalState, RandomSource random) {
        level.removeBlock(pos, false);
        boolean generated = (this.kind == Kind.GREATWOOD ? MagicTrees.feature("grown_greatwood_tree") : MagicTrees.feature("grown_silverwood_tree")).place(NoneFeatureConfiguration.INSTANCE, level, level.getChunkSource().getGenerator(), random, pos);
        if (!generated) {
            level.setBlock(pos, originalState, 3);
        }
    }

    public boolean isValidBonemealTarget(LevelReader level, BlockPos pos, BlockState state) {
        return true;
    }

    @Override
    public boolean isBonemealSuccess(Level level, RandomSource random, BlockPos pos, BlockState state) {
        return random.nextFloat() < 0.45F;
    }

    @Override
    public void performBonemeal(ServerLevel level, RandomSource random, BlockPos pos, BlockState state) {
        this.grow(level, pos, state, random);
    }

    @Override
    public VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
        return SHAPE;
    }

    @Override
    public int getFlammability(BlockState state, BlockGetter level, BlockPos pos, Direction face) {
        return 100;
    }

    @Override
    public int getFireSpreadSpeed(BlockState state, BlockGetter level, BlockPos pos, Direction face) {
        return 60;
    }

    public static final MapCodec<MagicSaplingBlock> GREATWOOD_CODEC = MagicSaplingBlock.native$BlockCodecPlatform$simple(properties -> new MagicSaplingBlock(Kind.GREATWOOD, properties));

    public static final MapCodec<MagicSaplingBlock> SILVERWOOD_CODEC = MagicSaplingBlock.native$BlockCodecPlatform$simple(properties -> new MagicSaplingBlock(Kind.SILVERWOOD, properties));

    protected MapCodec<MagicSaplingBlock> codec() {
        return kind == Kind.GREATWOOD ? GREATWOOD_CODEC : SILVERWOOD_CODEC;
    }

    private MagicSaplingBlock(net.minecraft.world.level.block.state.BlockBehaviour.Properties native$BonemealablePlantBlock$arg0, Kind kind, BlockBehaviour.Properties properties, boolean native$BonemealablePlantBlock$captured) {
        super(native$BonemealablePlantBlock$arg0);
        this.kind = kind;
    }

    @Override
    public void initializeClient(java.util.function.Consumer<net.minecraftforge.client.extensions.common.IClientBlockExtensions> installer) {
        platform$clientInstaller = installer;
        super.initializeClient(installer);
    }

    @Override
    public void platform$clientExtension(Object extension) {
        java.util.Objects.requireNonNull(platform$clientInstaller, "Forge initializeClient must run before client extension registration").accept((net.minecraftforge.client.extensions.common.IClientBlockExtensions) extension);
    }

    @Override
    public boolean isValidBonemealTarget(LevelReader level, BlockPos pos, BlockState state, boolean client) {
        return (switch(0) {
            default ->
                {
                    net.minecraft.world.level.LevelReader native$bodyOperand$5913 = level;
                    net.minecraft.core.BlockPos native$bodyOperand$5914 = pos;
                    net.minecraft.world.level.block.state.BlockState native$bodyOperand$5915 = state;
                    boolean native$bodyResult$5916 = false;
                    native$bodyReturn$5917: {
                        if (true) {
                            {
                                native$bodyResult$5916 = true;
                                break native$bodyReturn$5917;
                            }
                        }
                    }
                    yield native$bodyResult$5916;
                }
        });
    }

    static private <B extends net.minecraft.world.level.block.Block> com.mojang.serialization.MapCodec<B> native$BlockCodecPlatform$simple(java.util.function.Function<net.minecraft.world.level.block.state.BlockBehaviour.Properties, B> factory) {
        // Vanilla 1.21's Properties codec is a unit codec. Retain that schema for shared block definitions.
        return com.mojang.serialization.codecs.RecordCodecBuilder.mapCodec(instance -> instance.group(com.mojang.serialization.Codec.unit(net.minecraft.world.level.block.state.BlockBehaviour.Properties::of).fieldOf("properties").forGetter((B block) -> net.minecraft.world.level.block.state.BlockBehaviour.Properties.copy(block))).apply(instance, factory));
    }
}
