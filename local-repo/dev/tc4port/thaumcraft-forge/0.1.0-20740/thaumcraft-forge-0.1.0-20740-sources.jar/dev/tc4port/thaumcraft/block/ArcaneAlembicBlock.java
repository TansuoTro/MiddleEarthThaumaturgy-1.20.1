package dev.tc4port.thaumcraft.block;

import dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult;
import dev.tc4port.thaumcraft.api.aspect.AspectId;
import com.mojang.serialization.MapCodec;
import dev.tc4port.thaumcraft.block.entity.ArcaneAlembicBlockEntity;
import dev.tc4port.thaumcraft.common.WandInteractionTarget;
import dev.tc4port.thaumcraft.data.AspectStackData;
import dev.tc4port.thaumcraft.api.wand.WandCarrierItem;
import dev.tc4port.thaumcraft.item.WardedJarBlockItem;
import dev.tc4port.thaumcraft.state.TCItemState;
import dev.tc4port.thaumcraft.registry.TCItems;
import dev.tc4port.thaumcraft.registry.TCSounds;
import javax.annotation.Nullable;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.DirectionProperty;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;
import java.lang.Math;
import dev.tc4port.thaumcraft.nativeimpl.ClientExtensionTarget;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.level.pathfinder.PathComputationType;
import net.minecraft.world.phys.HitResult;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.Explosion;

/**
 * Dedicated block shell and interaction layer for TileAlembic.
 */
public final class ArcaneAlembicBlock extends net.minecraft.world.level.block.BaseEntityBlock implements WandInteractionTarget, dev.tc4port.thaumcraft.nativeimpl.ClientExtensionTarget {

    // Forge calls initializeClient from the native superclass constructor. Do not add a field initializer.
    private java.util.function.Consumer<net.minecraftforge.client.extensions.common.IClientBlockExtensions> platform$clientInstaller;

    public static final MapCodec<ArcaneAlembicBlock> CODEC = ArcaneAlembicBlock.native$BlockCodecPlatform$simple(ArcaneAlembicBlock::new);

    public static final DirectionProperty FACING = BlockStateProperties.HORIZONTAL_FACING;

    /*
     * BlockMetalDevice kept metadata one at the constructor's full-cube
     * bounds and also used the full cube in addCollisionBoxesToList. The OBJ
     * is narrower, but selection and collision were deliberately not.
     */
    private static final VoxelShape SHAPE = Shapes.block();

    @Nullable
    @Override
    public <T extends BlockEntity> net.minecraft.world.level.block.entity.BlockEntityTicker<T> getTicker(Level level, BlockState state, net.minecraft.world.level.block.entity.BlockEntityType<T> type) {
        return level.isClientSide ? null : createTickerHelper(type, dev.tc4port.thaumcraft.registry.TCBlockEntities.ARCANE_ALEMBIC.get(), ArcaneAlembicBlockEntity::serverTick);
    }

    public ArcaneAlembicBlock(BlockBehaviour.Properties properties) {
        this(properties, properties, true);
    }

    protected MapCodec<ArcaneAlembicBlock> codec() {
        return CODEC;
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(FACING);
    }

    @Nullable
    @Override
    public BlockState getStateForPlacement(BlockPlaceContext context) {
        return this.defaultBlockState().setValue(FACING, context.getHorizontalDirection().getOpposite());
    }

    @Nullable
    @Override
    public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        return new ArcaneAlembicBlockEntity(pos, state);
    }

    @Override
    public RenderShape getRenderShape(BlockState state) {
        return RenderShape.MODEL;
    }

    @Override
    public VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
        return SHAPE;
    }

    @Override
    public VoxelShape getCollisionShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
        return SHAPE;
    }

    protected ItemUseResult interactWithItem(ItemStack stack, BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
        if (!(level.getBlockEntity(pos) instanceof dev.tc4port.thaumcraft.block.entity.ArcaneAlembicBlockEntity alembic)) {
            return dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
        }
        if (stack.getItem() instanceof dev.tc4port.thaumcraft.api.wand.WandCarrierItem) {
            if (hit.getDirection().getAxis().isHorizontal()) {
                if (!level.isClientSide) {
                    level.setBlock(pos, state.setValue(dev.tc4port.thaumcraft.block.ArcaneAlembicBlock.FACING, hit.getDirection()), net.minecraft.world.level.block.Block.UPDATE_ALL);
                }
                player.swing(hand);
            }
            /* TileAlembic consumed its no-op top and bottom wand clicks. */
            return dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.sidedSuccess(level.isClientSide);
        }
        if (player.isShiftKeyDown() && alembic.aspectFilter() != null) {
            return dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
        }
        if (stack.is(dev.tc4port.thaumcraft.registry.TCItems.byId("jar_label").get()) && alembic.aspectFilter() == null) {
            dev.tc4port.thaumcraft.api.aspect.AspectId filter = alembic.aspect();
            if (filter == null) {
                filter = (switch(0) {
                    default ->
                        {
                            dev.tc4port.thaumcraft.api.data.ItemStateKey<dev.tc4port.thaumcraft.api.aspect.AspectId> native$receiver$371 = dev.tc4port.thaumcraft.state.TCItemState.JAR_FILTER;
                            net.minecraft.world.item.ItemStack native$argument$372 = stack;
                            java.util.Objects.requireNonNull(native$receiver$371);
                            yield dev.tc4port.thaumcraft.api.item.ItemStatePlatform.get(native$argument$372, native$receiver$371);
                        }
                });
            }
            if (filter == null) {
                return dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.CONSUME;
            }
            if (!level.isClientSide && alembic.setFilter(filter)) {
                // TC4 decremented the held stack directly, including in
                // creative mode. Preserve that behavior instead of using
                // ItemStack.consume(), which exempts creative players.
                stack.shrink(1);
                level.playSound(null, pos, dev.tc4port.thaumcraft.registry.TCSounds.PAGE.get(), net.minecraft.sounds.SoundSource.BLOCKS, 1.0F, 0.9F);
            }
            return dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.sidedSuccess(level.isClientSide);
        }
        dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult jarResult = fillJarFromAlembic(stack, level, pos, player, hand, alembic);
        if (jarResult != dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION) {
            return jarResult;
        }
        return dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
    }

    private static ItemUseResult fillJarFromAlembic(ItemStack stack, Level level, BlockPos pos, Player player, InteractionHand hand, ArcaneAlembicBlockEntity alembic) {
        WardedJarBlock.Kind jarKind = WardedJarBlockItem.kind(stack);
        if (jarKind == null || alembic.amount() <= 0 || alembic.aspect() == null) {
            return ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
        }
        AspectStackData stored = (switch(0) {
            default ->
                {
                    dev.tc4port.thaumcraft.api.data.ItemStateKey<dev.tc4port.thaumcraft.data.AspectStackData> native$receiver$523 = TCItemState.ASPECTS;
                    net.minecraft.world.item.ItemStack native$argument$524 = stack;
                    dev.tc4port.thaumcraft.data.AspectStackData native$argument$525 = AspectStackData.EMPTY;
                    java.util.Objects.requireNonNull(native$receiver$523);
                    yield dev.tc4port.thaumcraft.api.item.ItemStatePlatform.getOrDefault(native$argument$524, native$receiver$523, native$argument$525);
                }
        });
        AspectId aspect = alembic.aspect();
        int existing = stored.amount(aspect);
        boolean compatibleContents = stored.aspects().isEmpty() || stored.aspects().size() == 1 && existing > 0;
        AspectId filter = (switch(0) {
            default ->
                {
                    dev.tc4port.thaumcraft.api.data.ItemStateKey<dev.tc4port.thaumcraft.api.aspect.AspectId> native$receiver$526 = TCItemState.JAR_FILTER;
                    net.minecraft.world.item.ItemStack native$argument$527 = stack;
                    java.util.Objects.requireNonNull(native$receiver$526);
                    yield dev.tc4port.thaumcraft.api.item.ItemStatePlatform.get(native$argument$527, native$receiver$526);
                }
        });
        boolean compatibleFilter = filter == null || filter.equals(aspect);
        if (!compatibleContents || !compatibleFilter) {
            // The legacy block consumed the click even when the jar could not
            // accept the alembic's current aspect.
            return ItemUseResult.sidedSuccess(level.isClientSide);
        }
        boolean voidJar = jarKind == WardedJarBlock.Kind.VOID;
        int moved = voidJar ? alembic.amount() : Math.min(dev.tc4port.thaumcraft.api.essentia.FilledJarEssentiaApi.capacity(stack, level.isClientSide) - existing, alembic.amount());
        if (moved <= 0) {
            return ItemUseResult.sidedSuccess(level.isClientSide);
        }
        if (!level.isClientSide) {
            ItemStack result = stack.copyWithCount(1);
            {
                dev.tc4port.thaumcraft.api.data.ItemStateKey<dev.tc4port.thaumcraft.data.AspectStackData> native$receiver$528 = TCItemState.ASPECTS;
                net.minecraft.world.item.ItemStack native$argument$529 = result;
                dev.tc4port.thaumcraft.data.AspectStackData native$argument$530 = new AspectStackData(java.util.Map.of(aspect, existing + (int) Math.min(moved, Math.max(0L, (long) dev.tc4port.thaumcraft.api.essentia.FilledJarEssentiaApi.capacity(stack, false) - existing))));
                java.util.Objects.requireNonNull(native$receiver$528);
                dev.tc4port.thaumcraft.api.item.ItemStatePlatform.set(native$argument$529, native$receiver$528, java.util.Objects.requireNonNull(native$argument$530, "value"));
            }
            if (!alembic.take(aspect, moved)) {
                return ItemUseResult.FAIL;
            }
            if (stack.getCount() == 1) {
                player.setItemInHand(hand, result);
            } else {
                // Filling one jar splits it from an empty stack before the
                // content component lowers its maximum stack size to one.
                stack.shrink(1);
                if (!player.addItem(result)) {
                    player.drop(result, false);
                }
            }
            level.playSound(null, pos, TCSounds.ESSENTIA_POUR.get(), SoundSource.BLOCKS, 0.5F, 1.0F + (level.random.nextFloat() - level.random.nextFloat()) * 0.3F);
        }
        return ItemUseResult.sidedSuccess(level.isClientSide);
    }

    protected net.minecraft.world.InteractionResult interactWithoutItem(BlockState state, Level level, BlockPos pos, Player player, BlockHitResult hit) {
        if (!(level.getBlockEntity(pos) instanceof dev.tc4port.thaumcraft.block.entity.ArcaneAlembicBlockEntity alembic)) {
            return net.minecraft.world.InteractionResult.PASS;
        }
        if (player.isShiftKeyDown()) {
            if (!level.isClientSide) {
                if (alembic.aspectFilter() != null) {
                    if (alembic.clearFilter()) {
                        net.minecraft.core.Direction side = hit.getDirection();
                        ((net.minecraft.server.level.ServerLevel) level).addFreshEntity(new net.minecraft.world.entity.item.ItemEntity(level, pos.getX() + 0.5 + side.getStepX() / 3.0, pos.getY() + 0.5, pos.getZ() + 0.5 + side.getStepZ() / 3.0, new net.minecraft.world.item.ItemStack(dev.tc4port.thaumcraft.registry.TCItems.byId("jar_label").get())));
                        level.playSound(null, pos, dev.tc4port.thaumcraft.registry.TCSounds.PAGE.get(), net.minecraft.sounds.SoundSource.BLOCKS, 1.0F, 1.1F);
                    }
                    return net.minecraft.world.InteractionResult.SUCCESS;
                }
                alembic.clearContents();
                level.playSound(null, pos, dev.tc4port.thaumcraft.registry.TCSounds.ALEMBIC_KNOCK.get(), net.minecraft.sounds.SoundSource.BLOCKS, 0.2F, 1.0F);
                level.playSound(null, pos, dev.tc4port.thaumcraft.registry.TCSounds.ESSENTIA_POUR.get(), net.minecraft.sounds.SoundSource.BLOCKS, 0.5F, 1.0F + (level.random.nextFloat() - level.random.nextFloat()) * 0.3F);
            }
            return net.minecraft.world.InteractionResult.sidedSuccess(level.isClientSide);
        }
        if (!level.isClientSide) {
            java.lang.String key;
            int amount = alembic.amount();
            if (amount <= 0) {
                key = "tile.alembic.msg.1";
            } else if (amount < alembic.capacity() * 0.4) {
                key = "tile.alembic.msg.2";
            } else if (amount < alembic.capacity() * 0.8) {
                key = "tile.alembic.msg.3";
            } else if (amount < alembic.capacity()) {
                key = "tile.alembic.msg.4";
            } else {
                key = "tile.alembic.msg.5";
            }
            player.displayClientMessage(net.minecraft.network.chat.Component.translatable(key).withStyle(net.minecraft.ChatFormatting.DARK_AQUA), false);
            level.playSound(null, pos, dev.tc4port.thaumcraft.registry.TCSounds.ALEMBIC_KNOCK.get(), net.minecraft.sounds.SoundSource.BLOCKS, 0.2F, 1.0F);
        }
        return net.minecraft.world.InteractionResult.sidedSuccess(level.isClientSide);
    }

    @Override
    public boolean hasAnalogOutputSignal(BlockState state) {
        return true;
    }

    @Override
    public int getAnalogOutputSignal(BlockState state, Level level, BlockPos pos) {
        return level.getBlockEntity(pos) instanceof ArcaneAlembicBlockEntity alembic ? alembic.comparatorOutput() : 0;
    }

    @Override
    public void onRemove(BlockState state, Level level, BlockPos pos, BlockState newState, boolean movedByPiston) {
        if (!state.is(newState.getBlock()) && !level.isClientSide && level.getBlockEntity(pos) instanceof ArcaneAlembicBlockEntity alembic && alembic.aspectFilter() != null) {
            dev.tc4port.thaumcraft.loot.BlockRemovalLoot.drop((net.minecraft.server.level.ServerLevel) level, pos, state, alembic, "alembic_label");
        }
        super.onRemove(state, level, pos, newState, movedByPiston);
    }

    private ArcaneAlembicBlock(net.minecraft.world.level.block.state.BlockBehaviour.Properties native$NativeEntityBlock$arg0, BlockBehaviour.Properties properties, boolean native$NativeEntityBlock$captured) {
        super(native$NativeEntityBlock$arg0);
        this.registerDefaultState(this.stateDefinition.any().setValue(FACING, Direction.NORTH));
    }

    @Override
    public void initializeClient(java.util.function.Consumer<net.minecraftforge.client.extensions.common.IClientBlockExtensions> installer) {
        platform$clientInstaller = installer;
        super.initializeClient(installer);
    }

    @Override
    public void platform$clientExtension(Object extension) {
        java.util.Objects.requireNonNull(platform$clientInstaller, "Forge initializeClient must run before client extension registration").accept((net.minecraftforge.client.extensions.common.IClientBlockExtensions) extension);
    }

    @Override
    public InteractionResult use(BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
        ItemUseResult result = (switch(0) {
            default ->
                {
                    net.minecraft.world.item.ItemStack native$bodyOperand$4072 = player.getItemInHand(hand);
                    net.minecraft.world.level.block.state.BlockState native$bodyOperand$4073 = state;
                    net.minecraft.world.level.Level native$bodyOperand$4074 = level;
                    net.minecraft.core.BlockPos native$bodyOperand$4075 = pos;
                    net.minecraft.world.entity.player.Player native$bodyOperand$4076 = player;
                    net.minecraft.world.InteractionHand native$bodyOperand$4077 = hand;
                    net.minecraft.world.phys.BlockHitResult native$bodyOperand$4078 = hit;
                    dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult native$bodyResult$4084 = null;
                    native$bodyReturn$4085: {
                        if (true) {
                            if (!(native$bodyOperand$4074.getBlockEntity(native$bodyOperand$4075) instanceof dev.tc4port.thaumcraft.block.entity.ArcaneAlembicBlockEntity native$bodyBinding$4079)) {
                                {
                                    native$bodyResult$4084 = dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
                                    break native$bodyReturn$4085;
                                }
                            }
                            if (native$bodyOperand$4072.getItem() instanceof dev.tc4port.thaumcraft.api.wand.WandCarrierItem) {
                                if (native$bodyOperand$4078.getDirection().getAxis().isHorizontal()) {
                                    if (!native$bodyOperand$4074.isClientSide) {
                                        native$bodyOperand$4074.setBlock(native$bodyOperand$4075, native$bodyOperand$4073.setValue(dev.tc4port.thaumcraft.block.ArcaneAlembicBlock.FACING, native$bodyOperand$4078.getDirection()), net.minecraft.world.level.block.Block.UPDATE_ALL);
                                    }
                                    native$bodyOperand$4076.swing(native$bodyOperand$4077);
                                }
                                {
                                    native$bodyResult$4084 = dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.sidedSuccess(native$bodyOperand$4074.isClientSide);
                                    break native$bodyReturn$4085;
                                }
                            }
                            if (native$bodyOperand$4076.isShiftKeyDown() && native$bodyBinding$4079.aspectFilter() != null) {
                                {
                                    native$bodyResult$4084 = dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
                                    break native$bodyReturn$4085;
                                }
                            }
                            if (native$bodyOperand$4072.is(dev.tc4port.thaumcraft.registry.TCItems.byId("jar_label").get()) && native$bodyBinding$4079.aspectFilter() == null) {
                                dev.tc4port.thaumcraft.api.aspect.AspectId native$bodyBinding$4080 = native$bodyBinding$4079.aspect();
                                if (native$bodyBinding$4080 == null) {
                                    native$bodyBinding$4080 = (switch(0) {
                                        default ->
                                            {
                                                dev.tc4port.thaumcraft.api.data.ItemStateKey<dev.tc4port.thaumcraft.api.aspect.AspectId> native$bodyBinding$4081 = dev.tc4port.thaumcraft.state.TCItemState.JAR_FILTER;
                                                net.minecraft.world.item.ItemStack native$bodyBinding$4082 = native$bodyOperand$4072;
                                                java.util.Objects.requireNonNull(native$bodyBinding$4081);
                                                yield dev.tc4port.thaumcraft.api.item.ItemStatePlatform.get(native$bodyBinding$4082, native$bodyBinding$4081);
                                            }
                                    });
                                }
                                if (native$bodyBinding$4080 == null) {
                                    {
                                        native$bodyResult$4084 = dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.CONSUME;
                                        break native$bodyReturn$4085;
                                    }
                                }
                                if (!native$bodyOperand$4074.isClientSide && native$bodyBinding$4079.setFilter(native$bodyBinding$4080)) {
                                    // TC4 decremented the held stack directly, including in
                                    // creative mode. Preserve that behavior instead of using
                                    // ItemStack.consume(), which exempts creative players.
                                    native$bodyOperand$4072.shrink(1);
                                    native$bodyOperand$4074.playSound(null, native$bodyOperand$4075, dev.tc4port.thaumcraft.registry.TCSounds.PAGE.get(), net.minecraft.sounds.SoundSource.BLOCKS, 1.0F, 0.9F);
                                }
                                {
                                    native$bodyResult$4084 = dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.sidedSuccess(native$bodyOperand$4074.isClientSide);
                                    break native$bodyReturn$4085;
                                }
                            }
                            dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult native$bodyBinding$4083 = fillJarFromAlembic(native$bodyOperand$4072, native$bodyOperand$4074, native$bodyOperand$4075, native$bodyOperand$4076, native$bodyOperand$4077, native$bodyBinding$4079);
                            if (native$bodyBinding$4083 != dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION) {
                                {
                                    native$bodyResult$4084 = native$bodyBinding$4083;
                                    break native$bodyReturn$4085;
                                }
                            }
                            {
                                native$bodyResult$4084 = dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
                                break native$bodyReturn$4085;
                            }
                        }
                    }
                    yield native$bodyResult$4084;
                }
        });
        return result == ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION ? (hand == InteractionHand.MAIN_HAND ? (switch(0) {
            default ->
                {
                    net.minecraft.world.level.block.state.BlockState native$bodyOperand$3432 = state;
                    net.minecraft.world.level.Level native$bodyOperand$3433 = level;
                    net.minecraft.core.BlockPos native$bodyOperand$3434 = pos;
                    net.minecraft.world.entity.player.Player native$bodyOperand$3435 = player;
                    net.minecraft.world.phys.BlockHitResult native$bodyOperand$3436 = hit;
                    net.minecraft.world.InteractionResult native$bodyResult$3441 = null;
                    native$bodyReturn$3442: {
                        if (true) {
                            if (!(native$bodyOperand$3433.getBlockEntity(native$bodyOperand$3434) instanceof dev.tc4port.thaumcraft.block.entity.ArcaneAlembicBlockEntity native$bodyBinding$3437)) {
                                {
                                    native$bodyResult$3441 = net.minecraft.world.InteractionResult.PASS;
                                    break native$bodyReturn$3442;
                                }
                            }
                            if (native$bodyOperand$3435.isShiftKeyDown()) {
                                if (!native$bodyOperand$3433.isClientSide) {
                                    if (native$bodyBinding$3437.aspectFilter() != null) {
                                        if (native$bodyBinding$3437.clearFilter()) {
                                            net.minecraft.core.Direction native$bodyBinding$3438 = native$bodyOperand$3436.getDirection();
                                            ((net.minecraft.server.level.ServerLevel) native$bodyOperand$3433).addFreshEntity(new net.minecraft.world.entity.item.ItemEntity(native$bodyOperand$3433, native$bodyOperand$3434.getX() + 0.5 + native$bodyBinding$3438.getStepX() / 3.0, native$bodyOperand$3434.getY() + 0.5, native$bodyOperand$3434.getZ() + 0.5 + native$bodyBinding$3438.getStepZ() / 3.0, new net.minecraft.world.item.ItemStack(dev.tc4port.thaumcraft.registry.TCItems.byId("jar_label").get())));
                                            native$bodyOperand$3433.playSound(null, native$bodyOperand$3434, dev.tc4port.thaumcraft.registry.TCSounds.PAGE.get(), net.minecraft.sounds.SoundSource.BLOCKS, 1.0F, 1.1F);
                                        }
                                        {
                                            native$bodyResult$3441 = net.minecraft.world.InteractionResult.SUCCESS;
                                            break native$bodyReturn$3442;
                                        }
                                    }
                                    native$bodyBinding$3437.clearContents();
                                    native$bodyOperand$3433.playSound(null, native$bodyOperand$3434, dev.tc4port.thaumcraft.registry.TCSounds.ALEMBIC_KNOCK.get(), net.minecraft.sounds.SoundSource.BLOCKS, 0.2F, 1.0F);
                                    native$bodyOperand$3433.playSound(null, native$bodyOperand$3434, dev.tc4port.thaumcraft.registry.TCSounds.ESSENTIA_POUR.get(), net.minecraft.sounds.SoundSource.BLOCKS, 0.5F, 1.0F + (native$bodyOperand$3433.random.nextFloat() - native$bodyOperand$3433.random.nextFloat()) * 0.3F);
                                }
                                {
                                    native$bodyResult$3441 = net.minecraft.world.InteractionResult.sidedSuccess(native$bodyOperand$3433.isClientSide);
                                    break native$bodyReturn$3442;
                                }
                            }
                            if (!native$bodyOperand$3433.isClientSide) {
                                java.lang.String native$bodyBinding$3439;
                                int native$bodyBinding$3440 = native$bodyBinding$3437.amount();
                                if (native$bodyBinding$3440 <= 0) {
                                    native$bodyBinding$3439 = "tile.alembic.msg.1";
                                } else if (native$bodyBinding$3440 < native$bodyBinding$3437.capacity() * 0.4) {
                                    native$bodyBinding$3439 = "tile.alembic.msg.2";
                                } else if (native$bodyBinding$3440 < native$bodyBinding$3437.capacity() * 0.8) {
                                    native$bodyBinding$3439 = "tile.alembic.msg.3";
                                } else if (native$bodyBinding$3440 < native$bodyBinding$3437.capacity()) {
                                    native$bodyBinding$3439 = "tile.alembic.msg.4";
                                } else {
                                    native$bodyBinding$3439 = "tile.alembic.msg.5";
                                }
                                native$bodyOperand$3435.displayClientMessage(net.minecraft.network.chat.Component.translatable(native$bodyBinding$3439).withStyle(net.minecraft.ChatFormatting.DARK_AQUA), false);
                                native$bodyOperand$3433.playSound(null, native$bodyOperand$3434, dev.tc4port.thaumcraft.registry.TCSounds.ALEMBIC_KNOCK.get(), net.minecraft.sounds.SoundSource.BLOCKS, 0.2F, 1.0F);
                            }
                            {
                                native$bodyResult$3441 = net.minecraft.world.InteractionResult.sidedSuccess(native$bodyOperand$3433.isClientSide);
                                break native$bodyReturn$3442;
                            }
                        }
                    }
                    yield native$bodyResult$3441;
                }
        }) : InteractionResult.PASS) : result.result();
    }

    @Override
    public void playerWillDestroy(Level level, BlockPos pos, BlockState state, Player player) {
        {
            net.minecraft.world.level.Level native$bodyOperand$5630 = level;
            net.minecraft.core.BlockPos native$bodyOperand$5631 = pos;
            net.minecraft.world.level.block.state.BlockState native$bodyOperand$5632 = state;
            net.minecraft.world.entity.player.Player native$bodyOperand$5633 = player;
            net.minecraft.world.level.block.state.BlockState native$bodyResult$5634 = null;
            native$bodyReturn$5635: {
                if (true) {
                    super.playerWillDestroy(native$bodyOperand$5630, native$bodyOperand$5631, native$bodyOperand$5632, native$bodyOperand$5633);
                    {
                        native$bodyResult$5634 = native$bodyOperand$5632;
                        break native$bodyReturn$5635;
                    }
                }
            }
        }
    }

    public BlockState beforePlayerDestroy(Level level, BlockPos pos, BlockState state, Player player) {
        super.playerWillDestroy(level, pos, state, player);
        return state;
    }

    protected boolean survivesSharedExplosion() {
        return false;
    }

    public int getExpDrop(net.minecraft.world.level.block.state.BlockState native$callbackInput$1050, net.minecraft.world.level.LevelReader native$callbackInput$1051, net.minecraft.util.RandomSource native$callbackInput$1052, net.minecraft.core.BlockPos native$callbackInput$1053, int native$callbackInput$1054, int native$callbackInput$1055) {
        net.minecraft.world.level.block.state.BlockState state = native$callbackInput$1050;
        net.minecraft.util.RandomSource random = native$callbackInput$1052;
        return 0;
    }

    @Override
    public void onBlockExploded(BlockState state, Level level, BlockPos pos, Explosion explosion) {
        if (!(switch(0) {
            default ->
                {
                    boolean native$bodyResult$5205 = false;
                    native$bodyReturn$5206: {
                        if (true) {
                            {
                                native$bodyResult$5205 = false;
                                break native$bodyReturn$5206;
                            }
                        }
                    }
                    yield native$bodyResult$5205;
                }
        }))
            super.onBlockExploded(state, level, pos, explosion);
    }

    @Override
    public boolean canDropFromExplosion(BlockState state, BlockGetter level, BlockPos pos, Explosion explosion) {
        return !(switch(0) {
            default ->
                {
                    boolean native$bodyResult$4086 = false;
                    native$bodyReturn$4087: {
                        if (true) {
                            {
                                native$bodyResult$4086 = false;
                                break native$bodyReturn$4087;
                            }
                        }
                    }
                    yield native$bodyResult$4086;
                }
        }) && super.canDropFromExplosion(state, level, pos, explosion);
    }

    static private <B extends net.minecraft.world.level.block.Block> com.mojang.serialization.MapCodec<B> native$BlockCodecPlatform$simple(java.util.function.Function<net.minecraft.world.level.block.state.BlockBehaviour.Properties, B> factory) {
        // Vanilla 1.21's Properties codec is a unit codec. Retain that schema for shared block definitions.
        return com.mojang.serialization.codecs.RecordCodecBuilder.mapCodec(instance -> instance.group(com.mojang.serialization.Codec.unit(net.minecraft.world.level.block.state.BlockBehaviour.Properties::of).fieldOf("properties").forGetter((B block) -> net.minecraft.world.level.block.state.BlockBehaviour.Properties.copy(block))).apply(instance, factory));
    }
}
