package dev.tc4port.thaumcraft.api.golem;

import dev.tc4port.thaumcraft.entity.ThaumcraftGolemEntity;
import java.util.Optional;
import net.minecraft.core.GlobalPos;
import net.minecraft.world.entity.Entity;

/**
 * Read-only golem compatibility view; mutations remain permission-specific.
 */
public final class GolemApi {

    private GolemApi() {
    }

    public static boolean isGolem(Entity entity) {
        return entity instanceof ThaumcraftGolemEntity;
    }

    public static net.minecraft.core.Direction homeSide(Entity entity) {
        if (!(entity instanceof ThaumcraftGolemEntity golem))
            throw new IllegalArgumentException("Not a Thaumcraft golem");
        return golem.getHomeFace();
    }

    public static Optional<GolemView> view(Entity entity) {
        if (!(entity instanceof ThaumcraftGolemEntity golem)) {
            return Optional.empty();
        }
        Optional<GlobalPos> home = golem.hasRestriction() ? Optional.of(GlobalPos.of(golem.level().dimension(), golem.getRestrictCenter())) : Optional.empty();
        return Optional.of(new GolemView(golem.getDecoration(), Optional.ofNullable(golem.coreId()).map(dev.tc4port.thaumcraft.common.GolemCoreId::value), home, golem.markerSnapshot().stream().filter(marker -> marker.color() >= -1 && marker.color() <= 15).map(marker -> new GolemMarkerView(GlobalPos.of(marker.dimension(), marker.pos()), marker.side(), marker.color())).toList(), golem.getGolemType().stableLocation(), golem.position(), golem.getHealth(), golem.getMaxHealth(), golem.activitySnapshot()));
    }
}
