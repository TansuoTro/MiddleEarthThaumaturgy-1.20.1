package dev.tc4port.thaumcraft.block.entity;

import dev.tc4port.thaumcraft.nativeimpl.NativeFluidTank;
import dev.tc4port.thaumcraft.api.event.WorldProtection;
import dev.tc4port.thaumcraft.block.FiniteFluidBlock;
import dev.tc4port.thaumcraft.block.PurifyingFluidBlock;
import dev.tc4port.thaumcraft.menu.ArcaneSpaMenu;
import dev.tc4port.thaumcraft.registry.TCBlockEntities;
import dev.tc4port.thaumcraft.registry.TCBlocks;
import dev.tc4port.thaumcraft.registry.TCItems;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.HolderLookup;
import net.minecraft.core.NonNullList;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.WorldlyContainer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.ContainerData;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.material.Fluids;
import net.minecraft.world.level.block.entity.BaseContainerBlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityType;

/**
 * Source-parity implementation of TC4's {@code TileSpa}.
 */
public final class ArcaneSpaBlockEntity extends net.minecraft.world.level.block.entity.BaseContainerBlockEntity implements WorldlyContainer {

    public static final int SALTS_SLOT = 0;

    public static final int CONTAINER_SIZE = 1;

    public static final int TANK_CAPACITY = 5_000;

    public static int configuredTankCapacity() {
        return dev.tc4port.thaumcraft.common.TCGameplayParameters.MACHINES_SPA_TANK_CAPACITY.intValue();
    }

    public static final int OUTPUT_INTERVAL = 40;

    public static int configuredOutputInterval() {
        return dev.tc4port.thaumcraft.common.TCGameplayParameters.MACHINES_SPA_OUTPUT_INTERVAL.intValue();
    }

    private static final String TANK_KEY = "Tank";

    private static final int[] SALTS_SLOT_ARRAY = { SALTS_SLOT };

    private static final int[] NO_SLOTS = {};

    private NonNullList<ItemStack> items = NonNullList.withSize(CONTAINER_SIZE, ItemStack.EMPTY);

    private boolean mix = true;

    private int counter;

    private final NativeFluidTank tank = new NativeAnonymous0(ArcaneSpaBlockEntity::configuredTankCapacity);

    private final ContainerData data = new ContainerData() {

        @Override
        public int get(int index) {
            return switch(index) {
                case 0 ->
                    ArcaneSpaBlockEntity.this.mix ? 1 : 0;
                case 1 ->
                    ArcaneSpaBlockEntity.this.tank.getFluidAmount();
                default ->
                    0;
            };
        }

        @Override
        public void set(int index, int value) {
            if (index == 0) {
                ArcaneSpaBlockEntity.this.mix = value != 0;
            }
        }

        @Override
        public int getCount() {
            return 2;
        }
    };

    public ArcaneSpaBlockEntity(BlockPos pos, BlockState state) {
        super(TCBlockEntities.ARCANE_SPA.get(), pos, state);
    }

    /**
     * Original {@code counter++ % 40 == 0}: a newly placed spa can work on
     * its first registered server tick, then once every forty ticks.
     */
    public static void serverTick(Level level, BlockPos pos, BlockState state, ArcaneSpaBlockEntity spa) {
        if (!(level instanceof ServerLevel serverLevel) || spa.counter++ % configuredOutputInterval() != 0 || !level.hasChunksAt(pos.offset(-2, 0, -2), pos.offset(2, 0, 2)) || level.hasNeighborSignal(pos) || !spa.hasIngredients()) {
            return;
        }
        net.minecraftforge.fluids.FluidStack stored = spa.tank.getFluid();
        BlockPos center = pos.above();
        BlockState output = spa.mix ? TCBlocks.PURIFYING_FLUID.get().defaultBlockState() : outputState(serverLevel, center, stored);
        if (output == null) {
            return;
        }
        BlockState centerState = serverLevel.getBlockState(center);
        if (sameLegacySource(centerState, output)) {
            for (int x = -2; x <= 2; x++) {
                for (int z = -2; z <= 2; z++) {
                    BlockPos target = center.offset(x, 0, z);
                    if (isValidLocation(serverLevel, target, true, output, stored)) {
                        spa.consumeIngredients();
                        serverLevel.setBlock(target, output, 3);
                        return;
                    }
                }
            }
        } else if (isValidLocation(serverLevel, center, false, output, stored)) {
            spa.consumeIngredients();
            serverLevel.setBlock(center, output, 3);
        }
    }

    private static BlockState outputState(ServerLevel level, BlockPos pos, net.minecraftforge.fluids.FluidStack stack) {
        if (stack.isEmpty() || !(switch(0) {
            default ->
                {
                    net.minecraftforge.fluids.FluidStack native$operand$13659 = stack;
                    net.minecraft.world.level.Level native$operand$13660 = level;
                    net.minecraft.core.BlockPos native$operand$13661 = pos;
                    boolean native$result$13662 = (native$operand$13659.getFluid().getFluidType().canBePlacedInLevel(native$operand$13660, native$operand$13661, native$operand$13659));
                    yield native$result$13662;
                }
        })) {
            return null;
        }
        return ArcaneSpaBlockEntity.native$NativeFluidFunctions$blockForPlacement(stack, level, pos);
    }

    private static boolean isValidLocation(ServerLevel level, BlockPos pos, boolean mustBeAdjacent, BlockState output, net.minecraftforge.fluids.FluidStack stored) {
        /*
         * TileSpa rejected only vanilla water in an isHellWorld provider.
         * Purifying Fluid itself was allowed in the Nether.
         */
        if (!stored.isEmpty() && (switch(0) {
            default ->
                {
                    net.minecraftforge.fluids.FluidStack native$operand$13326 = stored;
                    net.minecraft.world.level.material.Fluid native$operand$13327 = Fluids.WATER;
                    boolean native$result$13328 = (native$operand$13326.getFluid() == native$operand$13327);
                    yield native$result$13328;
                }
        }) && output.getFluidState().is(Fluids.WATER) && level.dimensionType().ultraWarm()) {
            return false;
        }
        if (!level.isLoaded(pos))
            return false;
        BlockState current = level.getBlockState(pos);
        if (!WorldProtection.allow(level, pos, WorldProtection.Action.FILL_FLUID, null)) {
            return false;
        }
        BlockState below = level.getBlockState(pos.below());
        boolean sameBlock = current.is(output.getBlock());
        boolean replaceable = current.canBeReplaced() || /*
                 * All old liquid materials were replaceable. Keep that rule
                 * for a non-source state of the same output block even when
                 * a modern custom fluid shape has stricter item placement.
                 */
        sameBlock && !sameLegacySource(current, output);
        if (!below.isFaceSturdy(level, pos.below(), Direction.UP) || !replaceable || sameBlock && sameLegacySource(current, output)) {
            return false;
        }
        if (!mustBeAdjacent) {
            return true;
        }
        for (Direction direction : Direction.values()) {
            if (level.isLoaded(pos.relative(direction)) && sameLegacySource(level.getBlockState(pos.relative(direction)), output)) {
                return true;
            }
        }
        return false;
    }

    /**
     * Metadata zero, not merely "full fluid", was the exact source check.
     */
    private static boolean sameLegacySource(BlockState state, BlockState output) {
        if (!state.is(output.getBlock())) {
            return false;
        }
        if (state.getBlock() instanceof PurifyingFluidBlock) {
            return state.getValue(PurifyingFluidBlock.LEVEL) == 0;
        }
        if (state.getBlock() instanceof FiniteFluidBlock) {
            return state.getValue(FiniteFluidBlock.LEVEL) == 0;
        }
        return !state.getFluidState().isEmpty() ? state.getFluidState().isSource() : state.equals(output);
    }

    public boolean hasIngredients() {
        if (this.mix) {
            return !this.tank.isEmpty() && (switch(0) {
                default ->
                    {
                        net.minecraftforge.fluids.FluidStack native$operand$12963 = this.tank.getFluid();
                        net.minecraft.world.level.material.Fluid native$operand$12964 = Fluids.WATER;
                        boolean native$result$12965 = (native$operand$12963.getFluid() == native$operand$12964);
                        yield native$result$12965;
                    }
            }) && this.tank.getFluidAmount() >= net.minecraftforge.fluids.FluidType.BUCKET_VOLUME && this.items.get(SALTS_SLOT).is(TCItems.BATH_SALTS.get());
        }
        if (this.tank.getFluidAmount() < net.minecraftforge.fluids.FluidType.BUCKET_VOLUME || this.level == null) {
            return false;
        }
        BlockPos outputPos = this.worldPosition.above();
        return (switch(0) {
            default ->
                {
                    net.minecraftforge.fluids.FluidStack native$operand$14334 = this.tank.getFluid();
                    net.minecraft.world.level.Level native$operand$14335 = this.level;
                    net.minecraft.core.BlockPos native$operand$14336 = outputPos;
                    boolean native$result$14337 = (native$operand$14334.getFluid().getFluidType().canBePlacedInLevel(native$operand$14335, native$operand$14336, native$operand$14334));
                    yield native$result$14337;
                }
        });
    }

    private void consumeIngredients() {
        if (this.mix) {
            this.removeItem(SALTS_SLOT, 1);
        }
        this.tank.drain(net.minecraftforge.fluids.FluidType.BUCKET_VOLUME, net.minecraftforge.fluids.capability.IFluidHandler.FluidAction.EXECUTE);
        this.changedAndSync();
    }

    public void toggleMix() {
        this.mix = !this.mix;
        this.changedAndSync();
    }

    public boolean mix() {
        return this.mix;
    }

    public NativeFluidTank tank() {
        return this.tank;
    }

    public ContainerData data() {
        return this.data;
    }

    public int counter() {
        return this.counter;
    }

    @Override
    public int[] getSlotsForFace(Direction side) {
        return side == Direction.UP ? NO_SLOTS : SALTS_SLOT_ARRAY;
    }

    @Override
    public boolean canPlaceItemThroughFace(int slot, ItemStack stack, Direction direction) {
        return direction != Direction.UP && this.canPlaceItem(slot, stack);
    }

    @Override
    public boolean canTakeItemThroughFace(int slot, ItemStack stack, Direction direction) {
        return direction != Direction.UP;
    }

    @Override
    public boolean canPlaceItem(int slot, ItemStack stack) {
        return slot == SALTS_SLOT && stack.is(TCItems.BATH_SALTS.get());
    }

    @Override
    public int getContainerSize() {
        return CONTAINER_SIZE;
    }

    @Override
    protected Component getDefaultName() {
        return Component.translatable("container.thaumcraft.arcane_spa");
    }

    protected NonNullList<ItemStack> getItems() {
        return this.items;
    }

    protected void setItems(NonNullList<ItemStack> items) {
        this.items = items;
    }

    @Override
    public void load(CompoundTag tag) {
        HolderLookup.Provider registries = persistenceRegistries();
        super.load(tag);
        if (tag.contains("Items")) {
            this.items = NonNullList.withSize(CONTAINER_SIZE, ItemStack.EMPTY);
            {
                net.minecraft.nbt.CompoundTag native$operand$13663 = tag;
                net.minecraft.core.NonNullList<net.minecraft.world.item.ItemStack> native$operand$13664 = this.items;
                net.minecraft.core.HolderLookup.Provider native$operand$13665 = registries;
                net.minecraft.world.ContainerHelper.loadAllItems(native$operand$13663, native$operand$13664);
            }
        }
        if (tag.contains("mix")) {
            this.mix = tag.getBoolean("mix");
        }
        FluidTankStorage.load(this.tank, tag, TANK_KEY, registries);
        // The original counter was transient and restarted after load.
        this.counter = 0;
    }

    @Override
    protected void saveAdditional(CompoundTag tag) {
        HolderLookup.Provider registries = persistenceRegistries();
        super.saveAdditional(tag);
        {
            net.minecraft.nbt.CompoundTag native$operand$14338 = tag;
            net.minecraft.core.NonNullList<net.minecraft.world.item.ItemStack> native$operand$14339 = this.items;
            net.minecraft.core.HolderLookup.Provider native$operand$14340 = registries;
            net.minecraft.nbt.CompoundTag native$result$14341 = (net.minecraft.world.ContainerHelper.saveAllItems(native$operand$14338, native$operand$14339));
        }
        saveSyncedState(tag, registries);
    }

    private void saveSyncedState(CompoundTag tag, HolderLookup.Provider registries) {
        tag.putBoolean("mix", this.mix);
        FluidTankStorage.save(this.tank, tag, TANK_KEY, registries);
    }

    @Override
    public CompoundTag getUpdateTag() {
        HolderLookup.Provider registries = persistenceRegistries();
        CompoundTag tag = new CompoundTag();
        saveSyncedState(tag, registries);
        return tag;
    }

    @Override
    public Packet<ClientGamePacketListener> getUpdatePacket() {
        return ClientboundBlockEntityDataPacket.create(this);
    }

    public void changedAndSync() {
        super.setChanged();
        BlockEntitySync.sendToClient(this);
    }

    @Override
    protected AbstractContainerMenu createMenu(int containerId, Inventory inventory) {
        // Vanilla spectator opening bypasses our extra-data menu transport.
        if (inventory.player.isSpectator()) {
            return null;
        }
        return new ArcaneSpaMenu(containerId, inventory, this, this.data);
    }

    private class NativeAnonymous0 extends NativeFluidTank {

        NativeAnonymous0(java.util.function.IntSupplier native$arg0) {
            super(native$arg0);
        }

        @Override
        protected void onContentsChanged() {
            ArcaneSpaBlockEntity.this.changedAndSync();
        }
    }

    protected final HolderLookup.Provider persistenceRegistries() {
        if (level != null)
            return level.registryAccess();
        var server = net.minecraftforge.server.ServerLifecycleHooks.getCurrentServer();
        return server != null ? server.registryAccess() : net.minecraft.core.RegistryAccess.fromRegistryOfRegistries(net.minecraft.core.registries.BuiltInRegistries.REGISTRY);
    }

    protected static net.minecraft.network.chat.Component parseCustomNameSafe(String value, HolderLookup.Provider registries) {
        try {
            return net.minecraft.network.chat.Component.Serializer.fromJson(value);
        } catch (RuntimeException exception) {
            return null;
        }
    }

    @Override
    public boolean isEmpty() {
        return (switch(0) {
            default ->
                {
                    net.minecraft.core.NonNullList<net.minecraft.world.item.ItemStack> native$bodyResult$4852 = null;
                    native$bodyReturn$4853: {
                        if (true) {
                            {
                                native$bodyResult$4852 = this.items;
                                break native$bodyReturn$4853;
                            }
                        }
                    }
                    yield native$bodyResult$4852;
                }
        }).stream().allMatch(ItemStack::isEmpty);
    }

    @Override
    public ItemStack getItem(int index) {
        return (switch(0) {
            default ->
                {
                    net.minecraft.core.NonNullList<net.minecraft.world.item.ItemStack> native$bodyResult$5355 = null;
                    native$bodyReturn$5356: {
                        if (true) {
                            {
                                native$bodyResult$5355 = this.items;
                                break native$bodyReturn$5356;
                            }
                        }
                    }
                    yield native$bodyResult$5355;
                }
        }).get(index);
    }

    @Override
    public ItemStack removeItem(int index, int count) {
        ItemStack removed = net.minecraft.world.ContainerHelper.removeItem((switch(0) {
            default ->
                {
                    net.minecraft.core.NonNullList<net.minecraft.world.item.ItemStack> native$bodyResult$3951 = null;
                    native$bodyReturn$3952: {
                        if (true) {
                            {
                                native$bodyResult$3951 = this.items;
                                break native$bodyReturn$3952;
                            }
                        }
                    }
                    yield native$bodyResult$3951;
                }
        }), index, count);
        if (!removed.isEmpty())
            setChanged();
        return removed;
    }

    @Override
    public ItemStack removeItemNoUpdate(int index) {
        return net.minecraft.world.ContainerHelper.takeItem((switch(0) {
            default ->
                {
                    net.minecraft.core.NonNullList<net.minecraft.world.item.ItemStack> native$bodyResult$5357 = null;
                    native$bodyReturn$5358: {
                        if (true) {
                            {
                                native$bodyResult$5357 = this.items;
                                break native$bodyReturn$5358;
                            }
                        }
                    }
                    yield native$bodyResult$5357;
                }
        }), index);
    }

    @Override
    public void setItem(int index, ItemStack stack) {
        (switch(0) {
            default ->
                {
                    net.minecraft.core.NonNullList<net.minecraft.world.item.ItemStack> native$bodyResult$5359 = null;
                    native$bodyReturn$5360: {
                        if (true) {
                            {
                                native$bodyResult$5359 = this.items;
                                break native$bodyReturn$5360;
                            }
                        }
                    }
                    yield native$bodyResult$5359;
                }
        }).set(index, stack);
        int limit = Math.min(getMaxStackSize(), stack.getMaxStackSize());
        if (stack.getCount() > limit)
            stack.setCount(limit);
        setChanged();
    }

    @Override
    public void clearContent() {
        (switch(0) {
            default ->
                {
                    net.minecraft.core.NonNullList<net.minecraft.world.item.ItemStack> native$bodyResult$5361 = null;
                    native$bodyReturn$5362: {
                        if (true) {
                            {
                                native$bodyResult$5361 = this.items;
                                break native$bodyReturn$5362;
                            }
                        }
                    }
                    yield native$bodyResult$5361;
                }
        }).clear();
    }

    @Override
    public boolean stillValid(net.minecraft.world.entity.player.Player player) {
        return net.minecraft.world.Container.stillValidBlockEntity(this, player);
    }

    @Override
    public net.minecraft.world.phys.AABB getRenderBoundingBox() {
        return ArcaneSpaBlockEntity.native$ClientBlockEntityBounds$bounds(this);
    }

    @Override()
    public void onDataPacket(net.minecraft.network.Connection connection, net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket packet) {
        handleUpdateTag(packet.getTag());
    }

    static private net.minecraft.world.level.block.state.BlockState native$NativeFluidFunctions$blockForPlacement(net.minecraftforge.fluids.FluidStack stack, net.minecraft.world.level.Level level, net.minecraft.core.BlockPos pos) {
        var type = stack.getFluid().getFluidType();
        return type.getBlockForFluidState(level, pos, type.getStateForPlacement(level, pos, stack));
    }

    @SuppressWarnings({ "rawtypes", "unchecked" })
    static private net.minecraft.world.phys.AABB native$ClientBlockEntityBounds$bounds(net.minecraft.world.level.block.entity.BlockEntity blockEntity) {
        var renderer = net.minecraft.client.Minecraft.getInstance().getBlockEntityRenderDispatcher().getRenderer(blockEntity);
        return renderer instanceof dev.tc4port.thaumcraft.nativeimpl.NativeBlockEntityRenderer shared ? shared.getRenderBoundingBox(blockEntity) : new net.minecraft.world.phys.AABB(blockEntity.getBlockPos());
    }

    private boolean native$capabilitiesInvalid$16948;

    public boolean native$capabilityActive$16796;

    private java.util.Map<net.minecraft.core.Direction, net.minecraftforge.common.util.LazyOptional<net.minecraftforge.fluids.capability.IFluidHandler>> native$capabilityHandle$16797;

    public boolean native$capabilityActive$16800;

    private java.util.Map<net.minecraft.core.Direction, net.minecraftforge.common.util.LazyOptional<net.minecraftforge.items.IItemHandler>> native$capabilityHandle$16801;

    @Override
    public <native$capabilityResultType$16949> net.minecraftforge.common.util.LazyOptional<native$capabilityResultType$16949> getCapability(net.minecraftforge.common.capabilities.Capability<native$capabilityResultType$16949> native$requestedCapability$16950, net.minecraft.core.Direction native$requestedFace$16951) {
        getCapabilities();
        synchronized (this) {
            if (native$capabilitiesInvalid$16948)
                return net.minecraftforge.common.util.LazyOptional.empty();
            if (native$capabilityActive$16796 && native$requestedCapability$16950 == (net.minecraftforge.common.capabilities.ForgeCapabilities.FLUID_HANDLER)) {
                if (native$capabilityHandle$16797 == null)
                    native$capabilityHandle$16797 = new java.util.HashMap<>();
                net.minecraftforge.common.util.LazyOptional<net.minecraftforge.fluids.capability.IFluidHandler> native$capabilityResult$16953 = native$capabilityHandle$16797.computeIfAbsent(native$requestedFace$16951, native$capabilityFace$16798 -> {
                    net.minecraftforge.fluids.capability.IFluidHandler native$endpoint$91 = (switch(0) {
                        default ->
                            {
                                dev.tc4port.thaumcraft.block.entity.ArcaneSpaBlockEntity spa = dev.tc4port.thaumcraft.block.entity.ArcaneSpaBlockEntity.this;
                                net.minecraft.core.Direction side = native$capabilityFace$16798;
                                yield side == net.minecraft.core.Direction.UP ? null : spa.tank();
                            }
                    });
                    return native$endpoint$91 == null ? net.minecraftforge.common.util.LazyOptional.empty() : net.minecraftforge.common.util.LazyOptional.of(() -> native$endpoint$91);
                });
                if (native$capabilityResult$16953.isPresent())
                    return native$capabilityResult$16953.cast();
            }
            if (native$capabilityActive$16800 && native$requestedCapability$16950 == (net.minecraftforge.common.capabilities.ForgeCapabilities.ITEM_HANDLER)) {
                if (native$capabilityHandle$16801 == null)
                    native$capabilityHandle$16801 = new java.util.HashMap<>();
                net.minecraftforge.common.util.LazyOptional<net.minecraftforge.items.IItemHandler> native$capabilityResult$16954 = native$capabilityHandle$16801.computeIfAbsent(native$requestedFace$16951, native$capabilityFace$16802 -> {
                    net.minecraftforge.items.IItemHandler native$endpoint$106 = (switch(0) {
                        default ->
                            {
                                net.minecraft.world.WorldlyContainer native$operand$12758 = dev.tc4port.thaumcraft.block.entity.ArcaneSpaBlockEntity.this;
                                net.minecraft.core.Direction native$operand$12759 = native$capabilityFace$16802;
                                net.minecraftforge.items.IItemHandler native$result$12760 = (new net.minecraftforge.items.wrapper.SidedInvWrapper(native$operand$12758, native$operand$12759));
                                yield native$result$12760;
                            }
                    });
                    return native$endpoint$106 == null ? net.minecraftforge.common.util.LazyOptional.empty() : net.minecraftforge.common.util.LazyOptional.of(() -> native$endpoint$106);
                });
                if (native$capabilityResult$16954.isPresent())
                    return native$capabilityResult$16954.cast();
            }
        }
        return super.getCapability(native$requestedCapability$16950, native$requestedFace$16951);
    }

    @Override
    public void invalidateCaps() {
        java.util.List<net.minecraftforge.common.util.LazyOptional<?>> native$expiredCapabilities$16952 = new java.util.ArrayList<>();
        synchronized (this) {
            native$capabilitiesInvalid$16948 = true;
            if (native$capabilityHandle$16797 != null) {
                native$expiredCapabilities$16952.addAll(native$capabilityHandle$16797.values());
                native$capabilityHandle$16797 = null;
            }
            if (native$capabilityHandle$16801 != null) {
                native$expiredCapabilities$16952.addAll(native$capabilityHandle$16801.values());
                native$capabilityHandle$16801 = null;
            }
        }
        try {
            super.invalidateCaps();
        } finally {
            native$expiredCapabilities$16952.forEach(net.minecraftforge.common.util.LazyOptional::invalidate);
        }
    }

    @Override
    public void reviveCaps() {
        super.reviveCaps();
        synchronized (this) {
            native$capabilitiesInvalid$16948 = false;
        }
    }
}
