package dev.tc4port.thaumcraft.api.event;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.damagesource.DamageSource;
import java.util.function.Consumer;
import java.util.function.Supplier;

/**
 * Live native damage state; mutations take effect at the registered engine phase.
 */
public record Damage(LivingEntity getEntity, DamageSource getSource, Supplier<Float> amount, Consumer<Float> update, Consumer<Boolean> cancellation) {

    public float getAmount() {
        return amount.get();
    }

    public float getNewDamage() {
        return getAmount();
    }

    public void setAmount(float value) {
        update.accept(value);
    }

    public void setNewDamage(float value) {
        setAmount(value);
    }

    public void setCanceled(boolean value) {
        cancellation.accept(value);
    }
}
