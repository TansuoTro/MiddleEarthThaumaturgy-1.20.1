package dev.tc4port.thaumcraft.block.entity;

import dev.tc4port.thaumcraft.registry.TCBlockEntities;
import dev.tc4port.thaumcraft.api.block.WardingAuraApi;
import java.util.List;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import java.lang.Math;
import dev.tc4port.thaumcraft.nativeimpl.state.ItemFields;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityType;

/**
 * Tick behavior from TC4's {@code TileWardingStone}.
 */
public final class PavingStoneWardingBlockEntity extends net.minecraft.world.level.block.entity.BlockEntity implements ItemFields.Source {

    private int counter;

    public PavingStoneWardingBlockEntity(BlockPos pos, BlockState state) {
        super(TCBlockEntities.PAVING_STONE_WARDING.get(), pos, state);
    }

    public static void tick(Level level, BlockPos pos, BlockState state, PavingStoneWardingBlockEntity stone) {
        WardingAuraApi.syncBlockingState(level, pos.above());
        WardingAuraApi.syncBlockingState(level, pos.above(2));
        if (stone.counter == 0) {
            stone.counter = level.random.nextInt(100);
        }
        if (stone.counter % 5 == 0 && level.hasChunksAt(pos.offset(-2, 0, -2), pos.offset(2, 0, 2)) && !level.hasNeighborSignal(pos)) {
            pushAirborneCreatures(level, pos);
        }
        stone.counter++;
        if (stone.counter % 100 == 0) {
            WardingAuraApi.ensureAura(level, pos.above());
            WardingAuraApi.ensureAura(level, pos.above(2));
        }
    }

    private static void pushAirborneCreatures(Level level, BlockPos pos) {
        AABB column = new AABB(pos.getX(), pos.getY(), pos.getZ(), pos.getX() + 1.0, pos.getY() + 3.0, pos.getZ() + 1.0).inflate(0.1);
        List<LivingEntity> targets = level.getEntitiesOfClass(LivingEntity.class, column, entity -> !(entity instanceof Player) && !entity.onGround());
        for (LivingEntity entity : targets) {
            if (level instanceof ServerLevel serverLevel && !serverLevel.isPositionEntityTicking(entity.blockPosition())) {
                continue;
            }
            double angle = Math.toRadians(entity.getYRot() + 180.0F);
            entity.push(-Math.sin(angle) * 0.2, -0.1, Math.cos(angle) * 0.2);
        }
    }

    protected final HolderLookup.Provider persistenceRegistries() {
        if (level != null)
            return level.registryAccess();
        var server = net.minecraftforge.server.ServerLifecycleHooks.getCurrentServer();
        return server != null ? server.registryAccess() : net.minecraft.core.RegistryAccess.fromRegistryOfRegistries(net.minecraft.core.registries.BuiltInRegistries.REGISTRY);
    }

    protected static net.minecraft.network.chat.Component parseCustomNameSafe(String value, HolderLookup.Provider registries) {
        try {
            return net.minecraft.network.chat.Component.Serializer.fromJson(value);
        } catch (RuntimeException exception) {
            return null;
        }
    }

    protected void readItemFields(ItemFields.Input input) {
    }

    public void copyItemFields(ItemFields.Output output) {
    }

    public void applyComponentsFromItemStack(ItemStack stack) {
        readItemFields(ItemFields.from(stack));
    }

    public void removeComponentsFromTag(CompoundTag tag) {
    }

    @Override
    public void saveToItem(ItemStack stack) {
        CompoundTag tag = saveWithoutMetadata();
        {
            net.minecraft.nbt.CompoundTag native$bodyOperand$6214 = tag;
            native$bodyReturn$6216: {
                if (true) {
                }
            }
        }
        net.minecraft.world.item.BlockItem.setBlockEntityData(stack, getType(), tag);
        copyItemFields(ItemFields.to(stack));
    }

    @Override
    public net.minecraft.world.phys.AABB getRenderBoundingBox() {
        return PavingStoneWardingBlockEntity.native$ClientBlockEntityBounds$bounds(this);
    }

    @Override()
    public void onDataPacket(net.minecraft.network.Connection connection, net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket packet) {
        handleUpdateTag(packet.getTag());
    }

    @SuppressWarnings({ "rawtypes", "unchecked" })
    static private net.minecraft.world.phys.AABB native$ClientBlockEntityBounds$bounds(net.minecraft.world.level.block.entity.BlockEntity blockEntity) {
        var renderer = net.minecraft.client.Minecraft.getInstance().getBlockEntityRenderDispatcher().getRenderer(blockEntity);
        return renderer instanceof dev.tc4port.thaumcraft.nativeimpl.NativeBlockEntityRenderer shared ? shared.getRenderBoundingBox(blockEntity) : new net.minecraft.world.phys.AABB(blockEntity.getBlockPos());
    }
}
