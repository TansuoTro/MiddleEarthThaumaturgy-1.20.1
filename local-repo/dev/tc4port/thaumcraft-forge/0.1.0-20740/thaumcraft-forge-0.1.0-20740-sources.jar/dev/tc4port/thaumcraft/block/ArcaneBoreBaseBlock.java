package dev.tc4port.thaumcraft.block;

import dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult;
import com.mojang.serialization.MapCodec;
import dev.tc4port.thaumcraft.block.entity.ArcaneBoreBaseBlockEntity;
import dev.tc4port.thaumcraft.common.WandInteractionTarget;
import dev.tc4port.thaumcraft.api.wand.WandCarrierItem;
import dev.tc4port.thaumcraft.registry.TCSounds;
import javax.annotation.Nullable;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.DirectionProperty;
import net.minecraft.world.phys.BlockHitResult;
import dev.tc4port.thaumcraft.nativeimpl.ClientExtensionTarget;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.level.pathfinder.PathComputationType;
import net.minecraft.world.phys.HitResult;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.Explosion;

/**
 * Metadata four of BlockWoodenDevice. The facing is the item-output nozzle
 * direction and also the one face on which the base advertises no suction.
 */
public final class ArcaneBoreBaseBlock extends net.minecraft.world.level.block.BaseEntityBlock implements WandInteractionTarget, dev.tc4port.thaumcraft.nativeimpl.ClientExtensionTarget {

    // Forge calls initializeClient from the native superclass constructor. Do not add a field initializer.
    private java.util.function.Consumer<net.minecraftforge.client.extensions.common.IClientBlockExtensions> platform$clientInstaller;

    public static final MapCodec<ArcaneBoreBaseBlock> CODEC = ArcaneBoreBaseBlock.native$BlockCodecPlatform$simple(ArcaneBoreBaseBlock::new);

    public static final DirectionProperty FACING = BlockStateProperties.FACING;

    public ArcaneBoreBaseBlock(BlockBehaviour.Properties properties) {
        this(properties, properties, true);
    }

    protected MapCodec<ArcaneBoreBaseBlock> codec() {
        return CODEC;
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(FACING);
    }

    @Nullable
    @Override
    public BlockState getStateForPlacement(BlockPlaceContext context) {
        /*
         * Give a newly placed base the same player-facing horizontal pose as
         * the drill itself. A wand can still select all six source directions
         * afterwards, including UP and DOWN.
         */
        return this.defaultBlockState().setValue(FACING, context.getHorizontalDirection().getOpposite());
    }

    protected ItemUseResult interactWithItem(ItemStack stack, BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
        if (!(stack.getItem() instanceof dev.tc4port.thaumcraft.api.wand.WandCarrierItem)) {
            return dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
        }
        if (!level.isClientSide) {
            level.setBlock(pos, state.setValue(dev.tc4port.thaumcraft.block.ArcaneBoreBaseBlock.FACING, hit.getDirection()), net.minecraft.world.level.block.Block.UPDATE_ALL);
            level.playSound(null, pos, dev.tc4port.thaumcraft.registry.TCSounds.TOOL.get(), net.minecraft.sounds.SoundSource.BLOCKS, 0.3F, 1.9F + level.random.nextFloat() * 0.2F);
        }
        player.swing(hand);
        return dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.sidedSuccess(level.isClientSide);
    }

    @Nullable
    @Override
    public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        return new ArcaneBoreBaseBlockEntity(pos, state);
    }

    @Override
    public RenderShape getRenderShape(BlockState state) {
        return RenderShape.MODEL;
    }

    @Override
    public int getLightBlock(BlockState state, BlockGetter level, BlockPos pos) {
        return 0;
    }

    @Override
    public boolean canConnectRedstone(BlockState state, BlockGetter level, BlockPos pos, @Nullable Direction direction) {
        return direction != null;
    }

    private ArcaneBoreBaseBlock(net.minecraft.world.level.block.state.BlockBehaviour.Properties native$NativeEntityBlock$arg0, BlockBehaviour.Properties properties, boolean native$NativeEntityBlock$captured) {
        super(native$NativeEntityBlock$arg0);
        this.registerDefaultState(this.stateDefinition.any().setValue(FACING, Direction.NORTH));
    }

    @Override
    public void initializeClient(java.util.function.Consumer<net.minecraftforge.client.extensions.common.IClientBlockExtensions> installer) {
        platform$clientInstaller = installer;
        super.initializeClient(installer);
    }

    @Override
    public void platform$clientExtension(Object extension) {
        java.util.Objects.requireNonNull(platform$clientInstaller, "Forge initializeClient must run before client extension registration").accept((net.minecraftforge.client.extensions.common.IClientBlockExtensions) extension);
    }

    @Override
    public InteractionResult use(BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
        ItemUseResult result = (switch(0) {
            default ->
                {
                    net.minecraft.world.item.ItemStack native$bodyOperand$4099 = player.getItemInHand(hand);
                    net.minecraft.world.level.block.state.BlockState native$bodyOperand$4100 = state;
                    net.minecraft.world.level.Level native$bodyOperand$4101 = level;
                    net.minecraft.core.BlockPos native$bodyOperand$4102 = pos;
                    net.minecraft.world.entity.player.Player native$bodyOperand$4103 = player;
                    net.minecraft.world.InteractionHand native$bodyOperand$4104 = hand;
                    net.minecraft.world.phys.BlockHitResult native$bodyOperand$4105 = hit;
                    dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult native$bodyResult$4106 = null;
                    native$bodyReturn$4107: {
                        if (true) {
                            if (!(native$bodyOperand$4099.getItem() instanceof dev.tc4port.thaumcraft.api.wand.WandCarrierItem)) {
                                {
                                    native$bodyResult$4106 = dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
                                    break native$bodyReturn$4107;
                                }
                            }
                            if (!native$bodyOperand$4101.isClientSide) {
                                native$bodyOperand$4101.setBlock(native$bodyOperand$4102, native$bodyOperand$4100.setValue(dev.tc4port.thaumcraft.block.ArcaneBoreBaseBlock.FACING, native$bodyOperand$4105.getDirection()), net.minecraft.world.level.block.Block.UPDATE_ALL);
                                native$bodyOperand$4101.playSound(null, native$bodyOperand$4102, dev.tc4port.thaumcraft.registry.TCSounds.TOOL.get(), net.minecraft.sounds.SoundSource.BLOCKS, 0.3F, 1.9F + native$bodyOperand$4101.random.nextFloat() * 0.2F);
                            }
                            native$bodyOperand$4103.swing(native$bodyOperand$4104);
                            {
                                native$bodyResult$4106 = dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.sidedSuccess(native$bodyOperand$4101.isClientSide);
                                break native$bodyReturn$4107;
                            }
                        }
                    }
                    yield native$bodyResult$4106;
                }
        });
        return result == ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION ? (hand == InteractionHand.MAIN_HAND ? (switch(0) {
            default ->
                {
                    net.minecraft.world.level.block.state.BlockState native$bodyOperand$3450 = state;
                    net.minecraft.world.level.Level native$bodyOperand$3451 = level;
                    net.minecraft.core.BlockPos native$bodyOperand$3452 = pos;
                    net.minecraft.world.entity.player.Player native$bodyOperand$3453 = player;
                    net.minecraft.world.phys.BlockHitResult native$bodyOperand$3454 = hit;
                    net.minecraft.world.InteractionResult native$bodyResult$3455 = null;
                    native$bodyReturn$3456: {
                        if (true) {
                            {
                                native$bodyResult$3455 = super.use(native$bodyOperand$3450, native$bodyOperand$3451, native$bodyOperand$3452, native$bodyOperand$3453, net.minecraft.world.InteractionHand.MAIN_HAND, native$bodyOperand$3454);
                                break native$bodyReturn$3456;
                            }
                        }
                    }
                    yield native$bodyResult$3455;
                }
        }) : InteractionResult.PASS) : result.result();
    }

    protected InteractionResult interactWithoutItem(BlockState state, Level level, BlockPos pos, Player player, BlockHitResult hit) {
        return super.use(state, level, pos, player, net.minecraft.world.InteractionHand.MAIN_HAND, hit);
    }

    @Override
    public void playerWillDestroy(Level level, BlockPos pos, BlockState state, Player player) {
        {
            net.minecraft.world.level.Level native$bodyOperand$5642 = level;
            net.minecraft.core.BlockPos native$bodyOperand$5643 = pos;
            net.minecraft.world.level.block.state.BlockState native$bodyOperand$5644 = state;
            net.minecraft.world.entity.player.Player native$bodyOperand$5645 = player;
            net.minecraft.world.level.block.state.BlockState native$bodyResult$5646 = null;
            native$bodyReturn$5647: {
                if (true) {
                    super.playerWillDestroy(native$bodyOperand$5642, native$bodyOperand$5643, native$bodyOperand$5644, native$bodyOperand$5645);
                    {
                        native$bodyResult$5646 = native$bodyOperand$5644;
                        break native$bodyReturn$5647;
                    }
                }
            }
        }
    }

    public BlockState beforePlayerDestroy(Level level, BlockPos pos, BlockState state, Player player) {
        super.playerWillDestroy(level, pos, state, player);
        return state;
    }

    protected boolean survivesSharedExplosion() {
        return false;
    }

    public int getExpDrop(net.minecraft.world.level.block.state.BlockState native$callbackInput$1050, net.minecraft.world.level.LevelReader native$callbackInput$1051, net.minecraft.util.RandomSource native$callbackInput$1052, net.minecraft.core.BlockPos native$callbackInput$1053, int native$callbackInput$1054, int native$callbackInput$1055) {
        net.minecraft.world.level.block.state.BlockState state = native$callbackInput$1050;
        net.minecraft.util.RandomSource random = native$callbackInput$1052;
        return 0;
    }

    @Override
    public void onBlockExploded(BlockState state, Level level, BlockPos pos, Explosion explosion) {
        if (!(switch(0) {
            default ->
                {
                    boolean native$bodyResult$5209 = false;
                    native$bodyReturn$5210: {
                        if (true) {
                            {
                                native$bodyResult$5209 = false;
                                break native$bodyReturn$5210;
                            }
                        }
                    }
                    yield native$bodyResult$5209;
                }
        }))
            super.onBlockExploded(state, level, pos, explosion);
    }

    @Override
    public boolean canDropFromExplosion(BlockState state, BlockGetter level, BlockPos pos, Explosion explosion) {
        return !(switch(0) {
            default ->
                {
                    boolean native$bodyResult$4108 = false;
                    native$bodyReturn$4109: {
                        if (true) {
                            {
                                native$bodyResult$4108 = false;
                                break native$bodyReturn$4109;
                            }
                        }
                    }
                    yield native$bodyResult$4108;
                }
        }) && super.canDropFromExplosion(state, level, pos, explosion);
    }

    static private <B extends net.minecraft.world.level.block.Block> com.mojang.serialization.MapCodec<B> native$BlockCodecPlatform$simple(java.util.function.Function<net.minecraft.world.level.block.state.BlockBehaviour.Properties, B> factory) {
        // Vanilla 1.21's Properties codec is a unit codec. Retain that schema for shared block definitions.
        return com.mojang.serialization.codecs.RecordCodecBuilder.mapCodec(instance -> instance.group(com.mojang.serialization.Codec.unit(net.minecraft.world.level.block.state.BlockBehaviour.Properties::of).fieldOf("properties").forGetter((B block) -> net.minecraft.world.level.block.state.BlockBehaviour.Properties.copy(block))).apply(instance, factory));
    }
}
