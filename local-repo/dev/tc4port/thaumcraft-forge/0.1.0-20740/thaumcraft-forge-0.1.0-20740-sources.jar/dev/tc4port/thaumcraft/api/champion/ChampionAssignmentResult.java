package dev.tc4port.thaumcraft.api.champion;

import java.util.Objects;
import java.util.Optional;

/**
 * Result plus the actual assigned identity after built-in substitutions.
 */
public record ChampionAssignmentResult(ChampionAssignmentStatus status, Optional<ChampionId> assignedId) {

    public ChampionAssignmentResult {
        Objects.requireNonNull(status, "status");
        assignedId = Objects.requireNonNull(assignedId, "assignedId");
        if ((status == ChampionAssignmentStatus.APPLIED) != assignedId.isPresent()) {
            throw new IllegalArgumentException("Only an applied assignment may carry an identity");
        }
    }

    public boolean applied() {
        return this.status == ChampionAssignmentStatus.APPLIED;
    }
}
