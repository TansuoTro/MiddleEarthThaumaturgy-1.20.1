package dev.tc4port.thaumcraft.api.recipe;

import dev.tc4port.thaumcraft.api.aspect.AspectAmounts;
import net.minecraft.world.item.ItemStack;

/**
 * Stable-id addon cost hook for infusion enchantment recipes.
 *
 * <p>A recipe opts in with {@code "cost_transformation": "<id>"}. Each hook
 * receives a defensive copy of the real central item and the cost the core
 * formula computed for it, and returns the cost the altar quotes, displays and
 * charges. Matching, stage selection and the enchanted output are unchanged.
 * Hooks must be deterministic and side-effect free. The registration must
 * remain active for as long as a recipe referring to its id may be selected.</p>
 */
public interface InfusionEnchantmentCostTransformation {

    /**
     * Returns the aspect cost; amounts use the recipe's aspect bounds.
     */
    default AspectAmounts aspects(ItemStack centralInput, AspectAmounts base) {
        return base;
    }

    /**
     * Returns the recipe instability, between zero and the altar limit.
     */
    default int instability(ItemStack centralInput, int base) {
        return base;
    }

    /**
     * Returns the non-negative cost in whole player experience levels.
     */
    default int experienceLevels(ItemStack centralInput, int base) {
        return base;
    }
}
