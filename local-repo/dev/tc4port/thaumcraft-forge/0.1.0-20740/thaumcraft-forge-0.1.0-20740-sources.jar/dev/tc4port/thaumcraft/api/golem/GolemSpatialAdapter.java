package dev.tc4port.thaumcraft.api.golem;

import java.util.Optional;
import java.util.OptionalDouble;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.phys.Vec3;

/**
 * Source-level extension point for alternate golem coordinate spaces.
 *
 * <p>An addon implements this interface once and registers it through
 * {@link GolemSpatialAdapters}. Tasks, path caching, recovery limits and
 * transaction state machines remain owned by Thaumcraft.</p>
 */
public interface GolemSpatialAdapter {

    ResourceLocation id();

    /**
     * Higher values are queried first; equal priorities use the id order.
     */
    default int priority() {
        return 0;
    }

    /**
     * Returns empty when this adapter does not own the requested route.
     */
    Optional<GolemTravelFrame> resolve(GolemTravelContext context);

    /**
     * Supplies a coordinate-space-specific recovery only when necessary.
     * Returning empty keeps the core's ordinary collision-checked recovery.
     */
    default Optional<GolemRecoveryAction> recover(GolemTravelContext context, GolemTravelFrame frame, int attempt) {
        return Optional.empty();
    }

    /**
     * Optional point-to-point metric used by task scans which are not active
     * navigation requests.
     */
    default OptionalDouble distanceSquared(ServerLevel level, Vec3 first, Vec3 second) {
        return OptionalDouble.empty();
    }
}
