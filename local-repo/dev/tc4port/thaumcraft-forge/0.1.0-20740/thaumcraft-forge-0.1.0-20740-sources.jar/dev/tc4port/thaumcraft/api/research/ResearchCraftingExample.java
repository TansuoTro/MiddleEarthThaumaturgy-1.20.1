package dev.tc4port.thaumcraft.api.research;

import java.util.List;
import java.util.Objects;
import net.minecraft.world.item.ItemStack;

/**
 * One complete, component-preserving example of a dynamic crafting recipe.
 */
public record ResearchCraftingExample(int width, List<ItemStack> inputs, ItemStack output) {

    public ResearchCraftingExample {
        inputs = Objects.requireNonNull(inputs, "inputs").stream().map(ItemStack::copy).toList();
        output = Objects.requireNonNull(output, "output").copy();
        if (width < 1 || width > 3 || inputs.isEmpty() || inputs.size() % width != 0 || inputs.size() / width > 3 || output.isEmpty()) {
            throw new IllegalArgumentException("Invalid research crafting example");
        }
    }

    @Override
    public List<ItemStack> inputs() {
        return inputs.stream().map(ItemStack::copy).toList();
    }

    @Override
    public ItemStack output() {
        return output.copy();
    }
}
