package dev.tc4port.thaumcraft.block;

import dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult;
import com.mojang.serialization.MapCodec;
import dev.tc4port.thaumcraft.block.entity.ArcaneBoreBlockEntity;
import dev.tc4port.thaumcraft.common.WandInteractionTarget;
import dev.tc4port.thaumcraft.api.wand.WandCarrierItem;
import dev.tc4port.thaumcraft.registry.TCBlockEntities;
import dev.tc4port.thaumcraft.registry.TCBlocks;
import dev.tc4port.thaumcraft.registry.TCSounds;
import javax.annotation.Nullable;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.Containers;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityTicker;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.DirectionProperty;
import net.minecraft.world.level.pathfinder.PathComputationType;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;
import java.lang.Math;
import dev.tc4port.thaumcraft.nativeimpl.ClientExtensionTarget;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.phys.HitResult;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.Explosion;

/**
 * Metadata five of BlockWoodenDevice. The source block deliberately gave the
 * moving drill a two-block selection/collision box in its mining direction.
 */
public final class ArcaneBoreBlock extends net.minecraft.world.level.block.BaseEntityBlock implements WandInteractionTarget, dev.tc4port.thaumcraft.nativeimpl.ClientExtensionTarget {

    // Forge calls initializeClient from the native superclass constructor. Do not add a field initializer.
    private java.util.function.Consumer<net.minecraftforge.client.extensions.common.IClientBlockExtensions> platform$clientInstaller;

    public static final MapCodec<ArcaneBoreBlock> CODEC = ArcaneBoreBlock.native$BlockCodecPlatform$simple(ArcaneBoreBlock::new);

    public static final DirectionProperty FACING = BlockStateProperties.FACING;

    public static final DirectionProperty BASE_DIRECTION = DirectionProperty.create("base_direction");

    public ArcaneBoreBlock(BlockBehaviour.Properties properties) {
        this(properties, properties, true);
    }

    protected MapCodec<ArcaneBoreBlock> codec() {
        return CODEC;
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(FACING, BASE_DIRECTION);
    }

    @Nullable
    @Override
    public BlockState getStateForPlacement(BlockPlaceContext context) {
        Direction baseDirection = context.getClickedFace();
        if (baseDirection.getAxis() != Direction.Axis.Y) {
            return null;
        }
        return this.defaultBlockState().setValue(BASE_DIRECTION, baseDirection).setValue(FACING, legacyPlacementFacing(context));
    }

    private static Direction legacyPlacementFacing(BlockPlaceContext context) {
        Player player = context.getPlayer();
        BlockPos pos = context.getClickedPos();
        if (player != null && Math.abs(player.getX() - pos.getX()) < 2.0 && Math.abs(player.getZ() - pos.getZ()) < 2.0) {
            double eyeY = player.getEyeY();
            if (eyeY - pos.getY() > 2.0) {
                return Direction.UP;
            }
            if (pos.getY() - eyeY > 0.0) {
                return Direction.DOWN;
            }
        }
        return player == null ? context.getNearestLookingDirection().getOpposite() : player.getDirection().getOpposite();
    }

    @Override
    public boolean canSurvive(BlockState state, net.minecraft.world.level.LevelReader level, BlockPos pos) {
        Direction baseDirection = state.getValue(BASE_DIRECTION);
        if (baseDirection.getAxis() != Direction.Axis.Y) {
            return false;
        }
        BlockPos basePos = pos.relative(baseDirection.getOpposite());
        return level.getBlockState(basePos).is(TCBlocks.ARCANE_BORE_BASE.get());
    }

    @Override
    public void neighborChanged(BlockState state, Level level, BlockPos pos, Block neighborBlock, BlockPos neighborPos, boolean movedByPiston) {
        super.neighborChanged(state, level, pos, neighborBlock, neighborPos, movedByPiston);
        if (!level.isClientSide && !state.canSurvive(level, pos)) {
            level.destroyBlock(pos, true);
        }
    }

    @Override
    public VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
        return directionalTwoBlockShape(state.getValue(FACING));
    }

    @Override
    public VoxelShape getCollisionShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
        return directionalTwoBlockShape(state.getValue(FACING));
    }

    private static VoxelShape directionalTwoBlockShape(Direction facing) {
        return switch(facing) {
            case DOWN ->
                Shapes.box(0.0, -1.0, 0.0, 1.0, 1.0, 1.0);
            case UP ->
                Shapes.box(0.0, 0.0, 0.0, 1.0, 2.0, 1.0);
            case NORTH ->
                Shapes.box(0.0, 0.0, -1.0, 1.0, 1.0, 1.0);
            case SOUTH ->
                Shapes.box(0.0, 0.0, 0.0, 1.0, 1.0, 2.0);
            case WEST ->
                Shapes.box(-1.0, 0.0, 0.0, 1.0, 1.0, 1.0);
            case EAST ->
                Shapes.box(0.0, 0.0, 0.0, 2.0, 1.0, 1.0);
        };
    }

    protected ItemUseResult interactWithItem(ItemStack stack, BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
        if (!(stack.getItem() instanceof dev.tc4port.thaumcraft.api.wand.WandCarrierItem)) {
            return dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
        }
        if (!level.isClientSide) {
            net.minecraft.world.level.block.state.BlockState changed = state.setValue(dev.tc4port.thaumcraft.block.ArcaneBoreBlock.FACING, hit.getDirection());
            level.setBlock(pos, changed, net.minecraft.world.level.block.Block.UPDATE_ALL);
            if (level.getBlockEntity(pos) instanceof dev.tc4port.thaumcraft.block.entity.ArcaneBoreBlockEntity bore) {
                bore.orientationChanged(false);
            }
            level.playSound(null, pos, dev.tc4port.thaumcraft.registry.TCSounds.TOOL.get(), net.minecraft.sounds.SoundSource.BLOCKS, 0.5F, 0.9F + level.random.nextFloat() * 0.2F);
        }
        player.swing(hand);
        return dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.sidedSuccess(level.isClientSide);
    }

    protected InteractionResult interactWithoutItem(BlockState state, Level level, BlockPos pos, Player player, BlockHitResult hit) {
        if (!level.isClientSide && player instanceof net.minecraft.server.level.ServerPlayer serverPlayer && level.getBlockEntity(pos) instanceof dev.tc4port.thaumcraft.block.entity.ArcaneBoreBlockEntity bore) {
            net.minecraftforge.network.NetworkHooks.openScreen((net.minecraft.server.level.ServerPlayer) (serverPlayer), (net.minecraft.world.MenuProvider) (bore), (net.minecraft.core.BlockPos) (pos));
        }
        return net.minecraft.world.InteractionResult.sidedSuccess(level.isClientSide);
    }

    @Override
    public void onRemove(BlockState state, Level level, BlockPos pos, BlockState newState, boolean movedByPiston) {
        if (!state.is(newState.getBlock()) && level.getBlockEntity(pos) instanceof ArcaneBoreBlockEntity bore) {
            Containers.dropContents(level, pos, bore);
        }
        super.onRemove(state, level, pos, newState, movedByPiston);
    }

    @Nullable
    @Override
    public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        return new ArcaneBoreBlockEntity(pos, state);
    }

    @Nullable
    @Override
    public <T extends BlockEntity> BlockEntityTicker<T> getTicker(Level level, BlockState state, BlockEntityType<T> type) {
        return createTickerHelper(type, TCBlockEntities.ARCANE_BORE.get(), level.isClientSide ? ArcaneBoreBlockEntity::clientTick : ArcaneBoreBlockEntity::serverTick);
    }

    @Override
    public RenderShape getRenderShape(BlockState state) {
        return RenderShape.ENTITYBLOCK_ANIMATED;
    }

    @Override
    public VoxelShape getBlockSupportShape(BlockState state, BlockGetter level, BlockPos pos) {
        return Shapes.empty();
    }

    @Override
    public int getLightBlock(BlockState state, BlockGetter level, BlockPos pos) {
        return 0;
    }

    @Override
    public boolean canConnectRedstone(BlockState state, BlockGetter level, BlockPos pos, @Nullable Direction direction) {
        return direction != null;
    }

    @Override
    public boolean isPathfindable(BlockState state, BlockGetter level, BlockPos pos, PathComputationType pathType) {
        // The bore collides across two cells, so its own cell is never open.
        return false;
    }

    private ArcaneBoreBlock(net.minecraft.world.level.block.state.BlockBehaviour.Properties native$NativeEntityBlock$arg0, BlockBehaviour.Properties properties, boolean native$NativeEntityBlock$captured) {
        super(native$NativeEntityBlock$arg0);
        this.registerDefaultState(this.stateDefinition.any().setValue(FACING, Direction.UP).setValue(BASE_DIRECTION, Direction.UP));
    }

    @Override
    public void initializeClient(java.util.function.Consumer<net.minecraftforge.client.extensions.common.IClientBlockExtensions> installer) {
        platform$clientInstaller = installer;
        super.initializeClient(installer);
    }

    @Override
    public void platform$clientExtension(Object extension) {
        java.util.Objects.requireNonNull(platform$clientInstaller, "Forge initializeClient must run before client extension registration").accept((net.minecraftforge.client.extensions.common.IClientBlockExtensions) extension);
    }

    @Override
    public InteractionResult use(BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
        ItemUseResult result = (switch(0) {
            default ->
                {
                    net.minecraft.world.item.ItemStack native$bodyOperand$4110 = player.getItemInHand(hand);
                    net.minecraft.world.level.block.state.BlockState native$bodyOperand$4111 = state;
                    net.minecraft.world.level.Level native$bodyOperand$4112 = level;
                    net.minecraft.core.BlockPos native$bodyOperand$4113 = pos;
                    net.minecraft.world.entity.player.Player native$bodyOperand$4114 = player;
                    net.minecraft.world.InteractionHand native$bodyOperand$4115 = hand;
                    net.minecraft.world.phys.BlockHitResult native$bodyOperand$4116 = hit;
                    dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult native$bodyResult$4119 = null;
                    native$bodyReturn$4120: {
                        if (true) {
                            if (!(native$bodyOperand$4110.getItem() instanceof dev.tc4port.thaumcraft.api.wand.WandCarrierItem)) {
                                {
                                    native$bodyResult$4119 = dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
                                    break native$bodyReturn$4120;
                                }
                            }
                            if (!native$bodyOperand$4112.isClientSide) {
                                net.minecraft.world.level.block.state.BlockState native$bodyBinding$4117 = native$bodyOperand$4111.setValue(dev.tc4port.thaumcraft.block.ArcaneBoreBlock.FACING, native$bodyOperand$4116.getDirection());
                                native$bodyOperand$4112.setBlock(native$bodyOperand$4113, native$bodyBinding$4117, net.minecraft.world.level.block.Block.UPDATE_ALL);
                                if (native$bodyOperand$4112.getBlockEntity(native$bodyOperand$4113) instanceof dev.tc4port.thaumcraft.block.entity.ArcaneBoreBlockEntity native$bodyBinding$4118) {
                                    native$bodyBinding$4118.orientationChanged(false);
                                }
                                native$bodyOperand$4112.playSound(null, native$bodyOperand$4113, dev.tc4port.thaumcraft.registry.TCSounds.TOOL.get(), net.minecraft.sounds.SoundSource.BLOCKS, 0.5F, 0.9F + native$bodyOperand$4112.random.nextFloat() * 0.2F);
                            }
                            native$bodyOperand$4114.swing(native$bodyOperand$4115);
                            {
                                native$bodyResult$4119 = dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.sidedSuccess(native$bodyOperand$4112.isClientSide);
                                break native$bodyReturn$4120;
                            }
                        }
                    }
                    yield native$bodyResult$4119;
                }
        });
        return result == ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION ? (hand == InteractionHand.MAIN_HAND ? (switch(0) {
            default ->
                {
                    net.minecraft.world.level.block.state.BlockState native$bodyOperand$3457 = state;
                    net.minecraft.world.level.Level native$bodyOperand$3458 = level;
                    net.minecraft.core.BlockPos native$bodyOperand$3459 = pos;
                    net.minecraft.world.entity.player.Player native$bodyOperand$3460 = player;
                    net.minecraft.world.phys.BlockHitResult native$bodyOperand$3461 = hit;
                    net.minecraft.world.InteractionResult native$bodyResult$3464 = null;
                    native$bodyReturn$3465: {
                        if (true) {
                            if (!native$bodyOperand$3458.isClientSide && native$bodyOperand$3460 instanceof net.minecraft.server.level.ServerPlayer native$bodyBinding$3462 && native$bodyOperand$3458.getBlockEntity(native$bodyOperand$3459) instanceof dev.tc4port.thaumcraft.block.entity.ArcaneBoreBlockEntity native$bodyBinding$3463) {
                                net.minecraftforge.network.NetworkHooks.openScreen((net.minecraft.server.level.ServerPlayer) (native$bodyBinding$3462), (net.minecraft.world.MenuProvider) (native$bodyBinding$3463), (net.minecraft.core.BlockPos) (native$bodyOperand$3459));
                            }
                            {
                                native$bodyResult$3464 = net.minecraft.world.InteractionResult.sidedSuccess(native$bodyOperand$3458.isClientSide);
                                break native$bodyReturn$3465;
                            }
                        }
                    }
                    yield native$bodyResult$3464;
                }
        }) : InteractionResult.PASS) : result.result();
    }

    @Override
    public void playerWillDestroy(Level level, BlockPos pos, BlockState state, Player player) {
        {
            net.minecraft.world.level.Level native$bodyOperand$5648 = level;
            net.minecraft.core.BlockPos native$bodyOperand$5649 = pos;
            net.minecraft.world.level.block.state.BlockState native$bodyOperand$5650 = state;
            net.minecraft.world.entity.player.Player native$bodyOperand$5651 = player;
            net.minecraft.world.level.block.state.BlockState native$bodyResult$5652 = null;
            native$bodyReturn$5653: {
                if (true) {
                    super.playerWillDestroy(native$bodyOperand$5648, native$bodyOperand$5649, native$bodyOperand$5650, native$bodyOperand$5651);
                    {
                        native$bodyResult$5652 = native$bodyOperand$5650;
                        break native$bodyReturn$5653;
                    }
                }
            }
        }
    }

    public BlockState beforePlayerDestroy(Level level, BlockPos pos, BlockState state, Player player) {
        super.playerWillDestroy(level, pos, state, player);
        return state;
    }

    protected boolean survivesSharedExplosion() {
        return false;
    }

    public int getExpDrop(net.minecraft.world.level.block.state.BlockState native$callbackInput$1050, net.minecraft.world.level.LevelReader native$callbackInput$1051, net.minecraft.util.RandomSource native$callbackInput$1052, net.minecraft.core.BlockPos native$callbackInput$1053, int native$callbackInput$1054, int native$callbackInput$1055) {
        net.minecraft.world.level.block.state.BlockState state = native$callbackInput$1050;
        net.minecraft.util.RandomSource random = native$callbackInput$1052;
        return 0;
    }

    @Override
    public void onBlockExploded(BlockState state, Level level, BlockPos pos, Explosion explosion) {
        if (!(switch(0) {
            default ->
                {
                    boolean native$bodyResult$5211 = false;
                    native$bodyReturn$5212: {
                        if (true) {
                            {
                                native$bodyResult$5211 = false;
                                break native$bodyReturn$5212;
                            }
                        }
                    }
                    yield native$bodyResult$5211;
                }
        }))
            super.onBlockExploded(state, level, pos, explosion);
    }

    @Override
    public boolean canDropFromExplosion(BlockState state, BlockGetter level, BlockPos pos, Explosion explosion) {
        return !(switch(0) {
            default ->
                {
                    boolean native$bodyResult$4121 = false;
                    native$bodyReturn$4122: {
                        if (true) {
                            {
                                native$bodyResult$4121 = false;
                                break native$bodyReturn$4122;
                            }
                        }
                    }
                    yield native$bodyResult$4121;
                }
        }) && super.canDropFromExplosion(state, level, pos, explosion);
    }

    static private <B extends net.minecraft.world.level.block.Block> com.mojang.serialization.MapCodec<B> native$BlockCodecPlatform$simple(java.util.function.Function<net.minecraft.world.level.block.state.BlockBehaviour.Properties, B> factory) {
        // Vanilla 1.21's Properties codec is a unit codec. Retain that schema for shared block definitions.
        return com.mojang.serialization.codecs.RecordCodecBuilder.mapCodec(instance -> instance.group(com.mojang.serialization.Codec.unit(net.minecraft.world.level.block.state.BlockBehaviour.Properties::of).fieldOf("properties").forGetter((B block) -> net.minecraft.world.level.block.state.BlockBehaviour.Properties.copy(block))).apply(instance, factory));
    }
}
