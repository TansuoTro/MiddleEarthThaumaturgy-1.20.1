package dev.tc4port.thaumcraft.block;

import com.mojang.serialization.MapCodec;
import dev.tc4port.thaumcraft.block.entity.FocalManipulatorBlockEntity;
import dev.tc4port.thaumcraft.common.PlayerKnowledgeService;
import dev.tc4port.thaumcraft.registry.TCBlockEntities;
import javax.annotation.Nullable;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.Containers;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityTicker;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;
import dev.tc4port.thaumcraft.nativeimpl.ClientExtensionTarget;
import dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.level.pathfinder.PathComputationType;
import net.minecraft.world.phys.HitResult;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.Explosion;

/**
 * Dedicated replacement for BlockStoneDevice metadata 13.
 */
public final class FocalManipulatorBlock extends net.minecraft.world.level.block.BaseEntityBlock implements dev.tc4port.thaumcraft.nativeimpl.ClientExtensionTarget {

    // Forge calls initializeClient from the native superclass constructor. Do not add a field initializer.
    private java.util.function.Consumer<net.minecraftforge.client.extensions.common.IClientBlockExtensions> platform$clientInstaller;

    public static final MapCodec<FocalManipulatorBlock> CODEC = FocalManipulatorBlock.native$BlockCodecPlatform$simple(FocalManipulatorBlock::new);

    public FocalManipulatorBlock(BlockBehaviour.Properties properties) {
        this(properties, properties, true);
    }

    protected MapCodec<FocalManipulatorBlock> codec() {
        return CODEC;
    }

    @Nullable
    @Override
    public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        return new FocalManipulatorBlockEntity(pos, state);
    }

    @Nullable
    @Override
    public <T extends BlockEntity> BlockEntityTicker<T> getTicker(Level level, BlockState state, BlockEntityType<T> type) {
        return createTickerHelper(type, TCBlockEntities.FOCAL_MANIPULATOR.get(), level.isClientSide ? FocalManipulatorBlockEntity::clientTick : FocalManipulatorBlockEntity::serverTick);
    }

    protected InteractionResult interactWithoutItem(BlockState state, Level level, BlockPos pos, Player player, BlockHitResult hit) {
        if (player.isShiftKeyDown()) {
            return net.minecraft.world.InteractionResult.PASS;
        }
        if (level.isClientSide) {
            return net.minecraft.world.InteractionResult.SUCCESS;
        }
        if (!dev.tc4port.thaumcraft.common.PlayerKnowledgeService.get(player).hasCompletedResearch(dev.tc4port.thaumcraft.api.research.ResearchKey.parse("FOCALMANIPULATION"))) {
            player.displayClientMessage(net.minecraft.network.chat.Component.translatable("tc.researchmissing").withStyle(net.minecraft.ChatFormatting.RED), false);
            return net.minecraft.world.InteractionResult.CONSUME;
        }
        if (player instanceof net.minecraft.server.level.ServerPlayer serverPlayer && level.getBlockEntity(pos) instanceof dev.tc4port.thaumcraft.block.entity.FocalManipulatorBlockEntity table) {
            net.minecraftforge.network.NetworkHooks.openScreen((net.minecraft.server.level.ServerPlayer) (serverPlayer), (net.minecraft.world.MenuProvider) (table), (java.util.function.Consumer<net.minecraft.network.FriendlyByteBuf>) (buffer -> buffer.writeBlockPos(pos)));
        }
        return net.minecraft.world.InteractionResult.CONSUME;
    }

    @Override
    public void onRemove(BlockState state, Level level, BlockPos pos, BlockState newState, boolean movedByPiston) {
        if (!state.is(newState.getBlock()) && level.getBlockEntity(pos) instanceof FocalManipulatorBlockEntity table) {
            Containers.dropContents(level, pos, table);
        }
        super.onRemove(state, level, pos, newState, movedByPiston);
    }

    @Override
    public RenderShape getRenderShape(BlockState state) {
        return RenderShape.MODEL;
    }

    @Override
    public VoxelShape getBlockSupportShape(BlockState state, BlockGetter level, BlockPos pos) {
        return Shapes.empty();
    }

    private FocalManipulatorBlock(net.minecraft.world.level.block.state.BlockBehaviour.Properties native$NativeEntityBlock$arg0, BlockBehaviour.Properties properties, boolean native$NativeEntityBlock$captured) {
        super(native$NativeEntityBlock$arg0);
    }

    @Override
    public void initializeClient(java.util.function.Consumer<net.minecraftforge.client.extensions.common.IClientBlockExtensions> installer) {
        platform$clientInstaller = installer;
        super.initializeClient(installer);
    }

    @Override
    public void platform$clientExtension(Object extension) {
        java.util.Objects.requireNonNull(platform$clientInstaller, "Forge initializeClient must run before client extension registration").accept((net.minecraftforge.client.extensions.common.IClientBlockExtensions) extension);
    }

    @Override
    public InteractionResult use(BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
        ItemUseResult result = (switch(0) {
            default ->
                {
                    net.minecraft.world.item.ItemStack native$bodyOperand$4452 = player.getItemInHand(hand);
                    net.minecraft.world.level.block.state.BlockState native$bodyOperand$4453 = state;
                    net.minecraft.world.level.Level native$bodyOperand$4454 = level;
                    net.minecraft.core.BlockPos native$bodyOperand$4455 = pos;
                    net.minecraft.world.entity.player.Player native$bodyOperand$4456 = player;
                    net.minecraft.world.InteractionHand native$bodyOperand$4457 = hand;
                    net.minecraft.world.phys.BlockHitResult native$bodyOperand$4458 = hit;
                    dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult native$bodyResult$4459 = null;
                    native$bodyReturn$4460: {
                        if (true) {
                            {
                                native$bodyResult$4459 = dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
                                break native$bodyReturn$4460;
                            }
                        }
                    }
                    yield native$bodyResult$4459;
                }
        });
        return result == ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION ? (hand == InteractionHand.MAIN_HAND ? (switch(0) {
            default ->
                {
                    net.minecraft.world.level.block.state.BlockState native$bodyOperand$3681 = state;
                    net.minecraft.world.level.Level native$bodyOperand$3682 = level;
                    net.minecraft.core.BlockPos native$bodyOperand$3683 = pos;
                    net.minecraft.world.entity.player.Player native$bodyOperand$3684 = player;
                    net.minecraft.world.phys.BlockHitResult native$bodyOperand$3685 = hit;
                    net.minecraft.world.InteractionResult native$bodyResult$3689 = null;
                    native$bodyReturn$3690: {
                        if (true) {
                            if (native$bodyOperand$3684.isShiftKeyDown()) {
                                {
                                    native$bodyResult$3689 = net.minecraft.world.InteractionResult.PASS;
                                    break native$bodyReturn$3690;
                                }
                            }
                            if (native$bodyOperand$3682.isClientSide) {
                                {
                                    native$bodyResult$3689 = net.minecraft.world.InteractionResult.SUCCESS;
                                    break native$bodyReturn$3690;
                                }
                            }
                            if (!dev.tc4port.thaumcraft.common.PlayerKnowledgeService.get(native$bodyOperand$3684).hasCompletedResearch(dev.tc4port.thaumcraft.api.research.ResearchKey.parse("FOCALMANIPULATION"))) {
                                native$bodyOperand$3684.displayClientMessage(net.minecraft.network.chat.Component.translatable("tc.researchmissing").withStyle(net.minecraft.ChatFormatting.RED), false);
                                {
                                    native$bodyResult$3689 = net.minecraft.world.InteractionResult.CONSUME;
                                    break native$bodyReturn$3690;
                                }
                            }
                            if (native$bodyOperand$3684 instanceof net.minecraft.server.level.ServerPlayer native$bodyBinding$3686 && native$bodyOperand$3682.getBlockEntity(native$bodyOperand$3683) instanceof dev.tc4port.thaumcraft.block.entity.FocalManipulatorBlockEntity native$bodyBinding$3687) {
                                net.minecraftforge.network.NetworkHooks.openScreen((net.minecraft.server.level.ServerPlayer) (native$bodyBinding$3686), (net.minecraft.world.MenuProvider) (native$bodyBinding$3687), (java.util.function.Consumer<net.minecraft.network.FriendlyByteBuf>) (native$bodyBinding$3688 -> native$bodyBinding$3688.writeBlockPos(native$bodyOperand$3683)));
                            }
                            {
                                native$bodyResult$3689 = net.minecraft.world.InteractionResult.CONSUME;
                                break native$bodyReturn$3690;
                            }
                        }
                    }
                    yield native$bodyResult$3689;
                }
        }) : InteractionResult.PASS) : result.result();
    }

    protected ItemUseResult interactWithItem(ItemStack stack, BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
        return dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
    }

    @Override
    public void playerWillDestroy(Level level, BlockPos pos, BlockState state, Player player) {
        {
            net.minecraft.world.level.Level native$bodyOperand$5847 = level;
            net.minecraft.core.BlockPos native$bodyOperand$5848 = pos;
            net.minecraft.world.level.block.state.BlockState native$bodyOperand$5849 = state;
            net.minecraft.world.entity.player.Player native$bodyOperand$5850 = player;
            net.minecraft.world.level.block.state.BlockState native$bodyResult$5851 = null;
            native$bodyReturn$5852: {
                if (true) {
                    super.playerWillDestroy(native$bodyOperand$5847, native$bodyOperand$5848, native$bodyOperand$5849, native$bodyOperand$5850);
                    {
                        native$bodyResult$5851 = native$bodyOperand$5849;
                        break native$bodyReturn$5852;
                    }
                }
            }
        }
    }

    public BlockState beforePlayerDestroy(Level level, BlockPos pos, BlockState state, Player player) {
        super.playerWillDestroy(level, pos, state, player);
        return state;
    }

    protected boolean survivesSharedExplosion() {
        return false;
    }

    public int getExpDrop(net.minecraft.world.level.block.state.BlockState native$callbackInput$1050, net.minecraft.world.level.LevelReader native$callbackInput$1051, net.minecraft.util.RandomSource native$callbackInput$1052, net.minecraft.core.BlockPos native$callbackInput$1053, int native$callbackInput$1054, int native$callbackInput$1055) {
        net.minecraft.world.level.block.state.BlockState state = native$callbackInput$1050;
        net.minecraft.util.RandomSource random = native$callbackInput$1052;
        return 0;
    }

    @Override
    public void onBlockExploded(BlockState state, Level level, BlockPos pos, Explosion explosion) {
        if (!(switch(0) {
            default ->
                {
                    boolean native$bodyResult$5269 = false;
                    native$bodyReturn$5270: {
                        if (true) {
                            {
                                native$bodyResult$5269 = false;
                                break native$bodyReturn$5270;
                            }
                        }
                    }
                    yield native$bodyResult$5269;
                }
        }))
            super.onBlockExploded(state, level, pos, explosion);
    }

    @Override
    public boolean canDropFromExplosion(BlockState state, BlockGetter level, BlockPos pos, Explosion explosion) {
        return !(switch(0) {
            default ->
                {
                    boolean native$bodyResult$4461 = false;
                    native$bodyReturn$4462: {
                        if (true) {
                            {
                                native$bodyResult$4461 = false;
                                break native$bodyReturn$4462;
                            }
                        }
                    }
                    yield native$bodyResult$4461;
                }
        }) && super.canDropFromExplosion(state, level, pos, explosion);
    }

    static private <B extends net.minecraft.world.level.block.Block> com.mojang.serialization.MapCodec<B> native$BlockCodecPlatform$simple(java.util.function.Function<net.minecraft.world.level.block.state.BlockBehaviour.Properties, B> factory) {
        // Vanilla 1.21's Properties codec is a unit codec. Retain that schema for shared block definitions.
        return com.mojang.serialization.codecs.RecordCodecBuilder.mapCodec(instance -> instance.group(com.mojang.serialization.Codec.unit(net.minecraft.world.level.block.state.BlockBehaviour.Properties::of).fieldOf("properties").forGetter((B block) -> net.minecraft.world.level.block.state.BlockBehaviour.Properties.copy(block))).apply(instance, factory));
    }
}
