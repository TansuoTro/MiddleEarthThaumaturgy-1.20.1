package dev.tc4port.thaumcraft.api.gameplay;

import com.google.gson.JsonObject;
import net.minecraft.resources.ResourceLocation;

/**
 * A loaded event's selection data and action definition. Disabled resources are absent.
 * The JSON is defensively copied; editing it cannot modify the server's active catalog.
 */
public record WarpEventDefinition(ResourceLocation id, int minimumRoll, int maximumRoll, double weight, JsonObject definition) {

    public WarpEventDefinition {
        definition = definition.deepCopy();
    }

    @Override
    public JsonObject definition() {
        return definition.deepCopy();
    }
}
