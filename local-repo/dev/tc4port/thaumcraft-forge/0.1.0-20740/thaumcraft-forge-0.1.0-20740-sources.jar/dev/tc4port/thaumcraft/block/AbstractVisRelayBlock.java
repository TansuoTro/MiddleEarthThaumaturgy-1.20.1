package dev.tc4port.thaumcraft.block;

import dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult;
import dev.tc4port.thaumcraft.registry.TCRegistryDataMaps;
import dev.tc4port.thaumcraft.api.data.RelayAttunementDefinition;
import dev.tc4port.thaumcraft.block.entity.VisRelayBlockEntity;
import dev.tc4port.thaumcraft.common.WandInteractionTarget;
import dev.tc4port.thaumcraft.api.wand.WandCarrierItem;
import dev.tc4port.thaumcraft.registry.TCSounds;
import javax.annotation.Nullable;
import net.minecraft.core.BlockPos;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.pathfinder.PathComputationType;
import net.minecraft.world.phys.BlockHitResult;
import dev.tc4port.thaumcraft.nativeimpl.ClientExtensionTarget;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.phys.HitResult;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.Explosion;
import net.minecraft.world.level.BlockGetter;

/**
 * Shared BlockMetalDevice metadata 2/14 tuning interaction.
 */
abstract class AbstractVisRelayBlock extends net.minecraft.world.level.block.BaseEntityBlock implements WandInteractionTarget, dev.tc4port.thaumcraft.nativeimpl.ClientExtensionTarget {

    // Forge calls initializeClient from the native superclass constructor. Do not add a field initializer.
    private java.util.function.Consumer<net.minecraftforge.client.extensions.common.IClientBlockExtensions> platform$clientInstaller;

    AbstractVisRelayBlock(BlockBehaviour.Properties properties) {
        this(properties, properties, true);
    }

    protected ItemUseResult interactWithItem(ItemStack stack, BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
        if (!(level.getBlockEntity(pos) instanceof VisRelayBlockEntity relay)) {
            return ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
        }
        RelayAttunementDefinition tuning = relayAttunement(stack);
        if (!player.isShiftKeyDown() && tuning != null) {
            int slot = tuning.relaySlot();
            if (!level.isClientSide) {
                relay.setAttunement(slot < 0 || relay.attunement() == slot ? -1 : slot);
                playTuneSound(level, pos);
            }
            return ItemUseResult.sidedSuccess(level.isClientSide);
        }
        /*
         * IWandable cycled -1,0..5 independently of the shard shortcut.
         * The modern wand's own useOn handler is intentionally bypassed once
         * this block accepts the interaction.
         */
        if (stack.getItem() instanceof WandCarrierItem) {
            if (!level.isClientSide) {
                relay.setAttunement(relay.attunement() >= 5 ? -1 : relay.attunement() + 1);
                playTuneSound(level, pos);
            }
            return ItemUseResult.sidedSuccess(level.isClientSide);
        }
        return ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
    }

    @Nullable
    private static RelayAttunementDefinition relayAttunement(ItemStack stack) {
        return TCRegistryDataMaps.VIS_RELAY_ATTUNEMENTS.get(stack.getItemHolder());
    }

    private static void playTuneSound(Level level, BlockPos pos) {
        level.playSound(null, pos, TCSounds.CRYSTAL.get(), SoundSource.BLOCKS, 0.2F, 1.0F);
    }

    @Override
    public boolean isPathfindable(BlockState state, net.minecraft.world.level.BlockGetter level, BlockPos pos, PathComputationType pathType) {
        // Relay stubs float unless mounted on the floor; never path through.
        return false;
    }

    private AbstractVisRelayBlock(net.minecraft.world.level.block.state.BlockBehaviour.Properties native$NativeEntityBlock$arg0, BlockBehaviour.Properties properties, boolean native$NativeEntityBlock$captured) {
        super(native$NativeEntityBlock$arg0);
    }

    @Override
    public void initializeClient(java.util.function.Consumer<net.minecraftforge.client.extensions.common.IClientBlockExtensions> installer) {
        platform$clientInstaller = installer;
        super.initializeClient(installer);
    }

    @Override
    public void platform$clientExtension(Object extension) {
        java.util.Objects.requireNonNull(platform$clientInstaller, "Forge initializeClient must run before client extension registration").accept((net.minecraftforge.client.extensions.common.IClientBlockExtensions) extension);
    }

    @Override
    public InteractionResult use(BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
        ItemUseResult result = interactWithItem(player.getItemInHand(hand), state, level, pos, player, hand, hit);
        return result == ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION ? (hand == InteractionHand.MAIN_HAND ? interactWithoutItem(state, level, pos, player, hit) : InteractionResult.PASS) : result.result();
    }

    protected InteractionResult interactWithoutItem(BlockState state, Level level, BlockPos pos, Player player, BlockHitResult hit) {
        return super.use(state, level, pos, player, InteractionHand.MAIN_HAND, hit);
    }

    @Override
    public void playerWillDestroy(Level level, BlockPos pos, BlockState state, Player player) {
        beforePlayerDestroy(level, pos, state, player);
    }

    public BlockState beforePlayerDestroy(Level level, BlockPos pos, BlockState state, Player player) {
        super.playerWillDestroy(level, pos, state, player);
        return state;
    }

    protected boolean survivesSharedExplosion() {
        return false;
    }

    public int getExpDrop(net.minecraft.world.level.block.state.BlockState native$callbackInput$1050, net.minecraft.world.level.LevelReader native$callbackInput$1051, net.minecraft.util.RandomSource native$callbackInput$1052, net.minecraft.core.BlockPos native$callbackInput$1053, int native$callbackInput$1054, int native$callbackInput$1055) {
        net.minecraft.world.level.block.state.BlockState state = native$callbackInput$1050;
        net.minecraft.util.RandomSource random = native$callbackInput$1052;
        return 0;
    }

    @Override
    public void onBlockExploded(BlockState state, Level level, BlockPos pos, Explosion explosion) {
        if (!survivesSharedExplosion())
            super.onBlockExploded(state, level, pos, explosion);
    }

    @Override
    public boolean canDropFromExplosion(BlockState state, BlockGetter level, BlockPos pos, Explosion explosion) {
        return !survivesSharedExplosion() && super.canDropFromExplosion(state, level, pos, explosion);
    }
}
