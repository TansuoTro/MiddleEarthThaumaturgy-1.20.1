package dev.tc4port.thaumcraft.api.essentia;

/**
 * Whether a direct essentia extraction is only checked or committed.
 */
public enum EssentiaTransferMode {

    SIMULATE, EXECUTE;

    public boolean executes() {
        return this == EXECUTE;
    }
}
