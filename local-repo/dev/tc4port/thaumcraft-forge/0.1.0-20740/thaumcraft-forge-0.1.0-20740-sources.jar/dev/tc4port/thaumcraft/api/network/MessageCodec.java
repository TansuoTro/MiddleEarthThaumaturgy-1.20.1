package dev.tc4port.thaumcraft.api.network;

import java.util.function.BiConsumer;
import java.util.function.Function;

/**
 * The shared field encoding used by native loader codecs.
 */
public record MessageCodec<B, T>(BiConsumer<B, T> encoder, Function<B, T> decoder) {

    public static <B, T> MessageCodec<B, T> of(BiConsumer<B, T> encoder, Function<B, T> decoder) {
        return new MessageCodec<>(encoder, decoder);
    }

    public void encode(B buffer, T value) {
        encoder.accept(buffer, value);
    }

    public T decode(B buffer) {
        return decoder.apply(buffer);
    }
}
