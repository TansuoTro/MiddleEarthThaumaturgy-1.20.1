package dev.tc4port.thaumcraft.api.champion;

import java.util.List;
import java.util.Objects;
import java.util.Optional;
import net.minecraft.resources.ResourceLocation;

/**
 * Immutable metadata for one server-synchronized champion modifier.
 */
public record ChampionDefinition(ChampionId id, String nameKey, ChampionCategory category, ResourceLocation behavior, Optional<ChampionVisual> visualEffect, boolean randomEligible, List<ChampionAttributeModifier> attributeModifiers, java.util.Map<String, Double> parameters) {

    public ChampionDefinition {
        Objects.requireNonNull(id, "id");
        Objects.requireNonNull(category, "category");
        Objects.requireNonNull(behavior, "behavior");
        visualEffect = Objects.requireNonNull(visualEffect, "visualEffect");
        nameKey = requireText(nameKey);
        attributeModifiers = List.copyOf(attributeModifiers);
        parameters = ChampionNumbers.validate(parameters, false);
    }

    public float number(String name, float fallback) {
        return parameters.getOrDefault(name, (double) fallback).floatValue();
    }

    public int integer(String name, int fallback) {
        return parameters.getOrDefault(name, (double) fallback).intValue();
    }

    private static String requireText(String value) {
        Objects.requireNonNull(value, "nameKey");
        if (value.isBlank() || value.length() > 256) {
            throw new IllegalArgumentException("nameKey must contain 1 through 256 characters");
        }
        return value;
    }
}
