package dev.tc4port.thaumcraft.block.entity;

import dev.tc4port.thaumcraft.registry.TCBlockEntities;
import dev.tc4port.thaumcraft.registry.TCBlocks;
import java.util.List;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.animal.horse.AbstractHorse;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import dev.tc4port.thaumcraft.nativeimpl.state.ItemFields;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityType;

/**
 * Range cache and entity motion from TC4's {@code TileLifter}.
 */
public final class ArcaneLevitatorBlockEntity extends net.minecraft.world.level.block.entity.BlockEntity implements ItemFields.Source {

    // Nominal defaults; runtime behavior reads configured accessors.
    public static final int RANGE_PER_LEVITATOR = 10;

    public static final int RANGE_REFRESH_TICKS = 100;

    public static final double MAX_UPWARD_SPEED = 0.35;

    public static final double UPWARD_ACCELERATION = 0.1;

    public static final double DESCENT_DAMPING = 0.9;

    public static int configuredRangePerLevitator() {
        return dev.tc4port.thaumcraft.common.TCGameplayParameters.MACHINES_LEVITATOR_RANGE_PER_BLOCK.intValue();
    }

    public static int configuredRangeRefreshTicks() {
        return 100;
    }

    public static double configuredMaxUpwardSpeed() {
        return dev.tc4port.thaumcraft.common.TCGameplayParameters.MACHINES_LEVITATOR_MAXIMUM_UPWARD_SPEED.value();
    }

    public static double configuredUpwardAcceleration() {
        return dev.tc4port.thaumcraft.common.TCGameplayParameters.MACHINES_LEVITATOR_UPWARD_ACCELERATION.value();
    }

    public static double configuredDescentDamping() {
        return dev.tc4port.thaumcraft.common.TCGameplayParameters.MACHINES_LEVITATOR_DESCENT_DAMPING.value();
    }

    private int counter;

    private int rangeAbove;

    private boolean requiresUpdate = true;

    public ArcaneLevitatorBlockEntity(BlockPos pos, BlockState state) {
        super(TCBlockEntities.ARCANE_LEVITATOR.get(), pos, state);
    }

    /**
     * The legacy tile ticked on both logical sides. Keeping the range cache
     * and motion update local to each world preserves responsive lift for
     * locally controlled entities. Other clients observe server motion.
     */
    private Boolean modelPowered;

    public static void tick(Level level, BlockPos pos, BlockState state, ArcaneLevitatorBlockEntity levitator) {
        if (level.isClientSide) {
            boolean powered = gettingPower(level, pos);
            if (levitator.modelPowered == null || levitator.modelPowered != powered) {
                levitator.modelPowered = powered;
                level.sendBlockUpdated(pos, state, state, 3);
            }
        }
        levitator.counter++;
        if (levitator.requiresUpdate || levitator.counter % configuredRangeRefreshTicks() == 0) {
            levitator.requiresUpdate = false;
            levitator.rangeAbove = calculateRange(level, pos);
        }
        if (levitator.rangeAbove <= 0 || gettingPower(level, pos)) {
            return;
        }
        AABB column = new AABB(pos.getX(), pos.getY() + 1.0, pos.getZ(), pos.getX() + 1.0, pos.getY() + 1.0 + levitator.rangeAbove, pos.getZ() + 1.0);
        List<Entity> targets = level.getEntities((Entity) null, column, ArcaneLevitatorBlockEntity::canLift);
        for (Entity entity : targets) {
            applyLift(entity);
        }
    }

    public static boolean gettingPower(Level level, BlockPos pos) {
        return !level.hasChunksAt(pos.offset(-2, 0, -2), pos.offset(2, 0, 2)) || level.hasNeighborSignal(pos) || level.hasNeighborSignal(pos.above());
    }

    /**
     * Recreates the source's asymmetric stacking rule: only consecutive,
     * directly unpowered levitators below the current block add range.
     */
    public static int calculateRange(Level level, BlockPos pos) {
        int maximum = configuredRangePerLevitator();
        BlockPos.MutableBlockPos below = pos.mutable().move(0, -1, 0);
        while (below.getY() >= level.getMinBuildHeight() && level.getBlockState(below).is(TCBlocks.ARCANE_LEVITATOR.get()) && level.hasChunksAt(below.offset(-2, 0, -2), below.offset(2, 0, 2)) && !level.hasNeighborSignal(below)) {
            maximum += configuredRangePerLevitator();
            below.move(0, -1, 0);
        }
        int range = 0;
        BlockPos.MutableBlockPos above = pos.mutable().move(0, 1, 0);
        while (range < maximum && above.getY() < level.getMaxBuildHeight() && /*
                 * TileLifter stopped only at Block#isOpaqueCube. Modern
                 * canOcclude() is merely permission to participate in
                 * occlusion and is true for partial shapes such as slabs.
                 * isSolidRender is the full opaque-cube equivalent.
                 */
        !level.getBlockState(above).isSolidRender(level, above)) {
            range++;
            above.move(0, 1, 0);
        }
        return range;
    }

    public static boolean canLift(Entity entity) {
        return entity instanceof ItemEntity || entity.isPushable() || entity instanceof AbstractHorse;
    }

    public static void applyLift(Entity entity) {
        if (entity.level().isClientSide && !entity.isControlledByLocalInstance())
            return;
        Vec3 motion = entity.getDeltaMovement();
        double vertical = motion.y;
        /*
         * 4.2.3.5 queried the physical Shift key on the client. Applying the
         * equivalent per-player server state avoids one local key affecting
         * every creature in the column and works on dedicated servers.
         */
        if (entity instanceof Player player && player.isShiftKeyDown()) {
            if (vertical < 0.0) {
                vertical *= configuredDescentDamping();
            }
        } else if (vertical < configuredMaxUpwardSpeed()) {
            vertical += configuredUpwardAcceleration();
        }
        entity.setDeltaMovement(motion.x, vertical, motion.z);
        entity.hasImpulse = true;
        entity.fallDistance = 0.0F;
    }

    public int rangeAbove() {
        return this.rangeAbove;
    }

    public boolean requiresUpdate() {
        return this.requiresUpdate;
    }

    public void requestRangeUpdate() {
        this.requiresUpdate = true;
    }

    protected final HolderLookup.Provider persistenceRegistries() {
        if (level != null)
            return level.registryAccess();
        var server = net.minecraftforge.server.ServerLifecycleHooks.getCurrentServer();
        return server != null ? server.registryAccess() : net.minecraft.core.RegistryAccess.fromRegistryOfRegistries(net.minecraft.core.registries.BuiltInRegistries.REGISTRY);
    }

    protected static net.minecraft.network.chat.Component parseCustomNameSafe(String value, HolderLookup.Provider registries) {
        try {
            return net.minecraft.network.chat.Component.Serializer.fromJson(value);
        } catch (RuntimeException exception) {
            return null;
        }
    }

    protected void readItemFields(ItemFields.Input input) {
    }

    public void copyItemFields(ItemFields.Output output) {
    }

    public void applyComponentsFromItemStack(ItemStack stack) {
        readItemFields(ItemFields.from(stack));
    }

    public void removeComponentsFromTag(CompoundTag tag) {
    }

    @Override
    public void saveToItem(ItemStack stack) {
        CompoundTag tag = saveWithoutMetadata();
        {
            net.minecraft.nbt.CompoundTag native$bodyOperand$6105 = tag;
            native$bodyReturn$6107: {
                if (true) {
                }
            }
        }
        net.minecraft.world.item.BlockItem.setBlockEntityData(stack, getType(), tag);
        copyItemFields(ItemFields.to(stack));
    }

    @Override
    public net.minecraft.world.phys.AABB getRenderBoundingBox() {
        return ArcaneLevitatorBlockEntity.native$ClientBlockEntityBounds$bounds(this);
    }

    @Override()
    public void onDataPacket(net.minecraft.network.Connection connection, net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket packet) {
        handleUpdateTag(packet.getTag());
    }

    @SuppressWarnings({ "rawtypes", "unchecked" })
    static private net.minecraft.world.phys.AABB native$ClientBlockEntityBounds$bounds(net.minecraft.world.level.block.entity.BlockEntity blockEntity) {
        var renderer = net.minecraft.client.Minecraft.getInstance().getBlockEntityRenderDispatcher().getRenderer(blockEntity);
        return renderer instanceof dev.tc4port.thaumcraft.nativeimpl.NativeBlockEntityRenderer shared ? shared.getRenderBoundingBox(blockEntity) : new net.minecraft.world.phys.AABB(blockEntity.getBlockPos());
    }
}
