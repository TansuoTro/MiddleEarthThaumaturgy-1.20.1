package dev.tc4port.thaumcraft.api.recipe;

import dev.tc4port.thaumcraft.api.research.ResearchRequirement;
import java.util.List;
import java.util.Optional;
import net.minecraft.core.Holder;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.item.enchantment.Enchantment;

/**
 * Read-only access to native, data-defined infusion enchantments.
 */
public interface InfusionEnchantmentRecipe {

    ResearchRequirement research();

    Holder<Enchantment> enchantment();

    List<Ingredient> pedestalComponents();

    List<InfusionEnchantmentStage> stages();

    InfusionEnchantmentScaling costScaling();

    /**
     * Calculates a catalog example with only the target enchantment present.
     */
    InfusionEnchantmentCost costAtLevel(int inputLevel);

    /**
     * The {@link InfusionEnchantmentCostTransformation} id this recipe charges through, if any.
     */
    default Optional<net.minecraft.resources.ResourceLocation> costTransformation() {
        return Optional.empty();
    }

    /**
     * Empty for unsupported, conflicting, maxed or undeclared input states. Does not mutate input.
     * The cost is the altar's quote, including any cost transformation.
     */
    Optional<Result> resolve(ItemStack central);

    record Result(InfusionEnchantmentStage stage, ItemStack output, InfusionEnchantmentCost cost) {

        public Result {
            java.util.Objects.requireNonNull(stage, "stage");
            java.util.Objects.requireNonNull(cost, "cost");
            output = output.copy();
        }

        @Override
        public ItemStack output() {
            return output.copy();
        }
    }
}
