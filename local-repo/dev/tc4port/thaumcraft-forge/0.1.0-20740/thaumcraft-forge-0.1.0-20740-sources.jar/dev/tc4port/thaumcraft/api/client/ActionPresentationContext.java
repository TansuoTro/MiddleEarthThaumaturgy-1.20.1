package dev.tc4port.thaumcraft.api.client;

import java.util.Objects;
import java.util.Optional;
import javax.annotation.Nullable;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.Vec3;

/**
 * Immutable client view of one predicted or observer-confirmed action.
 * {@link #sourcePosition()} remains stable when the actor moves before a
 * server confirmation reaches its observers.
 */
public record ActionPresentationContext(ResourceLocation presentationId, ClientLevel level, @Nullable LivingEntity source, InteractionHand hand, Vec3 sourcePosition, Vec3 origin, Vec3 target, Optional<Entity> targetEntity, double detail, int value, long seed, boolean predicted) {

    public ActionPresentationContext {
        Objects.requireNonNull(presentationId, "presentationId");
        Objects.requireNonNull(level, "level");
        Objects.requireNonNull(hand, "hand");
        Objects.requireNonNull(sourcePosition, "sourcePosition");
        Objects.requireNonNull(origin, "origin");
        Objects.requireNonNull(target, "target");
        targetEntity = Objects.requireNonNull(targetEntity, "targetEntity");
    }

    /**
     * Optional actor for source-less block and world presentations.
     *
     * <p>The legacy {@link #source()} accessor remains nullable-compatible so
     * existing actor-owned handlers retain their source and binary shape.</p>
     */
    public Optional<LivingEntity> optionalSource() {
        return Optional.ofNullable(this.source);
    }
}
