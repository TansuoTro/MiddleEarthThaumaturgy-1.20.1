package dev.tc4port.thaumcraft.api.research;

import com.mojang.serialization.Codec;
import com.mojang.serialization.DataResult;
import java.util.Objects;

/**
 * Stable, case-preserving identity of one research entry.
 *
 * <p>TC4 research keys are case-sensitive and therefore cannot be represented
 * by {@code ResourceLocation}. Bare legacy keys belong to the
 * {@code thaumcraft} namespace; new addon keys should use
 * {@code addon_namespace:KEY}. A leading {@code @} is a private discovery
 * marker in saved player data, not a research identity, and is rejected.</p>
 */
public record ResearchKey(String namespace, String path) implements Comparable<ResearchKey> {

    public static final Codec<ResearchKey> CODEC = Codec.STRING.comapFlatMap(ResearchKey::decode, ResearchKey::serialized);

    private static final String CORE_NAMESPACE = "thaumcraft";

    public ResearchKey {
        namespace = Objects.requireNonNull(namespace, "namespace");
        path = Objects.requireNonNull(path, "path");
        if (!validNamespace(namespace) || !validPath(path)) {
            throw new IllegalArgumentException("Invalid research key " + namespace + ":" + path);
        }
        if ((namespace + ":" + path).length() > 256) {
            throw new IllegalArgumentException("Research key is longer than 256 characters");
        }
    }

    public static ResearchKey of(String namespace, String path) {
        return new ResearchKey(namespace, path);
    }

    /**
     * Parses a bare TC4 key or a namespaced addon key.
     */
    public static ResearchKey parse(String value) {
        Objects.requireNonNull(value, "value");
        int separator = value.indexOf(':');
        return separator < 0 ? new ResearchKey(CORE_NAMESPACE, value) : new ResearchKey(value.substring(0, separator), value.substring(separator + 1));
    }

    private static DataResult<ResearchKey> decode(String value) {
        try {
            return DataResult.success(parse(value));
        } catch (IllegalArgumentException exception) {
            return DataResult.error(() -> "Invalid research key '" + value + "': " + exception.getMessage());
        }
    }

    /**
     * String spelling used by TC4 data, recipes and player saves.
     */
    public String serialized() {
        return this.namespace.equals(CORE_NAMESPACE) ? this.path : this.toString();
    }

    public String nameTranslationKey() {
        return "tc.research_name." + this.serialized();
    }

    public String descriptionTranslationKey() {
        return "tc.research_text." + this.serialized();
    }

    @Override
    public int compareTo(ResearchKey other) {
        int namespaceOrder = this.namespace.compareTo(other.namespace);
        return namespaceOrder != 0 ? namespaceOrder : this.path.compareTo(other.path);
    }

    @Override
    public String toString() {
        return this.namespace + ":" + this.path;
    }

    private static boolean validNamespace(String value) {
        if (value.isEmpty()) {
            return false;
        }
        for (int index = 0; index < value.length(); index++) {
            char character = value.charAt(index);
            if (!(character >= 'a' && character <= 'z') && !(character >= '0' && character <= '9') && character != '_' && character != '-' && character != '.') {
                return false;
            }
        }
        return true;
    }

    private static boolean validPath(String value) {
        if (value.isEmpty() || value.charAt(0) == '@') {
            return false;
        }
        for (int index = 0; index < value.length(); index++) {
            char character = value.charAt(index);
            if (!(character >= 'a' && character <= 'z') && !(character >= 'A' && character <= 'Z') && !(character >= '0' && character <= '9') && character != '_' && character != '-' && character != '.' && character != '/') {
                return false;
            }
        }
        return true;
    }
}
