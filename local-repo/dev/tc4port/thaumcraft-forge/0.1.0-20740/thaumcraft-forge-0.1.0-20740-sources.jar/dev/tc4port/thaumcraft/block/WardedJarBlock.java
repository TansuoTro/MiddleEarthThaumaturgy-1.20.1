package dev.tc4port.thaumcraft.block;

import dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult;
import dev.tc4port.thaumcraft.api.aspect.AspectId;
import com.mojang.serialization.MapCodec;
import dev.tc4port.thaumcraft.block.entity.WardedJarBlockEntity;
import dev.tc4port.thaumcraft.registry.TCBlockEntities;
import dev.tc4port.thaumcraft.state.TCItemState;
import dev.tc4port.thaumcraft.registry.TCItems;
import dev.tc4port.thaumcraft.registry.TCSounds;
import javax.annotation.Nullable;
import net.minecraft.world.phys.HitResult;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityTicker;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.DirectionProperty;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;
import dev.tc4port.thaumcraft.nativeimpl.ClientExtensionTarget;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.level.pathfinder.PathComputationType;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.Explosion;

/**
 * Fillable and void warded jars. Contents and labels survive block-item
 * round trips through data components.
 */
public final class WardedJarBlock extends net.minecraft.world.level.block.BaseEntityBlock implements dev.tc4port.thaumcraft.nativeimpl.ClientExtensionTarget {

    // Forge calls initializeClient from the native superclass constructor. Do not add a field initializer.
    private java.util.function.Consumer<net.minecraftforge.client.extensions.common.IClientBlockExtensions> platform$clientInstaller;

    @Override
    public void setPlacedBy(Level level, BlockPos pos, BlockState state, @javax.annotation.Nullable net.minecraft.world.entity.LivingEntity placer, ItemStack stack) {
        super.setPlacedBy(level, pos, state, placer, stack);
        if (level.getBlockEntity(pos) instanceof WardedJarBlockEntity placed) {
            placed.applyComponentsFromItemStack(stack);
        }
    }

    public enum Kind {

        NORMAL, VOID
    }

    public static final MapCodec<WardedJarBlock> CODEC = WardedJarBlock.native$BlockCodecPlatform$simple(properties -> new WardedJarBlock(Kind.NORMAL, properties));

    public static final DirectionProperty FACING = BlockStateProperties.HORIZONTAL_FACING;

    private static final VoxelShape OUTLINE = Block.box(3, 0, 3, 13, 12, 13);

    private final Kind kind;

    public WardedJarBlock(Kind kind, BlockBehaviour.Properties properties) {
        this(properties, kind, properties, true);
    }

    public Kind kind() {
        return this.kind;
    }

    protected MapCodec<? extends WardedJarBlock> codec() {
        return CODEC;
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(FACING);
    }

    @Nullable
    @Override
    public BlockState getStateForPlacement(BlockPlaceContext context) {
        return this.defaultBlockState().setValue(FACING, context.getHorizontalDirection().getOpposite());
    }

    @Nullable
    @Override
    public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        return new WardedJarBlockEntity(pos, state);
    }

    @Nullable
    @Override
    public <T extends BlockEntity> BlockEntityTicker<T> getTicker(Level level, BlockState state, BlockEntityType<T> type) {
        return level.isClientSide ? null : createTickerHelper(type, TCBlockEntities.WARDED_JAR.get(), WardedJarBlockEntity::serverTick);
    }

    @Override
    public RenderShape getRenderShape(BlockState state) {
        return RenderShape.MODEL;
    }

    @Override
    public VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
        return OUTLINE;
    }

    @Override
    public VoxelShape getCollisionShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
        // BlockJar temporarily reset its bounds to a full cube here.
        return Shapes.block();
    }

    @Override
    public float getShadeBrightness(BlockState state, BlockGetter level, BlockPos pos) {
        // BlockJar was non-opaque even though its collision filled a cube.
        return 1.0F;
    }

    protected ItemUseResult interactWithItem(ItemStack stack, BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
        if (!(level.getBlockEntity(pos) instanceof dev.tc4port.thaumcraft.block.entity.WardedJarBlockEntity jar)) {
            return dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
        }
        if (player.isShiftKeyDown() && jar.filter() != null && hit.getDirection() == state.getValue(dev.tc4port.thaumcraft.block.WardedJarBlock.FACING)) {
            return dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
        }
        if (stack.is(dev.tc4port.thaumcraft.registry.TCItems.byId("jar_label").get()) && jar.filter() == null) {
            dev.tc4port.thaumcraft.api.aspect.AspectId selected = jar.aspect();
            if (selected == null) {
                selected = (switch(0) {
                    default ->
                        {
                            dev.tc4port.thaumcraft.api.data.ItemStateKey<dev.tc4port.thaumcraft.api.aspect.AspectId> native$receiver$373 = dev.tc4port.thaumcraft.state.TCItemState.JAR_FILTER;
                            net.minecraft.world.item.ItemStack native$argument$374 = stack;
                            java.util.Objects.requireNonNull(native$receiver$373);
                            yield dev.tc4port.thaumcraft.api.item.ItemStatePlatform.get(native$argument$374, native$receiver$373);
                        }
                });
            }
            if (selected == null) {
                return dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.CONSUME;
            }
            if (!level.isClientSide && jar.setFilter(selected)) {
                stack.shrink(1);
                level.setBlock(pos, state.setValue(dev.tc4port.thaumcraft.block.WardedJarBlock.FACING, player.getDirection().getOpposite()), net.minecraft.world.level.block.Block.UPDATE_CLIENTS);
                level.playSound(null, pos, dev.tc4port.thaumcraft.registry.TCSounds.JAR.get(), net.minecraft.sounds.SoundSource.BLOCKS, 0.4F, 1.0F);
            }
            return dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.sidedSuccess(level.isClientSide);
        }
        return dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
    }

    protected InteractionResult interactWithoutItem(BlockState state, Level level, BlockPos pos, Player player, BlockHitResult hit) {
        if (!(level.getBlockEntity(pos) instanceof dev.tc4port.thaumcraft.block.entity.WardedJarBlockEntity jar) || !player.isShiftKeyDown()) {
            return net.minecraft.world.InteractionResult.PASS;
        }
        if (jar.filter() != null && hit.getDirection() == state.getValue(dev.tc4port.thaumcraft.block.WardedJarBlock.FACING)) {
            removeFilter(level, pos, hit.getDirection(), jar);
        } else if (!level.isClientSide) {
            jar.clearContents();
            level.playSound(null, pos, dev.tc4port.thaumcraft.registry.TCSounds.JAR.get(), net.minecraft.sounds.SoundSource.BLOCKS, 0.4F, 1.0F);
            level.playSound(null, pos, dev.tc4port.thaumcraft.registry.TCSounds.ESSENTIA_POUR.get(), net.minecraft.sounds.SoundSource.BLOCKS, 0.5F, 1.0F + (level.random.nextFloat() - level.random.nextFloat()) * 0.3F);
        }
        return net.minecraft.world.InteractionResult.sidedSuccess(level.isClientSide);
    }

    private static void removeFilter(Level level, BlockPos pos, Direction side, WardedJarBlockEntity jar) {
        if (level.isClientSide || !jar.clearFilter()) {
            return;
        }
        ((ServerLevel) level).addFreshEntity(new ItemEntity(level, pos.getX() + 0.5 + side.getStepX() / 3.0, pos.getY() + 0.5, pos.getZ() + 0.5 + side.getStepZ() / 3.0, new ItemStack(TCItems.byId("jar_label").get())));
        level.playSound(null, pos, TCSounds.PAGE.get(), SoundSource.BLOCKS, 1.0F, 1.0F);
    }

    @Override
    public boolean hasAnalogOutputSignal(BlockState state) {
        return true;
    }

    @Override
    public int getAnalogOutputSignal(BlockState state, Level level, BlockPos pos) {
        return level.getBlockEntity(pos) instanceof WardedJarBlockEntity jar ? jar.comparatorOutput() : 0;
    }

    @Override
    public ItemStack getCloneItemStack(BlockState state, HitResult target, net.minecraft.world.level.BlockGetter level, BlockPos pos, Player player) {
        ItemStack stack = new ItemStack(this);
        if (level.getBlockEntity(pos) instanceof WardedJarBlockEntity jar) {
            {
                dev.tc4port.thaumcraft.block.entity.WardedJarBlockEntity native$receiver$982 = jar;
                net.minecraft.world.item.ItemStack native$argument$983 = stack;
                net.minecraft.core.HolderLookup.Provider native$argument$984 = player.level().registryAccess();
                java.util.Objects.requireNonNull(native$receiver$982);
                native$receiver$982.saveToItem(native$argument$983);
            }
        }
        return stack;
    }

    public BlockState beforePlayerDestroy(Level level, BlockPos pos, BlockState state, Player player) {
        if (player.isCreative() && level instanceof net.minecraft.server.level.ServerLevel serverLevel) {
            net.minecraft.world.level.block.Block.dropResources(state, serverLevel, pos, level.getBlockEntity(pos), player, player.getMainHandItem());
        }
        return (switch(0) {
            default ->
                {
                    net.minecraft.world.level.Level native$bodyOperand$6065 = level;
                    net.minecraft.core.BlockPos native$bodyOperand$6066 = pos;
                    net.minecraft.world.level.block.state.BlockState native$bodyOperand$6067 = state;
                    net.minecraft.world.entity.player.Player native$bodyOperand$6068 = player;
                    net.minecraft.world.level.block.state.BlockState native$bodyResult$6069 = null;
                    native$bodyReturn$6070: {
                        if (true) {
                            super.playerWillDestroy(native$bodyOperand$6065, native$bodyOperand$6066, native$bodyOperand$6067, native$bodyOperand$6068);
                            {
                                native$bodyResult$6069 = native$bodyOperand$6067;
                                break native$bodyReturn$6070;
                            }
                        }
                    }
                    yield native$bodyResult$6069;
                }
        });
    }

    private WardedJarBlock(net.minecraft.world.level.block.state.BlockBehaviour.Properties native$NativeEntityBlock$arg0, Kind kind, BlockBehaviour.Properties properties, boolean native$NativeEntityBlock$captured) {
        super(native$NativeEntityBlock$arg0);
        this.kind = kind;
        this.registerDefaultState(this.stateDefinition.any().setValue(FACING, Direction.NORTH));
    }

    @Override
    public void initializeClient(java.util.function.Consumer<net.minecraftforge.client.extensions.common.IClientBlockExtensions> installer) {
        platform$clientInstaller = installer;
        super.initializeClient(installer);
    }

    @Override
    public void platform$clientExtension(Object extension) {
        java.util.Objects.requireNonNull(platform$clientInstaller, "Forge initializeClient must run before client extension registration").accept((net.minecraftforge.client.extensions.common.IClientBlockExtensions) extension);
    }

    @Override
    public InteractionResult use(BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
        ItemUseResult result = (switch(0) {
            default ->
                {
                    net.minecraft.world.item.ItemStack native$bodyOperand$4822 = player.getItemInHand(hand);
                    net.minecraft.world.level.block.state.BlockState native$bodyOperand$4823 = state;
                    net.minecraft.world.level.Level native$bodyOperand$4824 = level;
                    net.minecraft.core.BlockPos native$bodyOperand$4825 = pos;
                    net.minecraft.world.entity.player.Player native$bodyOperand$4826 = player;
                    net.minecraft.world.InteractionHand native$bodyOperand$4827 = hand;
                    net.minecraft.world.phys.BlockHitResult native$bodyOperand$4828 = hit;
                    dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult native$bodyResult$4833 = null;
                    native$bodyReturn$4834: {
                        if (true) {
                            if (!(native$bodyOperand$4824.getBlockEntity(native$bodyOperand$4825) instanceof dev.tc4port.thaumcraft.block.entity.WardedJarBlockEntity native$bodyBinding$4829)) {
                                {
                                    native$bodyResult$4833 = dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
                                    break native$bodyReturn$4834;
                                }
                            }
                            if (native$bodyOperand$4826.isShiftKeyDown() && native$bodyBinding$4829.filter() != null && native$bodyOperand$4828.getDirection() == native$bodyOperand$4823.getValue(dev.tc4port.thaumcraft.block.WardedJarBlock.FACING)) {
                                {
                                    native$bodyResult$4833 = dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
                                    break native$bodyReturn$4834;
                                }
                            }
                            if (native$bodyOperand$4822.is(dev.tc4port.thaumcraft.registry.TCItems.byId("jar_label").get()) && native$bodyBinding$4829.filter() == null) {
                                dev.tc4port.thaumcraft.api.aspect.AspectId native$bodyBinding$4830 = native$bodyBinding$4829.aspect();
                                if (native$bodyBinding$4830 == null) {
                                    native$bodyBinding$4830 = (switch(0) {
                                        default ->
                                            {
                                                dev.tc4port.thaumcraft.api.data.ItemStateKey<dev.tc4port.thaumcraft.api.aspect.AspectId> native$bodyBinding$4831 = dev.tc4port.thaumcraft.state.TCItemState.JAR_FILTER;
                                                net.minecraft.world.item.ItemStack native$bodyBinding$4832 = native$bodyOperand$4822;
                                                java.util.Objects.requireNonNull(native$bodyBinding$4831);
                                                yield dev.tc4port.thaumcraft.api.item.ItemStatePlatform.get(native$bodyBinding$4832, native$bodyBinding$4831);
                                            }
                                    });
                                }
                                if (native$bodyBinding$4830 == null) {
                                    {
                                        native$bodyResult$4833 = dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.CONSUME;
                                        break native$bodyReturn$4834;
                                    }
                                }
                                if (!native$bodyOperand$4824.isClientSide && native$bodyBinding$4829.setFilter(native$bodyBinding$4830)) {
                                    native$bodyOperand$4822.shrink(1);
                                    native$bodyOperand$4824.setBlock(native$bodyOperand$4825, native$bodyOperand$4823.setValue(dev.tc4port.thaumcraft.block.WardedJarBlock.FACING, native$bodyOperand$4826.getDirection().getOpposite()), net.minecraft.world.level.block.Block.UPDATE_CLIENTS);
                                    native$bodyOperand$4824.playSound(null, native$bodyOperand$4825, dev.tc4port.thaumcraft.registry.TCSounds.JAR.get(), net.minecraft.sounds.SoundSource.BLOCKS, 0.4F, 1.0F);
                                }
                                {
                                    native$bodyResult$4833 = dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.sidedSuccess(native$bodyOperand$4824.isClientSide);
                                    break native$bodyReturn$4834;
                                }
                            }
                            {
                                native$bodyResult$4833 = dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
                                break native$bodyReturn$4834;
                            }
                        }
                    }
                    yield native$bodyResult$4833;
                }
        });
        return result == ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION ? (hand == InteractionHand.MAIN_HAND ? (switch(0) {
            default ->
                {
                    net.minecraft.world.level.block.state.BlockState native$bodyOperand$3932 = state;
                    net.minecraft.world.level.Level native$bodyOperand$3933 = level;
                    net.minecraft.core.BlockPos native$bodyOperand$3934 = pos;
                    net.minecraft.world.entity.player.Player native$bodyOperand$3935 = player;
                    net.minecraft.world.phys.BlockHitResult native$bodyOperand$3936 = hit;
                    net.minecraft.world.InteractionResult native$bodyResult$3938 = null;
                    native$bodyReturn$3939: {
                        if (true) {
                            if (!(native$bodyOperand$3933.getBlockEntity(native$bodyOperand$3934) instanceof dev.tc4port.thaumcraft.block.entity.WardedJarBlockEntity native$bodyBinding$3937) || !native$bodyOperand$3935.isShiftKeyDown()) {
                                {
                                    native$bodyResult$3938 = net.minecraft.world.InteractionResult.PASS;
                                    break native$bodyReturn$3939;
                                }
                            }
                            if (native$bodyBinding$3937.filter() != null && native$bodyOperand$3936.getDirection() == native$bodyOperand$3932.getValue(dev.tc4port.thaumcraft.block.WardedJarBlock.FACING)) {
                                removeFilter(native$bodyOperand$3933, native$bodyOperand$3934, native$bodyOperand$3936.getDirection(), native$bodyBinding$3937);
                            } else if (!native$bodyOperand$3933.isClientSide) {
                                native$bodyBinding$3937.clearContents();
                                native$bodyOperand$3933.playSound(null, native$bodyOperand$3934, dev.tc4port.thaumcraft.registry.TCSounds.JAR.get(), net.minecraft.sounds.SoundSource.BLOCKS, 0.4F, 1.0F);
                                native$bodyOperand$3933.playSound(null, native$bodyOperand$3934, dev.tc4port.thaumcraft.registry.TCSounds.ESSENTIA_POUR.get(), net.minecraft.sounds.SoundSource.BLOCKS, 0.5F, 1.0F + (native$bodyOperand$3933.random.nextFloat() - native$bodyOperand$3933.random.nextFloat()) * 0.3F);
                            }
                            {
                                native$bodyResult$3938 = net.minecraft.world.InteractionResult.sidedSuccess(native$bodyOperand$3933.isClientSide);
                                break native$bodyReturn$3939;
                            }
                        }
                    }
                    yield native$bodyResult$3938;
                }
        }) : InteractionResult.PASS) : result.result();
    }

    @Override
    public void playerWillDestroy(Level level, BlockPos pos, BlockState state, Player player) {
        {
            net.minecraft.world.level.Level native$bodyOperand$6071 = level;
            net.minecraft.core.BlockPos native$bodyOperand$6072 = pos;
            net.minecraft.world.level.block.state.BlockState native$bodyOperand$6073 = state;
            net.minecraft.world.entity.player.Player native$bodyOperand$6074 = player;
            net.minecraft.world.level.block.state.BlockState native$bodyResult$6076 = null;
            native$bodyReturn$6077: {
                if (true) {
                    if (native$bodyOperand$6074.isCreative() && native$bodyOperand$6071 instanceof net.minecraft.server.level.ServerLevel native$bodyBinding$6075) {
                        net.minecraft.world.level.block.Block.dropResources(native$bodyOperand$6073, native$bodyBinding$6075, native$bodyOperand$6072, native$bodyOperand$6071.getBlockEntity(native$bodyOperand$6072), native$bodyOperand$6074, native$bodyOperand$6074.getMainHandItem());
                    }
                    {
                        native$bodyResult$6076 = (switch(0) {
                            default ->
                                {
                                    net.minecraft.world.level.Level native$bodyOperand$9015 = native$bodyOperand$6071;
                                    net.minecraft.core.BlockPos native$bodyOperand$9016 = native$bodyOperand$6072;
                                    net.minecraft.world.level.block.state.BlockState native$bodyOperand$9017 = native$bodyOperand$6073;
                                    net.minecraft.world.entity.player.Player native$bodyOperand$9018 = native$bodyOperand$6074;
                                    net.minecraft.world.level.block.state.BlockState native$bodyResult$9019 = null;
                                    native$bodyReturn$9020: {
                                        if (true) {
                                            super.playerWillDestroy(native$bodyOperand$9015, native$bodyOperand$9016, native$bodyOperand$9017, native$bodyOperand$9018);
                                            {
                                                native$bodyResult$9019 = native$bodyOperand$9017;
                                                break native$bodyReturn$9020;
                                            }
                                        }
                                    }
                                    yield native$bodyResult$9019;
                                }
                        });
                        break native$bodyReturn$6077;
                    }
                }
            }
        }
    }

    protected boolean survivesSharedExplosion() {
        return false;
    }

    public int getExpDrop(net.minecraft.world.level.block.state.BlockState native$callbackInput$1050, net.minecraft.world.level.LevelReader native$callbackInput$1051, net.minecraft.util.RandomSource native$callbackInput$1052, net.minecraft.core.BlockPos native$callbackInput$1053, int native$callbackInput$1054, int native$callbackInput$1055) {
        net.minecraft.world.level.block.state.BlockState state = native$callbackInput$1050;
        net.minecraft.util.RandomSource random = native$callbackInput$1052;
        return 0;
    }

    @Override
    public void onBlockExploded(BlockState state, Level level, BlockPos pos, Explosion explosion) {
        if (!(switch(0) {
            default ->
                {
                    boolean native$bodyResult$5335 = false;
                    native$bodyReturn$5336: {
                        if (true) {
                            {
                                native$bodyResult$5335 = false;
                                break native$bodyReturn$5336;
                            }
                        }
                    }
                    yield native$bodyResult$5335;
                }
        }))
            super.onBlockExploded(state, level, pos, explosion);
    }

    @Override
    public boolean canDropFromExplosion(BlockState state, BlockGetter level, BlockPos pos, Explosion explosion) {
        return !(switch(0) {
            default ->
                {
                    boolean native$bodyResult$4835 = false;
                    native$bodyReturn$4836: {
                        if (true) {
                            {
                                native$bodyResult$4835 = false;
                                break native$bodyReturn$4836;
                            }
                        }
                    }
                    yield native$bodyResult$4835;
                }
        }) && super.canDropFromExplosion(state, level, pos, explosion);
    }

    static private <B extends net.minecraft.world.level.block.Block> com.mojang.serialization.MapCodec<B> native$BlockCodecPlatform$simple(java.util.function.Function<net.minecraft.world.level.block.state.BlockBehaviour.Properties, B> factory) {
        // Vanilla 1.21's Properties codec is a unit codec. Retain that schema for shared block definitions.
        return com.mojang.serialization.codecs.RecordCodecBuilder.mapCodec(instance -> instance.group(com.mojang.serialization.Codec.unit(net.minecraft.world.level.block.state.BlockBehaviour.Properties::of).fieldOf("properties").forGetter((B block) -> net.minecraft.world.level.block.state.BlockBehaviour.Properties.copy(block))).apply(instance, factory));
    }
}
