package dev.tc4port.thaumcraft.api.entity;

import dev.tc4port.thaumcraft.entity.FocusProjectileEntity;
import java.util.Objects;
import java.util.Optional;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.Vec3;
import net.minecraft.util.Mth;

/**
 * Public construction path for TC4's legacy explosive-orb projectile.
 */
public final class ExplosiveOrbApi {

    public static final float MAX_STRENGTH = 64.0F;

    private ExplosiveOrbApi() {
    }

    /**
     * Spawns the source-compatible orb, including TC4's renderer and
     * FXGeneric trail and EntityThrowable-compatible launch origin.
     */
    public static Optional<Entity> spawn(ServerLevel level, LivingEntity owner, float strength) {
        return spawn(level, owner, strength, false);
    }

    /**
     * Tainted Magic's Katana advances the constructed orb by one velocity.
     */
    public static Optional<Entity> spawnAdvanced(ServerLevel level, LivingEntity owner, float strength) {
        return spawn(level, owner, strength, true);
    }

    private static Optional<Entity> spawn(ServerLevel level, LivingEntity owner, float strength, boolean advanceOneMotion) {
        Objects.requireNonNull(level, "level");
        Objects.requireNonNull(owner, "owner");
        float yaw = owner.getYRot() * Mth.DEG_TO_RAD;
        Vec3 position = new Vec3(owner.getX() - Mth.cos(yaw) * 0.16F, owner.getEyeY() - 0.1, owner.getZ() - Mth.sin(yaw) * 0.16F);
        BlockPos blockPos = BlockPos.containing(position);
        if (!level.getServer().isSameThread() || owner.level() != level || !owner.isAlive() || !Float.isFinite(strength) || strength <= 0.0F || strength > MAX_STRENGTH || !level.hasChunkAt(blockPos) || level.isOutsideBuildHeight(blockPos) || !level.getWorldBorder().isWithinBounds(blockPos)) {
            return Optional.empty();
        }
        FocusProjectileEntity projectile = new FocusProjectileEntity(level, owner, FocusProjectileEntity.Mode.FIREBALL, strength, 0, 0, 0, 500);
        projectile.setPos(position);
        projectile.shootLegacyThrowable(owner, 1.5F, 1.0F);
        if (advanceOneMotion) {
            projectile.setPos(position.add(projectile.getDeltaMovement()));
        }
        return level.addFreshEntity(projectile) ? Optional.of(projectile) : Optional.empty();
    }
}
