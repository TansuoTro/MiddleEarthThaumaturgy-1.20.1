package dev.tc4port.thaumcraft.block;

import dev.tc4port.thaumcraft.registry.TCSounds;
import dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult;
import com.mojang.serialization.MapCodec;
import dev.tc4port.thaumcraft.block.entity.ArcaneSpaBlockEntity;
import dev.tc4port.thaumcraft.registry.TCBlockEntities;
import javax.annotation.Nullable;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.Containers;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityTicker;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;
import dev.tc4port.thaumcraft.nativeimpl.ClientExtensionTarget;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.level.pathfinder.PathComputationType;
import net.minecraft.world.phys.HitResult;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.Explosion;

/**
 * Dedicated replacement for BlockStoneDevice metadata 12.
 */
public final class ArcaneSpaBlock extends net.minecraft.world.level.block.BaseEntityBlock implements dev.tc4port.thaumcraft.nativeimpl.ClientExtensionTarget {

    // Forge calls initializeClient from the native superclass constructor. Do not add a field initializer.
    private java.util.function.Consumer<net.minecraftforge.client.extensions.common.IClientBlockExtensions> platform$clientInstaller;

    public static final MapCodec<ArcaneSpaBlock> CODEC = ArcaneSpaBlock.native$BlockCodecPlatform$simple(ArcaneSpaBlock::new);

    public ArcaneSpaBlock(BlockBehaviour.Properties properties) {
        this(properties, properties, true);
    }

    protected MapCodec<ArcaneSpaBlock> codec() {
        return CODEC;
    }

    @Nullable
    @Override
    public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        return new ArcaneSpaBlockEntity(pos, state);
    }

    @Nullable
    @Override
    public <T extends BlockEntity> BlockEntityTicker<T> getTicker(Level level, BlockState state, BlockEntityType<T> type) {
        return level.isClientSide ? null : createTickerHelper(type, TCBlockEntities.ARCANE_SPA.get(), ArcaneSpaBlockEntity::serverTick);
    }

    @Override
    public RenderShape getRenderShape(BlockState state) {
        return RenderShape.MODEL;
    }

    @Override
    public VoxelShape getBlockSupportShape(BlockState state, BlockGetter level, BlockPos pos) {
        // BlockStoneDevice metadata 12 returned true for every support face.
        return Shapes.block();
    }

    protected ItemUseResult interactWithItem(ItemStack stack, BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
        if (player.isShiftKeyDown() || !(level.getBlockEntity(pos) instanceof dev.tc4port.thaumcraft.block.entity.ArcaneSpaBlockEntity spa)) {
            return dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
        }
        net.minecraft.world.item.ItemStack oneContainer = stack.copyWithCount(1);
        net.minecraftforge.fluids.capability.IFluidHandlerItem container = (switch(0) {
            default ->
                {
                    net.minecraft.world.item.ItemStack native$operand$13630 = oneContainer;
                    net.minecraftforge.fluids.capability.IFluidHandlerItem native$result$13631 = (native$operand$13630.getCapability(net.minecraftforge.common.capabilities.ForgeCapabilities.FLUID_HANDLER_ITEM).orElse(null));
                    yield native$result$13631;
                }
        });
        if (container == null) {
            return dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
        }
        net.minecraftforge.fluids.FluidStack offered = container.drain(java.lang.Integer.MAX_VALUE, net.minecraftforge.fluids.capability.IFluidHandler.FluidAction.SIMULATE);
        if (offered.isEmpty()) {
            return dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
        }
        /*
         * A filled legacy container suppressed the GUI even when the tank
         * was full or held another fluid. Preserve that result path.
         */
        if (!level.isClientSide && spa.tank().fill(offered, net.minecraftforge.fluids.capability.IFluidHandler.FluidAction.SIMULATE) > 0) {
            net.minecraftforge.fluids.FluidStack drained = container.drain(offered, net.minecraftforge.fluids.capability.IFluidHandler.FluidAction.EXECUTE);
            if (!drained.isEmpty()) {
                /*
                 * TileSpa consumed the whole container even if only the last
                 * fraction fitted into its 5000 mB tank.
                 */
                spa.tank().fill(drained, net.minecraftforge.fluids.capability.IFluidHandler.FluidAction.EXECUTE);
                net.minecraft.world.item.ItemStack emptyContainer = container.getContainer().copy();
                if (stack.getCount() == 1) {
                    player.setItemInHand(hand, emptyContainer);
                } else {
                    stack.shrink(1);
                    if (!emptyContainer.isEmpty() && !player.addItem(emptyContainer)) {
                        player.drop(emptyContainer, false);
                    }
                }
                spa.changedAndSync();
                level.playSound(null, pos, dev.tc4port.thaumcraft.registry.TCSounds.SPA_FILL.get(), net.minecraft.sounds.SoundSource.BLOCKS, 0.33F, 1.0F + (level.random.nextFloat() - level.random.nextFloat()) * 0.3F);
            }
        }
        return dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.sidedSuccess(level.isClientSide);
    }

    protected InteractionResult interactWithoutItem(BlockState state, Level level, BlockPos pos, Player player, BlockHitResult hit) {
        if (player.isShiftKeyDown()) {
            return net.minecraft.world.InteractionResult.PASS;
        }
        if (!level.isClientSide && player instanceof net.minecraft.server.level.ServerPlayer serverPlayer && level.getBlockEntity(pos) instanceof dev.tc4port.thaumcraft.block.entity.ArcaneSpaBlockEntity spa) {
            net.minecraftforge.network.NetworkHooks.openScreen((net.minecraft.server.level.ServerPlayer) (serverPlayer), (net.minecraft.world.MenuProvider) (spa), (java.util.function.Consumer<net.minecraft.network.FriendlyByteBuf>) (buffer -> buffer.writeBlockPos(pos)));
        }
        return net.minecraft.world.InteractionResult.sidedSuccess(level.isClientSide);
    }

    @Override
    public void onRemove(BlockState state, Level level, BlockPos pos, BlockState newState, boolean movedByPiston) {
        if (!state.is(newState.getBlock()) && level.getBlockEntity(pos) instanceof ArcaneSpaBlockEntity spa) {
            Containers.dropContents(level, pos, spa);
        }
        super.onRemove(state, level, pos, newState, movedByPiston);
    }

    private ArcaneSpaBlock(net.minecraft.world.level.block.state.BlockBehaviour.Properties native$NativeEntityBlock$arg0, BlockBehaviour.Properties properties, boolean native$NativeEntityBlock$captured) {
        super(native$NativeEntityBlock$arg0);
    }

    @Override
    public void initializeClient(java.util.function.Consumer<net.minecraftforge.client.extensions.common.IClientBlockExtensions> installer) {
        platform$clientInstaller = installer;
        super.initializeClient(installer);
    }

    @Override
    public void platform$clientExtension(Object extension) {
        java.util.Objects.requireNonNull(platform$clientInstaller, "Forge initializeClient must run before client extension registration").accept((net.minecraftforge.client.extensions.common.IClientBlockExtensions) extension);
    }

    @Override
    public InteractionResult use(BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
        ItemUseResult result = (switch(0) {
            default ->
                {
                    net.minecraft.world.item.ItemStack native$bodyOperand$4190 = player.getItemInHand(hand);
                    net.minecraft.world.level.block.state.BlockState native$bodyOperand$4191 = state;
                    net.minecraft.world.level.Level native$bodyOperand$4192 = level;
                    net.minecraft.core.BlockPos native$bodyOperand$4193 = pos;
                    net.minecraft.world.entity.player.Player native$bodyOperand$4194 = player;
                    net.minecraft.world.InteractionHand native$bodyOperand$4195 = hand;
                    net.minecraft.world.phys.BlockHitResult native$bodyOperand$4196 = hit;
                    dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult native$bodyResult$4203 = null;
                    native$bodyReturn$4204: {
                        if (true) {
                            if (native$bodyOperand$4194.isShiftKeyDown() || !(native$bodyOperand$4192.getBlockEntity(native$bodyOperand$4193) instanceof dev.tc4port.thaumcraft.block.entity.ArcaneSpaBlockEntity native$bodyBinding$4197)) {
                                {
                                    native$bodyResult$4203 = dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
                                    break native$bodyReturn$4204;
                                }
                            }
                            net.minecraft.world.item.ItemStack native$bodyBinding$4198 = native$bodyOperand$4190.copyWithCount(1);
                            net.minecraftforge.fluids.capability.IFluidHandlerItem native$bodyBinding$4199 = (switch(0) {
                                default ->
                                    {
                                        net.minecraft.world.item.ItemStack native$operand$12805 = native$bodyBinding$4198;
                                        net.minecraftforge.fluids.capability.IFluidHandlerItem native$result$12806 = (native$operand$12805.getCapability(net.minecraftforge.common.capabilities.ForgeCapabilities.FLUID_HANDLER_ITEM).orElse(null));
                                        yield native$result$12806;
                                    }
                            });
                            if (native$bodyBinding$4199 == null) {
                                {
                                    native$bodyResult$4203 = dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
                                    break native$bodyReturn$4204;
                                }
                            }
                            net.minecraftforge.fluids.FluidStack native$bodyBinding$4200 = native$bodyBinding$4199.drain(java.lang.Integer.MAX_VALUE, net.minecraftforge.fluids.capability.IFluidHandler.FluidAction.SIMULATE);
                            if (native$bodyBinding$4200.isEmpty()) {
                                {
                                    native$bodyResult$4203 = dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
                                    break native$bodyReturn$4204;
                                }
                            }
                            /*
         * A filled legacy container suppressed the GUI even when the tank
         * was full or held another fluid. Preserve that result path.
         */
                            if (!native$bodyOperand$4192.isClientSide && native$bodyBinding$4197.tank().fill(native$bodyBinding$4200, net.minecraftforge.fluids.capability.IFluidHandler.FluidAction.SIMULATE) > 0) {
                                net.minecraftforge.fluids.FluidStack native$bodyBinding$4201 = native$bodyBinding$4199.drain(native$bodyBinding$4200, net.minecraftforge.fluids.capability.IFluidHandler.FluidAction.EXECUTE);
                                if (!native$bodyBinding$4201.isEmpty()) {
                                    /*
                 * TileSpa consumed the whole container even if only the last
                 * fraction fitted into its 5000 mB tank.
                 */
                                    native$bodyBinding$4197.tank().fill(native$bodyBinding$4201, net.minecraftforge.fluids.capability.IFluidHandler.FluidAction.EXECUTE);
                                    net.minecraft.world.item.ItemStack native$bodyBinding$4202 = native$bodyBinding$4199.getContainer().copy();
                                    if (native$bodyOperand$4190.getCount() == 1) {
                                        native$bodyOperand$4194.setItemInHand(native$bodyOperand$4195, native$bodyBinding$4202);
                                    } else {
                                        native$bodyOperand$4190.shrink(1);
                                        if (!native$bodyBinding$4202.isEmpty() && !native$bodyOperand$4194.addItem(native$bodyBinding$4202)) {
                                            native$bodyOperand$4194.drop(native$bodyBinding$4202, false);
                                        }
                                    }
                                    native$bodyBinding$4197.changedAndSync();
                                    native$bodyOperand$4192.playSound(null, native$bodyOperand$4193, dev.tc4port.thaumcraft.registry.TCSounds.SPA_FILL.get(), net.minecraft.sounds.SoundSource.BLOCKS, 0.33F, 1.0F + (native$bodyOperand$4192.random.nextFloat() - native$bodyOperand$4192.random.nextFloat()) * 0.3F);
                                }
                            }
                            {
                                native$bodyResult$4203 = dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.sidedSuccess(native$bodyOperand$4192.isClientSide);
                                break native$bodyReturn$4204;
                            }
                        }
                    }
                    yield native$bodyResult$4203;
                }
        });
        return result == ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION ? (hand == InteractionHand.MAIN_HAND ? (switch(0) {
            default ->
                {
                    net.minecraft.world.level.block.state.BlockState native$bodyOperand$3516 = state;
                    net.minecraft.world.level.Level native$bodyOperand$3517 = level;
                    net.minecraft.core.BlockPos native$bodyOperand$3518 = pos;
                    net.minecraft.world.entity.player.Player native$bodyOperand$3519 = player;
                    net.minecraft.world.phys.BlockHitResult native$bodyOperand$3520 = hit;
                    net.minecraft.world.InteractionResult native$bodyResult$3524 = null;
                    native$bodyReturn$3525: {
                        if (true) {
                            if (native$bodyOperand$3519.isShiftKeyDown()) {
                                {
                                    native$bodyResult$3524 = net.minecraft.world.InteractionResult.PASS;
                                    break native$bodyReturn$3525;
                                }
                            }
                            if (!native$bodyOperand$3517.isClientSide && native$bodyOperand$3519 instanceof net.minecraft.server.level.ServerPlayer native$bodyBinding$3521 && native$bodyOperand$3517.getBlockEntity(native$bodyOperand$3518) instanceof dev.tc4port.thaumcraft.block.entity.ArcaneSpaBlockEntity native$bodyBinding$3522) {
                                net.minecraftforge.network.NetworkHooks.openScreen((net.minecraft.server.level.ServerPlayer) (native$bodyBinding$3521), (net.minecraft.world.MenuProvider) (native$bodyBinding$3522), (java.util.function.Consumer<net.minecraft.network.FriendlyByteBuf>) (native$bodyBinding$3523 -> native$bodyBinding$3523.writeBlockPos(native$bodyOperand$3518)));
                            }
                            {
                                native$bodyResult$3524 = net.minecraft.world.InteractionResult.sidedSuccess(native$bodyOperand$3517.isClientSide);
                                break native$bodyReturn$3525;
                            }
                        }
                    }
                    yield native$bodyResult$3524;
                }
        }) : InteractionResult.PASS) : result.result();
    }

    @Override
    public void playerWillDestroy(Level level, BlockPos pos, BlockState state, Player player) {
        {
            net.minecraft.world.level.Level native$bodyOperand$5690 = level;
            net.minecraft.core.BlockPos native$bodyOperand$5691 = pos;
            net.minecraft.world.level.block.state.BlockState native$bodyOperand$5692 = state;
            net.minecraft.world.entity.player.Player native$bodyOperand$5693 = player;
            net.minecraft.world.level.block.state.BlockState native$bodyResult$5694 = null;
            native$bodyReturn$5695: {
                if (true) {
                    super.playerWillDestroy(native$bodyOperand$5690, native$bodyOperand$5691, native$bodyOperand$5692, native$bodyOperand$5693);
                    {
                        native$bodyResult$5694 = native$bodyOperand$5692;
                        break native$bodyReturn$5695;
                    }
                }
            }
        }
    }

    public BlockState beforePlayerDestroy(Level level, BlockPos pos, BlockState state, Player player) {
        super.playerWillDestroy(level, pos, state, player);
        return state;
    }

    protected boolean survivesSharedExplosion() {
        return false;
    }

    public int getExpDrop(net.minecraft.world.level.block.state.BlockState native$callbackInput$1050, net.minecraft.world.level.LevelReader native$callbackInput$1051, net.minecraft.util.RandomSource native$callbackInput$1052, net.minecraft.core.BlockPos native$callbackInput$1053, int native$callbackInput$1054, int native$callbackInput$1055) {
        net.minecraft.world.level.block.state.BlockState state = native$callbackInput$1050;
        net.minecraft.util.RandomSource random = native$callbackInput$1052;
        return 0;
    }

    @Override
    public void onBlockExploded(BlockState state, Level level, BlockPos pos, Explosion explosion) {
        if (!(switch(0) {
            default ->
                {
                    boolean native$bodyResult$5225 = false;
                    native$bodyReturn$5226: {
                        if (true) {
                            {
                                native$bodyResult$5225 = false;
                                break native$bodyReturn$5226;
                            }
                        }
                    }
                    yield native$bodyResult$5225;
                }
        }))
            super.onBlockExploded(state, level, pos, explosion);
    }

    @Override
    public boolean canDropFromExplosion(BlockState state, BlockGetter level, BlockPos pos, Explosion explosion) {
        return !(switch(0) {
            default ->
                {
                    boolean native$bodyResult$4205 = false;
                    native$bodyReturn$4206: {
                        if (true) {
                            {
                                native$bodyResult$4205 = false;
                                break native$bodyReturn$4206;
                            }
                        }
                    }
                    yield native$bodyResult$4205;
                }
        }) && super.canDropFromExplosion(state, level, pos, explosion);
    }

    static private <B extends net.minecraft.world.level.block.Block> com.mojang.serialization.MapCodec<B> native$BlockCodecPlatform$simple(java.util.function.Function<net.minecraft.world.level.block.state.BlockBehaviour.Properties, B> factory) {
        // Vanilla 1.21's Properties codec is a unit codec. Retain that schema for shared block definitions.
        return com.mojang.serialization.codecs.RecordCodecBuilder.mapCodec(instance -> instance.group(com.mojang.serialization.Codec.unit(net.minecraft.world.level.block.state.BlockBehaviour.Properties::of).fieldOf("properties").forGetter((B block) -> net.minecraft.world.level.block.state.BlockBehaviour.Properties.copy(block))).apply(instance, factory));
    }
}
