package dev.tc4port.thaumcraft.block;

import com.mojang.serialization.MapCodec;
import net.minecraft.util.StringRepresentable;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.IntegerProperty;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;
import dev.tc4port.thaumcraft.nativeimpl.ClientExtensionTarget;
import dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult;
import net.minecraft.core.BlockPos;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.level.pathfinder.PathComputationType;
import net.minecraft.world.phys.HitResult;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.Explosion;

/**
 * Old urn and abandoned crate from TC4's {@code BlockLoot}.
 */
public final class LootCacheBlock extends net.minecraft.world.level.block.Block implements dev.tc4port.thaumcraft.nativeimpl.ClientExtensionTarget {

    // Forge calls initializeClient from the native superclass constructor. Do not add a field initializer.
    private java.util.function.Consumer<net.minecraftforge.client.extensions.common.IClientBlockExtensions> platform$clientInstaller;

    public enum Kind implements StringRepresentable {

        URN("urn"), CRATE("crate");

        private final String name;

        Kind(String name) {
            this.name = name;
        }

        @Override
        public String getSerializedName() {
            return this.name;
        }
    }

    public static final IntegerProperty TIER = IntegerProperty.create("tier", 0, 2);

    private static final MapCodec<LootCacheBlock> URN_CODEC = LootCacheBlock.native$BlockCodecPlatform$simple(properties -> new LootCacheBlock(Kind.URN, properties));

    private static final MapCodec<LootCacheBlock> CRATE_CODEC = LootCacheBlock.native$BlockCodecPlatform$simple(properties -> new LootCacheBlock(Kind.CRATE, properties));

    private static final VoxelShape URN_OUTLINE = Block.box(2.0, 1.0, 2.0, 14.0, 13.0, 14.0);

    private static final VoxelShape CRATE_OUTLINE = Block.box(1.0, 0.0, 1.0, 15.0, 14.0, 15.0);

    private final Kind kind;

    public LootCacheBlock(Kind kind, BlockBehaviour.Properties properties) {
        this(properties, kind, properties, true);
    }

    public Kind kind() {
        return this.kind;
    }

    protected MapCodec<LootCacheBlock> codec() {
        return this.kind == Kind.URN ? URN_CODEC : CRATE_CODEC;
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(TIER);
    }

    @Override
    public VoxelShape getShape(BlockState state, BlockGetter level, net.minecraft.core.BlockPos pos, CollisionContext context) {
        return this.kind == Kind.URN ? URN_OUTLINE : CRATE_OUTLINE;
    }

    @Override
    public VoxelShape getCollisionShape(BlockState state, BlockGetter level, net.minecraft.core.BlockPos pos, CollisionContext context) {
        // BlockLoot changed only its selected bounds; collision stayed cubic.
        return Shapes.block();
    }

    private LootCacheBlock(net.minecraft.world.level.block.state.BlockBehaviour.Properties native$NativeBlock$arg0, Kind kind, BlockBehaviour.Properties properties, boolean native$NativeBlock$captured) {
        super(native$NativeBlock$arg0);
        this.kind = kind;
        this.registerDefaultState(this.stateDefinition.any().setValue(TIER, 0));
    }

    @Override
    public void initializeClient(java.util.function.Consumer<net.minecraftforge.client.extensions.common.IClientBlockExtensions> installer) {
        platform$clientInstaller = installer;
        super.initializeClient(installer);
    }

    @Override
    public void platform$clientExtension(Object extension) {
        java.util.Objects.requireNonNull(platform$clientInstaller, "Forge initializeClient must run before client extension registration").accept((net.minecraftforge.client.extensions.common.IClientBlockExtensions) extension);
    }

    @Override
    public InteractionResult use(BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
        ItemUseResult result = (switch(0) {
            default ->
                {
                    net.minecraft.world.item.ItemStack native$bodyOperand$4551 = player.getItemInHand(hand);
                    net.minecraft.world.level.block.state.BlockState native$bodyOperand$4552 = state;
                    net.minecraft.world.level.Level native$bodyOperand$4553 = level;
                    net.minecraft.core.BlockPos native$bodyOperand$4554 = pos;
                    net.minecraft.world.entity.player.Player native$bodyOperand$4555 = player;
                    net.minecraft.world.InteractionHand native$bodyOperand$4556 = hand;
                    net.minecraft.world.phys.BlockHitResult native$bodyOperand$4557 = hit;
                    dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult native$bodyResult$4558 = null;
                    native$bodyReturn$4559: {
                        if (true) {
                            {
                                native$bodyResult$4558 = dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
                                break native$bodyReturn$4559;
                            }
                        }
                    }
                    yield native$bodyResult$4558;
                }
        });
        return result == ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION ? (hand == InteractionHand.MAIN_HAND ? (switch(0) {
            default ->
                {
                    net.minecraft.world.level.block.state.BlockState native$bodyOperand$3749 = state;
                    net.minecraft.world.level.Level native$bodyOperand$3750 = level;
                    net.minecraft.core.BlockPos native$bodyOperand$3751 = pos;
                    net.minecraft.world.entity.player.Player native$bodyOperand$3752 = player;
                    net.minecraft.world.phys.BlockHitResult native$bodyOperand$3753 = hit;
                    net.minecraft.world.InteractionResult native$bodyResult$3754 = null;
                    native$bodyReturn$3755: {
                        if (true) {
                            {
                                native$bodyResult$3754 = super.use(native$bodyOperand$3749, native$bodyOperand$3750, native$bodyOperand$3751, native$bodyOperand$3752, net.minecraft.world.InteractionHand.MAIN_HAND, native$bodyOperand$3753);
                                break native$bodyReturn$3755;
                            }
                        }
                    }
                    yield native$bodyResult$3754;
                }
        }) : InteractionResult.PASS) : result.result();
    }

    protected ItemUseResult interactWithItem(ItemStack stack, BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
        return dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
    }

    protected InteractionResult interactWithoutItem(BlockState state, Level level, BlockPos pos, Player player, BlockHitResult hit) {
        return super.use(state, level, pos, player, net.minecraft.world.InteractionHand.MAIN_HAND, hit);
    }

    @Override
    public void playerWillDestroy(Level level, BlockPos pos, BlockState state, Player player) {
        {
            net.minecraft.world.level.Level native$bodyOperand$5901 = level;
            net.minecraft.core.BlockPos native$bodyOperand$5902 = pos;
            net.minecraft.world.level.block.state.BlockState native$bodyOperand$5903 = state;
            net.minecraft.world.entity.player.Player native$bodyOperand$5904 = player;
            net.minecraft.world.level.block.state.BlockState native$bodyResult$5905 = null;
            native$bodyReturn$5906: {
                if (true) {
                    super.playerWillDestroy(native$bodyOperand$5901, native$bodyOperand$5902, native$bodyOperand$5903, native$bodyOperand$5904);
                    {
                        native$bodyResult$5905 = native$bodyOperand$5903;
                        break native$bodyReturn$5906;
                    }
                }
            }
        }
    }

    public BlockState beforePlayerDestroy(Level level, BlockPos pos, BlockState state, Player player) {
        super.playerWillDestroy(level, pos, state, player);
        return state;
    }

    protected boolean survivesSharedExplosion() {
        return false;
    }

    public int getExpDrop(net.minecraft.world.level.block.state.BlockState native$callbackInput$1145, net.minecraft.world.level.LevelReader native$callbackInput$1146, net.minecraft.util.RandomSource native$callbackInput$1147, net.minecraft.core.BlockPos native$callbackInput$1148, int native$callbackInput$1149, int native$callbackInput$1150) {
        net.minecraft.world.level.block.state.BlockState state = native$callbackInput$1145;
        net.minecraft.util.RandomSource random = native$callbackInput$1147;
        return 0;
    }

    @Override
    public void onBlockExploded(BlockState state, Level level, BlockPos pos, Explosion explosion) {
        if (!(switch(0) {
            default ->
                {
                    boolean native$bodyResult$5287 = false;
                    native$bodyReturn$5288: {
                        if (true) {
                            {
                                native$bodyResult$5287 = false;
                                break native$bodyReturn$5288;
                            }
                        }
                    }
                    yield native$bodyResult$5287;
                }
        }))
            super.onBlockExploded(state, level, pos, explosion);
    }

    @Override
    public boolean canDropFromExplosion(BlockState state, BlockGetter level, BlockPos pos, Explosion explosion) {
        return !(switch(0) {
            default ->
                {
                    boolean native$bodyResult$4560 = false;
                    native$bodyReturn$4561: {
                        if (true) {
                            {
                                native$bodyResult$4560 = false;
                                break native$bodyReturn$4561;
                            }
                        }
                    }
                    yield native$bodyResult$4560;
                }
        }) && super.canDropFromExplosion(state, level, pos, explosion);
    }

    static private <B extends net.minecraft.world.level.block.Block> com.mojang.serialization.MapCodec<B> native$BlockCodecPlatform$simple(java.util.function.Function<net.minecraft.world.level.block.state.BlockBehaviour.Properties, B> factory) {
        // Vanilla 1.21's Properties codec is a unit codec. Retain that schema for shared block definitions.
        return com.mojang.serialization.codecs.RecordCodecBuilder.mapCodec(instance -> instance.group(com.mojang.serialization.Codec.unit(net.minecraft.world.level.block.state.BlockBehaviour.Properties::of).fieldOf("properties").forGetter((B block) -> net.minecraft.world.level.block.state.BlockBehaviour.Properties.copy(block))).apply(instance, factory));
    }
}
