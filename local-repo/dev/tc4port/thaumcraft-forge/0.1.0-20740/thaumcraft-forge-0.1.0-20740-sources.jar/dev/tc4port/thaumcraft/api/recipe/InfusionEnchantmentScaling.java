package dev.tc4port.thaumcraft.api.recipe;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;

/**
 * Explicit cost coefficients; levels are measured on the input equipment.
 */
public record InfusionEnchantmentScaling(float xpPerLevel, float aspectsPerLevel, float aspectsPerOtherLevel, float instabilityPerLevel) {

    private static final Codec<Float> COEFFICIENT = Codec.floatRange(0.0F, 1_000_000.0F);

    public static final Codec<InfusionEnchantmentScaling> CODEC = RecordCodecBuilder.create(instance -> instance.group(COEFFICIENT.fieldOf("xp_per_level").forGetter(InfusionEnchantmentScaling::xpPerLevel), COEFFICIENT.fieldOf("aspects_per_level").forGetter(InfusionEnchantmentScaling::aspectsPerLevel), COEFFICIENT.fieldOf("aspects_per_other_level").forGetter(InfusionEnchantmentScaling::aspectsPerOtherLevel), COEFFICIENT.fieldOf("instability_per_level").forGetter(InfusionEnchantmentScaling::instabilityPerLevel)).apply(instance, InfusionEnchantmentScaling::new));

    public InfusionEnchantmentScaling {
        for (float value : new float[] { xpPerLevel, aspectsPerLevel, aspectsPerOtherLevel, instabilityPerLevel }) {
            if (!Float.isFinite(value) || value < 0 || value > 1_000_000) {
                throw new IllegalArgumentException("Enchantment cost coefficients must be finite and in 0..1000000");
            }
        }
    }
}
