package dev.tc4port.thaumcraft.api.research;

/**
 * Client slot coordinates relative to the container screen, preserving all 38 slot identities.
 */
public record ResearchTableLayout(int scribingX, int scribingY, int noteX, int noteY, int inventoryX, int inventoryY) {

    public static final ResearchTableLayout DEFAULT = new ResearchTableLayout(14, 10, 70, 10, 48, 175);
}
