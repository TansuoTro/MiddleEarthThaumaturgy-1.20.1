package dev.tc4port.thaumcraft.api;

import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.tags.TagKey;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.Block;

/**
 * Stable tag identities intentionally consumed as addon extension points.
 */
public final class ThaumcraftTags {

    public static final TagKey<Item> THAUMIUM_INGOTS = TagKey.create(Registries.ITEM, net.minecraft.resources.ResourceLocation.parse((java.lang.String) ("forge:ingots/thaumium")));

    public static final TagKey<Block> INCORRECT_FOR_THAUMIUM_TOOL = TagKey.create(Registries.BLOCK, (switch(0) {
        default ->
            {
                java.lang.String native$operand$14275 = "incorrect_for_diamond_tool";
                net.minecraft.resources.ResourceLocation native$result$14276 = ((switch(0) {
                    default ->
                        {
                            java.lang.String native$operand$15978 = "minecraft";
                            java.lang.String native$operand$15979 = native$operand$14275;
                            net.minecraft.resources.ResourceLocation native$result$15980 = (net.minecraft.resources.ResourceLocation.fromNamespaceAndPath(native$operand$15978, native$operand$15979));
                            yield native$result$15980;
                        }
                }));
                yield native$result$14276;
            }
    }));

    public static final TagKey<Item> REPAIRABLE_ITEMS = item("repairable");

    public static final TagKey<Item> CRAFTING_TRANSMUTATION_CATALYSTS = item("crafting_transmutation_catalysts");

    /**
     * Helmets whose infusion masks participate in combat and warp effects.
     */
    public static final TagKey<Item> INFUSION_MASK_HELMETS = item("infusion_mask_helmets");

    /**
     * Reproduces the 1.7.10 model's {@code instanceof ItemFortressArmor} count:
     * core fortress armor and addon subclasses, excluding the separate void robes.
     */
    public static final TagKey<Item> FORTRESS_ARMOR = item("fortress_armor");

    /**
     * Armor that hides the second player-skin layer covered by its equipment slot.
     */
    public static final TagKey<Item> HIDES_SKIN_LAYERS = item("hides_skin_layers");

    public static final TagKey<Item> WAND_RODS = item("wand_rods");

    public static final TagKey<Item> STAFF_CORES = item("staff_cores");

    public static final TagKey<Item> WAND_CAPS = item("wand_caps");

    public static final TagKey<Block> INFUSION_STABILIZERS = block("infusion_stabilizers");

    public static final TagKey<Block> PORTABLE_HOLE_BLACKLIST = block("portable_hole_blacklist");

    public static final TagKey<Block> LAMP_GROWTH_BLACKLIST = block("lamp_growth_blacklist");

    public static final TagKey<Block> GOLEM_STANDARD_CROPS = block("golem_standard_crops");

    public static final TagKey<Block> GOLEM_CLICKABLE_CROPS = block("golem_clickable_crops");

    public static final TagKey<Block> GOLEM_STACKED_CROPS = block("golem_stacked_crops");

    public static final TagKey<Block> GREATWOOD_GROWS_ON = block("greatwood_grows_on");

    public static final TagKey<Block> SILVERWOOD_GROWS_ON = block("silverwood_grows_on");

    public static final TagKey<Block> NODE_GENERATION_REPLACEABLE = block("node_generation_replaceable");

    /**
     * Blocks converted to crusted taint by fibrous-taint spreading.
     */
    public static final TagKey<Block> TAINT_CONVERTS_TO_CRUSTED_TAINT = block("taint_converts_to_crusted_taint");

    /**
     * Blocks converted to tainted soil by fibrous-taint spreading.
     */
    public static final TagKey<Block> TAINT_CONVERTS_TO_TAINTED_SOIL = block("taint_converts_to_tainted_soil");

    /**
     * Blocks that own the two invisible warding-aura cells above them.
     * Addons may extend this tag to reuse TC's collision, redstone and
     * delayed orphan-cleanup behavior without injecting into those paths.
     */
    public static final TagKey<Block> WARDING_AURA_SOURCES = block("warding_aura_sources");

    private ThaumcraftTags() {
    }

    private static TagKey<Item> item(String path) {
        return TagKey.create(Registries.ITEM, id(path));
    }

    private static TagKey<Block> block(String path) {
        return TagKey.create(Registries.BLOCK, id(path));
    }

    private static ResourceLocation id(String path) {
        return java.util.Objects.requireNonNull(ResourceLocation.tryBuild("thaumcraft", path));
    }
}
