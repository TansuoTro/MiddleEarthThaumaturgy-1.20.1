package dev.tc4port.thaumcraft.api.wand;

import com.mojang.serialization.Codec;
import com.mojang.serialization.DataResult;

/**
 * Controls whether a registered wand part participates in raw assembly and
 * recipe-viewer presentation. Existing assembled wands continue to resolve
 * every registered mode.
 */
public enum WandPartAssemblyMode {

    /**
     * The raw part can be assembled and is presented by recipe viewers.
     */
    NORMAL(true, true, "normal"),
    /**
     * The raw part can be assembled but is omitted from recipe viewers.
     */
    HIDDEN(true, false, "hidden"),
    /**
     * The definition only supports existing or prebuilt assembled wands.
     */
    RUNTIME_ONLY(false, false, "runtime_only");

    public static final Codec<WandPartAssemblyMode> CODEC = Codec.STRING.comapFlatMap(WandPartAssemblyMode::decode, WandPartAssemblyMode::serialized);

    private final boolean assemblyAllowed;

    private final boolean recipeViewerVisible;

    private final String serialized;

    WandPartAssemblyMode(boolean assemblyAllowed, boolean recipeViewerVisible, String serialized) {
        this.assemblyAllowed = assemblyAllowed;
        this.recipeViewerVisible = recipeViewerVisible;
        this.serialized = serialized;
    }

    public boolean assemblyAllowed() {
        return assemblyAllowed;
    }

    public boolean recipeViewerVisible() {
        return recipeViewerVisible;
    }

    public String serialized() {
        return serialized;
    }

    private static DataResult<WandPartAssemblyMode> decode(String value) {
        for (WandPartAssemblyMode mode : values()) {
            if (mode.serialized.equals(value)) {
                return DataResult.success(mode);
            }
        }
        return DataResult.error(() -> "Unknown wand-part assembly mode: " + value);
    }
}
