package dev.tc4port.thaumcraft.block;

import com.mojang.serialization.MapCodec;
import dev.tc4port.thaumcraft.block.entity.EldritchNothingBlockEntity;
import javax.annotation.Nullable;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.world.level.pathfinder.PathComputationType;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;
import dev.tc4port.thaumcraft.nativeimpl.ClientExtensionTarget;
import dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.Explosion;

/**
 * Invisible solid boundary used around the legacy Outer Lands maze.
 *
 * <p>The source block deliberately remained an opaque cube for neighbour
 * tests even though its ordinary block renderer was disabled.  Only an
 * exposed boundary cell received a tile entity for the star-field surface.
 * The modern boolean state preserves that metadata-zero/one distinction
 * without making the invisible interior replaceable or non-occluding.</p>
 */
public final class EldritchNothingBlock extends net.minecraft.world.level.block.BaseEntityBlock implements dev.tc4port.thaumcraft.nativeimpl.ClientExtensionTarget {

    // Forge calls initializeClient from the native superclass constructor. Do not add a field initializer.
    private java.util.function.Consumer<net.minecraftforge.client.extensions.common.IClientBlockExtensions> platform$clientInstaller;

    public static final MapCodec<EldritchNothingBlock> CODEC = EldritchNothingBlock.native$BlockCodecPlatform$simple(EldritchNothingBlock::new);

    public static final BooleanProperty EXPOSED = BooleanProperty.create("exposed");

    private static final VoxelShape COLLISION = Block.box(2.0, 2.0, 2.0, 14.0, 14.0, 14.0);

    public EldritchNothingBlock(BlockBehaviour.Properties properties) {
        this(properties, properties, true);
    }

    protected MapCodec<EldritchNothingBlock> codec() {
        return CODEC;
    }

    @Nullable
    @Override
    public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        return state.getValue(EXPOSED) ? new EldritchNothingBlockEntity(pos, state) : null;
    }

    @Override
    public RenderShape getRenderShape(BlockState state) {
        return RenderShape.INVISIBLE;
    }

    @Override
    public VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
        return Shapes.empty();
    }

    @Override
    public VoxelShape getCollisionShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
        return COLLISION;
    }

    @Override
    public VoxelShape getOcclusionShape(BlockState state, BlockGetter level, BlockPos pos) {
        return Shapes.block();
    }

    @Override
    public VoxelShape getBlockSupportShape(BlockState state, BlockGetter level, BlockPos pos) {
        return Shapes.block();
    }

    @Override
    public void neighborChanged(BlockState state, Level level, BlockPos pos, Block neighborBlock, BlockPos neighborPos, boolean movedByPiston) {
        super.neighborChanged(state, level, pos, neighborBlock, neighborPos, movedByPiston);
        if (level.isClientSide) {
            return;
        }
        boolean exposed = isExposed(level, pos);
        if (state.getValue(EXPOSED) == exposed) {
            return;
        }
        if (!exposed) {
            level.removeBlockEntity(pos);
        }
        level.setBlock(pos, state.setValue(EXPOSED, exposed), Block.UPDATE_CLIENTS);
    }

    public static boolean isExposed(BlockGetter level, BlockPos pos) {
        for (Direction direction : Direction.values()) {
            if (!level.getBlockState(pos.relative(direction)).canOcclude()) {
                return true;
            }
        }
        return false;
    }

    @Override
    public void entityInside(BlockState state, Level level, BlockPos pos, Entity entity) {
        if (!level.isClientSide && entity.tickCount > 20 && (!(entity instanceof Player player) || !player.isCreative())) {
            entity.hurt(level.damageSources().fellOutOfWorld(), 8.0F);
        }
    }

    @Override
    public boolean canEntityDestroy(BlockState state, BlockGetter level, BlockPos pos, Entity entity) {
        return false;
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(EXPOSED);
    }

    @Override
    public boolean isPathfindable(BlockState state, BlockGetter level, BlockPos pos, PathComputationType pathType) {
        // The inset cube floats on every side; never path through it.
        return false;
    }

    private EldritchNothingBlock(net.minecraft.world.level.block.state.BlockBehaviour.Properties native$NativeEntityBlock$arg0, BlockBehaviour.Properties properties, boolean native$NativeEntityBlock$captured) {
        super(native$NativeEntityBlock$arg0);
        this.registerDefaultState(this.stateDefinition.any().setValue(EXPOSED, false));
    }

    @Override
    public void initializeClient(java.util.function.Consumer<net.minecraftforge.client.extensions.common.IClientBlockExtensions> installer) {
        platform$clientInstaller = installer;
        super.initializeClient(installer);
    }

    @Override
    public void platform$clientExtension(Object extension) {
        java.util.Objects.requireNonNull(platform$clientInstaller, "Forge initializeClient must run before client extension registration").accept((net.minecraftforge.client.extensions.common.IClientBlockExtensions) extension);
    }

    @Override
    public InteractionResult use(BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
        ItemUseResult result = (switch(0) {
            default ->
                {
                    net.minecraft.world.item.ItemStack native$bodyOperand$4344 = player.getItemInHand(hand);
                    net.minecraft.world.level.block.state.BlockState native$bodyOperand$4345 = state;
                    net.minecraft.world.level.Level native$bodyOperand$4346 = level;
                    net.minecraft.core.BlockPos native$bodyOperand$4347 = pos;
                    net.minecraft.world.entity.player.Player native$bodyOperand$4348 = player;
                    net.minecraft.world.InteractionHand native$bodyOperand$4349 = hand;
                    net.minecraft.world.phys.BlockHitResult native$bodyOperand$4350 = hit;
                    dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult native$bodyResult$4351 = null;
                    native$bodyReturn$4352: {
                        if (true) {
                            {
                                native$bodyResult$4351 = dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
                                break native$bodyReturn$4352;
                            }
                        }
                    }
                    yield native$bodyResult$4351;
                }
        });
        return result == ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION ? (hand == InteractionHand.MAIN_HAND ? (switch(0) {
            default ->
                {
                    net.minecraft.world.level.block.state.BlockState native$bodyOperand$3617 = state;
                    net.minecraft.world.level.Level native$bodyOperand$3618 = level;
                    net.minecraft.core.BlockPos native$bodyOperand$3619 = pos;
                    net.minecraft.world.entity.player.Player native$bodyOperand$3620 = player;
                    net.minecraft.world.phys.BlockHitResult native$bodyOperand$3621 = hit;
                    net.minecraft.world.InteractionResult native$bodyResult$3622 = null;
                    native$bodyReturn$3623: {
                        if (true) {
                            {
                                native$bodyResult$3622 = super.use(native$bodyOperand$3617, native$bodyOperand$3618, native$bodyOperand$3619, native$bodyOperand$3620, net.minecraft.world.InteractionHand.MAIN_HAND, native$bodyOperand$3621);
                                break native$bodyReturn$3623;
                            }
                        }
                    }
                    yield native$bodyResult$3622;
                }
        }) : InteractionResult.PASS) : result.result();
    }

    protected ItemUseResult interactWithItem(ItemStack stack, BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
        return dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
    }

    protected InteractionResult interactWithoutItem(BlockState state, Level level, BlockPos pos, Player player, BlockHitResult hit) {
        return super.use(state, level, pos, player, net.minecraft.world.InteractionHand.MAIN_HAND, hit);
    }

    @Override
    public void playerWillDestroy(Level level, BlockPos pos, BlockState state, Player player) {
        {
            net.minecraft.world.level.Level native$bodyOperand$5793 = level;
            net.minecraft.core.BlockPos native$bodyOperand$5794 = pos;
            net.minecraft.world.level.block.state.BlockState native$bodyOperand$5795 = state;
            net.minecraft.world.entity.player.Player native$bodyOperand$5796 = player;
            net.minecraft.world.level.block.state.BlockState native$bodyResult$5797 = null;
            native$bodyReturn$5798: {
                if (true) {
                    super.playerWillDestroy(native$bodyOperand$5793, native$bodyOperand$5794, native$bodyOperand$5795, native$bodyOperand$5796);
                    {
                        native$bodyResult$5797 = native$bodyOperand$5795;
                        break native$bodyReturn$5798;
                    }
                }
            }
        }
    }

    public BlockState beforePlayerDestroy(Level level, BlockPos pos, BlockState state, Player player) {
        super.playerWillDestroy(level, pos, state, player);
        return state;
    }

    protected boolean survivesSharedExplosion() {
        return false;
    }

    public int getExpDrop(net.minecraft.world.level.block.state.BlockState native$callbackInput$1050, net.minecraft.world.level.LevelReader native$callbackInput$1051, net.minecraft.util.RandomSource native$callbackInput$1052, net.minecraft.core.BlockPos native$callbackInput$1053, int native$callbackInput$1054, int native$callbackInput$1055) {
        net.minecraft.world.level.block.state.BlockState state = native$callbackInput$1050;
        net.minecraft.util.RandomSource random = native$callbackInput$1052;
        return 0;
    }

    @Override
    public void onBlockExploded(BlockState state, Level level, BlockPos pos, Explosion explosion) {
        if (!(switch(0) {
            default ->
                {
                    boolean native$bodyResult$5251 = false;
                    native$bodyReturn$5252: {
                        if (true) {
                            {
                                native$bodyResult$5251 = false;
                                break native$bodyReturn$5252;
                            }
                        }
                    }
                    yield native$bodyResult$5251;
                }
        }))
            super.onBlockExploded(state, level, pos, explosion);
    }

    @Override
    public boolean canDropFromExplosion(BlockState state, BlockGetter level, BlockPos pos, Explosion explosion) {
        return !(switch(0) {
            default ->
                {
                    boolean native$bodyResult$4353 = false;
                    native$bodyReturn$4354: {
                        if (true) {
                            {
                                native$bodyResult$4353 = false;
                                break native$bodyReturn$4354;
                            }
                        }
                    }
                    yield native$bodyResult$4353;
                }
        }) && super.canDropFromExplosion(state, level, pos, explosion);
    }

    static private <B extends net.minecraft.world.level.block.Block> com.mojang.serialization.MapCodec<B> native$BlockCodecPlatform$simple(java.util.function.Function<net.minecraft.world.level.block.state.BlockBehaviour.Properties, B> factory) {
        // Vanilla 1.21's Properties codec is a unit codec. Retain that schema for shared block definitions.
        return com.mojang.serialization.codecs.RecordCodecBuilder.mapCodec(instance -> instance.group(com.mojang.serialization.Codec.unit(net.minecraft.world.level.block.state.BlockBehaviour.Properties::of).fieldOf("properties").forGetter((B block) -> net.minecraft.world.level.block.state.BlockBehaviour.Properties.copy(block))).apply(instance, factory));
    }
}
