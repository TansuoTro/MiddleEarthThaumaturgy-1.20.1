package dev.tc4port.thaumcraft.api.research;

import dev.tc4port.thaumcraft.api.Registration;
import dev.tc4port.thaumcraft.common.PlayerKnowledgeService;
import dev.tc4port.thaumcraft.common.TCServerConfig;
import dev.tc4port.thaumcraft.research.ResearchCatalog;
import dev.tc4port.thaumcraft.research.ResearchPurchases;
import dev.tc4port.thaumcraft.network.ResearchPurchasePayload;
import dev.tc4port.thaumcraft.network.TCPayloads;
import java.util.Objects;
import java.util.Optional;
import java.util.concurrent.atomic.AtomicBoolean;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.player.Player;
import net.minecraft.server.level.ServerPlayer;

/**
 * Stable entry point for research lookup, purchases, completion and runtime overlays.
 */
public final class ResearchApi {

    private ResearchApi() {
    }

    /**
     * Returns the local effective catalog. On a logical server this is
     * authoritative; client callers must not use a resource-pack snapshot to
     * authorize gameplay.
     */
    public static ResearchRegistryView registry() {
        return ResearchCatalog.apiView();
    }

    /**
     * Returns the currently loaded server research progression mode. This
     * read-only value is safe for data-condition and legacy-stack migration
     * decisions; gameplay mutations remain server-authoritative.
     */
    public static ResearchDifficulty difficulty() {
        return ResearchDifficulty.fromLegacyValue(TCServerConfig.researchDifficulty());
    }

    /**
     * Read-only availability and cost preview using the local catalog and
     * player state. Client results are advisory; the server rechecks the request.
     */
    public static boolean canPurchase(Player player, ResearchKey key) {
        return ResearchPurchases.canPurchase(Objects.requireNonNull(player, "player"), Objects.requireNonNull(key, "key"));
    }

    /**
     * Requests a normal note or direct purchase from a connected client. Any
     * interface may call this; no Thaumonomicon menu or held book is required.
     * Sending a request does not imply success: the server owns validation,
     * costs, inventory updates and success feedback.
     */
    public static void requestPurchase(ResearchKey key) {
        TCPayloads.CHANNEL.sendToServer(new ResearchPurchasePayload(Objects.requireNonNull(key, "key")));
    }

    /**
     * Performs a normal research transaction on the player's server thread,
     * using the current catalog, discovery clues, prerequisites, difficulty and costs. Returns
     * true only when a note was created or a direct purchase completed. No menu
     * state authorizes or blocks this operation; off-thread calls are rejected.
     */
    public static boolean purchase(ServerPlayer player, ResearchKey key) {
        return ResearchPurchases.purchase(Objects.requireNonNull(player, "player"), Objects.requireNonNull(key, "key"));
    }

    /**
     * Reads the player's knowledge attachment without consulting the local
     * research resource pack. On a physical client only the local player's
     * synchronized attachment is authoritative.
     */
    public static boolean isComplete(Player player, ResearchKey key) {
        Objects.requireNonNull(player, "player");
        Objects.requireNonNull(key, "key");
        return PlayerKnowledgeService.get(player).hasCompletedResearch(key);
    }

    /**
     * Reads the persisted discovery marker corresponding to TC4's
     * {@code @research-key} identity. A discovery is distinct from completing
     * the research itself.
     */
    public static boolean isDiscovered(Player player, ResearchKey key) {
        Objects.requireNonNull(player, "player");
        Objects.requireNonNull(key, "key");
        return PlayerKnowledgeService.get(player).hasDiscoveredResearch(key);
    }

    /**
     * Adds and synchronizes one TC4 discovery marker on the owning server
     * thread. The key need not currently exist in the data-pack catalog:
     * legacy addons used private {@code @key} milestones which were persisted
     * even before, or without, a visible research entry.
     */
    public static ResearchDiscoveryResult discover(ServerPlayer player, ResearchKey key) {
        Objects.requireNonNull(player, "player");
        Objects.requireNonNull(key, "key");
        if (!player.server.isSameThread()) {
            return ResearchDiscoveryResult.OFF_SERVER_THREAD;
        }
        var knowledge = PlayerKnowledgeService.get(player);
        if (knowledge.hasCompletedResearch(key)) {
            return ResearchDiscoveryResult.ALREADY_COMPLETE;
        }
        if (knowledge.hasDiscoveredResearch(key)) {
            return ResearchDiscoveryResult.ALREADY_DISCOVERED;
        }
        return PlayerKnowledgeService.discoverResearch(player, key) ? ResearchDiscoveryResult.DISCOVERED : ResearchDiscoveryResult.ALREADY_DISCOVERED;
    }

    /**
     * Returns the effective warp in the local catalog. Client callers must
     * not use a resource-pack value to authorize server gameplay.
     */
    public static int warp(ResearchKey key) {
        return ResearchCatalog.warpFor(Objects.requireNonNull(key, "key"));
    }

    /**
     * Returns the synchronized data-only lore/link extension for an entry.
     * Standard pages and executable rendering internals are deliberately not
     * exposed as callbacks.
     */
    public static Optional<ResearchClientPresentation> clientPresentation(ResearchKey key) {
        Objects.requireNonNull(key, "key");
        return ResearchCatalog.clientPresentation(ResearchCatalog.snapshot(), key);
    }

    /**
     * Installs a reversible programmatic warp overlay for a target entry.
     * Data-pack research definitions remain authoritative; a missing target
     * leaves the overlay dormant until that definition exists.
     */
    public static Registration registerWarp(ResearchKey key, int amount) {
        return Registration.of(ResearchCatalog.registerWarp(Objects.requireNonNull(key, "key"), amount));
    }

    /**
     * Adds one reversible exclusion contribution to a named prerequisite
     * selector group. Data-pack contributions with the same registration ID
     * remain authoritative; closing restores the preceding effective union.
     * If that smaller union fails validation, close rolls back and leaves this
     * particular handle open so its owner may retry.
     */
    public static Registration registerSelectorExclusion(ResourceLocation registrationId, ResourceLocation groupId, ResearchSelectorExclusion exclusion) {
        Runnable remover = ResearchCatalog.registerSelectorExclusion(Objects.requireNonNull(registrationId, "registrationId"), Objects.requireNonNull(groupId, "groupId"), Objects.requireNonNull(exclusion, "exclusion"));
        AtomicBoolean open = new AtomicBoolean(true);
        return () -> {
            if (!open.compareAndSet(true, false)) {
                return;
            }
            try {
                remover.run();
            } catch (RuntimeException | Error failure) {
                // The catalog restores the contribution when validation of
                // the smaller union fails, so its owner must retain a usable
                // handle and may retry after the conflicting data changes.
                open.set(true);
                throw failure;
            }
        };
    }

    /**
     * Completes one known entry on its owning server thread. Gameplay and
     * shared grants obey current parents; only the explicit admin reason may
     * bypass them. Every reason awards the entry's Warp exactly once; admin
     * grants suppress the per-entry completion popup so recursive commands do
     * not flood the client.
     */
    public static ResearchCompletionResult complete(ServerPlayer player, ResearchKey key, ResearchCompletionContext context) {
        Objects.requireNonNull(player, "player");
        Objects.requireNonNull(key, "key");
        Objects.requireNonNull(context, "context");
        if (!player.server.isSameThread()) {
            return ResearchCompletionResult.DENIED;
        }
        var entry = ResearchCatalog.get(key);
        if (entry == null) {
            return ResearchCompletionResult.UNKNOWN_RESEARCH;
        }
        var knowledge = PlayerKnowledgeService.get(player);
        if (knowledge.hasCompletedResearch(key)) {
            return ResearchCompletionResult.ALREADY_COMPLETE;
        }
        if (context.reason() != ResearchCompletionReason.ADMIN_COMMAND && !entry.requirementsMet(knowledge)) {
            return ResearchCompletionResult.MISSING_PREREQUISITE;
        }
        boolean completed = context.reason() == ResearchCompletionReason.ADMIN_COMMAND ? PlayerKnowledgeService.completeResearchSilently(player, key, entry.warp()) : PlayerKnowledgeService.completeResearch(player, key, entry.warp());
        if (!completed) {
            return ResearchCompletionResult.DENIED;
        }
        if (context.reason() == ResearchCompletionReason.GAMEPLAY_REWARD) {
            completeEligibleSiblings(player, entry);
        }
        return ResearchCompletionResult.COMPLETED;
    }

    private static void completeEligibleSiblings(ServerPlayer player, dev.tc4port.thaumcraft.research.ResearchEntryDefinition entry) {
        for (ResearchKey sibling : entry.siblings()) {
            var siblingEntry = ResearchCatalog.get(sibling);
            if (siblingEntry != null && !PlayerKnowledgeService.get(player).hasCompletedResearch(sibling) && siblingEntry.requirementsMet(PlayerKnowledgeService.get(player))) {
                PlayerKnowledgeService.completeResearch(player, sibling, siblingEntry.warp());
            }
        }
    }
}
