package dev.tc4port.thaumcraft.api.recipe;

import dev.tc4port.thaumcraft.registry.TCRecipes;
import java.util.List;
import java.util.Optional;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.Level;

/**
 * Queries the current native recipe set; no independent registration or fallback catalog.
 */
public final class InfusionEnchantmentApi {

    private InfusionEnchantmentApi() {
    }

    public record Entry(ResourceLocation id, InfusionEnchantmentRecipe recipe) {
    }

    public static List<Entry> recipes(Level level) {
        return InfusionEnchantmentApi.native$RecipeAccess$all(level.getRecipeManager(), TCRecipes.INFUSION_ENCHANTMENT.get()).stream().map(holder -> new Entry(holder.getId(), java.util.Objects.requireNonNull(holder))).toList();
    }

    public static Optional<Entry> byId(Level level, ResourceLocation id) {
        return recipes(level).stream().filter(entry -> entry.id().equals(id)).findFirst();
    }

    @SuppressWarnings({ "unchecked", "rawtypes" })
    static private <T extends net.minecraft.world.item.crafting.Recipe<?>> java.util.List<T> native$RecipeAccess$all(net.minecraft.world.item.crafting.RecipeManager manager, net.minecraft.world.item.crafting.RecipeType<T> type) {
        java.util.List<T> values = manager.getAllRecipesFor((net.minecraft.world.item.crafting.RecipeType) type);
        return values.stream().map(InfusionEnchantmentApi::native$RecipeAccess$entry).toList();
    }

    static private <T extends net.minecraft.world.item.crafting.Recipe<?>> T native$RecipeAccess$entry(T recipe) {
        return InfusionEnchantmentApi.native$RecipeAccess$identified(recipe.getId(), recipe);
    }

    static private <T extends net.minecraft.world.item.crafting.Recipe<?>> T native$RecipeAccess$identified(net.minecraft.resources.ResourceLocation id, T recipe) {
        dev.tc4port.thaumcraft.api.recipe.NativeRecipeIds.bind(recipe, id);
        return recipe;
    }
}
