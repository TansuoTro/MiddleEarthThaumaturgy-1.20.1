package dev.tc4port.thaumcraft.block;

import dev.tc4port.thaumcraft.common.MultiblockFormation;
import dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult;
import com.mojang.serialization.MapCodec;
import dev.tc4port.thaumcraft.api.ThaumcraftApiHelper;
import dev.tc4port.thaumcraft.api.aspect.VisAction;
import dev.tc4port.thaumcraft.api.aspect.VisPaymentResult;
import dev.tc4port.thaumcraft.block.entity.AuraNodeBlockEntity;
import dev.tc4port.thaumcraft.block.entity.NodeJarBlockEntity;
import dev.tc4port.thaumcraft.api.node.NodeModifierId;
import dev.tc4port.thaumcraft.common.CompoundBlueprintCatalog;
import dev.tc4port.thaumcraft.common.PlayerKnowledgeService;
import dev.tc4port.thaumcraft.common.WandInteractionTarget;
import dev.tc4port.thaumcraft.common.WandVis;
import dev.tc4port.thaumcraft.api.node.AuraNodeState;
import dev.tc4port.thaumcraft.item.NodeJarItem;
import dev.tc4port.thaumcraft.api.wand.WandCarrierItem;
import dev.tc4port.thaumcraft.registry.TCBlocks;
import dev.tc4port.thaumcraft.state.TCItemState;
import dev.tc4port.thaumcraft.registry.TCItems;
import dev.tc4port.thaumcraft.worldgen.AuraNodeFactory;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import javax.annotation.Nullable;
import net.minecraft.world.phys.HitResult;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.LevelEvent;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.storage.loot.LootParams;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;
import dev.tc4port.thaumcraft.nativeimpl.ClientExtensionTarget;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.level.pathfinder.PathComputationType;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.Explosion;

/**
 * The metadata-2 {@code BlockJar} host used by TC4's jarred aura nodes.
 *
 * <p>This is intentionally not a normal jar variant. It owns a complete
 * {@link AuraNodeState} payload, drops the dedicated
 * node-jar item, and a wand releases the same node instance instead of
 * opening an essentia inventory.</p>
 */
public final class NodeJarBlock extends net.minecraft.world.level.block.BaseEntityBlock implements WandInteractionTarget, dev.tc4port.thaumcraft.nativeimpl.ClientExtensionTarget {

    // Forge calls initializeClient from the native superclass constructor. Do not add a field initializer.
    private java.util.function.Consumer<net.minecraftforge.client.extensions.common.IClientBlockExtensions> platform$clientInstaller;

    public static final MapCodec<NodeJarBlock> CODEC = NodeJarBlock.native$BlockCodecPlatform$simple(NodeJarBlock::new);

    private static final VoxelShape OUTLINE = Block.box(3, 0, 3, 13, 12, 13);

    public NodeJarBlock(BlockBehaviour.Properties properties) {
        this(properties, properties, true);
    }

    protected MapCodec<NodeJarBlock> codec() {
        return CODEC;
    }

    @Nullable
    @Override
    public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        return new NodeJarBlockEntity(pos, state);
    }

    @Override
    public void setPlacedBy(Level level, BlockPos pos, BlockState state, @Nullable LivingEntity placer, ItemStack stack) {
        super.setPlacedBy(level, pos, state, placer, stack);
        if (level.getBlockEntity(pos) instanceof NodeJarBlockEntity placed) {
            placed.applyComponentsFromItemStack(stack);
        }
        AuraNodeState itemData = (switch(0) {
            default ->
                {
                    dev.tc4port.thaumcraft.api.data.ItemStateKey<dev.tc4port.thaumcraft.api.node.AuraNodeState> native$receiver$531 = TCItemState.NODE;
                    net.minecraft.world.item.ItemStack native$argument$532 = stack;
                    dev.tc4port.thaumcraft.api.node.AuraNodeState native$argument$533 = AuraNodeState.EMPTY;
                    java.util.Objects.requireNonNull(native$receiver$531);
                    yield dev.tc4port.thaumcraft.api.item.ItemStatePlatform.getOrDefault(native$argument$532, native$receiver$531, native$argument$533);
                }
        });
        if (!NodeJarItem.isUninitialized(itemData) || !(level instanceof ServerLevel serverLevel) || !(level.getBlockEntity(pos) instanceof NodeJarBlockEntity jar)) {
            return;
        }
        AuraNodeState generated = AuraNodeFactory.create(serverLevel, pos, serverLevel.getRandom(), false, false, false);
        jar.setNodeState(new AuraNodeState(Optional.of(UUID.randomUUID()), generated.type(), generated.modifier(), generated.currentVis(), generated.currentVis()));
    }

    @Override
    public RenderShape getRenderShape(BlockState state) {
        /*
         * Match the proven Brain Jar split: the animated contents remain in
         * the block-entity renderer while the inherited jar shell joins the
         * chunk translucent layer with glass and water.  The chunk layer is
         * submitted after the BER node, preserving contents-before-shell
         * composition without a separately sorted translucent BER shell.
         */
        return RenderShape.MODEL;
    }

    @Override
    public VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
        return OUTLINE;
    }

    @Override
    public VoxelShape getCollisionShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
        // BlockJar used its full-cube bounds only for collision.
        return Shapes.block();
    }

    @Override
    public float getShadeBrightness(BlockState state, BlockGetter level, BlockPos pos) {
        // BlockJar was non-opaque even though its collision filled a cube.
        return 1.0F;
    }

    protected ItemUseResult interactWithItem(ItemStack stack, BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
        if (!(stack.getItem() instanceof dev.tc4port.thaumcraft.api.wand.WandCarrierItem) || !(level.getBlockEntity(pos) instanceof dev.tc4port.thaumcraft.block.entity.NodeJarBlockEntity jar)) {
            return dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
        }
        if (!level.isClientSide) {
            releaseNode((net.minecraft.server.level.ServerLevel) level, pos, jar);
        }
        return dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.sidedSuccess(level.isClientSide);
    }

    /**
     * Recreates {@code TileJarNode#onWandRightClick}: the jar is consumed,
     * the node id/type/modifier/current/base aspects are preserved, and only
     * the jar's glass break effect is played.
     */
    public static void releaseNode(ServerLevel level, BlockPos pos, NodeJarBlockEntity jar) {
        AuraNodeState data = NodeJarItem.normalizeNodeState(jar.nodeState());
        BlockState jarState = level.getBlockState(pos);
        level.setBlock(pos, TCBlocks.AURA_NODE.get().defaultBlockState(), Block.UPDATE_ALL);
        if (level.getBlockEntity(pos) instanceof AuraNodeBlockEntity node) {
            node.setNodeState(data);
        }
        level.levelEvent(LevelEvent.PARTICLES_DESTROY_BLOCK, pos, Block.getId(jarState));
        level.playSound(null, pos, SoundEvents.GLASS_BREAK, SoundSource.BLOCKS, 1.0F, 0.9F + level.random.nextFloat() * 0.2F);
    }

    /**
     * Searches the same x-2..x, y-3..y, z-2..z anchor range as
     * WandManager#createNodeJar.  ConfigRecipes registered event four only
     * for vanilla glass, so the top wooden slabs and central node are not
     * valid trigger faces even though they are members of the blueprint.
     */
    public static net.minecraft.world.InteractionResult tryForm(UseOnContext context) {
        Player player = context.getPlayer();
        if (player == null || !(context.getItemInHand().getItem() instanceof WandCarrierItem)) {
            return net.minecraft.world.InteractionResult.PASS;
        }
        Level level = context.getLevel();
        BlockPos clicked = context.getClickedPos();
        if (!CompoundBlueprintCatalog.isTrigger(CompoundBlueprintCatalog.NODE_JAR, level.getBlockState(clicked))) {
            return net.minecraft.world.InteractionResult.PASS;
        }
        /*
         * A registered construction trigger owns a focusless glass click
         * even when research or the multiblock check fails. Equipped block
         * foci are dispatched by WandItem before entering this path.
         */
        var blueprint = CompoundBlueprintCatalog.require(CompoundBlueprintCatalog.NODE_JAR);
        if (!PlayerKnowledgeService.get(player).hasCompletedResearch(blueprint.research())) {
            return net.minecraft.world.InteractionResult.FAIL;
        }
        for (int x = -2; x <= 0; x++) {
            for (int y = -3; y <= 0; y++) {
                for (int z = -2; z <= 0; z++) {
                    BlockPos anchor = clicked.offset(x, y, z);
                    if (!fits(level, anchor)) {
                        continue;
                    }
                    ItemStack wand = context.getItemInHand();
                    var cost = WandVis.craftingCost(wand, player, blueprint.aspects());
                    if (ThaumcraftApiHelper.consumeExactVisFromWand(wand, player, cost, VisAction.SIMULATE) != VisPaymentResult.AVAILABLE) {
                        return net.minecraft.world.InteractionResult.FAIL;
                    }
                    if (!level.isClientSide) {
                        if (!MultiblockFormation.convert((ServerLevel) level, player, context.getClickedFace(), wand, cost, () -> form((ServerLevel) level, anchor), () -> {
                            level.blockEvent(anchor.offset(1, 0, 1), TCBlocks.NODE_JAR.get(), 9, 0);
                            level.playSound(null, anchor, dev.tc4port.thaumcraft.registry.TCSounds.WAND.get(), SoundSource.BLOCKS, 1.0F, 1.0F);
                        })) {
                            return net.minecraft.world.InteractionResult.FAIL;
                        }
                    }
                    player.swing(context.getHand());
                    return net.minecraft.world.InteractionResult.sidedSuccess(level.isClientSide);
                }
            }
        }
        return net.minecraft.world.InteractionResult.FAIL;
    }

    /**
     * Four source blueprint layers are addressed from top to bottom:
     * nine wooden slabs, nine glass, a glass ring around the node, and nine
     * glass. Glass is deliberately exact vanilla clear glass, not a tag.
     */
    public static boolean fits(Level level, BlockPos anchor) {
        BlockPos nodePos = anchor.offset(1, 0, 1);
        // The port shares one block-entity type for TileNode and
        // TileNodeEnergized; only the former implemented INode in TC4.
        return CompoundBlueprintCatalog.matchesFormation(CompoundBlueprintCatalog.NODE_JAR, level, anchor.offset(0, 2, 0)) && level.getBlockEntity(nodePos) instanceof AuraNodeBlockEntity node && node.canTapIntoWand();
    }

    private static boolean form(ServerLevel level, BlockPos anchor) {
        BlockPos nodePos = anchor.offset(1, 0, 1);
        if (!(level.getBlockEntity(nodePos) instanceof AuraNodeBlockEntity node) || !node.canTapIntoWand()) {
            return false;
        }
        AuraNodeState source = node.nodeState();
        NodeModifierId modifier = source.modifier();
        if (level.random.nextFloat() < 0.75F) {
            if (modifier.equals(NodeModifierId.NONE)) {
                modifier = NodeModifierId.PALE;
            } else if (modifier.equals(NodeModifierId.BRIGHT)) {
                modifier = NodeModifierId.NONE;
            } else if (modifier.equals(NodeModifierId.PALE)) {
                modifier = NodeModifierId.FADING;
            }
        }
        /*
         * TileJarNode#setAspects copied the captured current AspectList into
         * both its live and base stores; it did not retain TileNode's old
         * higher base values.
         */
        AuraNodeState jarData = new AuraNodeState(source.instanceId(), source.type(), modifier, source.currentVis(), source.currentVis());
        for (int yLayer = 0; yLayer < 4; yLayer++) {
            for (int x = 0; x < 3; x++) {
                for (int z = 0; z < 3; z++) {
                    BlockPos target = anchor.offset(x, 2 - yLayer, z);
                    if (target.equals(nodePos)) {
                        if (!level.setBlock(target, TCBlocks.NODE_JAR.get().defaultBlockState(), Block.UPDATE_ALL))
                            return false;
                        if (level.getBlockEntity(target) instanceof NodeJarBlockEntity jar) {
                            jar.setNodeState(jarData);
                        } else
                            return false;
                    } else {
                        if (!level.removeBlock(target, false))
                            return false;
                    }
                }
            }
        }
        return true;
    }

    @Override
    public ItemStack getCloneItemStack(BlockState state, HitResult target, net.minecraft.world.level.BlockGetter level, BlockPos pos, Player player) {
        ItemStack stack = new ItemStack(TCItems.byId("node_jar_item").get());
        if (level.getBlockEntity(pos) instanceof NodeJarBlockEntity jar) {
            {
                dev.tc4port.thaumcraft.block.entity.NodeJarBlockEntity native$receiver$979 = jar;
                net.minecraft.world.item.ItemStack native$argument$980 = stack;
                net.minecraft.core.HolderLookup.Provider native$argument$981 = player.level().registryAccess();
                java.util.Objects.requireNonNull(native$receiver$979);
                native$receiver$979.saveToItem(native$argument$980);
            }
        }
        return stack;
    }

    public BlockState beforePlayerDestroy(Level level, BlockPos pos, BlockState state, Player player) {
        /*
         * ServerPlayerGameMode skips playerDestroy (and therefore loot) in
         * creative. BlockJar#onBlockHarvested explicitly invoked its drop
         * path in both modes, so restore only the skipped creative branch.
         */
        if (player.isCreative() && level instanceof net.minecraft.server.level.ServerLevel serverLevel && level.getBlockEntity(pos) instanceof dev.tc4port.thaumcraft.block.entity.NodeJarBlockEntity jar) {
            net.minecraft.world.level.block.Block.dropResources(state, serverLevel, pos, jar, player, player.getMainHandItem());
        }
        return (switch(0) {
            default ->
                {
                    net.minecraft.world.level.Level native$bodyOperand$5948 = level;
                    net.minecraft.core.BlockPos native$bodyOperand$5949 = pos;
                    net.minecraft.world.level.block.state.BlockState native$bodyOperand$5950 = state;
                    net.minecraft.world.entity.player.Player native$bodyOperand$5951 = player;
                    net.minecraft.world.level.block.state.BlockState native$bodyResult$5952 = null;
                    native$bodyReturn$5953: {
                        if (true) {
                            super.playerWillDestroy(native$bodyOperand$5948, native$bodyOperand$5949, native$bodyOperand$5950, native$bodyOperand$5951);
                            {
                                native$bodyResult$5952 = native$bodyOperand$5950;
                                break native$bodyReturn$5953;
                            }
                        }
                    }
                    yield native$bodyResult$5952;
                }
        });
    }

    @Override
    public List<ItemStack> getDrops(BlockState state, LootParams.Builder params) {
        BlockEntity entity = params.getOptionalParameter(net.minecraft.world.level.storage.loot.parameters.LootContextParams.BLOCK_ENTITY);
        if (!(entity instanceof NodeJarBlockEntity))
            return List.of();
        return super.getDrops(state, params);
    }

    private NodeJarBlock(net.minecraft.world.level.block.state.BlockBehaviour.Properties native$NativeEntityBlock$arg0, BlockBehaviour.Properties properties, boolean native$NativeEntityBlock$captured) {
        super(native$NativeEntityBlock$arg0);
    }

    @Override
    public void initializeClient(java.util.function.Consumer<net.minecraftforge.client.extensions.common.IClientBlockExtensions> installer) {
        platform$clientInstaller = installer;
        super.initializeClient(installer);
    }

    @Override
    public void platform$clientExtension(Object extension) {
        java.util.Objects.requireNonNull(platform$clientInstaller, "Forge initializeClient must run before client extension registration").accept((net.minecraftforge.client.extensions.common.IClientBlockExtensions) extension);
    }

    @Override
    public InteractionResult use(BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
        ItemUseResult result = (switch(0) {
            default ->
                {
                    net.minecraft.world.item.ItemStack native$bodyOperand$4628 = player.getItemInHand(hand);
                    net.minecraft.world.level.block.state.BlockState native$bodyOperand$4629 = state;
                    net.minecraft.world.level.Level native$bodyOperand$4630 = level;
                    net.minecraft.core.BlockPos native$bodyOperand$4631 = pos;
                    net.minecraft.world.entity.player.Player native$bodyOperand$4632 = player;
                    net.minecraft.world.InteractionHand native$bodyOperand$4633 = hand;
                    net.minecraft.world.phys.BlockHitResult native$bodyOperand$4634 = hit;
                    dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult native$bodyResult$4636 = null;
                    native$bodyReturn$4637: {
                        if (true) {
                            if (!(native$bodyOperand$4628.getItem() instanceof dev.tc4port.thaumcraft.api.wand.WandCarrierItem) || !(native$bodyOperand$4630.getBlockEntity(native$bodyOperand$4631) instanceof dev.tc4port.thaumcraft.block.entity.NodeJarBlockEntity native$bodyBinding$4635)) {
                                {
                                    native$bodyResult$4636 = dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
                                    break native$bodyReturn$4637;
                                }
                            }
                            if (!native$bodyOperand$4630.isClientSide) {
                                releaseNode((net.minecraft.server.level.ServerLevel) native$bodyOperand$4630, native$bodyOperand$4631, native$bodyBinding$4635);
                            }
                            {
                                native$bodyResult$4636 = dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.sidedSuccess(native$bodyOperand$4630.isClientSide);
                                break native$bodyReturn$4637;
                            }
                        }
                    }
                    yield native$bodyResult$4636;
                }
        });
        return result == ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION ? (hand == InteractionHand.MAIN_HAND ? (switch(0) {
            default ->
                {
                    net.minecraft.world.level.block.state.BlockState native$bodyOperand$3801 = state;
                    net.minecraft.world.level.Level native$bodyOperand$3802 = level;
                    net.minecraft.core.BlockPos native$bodyOperand$3803 = pos;
                    net.minecraft.world.entity.player.Player native$bodyOperand$3804 = player;
                    net.minecraft.world.phys.BlockHitResult native$bodyOperand$3805 = hit;
                    net.minecraft.world.InteractionResult native$bodyResult$3806 = null;
                    native$bodyReturn$3807: {
                        if (true) {
                            {
                                native$bodyResult$3806 = super.use(native$bodyOperand$3801, native$bodyOperand$3802, native$bodyOperand$3803, native$bodyOperand$3804, net.minecraft.world.InteractionHand.MAIN_HAND, native$bodyOperand$3805);
                                break native$bodyReturn$3807;
                            }
                        }
                    }
                    yield native$bodyResult$3806;
                }
        }) : InteractionResult.PASS) : result.result();
    }

    protected InteractionResult interactWithoutItem(BlockState state, Level level, BlockPos pos, Player player, BlockHitResult hit) {
        return super.use(state, level, pos, player, net.minecraft.world.InteractionHand.MAIN_HAND, hit);
    }

    @Override
    public void playerWillDestroy(Level level, BlockPos pos, BlockState state, Player player) {
        {
            net.minecraft.world.level.Level native$bodyOperand$5954 = level;
            net.minecraft.core.BlockPos native$bodyOperand$5955 = pos;
            net.minecraft.world.level.block.state.BlockState native$bodyOperand$5956 = state;
            net.minecraft.world.entity.player.Player native$bodyOperand$5957 = player;
            net.minecraft.world.level.block.state.BlockState native$bodyResult$5960 = null;
            native$bodyReturn$5961: {
                if (true) {
                    /*
         * ServerPlayerGameMode skips playerDestroy (and therefore loot) in
         * creative. BlockJar#onBlockHarvested explicitly invoked its drop
         * path in both modes, so restore only the skipped creative branch.
         */
                    if (native$bodyOperand$5957.isCreative() && native$bodyOperand$5954 instanceof net.minecraft.server.level.ServerLevel native$bodyBinding$5958 && native$bodyOperand$5954.getBlockEntity(native$bodyOperand$5955) instanceof dev.tc4port.thaumcraft.block.entity.NodeJarBlockEntity native$bodyBinding$5959) {
                        net.minecraft.world.level.block.Block.dropResources(native$bodyOperand$5956, native$bodyBinding$5958, native$bodyOperand$5955, native$bodyBinding$5959, native$bodyOperand$5957, native$bodyOperand$5957.getMainHandItem());
                    }
                    {
                        native$bodyResult$5960 = (switch(0) {
                            default ->
                                {
                                    net.minecraft.world.level.Level native$bodyOperand$9003 = native$bodyOperand$5954;
                                    net.minecraft.core.BlockPos native$bodyOperand$9004 = native$bodyOperand$5955;
                                    net.minecraft.world.level.block.state.BlockState native$bodyOperand$9005 = native$bodyOperand$5956;
                                    net.minecraft.world.entity.player.Player native$bodyOperand$9006 = native$bodyOperand$5957;
                                    net.minecraft.world.level.block.state.BlockState native$bodyResult$9007 = null;
                                    native$bodyReturn$9008: {
                                        if (true) {
                                            super.playerWillDestroy(native$bodyOperand$9003, native$bodyOperand$9004, native$bodyOperand$9005, native$bodyOperand$9006);
                                            {
                                                native$bodyResult$9007 = native$bodyOperand$9005;
                                                break native$bodyReturn$9008;
                                            }
                                        }
                                    }
                                    yield native$bodyResult$9007;
                                }
                        });
                        break native$bodyReturn$5961;
                    }
                }
            }
        }
    }

    protected boolean survivesSharedExplosion() {
        return false;
    }

    public int getExpDrop(net.minecraft.world.level.block.state.BlockState native$callbackInput$1050, net.minecraft.world.level.LevelReader native$callbackInput$1051, net.minecraft.util.RandomSource native$callbackInput$1052, net.minecraft.core.BlockPos native$callbackInput$1053, int native$callbackInput$1054, int native$callbackInput$1055) {
        net.minecraft.world.level.block.state.BlockState state = native$callbackInput$1050;
        net.minecraft.util.RandomSource random = native$callbackInput$1052;
        return 0;
    }

    @Override
    public void onBlockExploded(BlockState state, Level level, BlockPos pos, Explosion explosion) {
        if (!(switch(0) {
            default ->
                {
                    boolean native$bodyResult$5301 = false;
                    native$bodyReturn$5302: {
                        if (true) {
                            {
                                native$bodyResult$5301 = false;
                                break native$bodyReturn$5302;
                            }
                        }
                    }
                    yield native$bodyResult$5301;
                }
        }))
            super.onBlockExploded(state, level, pos, explosion);
    }

    @Override
    public boolean canDropFromExplosion(BlockState state, BlockGetter level, BlockPos pos, Explosion explosion) {
        return !(switch(0) {
            default ->
                {
                    boolean native$bodyResult$4638 = false;
                    native$bodyReturn$4639: {
                        if (true) {
                            {
                                native$bodyResult$4638 = false;
                                break native$bodyReturn$4639;
                            }
                        }
                    }
                    yield native$bodyResult$4638;
                }
        }) && super.canDropFromExplosion(state, level, pos, explosion);
    }

    static private <B extends net.minecraft.world.level.block.Block> com.mojang.serialization.MapCodec<B> native$BlockCodecPlatform$simple(java.util.function.Function<net.minecraft.world.level.block.state.BlockBehaviour.Properties, B> factory) {
        // Vanilla 1.21's Properties codec is a unit codec. Retain that schema for shared block definitions.
        return com.mojang.serialization.codecs.RecordCodecBuilder.mapCodec(instance -> instance.group(com.mojang.serialization.Codec.unit(net.minecraft.world.level.block.state.BlockBehaviour.Properties::of).fieldOf("properties").forGetter((B block) -> net.minecraft.world.level.block.state.BlockBehaviour.Properties.copy(block))).apply(instance, factory));
    }
}
