package dev.tc4port.thaumcraft.block;

import com.mojang.serialization.MapCodec;
import dev.tc4port.thaumcraft.client.WispMoteParticle;
import net.minecraft.core.BlockPos;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;

/**
 * Shimmerleaf remains a plains plant. TC4 world generation could initially
 * place it on sand, but the inherited BlockBush update subsequently removed
 * that unsupported state.
 */
public final class ShimmerleafBlock extends TCPlantBlock {

    public ShimmerleafBlock(BlockBehaviour.Properties properties) {
        super(properties);
    }

    @Override
    public void animateTick(BlockState state, Level level, BlockPos pos, RandomSource random) {
        if (random.nextInt(3) == 0) {
            float red = 0.3F + level.random.nextFloat() * 0.3F;
            float green = 0.7F + level.random.nextFloat() * 0.3F;
            float blue = 0.7F + level.random.nextFloat() * 0.3F;
            WispMoteParticle.spawn(level, pos.getX() + 0.5 + (random.nextFloat() - random.nextFloat()) * 0.1, pos.getY() + 0.5 + (random.nextFloat() - random.nextFloat()) * 0.15, pos.getZ() + 0.5 + (random.nextFloat() - random.nextFloat()) * 0.1, 0.2F, red, green, blue, false, 0.0F);
        }
    }

    public static final MapCodec<ShimmerleafBlock> CODEC = ShimmerleafBlock.native$BlockCodecPlatform$simple(ShimmerleafBlock::new);

    protected MapCodec<? extends ShimmerleafBlock> codec() {
        return CODEC;
    }

    static private <B extends net.minecraft.world.level.block.Block> com.mojang.serialization.MapCodec<B> native$BlockCodecPlatform$simple(java.util.function.Function<net.minecraft.world.level.block.state.BlockBehaviour.Properties, B> factory) {
        // Vanilla 1.21's Properties codec is a unit codec. Retain that schema for shared block definitions.
        return com.mojang.serialization.codecs.RecordCodecBuilder.mapCodec(instance -> instance.group(com.mojang.serialization.Codec.unit(net.minecraft.world.level.block.state.BlockBehaviour.Properties::of).fieldOf("properties").forGetter((B block) -> net.minecraft.world.level.block.state.BlockBehaviour.Properties.copy(block))).apply(instance, factory));
    }
}
