package dev.tc4port.thaumcraft.api.node;

import java.util.Objects;

/**
 * Read-only world-generation and ecology parameters from the active catalog.
 *
 * @param defaultType ordinary generated-node type
 * @param defaultModifier fallback modifier when no special modifier is rolled
 * @param silverwoodType type selected for silverwood generation
 * @param eerieType type selected for eerie generation
 * @param taintedType type selected for tainted-biome generation
 * @param modifierRarityDivisor divisor used when rolling a special modifier
 * @param smallAuraDivisor divisor applied to silverwood/small aura budgets
 * @param taintedAuraMultiplier multiplier applied to a tainted area's aura
 * @param extraAspectAttempts number of additional aspect-generation attempts
 * @param environmentRadius block radius of the cubic environment scan
 * @param waterThreshold water-block count that must be strictly exceeded
 * @param lavaThreshold lava-block count that must be strictly exceeded
 * @param stoneThreshold stone-block count that must be strictly exceeded
 * @param foliageThreshold foliage-block count that must be strictly exceeded
 * @param strongSpreadMinimum minimum strong-seeded aspect allocation weight
 * @param strongSpreadRange random range added to that strong allocation
 * @param ordinarySpreadMinimum minimum ordinary aspect allocation weight
 * @param ordinarySpreadRange random range added to that ordinary allocation
 */
public record NodeGenerationSettings(NodeTypeId defaultType, NodeModifierId defaultModifier, NodeTypeId silverwoodType, NodeTypeId eerieType, NodeTypeId taintedType, int modifierRarityDivisor, int smallAuraDivisor, float taintedAuraMultiplier, int extraAspectAttempts, int environmentRadius, int waterThreshold, int lavaThreshold, int stoneThreshold, int foliageThreshold, int strongSpreadMinimum, int strongSpreadRange, int ordinarySpreadMinimum, int ordinarySpreadRange) {

    public NodeGenerationSettings {
        defaultType = Objects.requireNonNull(defaultType, "defaultType");
        defaultModifier = Objects.requireNonNull(defaultModifier, "defaultModifier");
        silverwoodType = Objects.requireNonNull(silverwoodType, "silverwoodType");
        eerieType = Objects.requireNonNull(eerieType, "eerieType");
        taintedType = Objects.requireNonNull(taintedType, "taintedType");
        if (modifierRarityDivisor <= 0 || smallAuraDivisor <= 0 || !Float.isFinite(taintedAuraMultiplier) || taintedAuraMultiplier <= 0.0F || taintedAuraMultiplier > 1_000.0F || extraAspectAttempts <= 0 || environmentRadius <= 0 || waterThreshold < 0 || lavaThreshold < 0 || stoneThreshold < 0 || foliageThreshold < 0 || strongSpreadMinimum <= 0 || strongSpreadRange <= 0 || ordinarySpreadMinimum <= 0 || ordinarySpreadRange <= 0) {
            throw new IllegalArgumentException("Invalid node generation settings");
        }
    }
}
