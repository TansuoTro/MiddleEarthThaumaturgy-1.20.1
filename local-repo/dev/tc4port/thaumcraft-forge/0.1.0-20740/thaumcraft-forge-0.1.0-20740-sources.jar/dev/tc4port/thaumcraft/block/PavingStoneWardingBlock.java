package dev.tc4port.thaumcraft.block;

import com.mojang.serialization.MapCodec;
import dev.tc4port.thaumcraft.api.block.WardingAuraApi;
import dev.tc4port.thaumcraft.block.entity.PavingStoneWardingBlockEntity;
import dev.tc4port.thaumcraft.registry.TCBlockEntities;
import javax.annotation.Nullable;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityTicker;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import dev.tc4port.thaumcraft.nativeimpl.ClientExtensionTarget;
import dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.level.pathfinder.PathComputationType;
import net.minecraft.world.phys.HitResult;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.Explosion;
import net.minecraft.world.level.BlockGetter;

/**
 * TC4's {@code BlockCosmeticSolid} metadata-three paving stone.
 */
public final class PavingStoneWardingBlock extends net.minecraft.world.level.block.BaseEntityBlock implements dev.tc4port.thaumcraft.nativeimpl.ClientExtensionTarget {

    // Forge calls initializeClient from the native superclass constructor. Do not add a field initializer.
    private java.util.function.Consumer<net.minecraftforge.client.extensions.common.IClientBlockExtensions> platform$clientInstaller;

    public static final MapCodec<PavingStoneWardingBlock> CODEC = PavingStoneWardingBlock.native$BlockCodecPlatform$simple(PavingStoneWardingBlock::new);

    public PavingStoneWardingBlock(BlockBehaviour.Properties properties) {
        this(properties, properties, true);
    }

    protected MapCodec<PavingStoneWardingBlock> codec() {
        return CODEC;
    }

    @Nullable
    @Override
    public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        return new PavingStoneWardingBlockEntity(pos, state);
    }

    @Nullable
    @Override
    public <T extends BlockEntity> BlockEntityTicker<T> getTicker(Level level, BlockState state, BlockEntityType<T> type) {
        if (level.isClientSide) {
            return null;
        }
        return createTickerHelper(type, TCBlockEntities.PAVING_STONE_WARDING.get(), PavingStoneWardingBlockEntity::tick);
    }

    @Override
    public RenderShape getRenderShape(BlockState state) {
        return RenderShape.MODEL;
    }

    @Override
    public void neighborChanged(BlockState state, Level level, BlockPos pos, Block neighborBlock, BlockPos neighborPos, boolean movedByPiston) {
        super.neighborChanged(state, level, pos, neighborBlock, neighborPos, movedByPiston);
        WardingAuraApi.syncBlockingState(level, pos.above());
        WardingAuraApi.syncBlockingState(level, pos.above(2));
    }

    private PavingStoneWardingBlock(net.minecraft.world.level.block.state.BlockBehaviour.Properties native$NativeEntityBlock$arg0, BlockBehaviour.Properties properties, boolean native$NativeEntityBlock$captured) {
        super(native$NativeEntityBlock$arg0);
    }

    @Override
    public void initializeClient(java.util.function.Consumer<net.minecraftforge.client.extensions.common.IClientBlockExtensions> installer) {
        platform$clientInstaller = installer;
        super.initializeClient(installer);
    }

    @Override
    public void platform$clientExtension(Object extension) {
        java.util.Objects.requireNonNull(platform$clientInstaller, "Forge initializeClient must run before client extension registration").accept((net.minecraftforge.client.extensions.common.IClientBlockExtensions) extension);
    }

    @Override
    public InteractionResult use(BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
        ItemUseResult result = (switch(0) {
            default ->
                {
                    net.minecraft.world.item.ItemStack native$bodyOperand$4662 = player.getItemInHand(hand);
                    net.minecraft.world.level.block.state.BlockState native$bodyOperand$4663 = state;
                    net.minecraft.world.level.Level native$bodyOperand$4664 = level;
                    net.minecraft.core.BlockPos native$bodyOperand$4665 = pos;
                    net.minecraft.world.entity.player.Player native$bodyOperand$4666 = player;
                    net.minecraft.world.InteractionHand native$bodyOperand$4667 = hand;
                    net.minecraft.world.phys.BlockHitResult native$bodyOperand$4668 = hit;
                    dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult native$bodyResult$4669 = null;
                    native$bodyReturn$4670: {
                        if (true) {
                            {
                                native$bodyResult$4669 = dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
                                break native$bodyReturn$4670;
                            }
                        }
                    }
                    yield native$bodyResult$4669;
                }
        });
        return result == ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION ? (hand == InteractionHand.MAIN_HAND ? (switch(0) {
            default ->
                {
                    net.minecraft.world.level.block.state.BlockState native$bodyOperand$3822 = state;
                    net.minecraft.world.level.Level native$bodyOperand$3823 = level;
                    net.minecraft.core.BlockPos native$bodyOperand$3824 = pos;
                    net.minecraft.world.entity.player.Player native$bodyOperand$3825 = player;
                    net.minecraft.world.phys.BlockHitResult native$bodyOperand$3826 = hit;
                    net.minecraft.world.InteractionResult native$bodyResult$3827 = null;
                    native$bodyReturn$3828: {
                        if (true) {
                            {
                                native$bodyResult$3827 = super.use(native$bodyOperand$3822, native$bodyOperand$3823, native$bodyOperand$3824, native$bodyOperand$3825, net.minecraft.world.InteractionHand.MAIN_HAND, native$bodyOperand$3826);
                                break native$bodyReturn$3828;
                            }
                        }
                    }
                    yield native$bodyResult$3827;
                }
        }) : InteractionResult.PASS) : result.result();
    }

    protected ItemUseResult interactWithItem(ItemStack stack, BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
        return dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
    }

    protected InteractionResult interactWithoutItem(BlockState state, Level level, BlockPos pos, Player player, BlockHitResult hit) {
        return super.use(state, level, pos, player, net.minecraft.world.InteractionHand.MAIN_HAND, hit);
    }

    @Override
    public void playerWillDestroy(Level level, BlockPos pos, BlockState state, Player player) {
        {
            net.minecraft.world.level.Level native$bodyOperand$5974 = level;
            net.minecraft.core.BlockPos native$bodyOperand$5975 = pos;
            net.minecraft.world.level.block.state.BlockState native$bodyOperand$5976 = state;
            net.minecraft.world.entity.player.Player native$bodyOperand$5977 = player;
            net.minecraft.world.level.block.state.BlockState native$bodyResult$5978 = null;
            native$bodyReturn$5979: {
                if (true) {
                    super.playerWillDestroy(native$bodyOperand$5974, native$bodyOperand$5975, native$bodyOperand$5976, native$bodyOperand$5977);
                    {
                        native$bodyResult$5978 = native$bodyOperand$5976;
                        break native$bodyReturn$5979;
                    }
                }
            }
        }
    }

    public BlockState beforePlayerDestroy(Level level, BlockPos pos, BlockState state, Player player) {
        super.playerWillDestroy(level, pos, state, player);
        return state;
    }

    protected boolean survivesSharedExplosion() {
        return false;
    }

    public int getExpDrop(net.minecraft.world.level.block.state.BlockState native$callbackInput$1050, net.minecraft.world.level.LevelReader native$callbackInput$1051, net.minecraft.util.RandomSource native$callbackInput$1052, net.minecraft.core.BlockPos native$callbackInput$1053, int native$callbackInput$1054, int native$callbackInput$1055) {
        net.minecraft.world.level.block.state.BlockState state = native$callbackInput$1050;
        net.minecraft.util.RandomSource random = native$callbackInput$1052;
        return 0;
    }

    @Override
    public void onBlockExploded(BlockState state, Level level, BlockPos pos, Explosion explosion) {
        if (!(switch(0) {
            default ->
                {
                    boolean native$bodyResult$5307 = false;
                    native$bodyReturn$5308: {
                        if (true) {
                            {
                                native$bodyResult$5307 = false;
                                break native$bodyReturn$5308;
                            }
                        }
                    }
                    yield native$bodyResult$5307;
                }
        }))
            super.onBlockExploded(state, level, pos, explosion);
    }

    @Override
    public boolean canDropFromExplosion(BlockState state, BlockGetter level, BlockPos pos, Explosion explosion) {
        return !(switch(0) {
            default ->
                {
                    boolean native$bodyResult$4671 = false;
                    native$bodyReturn$4672: {
                        if (true) {
                            {
                                native$bodyResult$4671 = false;
                                break native$bodyReturn$4672;
                            }
                        }
                    }
                    yield native$bodyResult$4671;
                }
        }) && super.canDropFromExplosion(state, level, pos, explosion);
    }

    static private <B extends net.minecraft.world.level.block.Block> com.mojang.serialization.MapCodec<B> native$BlockCodecPlatform$simple(java.util.function.Function<net.minecraft.world.level.block.state.BlockBehaviour.Properties, B> factory) {
        // Vanilla 1.21's Properties codec is a unit codec. Retain that schema for shared block definitions.
        return com.mojang.serialization.codecs.RecordCodecBuilder.mapCodec(instance -> instance.group(com.mojang.serialization.Codec.unit(net.minecraft.world.level.block.state.BlockBehaviour.Properties::of).fieldOf("properties").forGetter((B block) -> net.minecraft.world.level.block.state.BlockBehaviour.Properties.copy(block))).apply(instance, factory));
    }
}
