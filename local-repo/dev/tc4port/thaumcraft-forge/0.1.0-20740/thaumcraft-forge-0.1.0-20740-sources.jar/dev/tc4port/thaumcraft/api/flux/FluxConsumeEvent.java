package dev.tc4port.thaumcraft.api.flux;

import dev.tc4port.thaumcraft.api.aspect.VisAction;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.block.state.BlockState;

/**
 * Cancellable protection hook fired in both transaction phases. Listeners
 * must make the same permission decision in each phase and must not mutate
 * state while {@link #action()} is SIMULATE.
 */
@net.minecraftforge.eventbus.api.Cancelable()
public final class FluxConsumeEvent extends net.minecraftforge.eventbus.api.Event {

    private final ServerLevel level;

    private final BlockPos position;

    private final BlockState state;

    private final int quanta;

    private final FluxConsumeContext context;

    private final VisAction action;

    public FluxConsumeEvent(ServerLevel level, BlockPos position, BlockState state, int quanta, FluxConsumeContext context, VisAction action) {
        this.level = level;
        this.position = position.immutable();
        this.state = state;
        this.quanta = quanta;
        this.context = context;
        this.action = action;
    }

    public ServerLevel level() {
        return this.level;
    }

    public BlockPos position() {
        return this.position;
    }

    public BlockState state() {
        return this.state;
    }

    public int quanta() {
        return this.quanta;
    }

    public FluxConsumeContext context() {
        return this.context;
    }

    public VisAction action() {
        return this.action;
    }
}
