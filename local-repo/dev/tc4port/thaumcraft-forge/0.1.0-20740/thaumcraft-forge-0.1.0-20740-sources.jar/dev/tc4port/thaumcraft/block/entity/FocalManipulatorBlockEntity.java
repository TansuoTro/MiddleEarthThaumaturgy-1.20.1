package dev.tc4port.thaumcraft.block.entity;

import dev.tc4port.thaumcraft.common.TCGameplayParameters;
import dev.tc4port.thaumcraft.api.aspect.AspectId;
import dev.tc4port.thaumcraft.api.aspect.VisChannel;
import dev.tc4port.thaumcraft.api.focus.FocusUpgradeDefinition;
import dev.tc4port.thaumcraft.api.focus.FocusUpgradeId;
import dev.tc4port.thaumcraft.common.FocusUpgradeCatalog;
import dev.tc4port.thaumcraft.common.VisNetwork;
import dev.tc4port.thaumcraft.api.focus.FocusIdentityItem;
import dev.tc4port.thaumcraft.common.FocusStacks;
import dev.tc4port.thaumcraft.api.focus.FocusStateView;
import dev.tc4port.thaumcraft.menu.FocalManipulatorMenu;
import dev.tc4port.thaumcraft.registry.TCBlockEntities;
import dev.tc4port.thaumcraft.registry.TCParticles;
import dev.tc4port.thaumcraft.registry.TCSounds;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.Nullable;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.HolderLookup;
import net.minecraft.core.NonNullList;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.Tag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.WorldlyContainer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.state.BlockState;
import java.lang.Math;
import net.minecraft.world.level.block.entity.BaseContainerBlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityType;

/**
 * One-slot, VisNet-powered implementation of TileFocalManipulator.
 */
public final class FocalManipulatorBlockEntity extends net.minecraft.world.level.block.entity.BaseContainerBlockEntity implements WorldlyContainer {

    public static final int INPUT_SLOT = 0;

    public static final int CONTAINER_SIZE = 1;

    private NonNullList<ItemStack> items = NonNullList.withSize(CONTAINER_SIZE, ItemStack.EMPTY);

    private Map<VisChannel, Integer> remainingAspects = Map.of();

    private int initialSize;

    @Nullable
    private FocusUpgradeId selectedUpgrade;

    private int rank = -1;

    private int ticks;

    public FocalManipulatorBlockEntity(BlockPos pos, BlockState state) {
        super(TCBlockEntities.FOCAL_MANIPULATOR.get(), pos, state);
    }

    public static void serverTick(net.minecraft.world.level.Level level, BlockPos pos, BlockState state, FocalManipulatorBlockEntity table) {
        if (!(level instanceof ServerLevel serverLevel)) {
            return;
        }
        if (table.rank < 0) {
            table.rank = 0;
        }
        table.ticks++;
        if (table.ticks % TCGameplayParameters.MACHINES_FOCAL_MANIPULATOR_WORK_INTERVAL.intValue() != 0 || table.initialSize <= 0) {
            return;
        }
        FocusUpgradeDefinition selected = FocusUpgradeCatalog.byId(table.selectedUpgrade);
        if (selected == null) {
            table.initialSize = 0;
            table.rank = -1;
            table.remainingAspects = Map.of();
            table.play(TCSounds.CRAFT_FAIL.get(), 0.33F);
            table.changedAndSync();
            return;
        }
        if (table.remainingTotal() <= 0 || table.items.get(INPUT_SLOT).isEmpty()) {
            table.play(TCSounds.CRAFT_FAIL.get(), 0.33F);
            table.initialSize = 0;
            table.rank = -1;
            table.selectedUpgrade = null;
            table.remainingAspects = Map.of();
            table.changedAndSync();
            return;
        }
        boolean complete = false;
        boolean drainedAny = false;
        if (table.initialSize > 0) {
            LinkedHashMap<VisChannel, Integer> changed = new LinkedHashMap<>(table.remainingAspects);
            List<Map.Entry<VisChannel, Integer>> drainOrder = table.remainingAspects.entrySet().stream()./*
                             * AspectList's old bubble sort was stable when
                             * amounts tied, so preserve insertion order.
                             */
            sorted(Map.Entry.<VisChannel, Integer>comparingByValue().reversed()).toList();
            for (Map.Entry<VisChannel, Integer> entry : drainOrder) {
                int amount = changed.getOrDefault(entry.getKey(), 0);
                int drained = VisNetwork.drain(serverLevel, pos, entry.getKey(), Math.min(TCGameplayParameters.MACHINES_FOCAL_MANIPULATOR_MAXIMUM_VIS_REQUEST.intValue(), amount));
                if (drained > 0) {
                    changed.put(entry.getKey(), amount - drained);
                    drainedAny = true;
                }
            }
            table.remainingAspects = orderedMap(changed);
            if (table.remainingTotal() <= 0 && !table.items.get(INPUT_SLOT).isEmpty()) {
                complete = true;
                if (table.items.get(INPUT_SLOT).getItem() instanceof FocusIdentityItem) {
                    ItemStack before = table.items.get(INPUT_SLOT);
                    int beforeSlots = FocusStacks.state(before).map(stateView -> stateView.upgradeSlots().size()).orElse(-1);
                    ItemStack upgraded = FocusUpgradeCatalog.apply(before, selected);
                    boolean persisted = FocusStacks.state(upgraded).map(stateView -> stateView.upgradeSlots().size() == beforeSlots + 1 && stateView.upgradeSlots().get(stateView.upgradeSlots().size() - 1).equals(selected.id())).orElse(false);
                    if (persisted) {
                        table.items.set(INPUT_SLOT, upgraded);
                    } else {
                        dev.tc4port.thaumcraft.Thaumcraft.LOGGER.error("Focus upgrade {} failed to persist at {} in {}", selected.id(), table.worldPosition, serverLevel.dimension().location());
                        table.play(TCSounds.CRAFT_FAIL.get(), 0.33F);
                        table.initialSize = 0;
                        table.rank = -1;
                        table.remainingAspects = Map.of();
                        table.changedAndSync();
                        return;
                    }
                }
                table.play(TCSounds.WAND.get(), 1.0F);
            }
        }
        if (complete) {
            table.initialSize = 0;
            table.rank = -1;
            table.remainingAspects = Map.of();
            table.changedAndSync();
        } else if (drainedAny) {
            table.changedAndSync();
        }
    }

    public static void clientTick(net.minecraft.world.level.Level level, BlockPos pos, BlockState state, FocalManipulatorBlockEntity table) {
        if (table.initialSize <= 0) {
            return;
        }
        double x = pos.getX() + 0.5 + (level.random.nextFloat() - level.random.nextFloat()) * 0.3F;
        double y = pos.getY() + 1.25 + (level.random.nextFloat() - level.random.nextFloat()) * 0.3F;
        double z = pos.getZ() + 0.5 + (level.random.nextFloat() - level.random.nextFloat()) * 0.3F;
        float red = 0.5F + level.random.nextFloat() * 0.4F;
        float green = 1.0F - level.random.nextFloat() * 0.4F;
        float blue = 1.0F - level.random.nextFloat() * 0.4F;
        /*
         * TC4's private ParticleEngine did not apply vanilla's distance
         * gate; the only cap was its 2,000-particle FIFO.
         */
        level.addAlwaysVisibleParticle(TCParticles.FOCAL_MANIPULATOR_SPARKLE.get(), x, y, z, red, green, blue);
    }

    public boolean startCraft(FocusUpgradeId upgradeId, Player player) {
        ItemStack focus = this.items.get(INPUT_SLOT);
        if (this.initialSize > 0 || !(focus.getItem() instanceof FocusIdentityItem) || FocusStacks.state(focus).isEmpty()) {
            return false;
        }
        int catalogRank = FocusUpgradeCatalog.nextRank(focus);
        /*
         * The legacy method assigned rank before any validation. A full
         * five-slot focus therefore briefly held rank six even though no
         * upgrade could start.
         */
        int nextRank = catalogRank < 1 ? 6 : catalogRank;
        this.rank = nextRank;
        if (catalogRank < 1) {
            return false;
        }
        FocusUpgradeDefinition upgrade = FocusUpgradeCatalog.byId(upgradeId);
        if (upgrade == null || !FocusUpgradeCatalog.canApply(focus, player, upgrade, nextRank)) {
            return false;
        }
        int xp = upgrade.rankXp().get(nextRank - 1);
        if (player.experienceLevel < xp)
            return false;
        FocusStateView before = FocusStacks.state(focus).orElse(null);
        if (before == null) {
            return false;
        }
        java.util.ArrayList<FocusUpgradeId> candidateSlots = new java.util.ArrayList<>(before.upgradeSlots());
        candidateSlots.add(upgrade.id());
        try {
            FocusStacks.withState(focus, new FocusStateView(before.focusId(), candidateSlots, before.properties()));
        } catch (RuntimeException exception) {
            dev.tc4port.thaumcraft.Thaumcraft.LOGGER.error("Focus {} cannot persist upgrade {} at {} in {}", before.focusId(), upgrade.id(), this.worldPosition, this.level == null ? "unknown" : this.level.dimension().location(), exception);
            return false;
        }
        this.remainingAspects = orderedMap(FocusUpgradeCatalog.primalCost(upgrade, nextRank));
        this.initialSize = this.remainingTotal();
        this.selectedUpgrade = upgrade.id();
        if (!player.isCreative()) {
            player.giveExperienceLevels(-xp);
        }
        this.changedAndSync();
        if (this.level != null) {
            this.level.playSound(null, this.worldPosition, TCSounds.CRAFT_START.get(), SoundSource.BLOCKS, 0.25F, 1.0F);
        }
        return true;
    }

    private void play(net.minecraft.sounds.SoundEvent sound, float volume) {
        if (this.level != null) {
            this.level.playSound(null, this.worldPosition, sound, SoundSource.BLOCKS, volume, 1.0F);
        }
    }

    public Map<VisChannel, Integer> remainingAspects() {
        return this.remainingAspects;
    }

    public int initialSize() {
        return initialSize;
    }

    @Nullable
    public FocusUpgradeId selectedUpgrade() {
        return selectedUpgrade;
    }

    public int rank() {
        return rank;
    }

    public int remainingTotal() {
        long total = 0L;
        for (int value : this.remainingAspects.values()) {
            total = Math.min(Integer.MAX_VALUE, total + Math.max(0L, value));
        }
        return (int) total;
    }

    private void changedAndSync() {
        super.setChanged();
        BlockEntitySync.sendToClient(this);
    }

    public void setItem(int slot, ItemStack stack) {
        {
            int native$bodyOperand$6159 = slot;
            net.minecraft.world.item.ItemStack native$bodyOperand$6160 = stack;
            native$bodyReturn$6163: {
                if (true) {
                    getItems().set(native$bodyOperand$6159, native$bodyOperand$6160);
                    int native$bodyBinding$6161 = java.lang.Math.min(getMaxStackSize(), native$bodyOperand$6160.getMaxStackSize());
                    if (native$bodyOperand$6160.getCount() > native$bodyBinding$6161)
                        native$bodyOperand$6160.setCount(native$bodyBinding$6161);
                    setChanged();
                }
            }
        }
        // TileFocalManipulator cleared its remaining aspect list whenever
        // the synchronized focus slot changed. An in-progress job therefore
        // fails on the next five-tick check instead of upgrading a new item.
        if (this.level == null || !this.level.isClientSide) {
            this.remainingAspects = Map.of();
        }
        this.changedAndSync();
    }

    @Override
    public boolean canPlaceItem(int slot, ItemStack stack) {
        return slot == INPUT_SLOT && stack.getItem() instanceof FocusIdentityItem && FocusStacks.state(stack).isPresent();
    }

    @Override
    public int[] getSlotsForFace(Direction side) {
        return new int[] { INPUT_SLOT };
    }

    @Override
    public boolean canPlaceItemThroughFace(int slot, ItemStack stack, Direction side) {
        return this.canPlaceItem(slot, stack);
    }

    @Override
    public boolean canTakeItemThroughFace(int slot, ItemStack stack, Direction side) {
        return slot == INPUT_SLOT;
    }

    @Override
    public int getMaxStackSize() {
        return 1;
    }

    @Override
    public int getContainerSize() {
        return CONTAINER_SIZE;
    }

    @Override
    protected Component getDefaultName() {
        return Component.translatable("container.thaumcraft.focal_manipulator");
    }

    protected NonNullList<ItemStack> getItems() {
        return items;
    }

    protected void setItems(NonNullList<ItemStack> items) {
        this.items = items;
    }

    @Override
    public void load(CompoundTag tag) {
        HolderLookup.Provider registries = persistenceRegistries();
        super.load(tag);
        this.items = NonNullList.withSize(CONTAINER_SIZE, ItemStack.EMPTY);
        {
            net.minecraft.nbt.CompoundTag native$operand$14356 = tag;
            net.minecraft.core.NonNullList<net.minecraft.world.item.ItemStack> native$operand$14357 = this.items;
            net.minecraft.core.HolderLookup.Provider native$operand$14358 = registries;
            net.minecraft.world.ContainerHelper.loadAllItems(native$operand$14356, native$operand$14357);
        }
        this.remainingAspects = readMap(tag.getCompound("Aspects"));
        this.initialSize = tag.getInt("size");
        this.selectedUpgrade = null;
        if (tag.contains("upgrade_id", Tag.TAG_STRING)) {
            try {
                this.selectedUpgrade = FocusUpgradeId.of(net.minecraft.resources.ResourceLocation.parse((java.lang.String) (tag.getString("upgrade_id"))));
            } catch (RuntimeException ignored) {
                this.selectedUpgrade = null;
            }
        }
        this.rank = tag.getInt("rank");
        // ticks was not persisted by the original tile.
        this.ticks = 0;
    }

    @Override
    protected void saveAdditional(CompoundTag tag) {
        HolderLookup.Provider registries = persistenceRegistries();
        super.saveAdditional(tag);
        {
            net.minecraft.nbt.CompoundTag native$operand$14359 = tag;
            net.minecraft.core.NonNullList<net.minecraft.world.item.ItemStack> native$operand$14360 = this.items;
            net.minecraft.core.HolderLookup.Provider native$operand$14361 = registries;
            net.minecraft.nbt.CompoundTag native$result$14362 = (net.minecraft.world.ContainerHelper.saveAllItems(native$operand$14359, native$operand$14360));
        }
        tag.put("Aspects", writeMap(this.remainingAspects));
        tag.putInt("size", this.initialSize);
        if (this.selectedUpgrade != null) {
            tag.putString("upgrade_id", this.selectedUpgrade.value().toString());
        }
        tag.putInt("rank", this.rank);
    }

    @Override
    public CompoundTag getUpdateTag() {
        return this.saveWithoutMetadata();
    }

    @Override
    public Packet<ClientGamePacketListener> getUpdatePacket() {
        return ClientboundBlockEntityDataPacket.create(this);
    }

    @Override
    protected AbstractContainerMenu createMenu(int containerId, Inventory inventory) {
        // Vanilla spectator opening bypasses our extra-data menu transport.
        if (inventory.player.isSpectator()) {
            return null;
        }
        return new FocalManipulatorMenu(containerId, inventory, this);
    }

    private static Map<VisChannel, Integer> readMap(CompoundTag tag) {
        LinkedHashMap<VisChannel, Integer> result = new LinkedHashMap<>();
        for (String key : tag.getAllKeys()) {
            int amount = tag.getInt(key);
            if (amount >= 0) {
                VisChannel.fromAspectId(AspectId.parse(key)).ifPresent(channel -> result.put(channel, amount));
            }
        }
        return orderedMap(result);
    }

    private static CompoundTag writeMap(Map<VisChannel, Integer> values) {
        CompoundTag tag = new CompoundTag();
        values.forEach((channel, amount) -> tag.putInt(channel.aspectId().serialized(), amount));
        return tag;
    }

    private static Map<VisChannel, Integer> orderedMap(Map<VisChannel, Integer> values) {
        return Collections.unmodifiableMap(new LinkedHashMap<>(values));
    }

    protected final HolderLookup.Provider persistenceRegistries() {
        if (level != null)
            return level.registryAccess();
        var server = net.minecraftforge.server.ServerLifecycleHooks.getCurrentServer();
        return server != null ? server.registryAccess() : net.minecraft.core.RegistryAccess.fromRegistryOfRegistries(net.minecraft.core.registries.BuiltInRegistries.REGISTRY);
    }

    protected static net.minecraft.network.chat.Component parseCustomNameSafe(String value, HolderLookup.Provider registries) {
        try {
            return net.minecraft.network.chat.Component.Serializer.fromJson(value);
        } catch (RuntimeException exception) {
            return null;
        }
    }

    @Override
    public boolean isEmpty() {
        return (switch(0) {
            default ->
                {
                    net.minecraft.core.NonNullList<net.minecraft.world.item.ItemStack> native$bodyResult$4858 = null;
                    native$bodyReturn$4859: {
                        if (true) {
                            {
                                native$bodyResult$4858 = items;
                                break native$bodyReturn$4859;
                            }
                        }
                    }
                    yield native$bodyResult$4858;
                }
        }).stream().allMatch(ItemStack::isEmpty);
    }

    @Override
    public ItemStack getItem(int index) {
        return (switch(0) {
            default ->
                {
                    net.minecraft.core.NonNullList<net.minecraft.world.item.ItemStack> native$bodyResult$5379 = null;
                    native$bodyReturn$5380: {
                        if (true) {
                            {
                                native$bodyResult$5379 = items;
                                break native$bodyReturn$5380;
                            }
                        }
                    }
                    yield native$bodyResult$5379;
                }
        }).get(index);
    }

    @Override
    public ItemStack removeItem(int index, int count) {
        ItemStack removed = net.minecraft.world.ContainerHelper.removeItem((switch(0) {
            default ->
                {
                    net.minecraft.core.NonNullList<net.minecraft.world.item.ItemStack> native$bodyResult$3957 = null;
                    native$bodyReturn$3958: {
                        if (true) {
                            {
                                native$bodyResult$3957 = items;
                                break native$bodyReturn$3958;
                            }
                        }
                    }
                    yield native$bodyResult$3957;
                }
        }), index, count);
        if (!removed.isEmpty())
            setChanged();
        return removed;
    }

    @Override
    public ItemStack removeItemNoUpdate(int index) {
        return net.minecraft.world.ContainerHelper.takeItem((switch(0) {
            default ->
                {
                    net.minecraft.core.NonNullList<net.minecraft.world.item.ItemStack> native$bodyResult$5381 = null;
                    native$bodyReturn$5382: {
                        if (true) {
                            {
                                native$bodyResult$5381 = items;
                                break native$bodyReturn$5382;
                            }
                        }
                    }
                    yield native$bodyResult$5381;
                }
        }), index);
    }

    @Override
    public void clearContent() {
        (switch(0) {
            default ->
                {
                    net.minecraft.core.NonNullList<net.minecraft.world.item.ItemStack> native$bodyResult$5383 = null;
                    native$bodyReturn$5384: {
                        if (true) {
                            {
                                native$bodyResult$5383 = items;
                                break native$bodyReturn$5384;
                            }
                        }
                    }
                    yield native$bodyResult$5383;
                }
        }).clear();
    }

    @Override
    public boolean stillValid(net.minecraft.world.entity.player.Player player) {
        return net.minecraft.world.Container.stillValidBlockEntity(this, player);
    }

    @Override
    public net.minecraft.world.phys.AABB getRenderBoundingBox() {
        return FocalManipulatorBlockEntity.native$ClientBlockEntityBounds$bounds(this);
    }

    @Override()
    public void onDataPacket(net.minecraft.network.Connection connection, net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket packet) {
        handleUpdateTag(packet.getTag());
    }

    @SuppressWarnings({ "rawtypes", "unchecked" })
    static private net.minecraft.world.phys.AABB native$ClientBlockEntityBounds$bounds(net.minecraft.world.level.block.entity.BlockEntity blockEntity) {
        var renderer = net.minecraft.client.Minecraft.getInstance().getBlockEntityRenderDispatcher().getRenderer(blockEntity);
        return renderer instanceof dev.tc4port.thaumcraft.nativeimpl.NativeBlockEntityRenderer shared ? shared.getRenderBoundingBox(blockEntity) : new net.minecraft.world.phys.AABB(blockEntity.getBlockPos());
    }

    private boolean native$capabilitiesInvalid$17009;

    public boolean native$capabilityActive$16840;

    private java.util.Map<net.minecraft.core.Direction, net.minecraftforge.common.util.LazyOptional<net.minecraftforge.items.IItemHandler>> native$capabilityHandle$16841;

    @Override
    public <native$capabilityResultType$17010> net.minecraftforge.common.util.LazyOptional<native$capabilityResultType$17010> getCapability(net.minecraftforge.common.capabilities.Capability<native$capabilityResultType$17010> native$requestedCapability$17011, net.minecraft.core.Direction native$requestedFace$17012) {
        getCapabilities();
        synchronized (this) {
            if (native$capabilitiesInvalid$17009)
                return net.minecraftforge.common.util.LazyOptional.empty();
            if (native$capabilityActive$16840 && native$requestedCapability$17011 == (net.minecraftforge.common.capabilities.ForgeCapabilities.ITEM_HANDLER)) {
                if (native$capabilityHandle$16841 == null)
                    native$capabilityHandle$16841 = new java.util.HashMap<>();
                net.minecraftforge.common.util.LazyOptional<net.minecraftforge.items.IItemHandler> native$capabilityResult$17014 = native$capabilityHandle$16841.computeIfAbsent(native$requestedFace$17012, native$capabilityFace$16842 -> {
                    net.minecraftforge.items.IItemHandler native$endpoint$256 = (switch(0) {
                        default ->
                            {
                                net.minecraft.world.WorldlyContainer native$operand$12776 = dev.tc4port.thaumcraft.block.entity.FocalManipulatorBlockEntity.this;
                                net.minecraft.core.Direction native$operand$12777 = native$capabilityFace$16842;
                                net.minecraftforge.items.IItemHandler native$result$12778 = (new net.minecraftforge.items.wrapper.SidedInvWrapper(native$operand$12776, native$operand$12777));
                                yield native$result$12778;
                            }
                    });
                    return native$endpoint$256 == null ? net.minecraftforge.common.util.LazyOptional.empty() : net.minecraftforge.common.util.LazyOptional.of(() -> native$endpoint$256);
                });
                if (native$capabilityResult$17014.isPresent())
                    return native$capabilityResult$17014.cast();
            }
        }
        return super.getCapability(native$requestedCapability$17011, native$requestedFace$17012);
    }

    @Override
    public void invalidateCaps() {
        java.util.List<net.minecraftforge.common.util.LazyOptional<?>> native$expiredCapabilities$17013 = new java.util.ArrayList<>();
        synchronized (this) {
            native$capabilitiesInvalid$17009 = true;
            if (native$capabilityHandle$16841 != null) {
                native$expiredCapabilities$17013.addAll(native$capabilityHandle$16841.values());
                native$capabilityHandle$16841 = null;
            }
        }
        try {
            super.invalidateCaps();
        } finally {
            native$expiredCapabilities$17013.forEach(net.minecraftforge.common.util.LazyOptional::invalidate);
        }
    }

    @Override
    public void reviveCaps() {
        super.reviveCaps();
        synchronized (this) {
            native$capabilitiesInvalid$17009 = false;
        }
    }
}
