package dev.tc4port.thaumcraft.api.focus;

import com.mojang.serialization.Codec;
import com.mojang.serialization.DataResult;
import java.util.Objects;
import net.minecraft.resources.ResourceLocation;

/**
 * Stable namespaced identity of one built-in focus behavior profile.
 */
public record FocusId(ResourceLocation value) {

    public static final int MAX_LENGTH = 256;

    public static final Codec<FocusId> CODEC = Codec.STRING.comapFlatMap(value -> {
        try {
            return DataResult.success(parse(value));
        } catch (IllegalArgumentException exception) {
            return DataResult.error(exception::getMessage);
        }
    }, FocusId::serialized);

    public FocusId {
        Objects.requireNonNull(value, "value");
        if (value.getPath().isEmpty() || value.toString().length() > MAX_LENGTH) {
            throw new IllegalArgumentException("Focus ID must have a non-empty path and at most " + MAX_LENGTH + " characters");
        }
    }

    public static FocusId of(ResourceLocation value) {
        return new FocusId(value);
    }

    public static FocusId parse(String value) {
        if (value == null || value.isBlank()) {
            throw new IllegalArgumentException("Focus ID must not be blank");
        }
        ResourceLocation parsed = value.indexOf(':') >= 0 ? ResourceLocation.tryParse(value) : ResourceLocation.tryBuild("thaumcraft", value);
        if (parsed == null) {
            throw new IllegalArgumentException("Invalid focus ID " + value);
        }
        return new FocusId(parsed);
    }

    /**
     * Canonical persisted form; core IDs retain their TC4 bare spelling.
     */
    public String serialized() {
        return this.value.getNamespace().equals("thaumcraft") ? this.value.getPath() : this.value.toString();
    }

    @Override
    public String toString() {
        return this.value.toString();
    }
}
