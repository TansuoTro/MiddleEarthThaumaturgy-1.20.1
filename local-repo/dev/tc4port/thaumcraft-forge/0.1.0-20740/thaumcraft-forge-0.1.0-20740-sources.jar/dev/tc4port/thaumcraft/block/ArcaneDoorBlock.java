package dev.tc4port.thaumcraft.block;

import com.mojang.serialization.MapCodec;
import dev.tc4port.thaumcraft.block.entity.ArcaneDoorBlockEntity;
import dev.tc4port.thaumcraft.block.entity.ArcanePressurePlateBlockEntity;
import dev.tc4port.thaumcraft.common.TCServerConfig;
import dev.tc4port.thaumcraft.registry.TCBlocks;
import dev.tc4port.thaumcraft.registry.TCItems;
import dev.tc4port.thaumcraft.registry.TCSounds;
import java.util.Set;
import java.util.UUID;
import javax.annotation.Nullable;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Explosion;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.DoorBlock;
import net.minecraft.world.level.block.EntityBlock;
import net.minecraft.world.level.block.LevelEvent;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.BlockSetType;
import net.minecraft.world.level.block.state.properties.DoubleBlockHalf;
import net.minecraft.world.level.gameevent.GameEvent;
import net.minecraft.world.phys.BlockHitResult;
import dev.tc4port.thaumcraft.nativeimpl.ClientExtensionTarget;
import dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.level.pathfinder.PathComputationType;
import net.minecraft.world.phys.HitResult;
import net.minecraft.util.RandomSource;

/**
 * TC4's two-block TileOwned Arcane Door.
 *
 * <p>The vanilla door state/shape implementation supplies the source's exact
 * three-sixteenth collision plane and hinge transforms. Redstone handling is
 * deliberately replaced: the source ignored ordinary power and listened only
 * to adjacent Arcane Pressure Plates whose owner also had door access.</p>
 */
public final class ArcaneDoorBlock extends net.minecraft.world.level.block.DoorBlock implements EntityBlock, dev.tc4port.thaumcraft.nativeimpl.ClientExtensionTarget {

    // Forge calls initializeClient from the native superclass constructor. Do not add a field initializer.
    private java.util.function.Consumer<net.minecraftforge.client.extensions.common.IClientBlockExtensions> platform$clientInstaller;

    public static final MapCodec<ArcaneDoorBlock> CODEC = ArcaneDoorBlock.native$BlockCodecPlatform$simple(ArcaneDoorBlock::new);

    private static final Direction[] PLATE_SEARCH_ORDER = { Direction.NORTH, Direction.SOUTH, Direction.WEST, Direction.EAST };

    public ArcaneDoorBlock(BlockBehaviour.Properties properties) {
        this(BlockSetType.IRON, properties, properties, true);
    }

    public MapCodec<ArcaneDoorBlock> codec() {
        return CODEC;
    }

    @Nullable
    @Override
    public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        return new ArcaneDoorBlockEntity(pos, state);
    }

    @Nullable
    @Override
    public BlockState getStateForPlacement(BlockPlaceContext context) {
        BlockState state = super.getStateForPlacement(context);
        return state == null ? null : state.setValue(POWERED, false).setValue(OPEN, false);
    }

    @Override
    public void setPlacedBy(Level level, BlockPos pos, BlockState state, @Nullable LivingEntity placer, ItemStack stack) {
        super.setPlacedBy(level, pos, state, placer, stack);
        if (!(placer instanceof Player player)) {
            return;
        }
        if (level.getBlockEntity(pos) instanceof ArcaneDoorBlockEntity lower) {
            lower.setOwner(player);
        }
        if (level.getBlockEntity(pos.above()) instanceof ArcaneDoorBlockEntity upper) {
            upper.setOwner(player);
        }
    }

    protected InteractionResult interactWithoutItem(BlockState state, Level level, BlockPos pos, Player player, BlockHitResult hitResult) {
        if (level.isClientSide) {
            return net.minecraft.world.InteractionResult.SUCCESS;
        }
        dev.tc4port.thaumcraft.block.entity.ArcaneDoorBlockEntity door = ownedAt(level, pos);
        if (door == null || !door.isAuthorized(player)) {
            player.sendSystemMessage(net.minecraft.network.chat.Component.literal("The door refuses to budge."));
            level.playSound(null, pos, dev.tc4port.thaumcraft.registry.TCSounds.DOOR_FAIL.get(), net.minecraft.sounds.SoundSource.BLOCKS, 0.66F, 1.0F);
            return net.minecraft.world.InteractionResult.CONSUME;
        }
        net.minecraft.core.BlockPos lowerPos = door.lowerPos();
        net.minecraft.world.level.block.state.BlockState lower = level.getBlockState(lowerPos);
        setDoorOpen(level, lowerPos, !lower.getValue(net.minecraft.world.level.block.DoorBlock.OPEN), player);
        return net.minecraft.world.InteractionResult.CONSUME;
    }

    @Override
    public void neighborChanged(BlockState state, Level level, BlockPos pos, Block neighborBlock, BlockPos neighborPos, boolean movedByPiston) {
        /*
         * Do not invoke DoorBlock.neighborChanged: TC4 Arcane Doors do not
         * react to vanilla redstone. Structural half/support cleanup remains
         * supplied by DoorBlock.updateShape.
         */
        if (!level.isClientSide && neighborBlock == TCBlocks.ARCANE_PRESSURE_PLATE.get()) {
            BlockPos lowerPos = state.getValue(HALF) == DoubleBlockHalf.UPPER ? pos.below() : pos;
            updateFromAdjacentPlates(level, lowerPos);
        }
    }

    private static void updateFromAdjacentPlates(Level level, BlockPos lowerPos) {
        if (!(level.getBlockEntity(lowerPos) instanceof ArcaneDoorBlockEntity door)) {
            return;
        }
        Set<UUID> doorUsers = door.authorizedPlayerIds();
        boolean matchingReleasedPlate = false;
        for (Direction direction : PLATE_SEARCH_ORDER) {
            BlockPos platePos = lowerPos.relative(direction);
            BlockState plateState = level.getBlockState(platePos);
            if (!plateState.is(TCBlocks.ARCANE_PRESSURE_PLATE.get()) || !(level.getBlockEntity(platePos) instanceof ArcanePressurePlateBlockEntity plate) || doorUsers.stream().noneMatch(plate::isOwner)) {
                continue;
            }
            if (plateState.getValue(ArcanePressurePlateBlock.POWERED)) {
                setDoorOpen(level, lowerPos, true, null);
                return;
            }
            matchingReleasedPlate = true;
        }
        if (matchingReleasedPlate) {
            setDoorOpen(level, lowerPos, false, null);
        }
    }

    public static void setDoorOpen(Level level, BlockPos lowerPos, boolean open, @Nullable Entity source) {
        BlockState lower = level.getBlockState(lowerPos);
        if (!(lower.getBlock() instanceof ArcaneDoorBlock) || lower.getValue(HALF) != DoubleBlockHalf.LOWER || lower.getValue(OPEN) == open) {
            return;
        }
        BlockState upper = level.getBlockState(lowerPos.above());
        level.setBlock(lowerPos, lower.setValue(OPEN, open).setValue(POWERED, false), Block.UPDATE_CLIENTS);
        if (upper.is(lower.getBlock()) && upper.getValue(HALF) == DoubleBlockHalf.UPPER) {
            level.setBlock(lowerPos.above(), upper.setValue(OPEN, open).setValue(POWERED, false), Block.UPDATE_CLIENTS);
        }
        level.playSound(null, lowerPos, level.random.nextBoolean() ? SoundEvents.WOODEN_DOOR_OPEN : SoundEvents.WOODEN_DOOR_CLOSE, SoundSource.BLOCKS, 1.0F, level.random.nextFloat() * 0.1F + 0.9F);
        level.gameEvent(source, open ? GameEvent.BLOCK_OPEN : GameEvent.BLOCK_CLOSE, lowerPos);
    }

    @Nullable
    public static ArcaneDoorBlockEntity ownedAt(Level level, BlockPos pos) {
        return level.getBlockEntity(pos) instanceof ArcaneDoorBlockEntity door ? door : null;
    }

    public static boolean recoverWithWand(Level level, BlockPos pos, Player player) {
        ArcaneDoorBlockEntity door = ownedAt(level, pos);
        if (door == null || TCServerConfig.wardedStone() && !door.isOwner(player)) {
            return false;
        }
        if (!level.isClientSide) {
            BlockPos lowerPos = door.lowerPos();
            level.addFreshEntity(new net.minecraft.world.entity.item.ItemEntity(level, pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5, new ItemStack(TCItems.ARCANE_DOOR_ITEM.get())));
            level.levelEvent(LevelEvent.PARTICLES_DESTROY_BLOCK, pos, Block.getId(level.getBlockState(pos)));
            level.removeBlock(lowerPos.above(), false);
            level.removeBlock(lowerPos, false);
        }
        return true;
    }

    @Override
    public boolean canEntityDestroy(BlockState state, BlockGetter level, BlockPos pos, Entity entity) {
        return false;
    }

    @Override
    public float getDestroyProgress(BlockState state, Player player, BlockGetter level, BlockPos pos) {
        return TCServerConfig.wardedStone() ? 0.0F : WardedGlassBlock.destroyProgress(state, player, level, pos, 15.0F);
    }

    @Override
    public float getExplosionResistance(BlockState state, BlockGetter level, BlockPos pos, Explosion explosion) {
        /*
         * BlockArcaneDoor inherited Block's ordinary explosion query.
         * setResistance(999) stored 2997 and the query divided it by five.
         */
        return 599.4F;
    }

    protected boolean survivesSharedExplosion() {
        return true;
    }

    private ArcaneDoorBlock(net.minecraft.world.level.block.state.properties.BlockSetType native$NativeDoorBlock$arg0, net.minecraft.world.level.block.state.BlockBehaviour.Properties native$NativeDoorBlock$arg1, BlockBehaviour.Properties properties, boolean native$NativeDoorBlock$captured) {
        super(native$NativeDoorBlock$arg1, native$NativeDoorBlock$arg0);
    }

    @Override
    public void initializeClient(java.util.function.Consumer<net.minecraftforge.client.extensions.common.IClientBlockExtensions> installer) {
        platform$clientInstaller = installer;
        super.initializeClient(installer);
    }

    @Override
    public void platform$clientExtension(Object extension) {
        java.util.Objects.requireNonNull(platform$clientInstaller, "Forge initializeClient must run before client extension registration").accept((net.minecraftforge.client.extensions.common.IClientBlockExtensions) extension);
    }

    @Override
    public InteractionResult use(BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
        ItemUseResult result = (switch(0) {
            default ->
                {
                    net.minecraft.world.item.ItemStack native$bodyOperand$4123 = player.getItemInHand(hand);
                    net.minecraft.world.level.block.state.BlockState native$bodyOperand$4124 = state;
                    net.minecraft.world.level.Level native$bodyOperand$4125 = level;
                    net.minecraft.core.BlockPos native$bodyOperand$4126 = pos;
                    net.minecraft.world.entity.player.Player native$bodyOperand$4127 = player;
                    net.minecraft.world.InteractionHand native$bodyOperand$4128 = hand;
                    net.minecraft.world.phys.BlockHitResult native$bodyOperand$4129 = hit;
                    dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult native$bodyResult$4130 = null;
                    native$bodyReturn$4131: {
                        if (true) {
                            {
                                native$bodyResult$4130 = dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
                                break native$bodyReturn$4131;
                            }
                        }
                    }
                    yield native$bodyResult$4130;
                }
        });
        return result == ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION ? (hand == InteractionHand.MAIN_HAND ? (switch(0) {
            default ->
                {
                    net.minecraft.world.level.block.state.BlockState native$bodyOperand$3466 = state;
                    net.minecraft.world.level.Level native$bodyOperand$3467 = level;
                    net.minecraft.core.BlockPos native$bodyOperand$3468 = pos;
                    net.minecraft.world.entity.player.Player native$bodyOperand$3469 = player;
                    net.minecraft.world.phys.BlockHitResult native$bodyOperand$3470 = hit;
                    net.minecraft.world.InteractionResult native$bodyResult$3474 = null;
                    native$bodyReturn$3475: {
                        if (true) {
                            if (native$bodyOperand$3467.isClientSide) {
                                {
                                    native$bodyResult$3474 = net.minecraft.world.InteractionResult.SUCCESS;
                                    break native$bodyReturn$3475;
                                }
                            }
                            dev.tc4port.thaumcraft.block.entity.ArcaneDoorBlockEntity native$bodyBinding$3471 = ownedAt(native$bodyOperand$3467, native$bodyOperand$3468);
                            if (native$bodyBinding$3471 == null || !native$bodyBinding$3471.isAuthorized(native$bodyOperand$3469)) {
                                native$bodyOperand$3469.sendSystemMessage(net.minecraft.network.chat.Component.literal("The door refuses to budge."));
                                native$bodyOperand$3467.playSound(null, native$bodyOperand$3468, dev.tc4port.thaumcraft.registry.TCSounds.DOOR_FAIL.get(), net.minecraft.sounds.SoundSource.BLOCKS, 0.66F, 1.0F);
                                {
                                    native$bodyResult$3474 = net.minecraft.world.InteractionResult.CONSUME;
                                    break native$bodyReturn$3475;
                                }
                            }
                            net.minecraft.core.BlockPos native$bodyBinding$3472 = native$bodyBinding$3471.lowerPos();
                            net.minecraft.world.level.block.state.BlockState native$bodyBinding$3473 = native$bodyOperand$3467.getBlockState(native$bodyBinding$3472);
                            setDoorOpen(native$bodyOperand$3467, native$bodyBinding$3472, !native$bodyBinding$3473.getValue(net.minecraft.world.level.block.DoorBlock.OPEN), native$bodyOperand$3469);
                            {
                                native$bodyResult$3474 = net.minecraft.world.InteractionResult.CONSUME;
                                break native$bodyReturn$3475;
                            }
                        }
                    }
                    yield native$bodyResult$3474;
                }
        }) : InteractionResult.PASS) : result.result();
    }

    protected ItemUseResult interactWithItem(ItemStack stack, BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
        return dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
    }

    @Override
    public void playerWillDestroy(Level level, BlockPos pos, BlockState state, Player player) {
        {
            net.minecraft.world.level.Level native$bodyOperand$5654 = level;
            net.minecraft.core.BlockPos native$bodyOperand$5655 = pos;
            net.minecraft.world.level.block.state.BlockState native$bodyOperand$5656 = state;
            net.minecraft.world.entity.player.Player native$bodyOperand$5657 = player;
            net.minecraft.world.level.block.state.BlockState native$bodyResult$5658 = null;
            native$bodyReturn$5659: {
                if (true) {
                    super.playerWillDestroy(native$bodyOperand$5654, native$bodyOperand$5655, native$bodyOperand$5656, native$bodyOperand$5657);
                    {
                        native$bodyResult$5658 = native$bodyOperand$5656;
                        break native$bodyReturn$5659;
                    }
                }
            }
        }
    }

    public BlockState beforePlayerDestroy(Level level, BlockPos pos, BlockState state, Player player) {
        super.playerWillDestroy(level, pos, state, player);
        return state;
    }

    public int getExpDrop(net.minecraft.world.level.block.state.BlockState native$callbackInput$1044, net.minecraft.world.level.LevelReader native$callbackInput$1045, net.minecraft.util.RandomSource native$callbackInput$1046, net.minecraft.core.BlockPos native$callbackInput$1047, int native$callbackInput$1048, int native$callbackInput$1049) {
        net.minecraft.world.level.block.state.BlockState state = native$callbackInput$1044;
        net.minecraft.util.RandomSource random = native$callbackInput$1046;
        return 0;
    }

    @Override
    public void onBlockExploded(BlockState state, Level level, BlockPos pos, Explosion explosion) {
        if (!(switch(0) {
            default ->
                {
                    boolean native$bodyResult$5213 = false;
                    native$bodyReturn$5214: {
                        if (true) {
                            {
                                native$bodyResult$5213 = true;
                                break native$bodyReturn$5214;
                            }
                        }
                    }
                    yield native$bodyResult$5213;
                }
        }))
            super.onBlockExploded(state, level, pos, explosion);
    }

    @Override
    public boolean canDropFromExplosion(BlockState state, BlockGetter level, BlockPos pos, Explosion explosion) {
        return !(switch(0) {
            default ->
                {
                    boolean native$bodyResult$4132 = false;
                    native$bodyReturn$4133: {
                        if (true) {
                            {
                                native$bodyResult$4132 = true;
                                break native$bodyReturn$4133;
                            }
                        }
                    }
                    yield native$bodyResult$4132;
                }
        }) && super.canDropFromExplosion(state, level, pos, explosion);
    }

    static private <B extends net.minecraft.world.level.block.Block> com.mojang.serialization.MapCodec<B> native$BlockCodecPlatform$simple(java.util.function.Function<net.minecraft.world.level.block.state.BlockBehaviour.Properties, B> factory) {
        // Vanilla 1.21's Properties codec is a unit codec. Retain that schema for shared block definitions.
        return com.mojang.serialization.codecs.RecordCodecBuilder.mapCodec(instance -> instance.group(com.mojang.serialization.Codec.unit(net.minecraft.world.level.block.state.BlockBehaviour.Properties::of).fieldOf("properties").forGetter((B block) -> net.minecraft.world.level.block.state.BlockBehaviour.Properties.copy(block))).apply(instance, factory));
    }
}
