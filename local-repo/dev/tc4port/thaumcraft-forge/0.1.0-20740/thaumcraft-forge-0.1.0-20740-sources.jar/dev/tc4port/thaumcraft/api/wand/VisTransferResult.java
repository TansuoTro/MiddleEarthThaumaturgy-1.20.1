package dev.tc4port.thaumcraft.api.wand;

import dev.tc4port.thaumcraft.api.aspect.VisChannel;
import dev.tc4port.thaumcraft.api.aspect.VisCost;
import java.util.Collections;
import java.util.EnumMap;
import java.util.Map;
import java.util.Objects;

/**
 * Bounded result of a raw centivis transfer into or out of one owner.
 */
public record VisTransferResult(VisCost requested, Map<VisChannel, Integer> transferredCentivis, boolean mutated) {

    public VisTransferResult {
        Objects.requireNonNull(requested, "requested");
        Objects.requireNonNull(transferredCentivis, "transferredCentivis");
        EnumMap<VisChannel, Integer> checked = new EnumMap<>(VisChannel.class);
        transferredCentivis.forEach((channel, amount) -> {
            Objects.requireNonNull(channel, "channel");
            Objects.requireNonNull(amount, "amount");
            int maximum = requested.amounts().getOrDefault(channel, 0);
            if (amount < 0 || amount > maximum) {
                throw new IllegalArgumentException("Transferred vis must be within the request: " + channel);
            }
            if (amount > 0) {
                checked.put(channel, amount);
            }
        });
        transferredCentivis = Collections.unmodifiableMap(checked);
        if (mutated && checked.values().stream().noneMatch(value -> value > 0)) {
            throw new IllegalArgumentException("A mutated transfer must move at least one centivis");
        }
    }

    public int transferred(VisChannel channel) {
        return this.transferredCentivis.getOrDefault(channel, 0);
    }

    public boolean complete() {
        return this.requested.amounts().entrySet().stream().allMatch(entry -> transferred(entry.getKey()) == entry.getValue());
    }

    public static VisTransferResult none(VisCost requested) {
        return new VisTransferResult(requested, Map.of(), false);
    }
}
