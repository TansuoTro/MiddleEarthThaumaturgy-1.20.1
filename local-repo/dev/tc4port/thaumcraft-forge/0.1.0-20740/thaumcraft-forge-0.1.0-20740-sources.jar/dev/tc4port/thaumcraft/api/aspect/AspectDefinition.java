package dev.tc4port.thaumcraft.api.aspect;

import java.util.List;
import java.util.Locale;
import java.util.Objects;
import java.util.Optional;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;

/**
 * Immutable public definition of one aspect.
 *
 * <p>Every identity is a typed namespaced resource ID. Compact built-in
 * spellings are confined to internal serialization bridges.</p>
 */
public record AspectDefinition(AspectId id, int color, List<AspectId> components, ResourceLocation texture, AspectBlendMode blendMode, int naturalGenerationWeight, Optional<VisChannel> visChannel) {

    public AspectDefinition {
        id = Objects.requireNonNull(id, "id");
        if (color < 0 || color > 0xFFFFFF) {
            throw new IllegalArgumentException("Aspect color must be a 24-bit RGB value: " + color);
        }
        components = List.copyOf(Objects.requireNonNull(components, "components"));
        if (!components.isEmpty() && components.size() != 2) {
            throw new IllegalArgumentException("An aspect must have zero or two components: " + id);
        }
        if (components.size() == 2 && components.get(0).equals(components.get(1))) {
            throw new IllegalArgumentException("Aspect components must be distinct: " + id);
        }
        texture = Objects.requireNonNull(texture, "texture");
        blendMode = Objects.requireNonNull(blendMode, "blendMode");
        if (naturalGenerationWeight < 0 || naturalGenerationWeight > 1000) {
            throw new IllegalArgumentException("Aspect natural generation weight must be 0..1000: " + id);
        }
        visChannel = Objects.requireNonNull(visChannel, "visChannel");
        if (visChannel.isPresent() && !components.isEmpty()) {
            throw new IllegalArgumentException("A vis channel must be a primal aspect: " + id);
        }
    }

    public boolean primal() {
        return this.components.isEmpty();
    }

    public boolean isVisChannel() {
        return this.visChannel.isPresent();
    }

    /**
     * TC4 deliberately exposed a title-cased tag rather than a translation.
     */
    public String name() {
        String path = this.id.value().getPath();
        if (path.isEmpty()) {
            return path;
        }
        return path.substring(0, 1).toUpperCase(Locale.ROOT) + path.substring(1).toLowerCase(Locale.ROOT);
    }

    public String descriptionKey() {
        ResourceLocation key = this.id.value();
        return key.getNamespace().equals("thaumcraft") ? "tc.aspect." + key.getPath() : "aspect." + key.getNamespace() + "." + key.getPath();
    }

    public Component description() {
        return Component.translatable(this.descriptionKey());
    }
}
