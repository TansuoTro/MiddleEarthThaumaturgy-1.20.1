package dev.tc4port.thaumcraft.block.entity;

import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;

/**
 * Shared forms of the ordinary block-entity dirty/update notification.
 * Callers retain ownership of when each notification happens.
 */
final class BlockEntitySync {

    private BlockEntitySync() {
    }

    static void sendToClientAndUpdateComparator(BlockEntity entity) {
        Level level = entity.getLevel();
        if (level == null || level.isClientSide) {
            return;
        }
        level.sendBlockUpdated(entity.getBlockPos(), entity.getBlockState(), entity.getBlockState(), Block.UPDATE_CLIENTS);
        level.updateNeighbourForOutputSignal(entity.getBlockPos(), entity.getBlockState().getBlock());
    }

    static void sendToClient(BlockEntity entity) {
        Level level = entity.getLevel();
        if (level == null || level.isClientSide) {
            return;
        }
        BlockState state = entity.getBlockState();
        level.sendBlockUpdated(entity.getBlockPos(), state, state, Block.UPDATE_CLIENTS);
    }
}
