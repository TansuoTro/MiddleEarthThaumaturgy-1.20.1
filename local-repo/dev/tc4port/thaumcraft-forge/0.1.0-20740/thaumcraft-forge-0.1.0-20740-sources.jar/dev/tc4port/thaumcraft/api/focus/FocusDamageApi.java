package dev.tc4port.thaumcraft.api.focus;

import javax.annotation.Nullable;
import net.minecraft.core.Holder;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.tags.TagKey;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageType;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.Level;

/**
 * Damage classification shared by built-in and addon foci. Scaling occurs once, before defense.
 */
public final class FocusDamageApi {

    public static final TagKey<DamageType> FOCUS_DAMAGE = TagKey.create(Registries.DAMAGE_TYPE, net.minecraft.resources.ResourceLocation.fromNamespaceAndPath((java.lang.String) ("thaumcraft"), (java.lang.String) ("focus_damage")));

    public static final ResourceKey<DamageType> DIRECT = type("focus_direct");

    public static final ResourceKey<DamageType> MAGIC = type("focus_magic");

    public static final ResourceKey<DamageType> INDIRECT_MAGIC = type("focus_indirect_magic");

    public static final ResourceKey<DamageType> PROJECTILE = type("focus_projectile");

    public static final ResourceKey<DamageType> FIREBALL = type("focus_fireball");

    public static final ResourceKey<DamageType> MOB_ATTACK = type("focus_mob_attack");

    public static final ResourceKey<DamageType> EXPLOSION = type("focus_explosion");

    private FocusDamageApi() {
    }

    public static DamageSource source(LivingEntity caster, ResourceKey<DamageType> type) {
        return sourceWithModifiers(caster.level(), type, caster, caster, FocusDamageModifiers.capture(caster));
    }

    /**
     * The parameters hold the cast-time damage modifiers even if the owner changes equipment or unloads.
     */
    public static DamageSource source(Level level, ResourceKey<DamageType> type, @Nullable Entity direct, @Nullable Entity caster, @Nullable FocusParameterValues parameters) {
        return sourceWithModifiers(level, type, direct, caster, parameters == null ? FocusDamageModifiers.IDENTITY : parameters.damageModifiers());
    }

    public static DamageSource source(Level level, ResourceKey<DamageType> type, @Nullable Entity direct, @Nullable Entity caster, double multiplier) {
        return sourceWithModifiers(level, type, direct, caster, new FocusDamageModifiers(multiplier, 0));
    }

    public static DamageSource sourceWithModifiers(Level level, ResourceKey<DamageType> type, @Nullable Entity direct, @Nullable Entity caster, FocusDamageModifiers modifiers) {
        return new CastDamageSource(level.registryAccess().registryOrThrow(Registries.DAMAGE_TYPE).getHolderOrThrow(type), direct, caster, java.util.Objects.requireNonNull(modifiers));
    }

    /**
     * Addon damage types can opt in through the tag, without using a special source subclass.
     */
    public static double multiplier(DamageSource source) {
        return modifiers(source).multiplier();
    }

    public static FocusDamageModifiers modifiers(DamageSource source) {
        if (!source.is(FOCUS_DAMAGE))
            return FocusDamageModifiers.IDENTITY;
        if (source instanceof CastDamageSource cast)
            return cast.modifiers;
        return source.getEntity() instanceof LivingEntity caster ? FocusDamageModifiers.capture(caster) : FocusDamageModifiers.IDENTITY;
    }

    private static ResourceKey<DamageType> type(String path) {
        return ResourceKey.create(Registries.DAMAGE_TYPE, net.minecraft.resources.ResourceLocation.fromNamespaceAndPath((java.lang.String) ("thaumcraft"), (java.lang.String) (path)));
    }

    private static final class CastDamageSource extends DamageSource {

        private final FocusDamageModifiers modifiers;

        private CastDamageSource(Holder<DamageType> type, @Nullable Entity direct, @Nullable Entity caster, FocusDamageModifiers modifiers) {
            super(type, direct, caster);
            this.modifiers = modifiers;
        }
    }
}
