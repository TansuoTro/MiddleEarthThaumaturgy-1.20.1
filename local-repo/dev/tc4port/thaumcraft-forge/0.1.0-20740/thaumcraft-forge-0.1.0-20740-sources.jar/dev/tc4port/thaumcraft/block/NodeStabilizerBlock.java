package dev.tc4port.thaumcraft.block;

import com.mojang.serialization.MapCodec;
import dev.tc4port.thaumcraft.block.entity.NodeStabilizerBlockEntity;
import dev.tc4port.thaumcraft.registry.TCBlockEntities;
import javax.annotation.Nullable;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityTicker;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;
import dev.tc4port.thaumcraft.nativeimpl.ClientExtensionTarget;
import dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.level.pathfinder.PathComputationType;
import net.minecraft.world.phys.HitResult;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.Explosion;

/**
 * Dedicated metadata-9/10 replacement for TC4's normal and advanced node
 * stabilizers. The block keeps the original full-cube collision while its
 * visible housing and pistons are rendered from node_stabilizer.obj.
 */
public final class NodeStabilizerBlock extends net.minecraft.world.level.block.BaseEntityBlock implements dev.tc4port.thaumcraft.nativeimpl.ClientExtensionTarget {

    // Forge calls initializeClient from the native superclass constructor. Do not add a field initializer.
    private java.util.function.Consumer<net.minecraftforge.client.extensions.common.IClientBlockExtensions> platform$clientInstaller;

    public static final MapCodec<NodeStabilizerBlock> CODEC = NodeStabilizerBlock.native$BlockCodecPlatform$simple(properties -> new NodeStabilizerBlock(false, properties));

    private final boolean advanced;

    public NodeStabilizerBlock(boolean advanced, BlockBehaviour.Properties properties) {
        this(properties, advanced, properties, true);
    }

    public boolean advanced() {
        return this.advanced;
    }

    public int lockStrength() {
        return this.advanced ? 2 : 1;
    }

    protected MapCodec<NodeStabilizerBlock> codec() {
        return CODEC;
    }

    @Nullable
    @Override
    public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        return new NodeStabilizerBlockEntity(pos, state);
    }

    @Nullable
    @Override
    public <T extends BlockEntity> BlockEntityTicker<T> getTicker(Level level, BlockState state, BlockEntityType<T> type) {
        return level.isClientSide ? createTickerHelper(type, TCBlockEntities.NODE_STABILIZER.get(), NodeStabilizerBlockEntity::clientTick) : null;
    }

    /**
     * A redstone source beside the stabilizer is diagonal to the aura
     * node, so modern neighbor propagation does not reliably notify the node.
     * Forward its power update through the node to the transducer as well as
     * the energized assembly's safety check.
     */
    @Override
    public void neighborChanged(BlockState state, Level level, BlockPos pos, Block neighborBlock, BlockPos neighborPos, boolean movedByPiston) {
        super.neighborChanged(state, level, pos, neighborBlock, neighborPos, movedByPiston);
        AuraNodeBlock.checkStructure(level, pos.above());
    }

    @Override
    public RenderShape getRenderShape(BlockState state) {
        return RenderShape.MODEL;
    }

    @Override
    public VoxelShape getBlockSupportShape(BlockState state, BlockGetter level, BlockPos pos) {
        return Shapes.empty();
    }

    private NodeStabilizerBlock(net.minecraft.world.level.block.state.BlockBehaviour.Properties native$NativeEntityBlock$arg0, boolean advanced, BlockBehaviour.Properties properties, boolean native$NativeEntityBlock$captured) {
        super(native$NativeEntityBlock$arg0);
        this.advanced = advanced;
    }

    @Override
    public void initializeClient(java.util.function.Consumer<net.minecraftforge.client.extensions.common.IClientBlockExtensions> installer) {
        platform$clientInstaller = installer;
        super.initializeClient(installer);
    }

    @Override
    public void platform$clientExtension(Object extension) {
        java.util.Objects.requireNonNull(platform$clientInstaller, "Forge initializeClient must run before client extension registration").accept((net.minecraftforge.client.extensions.common.IClientBlockExtensions) extension);
    }

    @Override
    public InteractionResult use(BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
        ItemUseResult result = (switch(0) {
            default ->
                {
                    net.minecraft.world.item.ItemStack native$bodyOperand$4640 = player.getItemInHand(hand);
                    net.minecraft.world.level.block.state.BlockState native$bodyOperand$4641 = state;
                    net.minecraft.world.level.Level native$bodyOperand$4642 = level;
                    net.minecraft.core.BlockPos native$bodyOperand$4643 = pos;
                    net.minecraft.world.entity.player.Player native$bodyOperand$4644 = player;
                    net.minecraft.world.InteractionHand native$bodyOperand$4645 = hand;
                    net.minecraft.world.phys.BlockHitResult native$bodyOperand$4646 = hit;
                    dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult native$bodyResult$4647 = null;
                    native$bodyReturn$4648: {
                        if (true) {
                            {
                                native$bodyResult$4647 = dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
                                break native$bodyReturn$4648;
                            }
                        }
                    }
                    yield native$bodyResult$4647;
                }
        });
        return result == ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION ? (hand == InteractionHand.MAIN_HAND ? (switch(0) {
            default ->
                {
                    net.minecraft.world.level.block.state.BlockState native$bodyOperand$3808 = state;
                    net.minecraft.world.level.Level native$bodyOperand$3809 = level;
                    net.minecraft.core.BlockPos native$bodyOperand$3810 = pos;
                    net.minecraft.world.entity.player.Player native$bodyOperand$3811 = player;
                    net.minecraft.world.phys.BlockHitResult native$bodyOperand$3812 = hit;
                    net.minecraft.world.InteractionResult native$bodyResult$3813 = null;
                    native$bodyReturn$3814: {
                        if (true) {
                            {
                                native$bodyResult$3813 = super.use(native$bodyOperand$3808, native$bodyOperand$3809, native$bodyOperand$3810, native$bodyOperand$3811, net.minecraft.world.InteractionHand.MAIN_HAND, native$bodyOperand$3812);
                                break native$bodyReturn$3814;
                            }
                        }
                    }
                    yield native$bodyResult$3813;
                }
        }) : InteractionResult.PASS) : result.result();
    }

    protected ItemUseResult interactWithItem(ItemStack stack, BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
        return dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
    }

    protected InteractionResult interactWithoutItem(BlockState state, Level level, BlockPos pos, Player player, BlockHitResult hit) {
        return super.use(state, level, pos, player, net.minecraft.world.InteractionHand.MAIN_HAND, hit);
    }

    @Override
    public void playerWillDestroy(Level level, BlockPos pos, BlockState state, Player player) {
        {
            net.minecraft.world.level.Level native$bodyOperand$5962 = level;
            net.minecraft.core.BlockPos native$bodyOperand$5963 = pos;
            net.minecraft.world.level.block.state.BlockState native$bodyOperand$5964 = state;
            net.minecraft.world.entity.player.Player native$bodyOperand$5965 = player;
            net.minecraft.world.level.block.state.BlockState native$bodyResult$5966 = null;
            native$bodyReturn$5967: {
                if (true) {
                    super.playerWillDestroy(native$bodyOperand$5962, native$bodyOperand$5963, native$bodyOperand$5964, native$bodyOperand$5965);
                    {
                        native$bodyResult$5966 = native$bodyOperand$5964;
                        break native$bodyReturn$5967;
                    }
                }
            }
        }
    }

    public BlockState beforePlayerDestroy(Level level, BlockPos pos, BlockState state, Player player) {
        super.playerWillDestroy(level, pos, state, player);
        return state;
    }

    protected boolean survivesSharedExplosion() {
        return false;
    }

    public int getExpDrop(net.minecraft.world.level.block.state.BlockState native$callbackInput$1050, net.minecraft.world.level.LevelReader native$callbackInput$1051, net.minecraft.util.RandomSource native$callbackInput$1052, net.minecraft.core.BlockPos native$callbackInput$1053, int native$callbackInput$1054, int native$callbackInput$1055) {
        net.minecraft.world.level.block.state.BlockState state = native$callbackInput$1050;
        net.minecraft.util.RandomSource random = native$callbackInput$1052;
        return 0;
    }

    @Override
    public void onBlockExploded(BlockState state, Level level, BlockPos pos, Explosion explosion) {
        if (!(switch(0) {
            default ->
                {
                    boolean native$bodyResult$5303 = false;
                    native$bodyReturn$5304: {
                        if (true) {
                            {
                                native$bodyResult$5303 = false;
                                break native$bodyReturn$5304;
                            }
                        }
                    }
                    yield native$bodyResult$5303;
                }
        }))
            super.onBlockExploded(state, level, pos, explosion);
    }

    @Override
    public boolean canDropFromExplosion(BlockState state, BlockGetter level, BlockPos pos, Explosion explosion) {
        return !(switch(0) {
            default ->
                {
                    boolean native$bodyResult$4649 = false;
                    native$bodyReturn$4650: {
                        if (true) {
                            {
                                native$bodyResult$4649 = false;
                                break native$bodyReturn$4650;
                            }
                        }
                    }
                    yield native$bodyResult$4649;
                }
        }) && super.canDropFromExplosion(state, level, pos, explosion);
    }

    static private <B extends net.minecraft.world.level.block.Block> com.mojang.serialization.MapCodec<B> native$BlockCodecPlatform$simple(java.util.function.Function<net.minecraft.world.level.block.state.BlockBehaviour.Properties, B> factory) {
        // Vanilla 1.21's Properties codec is a unit codec. Retain that schema for shared block definitions.
        return com.mojang.serialization.codecs.RecordCodecBuilder.mapCodec(instance -> instance.group(com.mojang.serialization.Codec.unit(net.minecraft.world.level.block.state.BlockBehaviour.Properties::of).fieldOf("properties").forGetter((B block) -> net.minecraft.world.level.block.state.BlockBehaviour.Properties.copy(block))).apply(instance, factory));
    }
}
