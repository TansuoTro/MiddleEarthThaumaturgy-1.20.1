package dev.tc4port.thaumcraft.block.entity;

import dev.tc4port.thaumcraft.common.TCGameplayParameters;
import dev.tc4port.thaumcraft.block.FluxScrubberBlock;
import dev.tc4port.thaumcraft.api.aspect.AspectId;
import dev.tc4port.thaumcraft.api.aspect.VisAction;
import dev.tc4port.thaumcraft.api.aspect.VisChannel;
import dev.tc4port.thaumcraft.api.flux.FluxApi;
import dev.tc4port.thaumcraft.api.node.VisNetworkApi;
import dev.tc4port.thaumcraft.api.essentia.EssentiaTransferMode;
import dev.tc4port.thaumcraft.api.essentia.EssentiaTransport;
import dev.tc4port.thaumcraft.network.BlockSparklePayload;
import dev.tc4port.thaumcraft.registry.TCBlockEntities;
import dev.tc4port.thaumcraft.registry.TCBlocks;
import java.util.ArrayList;
import java.util.Collections;
import javax.annotation.Nullable;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;
import java.lang.Math;
import dev.tc4port.thaumcraft.nativeimpl.state.ItemFields;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityType;

/**
 * Exact TileFluxScrubber storage, scan cadence and essentia output.
 */
public final class FluxScrubberBlockEntity extends net.minecraft.world.level.block.entity.BlockEntity implements EssentiaTransport, ItemFields.Source {

    public static final int RANGE = 16;

    public static final int MAX_ESSENTIA = 4;

    private static final int FLUX_SPARKLE_COLOR = 14_483_711;

    private final ArrayList<BlockPos> checklist = new ArrayList<>();

    private int checklistCursor;

    private int checklistRange;

    private int essentia;

    private int charges;

    private int power;

    private int animationOffset;

    public FluxScrubberBlockEntity(BlockPos pos, BlockState state) {
        super(TCBlockEntities.FLUX_SCRUBBER.get(), pos, state);
    }

    public static void serverTick(Level level, BlockPos pos, BlockState state, FluxScrubberBlockEntity scrubber) {
        if (!(level instanceof ServerLevel server)) {
            return;
        }
        if (scrubber.charges >= TCGameplayParameters.MACHINES_FLUX_SCRUBBER_REMOVALS_PER_ROLL.intValue()) {
            scrubber.charges -= TCGameplayParameters.MACHINES_FLUX_SCRUBBER_REMOVALS_PER_ROLL.intValue();
            if (level.random.nextInt(TCGameplayParameters.MACHINES_FLUX_SCRUBBER_OUTPUT_CHANCE_DENOMINATOR.intValue()) == 0) {
                if (scrubber.essentia < TCGameplayParameters.MACHINES_FLUX_SCRUBBER_ESSENTIA_CAPACITY.intValue()) {
                    scrubber.essentia++;
                }
            }
            scrubber.setChanged();
        }
        if (scrubber.power < TCGameplayParameters.MACHINES_FLUX_SCRUBBER_REMOVAL_CENTIVIS.intValue()) {
            int drained = VisNetworkApi.drain(server, pos, VisChannel.AER, TCGameplayParameters.MACHINES_FLUX_SCRUBBER_REFILL_CENTIVIS.intValue(), VisAction.EXECUTE);
            if (drained > 0) {
                scrubber.power = (int) Math.min(Integer.MAX_VALUE, (long) scrubber.power + drained);
                scrubber.setChanged();
            }
        }
        if (scrubber.power >= TCGameplayParameters.MACHINES_FLUX_SCRUBBER_REMOVAL_CENTIVIS.intValue()) {
            scrubber.checkFlux(server);
        }
    }

    public static void clientTick(Level level, BlockPos pos, BlockState state, FluxScrubberBlockEntity scrubber) {
        if (scrubber.animationOffset == 0) {
            scrubber.animationOffset = level.random.nextInt(1_000);
        }
    }

    private void checkFlux(ServerLevel level) {
        if (this.checklistRange != TCGameplayParameters.MACHINES_FLUX_SCRUBBER_RANGE.intValue() || this.checklistCursor >= this.checklist.size()) {
            this.rebuildChecklist(level);
        }
        int checked = 0;
        while (checked++ < 16 && this.checklistCursor < this.checklist.size()) {
            BlockPos target = this.checklist.set(this.checklistCursor++, null);
            if (!level.isLoaded(target))
                continue;
            BlockState targetState = level.getBlockState(target);
            if (targetState.isAir() || !isFlux(targetState) || this.worldPosition.distSqr(target) >= TCGameplayParameters.MACHINES_FLUX_SCRUBBER_RANGE.intValue() * TCGameplayParameters.MACHINES_FLUX_SCRUBBER_RANGE.intValue()) {
                continue;
            }
            if (FluxApi.consume(level, target, 1, dev.tc4port.thaumcraft.api.flux.FluxConsumeContext.machine(net.minecraft.resources.ResourceLocation.fromNamespaceAndPath("thaumcraft", "flux_scrubber"), this.worldPosition), VisAction.EXECUTE) != 1) {
                continue;
            }
            this.power -= TCGameplayParameters.MACHINES_FLUX_SCRUBBER_REMOVAL_CENTIVIS.intValue();
            this.sendSparkles(level, target);
            this.charges++;
            this.setChanged();
            return;
        }
    }

    private static boolean isFlux(BlockState state) {
        /*
         * BlockFluxGoo and BlockFluxGas were constructed with the same
         * Config.fluxGoomaterial singleton. TileFluxScrubber compared that
         * material by identity, so both finite fluids are valid targets.
         */
        return state.is(TCBlocks.FLUX_GOO.get()) || state.is(TCBlocks.FLUX_GAS.get());
    }

    private void rebuildChecklist(ServerLevel level) {
        this.checklist.clear();
        this.checklistCursor = 0;
        this.checklistRange = TCGameplayParameters.MACHINES_FLUX_SCRUBBER_RANGE.intValue();
        int range = this.checklistRange;
        for (int x = -range; x <= range; x++) {
            for (int y = -range; y <= range; y++) {
                for (int z = -range; z <= range; z++) {
                    this.checklist.add(this.worldPosition.offset(x, y, z));
                }
            }
        }
        /*
         * Collections.shuffle(Random) cannot consume RandomSource. This is
         * the same Fisher-Yates shuffle, driven by the modern level RNG.
         */
        for (int index = this.checklist.size() - 1; index > 0; index--) {
            Collections.swap(this.checklist, index, level.random.nextInt(index + 1));
        }
    }

    private void sendSparkles(ServerLevel level, BlockPos target) {
        BlockSparklePayload payload = new BlockSparklePayload(target, FLUX_SPARKLE_COLOR, 7);
        Vec3 center = Vec3.atCenterOf(target);
        for (ServerPlayer player : level.players()) {
            if (player.distanceToSqr(center) <= 32.0 * 32.0) {
                dev.tc4port.thaumcraft.network.TCPayloads.CHANNEL.sendToPlayer(player, payload);
            }
        }
    }

    public Direction facing() {
        return this.getBlockState().hasProperty(FluxScrubberBlock.FACING) ? this.getBlockState().getValue(FluxScrubberBlock.FACING) : Direction.DOWN;
    }

    public int essentia() {
        return this.essentia;
    }

    public int charges() {
        return this.charges;
    }

    public int power() {
        return this.power;
    }

    public int animationOffset() {
        return this.animationOffset;
    }

    @Override
    public boolean isConnectable(Direction face) {
        return face == this.facing();
    }

    @Override
    public boolean canInputFrom(Direction face) {
        return false;
    }

    @Override
    public boolean canOutputTo(Direction face) {
        return face == this.facing();
    }

    @Nullable
    @Override
    public AspectId suctionType(Direction face) {
        return null;
    }

    @Override
    public int suctionAmount(Direction face) {
        return 0;
    }

    @Override
    public int takeEssentia(AspectId aspect, int amount, Direction face, EssentiaTransferMode mode) {
        /*
         * TileFluxScrubber did not validate requested aspect or side here;
         * pipes are expected to query its advertised type/output first.
         */
        if (amount <= 0) {
            return 0;
        }
        int taken = Math.min(this.essentia, amount);
        if (taken > 0 && mode.executes()) {
            this.essentia -= taken;
            this.setChanged();
        }
        return taken;
    }

    @Override
    public int addEssentia(AspectId aspect, int amount, Direction face, EssentiaTransferMode mode) {
        return 0;
    }

    @Nullable
    @Override
    public AspectId essentiaType(Direction face) {
        return AspectId.parse("praecantatio");
    }

    @Override
    public int essentiaAmount(Direction face) {
        return this.essentia;
    }

    @Override
    public int minimumSuction() {
        return 0;
    }

    @Override
    public boolean renderExtendedTube() {
        return false;
    }

    @Override
    public void load(CompoundTag tag) {
        super.load(tag);
        this.charges = tag.getInt("charges");
        this.power = tag.getInt("power");
        this.essentia = tag.getInt("essentia");
        this.checklist.clear();
        this.checklistCursor = 0;
    }

    @Override
    protected void saveAdditional(CompoundTag tag) {
        super.saveAdditional(tag);
        tag.putInt("charges", this.charges);
        tag.putInt("power", this.power);
        tag.putInt("essentia", this.essentia);
    }

    protected final HolderLookup.Provider persistenceRegistries() {
        if (level != null)
            return level.registryAccess();
        var server = net.minecraftforge.server.ServerLifecycleHooks.getCurrentServer();
        return server != null ? server.registryAccess() : net.minecraft.core.RegistryAccess.fromRegistryOfRegistries(net.minecraft.core.registries.BuiltInRegistries.REGISTRY);
    }

    protected static net.minecraft.network.chat.Component parseCustomNameSafe(String value, HolderLookup.Provider registries) {
        try {
            return net.minecraft.network.chat.Component.Serializer.fromJson(value);
        } catch (RuntimeException exception) {
            return null;
        }
    }

    protected void readItemFields(ItemFields.Input input) {
    }

    public void copyItemFields(ItemFields.Output output) {
    }

    public void applyComponentsFromItemStack(ItemStack stack) {
        readItemFields(ItemFields.from(stack));
    }

    public void removeComponentsFromTag(CompoundTag tag) {
    }

    @Override
    public void saveToItem(ItemStack stack) {
        CompoundTag tag = saveWithoutMetadata();
        {
            net.minecraft.nbt.CompoundTag native$bodyOperand$6156 = tag;
            native$bodyReturn$6158: {
                if (true) {
                }
            }
        }
        net.minecraft.world.item.BlockItem.setBlockEntityData(stack, getType(), tag);
        copyItemFields(ItemFields.to(stack));
    }

    @Override
    public net.minecraft.world.phys.AABB getRenderBoundingBox() {
        return FluxScrubberBlockEntity.native$ClientBlockEntityBounds$bounds(this);
    }

    @Override()
    public void onDataPacket(net.minecraft.network.Connection connection, net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket packet) {
        handleUpdateTag(packet.getTag());
    }

    @SuppressWarnings({ "rawtypes", "unchecked" })
    static private net.minecraft.world.phys.AABB native$ClientBlockEntityBounds$bounds(net.minecraft.world.level.block.entity.BlockEntity blockEntity) {
        var renderer = net.minecraft.client.Minecraft.getInstance().getBlockEntityRenderDispatcher().getRenderer(blockEntity);
        return renderer instanceof dev.tc4port.thaumcraft.nativeimpl.NativeBlockEntityRenderer shared ? shared.getRenderBoundingBox(blockEntity) : new net.minecraft.world.phys.AABB(blockEntity.getBlockPos());
    }

    private boolean native$capabilitiesInvalid$16904;

    public boolean native$capabilityActive$16765;

    public net.minecraftforge.common.capabilities.Capability<dev.tc4port.thaumcraft.api.essentia.EssentiaTransport> native$capabilityCapture$16764;

    private net.minecraftforge.common.util.LazyOptional<dev.tc4port.thaumcraft.api.essentia.EssentiaTransport> native$capabilityHandle$16766;

    @Override
    public <native$capabilityResultType$16905> net.minecraftforge.common.util.LazyOptional<native$capabilityResultType$16905> getCapability(net.minecraftforge.common.capabilities.Capability<native$capabilityResultType$16905> native$requestedCapability$16906, net.minecraft.core.Direction native$requestedFace$16907) {
        getCapabilities();
        synchronized (this) {
            if (native$capabilitiesInvalid$16904)
                return net.minecraftforge.common.util.LazyOptional.empty();
            if (native$capabilityActive$16765 && native$requestedCapability$16906 == (this.native$capabilityCapture$16764)) {
                if (native$capabilityHandle$16766 == null)
                    native$capabilityHandle$16766 = net.minecraftforge.common.util.LazyOptional.of(() -> this);
                return native$capabilityHandle$16766.cast();
            }
        }
        return super.getCapability(native$requestedCapability$16906, native$requestedFace$16907);
    }

    @Override
    public void invalidateCaps() {
        java.util.List<net.minecraftforge.common.util.LazyOptional<?>> native$expiredCapabilities$16908 = new java.util.ArrayList<>();
        synchronized (this) {
            native$capabilitiesInvalid$16904 = true;
            if (native$capabilityHandle$16766 != null) {
                native$expiredCapabilities$16908.add(native$capabilityHandle$16766);
                native$capabilityHandle$16766 = null;
            }
        }
        try {
            super.invalidateCaps();
        } finally {
            native$expiredCapabilities$16908.forEach(net.minecraftforge.common.util.LazyOptional::invalidate);
        }
    }

    @Override
    public void reviveCaps() {
        super.reviveCaps();
        synchronized (this) {
            native$capabilitiesInvalid$16904 = false;
        }
    }
}
