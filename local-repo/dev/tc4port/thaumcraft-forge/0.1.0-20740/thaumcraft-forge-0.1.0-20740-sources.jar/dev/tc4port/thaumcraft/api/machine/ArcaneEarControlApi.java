package dev.tc4port.thaumcraft.api.machine;

import dev.tc4port.thaumcraft.util.RuntimeWarnings;
import dev.tc4port.thaumcraft.block.entity.ArcaneEarBlockEntity;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;

/**
 * Controlled loaded-block write boundary for TC-owned Arcane Ears.
 */
public final class ArcaneEarControlApi {

    private ArcaneEarControlApi() {
    }

    public static ArcaneEarControlResult setNote(ServerLevel level, BlockPos position, int note) {
        if (level == null || position == null || note < 0 || note > 24) {
            RuntimeWarnings.warnOnce("arcane-ear-note", "Ignoring invalid Arcane Ear note request");
            return ArcaneEarControlResult.INVALID_REQUEST;
        }
        if (!level.getServer().isSameThread()) {
            return ArcaneEarControlResult.OFF_SERVER_THREAD;
        }
        if (!level.hasChunkAt(position)) {
            return ArcaneEarControlResult.TARGET_UNLOADED;
        }
        if (!(level.getBlockEntity(position) instanceof ArcaneEarBlockEntity ear)) {
            return ArcaneEarControlResult.NOT_AN_ARCANE_EAR;
        }
        if (ear.note() == note) {
            return ArcaneEarControlResult.UNCHANGED;
        }
        ear.setControlledNote(note);
        return ArcaneEarControlResult.UPDATED;
    }
}
