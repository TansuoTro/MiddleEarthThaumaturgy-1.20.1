package dev.tc4port.thaumcraft.block.entity;

import dev.tc4port.thaumcraft.api.event.GameplayHooks;
import dev.tc4port.thaumcraft.common.TCGameplayParameters;
import dev.tc4port.thaumcraft.client.TubeVentParticle;
import dev.tc4port.thaumcraft.entity.EldritchCrabEntity;
import dev.tc4port.thaumcraft.registry.TCBlockEntities;
import dev.tc4port.thaumcraft.registry.TCEntities;
import dev.tc4port.thaumcraft.registry.TCSounds;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import dev.tc4port.thaumcraft.nativeimpl.state.ItemFields;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityType;

/**
 * Exact timing, activation cap, ejection and directed vent effect from
 * TileEldritchCrabSpawner.
 */
public final class EldritchCrabSpawnerBlockEntity extends net.minecraft.world.level.block.entity.BlockEntity implements ItemFields.Source {

    private static final int ACTIVE_VENT_EVENT = 1;

    private static final int VENT_COLOR = 0x9988AA;

    private int countdown = TCGameplayParameters.MACHINES_ELDRITCH_CRAB_SPAWNER_INITIAL_COUNTDOWN.intValue();

    private int ticks;

    private int venting;

    private Direction facing = Direction.DOWN;

    public EldritchCrabSpawnerBlockEntity(BlockPos pos, BlockState state) {
        super(TCBlockEntities.ELDRITCH_CRAB_SPAWNER.get(), pos, state);
    }

    public static void serverTick(Level level, BlockPos pos, BlockState state, EldritchCrabSpawnerBlockEntity spawner) {
        if (!(level instanceof ServerLevel server)) {
            return;
        }
        tickServer(server, pos, state, spawner, spawner.isActivated());
    }

    private static void tickServer(ServerLevel level, BlockPos pos, BlockState state, EldritchCrabSpawnerBlockEntity spawner, boolean active) {
        if (spawner.ticks == 0) {
            spawner.ticks = level.random.nextInt(500);
        }
        spawner.ticks++;
        spawner.countdown--;
        if (spawner.countdown < 0) {
            spawner.countdown = TCGameplayParameters.MACHINES_ELDRITCH_CRAB_SPAWNER_RETRY_COUNTDOWN.intValue() + level.random.nextInt(TCGameplayParameters.MACHINES_ELDRITCH_CRAB_SPAWNER_RETRY_RANDOM_CHOICES.intValue());
            return;
        }
        // Population affects only these two decisions; retain their original ticks.
        boolean capped = active && (spawner.countdown == 15 || spawner.countdown <= 0) && spawner.maxEntitiesReached();
        if (spawner.countdown == 15 && active && !capped) {
            level.blockEvent(pos, state.getBlock(), ACTIVE_VENT_EVENT, 0);
            level.playSound(null, pos, TCSounds.CRAB_SPAWN.get(), SoundSource.BLOCKS, 0.5F, 1.0F);
        }
        if (spawner.countdown <= 0 && active && !capped) {
            spawner.countdown = TCGameplayParameters.MACHINES_ELDRITCH_CRAB_SPAWNER_SPAWN_COUNTDOWN.intValue() + level.random.nextInt(TCGameplayParameters.MACHINES_ELDRITCH_CRAB_SPAWNER_SPAWN_RANDOM_CHOICES.intValue());
            spawner.spawnCrab(level);
            level.playSound(null, pos, TCSounds.GORE.get(), SoundSource.BLOCKS, 0.5F, 1.0F);
        }
    }

    public static void clientTick(Level level, BlockPos pos, BlockState state, EldritchCrabSpawnerBlockEntity spawner) {
        if (spawner.venting > 0) {
            spawner.venting--;
            for (int count = 0; count < 3; count++) {
                spawner.drawVent();
            }
        } else if (level.random.nextInt(20) == 0) {
            spawner.drawVent();
        }
    }

    private void drawVent() {
        if (this.level == null) {
            return;
        }
        /*
         * Preserve all six legacy random draws and their original order.
         */
        float fx = 0.15F - this.level.random.nextFloat() * 0.3F;
        float fz = 0.15F - this.level.random.nextFloat() * 0.3F;
        float fy = 0.15F - this.level.random.nextFloat() * 0.3F;
        float fx2 = 0.1F - this.level.random.nextFloat() * 0.2F;
        float fz2 = 0.1F - this.level.random.nextFloat() * 0.2F;
        float fy2 = 0.1F - this.level.random.nextFloat() * 0.2F;
        TubeVentParticle.spawnDirected(this.level, this.worldPosition.getX() + 0.5F + fx + this.facing.getStepX() / 2.1F, this.worldPosition.getY() + 0.5F + fy + this.facing.getStepY() / 2.1F, this.worldPosition.getZ() + 0.5F + fz + this.facing.getStepZ() / 2.1F, this.facing.getStepX() / 3.0F + fx2, this.facing.getStepY() / 3.0F + fy2, this.facing.getStepZ() / 3.0F + fz2, VENT_COLOR, 2.0F);
    }

    private boolean maxEntitiesReached() {
        if (this.level == null) {
            return false;
        }
        AABB range = new AABB(this.worldPosition).inflate(32.0);
        return this.level.getEntitiesOfClass(EldritchCrabEntity.class, range).size() > TCGameplayParameters.MACHINES_ELDRITCH_CRAB_SPAWNER_NEARBY_BLOCKING_THRESHOLD.intValue();
    }

    public boolean isActivated() {
        return this.level != null && this.level.getNearestPlayer(this.worldPosition.getX() + 0.5, this.worldPosition.getY() + 0.5, this.worldPosition.getZ() + 0.5, 16.0, false) != null;
    }

    private void spawnCrab(ServerLevel level) {
        EldritchCrabEntity crab = TCEntities.ELDRITCH_CRAB.get().create(level);
        if (crab == null) {
            return;
        }
        BlockPos output = this.worldPosition.relative(this.facing);
        crab.moveTo(output.getX() + 0.5, output.getY() + 0.5, output.getZ() + 0.5, 0.0F, 0.0F);
        /*
         * The legacy maze completed both sides of a chunk seam before a
         * player could activate the vent, so its selected exposed face was
         * still empty when the crab was emitted.  Modern cells are populated
         * independently; a reciprocal cell (or a player block) can close
         * that face later.  Mob#checkSpawnObstruction no longer rejects block
         * collision for this scripted spawn, so explicitly retain the old
         * clear-volume precondition instead of creating crabs inside a wall.
         */
        AABB obstructionBox = crab.getBoundingBox();
        if (this.facing == Direction.DOWN) {
            /*
             * Entity y is the feet position.  At the legacy spawn point a
             * 0.6-block-tall crab therefore reaches 0.1 blocks back into a
             * ceiling-mounted vent.  1.7 did not reject that harmless
             * overlap and immediately ejected the crab downward.  Probe a
             * slightly advanced box so the vent itself is ignored while a
             * wall, floor or liquid in the actual outlet still blocks the
             * scripted spawn.
             */
            obstructionBox = obstructionBox.move(0.0, -0.125, 0.0);
        } else if (this.facing.getAxis().isHorizontal()) {
            /*
             * A wall vent in the maze's uppermost stone row has the same
             * legacy coordinate quirk on a different neighbour.  The crab's
             * feet begin halfway up the outlet, so its 0.6-block height
             * reaches 0.1 blocks into the ceiling above that otherwise-open
             * outlet.  The source spawned it and let gravity/ejection clear
             * the overlap.  Trim only that top sliver from the safety probe;
             * the full outlet volume, its floor, fluids and horizontal walls
             * remain checked, while the real position is left unchanged.
             */
            obstructionBox = obstructionBox.contract(0.0, 0.125, 0.0);
        }
        if (!level.noCollision(crab, obstructionBox) || level.containsAnyLiquid(obstructionBox)) {
            return;
        }
        GameplayHooks.finalizeMobSpawn(crab, level, level.getCurrentDifficultyAt(output), MobSpawnType.SPAWNER, null);
        crab.setHelmet(false);
        crab.setDeltaMovement(this.facing.getStepX() * 0.2F, this.facing.getStepY() * 0.2F, this.facing.getStepZ() * 0.2F);
        level.addFreshEntity(crab);
    }

    public Direction facing() {
        return this.facing;
    }

    public void setFacing(Direction facing) {
        this.facing = facing == null ? Direction.DOWN : facing;
        this.setChanged();
        if (this.level != null) {
            this.level.sendBlockUpdated(this.worldPosition, this.getBlockState(), this.getBlockState(), 3);
        }
    }

    public int countdown() {
        return this.countdown;
    }

    @Override
    public boolean triggerEvent(int id, int type) {
        if (id == ACTIVE_VENT_EVENT) {
            if (this.level != null && this.level.isClientSide) {
                this.venting = 20;
            }
            return true;
        }
        return super.triggerEvent(id, type);
    }

    @Override
    public void load(CompoundTag tag) {
        Direction previousFacing = this.facing;
        super.load(tag);
        this.facing = Direction.from3DDataValue(tag.getByte("facing"));
        if (this.level != null && this.level.isClientSide && previousFacing != this.facing) {
            this.level.sendBlockUpdated(this.worldPosition, this.getBlockState(), this.getBlockState(), 2);
        }
    }

    @Override
    protected void saveAdditional(CompoundTag tag) {
        super.saveAdditional(tag);
        tag.putByte("facing", (byte) this.facing.get3DDataValue());
    }

    @Override
    public CompoundTag getUpdateTag() {
        return this.saveWithoutMetadata();
    }

    @Override
    public Packet<ClientGamePacketListener> getUpdatePacket() {
        return ClientboundBlockEntityDataPacket.create(this);
    }

    protected final HolderLookup.Provider persistenceRegistries() {
        if (level != null)
            return level.registryAccess();
        var server = net.minecraftforge.server.ServerLifecycleHooks.getCurrentServer();
        return server != null ? server.registryAccess() : net.minecraft.core.RegistryAccess.fromRegistryOfRegistries(net.minecraft.core.registries.BuiltInRegistries.REGISTRY);
    }

    protected static net.minecraft.network.chat.Component parseCustomNameSafe(String value, HolderLookup.Provider registries) {
        try {
            return net.minecraft.network.chat.Component.Serializer.fromJson(value);
        } catch (RuntimeException exception) {
            return null;
        }
    }

    protected void readItemFields(ItemFields.Input input) {
    }

    public void copyItemFields(ItemFields.Output output) {
    }

    public void applyComponentsFromItemStack(ItemStack stack) {
        readItemFields(ItemFields.from(stack));
    }

    public void removeComponentsFromTag(CompoundTag tag) {
    }

    @Override
    public void saveToItem(ItemStack stack) {
        CompoundTag tag = saveWithoutMetadata();
        {
            net.minecraft.nbt.CompoundTag native$bodyOperand$6129 = tag;
            native$bodyReturn$6131: {
                if (true) {
                }
            }
        }
        net.minecraft.world.item.BlockItem.setBlockEntityData(stack, getType(), tag);
        copyItemFields(ItemFields.to(stack));
    }

    @Override
    public net.minecraft.world.phys.AABB getRenderBoundingBox() {
        return EldritchCrabSpawnerBlockEntity.native$ClientBlockEntityBounds$bounds(this);
    }

    @Override()
    public void onDataPacket(net.minecraft.network.Connection connection, net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket packet) {
        handleUpdateTag(packet.getTag());
    }

    @SuppressWarnings({ "rawtypes", "unchecked" })
    static private net.minecraft.world.phys.AABB native$ClientBlockEntityBounds$bounds(net.minecraft.world.level.block.entity.BlockEntity blockEntity) {
        var renderer = net.minecraft.client.Minecraft.getInstance().getBlockEntityRenderDispatcher().getRenderer(blockEntity);
        return renderer instanceof dev.tc4port.thaumcraft.nativeimpl.NativeBlockEntityRenderer shared ? shared.getRenderBoundingBox(blockEntity) : new net.minecraft.world.phys.AABB(blockEntity.getBlockPos());
    }
}
