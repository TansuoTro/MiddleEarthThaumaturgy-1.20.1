package dev.tc4port.thaumcraft.api.research;

import dev.tc4port.thaumcraft.api.aspect.AspectId;
import dev.tc4port.thaumcraft.network.ResearchTableActionPayload;
import dev.tc4port.thaumcraft.network.TCPayloads;
import dev.tc4port.thaumcraft.research.ResearchTableActions;
import java.util.Objects;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerPlayer;

/**
 * Research-table transactions for built-in and addon interfaces.
 *
 * <p>No particular screen, menu or held item is required. The position identifies
 * a loaded research table in the player's current dimension, within its normal
 * interaction distance. Transactions use the table's current note and scribing
 * tool, and the player's current knowledge and supplies. Spectators and calls
 * outside the player's server thread cannot mutate state.
 *
 * <p>Client request methods require a connected client and do not confirm success.
 * The server rechecks the current state, applies costs and synchronizes changes.
 */
public final class ResearchTableApi {

    private ResearchTableApi() {
    }

    /**
     * Requests placement in a blank axial hex cell; coordinates may be negative.
     */
    public static void requestPlaceAspect(BlockPos tablePos, int q, int r, AspectId aspect) {
        TCPayloads.CHANNEL.sendToServer(ResearchTableActionPayload.place(Objects.requireNonNull(tablePos, "tablePos"), q, r, Objects.requireNonNull(aspect, "aspect")));
    }

    /**
     * Requests erasure of a player-added hex; fixed endpoints and completed notes cannot be erased.
     */
    public static void requestEraseAspect(BlockPos tablePos, int q, int r) {
        TCPayloads.CHANNEL.sendToServer(ResearchTableActionPayload.erase(Objects.requireNonNull(tablePos, "tablePos"), q, r));
    }

    /**
     * Requests an aspect combination using the player's pool and the table's bonus pool.
     */
    public static void requestCombine(BlockPos tablePos, AspectId first, AspectId second) {
        TCPayloads.CHANNEL.sendToServer(ResearchTableActionPayload.combine(Objects.requireNonNull(tablePos, "tablePos"), Objects.requireNonNull(first, "first"), Objects.requireNonNull(second, "second")));
    }

    /**
     * Requests a copy of the completed note, paying its current aspect, paper and ink-sac costs.
     */
    public static void requestDuplicate(BlockPos tablePos) {
        TCPayloads.CHANNEL.sendToServer(ResearchTableActionPayload.duplicate(Objects.requireNonNull(tablePos, "tablePos")));
    }

    /**
     * Returns true only when placement succeeds and its normal costs have been applied.
     */
    public static boolean placeAspect(ServerPlayer player, BlockPos tablePos, int q, int r, AspectId aspect) {
        return ResearchTableActions.placeAspect(Objects.requireNonNull(player, "player"), Objects.requireNonNull(tablePos, "tablePos"), q, r, Objects.requireNonNull(aspect, "aspect"));
    }

    /**
     * Returns true only after erasure, including the normal ink cost and research-dependent refund roll.
     */
    public static boolean eraseAspect(ServerPlayer player, BlockPos tablePos, int q, int r) {
        return ResearchTableActions.eraseAspect(Objects.requireNonNull(player, "player"), Objects.requireNonNull(tablePos, "tablePos"), q, r);
    }

    /**
     * Returns true when the normal combination attempt consumes its inputs, even if they have no result.
     */
    public static boolean combine(ServerPlayer player, BlockPos tablePos, AspectId first, AspectId second) {
        return ResearchTableActions.combine(Objects.requireNonNull(player, "player"), Objects.requireNonNull(tablePos, "tablePos"), Objects.requireNonNull(first, "first"), Objects.requireNonNull(second, "second"));
    }

    /**
     * Returns true only when a completed note is copied and its costs are paid.
     */
    public static boolean duplicate(ServerPlayer player, BlockPos tablePos) {
        return ResearchTableActions.duplicate(Objects.requireNonNull(player, "player"), Objects.requireNonNull(tablePos, "tablePos"));
    }
}
