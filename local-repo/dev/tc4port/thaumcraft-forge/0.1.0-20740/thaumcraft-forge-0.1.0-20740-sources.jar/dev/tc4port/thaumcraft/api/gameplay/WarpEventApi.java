package dev.tc4port.thaumcraft.api.gameplay;

import dev.tc4port.thaumcraft.common.GameplayContexts;
import dev.tc4port.thaumcraft.common.GameplayRollCatalog;
import dev.tc4port.thaumcraft.common.PlayerKnowledgeService;
import dev.tc4port.thaumcraft.common.WarpEventSystem;
import dev.tc4port.thaumcraft.common.WarpGear;
import java.util.Map;
import java.util.Objects;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;

/**
 * Executes a Warp event ID with the player's Warp context on the server thread.
 * IDs identify files in thaumcraft/warp/events, for example {@code thaumcraft:death_gaze}.
 * Explicit calls bypass natural Warp selection and leave the event counter unchanged.
 * Behavior conditions, branch weights and action probabilities still apply; {@code roll} is zero.
 * Missing/disabled behaviors or rejected requirements return false. A true result means
 * the group was accepted; native command/function callers may return before it executes.
 * Callback failures stop the remaining steps without rolling back earlier side effects.
 * {@link #triggerRandom(ServerPlayer)} instead rolls current severity and respects player protection.
 */
public final class WarpEventApi {

    private WarpEventApi() {
    }

    /**
     * Immutable snapshot of the current native reload result, for addon queues and tooling.
     * A new snapshot replaces the previous one after a successful reload. Keeping an old
     * definition does not keep its event executable: trigger always resolves the current ID.
     */
    public static Map<ResourceLocation, WarpEventDefinition> events() {
        return GameplayRollCatalog.WARP.definitions();
    }

    /**
     * Select without executing, for caller-owned queues. The same roll bounds, weights,
     * compiled conditions and requirements as natural Warp apply. The predicate limits IDs;
     * it does not override eligibility. Trigger resolves and checks the chosen ID again.
     */
    public static java.util.Optional<ResourceLocation> select(int roll, GameplayContext context, java.util.function.Predicate<ResourceLocation> included) {
        return GameplayRollCatalog.WARP.select(roll, context, Objects.requireNonNull(included));
    }

    /**
     * Register an eligibility callback before data loading. Event JSON may reference its
     * ID through the optional condition member. It gates natural selection and explicit calls.
     * Closing the handle disables compiled references; re-registering requires a reload.
     */
    public static dev.tc4port.thaumcraft.api.Registration registerCondition(ResourceLocation id, java.util.function.Predicate<GameplayContext> condition) {
        return dev.tc4port.thaumcraft.common.WarpEventConditions.register(id, condition);
    }

    /**
     * Execute the current event using a caller-owned server context. For persisted addon
     * queues this can retain the original Warp strength without rewriting player storage.
     * The current enabled state, named condition and group requirements always apply.
     */
    public static boolean trigger(ResourceLocation eventId, GameplayContext context) {
        return GameplayRollCatalog.WARP.execute(Objects.requireNonNull(eventId), Objects.requireNonNull(context));
    }

    /**
     * Uses the player's current total Warp, equipment Warp and event counter.
     */
    public static boolean trigger(ServerPlayer player, ResourceLocation eventId) {
        requireServerThread(player);
        return triggerWithWarp(player, eventId, PlayerKnowledgeService.get(player).totalWarp());
    }

    /**
     * Trigger a named event with typed SNBT invocation parameters. Optional {@code warp}
     * or {@code strength} is a nonnegative integer context override; they are mutually exclusive.
     * Other keys are passed unchanged to {@link GameplayContext#parameters()} for conditions
     * and actions to validate, for example with their own Codec and NbtOps. Numeric custom
     * fields also become finite context values for GameplayNumber expressions. Derived player
     * values and system limits cannot be overwritten. No parameter changes stored Warp.
     */
    public static boolean trigger(ServerPlayer player, ResourceLocation eventId, net.minecraft.nbt.CompoundTag parameters) {
        requireServerThread(player);
        Objects.requireNonNull(parameters);
        if (parameters.contains("warp") && parameters.contains("strength"))
            throw new IllegalArgumentException("Use either warp or strength, not both");
        int warp = parameters.contains("warp") ? integerParameter(parameters, "warp") : (int) Math.min(Integer.MAX_VALUE, dev.tc4port.thaumcraft.api.player.PlayerWarpApi.view(player).total());
        var base = context(player, warp);
        var values = new java.util.LinkedHashMap<>(base.values());
        if (parameters.contains("strength"))
            values.put("strength", (double) integerParameter(parameters, "strength"));
        for (String key : parameters.getAllKeys()) {
            if (key.equals("warp") || key.equals("strength"))
                continue;
            if (values.containsKey(key))
                throw new IllegalArgumentException("Reserved context value: " + key);
            if (parameters.get(key) instanceof net.minecraft.nbt.NumericTag number) {
                double value = number.getAsDouble();
                if (!Double.isFinite(value))
                    throw new IllegalArgumentException("Non-finite parameter: " + key);
                values.put(key, value);
            }
        }
        return trigger(eventId, new GameplayContext(base.level(), base.position(), base.actor(), base.target(), base.usedItem(), values, parameters));
    }

    private static int integerParameter(net.minecraft.nbt.CompoundTag parameters, String key) {
        if (!(parameters.get(key) instanceof net.minecraft.nbt.NumericTag number))
            throw new IllegalArgumentException(key + " must be a nonnegative integer");
        double value = number.getAsDouble();
        if (!Double.isFinite(value) || value < 0 || value > Integer.MAX_VALUE || value != Math.rint(value))
            throw new IllegalArgumentException(key + " must be a nonnegative integer within the integer range");
        return (int) value;
    }

    /**
     * Roll and execute at most one eligible event from every loaded namespace, using the
     * player's current Warp, equipment, activity, live strength formula and faceplate reduction.
     * Allows creative players; respects wuss mode, spectator mode, death and Warp Ward. Skips the natural
     * interval and occurrence-chance check; an exhausted activity counter alone does not block it.
     * Does not decay Warp/activity or grant threshold research as part of dispatch, although
     * the chosen event's own actions may change player state. No eligible roll returns false;
     * there is no retry or fallback. Requires the server thread, like other trigger methods.
     */
    public static boolean triggerRandom(ServerPlayer player) {
        requireServerThread(player);
        if (!player.isAlive() || !dev.tc4port.thaumcraft.api.player.PlayerWarpApi.eventsAllowed(player))
            return false;
        int warp = (int) Math.min(Integer.MAX_VALUE, dev.tc4port.thaumcraft.api.player.PlayerWarpApi.view(player).total());
        if ((long) warp + WarpGear.equippedWarp(player) <= 0)
            return false;
        var base = context(player, warp);
        int strength = (int) base.value("strength");
        if (strength <= 0)
            return false;
        int roll = WarpEventSystem.rollEffect(player, strength);
        var values = new java.util.LinkedHashMap<>(base.values());
        values.put("roll", (double) roll);
        var selectedContext = new GameplayContext(base.level(), base.position(), base.actor(), base.target(), base.usedItem(), values);
        return GameplayRollCatalog.WARP.roll(roll, selectedContext);
    }

    /**
     * Replaces total Warp for this execution, then combines it with the player's equipment
     * Warp and current event counter using the live natural-strength formula and ceiling.
     * The context's {@code warp} is the supplied value; individual Warp pools stay actual.
     *
     * @param warp nonnegative total Warp for this execution; never written to the player
     */
    public static boolean triggerWithWarp(ServerPlayer player, ResourceLocation eventId, int warp) {
        return trigger(eventId, context(player, warp));
    }

    /**
     * Build the same context as triggerWithWarp, for selection and delayed action groups.
     * Uses the current core strength formula/ceiling, equipment and counter. Pool values
     * remain actual, the supplied warp is never stored, and roll starts at zero.
     */
    public static GameplayContext context(ServerPlayer player, int warp) {
        requireServerThread(player);
        if (warp < 0)
            throw new IllegalArgumentException("Event Warp cannot be negative");
        int eventWarp = (int) Math.min(Integer.MAX_VALUE, (long) warp + WarpGear.equippedWarp(player));
        int strength = WarpEventSystem.eventStrength(eventWarp, PlayerKnowledgeService.get(player).warpCounter());
        var values = new java.util.LinkedHashMap<>(GameplayContexts.warpValues(0, strength));
        values.put("warp", (double) warp);
        return GameplayContexts.affected(player, values);
    }

    /**
     * Uses the supplied strength directly, without the natural formula or its ceiling.
     * Individual action bounds still apply. The context's {@code warp} and individual
     * Warp pools reflect the player's actual stored values.
     *
     * @param strength nonnegative effect strength for this execution
     */
    public static boolean triggerWithStrength(ServerPlayer player, ResourceLocation eventId, int strength) {
        requireServerThread(player);
        if (strength < 0)
            throw new IllegalArgumentException("Event strength cannot be negative");
        return execute(player, eventId, PlayerKnowledgeService.get(player).totalWarp(), strength);
    }

    private static boolean execute(ServerPlayer player, ResourceLocation eventId, int warp, int strength) {
        Objects.requireNonNull(eventId, "eventId");
        var values = new java.util.LinkedHashMap<>(GameplayContexts.warpValues(0, strength));
        values.put("warp", (double) warp);
        return GameplayRollCatalog.WARP.execute(eventId, GameplayContexts.affected(player, values));
    }

    private static void requireServerThread(ServerPlayer player) {
        Objects.requireNonNull(player, "player");
        if (!player.serverLevel().getServer().isSameThread()) {
            throw new IllegalStateException("Warp events require the server thread");
        }
    }
}
