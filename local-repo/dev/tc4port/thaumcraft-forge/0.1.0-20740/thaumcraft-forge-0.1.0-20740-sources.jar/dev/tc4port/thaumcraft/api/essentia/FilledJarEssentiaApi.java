package dev.tc4port.thaumcraft.api.essentia;

import dev.tc4port.thaumcraft.util.RuntimeWarnings;
import dev.tc4port.thaumcraft.api.aspect.AspectApi;
import dev.tc4port.thaumcraft.api.aspect.AspectId;
import dev.tc4port.thaumcraft.data.AspectStackData;
import dev.tc4port.thaumcraft.item.WardedJarBlockItem;
import dev.tc4port.thaumcraft.state.TCItemState;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import net.minecraft.world.item.ItemStack;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.Level;

/**
 * Atomic ItemStack extraction for TC-owned filled warded jars.
 *
 * <p>Simulation is side-neutral. Execution mutates the supplied stack only
 * on a logical server, never changes its label, and succeeds all-or-nothing.
 * Callers remain responsible for owning and synchronizing that stack.</p>
 */
public final class FilledJarEssentiaApi {

    private FilledJarEssentiaApi() {
    }

    /**
     * Capacity of the item identity on the selected logical side.
     */
    public static int capacity(ItemStack stack, boolean clientSide) {
        if (!isJar(stack))
            return 0;
        boolean voidJar = WardedJarBlockItem.kind(stack) == dev.tc4port.thaumcraft.block.WardedJarBlock.Kind.VOID;
        return EssentiaStorageApi.capacity(voidJar ? EssentiaStorageApi.VOID_JAR : EssentiaStorageApi.WARDED_JAR, 64, clientSide);
    }

    public static boolean isJar(ItemStack stack) {
        return WardedJarBlockItem.isJar(stack);
    }

    /**
     * Includes a label on an otherwise empty jar.
     */
    public static boolean hasStoredData(ItemStack stack) {
        return WardedJarBlockItem.hasStoredData(stack);
    }

    public static dev.tc4port.thaumcraft.api.aspect.AspectAmounts contents(ItemStack stack) {
        Objects.requireNonNull(stack, "stack");
        return isJar(stack) ? new dev.tc4port.thaumcraft.api.aspect.AspectAmounts((switch(0) {
            default ->
                {
                    dev.tc4port.thaumcraft.api.data.ItemStateKey<dev.tc4port.thaumcraft.data.AspectStackData> native$receiver$450 = TCItemState.ASPECTS;
                    net.minecraft.world.item.ItemStack native$argument$451 = stack;
                    dev.tc4port.thaumcraft.data.AspectStackData native$argument$452 = AspectStackData.EMPTY;
                    java.util.Objects.requireNonNull(native$receiver$450);
                    yield dev.tc4port.thaumcraft.api.item.ItemStatePlatform.getOrDefault(native$argument$451, native$receiver$450, native$argument$452);
                }
        }).aspects()) : dev.tc4port.thaumcraft.api.aspect.AspectAmounts.EMPTY;
    }

    /**
     * Moves up to requested units into a loaded core jar, debiting only accepted units.
     */
    public static int transferToJar(ServerLevel level, ItemStack source, net.minecraft.core.BlockPos target, int requested) {
        if (level == null || source == null || target == null || requested <= 0) {
            RuntimeWarnings.warnOnce("filled-jar-transfer", "Ignoring invalid filled jar transfer request");
            return 0;
        }
        if (!level.getServer().isSameThread() || !level.hasChunkAt(target) || source.getCount() != 1 || !isJar(source))
            return 0;
        AspectStackData stored = (switch(0) {
            default ->
                {
                    dev.tc4port.thaumcraft.api.data.ItemStateKey<dev.tc4port.thaumcraft.data.AspectStackData> native$receiver$492 = TCItemState.ASPECTS;
                    net.minecraft.world.item.ItemStack native$argument$493 = source;
                    dev.tc4port.thaumcraft.data.AspectStackData native$argument$494 = AspectStackData.EMPTY;
                    java.util.Objects.requireNonNull(native$receiver$492);
                    yield dev.tc4port.thaumcraft.api.item.ItemStatePlatform.getOrDefault(native$argument$493, native$receiver$492, native$argument$494);
                }
        });
        if (stored.aspects().size() != 1)
            return 0;
        var entry = stored.aspects().entrySet().iterator().next();
        if (entry.getValue() <= 0 || !(level.getBlockEntity(target) instanceof dev.tc4port.thaumcraft.block.entity.WardedJarBlockEntity jar) || !jar.accepts(entry.getKey()))
            return 0;
        int attempted = Math.min(requested, entry.getValue());
        int accepted = attempted - jar.addToContainer(entry.getKey(), attempted);
        if (accepted <= 0)
            return 0;
        int remaining = entry.getValue() - accepted;
        if (remaining == 0) {
            dev.tc4port.thaumcraft.api.data.ItemStateKey<dev.tc4port.thaumcraft.data.AspectStackData> native$receiver$799 = TCItemState.ASPECTS;
            net.minecraft.world.item.ItemStack native$argument$800 = source;
            java.util.Objects.requireNonNull(native$receiver$799);
            dev.tc4port.thaumcraft.api.item.ItemStatePlatform.remove(native$argument$800, native$receiver$799);
        } else {
            dev.tc4port.thaumcraft.api.data.ItemStateKey<dev.tc4port.thaumcraft.data.AspectStackData> native$receiver$801 = TCItemState.ASPECTS;
            net.minecraft.world.item.ItemStack native$argument$802 = source;
            dev.tc4port.thaumcraft.data.AspectStackData native$argument$803 = new AspectStackData(Map.of(entry.getKey(), remaining));
            java.util.Objects.requireNonNull(native$receiver$801);
            dev.tc4port.thaumcraft.api.item.ItemStatePlatform.set(native$argument$802, native$receiver$801, java.util.Objects.requireNonNull(native$argument$803, "value"));
        }
        return accepted;
    }

    public static Optional<FilledJarEssentiaView> view(ItemStack stack) {
        Objects.requireNonNull(stack, "stack");
        if (stack.isEmpty() || stack.getCount() != 1 || !(stack.getItem() instanceof WardedJarBlockItem)) {
            return Optional.empty();
        }
        AspectStackData stored = (switch(0) {
            default ->
                {
                    dev.tc4port.thaumcraft.api.data.ItemStateKey<dev.tc4port.thaumcraft.data.AspectStackData> native$receiver$495 = TCItemState.ASPECTS;
                    net.minecraft.world.item.ItemStack native$argument$496 = stack;
                    dev.tc4port.thaumcraft.data.AspectStackData native$argument$497 = AspectStackData.EMPTY;
                    java.util.Objects.requireNonNull(native$receiver$495);
                    yield dev.tc4port.thaumcraft.api.item.ItemStatePlatform.getOrDefault(native$argument$496, native$receiver$495, native$argument$497);
                }
        });
        if (stored.aspects().size() != 1) {
            return Optional.empty();
        }
        Map.Entry<AspectId, Integer> entry = stored.aspects().entrySet().iterator().next();
        if (entry.getValue() == null || entry.getValue() <= 0 || AspectApi.registry().get(entry.getKey()).isEmpty()) {
            return Optional.empty();
        }
        return Optional.of(new FilledJarEssentiaView(entry.getKey(), entry.getValue()));
    }

    /**
     * Returns {@code amount} on complete success and zero otherwise.
     */
    public static int extract(Level level, ItemStack stack, AspectId aspect, int amount, EssentiaTransferMode mode) {
        if (level == null || stack == null || aspect == null || mode == null || amount <= 0 || AspectApi.registry().get(aspect).isEmpty()) {
            RuntimeWarnings.warnOnce("filled-jar-extract", "Ignoring invalid filled jar extraction request");
            return 0;
        }
        FilledJarEssentiaView contents = view(stack).orElse(null);
        if (contents == null || !contents.aspect().equals(aspect) || contents.amount() < amount) {
            return 0;
        }
        if (!mode.executes()) {
            return amount;
        }
        if (!(level instanceof ServerLevel serverLevel) || !serverLevel.getServer().isSameThread()) {
            return 0;
        }
        int remaining = contents.amount() - amount;
        if (remaining == 0) {
            {
                dev.tc4port.thaumcraft.api.data.ItemStateKey<dev.tc4port.thaumcraft.data.AspectStackData> native$receiver$498 = TCItemState.ASPECTS;
                net.minecraft.world.item.ItemStack native$argument$499 = stack;
                java.util.Objects.requireNonNull(native$receiver$498);
                dev.tc4port.thaumcraft.api.item.ItemStatePlatform.remove(native$argument$499, native$receiver$498);
            }
        } else {
            {
                dev.tc4port.thaumcraft.api.data.ItemStateKey<dev.tc4port.thaumcraft.data.AspectStackData> native$receiver$500 = TCItemState.ASPECTS;
                net.minecraft.world.item.ItemStack native$argument$501 = stack;
                dev.tc4port.thaumcraft.data.AspectStackData native$argument$502 = new AspectStackData(Map.of(aspect, remaining));
                java.util.Objects.requireNonNull(native$receiver$500);
                dev.tc4port.thaumcraft.api.item.ItemStatePlatform.set(native$argument$501, native$receiver$500, java.util.Objects.requireNonNull(native$argument$502, "value"));
            }
        }
        return amount;
    }
}
