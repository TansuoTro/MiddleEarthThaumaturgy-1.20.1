package dev.tc4port.thaumcraft.block.entity;

import dev.tc4port.thaumcraft.api.event.GameplayHooks;
import dev.tc4port.thaumcraft.entity.AbstractCultistEntity;
import dev.tc4port.thaumcraft.entity.CultistClericEntity;
import dev.tc4port.thaumcraft.entity.CultistKnightEntity;
import dev.tc4port.thaumcraft.entity.EldritchGuardianEntity;
import dev.tc4port.thaumcraft.common.SpawnPlacementRules;
import dev.tc4port.thaumcraft.registry.TCBlockEntities;
import dev.tc4port.thaumcraft.registry.TCEntities;
import dev.tc4port.thaumcraft.worldgen.outer.OuterMazeData;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import java.lang.Integer;
import dev.tc4port.thaumcraft.nativeimpl.state.ItemFields;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityType;

/**
 * Persistent eye and cultist/guardian spawner state from
 * {@code TileEldritchAltar}.
 */
public final class EldritchAltarBlockEntity extends net.minecraft.world.level.block.entity.BlockEntity implements ItemFields.Source {

    private static final int[][] CLERIC_CORNERS = { { -2, -2 }, { -2, 2 }, { 2, -2 }, { 2, 2 } };

    private boolean spawner;

    private boolean open;

    private boolean spawnedClerics;

    private int clericCorners;

    private byte spawnType;

    private byte eyes;

    private int counter;

    public EldritchAltarBlockEntity(BlockPos pos, BlockState state) {
        super(TCBlockEntities.ELDRITCH_ALTAR.get(), pos, state);
    }

    public static void serverTick(Level level, BlockPos pos, BlockState state, EldritchAltarBlockEntity altar) {
        if (!(level instanceof ServerLevel server) || !altar.spawner) {
            return;
        }
        /*
         * Preserve the source's post-increment ordering. Its first spawn
         * attempt occurs when the stored counter advances from 119 to 120.
         */
        int previous = altar.counter++;
        if (previous < 80 || altar.counter % 40 != 0) {
            return;
        }
        if (altar.spawnType == 0) {
            if (!altar.spawnedClerics) {
                altar.spawnClerics(server);
            } else {
                altar.spawnGuards(server);
            }
        } else if (altar.spawnType == 1) {
            altar.spawnGuardian(server);
        }
    }

    private void spawnGuards(ServerLevel level) {
        AABB range = new AABB(this.worldPosition).inflate(24.0, 16.0, 24.0);
        if (level.getEntitiesOfClass(CultistClericEntity.class, range).isEmpty()) {
            // A block-ticking altar can outlive entity ticking in a corner
            // chunk. Do not retire it while its ritualists are invisible.
            for (int corner = 0; corner < CLERIC_CORNERS.length; corner++) {
                if ((this.clericCorners & (1 << corner)) != 0 && !isEntityChunkReady(level, clericCorner(corner))) {
                    return;
                }
            }
            this.spawner = false;
            this.changedAndSync();
            return;
        }
        if (level.getEntitiesOfClass(AbstractCultistEntity.class, range).size() >= 8) {
            return;
        }
        CultistKnightEntity knight = TCEntities.CULTIST_KNIGHT.get().create(level);
        if (knight == null) {
            return;
        }
        BlockPos candidate = randomCandidate(level);
        if (!hasSolidFloor(level, candidate)) {
            return;
        }
        knight.moveTo(candidate.getX(), candidate.getY(), candidate.getZ(), level.random.nextFloat() * 360.0F, 0.0F);
        spawnRestricted(level, knight, candidate, 16);
    }

    private void spawnGuardian(ServerLevel level) {
        this.trySpawnGuardianAt(level, randomCandidate(level));
    }

    /**
     * One source spawn attempt at an already selected coordinate. Keeping
     * this branch separate makes the complete collision and population
     * contract deterministic enough to regression-test.
     */
    public boolean trySpawnGuardianAt(ServerLevel level, BlockPos candidate) {
        EldritchGuardianEntity guardian = TCEntities.ELDRITCH_GUARDIAN.get().create(level);
        if (guardian == null) {
            return false;
        }
        if (!hasSolidFloor(level, candidate)) {
            return false;
        }
        guardian.moveTo(candidate.getX(), candidate.getY(), candidate.getZ(), level.random.nextFloat() * 360.0F, 0.0F);
        /*
         * Mob#checkSpawnRules is an always-true instance hook in 1.21. The
         * registered static predicate is what carries the source guardian's
         * 32x16x32 exclusion range, so invoke it directly here.
         */
        if (!EldritchGuardianEntity.checkSpawnRules(TCEntities.ELDRITCH_GUARDIAN.get(), level, MobSpawnType.SPAWNER, candidate, level.random) || !SpawnPlacementRules.hasClearVolume(level, guardian)) {
            return false;
        }
        GameplayHooks.finalizeMobSpawn(guardian, level, level.getCurrentDifficultyAt(candidate), MobSpawnType.SPAWNER, null);
        guardian.restrictTo(this.worldPosition, 16);
        if (!level.addFreshEntity(guardian)) {
            return false;
        }
        guardian.spawnAnim();
        return true;
    }

    private void spawnClerics(ServerLevel level) {
        boolean changed = false;
        for (int corner = 0; corner < CLERIC_CORNERS.length; corner++) {
            int bit = 1 << corner;
            if ((this.clericCorners & bit) != 0) {
                continue;
            }
            BlockPos candidate = clericCorner(corner);
            // A ticking chunk can still be asynchronously loading its
            // persisted entities. Wait before observing or spawning here.
            if (!isEntityChunkReady(level, candidate)) {
                continue;
            }
            if (!hasSolidFloor(level, candidate)) {
                continue;
            }
            CultistClericEntity cleric = TCEntities.CULTIST_CLERIC.get().create(level);
            if (cleric == null) {
                continue;
            }
            cleric.moveTo(candidate.getX() + 0.5, candidate.getY(), candidate.getZ() + 0.5, 0.0F, 0.0F);
            if (spawnRestricted(level, cleric, candidate, 8)) {
                this.clericCorners |= bit;
                changed = true;
            }
        }
        // Keep the source's three-corner transition, but never retry a
        // corner that already accepted its ritualist.
        if (!this.spawnedClerics && Integer.bitCount(this.clericCorners) >= 3) {
            this.spawnedClerics = true;
            changed = true;
        }
        if (changed) {
            this.changedAndSync();
        }
    }

    private BlockPos clericCorner(int corner) {
        return this.worldPosition.offset(CLERIC_CORNERS[corner][0], 0, CLERIC_CORNERS[corner][1]);
    }

    private static boolean isEntityChunkReady(ServerLevel level, BlockPos pos) {
        return level.isPositionEntityTicking(pos) && level.areEntitiesLoaded(ChunkPos.asLong(pos.getX() >> 4, pos.getZ() >> 4));
    }

    private boolean spawnRestricted(ServerLevel level, Mob mob, BlockPos candidate, int range) {
        if (!SpawnPlacementRules.hasClearVolume(level, mob)) {
            return false;
        }
        GameplayHooks.finalizeMobSpawn(mob, level, level.getCurrentDifficultyAt(candidate), MobSpawnType.SPAWNER, null);
        mob.restrictTo(this.worldPosition, range);
        if (mob instanceof CultistClericEntity cleric) {
            // FinalizeSpawn can randomize head yaw. Initialize the complete
            // ritual pose afterwards, before the first tracking/spawn packet.
            cleric.startRitual();
        }
        if (!level.addFreshEntity(mob)) {
            return false;
        }
        mob.spawnAnim();
        return true;
    }

    private BlockPos randomCandidate(ServerLevel level) {
        return this.worldPosition.offset(Mth.nextInt(level.random, 4, 10) * Mth.nextInt(level.random, -1, 1), Mth.nextInt(level.random, 0, 3) * Mth.nextInt(level.random, -1, 1), Mth.nextInt(level.random, 4, 10) * Mth.nextInt(level.random, -1, 1));
    }

    private static boolean hasSolidFloor(ServerLevel level, BlockPos candidate) {
        BlockPos floor = candidate.below();
        return level.getBlockState(floor).isFaceSturdy(level, floor, Direction.UP);
    }

    public void insertEye() {
        if (this.eyes >= 4) {
            return;
        }
        if (this.eyes >= 2) {
            this.spawner = true;
            this.spawnType = 1;
        }
        this.eyes++;
        this.checkForMaze();
        this.changedAndSync();
    }

    /**
     * Exact altar-side maze request. The old method started a raw thread and
     * returned false on the generating call; generation is now synchronous
     * and save-safe, while the return value retains that source contract.
     */
    public boolean checkForMaze() {
        if (!(this.level instanceof ServerLevel server)) {
            return false;
        }
        int chunkX = this.worldPosition.getX() >> 4;
        int chunkZ = this.worldPosition.getZ() >> 4;
        OuterMazeData data = OuterMazeData.get(server);
        return data.checkOrGenerateAltarMaze(chunkX, chunkZ, server.random);
    }

    public boolean spawner() {
        return this.spawner;
    }

    public void setSpawner(boolean spawner) {
        this.spawner = spawner;
        this.changedAndSync();
    }

    public byte spawnType() {
        return this.spawnType;
    }

    public void setSpawnType(byte spawnType) {
        this.spawnType = spawnType;
        this.changedAndSync();
    }

    public byte eyes() {
        return this.eyes;
    }

    public boolean open() {
        return this.open;
    }

    public void setOpen(boolean open) {
        this.open = open;
        this.changedAndSync();
    }

    public boolean spawnedClerics() {
        return this.spawnedClerics;
    }

    public int counter() {
        return this.counter;
    }

    private void changedAndSync() {
        this.setChanged();
        if (this.level != null) {
            this.level.sendBlockUpdated(this.worldPosition, this.getBlockState(), this.getBlockState(), 3);
        }
    }

    @Override
    public void load(CompoundTag tag) {
        int previous = this.eyes;
        super.load(tag);
        this.eyes = tag.getByte("eyes");
        this.open = tag.getBoolean("open");
        this.spawnedClerics = tag.getBoolean("spawnedClerics");
        this.clericCorners = tag.getByte("clericCorners") & 0xF;
        this.spawner = tag.getBoolean("spawner");
        this.spawnType = tag.getByte("spawntype");
        if (level != null && level.isClientSide && previous != this.eyes) {
            level.sendBlockUpdated(worldPosition, getBlockState(), getBlockState(), 3);
        }
    }

    @Override
    protected void saveAdditional(CompoundTag tag) {
        super.saveAdditional(tag);
        tag.putByte("eyes", this.eyes);
        tag.putBoolean("open", this.open);
        tag.putBoolean("spawnedClerics", this.spawnedClerics);
        tag.putByte("clericCorners", (byte) this.clericCorners);
        tag.putBoolean("spawner", this.spawner);
        tag.putByte("spawntype", this.spawnType);
    }

    @Override
    public CompoundTag getUpdateTag() {
        return this.saveWithoutMetadata();
    }

    @Override
    public Packet<ClientGamePacketListener> getUpdatePacket() {
        return ClientboundBlockEntityDataPacket.create(this);
    }

    protected final HolderLookup.Provider persistenceRegistries() {
        if (level != null)
            return level.registryAccess();
        var server = net.minecraftforge.server.ServerLifecycleHooks.getCurrentServer();
        return server != null ? server.registryAccess() : net.minecraft.core.RegistryAccess.fromRegistryOfRegistries(net.minecraft.core.registries.BuiltInRegistries.REGISTRY);
    }

    protected static net.minecraft.network.chat.Component parseCustomNameSafe(String value, HolderLookup.Provider registries) {
        try {
            return net.minecraft.network.chat.Component.Serializer.fromJson(value);
        } catch (RuntimeException exception) {
            return null;
        }
    }

    protected void readItemFields(ItemFields.Input input) {
    }

    public void copyItemFields(ItemFields.Output output) {
    }

    public void applyComponentsFromItemStack(ItemStack stack) {
        readItemFields(ItemFields.from(stack));
    }

    public void removeComponentsFromTag(CompoundTag tag) {
    }

    @Override
    public void saveToItem(ItemStack stack) {
        CompoundTag tag = saveWithoutMetadata();
        {
            net.minecraft.nbt.CompoundTag native$bodyOperand$6123 = tag;
            native$bodyReturn$6125: {
                if (true) {
                }
            }
        }
        net.minecraft.world.item.BlockItem.setBlockEntityData(stack, getType(), tag);
        copyItemFields(ItemFields.to(stack));
    }

    @Override
    public net.minecraft.world.phys.AABB getRenderBoundingBox() {
        return EldritchAltarBlockEntity.native$ClientBlockEntityBounds$bounds(this);
    }

    @Override()
    public void onDataPacket(net.minecraft.network.Connection connection, net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket packet) {
        handleUpdateTag(packet.getTag());
    }

    @SuppressWarnings({ "rawtypes", "unchecked" })
    static private net.minecraft.world.phys.AABB native$ClientBlockEntityBounds$bounds(net.minecraft.world.level.block.entity.BlockEntity blockEntity) {
        var renderer = net.minecraft.client.Minecraft.getInstance().getBlockEntityRenderDispatcher().getRenderer(blockEntity);
        return renderer instanceof dev.tc4port.thaumcraft.nativeimpl.NativeBlockEntityRenderer shared ? shared.getRenderBoundingBox(blockEntity) : new net.minecraft.world.phys.AABB(blockEntity.getBlockPos());
    }
}
