package dev.tc4port.thaumcraft.block.entity;

import dev.tc4port.thaumcraft.common.TCGameplayParameters;
import dev.tc4port.thaumcraft.block.AdvancedAlchemyFurnaceBlock;
import dev.tc4port.thaumcraft.api.aspect.AspectAmounts;
import dev.tc4port.thaumcraft.api.aspect.AspectContainerView;
import dev.tc4port.thaumcraft.api.aspect.AspectId;
import dev.tc4port.thaumcraft.api.aspect.VisChannel;
import dev.tc4port.thaumcraft.api.essentia.EssentiaTransferMode;
import dev.tc4port.thaumcraft.api.essentia.EssentiaTransport;
import dev.tc4port.thaumcraft.api.aspect.AspectQueryApi;
import dev.tc4port.thaumcraft.common.VisNetwork;
import dev.tc4port.thaumcraft.common.AdvancedFurnaceSettings;
import dev.tc4port.thaumcraft.registry.TCBlockEntities;
import java.util.LinkedHashMap;
import java.util.Map;
import javax.annotation.Nullable;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.Mth;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import java.lang.Math;
import dev.tc4port.thaumcraft.nativeimpl.state.ItemFields;
import net.minecraft.world.level.block.entity.BlockEntityType;

/**
 * TileAlchemyFurnaceAdvanced and its four metadata-one nozzles.
 */
public final class AdvancedAlchemyFurnaceBlockEntity extends net.minecraft.world.level.block.entity.BlockEntity implements EssentiaTransport, AspectContainerView, ItemFields.Source {

    public static final int MAX_VIS = 500;

    public static final int MAX_POWER = 500;

    private final LinkedHashMap<AspectId, Integer> aspects = new LinkedHashMap<>();

    private int visualFireCapacity = MAX_POWER;

    private int visualEssentiaCapacity = MAX_VIS;

    private int heat;

    private int entropyPower;

    private int waterPower;

    private int processed;

    private int count;

    public AdvancedAlchemyFurnaceBlockEntity(BlockPos pos, BlockState state) {
        super(TCBlockEntities.ADVANCED_ALCHEMY_FURNACE.get(), pos, state);
    }

    public static void serverTick(Level level, BlockPos pos, BlockState state, AdvancedAlchemyFurnaceBlockEntity furnace) {
        if (!(level instanceof ServerLevel server) || state.getValue(AdvancedAlchemyFurnaceBlock.PART) != AdvancedAlchemyFurnaceBlock.CORE) {
            return;
        }
        var capacities = AdvancedFurnaceSettings.capacities();
        int essentiaCapacity = dev.tc4port.thaumcraft.api.essentia.EssentiaStorageApi.capacity(dev.tc4port.thaumcraft.api.essentia.EssentiaStorageApi.ADVANCED_ALCHEMICAL_FURNACE, 500, false);
        furnace.count++;
        boolean changed = furnace.visualFireCapacity != capacities.fire() || furnace.visualEssentiaCapacity != essentiaCapacity;
        furnace.visualFireCapacity = capacities.fire();
        furnace.visualEssentiaCapacity = essentiaCapacity;
        if (furnace.processed > 0) {
            furnace.processed--;
        }
        if (furnace.count % TCGameplayParameters.ALCHEMY_ADVANCED_ALCHEMICAL_FURNACE_REFILL_INTERVAL.intValue() == 0) {
            int previousHeat = furnace.heat;
            // A disconnected Ignis supply must not accumulate a heat debt.
            furnace.heat = Math.max(0, furnace.heat - TCGameplayParameters.ALCHEMY_ADVANCED_ALCHEMICAL_FURNACE_HEAT_DECAY.intValue());
            if (furnace.heat < capacities.fire()) {
                int drained = VisNetwork.drain(server, pos, VisChannel.IGNIS, Math.min(TCGameplayParameters.ALCHEMY_ADVANCED_ALCHEMICAL_FURNACE_REFILL_CENTIVIS.intValue(), capacities.fire() - furnace.heat));
                furnace.heat += drained;
                changed |= drained > 0;
            }
            if (furnace.entropyPower < capacities.entropy()) {
                int drained = VisNetwork.drain(server, pos, VisChannel.PERDITIO, Math.min(TCGameplayParameters.ALCHEMY_ADVANCED_ALCHEMICAL_FURNACE_REFILL_CENTIVIS.intValue(), capacities.entropy() - furnace.entropyPower));
                furnace.entropyPower += drained;
                changed |= drained > 0;
            }
            if (furnace.waterPower < capacities.water()) {
                int drained = VisNetwork.drain(server, pos, VisChannel.AQUA, Math.min(TCGameplayParameters.ALCHEMY_ADVANCED_ALCHEMICAL_FURNACE_REFILL_CENTIVIS.intValue(), capacities.water() - furnace.waterPower));
                furnace.waterPower += drained;
                changed |= drained > 0;
            }
            changed |= previousHeat / 50 != furnace.heat / 50;
            changed |= (previousHeat > 100) != (furnace.heat > 100);
        }
        if (changed) {
            furnace.changedAndSync();
        }
    }

    public static void clientTick(Level level, BlockPos pos, BlockState state, AdvancedAlchemyFurnaceBlockEntity furnace) {
        dev.tc4port.thaumcraft.client.AdvancedFurnaceBubbleParticle.tickFurnace(level, pos, furnace);
    }

    public boolean process(ItemStack stack) {
        var capacities = AdvancedFurnaceSettings.capacities();
        int essentiaCapacity = dev.tc4port.thaumcraft.api.essentia.EssentiaStorageApi.capacity(dev.tc4port.thaumcraft.api.essentia.EssentiaStorageApi.ADVANCED_ALCHEMICAL_FURNACE, 500, false);
        if (!this.isCore() || this.processed != 0 || stack.isEmpty() || this.vis() >= essentiaCapacity) {
            return false;
        }
        Map<AspectId, Integer> resolved = AspectQueryApi.item(stack).amounts();
        if (resolved.isEmpty()) {
            return false;
        }
        long resolvedAmount = resolved.values().stream().mapToLong(Integer::longValue).sum();
        var costs = capacities.costs(resolvedAmount);
        if (resolvedAmount + this.vis() > essentiaCapacity || costs.fire() > this.heat || costs.entropy() > this.entropyPower || costs.water() > this.waterPower) {
            return false;
        }
        this.heat -= (int) costs.fire();
        this.entropyPower -= (int) costs.entropy();
        this.waterPower -= (int) costs.water();
        this.processed += (int) (TCGameplayParameters.ALCHEMY_ADVANCED_ALCHEMICAL_FURNACE_BASE_PROCESS_TICKS.floatValue() + Math.max(0.0F, (1.0F - this.heat / (float) capacities.fire()) * TCGameplayParameters.ALCHEMY_ADVANCED_ALCHEMICAL_FURNACE_COLD_PROCESS_TICKS.floatValue()));
        resolved.forEach((aspect, value) -> this.aspects.merge(aspect, value, Integer::sum));
        this.changedAndSync();
        return true;
    }

    public int vis() {
        return (int) Math.min(Integer.MAX_VALUE, this.aspects.values().stream().mapToLong(Integer::longValue).sum());
    }

    public int fireCapacity() {
        return this.visualFireCapacity;
    }

    public int essentiaCapacity() {
        return this.visualEssentiaCapacity;
    }

    public int heat() {
        return this.heat;
    }

    public int entropyPower() {
        return this.entropyPower;
    }

    public int waterPower() {
        return this.waterPower;
    }

    public int processed() {
        return this.processed;
    }

    public Map<AspectId, Integer> aspects() {
        return Map.copyOf(this.aspects);
    }

    @Override
    public AspectAmounts visibleAspects() {
        if (!this.isNozzle()) {
            return AspectAmounts.EMPTY;
        }
        AdvancedAlchemyFurnaceBlockEntity core = this.core();
        return core == null ? AspectAmounts.EMPTY : new AspectAmounts(core.aspects);
    }

    @Nullable
    public AdvancedAlchemyFurnaceBlockEntity core() {
        if (this.isCore()) {
            return this;
        }
        if (this.level == null || !this.isNozzle()) {
            return null;
        }
        for (Direction direction : Direction.values()) {
            BlockPos neighborPos = this.worldPosition.relative(direction);
            if (!this.level.isLoaded(neighborPos))
                continue;
            BlockEntity candidate = this.level.getBlockEntity(neighborPos);
            if (candidate instanceof AdvancedAlchemyFurnaceBlockEntity core && core.isCore()) {
                return core;
            }
        }
        return null;
    }

    @Nullable
    private Direction nozzleFacing() {
        AdvancedAlchemyFurnaceBlockEntity core = this.core();
        if (core == null || core == this) {
            return null;
        }
        int x = this.worldPosition.getX() - core.worldPosition.getX();
        int y = this.worldPosition.getY() - core.worldPosition.getY();
        int z = this.worldPosition.getZ() - core.worldPosition.getZ();
        return Direction.fromDelta(x, y, z);
    }

    private boolean isCore() {
        return this.getBlockState().getValue(AdvancedAlchemyFurnaceBlock.PART) == AdvancedAlchemyFurnaceBlock.CORE;
    }

    private boolean isNozzle() {
        return this.getBlockState().getValue(AdvancedAlchemyFurnaceBlock.PART) == AdvancedAlchemyFurnaceBlock.NOZZLE;
    }

    @Override
    public EssentiaTransport transferView() {
        AdvancedAlchemyFurnaceBlockEntity resolved = this.core();
        if (!this.isNozzle() || resolved == null)
            return this;
        Direction facing = Direction.fromDelta(this.worldPosition.getX() - resolved.worldPosition.getX(), this.worldPosition.getY() - resolved.worldPosition.getY(), this.worldPosition.getZ() - resolved.worldPosition.getZ());
        return new NozzleTransfer(resolved, facing);
    }

    private record NozzleTransfer(AdvancedAlchemyFurnaceBlockEntity core, Direction facing) implements EssentiaTransport {

        @Override
        public boolean isConnectable(Direction face) {
            return face == this.facing;
        }

        @Override
        public boolean canInputFrom(Direction face) {
            return false;
        }

        @Override
        public boolean canOutputTo(Direction face) {
            return this.isConnectable(face);
        }

        @Override
        public AspectId suctionType(Direction face) {
            return null;
        }

        @Override
        public int suctionAmount(Direction face) {
            return 0;
        }

        @Override
        public int takeEssentia(AspectId aspect, int amount, Direction face, EssentiaTransferMode mode) {
            return this.canOutputTo(face) ? this.core.takeFromCore(aspect, amount, mode) : 0;
        }

        @Override
        public int addEssentia(AspectId aspect, int amount, Direction face, EssentiaTransferMode mode) {
            return 0;
        }

        @Override
        public AspectId essentiaType(Direction face) {
            return this.core.essentiaType(face);
        }

        @Override
        public int essentiaAmount(Direction face) {
            return this.core.essentiaAmount(face);
        }

        @Override
        public int availableEssentia(AspectId aspect, Direction face) {
            return this.core.availableEssentia(aspect, face);
        }

        @Override
        public int minimumSuction() {
            return 0;
        }

        @Override
        public boolean renderExtendedTube() {
            return false;
        }
    }

    @Override
    public boolean isConnectable(Direction face) {
        return this.isNozzle() && face == this.nozzleFacing();
    }

    @Override
    public boolean canInputFrom(Direction face) {
        return false;
    }

    @Override
    public boolean canOutputTo(Direction face) {
        return this.isConnectable(face);
    }

    @Nullable
    @Override
    public AspectId suctionType(Direction face) {
        return null;
    }

    @Override
    public int suctionAmount(Direction face) {
        return 0;
    }

    @Override
    public int takeEssentia(AspectId aspect, int amount, Direction face, EssentiaTransferMode mode) {
        return this.transferView() instanceof NozzleTransfer view ? view.takeEssentia(aspect, amount, face, mode) : 0;
    }

    private int takeFromCore(AspectId aspect, int amount, EssentiaTransferMode mode) {
        if (amount <= 0 || !dev.tc4port.thaumcraft.aspect.AspectCatalog.contains(aspect) || this.aspects.getOrDefault(aspect, 0) < amount)
            return 0;
        if (!mode.executes())
            return amount;
        int remaining = this.aspects.get(aspect) - amount;
        if (remaining == 0)
            this.aspects.remove(aspect);
        else
            this.aspects.put(aspect, remaining);
        this.changedAndSync();
        return amount;
    }

    @Override
    public int addEssentia(AspectId aspect, int amount, Direction face, EssentiaTransferMode mode) {
        return 0;
    }

    @Nullable
    @Override
    public AspectId essentiaType(Direction face) {
        AdvancedAlchemyFurnaceBlockEntity core = this.core();
        return core == null ? null : core.aspects.entrySet().stream().filter(entry -> entry.getValue() > 0).map(Map.Entry::getKey).filter(dev.tc4port.thaumcraft.aspect.AspectCatalog::contains).findFirst().orElse(null);
    }

    @Override
    public int essentiaAmount(Direction face) {
        AdvancedAlchemyFurnaceBlockEntity core = this.core();
        AspectId aspect = core == null ? null : core.essentiaType(face);
        return core == null || aspect == null ? 0 : core.aspects.getOrDefault(aspect, 0);
    }

    @Override
    public int availableEssentia(AspectId aspect, Direction face) {
        AdvancedAlchemyFurnaceBlockEntity core = this.core();
        if (core == null || aspect == null || !dev.tc4port.thaumcraft.aspect.AspectCatalog.contains(aspect)) {
            return 0;
        }
        return core.aspects.getOrDefault(aspect, 0);
    }

    @Override
    public int minimumSuction() {
        return 0;
    }

    @Override
    public boolean renderExtendedTube() {
        return false;
    }

    private void changedAndSync() {
        this.setChanged();
        if (this.level == null || this.level.isClientSide) {
            return;
        }
        BlockState state = this.getBlockState();
        boolean lit = this.heat > 100;
        int light = lit ? Mth.clamp((int) (this.heat / (float) AdvancedFurnaceSettings.capacities().fire() * 12.0F), 0, 15) : 0;
        if (this.isCore() && (state.getValue(AdvancedAlchemyFurnaceBlock.LIT) != lit || state.getValue(AdvancedAlchemyFurnaceBlock.LIGHT) != light)) {
            this.level.setBlock(this.worldPosition, state.setValue(AdvancedAlchemyFurnaceBlock.LIT, lit).setValue(AdvancedAlchemyFurnaceBlock.LIGHT, light), Block.UPDATE_ALL);
        } else {
            this.level.sendBlockUpdated(this.worldPosition, state, state, Block.UPDATE_CLIENTS);
        }
    }

    @Override
    public void load(CompoundTag tag) {
        int previousAppearance = (heat() > 100 ? 1 : 0) | (vis() > 0 ? 2 : 0);
        super.load(tag);
        this.visualFireCapacity = tag.contains("fireCapacity") ? Math.max(1, tag.getInt("fireCapacity")) : MAX_POWER;
        this.visualEssentiaCapacity = tag.contains("essentiaCapacity") ? Math.max(1, tag.getInt("essentiaCapacity")) : MAX_VIS;
        this.heat = Math.max(0, tag.getInt("heat"));
        this.entropyPower = Math.max(0, tag.getInt("power1"));
        this.waterPower = Math.max(0, tag.getInt("power2"));
        this.aspects.clear();
        CompoundTag stored = tag.getCompound("aspects");
        for (String key : stored.getAllKeys()) {
            int amount = stored.getInt(key);
            AspectId aspect = parsePersistedAspect(key);
            if (amount > 0 && aspect != null) {
                this.aspects.merge(aspect, amount, Math::addExact);
            }
        }
        int appearance = (heat() > 100 ? 1 : 0) | (vis() > 0 ? 2 : 0);
        if (this.level != null && this.level.isClientSide && previousAppearance != appearance) {
            for (BlockPos part : BlockPos.betweenClosed(this.worldPosition.offset(-1, 0, -1), this.worldPosition.offset(1, 1, 1))) {
                BlockState state = this.level.getBlockState(part);
                this.level.sendBlockUpdated(part, state, state, 2);
            }
        }
    }

    @Override
    protected void saveAdditional(CompoundTag tag) {
        super.saveAdditional(tag);
        tag.putInt("fireCapacity", AdvancedFurnaceSettings.capacities().fire());
        tag.putInt("essentiaCapacity", dev.tc4port.thaumcraft.api.essentia.EssentiaStorageApi.capacity(dev.tc4port.thaumcraft.api.essentia.EssentiaStorageApi.ADVANCED_ALCHEMICAL_FURNACE, 500, false));
        tag.putInt("heat", this.heat);
        tag.putInt("power1", this.entropyPower);
        tag.putInt("power2", this.waterPower);
        CompoundTag stored = new CompoundTag();
        this.aspects.forEach((aspect, amount) -> stored.putInt(aspect.serialized(), amount));
        tag.put("aspects", stored);
    }

    @Nullable
    private static AspectId parsePersistedAspect(@Nullable String value) {
        try {
            return value == null || value.isBlank() ? null : AspectId.parse(value);
        } catch (RuntimeException ignored) {
            return null;
        }
    }

    @Override
    public CompoundTag getUpdateTag() {
        return this.saveWithoutMetadata();
    }

    @Override
    public Packet<ClientGamePacketListener> getUpdatePacket() {
        return ClientboundBlockEntityDataPacket.create(this);
    }

    protected final HolderLookup.Provider persistenceRegistries() {
        if (level != null)
            return level.registryAccess();
        var server = net.minecraftforge.server.ServerLifecycleHooks.getCurrentServer();
        return server != null ? server.registryAccess() : net.minecraft.core.RegistryAccess.fromRegistryOfRegistries(net.minecraft.core.registries.BuiltInRegistries.REGISTRY);
    }

    protected static net.minecraft.network.chat.Component parseCustomNameSafe(String value, HolderLookup.Provider registries) {
        try {
            return net.minecraft.network.chat.Component.Serializer.fromJson(value);
        } catch (RuntimeException exception) {
            return null;
        }
    }

    protected void readItemFields(ItemFields.Input input) {
    }

    public void copyItemFields(ItemFields.Output output) {
    }

    public void applyComponentsFromItemStack(ItemStack stack) {
        readItemFields(ItemFields.from(stack));
    }

    public void removeComponentsFromTag(CompoundTag tag) {
    }

    @Override
    public void saveToItem(ItemStack stack) {
        CompoundTag tag = saveWithoutMetadata();
        {
            net.minecraft.nbt.CompoundTag native$bodyOperand$6084 = tag;
            native$bodyReturn$6086: {
                if (true) {
                }
            }
        }
        net.minecraft.world.item.BlockItem.setBlockEntityData(stack, getType(), tag);
        copyItemFields(ItemFields.to(stack));
    }

    @Override
    public net.minecraft.world.phys.AABB getRenderBoundingBox() {
        return AdvancedAlchemyFurnaceBlockEntity.native$ClientBlockEntityBounds$bounds(this);
    }

    @Override()
    public void onDataPacket(net.minecraft.network.Connection connection, net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket packet) {
        handleUpdateTag(packet.getTag());
    }

    @SuppressWarnings({ "rawtypes", "unchecked" })
    static private net.minecraft.world.phys.AABB native$ClientBlockEntityBounds$bounds(net.minecraft.world.level.block.entity.BlockEntity blockEntity) {
        var renderer = net.minecraft.client.Minecraft.getInstance().getBlockEntityRenderDispatcher().getRenderer(blockEntity);
        return renderer instanceof dev.tc4port.thaumcraft.nativeimpl.NativeBlockEntityRenderer shared ? shared.getRenderBoundingBox(blockEntity) : new net.minecraft.world.phys.AABB(blockEntity.getBlockPos());
    }

    private boolean native$capabilitiesInvalid$16864;

    public boolean native$capabilityActive$16765;

    public net.minecraftforge.common.capabilities.Capability<dev.tc4port.thaumcraft.api.essentia.EssentiaTransport> native$capabilityCapture$16764;

    private net.minecraftforge.common.util.LazyOptional<dev.tc4port.thaumcraft.api.essentia.EssentiaTransport> native$capabilityHandle$16766;

    @Override
    public <native$capabilityResultType$16865> net.minecraftforge.common.util.LazyOptional<native$capabilityResultType$16865> getCapability(net.minecraftforge.common.capabilities.Capability<native$capabilityResultType$16865> native$requestedCapability$16866, net.minecraft.core.Direction native$requestedFace$16867) {
        getCapabilities();
        synchronized (this) {
            if (native$capabilitiesInvalid$16864)
                return net.minecraftforge.common.util.LazyOptional.empty();
            if (native$capabilityActive$16765 && native$requestedCapability$16866 == (this.native$capabilityCapture$16764)) {
                if (native$capabilityHandle$16766 == null)
                    native$capabilityHandle$16766 = net.minecraftforge.common.util.LazyOptional.of(() -> this);
                return native$capabilityHandle$16766.cast();
            }
        }
        return super.getCapability(native$requestedCapability$16866, native$requestedFace$16867);
    }

    @Override
    public void invalidateCaps() {
        java.util.List<net.minecraftforge.common.util.LazyOptional<?>> native$expiredCapabilities$16868 = new java.util.ArrayList<>();
        synchronized (this) {
            native$capabilitiesInvalid$16864 = true;
            if (native$capabilityHandle$16766 != null) {
                native$expiredCapabilities$16868.add(native$capabilityHandle$16766);
                native$capabilityHandle$16766 = null;
            }
        }
        try {
            super.invalidateCaps();
        } finally {
            native$expiredCapabilities$16868.forEach(net.minecraftforge.common.util.LazyOptional::invalidate);
        }
    }

    @Override
    public void reviveCaps() {
        super.reviveCaps();
        synchronized (this) {
            native$capabilitiesInvalid$16864 = false;
        }
    }
}
