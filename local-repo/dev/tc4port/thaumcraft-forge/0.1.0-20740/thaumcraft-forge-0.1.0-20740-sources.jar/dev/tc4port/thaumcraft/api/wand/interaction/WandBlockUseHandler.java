package dev.tc4port.thaumcraft.api.wand.interaction;

import javax.annotation.Nullable;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;

/**
 * Takes ownership before both built-in and addon foci. Register on both logical
 * sides. Selection must be side-effect-free and agree on both sides; perform
 * world/inventory/Vis changes only on the server, and local effects on the client.
 * Callbacks run on the owning game thread. No focus cost is charged by this API.
 */
public interface WandBlockUseHandler {

    /**
     * Target for air use, held ticks and local presentation; null declines.
     * Defaults to native block reach with fluids ignored. Override for a
     * different reach or fluid policy. Must be read-only on both logical sides.
     * Native block clicks supply their own hit; this method validates later aim.
     */
    @Nullable
    default BlockHitResult findTarget(Player player, float partialTick) {
        var eye = player.getEyePosition(partialTick);
        var look = player.level().isClientSide ? player.getViewVector(partialTick) : player.getLookAngle();
        var hit = player.level().clip(new ClipContext(eye, eye.add(look.scale((switch(0) {
            default ->
                {
                    net.minecraft.world.entity.player.Player native$operand$12891 = player;
                    double native$result$12892 = (native$operand$12891.getBlockReach());
                    yield native$result$12892;
                }
        }))), ClipContext.Block.OUTLINE, ClipContext.Fluid.NONE, player));
        return hit.getType() == HitResult.Type.BLOCK ? hit : null;
    }

    /**
     * False declines this registration, allowing other handlers or normal use.
     */
    default boolean canStart(WandBlockUseContext context) {
        return true;
    }

    /**
     * Called once after the native held-use state starts.
     */
    default void onStart(WandBlockUseContext context) {
    }

    /**
     * Called once per native use tick, independent of a custom wand's focus
     * iteration multiplier. Return false to end use without casting this tick.
     */
    default boolean onTick(WandBlockUseContext context) {
        return true;
    }

    /**
     * Called once per started session, including release or invalidation.
     */
    default void onStop(WandBlockUseContext context) {
    }
}
