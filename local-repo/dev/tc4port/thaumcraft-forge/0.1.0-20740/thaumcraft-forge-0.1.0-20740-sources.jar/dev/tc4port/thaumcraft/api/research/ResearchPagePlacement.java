package dev.tc4port.thaumcraft.api.research;

import java.util.Objects;

/**
 * Physical presentation placement; page numbers are one-based.
 */
public record ResearchPagePlacement(Mode mode, int page, int x, int y, int width, int height, int zIndex) {

    public ResearchPagePlacement {
        Objects.requireNonNull(mode, "mode");
        if ((mode == Mode.INSERT || mode == Mode.OVERLAY) ? page < 1 : page != 0) {
            throw new IllegalArgumentException("Only INSERT and OVERLAY have a positive page number");
        }
        if (mode == Mode.OVERLAY) {
            if (x < 0 || x >= 139 || y < 0 || y >= 198 || width < 1 || width > 139 || height < 1 || height > 198) {
                throw new IllegalArgumentException("Overlay must have a bounded rectangle in a book page");
            }
        } else if (x != 0 || y != 0 || width != 0 || height != 0 || zIndex != 0) {
            throw new IllegalArgumentException("Only OVERLAY has page coordinates and a stacking order");
        }
    }

    public ResearchPagePlacement(Mode mode, int page) {
        this(mode, page, 0, 0, 0, 0, 0);
    }

    public static ResearchPagePlacement flow() {
        return new ResearchPagePlacement(Mode.FLOW, 0);
    }

    public static ResearchPagePlacement ordered() {
        return new ResearchPagePlacement(Mode.ORDERED, 0);
    }

    public static ResearchPagePlacement append() {
        return new ResearchPagePlacement(Mode.APPEND, 0);
    }

    public static ResearchPagePlacement insert(int page) {
        return new ResearchPagePlacement(Mode.INSERT, page);
    }

    public static ResearchPagePlacement overlay(int page, int x, int y, int width, int height, int zIndex) {
        return new ResearchPagePlacement(Mode.OVERLAY, page, x, y, width, height, zIndex);
    }

    public enum Mode {

        FLOW, INSERT, APPEND, ORDERED, OVERLAY
    }
}
