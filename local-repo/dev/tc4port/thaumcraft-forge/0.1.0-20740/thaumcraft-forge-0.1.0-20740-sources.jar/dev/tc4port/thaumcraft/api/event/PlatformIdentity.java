package dev.tc4port.thaumcraft.api.event;

/**
 * Build-provided identity; no consumer is selected by the source library.
 */
public final class PlatformIdentity {

    private PlatformIdentity() {
    }

    public static final String NAMESPACE = "thaumcraft";
}
