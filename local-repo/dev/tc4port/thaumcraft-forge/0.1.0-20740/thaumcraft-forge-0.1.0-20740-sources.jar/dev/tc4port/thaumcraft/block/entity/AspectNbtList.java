package dev.tc4port.thaumcraft.block.entity;

import dev.tc4port.thaumcraft.api.aspect.AspectId;
import java.util.LinkedHashMap;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;

/**
 * Current ordered {@code key}/{@code amount} aspect-list encoding.
 */
final class AspectNbtList {

    private static final String FIELD = "Aspects";

    private AspectNbtList() {
    }

    static void loadInto(CompoundTag tag, LinkedHashMap<AspectId, Integer> destination) {
        destination.clear();
        ListTag stored = tag.getList(FIELD, Tag.TAG_COMPOUND);
        for (int index = 0; index < stored.size(); index++) {
            CompoundTag entry = stored.getCompound(index);
            AspectId canonical = parse(entry.getString("key"));
            int amount = entry.getInt("amount");
            if (amount > 0 && canonical != null) {
                destination.merge(canonical, amount, Integer::sum);
            }
        }
    }

    static void saveFrom(CompoundTag tag, LinkedHashMap<AspectId, Integer> source) {
        ListTag stored = new ListTag();
        source.forEach((aspect, amount) -> {
            CompoundTag entry = new CompoundTag();
            entry.putString("key", aspect.serialized());
            entry.putInt("amount", amount);
            stored.add(entry);
        });
        tag.put(FIELD, stored);
    }

    private static AspectId parse(String value) {
        try {
            return value == null || value.isBlank() ? null : AspectId.parse(value);
        } catch (RuntimeException ignored) {
            return null;
        }
    }
}
