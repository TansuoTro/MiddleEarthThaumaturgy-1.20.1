package dev.tc4port.thaumcraft.api.wand;

/**
 * Shared bounds for runtime and data-defined wand assembly coefficients.
 */
public final class WandPartLimits {

    public static final int MAX_CRAFT_COST = 3_783;

    private WandPartLimits() {
    }
}
