package dev.tc4port.thaumcraft.block.entity;

import dev.tc4port.thaumcraft.common.ArcaneOwnedBlockEntity;
import java.util.HashSet;
import java.util.Set;
import java.util.UUID;
import javax.annotation.Nullable;
import net.minecraft.core.BlockPos;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockState;
import dev.tc4port.thaumcraft.nativeimpl.state.ItemFields;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.entity.BlockEntity;

/**
 * UUID-based modern form of TC4's shared TileOwned state.
 *
 * <p>Source access entries prefixed the player name with zero for ordinary
 * access or one for administrative access. Separate UUID sets preserve that
 * distinction without making ownership depend on mutable profile names.</p>
 */
public abstract class AbstractArcaneOwnedBlockEntity extends net.minecraft.world.level.block.entity.BlockEntity implements ArcaneOwnedBlockEntity, ItemFields.Source {

    private static final String OWNER_KEY = "owner";

    private static final String ACCESS_KEY = "access";

    private static final String PLAYER_KEY = "player";

    private static final String ADMIN_KEY = "admin";

    @Nullable
    private UUID owner;

    private final Set<UUID> access = new HashSet<>();

    private final Set<UUID> administrators = new HashSet<>();

    protected AbstractArcaneOwnedBlockEntity(BlockEntityType<?> type, BlockPos pos, BlockState state) {
        super(type, pos, state);
    }

    public void setOwner(Player player) {
        this.setOwner(player.getUUID());
    }

    public void setOwner(UUID player) {
        this.owner = player;
        this.markUpdated();
    }

    @Nullable
    public UUID ownerId() {
        return this.owner;
    }

    public boolean isOwner(Player player) {
        return this.isOwner(player.getUUID());
    }

    public boolean isOwner(UUID player) {
        return this.owner != null && this.owner.equals(player);
    }

    public boolean isAuthorized(Player player) {
        return this.isAuthorized(player.getUUID());
    }

    public boolean isAuthorized(UUID player) {
        return this.isOwner(player) || this.access.contains(player) || this.administrators.contains(player);
    }

    public Set<UUID> authorizedPlayerIds() {
        Set<UUID> players = new HashSet<>(this.access);
        players.addAll(this.administrators);
        if (this.owner != null) {
            players.add(this.owner);
        }
        return Set.copyOf(players);
    }

    public boolean canAdminister(Player player) {
        return this.isOwner(player) || this.administrators.contains(player.getUUID());
    }

    public boolean canCreateKey(Player player, boolean gold) {
        return gold ? this.isOwner(player) : this.canAdminister(player);
    }

    public boolean grant(Player player, boolean gold) {
        UUID id = player.getUUID();
        if (this.isAuthorized(id)) {
            return false;
        }
        if (gold) {
            this.administrators.add(id);
        } else {
            this.access.add(id);
        }
        this.markUpdated();
        return true;
    }

    public void copyPermissionsFrom(AbstractArcaneOwnedBlockEntity source) {
        this.owner = source.owner;
        this.access.clear();
        this.access.addAll(source.access);
        this.administrators.clear();
        this.administrators.addAll(source.administrators);
        this.markUpdated();
    }

    protected void markUpdated() {
        this.setChanged();
        if (this.level != null && !this.level.isClientSide) {
            this.level.sendBlockUpdated(this.worldPosition, this.getBlockState(), this.getBlockState(), Block.UPDATE_CLIENTS);
        }
    }

    @Override
    public void load(CompoundTag tag) {
        super.load(tag);
        this.owner = tag.hasUUID(OWNER_KEY) ? tag.getUUID(OWNER_KEY) : null;
        this.access.clear();
        this.administrators.clear();
        ListTag stored = tag.getList(ACCESS_KEY, Tag.TAG_COMPOUND);
        for (int index = 0; index < stored.size(); index++) {
            CompoundTag entry = stored.getCompound(index);
            if (!entry.hasUUID(PLAYER_KEY)) {
                continue;
            }
            UUID player = entry.getUUID(PLAYER_KEY);
            if (entry.getBoolean(ADMIN_KEY)) {
                this.administrators.add(player);
            } else {
                this.access.add(player);
            }
        }
    }

    @Override
    protected void saveAdditional(CompoundTag tag) {
        super.saveAdditional(tag);
        if (this.owner != null) {
            tag.putUUID(OWNER_KEY, this.owner);
        }
        ListTag stored = new ListTag();
        this.access.forEach(player -> stored.add(accessTag(player, false)));
        this.administrators.forEach(player -> stored.add(accessTag(player, true)));
        tag.put(ACCESS_KEY, stored);
    }

    private static CompoundTag accessTag(UUID player, boolean admin) {
        CompoundTag tag = new CompoundTag();
        tag.putUUID(PLAYER_KEY, player);
        tag.putBoolean(ADMIN_KEY, admin);
        return tag;
    }

    @Override
    public CompoundTag getUpdateTag() {
        return this.saveWithoutMetadata();
    }

    @Override
    public Packet<ClientGamePacketListener> getUpdatePacket() {
        return ClientboundBlockEntityDataPacket.create(this);
    }

    protected final HolderLookup.Provider persistenceRegistries() {
        if (level != null)
            return level.registryAccess();
        var server = net.minecraftforge.server.ServerLifecycleHooks.getCurrentServer();
        return server != null ? server.registryAccess() : net.minecraft.core.RegistryAccess.fromRegistryOfRegistries(net.minecraft.core.registries.BuiltInRegistries.REGISTRY);
    }

    protected static net.minecraft.network.chat.Component parseCustomNameSafe(String value, HolderLookup.Provider registries) {
        try {
            return net.minecraft.network.chat.Component.Serializer.fromJson(value);
        } catch (RuntimeException exception) {
            return null;
        }
    }

    protected void readItemFields(ItemFields.Input input) {
    }

    public void copyItemFields(ItemFields.Output output) {
    }

    public void applyComponentsFromItemStack(ItemStack stack) {
        readItemFields(ItemFields.from(stack));
    }

    public void removeComponentsFromTag(CompoundTag tag) {
    }

    @Override
    public void saveToItem(ItemStack stack) {
        CompoundTag tag = saveWithoutMetadata();
        removeComponentsFromTag(tag);
        net.minecraft.world.item.BlockItem.setBlockEntityData(stack, getType(), tag);
        copyItemFields(ItemFields.to(stack));
    }

    @Override
    public net.minecraft.world.phys.AABB getRenderBoundingBox() {
        return AbstractArcaneOwnedBlockEntity.native$ClientBlockEntityBounds$bounds(this);
    }

    @Override()
    public void onDataPacket(net.minecraft.network.Connection connection, net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket packet) {
        handleUpdateTag(packet.getTag());
    }

    @SuppressWarnings({ "rawtypes", "unchecked" })
    static private net.minecraft.world.phys.AABB native$ClientBlockEntityBounds$bounds(net.minecraft.world.level.block.entity.BlockEntity blockEntity) {
        var renderer = net.minecraft.client.Minecraft.getInstance().getBlockEntityRenderDispatcher().getRenderer(blockEntity);
        return renderer instanceof dev.tc4port.thaumcraft.nativeimpl.NativeBlockEntityRenderer shared ? shared.getRenderBoundingBox(blockEntity) : new net.minecraft.world.phys.AABB(blockEntity.getBlockPos());
    }
}
