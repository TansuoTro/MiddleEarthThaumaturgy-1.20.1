package dev.tc4port.thaumcraft.api.champion;

import java.util.List;
import java.util.Objects;

/**
 * Immutable global rules used by server-authoritative assignment.
 */
public record ChampionSettings(List<ChampionAttributeModifier> baseAttributeModifiers, float initialHealHealthPoints, ChampionId creeperSubstituteId, java.util.Map<String, Double> spawnRules) {

    public ChampionSettings {
        baseAttributeModifiers = List.copyOf(baseAttributeModifiers);
        Objects.requireNonNull(creeperSubstituteId, "creeperSubstituteId");
        spawnRules = ChampionNumbers.validate(spawnRules, true);
        if (!Float.isFinite(initialHealHealthPoints) || initialHealHealthPoints < 0.0F) {
            throw new IllegalArgumentException("Initial champion healing must be finite and non-negative");
        }
    }

    public int integer(String name, int fallback) {
        return spawnRules.getOrDefault(name, (double) fallback).intValue();
    }

    public double number(String name, double fallback) {
        return spawnRules.getOrDefault(name, fallback);
    }
}
