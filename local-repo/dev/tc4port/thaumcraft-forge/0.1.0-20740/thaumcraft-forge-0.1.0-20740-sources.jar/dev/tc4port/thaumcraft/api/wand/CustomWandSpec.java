package dev.tc4port.thaumcraft.api.wand;

import java.util.Objects;

/**
 * Bounded behavior contract for an addon-owned focus-casting carrier.
 *
 * @param rod rod identity used for recharge behavior and presentation
 * @param cap cap identity used for aspect-specific casting cost
 * @param capacityCentivis capacity of every primal channel in centivis
 * @param staffPower whether focus origin/power treats this as a staff
 * @param requiresBothHands whether the opposite hand must remain empty
 * @param supportsArcaneCrafting whether the carrier may enter the worktable
 * @param capCostDivisor divisor applied to the selected cap cost
 * @param frugalDiscountDivisor divisor for each Frugal focus level
 * @param continuousIterations focus calls per native use tick; block callbacks and node absorption run once
 * @param cooldownMultiplier multiplier applied to positive focus cooldowns
 */
public record CustomWandSpec(WandMaterialId rod, WandMaterialId cap, int capacityCentivis, boolean staffPower, boolean requiresBothHands, boolean supportsArcaneCrafting, float capCostDivisor, float frugalDiscountDivisor, int continuousIterations, float cooldownMultiplier) {

    public static final int MAX_CAPACITY_CENTIVIS = 10_000_000;

    public CustomWandSpec {
        rod = Objects.requireNonNull(rod, "rod");
        cap = Objects.requireNonNull(cap, "cap");
        if (capacityCentivis <= 0 || capacityCentivis > MAX_CAPACITY_CENTIVIS) {
            throw new IllegalArgumentException("Custom wand capacity must be from 1 to " + MAX_CAPACITY_CENTIVIS + " centivis");
        }
        if (!Float.isFinite(capCostDivisor) || capCostDivisor <= 0.0F || !Float.isFinite(frugalDiscountDivisor) || frugalDiscountDivisor <= 0.0F || continuousIterations < 1 || continuousIterations > 4 || !Float.isFinite(cooldownMultiplier) || cooldownMultiplier <= 0.0F || cooldownMultiplier > 10.0F) {
            throw new IllegalArgumentException("Custom wand modifiers must be finite and positive; " + "continuous iterations must be from 1 to 4");
        }
    }
}
