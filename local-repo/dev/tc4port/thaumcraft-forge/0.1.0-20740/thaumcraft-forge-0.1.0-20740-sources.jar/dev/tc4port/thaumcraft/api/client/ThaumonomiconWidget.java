package dev.tc4port.thaumcraft.api.client;

import java.util.List;
import net.minecraft.client.renderer.Rect2i;

/**
 * Optional lifecycle and overlay geometry for widgets registered through ThaumonomiconApi.
 */
public interface ThaumonomiconWidget {

    /**
     * Called after book initialization/resizing and before each book render.
     */
    default void updateBook() {
    }

    /**
     * Explicit navigation, including locating another entry in the same category.
     */
    default void bookNavigated() {
    }

    /**
     * Occupied overlay regions for recipe-viewer layout, in GUI coordinates.
     */
    List<Rect2i> overlayBounds();

    /**
     * Separate tooltip occlusion from a widget's possibly larger input region.
     */
    boolean blocksBookTooltips(double x, double y);
}
