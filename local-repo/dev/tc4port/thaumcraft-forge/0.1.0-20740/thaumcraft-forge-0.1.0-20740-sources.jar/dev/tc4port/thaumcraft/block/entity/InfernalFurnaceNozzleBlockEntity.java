package dev.tc4port.thaumcraft.block.entity;

import dev.tc4port.thaumcraft.api.aspect.AspectId;
import dev.tc4port.thaumcraft.api.essentia.EssentiaApi;
import dev.tc4port.thaumcraft.api.essentia.EssentiaTransferMode;
import dev.tc4port.thaumcraft.api.essentia.EssentiaTransport;
import dev.tc4port.thaumcraft.registry.TCBlockEntities;
import javax.annotation.Nullable;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import dev.tc4port.thaumcraft.nativeimpl.state.ItemFields;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.entity.BlockEntityType;

/**
 * Recipe-configured essentia intake on the formed furnace's side and bottom obsidian ports.
 */
public final class InfernalFurnaceNozzleBlockEntity extends net.minecraft.world.level.block.entity.BlockEntity implements EssentiaTransport, ItemFields.Source {

    private int drawDelay;

    public InfernalFurnaceNozzleBlockEntity(BlockPos pos, BlockState state) {
        super(TCBlockEntities.INFERNAL_FURNACE_NOZZLE.get(), pos, state);
    }

    public static void serverTick(Level level, BlockPos pos, BlockState state, InfernalFurnaceNozzleBlockEntity nozzle) {
        InfernalFurnaceBlockEntity furnace = nozzle.furnace();
        var settings = furnace == null ? null : furnace.processing();
        if (settings == null || !settings.boosted() || !furnace.acceptsBoost(settings.aspect()) || settings.get("essentia_ticks_per_unit") == 0 || furnace.speedyTime() >= settings.get("essentia_refill_threshold") || ++nozzle.drawDelay % settings.get("essentia_interval") != 0) {
            return;
        }
        Direction outward = nozzle.outwardFrom(furnace.getBlockPos());
        if (outward == null) {
            return;
        }
        BlockPos neighborPos = pos.relative(outward);
        if (!level.isLoaded(neighborPos))
            return;
        EssentiaTransport transport = EssentiaApi.transport(level, neighborPos, outward.getOpposite());
        if (transport == null) {
            return;
        }
        Direction neighborFace = outward.getOpposite();
        if (!transport.isConnectable(neighborFace) || !transport.canOutputTo(neighborFace) || transport.suctionAmount(neighborFace) >= nozzle.suctionAmount(outward)) {
            return;
        }
        if (EssentiaApi.take(level, transport, settings.aspect().aspectId(), 1, neighborFace, EssentiaTransferMode.EXECUTE) == 1) {
            furnace.addSpeedyTime(settings.get("essentia_ticks_per_unit"));
        }
    }

    @Nullable
    private InfernalFurnaceBlockEntity furnace() {
        if (this.level == null) {
            return null;
        }
        for (Direction direction : Direction.values()) {
            BlockPos neighborPos = this.worldPosition.relative(direction);
            if (!this.level.isLoaded(neighborPos))
                continue;
            BlockEntity blockEntity = this.level.getBlockEntity(neighborPos);
            if (blockEntity instanceof InfernalFurnaceBlockEntity furnace) {
                return furnace;
            }
        }
        return null;
    }

    @Nullable
    private Direction outwardFrom(BlockPos furnacePos) {
        // The eligible tick already resolved its adjacent furnace. Derive only
        // this direction from that lookup; later suction queries remain live
        // after neighboring transports have run their callbacks.
        for (Direction direction : Direction.values()) {
            if (this.worldPosition.relative(direction).equals(furnacePos)) {
                return direction.getOpposite();
            }
        }
        return null;
    }

    @Nullable
    private Direction outward() {
        InfernalFurnaceBlockEntity furnace = this.furnace();
        return furnace == null ? null : this.outwardFrom(furnace.getBlockPos());
    }

    @Override
    public boolean isConnectable(Direction face) {
        return this.outward() != null;
    }

    @Override
    public boolean canInputFrom(Direction face) {
        return this.outward() != null;
    }

    @Override
    public boolean canOutputTo(Direction face) {
        return false;
    }

    @Nullable
    @Override
    public AspectId suctionType(Direction face) {
        var furnace = this.furnace();
        return furnace == null ? null : furnace.essentiaSuctionType();
    }

    @Override
    public int suctionAmount(Direction face) {
        InfernalFurnaceBlockEntity furnace = this.furnace();
        return furnace == null ? 0 : furnace.essentiaSuction();
    }

    @Override
    public int takeEssentia(AspectId aspect, int amount, Direction face, EssentiaTransferMode mode) {
        return 0;
    }

    @Override
    public int addEssentia(AspectId aspect, int amount, Direction face, EssentiaTransferMode mode) {
        return 0;
    }

    @Nullable
    @Override
    public AspectId essentiaType(Direction face) {
        return null;
    }

    @Override
    public int essentiaAmount(Direction face) {
        return 0;
    }

    @Override
    public int minimumSuction() {
        return 0;
    }

    @Override
    public boolean renderExtendedTube() {
        return false;
    }

    protected final HolderLookup.Provider persistenceRegistries() {
        if (level != null)
            return level.registryAccess();
        var server = net.minecraftforge.server.ServerLifecycleHooks.getCurrentServer();
        return server != null ? server.registryAccess() : net.minecraft.core.RegistryAccess.fromRegistryOfRegistries(net.minecraft.core.registries.BuiltInRegistries.REGISTRY);
    }

    protected static net.minecraft.network.chat.Component parseCustomNameSafe(String value, HolderLookup.Provider registries) {
        try {
            return net.minecraft.network.chat.Component.Serializer.fromJson(value);
        } catch (RuntimeException exception) {
            return null;
        }
    }

    protected void readItemFields(ItemFields.Input input) {
    }

    public void copyItemFields(ItemFields.Output output) {
    }

    public void applyComponentsFromItemStack(ItemStack stack) {
        readItemFields(ItemFields.from(stack));
    }

    public void removeComponentsFromTag(CompoundTag tag) {
    }

    @Override
    public void saveToItem(ItemStack stack) {
        CompoundTag tag = saveWithoutMetadata();
        {
            net.minecraft.nbt.CompoundTag native$bodyOperand$6167 = tag;
            native$bodyReturn$6169: {
                if (true) {
                }
            }
        }
        net.minecraft.world.item.BlockItem.setBlockEntityData(stack, getType(), tag);
        copyItemFields(ItemFields.to(stack));
    }

    @Override
    public net.minecraft.world.phys.AABB getRenderBoundingBox() {
        return InfernalFurnaceNozzleBlockEntity.native$ClientBlockEntityBounds$bounds(this);
    }

    @Override()
    public void onDataPacket(net.minecraft.network.Connection connection, net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket packet) {
        handleUpdateTag(packet.getTag());
    }

    @SuppressWarnings({ "rawtypes", "unchecked" })
    static private net.minecraft.world.phys.AABB native$ClientBlockEntityBounds$bounds(net.minecraft.world.level.block.entity.BlockEntity blockEntity) {
        var renderer = net.minecraft.client.Minecraft.getInstance().getBlockEntityRenderDispatcher().getRenderer(blockEntity);
        return renderer instanceof dev.tc4port.thaumcraft.nativeimpl.NativeBlockEntityRenderer shared ? shared.getRenderBoundingBox(blockEntity) : new net.minecraft.world.phys.AABB(blockEntity.getBlockPos());
    }

    private boolean native$capabilitiesInvalid$16909;

    public boolean native$capabilityActive$16765;

    public net.minecraftforge.common.capabilities.Capability<dev.tc4port.thaumcraft.api.essentia.EssentiaTransport> native$capabilityCapture$16764;

    private net.minecraftforge.common.util.LazyOptional<dev.tc4port.thaumcraft.api.essentia.EssentiaTransport> native$capabilityHandle$16766;

    @Override
    public <native$capabilityResultType$16910> net.minecraftforge.common.util.LazyOptional<native$capabilityResultType$16910> getCapability(net.minecraftforge.common.capabilities.Capability<native$capabilityResultType$16910> native$requestedCapability$16911, net.minecraft.core.Direction native$requestedFace$16912) {
        getCapabilities();
        synchronized (this) {
            if (native$capabilitiesInvalid$16909)
                return net.minecraftforge.common.util.LazyOptional.empty();
            if (native$capabilityActive$16765 && native$requestedCapability$16911 == (this.native$capabilityCapture$16764)) {
                if (native$capabilityHandle$16766 == null)
                    native$capabilityHandle$16766 = net.minecraftforge.common.util.LazyOptional.of(() -> this);
                return native$capabilityHandle$16766.cast();
            }
        }
        return super.getCapability(native$requestedCapability$16911, native$requestedFace$16912);
    }

    @Override
    public void invalidateCaps() {
        java.util.List<net.minecraftforge.common.util.LazyOptional<?>> native$expiredCapabilities$16913 = new java.util.ArrayList<>();
        synchronized (this) {
            native$capabilitiesInvalid$16909 = true;
            if (native$capabilityHandle$16766 != null) {
                native$expiredCapabilities$16913.add(native$capabilityHandle$16766);
                native$capabilityHandle$16766 = null;
            }
        }
        try {
            super.invalidateCaps();
        } finally {
            native$expiredCapabilities$16913.forEach(net.minecraftforge.common.util.LazyOptional::invalidate);
        }
    }

    @Override
    public void reviveCaps() {
        super.reviveCaps();
        synchronized (this) {
            native$capabilitiesInvalid$16909 = false;
        }
    }
}
