package dev.tc4port.thaumcraft.api.node;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.Objects;
import java.util.Optional;
import java.util.UUID;
import net.minecraft.core.UUIDUtil;

/**
 * Immutable, typed aura-node state. Aspect amounts are whole Vis, not
 * centivis. Unknown namespaced type/modifier identities are retained for
 * forward-readable storage, but the closed built-in catalog
 * treats them as neutral/inactive identities.
 *
 * <p>A present {@code instanceId} is the persistent scan identity and must be
 * unique, stable for the logical node's lifetime, and synchronized to clients.
 * Empty selects the dimension-and-block-position fallback for fixed owners.
 */
public record AuraNodeState(Optional<UUID> instanceId, NodeTypeId type, NodeModifierId modifier, NodeVis baseVis, NodeVis currentVis) {

    public static final AuraNodeState EMPTY = new AuraNodeState(Optional.empty(), NodeTypeId.NORMAL, NodeModifierId.NONE, NodeVis.EMPTY, NodeVis.EMPTY);

    public static final Codec<AuraNodeState> CODEC = RecordCodecBuilder.create(instance -> instance.group(AuraNodeState.native$StrictOptionalFields$of(UUIDUtil.STRING_CODEC, "id").forGetter(AuraNodeState::instanceId), AuraNodeState.native$StrictOptionalFields$of(NodeTypeId.CODEC, "type", NodeTypeId.NORMAL).forGetter(AuraNodeState::type), AuraNodeState.native$StrictOptionalFields$of(NodeModifierId.CODEC, "modifier", NodeModifierId.NONE).forGetter(AuraNodeState::modifier), AuraNodeState.native$StrictOptionalFields$of(NodeVis.CODEC, "base_aspects", NodeVis.EMPTY).forGetter(AuraNodeState::baseVis), AuraNodeState.native$StrictOptionalFields$of(NodeVis.CODEC, "current_aspects", NodeVis.EMPTY).forGetter(AuraNodeState::currentVis)).apply(instance, AuraNodeState::new));

    public AuraNodeState {
        instanceId = instanceId == null ? Optional.empty() : instanceId;
        type = Objects.requireNonNull(type, "type");
        modifier = Objects.requireNonNull(modifier, "modifier");
        baseVis = Objects.requireNonNull(baseVis, "baseVis");
        currentVis = Objects.requireNonNull(currentVis, "currentVis");
    }

    /**
     * Returns a copy with a different persistent scan identity.
     */
    public AuraNodeState withInstanceId(Optional<UUID> value) {
        return new AuraNodeState(value, this.type, this.modifier, this.baseVis, this.currentVis);
    }

    /**
     * Returns a copy with a different typed node identity.
     */
    public AuraNodeState withType(NodeTypeId value) {
        return new AuraNodeState(this.instanceId, value, this.modifier, this.baseVis, this.currentVis);
    }

    /**
     * Returns a copy with a different live whole-Vis store.
     */
    public AuraNodeState withCurrentVis(NodeVis value) {
        return new AuraNodeState(this.instanceId, this.type, this.modifier, this.baseVis, value);
    }

    /**
     * Returns a copy with different base and live whole-Vis stores.
     */
    public AuraNodeState withVis(NodeVis base, NodeVis current) {
        return new AuraNodeState(this.instanceId, this.type, this.modifier, base, current);
    }

    /**
     * Returns a copy with a complete typed node definition.
     */
    public AuraNodeState withState(NodeTypeId nodeType, NodeModifierId nodeModifier, NodeVis base, NodeVis current) {
        return new AuraNodeState(this.instanceId, nodeType, nodeModifier, base, current);
    }

    static private <A> com.mojang.serialization.MapCodec<java.util.Optional<A>> native$StrictOptionalFields$of(com.mojang.serialization.Codec<A> codec, java.lang.String name) {
        java.util.Objects.requireNonNull(codec, "codec");
        java.util.Objects.requireNonNull(name, "name");
        return new com.mojang.serialization.MapCodec<>() {

            @Override
            public <T> com.mojang.serialization.DataResult<java.util.Optional<A>> decode(com.mojang.serialization.DynamicOps<T> ops, com.mojang.serialization.MapLike<T> input) {
                T value = input.get(name);
                return value == null ? com.mojang.serialization.DataResult.success(java.util.Optional.empty()) : codec.parse(ops, value).map(java.util.Optional::of);
            }

            @Override
            public <T> com.mojang.serialization.RecordBuilder<T> encode(java.util.Optional<A> input, com.mojang.serialization.DynamicOps<T> ops, com.mojang.serialization.RecordBuilder<T> prefix) {
                return input.isPresent() ? prefix.add(name, codec.encodeStart(ops, input.get())) : prefix;
            }

            @Override
            public <T> java.util.stream.Stream<T> keys(com.mojang.serialization.DynamicOps<T> ops) {
                return java.util.stream.Stream.of(ops.createString(name));
            }

            @Override
            public java.lang.String toString() {
                return "StrictOptionalField[" + name + ": " + codec + "]";
            }
        };
    }

    static private <A> com.mojang.serialization.MapCodec<A> native$StrictOptionalFields$of(com.mojang.serialization.Codec<A> codec, java.lang.String name, A defaultValue) {
        return AuraNodeState.native$StrictOptionalFields$of(codec, name).xmap(value -> value.orElse(defaultValue), value -> java.util.Objects.equals(value, defaultValue) ? java.util.Optional.empty() : java.util.Optional.of(value));
    }
}
