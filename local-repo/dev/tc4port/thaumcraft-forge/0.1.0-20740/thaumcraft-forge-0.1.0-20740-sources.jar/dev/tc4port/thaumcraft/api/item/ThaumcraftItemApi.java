package dev.tc4port.thaumcraft.api.item;

import dev.tc4port.thaumcraft.util.RuntimeWarnings;
import dev.tc4port.thaumcraft.api.aspect.AspectAmounts;
import dev.tc4port.thaumcraft.api.aspect.AspectApi;
import dev.tc4port.thaumcraft.api.aspect.AspectId;
import dev.tc4port.thaumcraft.data.AspectStackData;
import dev.tc4port.thaumcraft.item.CrystalEssenceItem;
import dev.tc4port.thaumcraft.state.TCItemState;
import dev.tc4port.thaumcraft.registry.CrystalEssences;
import java.util.LinkedHashMap;
import net.minecraft.world.item.ItemStack;

/**
 * Narrow factories for correctly component-backed Thaumcraft items.
 */
public final class ThaumcraftItemApi {

    public static final int MAX_WISP_ASPECT_TYPES = WispEssenceFactory.MAX_WISP_ASPECT_TYPES;

    public static final int MAX_WISP_TOTAL_ASPECTS = WispEssenceFactory.MAX_WISP_TOTAL_ASPECTS;

    public static final int MAX_WISP_ENCODED_BYTES = WispEssenceFactory.MAX_WISP_ENCODED_BYTES;

    private ThaumcraftItemApi() {
    }

    /**
     * Creates a phial filled to the current synchronized storage capacity.
     */
    public static ItemStack createEssencePhial(AspectId aspect, boolean clientSide) {
        if (aspect == null || AspectApi.registry().get(aspect).isEmpty()) {
            return ItemStack.EMPTY;
        }
        return dev.tc4port.thaumcraft.item.EssencePhialItem.forAspect(dev.tc4port.thaumcraft.registry.TCItems.ESSENCE_PHIAL.get(), aspect, clientSide);
    }

    /**
     * Creates the component-backed one-aspect crystal used by TC4's
     * crystallized-essentia drops.
     *
     * <p>The active aspect registry is checked before the stack is created so
     * addon callers cannot accidentally emit a visually valid but empty
     * crystal for an unknown or stale identity.</p>
     *
     * @return the crystal, or {@link ItemStack#EMPTY} for an invalid aspect
     */
    public static ItemStack createCrystalEssence(AspectId aspect) {
        if (aspect == null || AspectApi.registry().get(aspect).isEmpty()) {
            RuntimeWarnings.warnOnce("crystal-essence-create", "Ignoring crystal essence request with unknown aspect {}", aspect);
            return ItemStack.EMPTY;
        }
        return CrystalEssenceItem.forAspect(CrystalEssences.item(), aspect);
    }

    public static ItemStack createWispEssence(AspectAmounts aspects) {
        return WispEssenceFactory.create(aspects);
    }
}
