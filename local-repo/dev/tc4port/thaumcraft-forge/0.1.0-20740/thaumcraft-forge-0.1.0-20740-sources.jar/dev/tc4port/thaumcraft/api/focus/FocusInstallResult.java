package dev.tc4port.thaumcraft.api.focus;

public enum FocusInstallResult {

    INSTALLED,
    WOULD_INSTALL,
    NOT_A_WAND,
    NOT_A_FOCUS,
    UNKNOWN_PROFILE,
    INVALID_STATE,
    NO_RETURN_SPACE,
    DENIED
}
