package dev.tc4port.thaumcraft.api.event;

/**
 * Stable authored operations, independent of the native enum spelling.
 */
public enum AttributeOperation {

    ADD_VALUE, ADD_MULTIPLIED_BASE, ADD_MULTIPLIED_TOTAL
}
