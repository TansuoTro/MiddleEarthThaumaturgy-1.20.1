package dev.tc4port.thaumcraft.block;

import com.mojang.serialization.MapCodec;
import dev.tc4port.thaumcraft.api.node.AuraNodeState;
import dev.tc4port.thaumcraft.block.entity.AuraNodeBlockEntity;
import dev.tc4port.thaumcraft.registry.TCBlockEntities;
import dev.tc4port.thaumcraft.worldgen.AuraNodeFactory;
import java.util.Optional;
import java.util.UUID;
import javax.annotation.Nullable;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityTicker;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import dev.tc4port.thaumcraft.nativeimpl.ClientExtensionTarget;
import dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.level.pathfinder.PathComputationType;
import net.minecraft.world.phys.HitResult;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.Explosion;
import net.minecraft.world.level.BlockGetter;

/**
 * A solid structure block containing an aura node (TC4 cosmetic-solid
 * metadata 8).
 */
public final class AuraNodeSolidBlock extends net.minecraft.world.level.block.BaseEntityBlock implements dev.tc4port.thaumcraft.nativeimpl.ClientExtensionTarget {

    // Forge calls initializeClient from the native superclass constructor. Do not add a field initializer.
    private java.util.function.Consumer<net.minecraftforge.client.extensions.common.IClientBlockExtensions> platform$clientInstaller;

    public static final MapCodec<AuraNodeSolidBlock> CODEC = AuraNodeSolidBlock.native$BlockCodecPlatform$simple(AuraNodeSolidBlock::new);

    public AuraNodeSolidBlock(BlockBehaviour.Properties properties) {
        this(properties, properties, true);
    }

    protected MapCodec<AuraNodeSolidBlock> codec() {
        return CODEC;
    }

    @Nullable
    @Override
    public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        return new AuraNodeBlockEntity(pos, state);
    }

    @Override
    public void setPlacedBy(Level level, BlockPos pos, BlockState state, @Nullable LivingEntity placer, ItemStack stack) {
        super.setPlacedBy(level, pos, state, placer, stack);
        if (placer instanceof Player && level instanceof ServerLevel serverLevel && level.getBlockEntity(pos) instanceof AuraNodeBlockEntity node) {
            // Use the natural host's biome, environment and node-generation rules.
            AuraNodeState generated = AuraNodeFactory.create(serverLevel, pos, serverLevel.getRandom(), false, true, false);
            // A newly placed node must be scanned again, even at a reused position.
            node.setNodeState(generated.withInstanceId(Optional.of(UUID.randomUUID())));
        }
    }

    @Override
    public RenderShape getRenderShape(BlockState state) {
        return RenderShape.MODEL;
    }

    public BlockState beforePlayerDestroy(Level level, BlockPos pos, BlockState state, Player player) {
        // Creative and incorrect-tool destruction skip native block loot.
        // The table retains separate requirements for material and node rewards.
        if ((player.isCreative() || !player.hasCorrectToolForDrops(state)) && level instanceof net.minecraft.server.level.ServerLevel) {
            net.minecraft.world.level.block.Block.dropResources(state, level, pos, level.getBlockEntity(pos), player, player.getMainHandItem());
        }
        return (switch(0) {
            default ->
                {
                    net.minecraft.world.level.Level native$bodyOperand$5726 = level;
                    net.minecraft.core.BlockPos native$bodyOperand$5727 = pos;
                    net.minecraft.world.level.block.state.BlockState native$bodyOperand$5728 = state;
                    net.minecraft.world.entity.player.Player native$bodyOperand$5729 = player;
                    net.minecraft.world.level.block.state.BlockState native$bodyResult$5730 = null;
                    native$bodyReturn$5731: {
                        if (true) {
                            super.playerWillDestroy(native$bodyOperand$5726, native$bodyOperand$5727, native$bodyOperand$5728, native$bodyOperand$5729);
                            {
                                native$bodyResult$5730 = native$bodyOperand$5728;
                                break native$bodyReturn$5731;
                            }
                        }
                    }
                    yield native$bodyResult$5730;
                }
        });
    }

    @Nullable
    @Override
    public <T extends BlockEntity> BlockEntityTicker<T> getTicker(Level level, BlockState state, BlockEntityType<T> type) {
        return createTickerHelper(type, TCBlockEntities.AURA_NODE.get(), level.isClientSide ? AuraNodeBlockEntity::clientTick : AuraNodeBlockEntity::serverTick);
    }

    @Override
    public java.util.List<net.minecraft.world.item.ItemStack> getDrops(BlockState state, net.minecraft.world.level.storage.loot.LootParams.Builder params) {
        params.withParameter(net.minecraft.world.level.storage.loot.parameters.LootContextParams.BLOCK_STATE, state);
        dev.tc4port.thaumcraft.loot.NodeLoot.prepare(params);
        return super.getDrops(state, params);
    }

    private AuraNodeSolidBlock(net.minecraft.world.level.block.state.BlockBehaviour.Properties native$NativeEntityBlock$arg0, BlockBehaviour.Properties properties, boolean native$NativeEntityBlock$captured) {
        super(native$NativeEntityBlock$arg0);
    }

    @Override
    public void initializeClient(java.util.function.Consumer<net.minecraftforge.client.extensions.common.IClientBlockExtensions> installer) {
        platform$clientInstaller = installer;
        super.initializeClient(installer);
    }

    @Override
    public void platform$clientExtension(Object extension) {
        java.util.Objects.requireNonNull(platform$clientInstaller, "Forge initializeClient must run before client extension registration").accept((net.minecraftforge.client.extensions.common.IClientBlockExtensions) extension);
    }

    @Override
    public InteractionResult use(BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
        ItemUseResult result = (switch(0) {
            default ->
                {
                    net.minecraft.world.item.ItemStack native$bodyOperand$4240 = player.getItemInHand(hand);
                    net.minecraft.world.level.block.state.BlockState native$bodyOperand$4241 = state;
                    net.minecraft.world.level.Level native$bodyOperand$4242 = level;
                    net.minecraft.core.BlockPos native$bodyOperand$4243 = pos;
                    net.minecraft.world.entity.player.Player native$bodyOperand$4244 = player;
                    net.minecraft.world.InteractionHand native$bodyOperand$4245 = hand;
                    net.minecraft.world.phys.BlockHitResult native$bodyOperand$4246 = hit;
                    dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult native$bodyResult$4247 = null;
                    native$bodyReturn$4248: {
                        if (true) {
                            {
                                native$bodyResult$4247 = dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
                                break native$bodyReturn$4248;
                            }
                        }
                    }
                    yield native$bodyResult$4247;
                }
        });
        return result == ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION ? (hand == InteractionHand.MAIN_HAND ? (switch(0) {
            default ->
                {
                    net.minecraft.world.level.block.state.BlockState native$bodyOperand$3550 = state;
                    net.minecraft.world.level.Level native$bodyOperand$3551 = level;
                    net.minecraft.core.BlockPos native$bodyOperand$3552 = pos;
                    net.minecraft.world.entity.player.Player native$bodyOperand$3553 = player;
                    net.minecraft.world.phys.BlockHitResult native$bodyOperand$3554 = hit;
                    net.minecraft.world.InteractionResult native$bodyResult$3555 = null;
                    native$bodyReturn$3556: {
                        if (true) {
                            {
                                native$bodyResult$3555 = super.use(native$bodyOperand$3550, native$bodyOperand$3551, native$bodyOperand$3552, native$bodyOperand$3553, net.minecraft.world.InteractionHand.MAIN_HAND, native$bodyOperand$3554);
                                break native$bodyReturn$3556;
                            }
                        }
                    }
                    yield native$bodyResult$3555;
                }
        }) : InteractionResult.PASS) : result.result();
    }

    protected ItemUseResult interactWithItem(ItemStack stack, BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
        return dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
    }

    protected InteractionResult interactWithoutItem(BlockState state, Level level, BlockPos pos, Player player, BlockHitResult hit) {
        return super.use(state, level, pos, player, net.minecraft.world.InteractionHand.MAIN_HAND, hit);
    }

    @Override
    public void playerWillDestroy(Level level, BlockPos pos, BlockState state, Player player) {
        {
            net.minecraft.world.level.Level native$bodyOperand$5732 = level;
            net.minecraft.core.BlockPos native$bodyOperand$5733 = pos;
            net.minecraft.world.level.block.state.BlockState native$bodyOperand$5734 = state;
            net.minecraft.world.entity.player.Player native$bodyOperand$5735 = player;
            net.minecraft.world.level.block.state.BlockState native$bodyResult$5736 = null;
            native$bodyReturn$5737: {
                if (true) {
                    // Creative and incorrect-tool destruction skip native block loot.
                    // The table retains separate requirements for material and node rewards.
                    if ((native$bodyOperand$5735.isCreative() || !native$bodyOperand$5735.hasCorrectToolForDrops(native$bodyOperand$5734)) && native$bodyOperand$5732 instanceof net.minecraft.server.level.ServerLevel) {
                        net.minecraft.world.level.block.Block.dropResources(native$bodyOperand$5734, native$bodyOperand$5732, native$bodyOperand$5733, native$bodyOperand$5732.getBlockEntity(native$bodyOperand$5733), native$bodyOperand$5735, native$bodyOperand$5735.getMainHandItem());
                    }
                    {
                        native$bodyResult$5736 = (switch(0) {
                            default ->
                                {
                                    net.minecraft.world.level.Level native$bodyOperand$8991 = native$bodyOperand$5732;
                                    net.minecraft.core.BlockPos native$bodyOperand$8992 = native$bodyOperand$5733;
                                    net.minecraft.world.level.block.state.BlockState native$bodyOperand$8993 = native$bodyOperand$5734;
                                    net.minecraft.world.entity.player.Player native$bodyOperand$8994 = native$bodyOperand$5735;
                                    net.minecraft.world.level.block.state.BlockState native$bodyResult$8995 = null;
                                    native$bodyReturn$8996: {
                                        if (true) {
                                            super.playerWillDestroy(native$bodyOperand$8991, native$bodyOperand$8992, native$bodyOperand$8993, native$bodyOperand$8994);
                                            {
                                                native$bodyResult$8995 = native$bodyOperand$8993;
                                                break native$bodyReturn$8996;
                                            }
                                        }
                                    }
                                    yield native$bodyResult$8995;
                                }
                        });
                        break native$bodyReturn$5737;
                    }
                }
            }
        }
    }

    protected boolean survivesSharedExplosion() {
        return false;
    }

    public int getExpDrop(net.minecraft.world.level.block.state.BlockState native$callbackInput$1050, net.minecraft.world.level.LevelReader native$callbackInput$1051, net.minecraft.util.RandomSource native$callbackInput$1052, net.minecraft.core.BlockPos native$callbackInput$1053, int native$callbackInput$1054, int native$callbackInput$1055) {
        net.minecraft.world.level.block.state.BlockState state = native$callbackInput$1050;
        net.minecraft.util.RandomSource random = native$callbackInput$1052;
        return 0;
    }

    @Override
    public void onBlockExploded(BlockState state, Level level, BlockPos pos, Explosion explosion) {
        if (!(switch(0) {
            default ->
                {
                    boolean native$bodyResult$5233 = false;
                    native$bodyReturn$5234: {
                        if (true) {
                            {
                                native$bodyResult$5233 = false;
                                break native$bodyReturn$5234;
                            }
                        }
                    }
                    yield native$bodyResult$5233;
                }
        }))
            super.onBlockExploded(state, level, pos, explosion);
    }

    @Override
    public boolean canDropFromExplosion(BlockState state, BlockGetter level, BlockPos pos, Explosion explosion) {
        return !(switch(0) {
            default ->
                {
                    boolean native$bodyResult$4249 = false;
                    native$bodyReturn$4250: {
                        if (true) {
                            {
                                native$bodyResult$4249 = false;
                                break native$bodyReturn$4250;
                            }
                        }
                    }
                    yield native$bodyResult$4249;
                }
        }) && super.canDropFromExplosion(state, level, pos, explosion);
    }

    static private <B extends net.minecraft.world.level.block.Block> com.mojang.serialization.MapCodec<B> native$BlockCodecPlatform$simple(java.util.function.Function<net.minecraft.world.level.block.state.BlockBehaviour.Properties, B> factory) {
        // Vanilla 1.21's Properties codec is a unit codec. Retain that schema for shared block definitions.
        return com.mojang.serialization.codecs.RecordCodecBuilder.mapCodec(instance -> instance.group(com.mojang.serialization.Codec.unit(net.minecraft.world.level.block.state.BlockBehaviour.Properties::of).fieldOf("properties").forGetter((B block) -> net.minecraft.world.level.block.state.BlockBehaviour.Properties.copy(block))).apply(instance, factory));
    }
}
