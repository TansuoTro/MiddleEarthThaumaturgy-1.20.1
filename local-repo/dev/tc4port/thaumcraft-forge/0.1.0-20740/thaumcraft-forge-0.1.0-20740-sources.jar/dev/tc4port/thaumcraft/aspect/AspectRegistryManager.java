package dev.tc4port.thaumcraft.aspect;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import dev.tc4port.thaumcraft.Thaumcraft;
import dev.tc4port.thaumcraft.api.aspect.AspectDefinition;
import dev.tc4port.thaumcraft.api.aspect.AspectId;
import dev.tc4port.thaumcraft.common.ConditionalJsonResourceReloadListener;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.packs.resources.ResourceManager;
import net.minecraft.util.profiling.ProfilerFiller;

/**
 * Server-authoritative, reloadable aspect graph and client sync owner.
 */
public final class AspectRegistryManager extends ConditionalJsonResourceReloadListener {

    private static final Gson GSON = new GsonBuilder().create();

    private static final String PACKAGED_DEFAULT_RESOURCE = "/data/thaumcraft/thaumcraft/aspects/default.json";

    private static final ResourceLocation DEFAULT_RESOURCE = ResourceLocation.tryBuild(Thaumcraft.MOD_ID, "default");

    private static final ResourceLocation RETIRED_RESOURCE = ResourceLocation.tryBuild(Thaumcraft.MOD_ID, "legacy");

    private static final AspectRegistryManager INSTANCE = new AspectRegistryManager();

    private static final List<AspectDefinition> PACKAGED_CORE_DEFINITIONS = loadPackagedCoreDefinitions();

    private static final List<AspectId> PACKAGED_EERIE_WISP_SPAWN_POOL = loadPackagedEerieWispSpawnPool();

    private static final List<AspectId> CORE_PRESENTATION_ORDER = PACKAGED_CORE_DEFINITIONS.stream().map(AspectDefinition::id).toList();

    private static volatile Installed installed = new Installed(AspectRegistrySnapshot.create(0L, PACKAGED_CORE_DEFINITIONS), PACKAGED_EERIE_WISP_SPAWN_POOL);

    private AspectRegistryManager() {
        super(GSON, "thaumcraft/aspects");
    }

    public static void register() {
        dev.tc4port.thaumcraft.aspect.AspectRegistryManager.native$subscription$11230(java.util.Objects.requireNonNull(INSTANCE));
        dev.tc4port.thaumcraft.aspect.AspectRegistryManager.native$subscription$11232();
    }

    public static AspectRegistrySnapshot current() {
        return installed.snapshot();
    }

    /**
     * Ordered source pool used by Eerie-biome Wisp spawn selection.
     */
    public static List<AspectId> eerieWispSpawnPool() {
        return installed.eerieWispSpawnPool();
    }

    public static void installRemoteSnapshot(long serverGeneration, List<AspectDefinition> definitions) {
        Installed previous = installed;
        AspectRegistrySnapshot replacement = nextSyncedSnapshot(previous.snapshot(), serverGeneration, definitions);
        installed = new Installed(replacement, previous.eerieWispSpawnPool());
        Thaumcraft.LOGGER.info("Installed {} server-synchronized aspect definitions " + "at generation {}", replacement.definitions().size(), replacement.generation());
    }

    @Override
    protected void applyMatched(Map<ResourceLocation, JsonElement> prepared, ResourceManager resourceManager, ProfilerFiller profiler) {
        Installed previous = installed;
        if (previous.snapshot().generation() == Long.MAX_VALUE) {
            throw new IllegalStateException("Aspect registry generation is exhausted");
        }
        long nextGeneration = Math.max(1L, previous.snapshot().generation() + 1L);
        Installed replacement = buildReloadInstalled(nextGeneration, prepared);
        installed = replacement;
        Thaumcraft.LOGGER.info("Loaded {} data-pack aspects ({} primal, {} compound) and " + "{} Eerie Wisp spawn entries at generation {}", replacement.snapshot().definitions().size(), replacement.snapshot().primals().size(), replacement.snapshot().compounds().size(), replacement.eerieWispSpawnPool().size(), replacement.snapshot().generation());
    }

    static AspectRegistrySnapshot nextSyncedSnapshot(AspectRegistrySnapshot previous, long serverGeneration, List<AspectDefinition> definitions) {
        AspectRegistrySnapshot candidate = AspectRegistrySnapshot.create(serverGeneration, definitions);
        if (List.copyOf(previous.definitions().entrySet()).equals(List.copyOf(candidate.definitions().entrySet()))) {
            return previous;
        }
        if (previous.generation() == Long.MAX_VALUE) {
            throw new IllegalStateException("Aspect registry generation is exhausted");
        }
        long localGeneration = previous.generation() + 1L;
        return AspectRegistrySnapshot.create(localGeneration, definitions);
    }

    static AspectRegistrySnapshot buildReloadSnapshot(long generation, Map<ResourceLocation, JsonElement> prepared) {
        if (prepared.containsKey(RETIRED_RESOURCE)) {
            throw new IllegalArgumentException("Retired aspect resource " + RETIRED_RESOURCE + " is not current game data");
        }
        JsonElement defaultElement = prepared.get(DEFAULT_RESOURCE);
        if (defaultElement == null || !defaultElement.isJsonObject()) {
            throw new IllegalArgumentException("Missing required aspect resource " + DEFAULT_RESOURCE);
        }
        List<AspectDefinition> defaultDefinitions = AspectDefinitionJson.parseResource(DEFAULT_RESOURCE, defaultElement.getAsJsonObject());
        List<AspectId> defaultOrder = defaultDefinitions.stream().map(AspectDefinition::id).toList();
        if (!defaultOrder.equals(CORE_PRESENTATION_ORDER)) {
            throw new IllegalArgumentException("The aspect default must declare the exact 48 core IDs " + "in their current presentation order");
        }
        LinkedHashMap<AspectId, AspectDefinition> loaded = new LinkedHashMap<>();
        LinkedHashMap<AspectId, ResourceLocation> owners = new LinkedHashMap<>();
        for (AspectDefinition definition : defaultDefinitions) {
            loaded.put(definition.id(), definition);
            owners.put(definition.id(), DEFAULT_RESOURCE);
        }
        List<Map.Entry<ResourceLocation, JsonElement>> resources = prepared.entrySet().stream().filter(entry -> !entry.getKey().equals(DEFAULT_RESOURCE)).sorted(Map.Entry.comparingByKey()).toList();
        for (Map.Entry<ResourceLocation, JsonElement> resource : resources) {
            for (AspectDefinition definition : AspectDefinitionJson.parseResource(resource.getKey(), resource.getValue().getAsJsonObject())) {
                ResourceLocation previous = owners.putIfAbsent(definition.id(), resource.getKey());
                if (previous != null) {
                    boolean singleCoreOverride = previous.equals(DEFAULT_RESOURCE) && resource.getKey().equals(definition.id().value());
                    if (!singleCoreOverride) {
                        throw new IllegalArgumentException("Aspect " + definition.id() + " is declared by both " + previous + " and " + resource.getKey());
                    }
                    owners.put(definition.id(), resource.getKey());
                }
                loaded.put(definition.id(), definition);
            }
        }
        AspectRegistrySnapshot snapshot = AspectRegistrySnapshot.create(generation, loaded.values());
        for (AspectId aspect : parseEerieWispSpawnPool(DEFAULT_RESOURCE, defaultElement.getAsJsonObject())) {
            if (snapshot.get(aspect).isEmpty()) {
                throw new IllegalArgumentException("Unknown Eerie Wisp spawn aspect " + aspect);
            }
        }
        return snapshot;
    }

    static Installed buildReloadInstalled(long generation, Map<ResourceLocation, JsonElement> prepared) {
        AspectRegistrySnapshot snapshot = buildReloadSnapshot(generation, prepared);
        JsonElement defaultElement = prepared.get(DEFAULT_RESOURCE);
        List<AspectId> pool = parseEerieWispSpawnPool(DEFAULT_RESOURCE, defaultElement.getAsJsonObject());
        for (AspectId aspect : pool) {
            if (snapshot.get(aspect).isEmpty()) {
                throw new IllegalArgumentException("Unknown Eerie Wisp spawn aspect " + aspect);
            }
        }
        return new Installed(snapshot, pool);
    }

    private static List<AspectDefinition> loadPackagedCoreDefinitions() {
        try (InputStream stream = AspectRegistryManager.class.getResourceAsStream(PACKAGED_DEFAULT_RESOURCE)) {
            if (stream == null) {
                throw new IllegalStateException("Missing packaged aspect default " + PACKAGED_DEFAULT_RESOURCE);
            }
            JsonObject root = JsonParser.parseReader(new InputStreamReader(stream, StandardCharsets.UTF_8)).getAsJsonObject();
            return List.copyOf(AspectDefinitionJson.parseResource(DEFAULT_RESOURCE, root));
        } catch (Exception exception) {
            throw new ExceptionInInitializerError(exception);
        }
    }

    private static List<AspectId> loadPackagedEerieWispSpawnPool() {
        try (InputStream stream = AspectRegistryManager.class.getResourceAsStream(PACKAGED_DEFAULT_RESOURCE)) {
            if (stream == null) {
                throw new IllegalStateException("Missing packaged aspect default " + PACKAGED_DEFAULT_RESOURCE);
            }
            JsonObject root = JsonParser.parseReader(new InputStreamReader(stream, StandardCharsets.UTF_8)).getAsJsonObject();
            return parseEerieWispSpawnPool(DEFAULT_RESOURCE, root);
        } catch (Exception exception) {
            throw new ExceptionInInitializerError(exception);
        }
    }

    private static List<AspectId> parseEerieWispSpawnPool(ResourceLocation source, JsonObject root) {
        JsonElement element = root.get("eerie_wisp_spawn_pool");
        if (element == null || !element.isJsonArray() || element.getAsJsonArray().isEmpty() || element.getAsJsonArray().size() > 256) {
            throw new IllegalArgumentException("Eerie Wisp spawn pool must contain 1..256 aspect IDs in " + source);
        }
        java.util.ArrayList<AspectId> result = new java.util.ArrayList<>();
        Set<AspectId> unique = new HashSet<>();
        for (JsonElement entry : element.getAsJsonArray()) {
            if (!entry.isJsonPrimitive() || !entry.getAsJsonPrimitive().isString()) {
                throw new IllegalArgumentException("Eerie Wisp spawn pool entries must be string IDs in " + source);
            }
            String serialized = entry.getAsString();
            AspectId id = AspectId.parse(serialized);
            if (!id.toString().equals(serialized) || !unique.add(id)) {
                throw new IllegalArgumentException("Eerie Wisp spawn pool IDs must be unique, canonical " + "and fully namespaced in " + source);
            }
            result.add(id);
        }
        return List.copyOf(result);
    }

    record Installed(AspectRegistrySnapshot snapshot, List<AspectId> eerieWispSpawnPool) {

        Installed {
            eerieWispSpawnPool = List.copyOf(eerieWispSpawnPool);
        }
    }

    private static void native$listener$11231(java.util.stream.Stream<net.minecraft.server.level.ServerPlayer> players) {
        var snapshot = current();
        var payload = new dev.tc4port.thaumcraft.network.AspectRegistrySyncPayload(snapshot.generation(), java.util.List.copyOf(snapshot.definitions().values()));
        players.forEach(player -> dev.tc4port.thaumcraft.network.TCPayloads.CHANNEL.sendToPlayer(player, payload));
    }

    static private void native$subscription$11230(dev.tc4port.thaumcraft.common.ConditionalJsonResourceReloadListener native$listenerReceiver$11229) {
        net.minecraftforge.common.MinecraftForge.EVENT_BUS.addListener((net.minecraftforge.event.AddReloadListenerEvent event) -> native$listenerReceiver$11229.registerReloadListener((net.minecraftforge.event.AddReloadListenerEvent) (java.util.Objects.requireNonNull(event))));
    }

    static private void native$subscription$11232() {
        net.minecraftforge.common.MinecraftForge.EVENT_BUS.addListener((net.minecraftforge.event.OnDatapackSyncEvent event) -> dev.tc4port.thaumcraft.aspect.AspectRegistryManager.native$listener$11231((java.util.stream.Stream<net.minecraft.server.level.ServerPlayer>) (event.getPlayer() == null ? event.getPlayerList().getPlayers().stream() : java.util.stream.Stream.of(event.getPlayer()))));
    }
}
