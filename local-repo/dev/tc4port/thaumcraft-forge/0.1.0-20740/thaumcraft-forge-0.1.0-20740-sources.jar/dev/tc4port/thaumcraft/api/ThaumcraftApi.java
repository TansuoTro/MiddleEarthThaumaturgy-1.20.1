package dev.tc4port.thaumcraft.api;

import dev.tc4port.thaumcraft.api.data.*;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.Block;
import dev.tc4port.thaumcraft.registry.TCRegistryDataMaps;
import dev.tc4port.thaumcraft.registry.RegistryDataMapKey;

/**
 * Uniform data-map definitions; all shared API operations are inherited.
 */
public final class ThaumcraftApi extends ThaumcraftApiCommon {

    private ThaumcraftApi() {
    }

    /**
     * Current reloadable equipment definition; null when the item has no abilities.
     */
    @javax.annotation.Nullable
    public static EquipmentAbilityDefinition equipmentAbilities(net.minecraft.world.item.ItemStack stack) {
        return stack.isEmpty() ? null : TCRegistryDataMaps.EQUIPMENT_ABILITIES.get(stack.getItemHolder());
    }

    /**
     * Current reloadable equipped-warp definition, without exposing the native registry backend.
     */
    @javax.annotation.Nullable
    public static WarpDefinition equippedWarp(net.minecraft.world.item.ItemStack stack) {
        return stack.isEmpty() ? null : TCRegistryDataMaps.EQUIPPED_WARP.get(stack.getItemHolder());
    }

    /**
     * Server biome values; enumerate with values(level.registryAccess()) in the Universal API.
     */
    public static final RegistryDataMapKey<net.minecraft.world.level.biome.Biome, java.util.List<BiomeAuraDefinition>> BIOME_AURA_DATA = TCRegistryDataMaps.BIOME_AURA;

    public static final RegistryDataMapKey<Item, WandRodDefinition> WAND_ROD_DATA = TCRegistryDataMaps.WAND_RODS;

    public static final RegistryDataMapKey<Block, BlockAspectDefinition> BLOCK_ASPECT_DATA = TCRegistryDataMaps.BLOCK_ASPECTS;

    public static final RegistryDataMapKey<Item, WandCapDefinition> WAND_CAP_DATA = TCRegistryDataMaps.WAND_CAPS;

    public static final RegistryDataMapKey<Item, WarpDefinition> CRAFTING_WARP_DATA = TCRegistryDataMaps.CRAFTING_WARP;

    public static final RegistryDataMapKey<Item, WarpDefinition> EQUIPPED_WARP_DATA = TCRegistryDataMaps.EQUIPPED_WARP;

    public static final RegistryDataMapKey<Item, PechValueDefinition> PECH_VALUE_DATA = TCRegistryDataMaps.PECH_VALUES;

    public static final RegistryDataMapKey<Item, EquipmentAbilityDefinition> EQUIPMENT_ABILITY_DATA = TCRegistryDataMaps.EQUIPMENT_ABILITIES;

    public static final RegistryDataMapKey<Item, RelayAttunementDefinition> VIS_RELAY_ATTUNEMENT_DATA = TCRegistryDataMaps.VIS_RELAY_ATTUNEMENTS;
}
