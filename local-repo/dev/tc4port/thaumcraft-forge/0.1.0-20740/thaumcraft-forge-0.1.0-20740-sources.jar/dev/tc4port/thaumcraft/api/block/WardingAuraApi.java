package dev.tc4port.thaumcraft.api.block;

import dev.tc4port.thaumcraft.block.WardingAuraBlock;
import dev.tc4port.thaumcraft.registry.TCBlocks;
import java.util.Objects;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;

/**
 * Stable addon boundary for the invisible creature fence owned by blocks in
 * {@code thaumcraft:warding_aura_sources}.
 *
 * <p>Addons own their source block and its refresh schedule. Thaumcraft owns
 * the aura block identity, collision, redstone state, source resolution and
 * delayed orphan cleanup.</p>
 */
public final class WardingAuraApi {

    private WardingAuraApi() {
    }

    public static boolean isAura(BlockState state) {
        return state.is(TCBlocks.WARDING_AURA.get());
    }

    /**
     * Keeps an existing aura or creates one in a replaceable cell.
     *
     * @return whether the cell contains a warding aura after the operation
     */
    public static boolean ensureAura(Level level, BlockPos auraPosition) {
        Objects.requireNonNull(level, "level");
        Objects.requireNonNull(auraPosition, "auraPosition");
        if (!(level instanceof ServerLevel serverLevel)) {
            return false;
        }
        return ensureLoadedAura(serverLevel, auraPosition).successful();
    }

    /**
     * Creates an aura without loading a chunk or accepting an unsafe call.
     */
    public static WardingAuraResult ensureLoadedAura(ServerLevel level, BlockPos auraPosition) {
        Objects.requireNonNull(level, "level");
        Objects.requireNonNull(auraPosition, "auraPosition");
        WardingAuraResult invalid = invalidAccess(level, auraPosition);
        if (invalid != null) {
            return invalid;
        }
        BlockState current = level.getBlockState(auraPosition);
        if (isAura(current)) {
            return WardingAuraResult.ALREADY_PRESENT;
        }
        if (!current.canBeReplaced()) {
            return WardingAuraResult.BLOCKED;
        }
        level.setBlock(auraPosition, TCBlocks.WARDING_AURA.get().defaultBlockState(), Block.UPDATE_ALL);
        return isAura(level.getBlockState(auraPosition)) ? WardingAuraResult.CREATED : WardingAuraResult.BLOCKED;
    }

    public static void syncBlockingState(Level level, BlockPos auraPosition) {
        Objects.requireNonNull(level, "level");
        Objects.requireNonNull(auraPosition, "auraPosition");
        if (level instanceof ServerLevel serverLevel) {
            syncLoadedBlockingState(serverLevel, auraPosition);
        }
    }

    /**
     * Synchronizes one loaded aura's powered collision/pathfinding state.
     */
    public static WardingAuraResult syncLoadedBlockingState(ServerLevel level, BlockPos auraPosition) {
        Objects.requireNonNull(level, "level");
        Objects.requireNonNull(auraPosition, "auraPosition");
        WardingAuraResult invalid = invalidAccess(level, auraPosition);
        if (invalid != null) {
            return invalid;
        }
        if (!isAura(level.getBlockState(auraPosition))) {
            return WardingAuraResult.NOT_AURA;
        }
        return WardingAuraBlock.syncBlockingState(level, auraPosition) ? WardingAuraResult.UPDATED : WardingAuraResult.UNCHANGED;
    }

    public static BlockPos sourcePosition(BlockGetter level, BlockPos auraPosition) {
        return WardingAuraBlock.sourcePosition(level, auraPosition);
    }

    private static WardingAuraResult invalidAccess(ServerLevel level, BlockPos auraPosition) {
        if (!level.getServer().isSameThread()) {
            return WardingAuraResult.OFF_SERVER_THREAD;
        }
        if (level.isOutsideBuildHeight(auraPosition) || level.isOutsideBuildHeight(auraPosition.below(2)) || !level.getWorldBorder().isWithinBounds(auraPosition)) {
            return WardingAuraResult.OUT_OF_BOUNDS;
        }
        if (!level.hasChunkAt(auraPosition)) {
            return WardingAuraResult.CHUNK_UNLOADED;
        }
        return null;
    }
}
