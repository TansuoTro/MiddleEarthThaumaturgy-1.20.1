package dev.tc4port.thaumcraft.block;

import net.minecraft.world.level.block.state.BlockState;

/**
 * Shared view of TC4's finite and classic metadata fluid levels for the
 * neighbor-aware legacy surface model.
 */
public interface MetadataFluidRenderBlock {

    int quantaPerBlock();

    boolean flowsUpward();

    boolean hasContinuousRenderOrigin(BlockState origin);

    int amount(BlockState state);

    float filledPercentage(BlockState state);
}
