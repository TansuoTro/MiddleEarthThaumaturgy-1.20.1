package dev.tc4port.thaumcraft.api.essentia;

import dev.tc4port.thaumcraft.api.aspect.AspectId;
import java.util.Objects;

/**
 * Immutable contents of one TC-owned filled warded-jar stack.
 */
public record FilledJarEssentiaView(AspectId aspect, int amount) {

    public FilledJarEssentiaView {
        Objects.requireNonNull(aspect, "aspect");
        if (amount <= 0) {
            throw new IllegalArgumentException("Filled jar amount must be positive");
        }
    }
}
