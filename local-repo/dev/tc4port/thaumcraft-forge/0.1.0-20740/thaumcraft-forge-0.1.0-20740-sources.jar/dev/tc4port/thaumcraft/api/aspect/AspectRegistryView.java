package dev.tc4port.thaumcraft.api.aspect;

import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;

/**
 * Read-only, generation-stamped view used by addons and the core.
 */
public interface AspectRegistryView {

    /**
     * Process-local cache stamp. It changes whenever installed definitions
     * change, including switches between servers with equal revision values.
     */
    long generation();

    /**
     * Definitions in presentation registration order: the effective
     * {@code thaumcraft:default} core first, then data-pack additions.
     * Iteration position is not an id or rule.
     */
    Map<AspectId, AspectDefinition> definitions();

    Optional<AspectDefinition> get(AspectId id);

    Set<AspectId> primals();

    Set<AspectId> compounds();

    List<VisChannel> visChannels();

    /**
     * Positive natural-generation weights keyed by primal identity.
     * Map iteration order has no gameplay meaning.
     */
    Map<AspectId, Integer> naturalPrimalWeights();

    /**
     * Positive natural-generation weights keyed by compound identity.
     * Map iteration order has no gameplay meaning.
     */
    Map<AspectId, Integer> naturalCompoundWeights();

    /**
     * Order-independent weighted selection for caller-supplied entropy.
     */
    AspectId selectNaturalPrimal(long entropy);

    /**
     * Order-independent weighted selection for caller-supplied entropy.
     */
    AspectId selectNaturalCompound(long entropy);

    Optional<AspectId> combination(AspectId first, AspectId second);
}
