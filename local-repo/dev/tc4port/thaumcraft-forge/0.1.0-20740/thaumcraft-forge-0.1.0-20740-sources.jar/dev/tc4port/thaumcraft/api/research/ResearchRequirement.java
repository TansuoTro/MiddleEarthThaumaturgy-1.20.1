package dev.tc4port.thaumcraft.api.research;

import com.mojang.serialization.MapCodec;
import java.util.Objects;
import java.util.Optional;

/**
 * Explicit optional research gate; no empty-string sentinel is exposed.
 */
public record ResearchRequirement(Optional<ResearchKey> key) {

    private static final ResearchRequirement NONE = new ResearchRequirement(Optional.empty());

    public ResearchRequirement {
        key = Objects.requireNonNull(key, "key");
        key.ifPresent(value -> Objects.requireNonNull(value, "research key"));
    }

    public static ResearchRequirement none() {
        return NONE;
    }

    public static ResearchRequirement required(ResearchKey key) {
        return new ResearchRequirement(Optional.of(Objects.requireNonNull(key, "key")));
    }

    public boolean isRequired() {
        return this.key.isPresent();
    }

    /**
     * Codec for an optional research field. An omitted field is
     * {@link #none()}; a present value must be a valid, non-empty
     * {@link ResearchKey}.
     */
    public static MapCodec<ResearchRequirement> optionalFieldOf(String fieldName) {
        return ResearchRequirement.native$StrictOptionalFields$of(ResearchKey.CODEC, Objects.requireNonNull(fieldName, "fieldName")).xmap(key -> key.map(ResearchRequirement::required).orElseGet(ResearchRequirement::none), ResearchRequirement::key);
    }

    static private <A> com.mojang.serialization.MapCodec<java.util.Optional<A>> native$StrictOptionalFields$of(com.mojang.serialization.Codec<A> codec, java.lang.String name) {
        java.util.Objects.requireNonNull(codec, "codec");
        java.util.Objects.requireNonNull(name, "name");
        return new com.mojang.serialization.MapCodec<>() {

            @Override
            public <T> com.mojang.serialization.DataResult<java.util.Optional<A>> decode(com.mojang.serialization.DynamicOps<T> ops, com.mojang.serialization.MapLike<T> input) {
                T value = input.get(name);
                return value == null ? com.mojang.serialization.DataResult.success(java.util.Optional.empty()) : codec.parse(ops, value).map(java.util.Optional::of);
            }

            @Override
            public <T> com.mojang.serialization.RecordBuilder<T> encode(java.util.Optional<A> input, com.mojang.serialization.DynamicOps<T> ops, com.mojang.serialization.RecordBuilder<T> prefix) {
                return input.isPresent() ? prefix.add(name, codec.encodeStart(ops, input.get())) : prefix;
            }

            @Override
            public <T> java.util.stream.Stream<T> keys(com.mojang.serialization.DynamicOps<T> ops) {
                return java.util.stream.Stream.of(ops.createString(name));
            }

            @Override
            public java.lang.String toString() {
                return "StrictOptionalField[" + name + ": " + codec + "]";
            }
        };
    }
}
