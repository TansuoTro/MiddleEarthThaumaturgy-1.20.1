package dev.tc4port.thaumcraft.aspect;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;
import com.google.gson.JsonPrimitive;
import dev.tc4port.thaumcraft.api.aspect.AspectBlendMode;
import dev.tc4port.thaumcraft.api.aspect.AspectDefinition;
import dev.tc4port.thaumcraft.api.aspect.AspectId;
import dev.tc4port.thaumcraft.api.aspect.VisChannel;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Optional;
import java.util.Set;
import net.minecraft.resources.ResourceLocation;

/**
 * Strict authoring boundary shared by the bootstrap and live reload.
 */
final class AspectDefinitionJson {

    private static final ResourceLocation DEFAULT_RESOURCE = AspectId.parse("default").value();

    private static final Set<String> DEFAULT_FIELDS = Set.of("entries", "eerie_wisp_spawn_pool");

    private static final Set<String> DEFINITION_FIELDS = Set.of("id", "color", "components", "texture", "blend", "natural_generation_weight", "vis_channel");

    private AspectDefinitionJson() {
    }

    static List<AspectDefinition> parseResource(ResourceLocation source, JsonObject root) {
        if (source.equals(DEFAULT_RESOURCE)) {
            requireOnly(root, DEFAULT_FIELDS, "default aspect root", source);
            if (!root.has("entries") || !root.get("entries").isJsonArray()) {
                throw error("Default aspect entries must be an array", source);
            }
            if (root.getAsJsonArray("entries").isEmpty() || root.getAsJsonArray("entries").size() > AspectRegistrySnapshot.MAX_DEFINITIONS) {
                throw error("Default aspect entries must contain 1.." + AspectRegistrySnapshot.MAX_DEFINITIONS, source);
            }
            ArrayList<AspectDefinition> definitions = new ArrayList<>();
            HashSet<AspectId> ids = new HashSet<>();
            for (JsonElement element : root.getAsJsonArray("entries")) {
                AspectDefinition definition = parseDefinition(source, requiredObject(element, source), null);
                if (!ids.add(definition.id())) {
                    throw error("Duplicate default aspect " + definition.id(), source);
                }
                definitions.add(definition);
            }
            return List.copyOf(definitions);
        }
        if (root.has("entries")) {
            throw error("The aggregate entries schema belongs only to " + DEFAULT_RESOURCE, source);
        }
        return List.of(parseDefinition(source, root, AspectId.of(source)));
    }

    private static AspectDefinition parseDefinition(ResourceLocation source, JsonObject object, AspectId defaultId) {
        try {
            requireOnly(object, DEFINITION_FIELDS, "aspect definition", source);
            if (!object.has("color")) {
                throw error("Aspect color is required", source);
            }
            AspectId id = object.has("id") ? aspectId(string(object, "id", source), "id", source) : defaultId;
            if (id == null) {
                throw error("Default aspect entry is missing id", source);
            }
            if (defaultId != null && !id.equals(defaultId)) {
                throw error("A single aspect resource may only declare its own " + "identity " + defaultId, source);
            }
            ArrayList<AspectId> components = new ArrayList<>();
            if (object.has("components")) {
                JsonElement element = object.get("components");
                if (!element.isJsonArray() || element.getAsJsonArray().size() != 0 && element.getAsJsonArray().size() != 2) {
                    throw error("Aspect components must contain zero or two IDs", source);
                }
                for (JsonElement component : element.getAsJsonArray()) {
                    if (!component.isJsonPrimitive() || !component.getAsJsonPrimitive().isString()) {
                        throw error("Aspect components must be strings", source);
                    }
                    components.add(aspectId(component.getAsString(), "component", source));
                }
                if (components.size() == 2 && components.get(0).equals(components.get(1))) {
                    throw error("Aspect components must be two distinct IDs", source);
                }
            }
            ResourceLocation identity = id.value();
            ResourceLocation texture = object.has("texture") ? resourceLocation(string(object, "texture", source), "texture", source) : ResourceLocation.tryBuild(identity.getNamespace(), "textures/aspects/" + identity.getPath().toLowerCase(Locale.ROOT) + ".png");
            AspectBlendMode blend = object.has("blend") ? blendMode(string(object, "blend", source), source) : AspectBlendMode.ADDITIVE;
            int naturalWeight = object.has("natural_generation_weight") ? integer(object, "natural_generation_weight", 0, 1_000, source) : 0;
            Optional<VisChannel> visChannel = Optional.empty();
            if (object.has("vis_channel")) {
                int slot = integer(object, "vis_channel", 0, 5, source);
                visChannel = VisChannel.fromIndex(slot);
                if (visChannel.isEmpty()) {
                    throw error("Aspect vis channel must be 0..5", source);
                }
            }
            return new AspectDefinition(id, readColor(object.get("color"), source), components, texture, blend, naturalWeight, visChannel);
        } catch (RuntimeException exception) {
            if (exception instanceof JsonParseException) {
                throw exception;
            }
            throw new JsonParseException("Invalid aspect definition in " + source, exception);
        }
    }

    private static int readColor(JsonElement element, ResourceLocation source) {
        if (element == null || !element.isJsonPrimitive()) {
            throw error("Aspect color is required", source);
        }
        JsonPrimitive primitive = element.getAsJsonPrimitive();
        if (primitive.isNumber()) {
            return exactInteger(primitive, "color", 0, 0xFFFFFF, source);
        }
        if (!primitive.isString()) {
            throw error("Aspect color must be RGB text or an integer", source);
        }
        String value = primitive.getAsString();
        if (value.startsWith("#")) {
            value = value.substring(1);
        } else if (value.startsWith("0x") || value.startsWith("0X")) {
            value = value.substring(2);
        }
        if (!value.matches("[0-9a-fA-F]{6}")) {
            throw error("Invalid 24-bit aspect color " + value, source);
        }
        return Integer.parseUnsignedInt(value, 16);
    }

    private static AspectId aspectId(String value, String role, ResourceLocation source) {
        return AspectId.of(resourceLocation(value, role, source));
    }

    private static AspectBlendMode blendMode(String value, ResourceLocation source) {
        return switch(value) {
            case "additive" ->
                AspectBlendMode.ADDITIVE;
            case "normal" ->
                AspectBlendMode.NORMAL;
            default ->
                throw error("blend must be exactly additive or normal", source);
        };
    }

    private static ResourceLocation resourceLocation(String value, String role, ResourceLocation source) {
        ResourceLocation location = value.indexOf(':') < 0 ? null : ResourceLocation.tryParse(value);
        if (location == null || !value.equals(location.toString()) || value.length() > 256) {
            throw error(role + " must be a canonical fully namespaced ID: " + value, source);
        }
        return location;
    }

    private static int integer(JsonObject object, String key, int minimum, int maximum, ResourceLocation source) {
        JsonElement element = object.get(key);
        if (element == null || !element.isJsonPrimitive() || !element.getAsJsonPrimitive().isNumber()) {
            throw error(key + " must be an exact integer", source);
        }
        return exactInteger(element.getAsJsonPrimitive(), key, minimum, maximum, source);
    }

    private static int exactInteger(JsonPrimitive primitive, String role, int minimum, int maximum, ResourceLocation source) {
        int value;
        try {
            value = new BigDecimal(primitive.getAsString()).intValueExact();
        } catch (NumberFormatException | ArithmeticException exception) {
            throw error(role + " must be an exact integer", source);
        }
        if (value < minimum || value > maximum) {
            throw error(role + " must be in " + minimum + ".." + maximum, source);
        }
        return value;
    }

    private static String string(JsonObject object, String key, ResourceLocation source) {
        JsonElement element = object.get(key);
        if (element == null || !element.isJsonPrimitive() || !element.getAsJsonPrimitive().isString() || element.getAsString().isBlank()) {
            throw error(key + " must be a non-blank string", source);
        }
        return element.getAsString();
    }

    private static JsonObject requiredObject(JsonElement element, ResourceLocation source) {
        if (element == null || !element.isJsonObject()) {
            throw error("Aspect definition must be an object", source);
        }
        return element.getAsJsonObject();
    }

    private static void requireOnly(JsonObject object, Set<String> allowed, String role, ResourceLocation source) {
        if (!allowed.containsAll(object.keySet())) {
            HashSet<String> unknown = new HashSet<>(object.keySet());
            unknown.removeAll(allowed);
            throw error("Unknown " + role + " fields " + unknown, source);
        }
    }

    private static JsonParseException error(String message, ResourceLocation source) {
        return new JsonParseException(message + " in " + source);
    }
}
