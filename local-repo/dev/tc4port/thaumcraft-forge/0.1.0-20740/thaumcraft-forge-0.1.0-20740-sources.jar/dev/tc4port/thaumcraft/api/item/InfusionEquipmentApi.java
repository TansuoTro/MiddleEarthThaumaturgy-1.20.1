package dev.tc4port.thaumcraft.api.item;

import dev.tc4port.thaumcraft.state.TCItemState;
import java.util.OptionalInt;
import net.minecraft.world.item.ItemStack;

/**
 * Read-only view of TC4's infusion-applied equipment decorations.
 */
public final class InfusionEquipmentApi {

    private InfusionEquipmentApi() {
    }

    /**
     * Returns whether an infusion applied revealing goggles to this stack.
     */
    public static boolean hasGoggles(ItemStack stack) {
        return (switch(0) {
            default ->
                {
                    dev.tc4port.thaumcraft.api.data.ItemStateKey<java.lang.Boolean> native$receiver$846 = TCItemState.INFUSION_GOGGLES;
                    net.minecraft.world.item.ItemStack native$argument$847 = stack;
                    java.lang.Boolean native$argument$848 = false;
                    java.util.Objects.requireNonNull(native$receiver$846);
                    yield dev.tc4port.thaumcraft.api.item.ItemStatePlatform.getOrDefault(native$argument$847, native$receiver$846, native$argument$848);
                }
        });
    }

    /**
     * Returns the legacy fortress mask variant (0..2), when present.
     */
    public static OptionalInt mask(ItemStack stack) {
        Integer mask = (switch(0) {
            default ->
                {
                    dev.tc4port.thaumcraft.api.data.ItemStateKey<java.lang.Integer> native$receiver$509 = TCItemState.INFUSION_MASK;
                    net.minecraft.world.item.ItemStack native$argument$510 = stack;
                    java.util.Objects.requireNonNull(native$receiver$509);
                    yield dev.tc4port.thaumcraft.api.item.ItemStatePlatform.get(native$argument$510, native$receiver$509);
                }
        });
        return mask == null ? OptionalInt.empty() : OptionalInt.of(mask);
    }
}
