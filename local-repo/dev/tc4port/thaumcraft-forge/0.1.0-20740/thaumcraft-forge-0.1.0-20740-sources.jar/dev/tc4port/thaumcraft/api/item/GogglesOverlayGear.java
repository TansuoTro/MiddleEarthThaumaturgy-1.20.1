package dev.tc4port.thaumcraft.api.item;

import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;

/**
 * Dynamic owner-item hook for Thaumcraft's goggles HUD over machines and
 * aspect containers.
 *
 * <p>Static items should use the synchronized equipment-ability Data Map.
 * Implement this interface only when the answer depends on stack or wearer
 * state. The callback is a read-only query and may run on either physical
 * side.</p>
 */
@FunctionalInterface
public interface GogglesOverlayGear {

    boolean showsThaumcraftGogglesOverlay(ItemStack stack, Player wearer);
}
