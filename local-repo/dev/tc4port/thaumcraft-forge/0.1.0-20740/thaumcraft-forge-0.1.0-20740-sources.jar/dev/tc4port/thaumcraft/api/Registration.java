package dev.tc4port.thaumcraft.api;

import java.util.Objects;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Idempotent lifetime handle for one runtime API registration.
 *
 * <p>Addons should retain the handle for as long as the registered behavior
 * is active and close it when that behavior is removed. Closing a handle more
 * than once is always safe.</p>
 */
@FunctionalInterface
public interface Registration extends AutoCloseable {

    @Override
    void close();

    /**
     * Wraps a remover in an idempotent, at-most-once handle. If the remover
     * throws, the exception propagates and the handle is still consumed so a
     * partially completed external side effect is never repeated implicitly.
     */
    static Registration of(Runnable remover) {
        Objects.requireNonNull(remover, "remover");
        AtomicBoolean open = new AtomicBoolean(true);
        return () -> {
            if (open.getAndSet(false)) {
                remover.run();
            }
        };
    }

    /**
     * Returns an already inert handle.
     */
    static Registration empty() {
        return () -> {
        };
    }
}
