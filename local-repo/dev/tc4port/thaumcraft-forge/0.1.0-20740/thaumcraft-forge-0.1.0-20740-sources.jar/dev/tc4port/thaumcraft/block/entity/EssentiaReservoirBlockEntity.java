package dev.tc4port.thaumcraft.block.entity;

import dev.tc4port.thaumcraft.common.TCGameplayParameters;
import dev.tc4port.thaumcraft.api.ThaumcraftApiHelper;
import dev.tc4port.thaumcraft.api.aspect.AspectDefinition;
import dev.tc4port.thaumcraft.aspect.AspectCatalog;
import dev.tc4port.thaumcraft.block.EssentiaReservoirBlock;
import dev.tc4port.thaumcraft.api.aspect.AspectId;
import dev.tc4port.thaumcraft.api.aspect.AspectAmounts;
import dev.tc4port.thaumcraft.api.aspect.AspectContainerView;
import dev.tc4port.thaumcraft.api.essentia.EssentiaApi;
import dev.tc4port.thaumcraft.api.essentia.EssentiaSource;
import dev.tc4port.thaumcraft.api.essentia.EssentiaTransferMode;
import dev.tc4port.thaumcraft.api.essentia.EssentiaTransport;
import dev.tc4port.thaumcraft.registry.TCBlockEntities;
import dev.tc4port.thaumcraft.registry.TCSounds;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;
import javax.annotation.Nullable;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import java.lang.Math;
import dev.tc4port.thaumcraft.nativeimpl.state.ItemFields;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityType;

/**
 * TC4's insertion-ordered, mixed-aspect 256-unit reservoir.
 */
public final class EssentiaReservoirBlockEntity extends net.minecraft.world.level.block.entity.BlockEntity implements EssentiaTransport, EssentiaSource, AspectContainerView, ItemFields.Source {

    public static final int CAPACITY = 256;

    private final LinkedHashMap<AspectId, Integer> essentia = new LinkedHashMap<>();

    private int lastCapacity;

    private int count;

    private AspectId displayAspect;

    private float colorRed = 1.0F;

    private float colorGreen = 1.0F;

    private float colorBlue = 1.0F;

    private float redIncrement;

    private float greenIncrement;

    private float blueIncrement;

    public int capacity() {
        return dev.tc4port.thaumcraft.api.essentia.EssentiaStorageApi.capacity(dev.tc4port.thaumcraft.api.essentia.EssentiaStorageApi.ESSENTIA_RESERVOIR, 256, this.level != null && this.level.isClientSide);
    }

    public EssentiaReservoirBlockEntity(BlockPos pos, BlockState state) {
        super(TCBlockEntities.ESSENTIA_RESERVOIR.get(), pos, state);
    }

    public static void serverTick(Level level, BlockPos pos, BlockState state, EssentiaReservoirBlockEntity reservoir) {
        if (reservoir.lastCapacity != reservoir.capacity()) {
            reservoir.lastCapacity = reservoir.capacity();
            reservoir.changedAndSync();
        }
        reservoir.count++;
        if (reservoir.count % TCGameplayParameters.ALCHEMY_ESSENTIA_RESERVOIR_INTAKE_INTERVAL.intValue() == 0 && reservoir.totalAmount() < reservoir.capacity()) {
            reservoir.fillReservoir();
        }
    }

    public static void clientTick(Level level, BlockPos pos, BlockState state, EssentiaReservoirBlockEntity reservoir) {
        reservoir.count++;
        int total = reservoir.totalAmount();
        if (total <= 0) {
            reservoir.displayAspect = null;
            return;
        }
        // Preserve the default reservoir's fullness-dependent creak rate.
        // Raw enlarged amounts can otherwise make nextInt's bound nonpositive.
        int audibleFullness = (int) Math.min(CAPACITY, (long) total * CAPACITY / reservoir.capacity());
        if (level.random.nextInt(500 - audibleFullness) == 0) {
            level.playLocalSound(pos, TCSounds.RESERVOIR_AMBIENT.get(), SoundSource.BLOCKS, 1.0F, 1.4F + level.random.nextFloat() * 0.2F, false);
        }
        if (reservoir.count % 20 == 0 && !reservoir.essentia.isEmpty()) {
            int index = reservoir.count / 20 % reservoir.essentia.size();
            reservoir.displayAspect = reservoir.essentia.keySet().stream().skip(index).findFirst().orElse(null);
            AspectDefinition definition = AspectCatalog.get(reservoir.displayAspect);
            if (definition != null) {
                float targetRed = (definition.color() >> 16 & 255) / 255.0F;
                float targetGreen = (definition.color() >> 8 & 255) / 255.0F;
                float targetBlue = (definition.color() & 255) / 255.0F;
                reservoir.redIncrement = (reservoir.colorRed - targetRed) / 20.0F;
                reservoir.greenIncrement = (reservoir.colorGreen - targetGreen) / 20.0F;
                reservoir.blueIncrement = (reservoir.colorBlue - targetBlue) / 20.0F;
            }
        }
        if (reservoir.displayAspect != null) {
            reservoir.colorRed -= reservoir.redIncrement;
            reservoir.colorGreen -= reservoir.greenIncrement;
            reservoir.colorBlue -= reservoir.blueIncrement;
        }
    }

    public Map<AspectId, Integer> aspects() {
        return Collections.unmodifiableMap(new LinkedHashMap<>(this.essentia));
    }

    @Override
    public AspectAmounts visibleAspects() {
        return new AspectAmounts(this.essentia);
    }

    public int totalAmount() {
        return (int) Math.min(Integer.MAX_VALUE, this.essentia.values().stream().mapToLong(Integer::longValue).sum());
    }

    @Nullable
    public AspectId displayAspect() {
        return this.displayAspect;
    }

    public float colorRed() {
        return this.colorRed;
    }

    public float colorGreen() {
        return this.colorGreen;
    }

    public float colorBlue() {
        return this.colorBlue;
    }

    public int addToContainer(AspectId aspect, int amount) {
        if (amount <= 0 || !AspectCatalog.contains(aspect)) {
            return amount;
        }
        int space = Math.max(0, capacity() - this.totalAmount());
        int accepted = Math.min(space, amount);
        if (accepted > 0) {
            this.essentia.merge(aspect, accepted, Integer::sum);
            this.changedAndSync();
        }
        return amount - accepted;
    }

    public boolean takeFromContainer(AspectId aspect, int amount) {
        if (aspect == null || amount <= 0 || !AspectCatalog.contains(aspect)) {
            return false;
        }
        int present = this.essentia.getOrDefault(aspect, 0);
        if (present < amount) {
            return false;
        }
        int remaining = present - amount;
        if (remaining <= 0) {
            this.essentia.remove(aspect);
        } else {
            this.essentia.put(aspect, remaining);
        }
        this.changedAndSync();
        return true;
    }

    @Override
    public int extractEssentia(AspectId aspect, int amount, EssentiaTransferMode mode) {
        if (amount <= 0 || this.essentia.getOrDefault(aspect, 0) < amount) {
            return 0;
        }
        return !mode.executes() || this.takeFromContainer(aspect, amount) ? amount : 0;
    }

    public int comparatorOutput() {
        int total = this.totalAmount();
        int capacity = capacity();
        int filled = Math.min(total, capacity);
        return (int) ((long) filled * 14 / capacity) + (total > 0 ? 1 : 0);
    }

    private Direction facing() {
        return this.getBlockState().getValue(EssentiaReservoirBlock.FACING);
    }

    private void fillReservoir() {
        Direction facing = this.facing();
        EssentiaTransport source = this.transportAt(facing);
        if (source == null || !source.canOutputTo(facing.getOpposite())) {
            return;
        }
        Direction sourceFace = facing.getOpposite();
        AspectId candidate = null;
        if (source.essentiaAmount(sourceFace) > 0 && source.suctionAmount(sourceFace) < this.suctionAmount(facing) && this.suctionAmount(facing) >= source.minimumSuction()) {
            candidate = source.essentiaType(sourceFace);
        }
        if (candidate != null && source.suctionAmount(sourceFace) < this.suctionAmount(facing)) {
            this.addToContainer(candidate, EssentiaApi.take(this.level, source, candidate, 1, sourceFace, EssentiaTransferMode.EXECUTE));
        }
    }

    @Nullable
    private EssentiaTransport transportAt(Direction direction) {
        if (this.level == null) {
            return null;
        }
        return ThaumcraftApiHelper.getConnectableTransport(this.level, this.worldPosition, direction);
    }

    @Override
    public boolean isConnectable(Direction face) {
        return face == this.facing();
    }

    @Override
    public boolean canInputFrom(Direction face) {
        return face == this.facing();
    }

    @Override
    public boolean canOutputTo(Direction face) {
        return face == this.facing();
    }

    @Nullable
    @Override
    public AspectId suctionType(Direction face) {
        return null;
    }

    @Override
    public int suctionAmount(Direction face) {
        return this.totalAmount() < capacity() ? TCGameplayParameters.ALCHEMY_ESSENTIA_RESERVOIR_SUCTION.intValue() : 0;
    }

    @Override
    public int takeEssentia(AspectId aspect, int amount, Direction face, EssentiaTransferMode mode) {
        return this.canOutputTo(face) ? this.extractEssentia(aspect, amount, mode) : 0;
    }

    @Override
    public int addEssentia(AspectId aspect, int amount, Direction face, EssentiaTransferMode mode) {
        if (!this.canInputFrom(face) || amount <= 0 || !AspectCatalog.contains(aspect)) {
            return 0;
        }
        int accepted = Math.max(0, Math.min(amount, capacity() - this.totalAmount()));
        if (accepted > 0 && mode.executes()) {
            this.addToContainer(aspect, accepted);
        }
        return accepted;
    }

    @Nullable
    @Override
    public AspectId essentiaType(Direction face) {
        return null;
    }

    @Nullable
    @Override
    public AspectId extractableAspect(Direction face) {
        return this.essentia.entrySet().stream().filter(entry -> entry.getValue() > 0).map(Map.Entry::getKey).filter(AspectCatalog::contains).findFirst().orElse(null);
    }

    @Override
    public int availableEssentia(AspectId aspect, Direction face) {
        if (aspect == null || !AspectCatalog.contains(aspect)) {
            return 0;
        }
        return this.essentia.getOrDefault(aspect, 0);
    }

    @Override
    public int essentiaAmount(Direction face) {
        return this.totalAmount();
    }

    @Override
    public int minimumSuction() {
        return 24;
    }

    @Override
    public boolean renderExtendedTube() {
        return false;
    }

    private void changedAndSync() {
        this.setChanged();
        BlockEntitySync.sendToClientAndUpdateComparator(this);
    }

    @Override
    public void load(CompoundTag tag) {
        super.load(tag);
        AspectNbtList.loadInto(tag, this.essentia);
    }

    @Override
    protected void saveAdditional(CompoundTag tag) {
        super.saveAdditional(tag);
        AspectNbtList.saveFrom(tag, this.essentia);
    }

    @Override
    public CompoundTag getUpdateTag() {
        return this.saveWithoutMetadata();
    }

    @Override
    public Packet<ClientGamePacketListener> getUpdatePacket() {
        return ClientboundBlockEntityDataPacket.create(this);
    }

    protected final HolderLookup.Provider persistenceRegistries() {
        if (level != null)
            return level.registryAccess();
        var server = net.minecraftforge.server.ServerLifecycleHooks.getCurrentServer();
        return server != null ? server.registryAccess() : net.minecraft.core.RegistryAccess.fromRegistryOfRegistries(net.minecraft.core.registries.BuiltInRegistries.REGISTRY);
    }

    protected static net.minecraft.network.chat.Component parseCustomNameSafe(String value, HolderLookup.Provider registries) {
        try {
            return net.minecraft.network.chat.Component.Serializer.fromJson(value);
        } catch (RuntimeException exception) {
            return null;
        }
    }

    protected void readItemFields(ItemFields.Input input) {
    }

    public void copyItemFields(ItemFields.Output output) {
    }

    public void applyComponentsFromItemStack(ItemStack stack) {
        readItemFields(ItemFields.from(stack));
    }

    public void removeComponentsFromTag(CompoundTag tag) {
    }

    @Override
    public void saveToItem(ItemStack stack) {
        CompoundTag tag = saveWithoutMetadata();
        {
            net.minecraft.nbt.CompoundTag native$bodyOperand$6147 = tag;
            native$bodyReturn$6149: {
                if (true) {
                }
            }
        }
        net.minecraft.world.item.BlockItem.setBlockEntityData(stack, getType(), tag);
        copyItemFields(ItemFields.to(stack));
    }

    @Override
    public net.minecraft.world.phys.AABB getRenderBoundingBox() {
        return EssentiaReservoirBlockEntity.native$ClientBlockEntityBounds$bounds(this);
    }

    @Override()
    public void onDataPacket(net.minecraft.network.Connection connection, net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket packet) {
        handleUpdateTag(packet.getTag());
    }

    @SuppressWarnings({ "rawtypes", "unchecked" })
    static private net.minecraft.world.phys.AABB native$ClientBlockEntityBounds$bounds(net.minecraft.world.level.block.entity.BlockEntity blockEntity) {
        var renderer = net.minecraft.client.Minecraft.getInstance().getBlockEntityRenderDispatcher().getRenderer(blockEntity);
        return renderer instanceof dev.tc4port.thaumcraft.nativeimpl.NativeBlockEntityRenderer shared ? shared.getRenderBoundingBox(blockEntity) : new net.minecraft.world.phys.AABB(blockEntity.getBlockPos());
    }

    private boolean native$capabilitiesInvalid$16894;

    public boolean native$capabilityActive$16765;

    public net.minecraftforge.common.capabilities.Capability<dev.tc4port.thaumcraft.api.essentia.EssentiaTransport> native$capabilityCapture$16764;

    private net.minecraftforge.common.util.LazyOptional<dev.tc4port.thaumcraft.api.essentia.EssentiaTransport> native$capabilityHandle$16766;

    public boolean native$capabilityActive$16782;

    public net.minecraftforge.common.capabilities.Capability<dev.tc4port.thaumcraft.api.essentia.EssentiaSource> native$capabilityCapture$16781;

    private net.minecraftforge.common.util.LazyOptional<dev.tc4port.thaumcraft.api.essentia.EssentiaSource> native$capabilityHandle$16783;

    @Override
    public <native$capabilityResultType$16895> net.minecraftforge.common.util.LazyOptional<native$capabilityResultType$16895> getCapability(net.minecraftforge.common.capabilities.Capability<native$capabilityResultType$16895> native$requestedCapability$16896, net.minecraft.core.Direction native$requestedFace$16897) {
        getCapabilities();
        synchronized (this) {
            if (native$capabilitiesInvalid$16894)
                return net.minecraftforge.common.util.LazyOptional.empty();
            if (native$capabilityActive$16765 && native$requestedCapability$16896 == (this.native$capabilityCapture$16764)) {
                if (native$capabilityHandle$16766 == null)
                    native$capabilityHandle$16766 = net.minecraftforge.common.util.LazyOptional.of(() -> this);
                return native$capabilityHandle$16766.cast();
            }
            if (native$capabilityActive$16782 && native$requestedCapability$16896 == (this.native$capabilityCapture$16781)) {
                if (native$capabilityHandle$16783 == null)
                    native$capabilityHandle$16783 = net.minecraftforge.common.util.LazyOptional.of(() -> this);
                return native$capabilityHandle$16783.cast();
            }
        }
        return super.getCapability(native$requestedCapability$16896, native$requestedFace$16897);
    }

    @Override
    public void invalidateCaps() {
        java.util.List<net.minecraftforge.common.util.LazyOptional<?>> native$expiredCapabilities$16898 = new java.util.ArrayList<>();
        synchronized (this) {
            native$capabilitiesInvalid$16894 = true;
            if (native$capabilityHandle$16766 != null) {
                native$expiredCapabilities$16898.add(native$capabilityHandle$16766);
                native$capabilityHandle$16766 = null;
            }
            if (native$capabilityHandle$16783 != null) {
                native$expiredCapabilities$16898.add(native$capabilityHandle$16783);
                native$capabilityHandle$16783 = null;
            }
        }
        try {
            super.invalidateCaps();
        } finally {
            native$expiredCapabilities$16898.forEach(net.minecraftforge.common.util.LazyOptional::invalidate);
        }
    }

    @Override
    public void reviveCaps() {
        super.reviveCaps();
        synchronized (this) {
            native$capabilitiesInvalid$16894 = false;
        }
    }
}
