package dev.tc4port.thaumcraft.api.focus.action;

import java.util.List;

public interface FocusActionRegistryView {

    long generation();

    List<FocusActionSpec> actions();
}
