package dev.tc4port.thaumcraft.api.wand.behavior;

@FunctionalInterface
public interface WandServerBehavior {

    /**
     * Called by TC on the owning server thread at the API's 20-tick cadence.
     */
    void serverTick(WandServerContext context);
}
