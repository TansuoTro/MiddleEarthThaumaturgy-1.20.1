package dev.tc4port.thaumcraft.block.entity;

import dev.tc4port.thaumcraft.block.NodeStabilizerBlock;
import dev.tc4port.thaumcraft.registry.TCBlockEntities;
import dev.tc4port.thaumcraft.registry.TCBlocks;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import java.lang.Math;
import dev.tc4port.thaumcraft.nativeimpl.state.ItemFields;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityType;

/**
 * Client piston interpolation from TileNodeStabilizer.
 */
public final class NodeStabilizerBlockEntity extends net.minecraft.world.level.block.entity.BlockEntity implements ItemFields.Source {

    public static final int MAX_EXTENSION = 37;

    private int count;

    public NodeStabilizerBlockEntity(BlockPos pos, BlockState state) {
        super(TCBlockEntities.NODE_STABILIZER.get(), pos, state);
    }

    public int count() {
        return this.count;
    }

    public float extension(float partialTick) {
        if (this.level == null) {
            return 0.0F;
        }
        boolean active = isActive(this.level, this.worldPosition);
        float interpolated = active ? Math.min(MAX_EXTENSION, this.count + partialTick) : Math.max(0.0F, this.count - partialTick);
        return interpolated / 100.0F;
    }

    public int lockStrength() {
        return this.getBlockState().getBlock() instanceof NodeStabilizerBlock stabilizer ? stabilizer.lockStrength() : 1;
    }

    public static void clientTick(Level level, BlockPos pos, BlockState state, NodeStabilizerBlockEntity stabilizer) {
        if (isActive(level, pos)) {
            stabilizer.count = Math.min(MAX_EXTENSION, stabilizer.count + 1);
        } else {
            stabilizer.count = Math.max(0, stabilizer.count - 1);
        }
    }

    public static boolean isActive(Level level, BlockPos pos) {
        if (!level.hasChunksAt(pos.offset(-2, 0, -2), pos.offset(2, 0, 2)))
            return false;
        BlockState above = level.getBlockState(pos.above());
        return (above.is(TCBlocks.AURA_NODE.get()) || above.is(TCBlocks.ENERGIZED_AURA_NODE.get())) && !level.hasNeighborSignal(pos);
    }

    protected final HolderLookup.Provider persistenceRegistries() {
        if (level != null)
            return level.registryAccess();
        var server = net.minecraftforge.server.ServerLifecycleHooks.getCurrentServer();
        return server != null ? server.registryAccess() : net.minecraft.core.RegistryAccess.fromRegistryOfRegistries(net.minecraft.core.registries.BuiltInRegistries.REGISTRY);
    }

    protected static net.minecraft.network.chat.Component parseCustomNameSafe(String value, HolderLookup.Provider registries) {
        try {
            return net.minecraft.network.chat.Component.Serializer.fromJson(value);
        } catch (RuntimeException exception) {
            return null;
        }
    }

    protected void readItemFields(ItemFields.Input input) {
    }

    public void copyItemFields(ItemFields.Output output) {
    }

    public void applyComponentsFromItemStack(ItemStack stack) {
        readItemFields(ItemFields.from(stack));
    }

    public void removeComponentsFromTag(CompoundTag tag) {
    }

    @Override
    public void saveToItem(ItemStack stack) {
        CompoundTag tag = saveWithoutMetadata();
        {
            net.minecraft.nbt.CompoundTag native$bodyOperand$6208 = tag;
            native$bodyReturn$6210: {
                if (true) {
                }
            }
        }
        net.minecraft.world.item.BlockItem.setBlockEntityData(stack, getType(), tag);
        copyItemFields(ItemFields.to(stack));
    }

    @Override
    public net.minecraft.world.phys.AABB getRenderBoundingBox() {
        return NodeStabilizerBlockEntity.native$ClientBlockEntityBounds$bounds(this);
    }

    @Override()
    public void onDataPacket(net.minecraft.network.Connection connection, net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket packet) {
        handleUpdateTag(packet.getTag());
    }

    @SuppressWarnings({ "rawtypes", "unchecked" })
    static private net.minecraft.world.phys.AABB native$ClientBlockEntityBounds$bounds(net.minecraft.world.level.block.entity.BlockEntity blockEntity) {
        var renderer = net.minecraft.client.Minecraft.getInstance().getBlockEntityRenderDispatcher().getRenderer(blockEntity);
        return renderer instanceof dev.tc4port.thaumcraft.nativeimpl.NativeBlockEntityRenderer shared ? shared.getRenderBoundingBox(blockEntity) : new net.minecraft.world.phys.AABB(blockEntity.getBlockPos());
    }
}
