package dev.tc4port.thaumcraft.api.research;

import java.util.List;
import java.util.Optional;
import javax.annotation.Nullable;
import net.minecraft.world.item.ItemStack;

/**
 * Opt-in presentation for a dynamic crafting recipe with no static result.
 * Implement on the native recipe class. Each cycle must return a complete,
 * actually craftable example; all input slots and the output cycle together.
 * The book and recipe viewers query only recipes present in the live recipe manager.
 */
public interface ResearchCraftingRecipe {

    /**
     * Returns null when the current data permits no craftable display example.
     */
    @Nullable
    ResearchCraftingExample researchCraftingExample(long cycle);

    /**
     * Finite, complete examples for unfocused recipe browsing. Never enumerate all combinations.
     */
    default List<ResearchCraftingExample> researchCraftingExamples() {
        var example = researchCraftingExample(0);
        return example == null ? List.of() : List.of(example);
    }

    /**
     * Optional inverse lookup for a specific output, including its component state.
     * The viewer passes an owned copy and validates the returned grid against the live recipe.
     * Return empty if that output cannot be crafted. Do not change world or recipe state.
     */
    default Optional<ResearchCraftingExample> researchCraftingExampleForOutput(ItemStack output) {
        return researchCraftingExamples().stream().filter(example -> net.minecraft.world.item.ItemStack.isSameItemSameTags((net.minecraft.world.item.ItemStack) (example.output()), (net.minecraft.world.item.ItemStack) (output))).findFirst();
    }
}
