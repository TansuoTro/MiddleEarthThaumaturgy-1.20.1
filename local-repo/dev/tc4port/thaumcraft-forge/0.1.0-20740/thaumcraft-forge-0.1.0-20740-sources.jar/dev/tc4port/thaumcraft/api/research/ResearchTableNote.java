package dev.tc4port.thaumcraft.api.research;

import dev.tc4port.thaumcraft.api.aspect.AspectId;
import java.util.List;
import java.util.Optional;

/**
 * Immutable projection of the currently synchronized note; contains no writable item state.
 */
public record ResearchTableNote(Optional<ResearchKey> research, int color, boolean complete, int copies, List<Cell> cells) {

    public ResearchTableNote {
        cells = List.copyOf(cells);
    }

    public enum Kind {

        BLANK, FIXED, PLACED
    }

    public record Cell(int q, int r, Kind kind, Optional<AspectId> aspect) {
    }
}
