package dev.tc4port.thaumcraft.block;

import com.mojang.serialization.MapCodec;
import dev.tc4port.thaumcraft.block.entity.ArcaneLevitatorBlockEntity;
import dev.tc4port.thaumcraft.registry.TCBlockEntities;
import dev.tc4port.thaumcraft.registry.TCParticles;
import javax.annotation.Nullable;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.util.RandomSource;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityTicker;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;
import dev.tc4port.thaumcraft.nativeimpl.ClientExtensionTarget;
import dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.level.pathfinder.PathComputationType;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.level.Explosion;

/**
 * TC4's independent {@code BlockLifter}.
 *
 * <p>The block is a collision/occlusion cube, but the source explicitly
 * reported only its four horizontal faces as solid. The thin four-wall
 * support shape preserves that unusual attachment contract without changing
 * the full collision shape.</p>
 */
public final class ArcaneLevitatorBlock extends net.minecraft.world.level.block.BaseEntityBlock implements dev.tc4port.thaumcraft.nativeimpl.ClientExtensionTarget {

    // Forge calls initializeClient from the native superclass constructor. Do not add a field initializer.
    private java.util.function.Consumer<net.minecraftforge.client.extensions.common.IClientBlockExtensions> platform$clientInstaller;

    public static final MapCodec<ArcaneLevitatorBlock> CODEC = ArcaneLevitatorBlock.native$BlockCodecPlatform$simple(ArcaneLevitatorBlock::new);

    public static final BooleanProperty POWERED = BooleanProperty.create("powered");

    private static final VoxelShape HORIZONTAL_SUPPORT = Shapes.or(Block.box(0.0, 0.0, 0.0, 1.0, 16.0, 16.0), Block.box(15.0, 0.0, 0.0, 16.0, 16.0, 16.0), Block.box(0.0, 0.0, 0.0, 16.0, 16.0, 1.0), Block.box(0.0, 0.0, 15.0, 16.0, 16.0, 16.0));

    public ArcaneLevitatorBlock(BlockBehaviour.Properties properties) {
        this(properties, properties, true);
    }

    protected MapCodec<ArcaneLevitatorBlock> codec() {
        return CODEC;
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(POWERED);
    }

    @Nullable
    @Override
    public BlockState getStateForPlacement(BlockPlaceContext context) {
        return this.defaultBlockState().setValue(POWERED, ArcaneLevitatorBlockEntity.gettingPower(context.getLevel(), context.getClickedPos()));
    }

    @Nullable
    @Override
    public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        return new ArcaneLevitatorBlockEntity(pos, state);
    }

    @Nullable
    @Override
    public <T extends BlockEntity> BlockEntityTicker<T> getTicker(Level level, BlockState state, BlockEntityType<T> type) {
        /*
         * TileLifter.updateEntity ran in both logical worlds. The client
         * half is essential for the locally controlled player: waiting for
         * the authoritative server velocity alone lets modern client
         * movement overwrite the lift and makes the field appear inert.
         */
        return createTickerHelper(type, TCBlockEntities.ARCANE_LEVITATOR.get(), ArcaneLevitatorBlockEntity::tick);
    }

    @Override
    public RenderShape getRenderShape(BlockState state) {
        /*
         * BaseEntityBlock defaults to INVISIBLE in 1.21. BlockLifter used a
         * normal textured cube plus custom glow faces, so the baked body
         * must participate in chunk rendering.
         */
        return RenderShape.MODEL;
    }

    @Override
    public void onPlace(BlockState state, Level level, BlockPos pos, BlockState oldState, boolean movedByPiston) {
        super.onPlace(state, level, pos, oldState, movedByPiston);
        if (!oldState.is(state.getBlock())) {
            requestStackBelow(level, pos);
        }
    }

    @Override
    public void onRemove(BlockState state, Level level, BlockPos pos, BlockState newState, boolean movedByPiston) {
        if (!state.is(newState.getBlock())) {
            requestStackBelow(level, pos);
        }
        super.onRemove(state, level, pos, newState, movedByPiston);
    }

    @Override
    public void neighborChanged(BlockState state, Level level, BlockPos pos, Block neighborBlock, BlockPos neighborPos, boolean movedByPiston) {
        super.neighborChanged(state, level, pos, neighborBlock, neighborPos, movedByPiston);
        boolean powered = ArcaneLevitatorBlockEntity.gettingPower(level, pos);
        if (powered != state.getValue(POWERED)) {
            level.setBlock(pos, state.setValue(POWERED, powered), Block.UPDATE_CLIENTS);
            requestStackBelow(level, pos);
        }
    }

    @Override
    public void animateTick(BlockState state, Level level, BlockPos pos, RandomSource random) {
        BlockEntity blockEntity = level.getBlockEntity(pos);
        if (!(blockEntity instanceof ArcaneLevitatorBlockEntity levitator) || ArcaneLevitatorBlockEntity.gettingPower(level, pos) || /*
                 * ClientProxy.sparkle accepted 4 of 6 attempts at the
                 * default particle setting. Modern minimal particles are
                 * still filtered by LevelRenderer.
                 */
        random.nextInt(6) >= 4 || /*
                 * BlockLifter read TileLifter.rangeAbove here. Recomputing
                 * the column inside randomDisplayTick made particles appear
                 * before the tile's first update and ignored its 100-tick
                 * cache contract.
                 */
        levitator.rangeAbove() <= 0) {
            return;
        }
        level.addParticle(TCParticles.LIFTER_SPARKLE.get(), pos.getX() + 0.2 + random.nextFloat() * 0.6, pos.getY() + 1.0, pos.getZ() + 0.2 + random.nextFloat() * 0.6, 0.0, 0.0, 0.0);
    }

    @Override
    public VoxelShape getBlockSupportShape(BlockState state, BlockGetter level, BlockPos pos) {
        return HORIZONTAL_SUPPORT;
    }

    @Override
    public boolean canConnectRedstone(BlockState state, BlockGetter level, BlockPos pos, @Nullable Direction direction) {
        return direction != null && direction.getAxis().isHorizontal();
    }

    private void requestStackBelow(Level level, BlockPos pos) {
        BlockPos.MutableBlockPos cursor = pos.mutable().move(Direction.DOWN);
        while (level.getBlockState(cursor).is(this)) {
            if (level.getBlockEntity(cursor) instanceof ArcaneLevitatorBlockEntity levitator) {
                levitator.requestRangeUpdate();
            }
            cursor.move(Direction.DOWN);
        }
    }

    private ArcaneLevitatorBlock(net.minecraft.world.level.block.state.BlockBehaviour.Properties native$NativeEntityBlock$arg0, BlockBehaviour.Properties properties, boolean native$NativeEntityBlock$captured) {
        super(native$NativeEntityBlock$arg0);
        this.registerDefaultState(this.stateDefinition.any().setValue(POWERED, false));
    }

    @Override
    public void initializeClient(java.util.function.Consumer<net.minecraftforge.client.extensions.common.IClientBlockExtensions> installer) {
        platform$clientInstaller = installer;
        super.initializeClient(installer);
    }

    @Override
    public void platform$clientExtension(Object extension) {
        java.util.Objects.requireNonNull(platform$clientInstaller, "Forge initializeClient must run before client extension registration").accept((net.minecraftforge.client.extensions.common.IClientBlockExtensions) extension);
    }

    @Override
    public InteractionResult use(BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
        ItemUseResult result = (switch(0) {
            default ->
                {
                    net.minecraft.world.item.ItemStack native$bodyOperand$4156 = player.getItemInHand(hand);
                    net.minecraft.world.level.block.state.BlockState native$bodyOperand$4157 = state;
                    net.minecraft.world.level.Level native$bodyOperand$4158 = level;
                    net.minecraft.core.BlockPos native$bodyOperand$4159 = pos;
                    net.minecraft.world.entity.player.Player native$bodyOperand$4160 = player;
                    net.minecraft.world.InteractionHand native$bodyOperand$4161 = hand;
                    net.minecraft.world.phys.BlockHitResult native$bodyOperand$4162 = hit;
                    dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult native$bodyResult$4163 = null;
                    native$bodyReturn$4164: {
                        if (true) {
                            {
                                native$bodyResult$4163 = dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
                                break native$bodyReturn$4164;
                            }
                        }
                    }
                    yield native$bodyResult$4163;
                }
        });
        return result == ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION ? (hand == InteractionHand.MAIN_HAND ? (switch(0) {
            default ->
                {
                    net.minecraft.world.level.block.state.BlockState native$bodyOperand$3491 = state;
                    net.minecraft.world.level.Level native$bodyOperand$3492 = level;
                    net.minecraft.core.BlockPos native$bodyOperand$3493 = pos;
                    net.minecraft.world.entity.player.Player native$bodyOperand$3494 = player;
                    net.minecraft.world.phys.BlockHitResult native$bodyOperand$3495 = hit;
                    net.minecraft.world.InteractionResult native$bodyResult$3496 = null;
                    native$bodyReturn$3497: {
                        if (true) {
                            {
                                native$bodyResult$3496 = super.use(native$bodyOperand$3491, native$bodyOperand$3492, native$bodyOperand$3493, native$bodyOperand$3494, net.minecraft.world.InteractionHand.MAIN_HAND, native$bodyOperand$3495);
                                break native$bodyReturn$3497;
                            }
                        }
                    }
                    yield native$bodyResult$3496;
                }
        }) : InteractionResult.PASS) : result.result();
    }

    protected ItemUseResult interactWithItem(ItemStack stack, BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
        return dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
    }

    protected InteractionResult interactWithoutItem(BlockState state, Level level, BlockPos pos, Player player, BlockHitResult hit) {
        return super.use(state, level, pos, player, net.minecraft.world.InteractionHand.MAIN_HAND, hit);
    }

    @Override
    public void playerWillDestroy(Level level, BlockPos pos, BlockState state, Player player) {
        {
            net.minecraft.world.level.Level native$bodyOperand$5672 = level;
            net.minecraft.core.BlockPos native$bodyOperand$5673 = pos;
            net.minecraft.world.level.block.state.BlockState native$bodyOperand$5674 = state;
            net.minecraft.world.entity.player.Player native$bodyOperand$5675 = player;
            net.minecraft.world.level.block.state.BlockState native$bodyResult$5676 = null;
            native$bodyReturn$5677: {
                if (true) {
                    super.playerWillDestroy(native$bodyOperand$5672, native$bodyOperand$5673, native$bodyOperand$5674, native$bodyOperand$5675);
                    {
                        native$bodyResult$5676 = native$bodyOperand$5674;
                        break native$bodyReturn$5677;
                    }
                }
            }
        }
    }

    public BlockState beforePlayerDestroy(Level level, BlockPos pos, BlockState state, Player player) {
        super.playerWillDestroy(level, pos, state, player);
        return state;
    }

    protected boolean survivesSharedExplosion() {
        return false;
    }

    public int getExpDrop(net.minecraft.world.level.block.state.BlockState native$callbackInput$1050, net.minecraft.world.level.LevelReader native$callbackInput$1051, net.minecraft.util.RandomSource native$callbackInput$1052, net.minecraft.core.BlockPos native$callbackInput$1053, int native$callbackInput$1054, int native$callbackInput$1055) {
        net.minecraft.world.level.block.state.BlockState state = native$callbackInput$1050;
        net.minecraft.util.RandomSource random = native$callbackInput$1052;
        return 0;
    }

    @Override
    public void onBlockExploded(BlockState state, Level level, BlockPos pos, Explosion explosion) {
        if (!(switch(0) {
            default ->
                {
                    boolean native$bodyResult$5219 = false;
                    native$bodyReturn$5220: {
                        if (true) {
                            {
                                native$bodyResult$5219 = false;
                                break native$bodyReturn$5220;
                            }
                        }
                    }
                    yield native$bodyResult$5219;
                }
        }))
            super.onBlockExploded(state, level, pos, explosion);
    }

    @Override
    public boolean canDropFromExplosion(BlockState state, BlockGetter level, BlockPos pos, Explosion explosion) {
        return !(switch(0) {
            default ->
                {
                    boolean native$bodyResult$4165 = false;
                    native$bodyReturn$4166: {
                        if (true) {
                            {
                                native$bodyResult$4165 = false;
                                break native$bodyReturn$4166;
                            }
                        }
                    }
                    yield native$bodyResult$4165;
                }
        }) && super.canDropFromExplosion(state, level, pos, explosion);
    }

    static private <B extends net.minecraft.world.level.block.Block> com.mojang.serialization.MapCodec<B> native$BlockCodecPlatform$simple(java.util.function.Function<net.minecraft.world.level.block.state.BlockBehaviour.Properties, B> factory) {
        // Vanilla 1.21's Properties codec is a unit codec. Retain that schema for shared block definitions.
        return com.mojang.serialization.codecs.RecordCodecBuilder.mapCodec(instance -> instance.group(com.mojang.serialization.Codec.unit(net.minecraft.world.level.block.state.BlockBehaviour.Properties::of).fieldOf("properties").forGetter((B block) -> net.minecraft.world.level.block.state.BlockBehaviour.Properties.copy(block))).apply(instance, factory));
    }
}
