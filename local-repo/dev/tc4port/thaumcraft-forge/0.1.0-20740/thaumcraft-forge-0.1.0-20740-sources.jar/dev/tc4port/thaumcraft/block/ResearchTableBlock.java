package dev.tc4port.thaumcraft.block;

import com.mojang.serialization.MapCodec;
import dev.tc4port.thaumcraft.block.entity.ResearchTableBlockEntity;
import dev.tc4port.thaumcraft.registry.TCBlockEntities;
import dev.tc4port.thaumcraft.registry.TCBlocks;
import javax.annotation.Nullable;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.Containers;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.Mirror;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.Rotation;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityTicker;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.world.level.block.state.properties.DirectionProperty;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;
import dev.tc4port.thaumcraft.nativeimpl.ClientExtensionTarget;
import dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.level.pathfinder.PathComputationType;
import net.minecraft.world.phys.HitResult;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.Explosion;

/**
 * Metadata 2..9 represented as an explicit primary/partner two-block state.
 */
public final class ResearchTableBlock extends net.minecraft.world.level.block.BaseEntityBlock implements dev.tc4port.thaumcraft.nativeimpl.ClientExtensionTarget {

    // Forge calls initializeClient from the native superclass constructor. Do not add a field initializer.
    private java.util.function.Consumer<net.minecraftforge.client.extensions.common.IClientBlockExtensions> platform$clientInstaller;

    public static final MapCodec<ResearchTableBlock> CODEC = ResearchTableBlock.native$BlockCodecPlatform$simple(ResearchTableBlock::new);

    public static final DirectionProperty FACING = BlockStateProperties.HORIZONTAL_FACING;

    public static final BooleanProperty PRIMARY = BooleanProperty.create("primary");

    private static final VoxelShape NORTH_SHAPE = Block.box(0.0, 0.0, -16.0, 16.0, 16.0, 16.0);

    private static final VoxelShape SOUTH_SHAPE = Block.box(0.0, 0.0, 0.0, 16.0, 16.0, 32.0);

    private static final VoxelShape WEST_SHAPE = Block.box(-16.0, 0.0, 0.0, 16.0, 16.0, 16.0);

    private static final VoxelShape EAST_SHAPE = Block.box(0.0, 0.0, 0.0, 32.0, 16.0, 16.0);

    public ResearchTableBlock(BlockBehaviour.Properties properties) {
        this(properties, properties, true);
    }

    protected MapCodec<ResearchTableBlock> codec() {
        return CODEC;
    }

    @Nullable
    @Override
    public BlockState getStateForPlacement(BlockPlaceContext context) {
        /*
         * The source never exposed metadata 2..9 as an ordinary creative
         * placement.  The split modern registry does expose a research-table
         * item, so its placement must not create an orphan primary whose
         * renderer merely extends into an empty neighboring cell.  Put the
         * partner on the player's right to match the item renderer's
         * left-primary/right-partner layout.
         */
        Direction partnerDirection = context.getHorizontalDirection().getClockWise();
        BlockPos partnerPos = context.getClickedPos().relative(partnerDirection);
        Level level = context.getLevel();
        BlockState primary = this.defaultBlockState().setValue(FACING, partnerDirection).setValue(PRIMARY, true);
        BlockState partner = primary.setValue(PRIMARY, false);
        CollisionContext collision = context.getPlayer() == null ? CollisionContext.empty() : CollisionContext.of(context.getPlayer());
        return level.getBlockState(partnerPos).canBeReplaced(context) && level.getWorldBorder().isWithinBounds(partnerPos) && level.isUnobstructed(partner, partnerPos, collision) ? primary : null;
    }

    @Override
    public void setPlacedBy(Level level, BlockPos pos, BlockState state, @Nullable LivingEntity placer, ItemStack stack) {
        super.setPlacedBy(level, pos, state, placer, stack);
        if (!level.isClientSide) {
            BlockPos partnerPos = pos.relative(state.getValue(FACING));
            level.setBlock(partnerPos, state.setValue(PRIMARY, false), Block.UPDATE_ALL);
            level.blockUpdated(pos, Blocks.AIR);
            state.updateNeighbourShapes(level, pos, Block.UPDATE_ALL);
        }
    }

    public static void form(Level level, BlockPos primaryPos, Direction partnerDirection, ItemStack scribingTools) {
        BlockPos partnerPos = primaryPos.relative(partnerDirection);
        BlockState primary = TCBlocks.RESEARCH_TABLE.get().defaultBlockState().setValue(FACING, partnerDirection).setValue(PRIMARY, true);
        BlockState partner = primary.setValue(PRIMARY, false);
        level.setBlock(primaryPos, primary, Block.UPDATE_ALL);
        level.setBlock(partnerPos, partner, Block.UPDATE_ALL);
        if (level.getBlockEntity(primaryPos) instanceof ResearchTableBlockEntity table) {
            table.setItem(ResearchTableBlockEntity.SCRIBING_SLOT, scribingTools);
        }
    }

    @Nullable
    @Override
    public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        return state.getValue(PRIMARY) ? new ResearchTableBlockEntity(pos, state) : null;
    }

    @Nullable
    @Override
    public <T extends BlockEntity> BlockEntityTicker<T> getTicker(Level level, BlockState state, BlockEntityType<T> type) {
        return level.isClientSide || !state.getValue(PRIMARY) ? null : createTickerHelper(type, TCBlockEntities.RESEARCH_TABLE.get(), ResearchTableBlockEntity::serverTick);
    }

    @Override
    public RenderShape getRenderShape(BlockState state) {
        return RenderShape.MODEL;
    }

    @Override
    public VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
        Direction towardOther = state.getValue(PRIMARY) ? state.getValue(FACING) : state.getValue(FACING).getOpposite();
        return switch(towardOther) {
            case NORTH ->
                NORTH_SHAPE;
            case SOUTH ->
                SOUTH_SHAPE;
            case WEST ->
                WEST_SHAPE;
            default ->
                EAST_SHAPE;
        };
    }

    @Override
    public VoxelShape getCollisionShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
        /*
         * BlockTable only enlarged the selected bounding box for metadata
         * 2..9. It never replaced the inherited full-block collision box.
         * Modern BlockBehaviour otherwise reuses getShape here, which made
         * either half collide through the neighboring desk cell.
         */
        return Shapes.block();
    }

    @Override
    public VoxelShape getBlockSupportShape(BlockState state, BlockGetter level, BlockPos pos) {
        return TableBlock.TOP_SUPPORT;
    }

    protected InteractionResult interactWithoutItem(BlockState state, Level level, BlockPos pos, Player player, BlockHitResult hit) {
        if (player.isShiftKeyDown()) {
            return net.minecraft.world.InteractionResult.PASS;
        }
        net.minecraft.core.BlockPos primaryPos = primaryPosition(state, pos);
        if (level.isClientSide) {
            return net.minecraft.world.InteractionResult.SUCCESS;
        }
        if (player instanceof net.minecraft.server.level.ServerPlayer serverPlayer && level.getBlockEntity(primaryPos) instanceof dev.tc4port.thaumcraft.block.entity.ResearchTableBlockEntity table) {
            net.minecraftforge.network.NetworkHooks.openScreen((net.minecraft.server.level.ServerPlayer) (serverPlayer), (net.minecraft.world.MenuProvider) (table), (java.util.function.Consumer<net.minecraft.network.FriendlyByteBuf>) (buffer -> buffer.writeBlockPos(primaryPos)));
        }
        return net.minecraft.world.InteractionResult.CONSUME;
    }

    @Override
    public BlockState updateShape(BlockState state, Direction direction, BlockState neighborState, net.minecraft.world.level.LevelAccessor level, BlockPos currentPos, BlockPos neighborPos) {
        Direction towardOther = state.getValue(PRIMARY) ? state.getValue(FACING) : state.getValue(FACING).getOpposite();
        if (direction == towardOther && (!neighborState.is(this) || neighborState.getValue(PRIMARY) == state.getValue(PRIMARY))) {
            /*
             * Level#setBlock can propagate the missing-part shape update
             * before the removed half's onRemove callback runs. In that
             * order, returning a plain table first destroys the primary
             * block entity and its two-slot inventory is lost. Empty the
             * primary while it is still available; onRemove may encounter
             * it again, but dropContents clears the slots and therefore
             * remains exactly-once.
             */
            if (level instanceof Level concreteLevel && !concreteLevel.isClientSide) {
                BlockPos primaryPos = primaryPosition(state, currentPos);
                if (concreteLevel.getBlockEntity(primaryPos) instanceof ResearchTableBlockEntity table) {
                    Containers.dropContents(concreteLevel, primaryPos, table);
                }
            }
            return TCBlocks.TABLE.get().defaultBlockState();
        }
        return super.updateShape(state, direction, neighborState, level, currentPos, neighborPos);
    }

    @Override
    public void onRemove(BlockState state, Level level, BlockPos pos, BlockState newState, boolean movedByPiston) {
        if (!state.is(newState.getBlock())) {
            BlockPos primaryPos = primaryPosition(state, pos);
            if (level.getBlockEntity(primaryPos) instanceof ResearchTableBlockEntity table) {
                Containers.dropContents(level, primaryPos, table);
            }
            Direction towardOther = state.getValue(PRIMARY) ? state.getValue(FACING) : state.getValue(FACING).getOpposite();
            BlockPos otherPos = pos.relative(towardOther);
            BlockState other = level.getBlockState(otherPos);
            if (other.is(this)) {
                level.setBlock(otherPos, TCBlocks.TABLE.get().defaultBlockState(), Block.UPDATE_ALL);
            }
        }
        super.onRemove(state, level, pos, newState, movedByPiston);
    }

    private static BlockPos primaryPosition(BlockState state, BlockPos pos) {
        return state.getValue(PRIMARY) ? pos : pos.relative(state.getValue(FACING).getOpposite());
    }

    @Override
    public BlockState rotate(BlockState state, Rotation rotation) {
        return state.setValue(FACING, rotation.rotate(state.getValue(FACING)));
    }

    @Override
    public BlockState mirror(BlockState state, Mirror mirror) {
        return this.rotate(state, mirror.getRotation(state.getValue(FACING)));
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(FACING, PRIMARY);
    }

    private ResearchTableBlock(net.minecraft.world.level.block.state.BlockBehaviour.Properties native$NativeEntityBlock$arg0, BlockBehaviour.Properties properties, boolean native$NativeEntityBlock$captured) {
        super(native$NativeEntityBlock$arg0);
        this.registerDefaultState(this.stateDefinition.any().setValue(FACING, Direction.EAST).setValue(PRIMARY, true));
    }

    @Override
    public void initializeClient(java.util.function.Consumer<net.minecraftforge.client.extensions.common.IClientBlockExtensions> installer) {
        platform$clientInstaller = installer;
        super.initializeClient(installer);
    }

    @Override
    public void platform$clientExtension(Object extension) {
        java.util.Objects.requireNonNull(platform$clientInstaller, "Forge initializeClient must run before client extension registration").accept((net.minecraftforge.client.extensions.common.IClientBlockExtensions) extension);
    }

    @Override
    public InteractionResult use(BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
        ItemUseResult result = (switch(0) {
            default ->
                {
                    net.minecraft.world.item.ItemStack native$bodyOperand$4673 = player.getItemInHand(hand);
                    net.minecraft.world.level.block.state.BlockState native$bodyOperand$4674 = state;
                    net.minecraft.world.level.Level native$bodyOperand$4675 = level;
                    net.minecraft.core.BlockPos native$bodyOperand$4676 = pos;
                    net.minecraft.world.entity.player.Player native$bodyOperand$4677 = player;
                    net.minecraft.world.InteractionHand native$bodyOperand$4678 = hand;
                    net.minecraft.world.phys.BlockHitResult native$bodyOperand$4679 = hit;
                    dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult native$bodyResult$4680 = null;
                    native$bodyReturn$4681: {
                        if (true) {
                            {
                                native$bodyResult$4680 = dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
                                break native$bodyReturn$4681;
                            }
                        }
                    }
                    yield native$bodyResult$4680;
                }
        });
        return result == ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION ? (hand == InteractionHand.MAIN_HAND ? (switch(0) {
            default ->
                {
                    net.minecraft.world.level.block.state.BlockState native$bodyOperand$3829 = state;
                    net.minecraft.world.level.Level native$bodyOperand$3830 = level;
                    net.minecraft.core.BlockPos native$bodyOperand$3831 = pos;
                    net.minecraft.world.entity.player.Player native$bodyOperand$3832 = player;
                    net.minecraft.world.phys.BlockHitResult native$bodyOperand$3833 = hit;
                    net.minecraft.world.InteractionResult native$bodyResult$3838 = null;
                    native$bodyReturn$3839: {
                        if (true) {
                            if (native$bodyOperand$3832.isShiftKeyDown()) {
                                {
                                    native$bodyResult$3838 = net.minecraft.world.InteractionResult.PASS;
                                    break native$bodyReturn$3839;
                                }
                            }
                            net.minecraft.core.BlockPos native$bodyBinding$3834 = primaryPosition(native$bodyOperand$3829, native$bodyOperand$3831);
                            if (native$bodyOperand$3830.isClientSide) {
                                {
                                    native$bodyResult$3838 = net.minecraft.world.InteractionResult.SUCCESS;
                                    break native$bodyReturn$3839;
                                }
                            }
                            if (native$bodyOperand$3832 instanceof net.minecraft.server.level.ServerPlayer native$bodyBinding$3835 && native$bodyOperand$3830.getBlockEntity(native$bodyBinding$3834) instanceof dev.tc4port.thaumcraft.block.entity.ResearchTableBlockEntity native$bodyBinding$3836) {
                                net.minecraftforge.network.NetworkHooks.openScreen((net.minecraft.server.level.ServerPlayer) (native$bodyBinding$3835), (net.minecraft.world.MenuProvider) (native$bodyBinding$3836), (java.util.function.Consumer<net.minecraft.network.FriendlyByteBuf>) (native$bodyBinding$3837 -> native$bodyBinding$3837.writeBlockPos(native$bodyBinding$3834)));
                            }
                            {
                                native$bodyResult$3838 = net.minecraft.world.InteractionResult.CONSUME;
                                break native$bodyReturn$3839;
                            }
                        }
                    }
                    yield native$bodyResult$3838;
                }
        }) : InteractionResult.PASS) : result.result();
    }

    protected ItemUseResult interactWithItem(ItemStack stack, BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
        return dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
    }

    @Override
    public void playerWillDestroy(Level level, BlockPos pos, BlockState state, Player player) {
        {
            net.minecraft.world.level.Level native$bodyOperand$5980 = level;
            net.minecraft.core.BlockPos native$bodyOperand$5981 = pos;
            net.minecraft.world.level.block.state.BlockState native$bodyOperand$5982 = state;
            net.minecraft.world.entity.player.Player native$bodyOperand$5983 = player;
            net.minecraft.world.level.block.state.BlockState native$bodyResult$5984 = null;
            native$bodyReturn$5985: {
                if (true) {
                    super.playerWillDestroy(native$bodyOperand$5980, native$bodyOperand$5981, native$bodyOperand$5982, native$bodyOperand$5983);
                    {
                        native$bodyResult$5984 = native$bodyOperand$5982;
                        break native$bodyReturn$5985;
                    }
                }
            }
        }
    }

    public BlockState beforePlayerDestroy(Level level, BlockPos pos, BlockState state, Player player) {
        super.playerWillDestroy(level, pos, state, player);
        return state;
    }

    protected boolean survivesSharedExplosion() {
        return false;
    }

    public int getExpDrop(net.minecraft.world.level.block.state.BlockState native$callbackInput$1050, net.minecraft.world.level.LevelReader native$callbackInput$1051, net.minecraft.util.RandomSource native$callbackInput$1052, net.minecraft.core.BlockPos native$callbackInput$1053, int native$callbackInput$1054, int native$callbackInput$1055) {
        net.minecraft.world.level.block.state.BlockState state = native$callbackInput$1050;
        net.minecraft.util.RandomSource random = native$callbackInput$1052;
        return 0;
    }

    @Override
    public void onBlockExploded(BlockState state, Level level, BlockPos pos, Explosion explosion) {
        if (!(switch(0) {
            default ->
                {
                    boolean native$bodyResult$5309 = false;
                    native$bodyReturn$5310: {
                        if (true) {
                            {
                                native$bodyResult$5309 = false;
                                break native$bodyReturn$5310;
                            }
                        }
                    }
                    yield native$bodyResult$5309;
                }
        }))
            super.onBlockExploded(state, level, pos, explosion);
    }

    @Override
    public boolean canDropFromExplosion(BlockState state, BlockGetter level, BlockPos pos, Explosion explosion) {
        return !(switch(0) {
            default ->
                {
                    boolean native$bodyResult$4682 = false;
                    native$bodyReturn$4683: {
                        if (true) {
                            {
                                native$bodyResult$4682 = false;
                                break native$bodyReturn$4683;
                            }
                        }
                    }
                    yield native$bodyResult$4682;
                }
        }) && super.canDropFromExplosion(state, level, pos, explosion);
    }

    static private <B extends net.minecraft.world.level.block.Block> com.mojang.serialization.MapCodec<B> native$BlockCodecPlatform$simple(java.util.function.Function<net.minecraft.world.level.block.state.BlockBehaviour.Properties, B> factory) {
        // Vanilla 1.21's Properties codec is a unit codec. Retain that schema for shared block definitions.
        return com.mojang.serialization.codecs.RecordCodecBuilder.mapCodec(instance -> instance.group(com.mojang.serialization.Codec.unit(net.minecraft.world.level.block.state.BlockBehaviour.Properties::of).fieldOf("properties").forGetter((B block) -> net.minecraft.world.level.block.state.BlockBehaviour.Properties.copy(block))).apply(instance, factory));
    }
}
