package dev.tc4port.thaumcraft.block;

import com.mojang.serialization.MapCodec;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelReader;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.material.PushReaction;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;
import dev.tc4port.thaumcraft.nativeimpl.ClientExtensionTarget;
import dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.level.pathfinder.PathComputationType;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.level.Explosion;

/**
 * One metadata colour of BlockCandle. These are intentionally always lit:
 * TC4 had no lit state and emitted flame/smoke continuously.
 */
public final class TallowCandleBlock extends net.minecraft.world.level.block.Block implements dev.tc4port.thaumcraft.nativeimpl.ClientExtensionTarget {

    // Forge calls initializeClient from the native superclass constructor. Do not add a field initializer.
    private java.util.function.Consumer<net.minecraftforge.client.extensions.common.IClientBlockExtensions> platform$clientInstaller;

    private static final VoxelShape OUTLINE = Block.box(6.0, 0.0, 6.0, 10.0, 8.0, 10.0);

    private final int colorIndex;

    public TallowCandleBlock(int colorIndex, BlockBehaviour.Properties properties) {
        this(properties, colorIndex, properties, true);
    }

    public int colorIndex() {
        return this.colorIndex;
    }

    @Override
    public VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
        return OUTLINE;
    }

    @Override
    public VoxelShape getCollisionShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
        return Shapes.empty();
    }

    @Override
    public boolean canSurvive(BlockState state, LevelReader level, BlockPos pos) {
        return level.getBlockState(pos.below()).isFaceSturdy(level, pos.below(), Direction.UP);
    }

    @Override
    public BlockState updateShape(BlockState state, Direction direction, BlockState neighborState, net.minecraft.world.level.LevelAccessor level, BlockPos pos, BlockPos neighborPos) {
        return direction == Direction.DOWN && !state.canSurvive(level, pos) ? net.minecraft.world.level.block.Blocks.AIR.defaultBlockState() : super.updateShape(state, direction, neighborState, level, pos, neighborPos);
    }

    @Override
    public void animateTick(BlockState state, Level level, BlockPos pos, RandomSource random) {
        double x = pos.getX() + 0.5;
        double y = pos.getY() + 0.7;
        double z = pos.getZ() + 0.5;
        level.addParticle(ParticleTypes.SMOKE, x, y, z, 0.0, 0.0, 0.0);
        level.addParticle(ParticleTypes.FLAME, x, y, z, 0.0, 0.0, 0.0);
    }

    @Override
    public PushReaction getPistonPushReaction(BlockState state) {
        return PushReaction.DESTROY;
    }

    public static final MapCodec<TallowCandleBlock> CODEC = TallowCandleBlock.native$BlockCodecPlatform$simple(properties -> new TallowCandleBlock(0, properties));

    protected MapCodec<? extends TallowCandleBlock> codec() {
        return CODEC;
    }

    private TallowCandleBlock(net.minecraft.world.level.block.state.BlockBehaviour.Properties native$NativeBlock$arg0, int colorIndex, BlockBehaviour.Properties properties, boolean native$NativeBlock$captured) {
        super(native$NativeBlock$arg0);
        this.colorIndex = colorIndex;
    }

    @Override
    public void initializeClient(java.util.function.Consumer<net.minecraftforge.client.extensions.common.IClientBlockExtensions> installer) {
        platform$clientInstaller = installer;
        super.initializeClient(installer);
    }

    @Override
    public void platform$clientExtension(Object extension) {
        java.util.Objects.requireNonNull(platform$clientInstaller, "Forge initializeClient must run before client extension registration").accept((net.minecraftforge.client.extensions.common.IClientBlockExtensions) extension);
    }

    @Override
    public InteractionResult use(BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
        ItemUseResult result = (switch(0) {
            default ->
                {
                    net.minecraft.world.item.ItemStack native$bodyOperand$4731 = player.getItemInHand(hand);
                    net.minecraft.world.level.block.state.BlockState native$bodyOperand$4732 = state;
                    net.minecraft.world.level.Level native$bodyOperand$4733 = level;
                    net.minecraft.core.BlockPos native$bodyOperand$4734 = pos;
                    net.minecraft.world.entity.player.Player native$bodyOperand$4735 = player;
                    net.minecraft.world.InteractionHand native$bodyOperand$4736 = hand;
                    net.minecraft.world.phys.BlockHitResult native$bodyOperand$4737 = hit;
                    dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult native$bodyResult$4738 = null;
                    native$bodyReturn$4739: {
                        if (true) {
                            {
                                native$bodyResult$4738 = dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
                                break native$bodyReturn$4739;
                            }
                        }
                    }
                    yield native$bodyResult$4738;
                }
        });
        return result == ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION ? (hand == InteractionHand.MAIN_HAND ? (switch(0) {
            default ->
                {
                    net.minecraft.world.level.block.state.BlockState native$bodyOperand$3868 = state;
                    net.minecraft.world.level.Level native$bodyOperand$3869 = level;
                    net.minecraft.core.BlockPos native$bodyOperand$3870 = pos;
                    net.minecraft.world.entity.player.Player native$bodyOperand$3871 = player;
                    net.minecraft.world.phys.BlockHitResult native$bodyOperand$3872 = hit;
                    net.minecraft.world.InteractionResult native$bodyResult$3873 = null;
                    native$bodyReturn$3874: {
                        if (true) {
                            {
                                native$bodyResult$3873 = super.use(native$bodyOperand$3868, native$bodyOperand$3869, native$bodyOperand$3870, native$bodyOperand$3871, net.minecraft.world.InteractionHand.MAIN_HAND, native$bodyOperand$3872);
                                break native$bodyReturn$3874;
                            }
                        }
                    }
                    yield native$bodyResult$3873;
                }
        }) : InteractionResult.PASS) : result.result();
    }

    protected ItemUseResult interactWithItem(ItemStack stack, BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
        return dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
    }

    protected InteractionResult interactWithoutItem(BlockState state, Level level, BlockPos pos, Player player, BlockHitResult hit) {
        return super.use(state, level, pos, player, net.minecraft.world.InteractionHand.MAIN_HAND, hit);
    }

    @Override
    public void playerWillDestroy(Level level, BlockPos pos, BlockState state, Player player) {
        {
            net.minecraft.world.level.Level native$bodyOperand$6010 = level;
            net.minecraft.core.BlockPos native$bodyOperand$6011 = pos;
            net.minecraft.world.level.block.state.BlockState native$bodyOperand$6012 = state;
            net.minecraft.world.entity.player.Player native$bodyOperand$6013 = player;
            net.minecraft.world.level.block.state.BlockState native$bodyResult$6014 = null;
            native$bodyReturn$6015: {
                if (true) {
                    super.playerWillDestroy(native$bodyOperand$6010, native$bodyOperand$6011, native$bodyOperand$6012, native$bodyOperand$6013);
                    {
                        native$bodyResult$6014 = native$bodyOperand$6012;
                        break native$bodyReturn$6015;
                    }
                }
            }
        }
    }

    public BlockState beforePlayerDestroy(Level level, BlockPos pos, BlockState state, Player player) {
        super.playerWillDestroy(level, pos, state, player);
        return state;
    }

    protected boolean survivesSharedExplosion() {
        return false;
    }

    public int getExpDrop(net.minecraft.world.level.block.state.BlockState native$callbackInput$1145, net.minecraft.world.level.LevelReader native$callbackInput$1146, net.minecraft.util.RandomSource native$callbackInput$1147, net.minecraft.core.BlockPos native$callbackInput$1148, int native$callbackInput$1149, int native$callbackInput$1150) {
        net.minecraft.world.level.block.state.BlockState state = native$callbackInput$1145;
        net.minecraft.util.RandomSource random = native$callbackInput$1147;
        return 0;
    }

    @Override
    public void onBlockExploded(BlockState state, Level level, BlockPos pos, Explosion explosion) {
        if (!(switch(0) {
            default ->
                {
                    boolean native$bodyResult$5319 = false;
                    native$bodyReturn$5320: {
                        if (true) {
                            {
                                native$bodyResult$5319 = false;
                                break native$bodyReturn$5320;
                            }
                        }
                    }
                    yield native$bodyResult$5319;
                }
        }))
            super.onBlockExploded(state, level, pos, explosion);
    }

    @Override
    public boolean canDropFromExplosion(BlockState state, BlockGetter level, BlockPos pos, Explosion explosion) {
        return !(switch(0) {
            default ->
                {
                    boolean native$bodyResult$4740 = false;
                    native$bodyReturn$4741: {
                        if (true) {
                            {
                                native$bodyResult$4740 = false;
                                break native$bodyReturn$4741;
                            }
                        }
                    }
                    yield native$bodyResult$4740;
                }
        }) && super.canDropFromExplosion(state, level, pos, explosion);
    }

    static private <B extends net.minecraft.world.level.block.Block> com.mojang.serialization.MapCodec<B> native$BlockCodecPlatform$simple(java.util.function.Function<net.minecraft.world.level.block.state.BlockBehaviour.Properties, B> factory) {
        // Vanilla 1.21's Properties codec is a unit codec. Retain that schema for shared block definitions.
        return com.mojang.serialization.codecs.RecordCodecBuilder.mapCodec(instance -> instance.group(com.mojang.serialization.Codec.unit(net.minecraft.world.level.block.state.BlockBehaviour.Properties::of).fieldOf("properties").forGetter((B block) -> net.minecraft.world.level.block.state.BlockBehaviour.Properties.copy(block))).apply(instance, factory));
    }
}
