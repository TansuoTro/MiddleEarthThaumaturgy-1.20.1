package dev.tc4port.thaumcraft.block;

import dev.tc4port.thaumcraft.registry.TCSounds;
import dev.tc4port.thaumcraft.nativeimpl.EffectTypes;
import dev.tc4port.thaumcraft.common.TCGameplayParameters;
import com.mojang.serialization.MapCodec;
import dev.tc4port.thaumcraft.api.entity.EldritchMob;
import dev.tc4port.thaumcraft.registry.TCParticles;
import net.minecraft.core.BlockPos;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;

/**
 * Server behavior of BlockAiry metadata 10/11.
 */
public final class ArcaneFieldBlock extends TemporaryAirBlock implements dev.tc4port.thaumcraft.nativeimpl.ClientExtensionTarget {

    public enum Kind {

        STATIC, SAPPING
    }

    private static final MapCodec<ArcaneFieldBlock> STATIC_CODEC = ArcaneFieldBlock.native$BlockCodecPlatform$simple(properties -> new ArcaneFieldBlock(Kind.STATIC, properties));

    private static final MapCodec<ArcaneFieldBlock> SAPPING_CODEC = ArcaneFieldBlock.native$BlockCodecPlatform$simple(properties -> new ArcaneFieldBlock(Kind.SAPPING, properties));

    private final Kind kind;

    public ArcaneFieldBlock(Kind kind, BlockBehaviour.Properties properties) {
        super(properties);
        this.kind = kind;
    }

    protected MapCodec<ArcaneFieldBlock> codec() {
        return this.kind == Kind.STATIC ? STATIC_CODEC : SAPPING_CODEC;
    }

    /**
     * BlockAiry metadata 10/11 used render type -1 and a zero-sized selection
     * box.  Missing blockstate JSON is not a substitute for that contract:
     * the modern fallback model is the black cube seen behind the warden.
     */
    @Override
    public RenderShape getRenderShape(BlockState state) {
        return RenderShape.INVISIBLE;
    }

    @Override
    public VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
        return Shapes.empty();
    }

    @Override
    public void entityInside(BlockState state, Level level, BlockPos pos, Entity entity) {
        if (this.kind == Kind.STATIC) {
            entity.hurt(dev.tc4port.thaumcraft.common.FocusFieldDamage.source(level, pos), TCGameplayParameters.EFFECTS_ARCANE_FIELDS_SHOCK_BASE_DAMAGE.floatValue() + level.random.nextInt(TCGameplayParameters.EFFECTS_ARCANE_FIELDS_SHOCK_DAMAGE_CHOICES.intValue()));
            entity.setDeltaMovement(entity.getDeltaMovement().multiply(TCGameplayParameters.EFFECTS_ARCANE_FIELDS_SHOCK_HORIZONTAL_DAMPING.floatValue(), 1.0, TCGameplayParameters.EFFECTS_ARCANE_FIELDS_SHOCK_HORIZONTAL_DAMPING.floatValue()));
            if (!level.isClientSide && level.random.nextInt(TCGameplayParameters.EFFECTS_ARCANE_FIELDS_SHOCK_REMOVAL_DENOMINATOR.intValue()) == 0) {
                level.removeBlock(pos, false);
            }
            return;
        }
        if (entity instanceof EldritchMob) {
            return;
        }
        if (level.random.nextInt(TCGameplayParameters.EFFECTS_ARCANE_FIELDS_DRAIN_DAMAGE_DENOMINATOR.intValue()) == 0) {
            entity.hurt(level.damageSources().wither(), TCGameplayParameters.EFFECTS_ARCANE_FIELDS_DRAIN_DAMAGE.floatValue());
        }
        entity.setDeltaMovement(entity.getDeltaMovement().multiply(TCGameplayParameters.EFFECTS_ARCANE_FIELDS_DRAIN_HORIZONTAL_DAMPING.floatValue(), 1.0, TCGameplayParameters.EFFECTS_ARCANE_FIELDS_DRAIN_HORIZONTAL_DAMPING.floatValue()));
        if (entity instanceof Player player) {
            player.causeFoodExhaustion(TCGameplayParameters.EFFECTS_ARCANE_FIELDS_DRAIN_EXHAUSTION.floatValue());
        }
        if (entity instanceof LivingEntity living) {
            living.addEffect((switch(0) {
                default ->
                    {
                        net.minecraft.core.Holder<net.minecraft.world.effect.MobEffect> native$operand$13275 = EffectTypes.WEAKNESS;
                        int native$operand$13276 = 100;
                        int native$operand$13277 = 1;
                        boolean native$operand$13278 = true;
                        boolean native$operand$13279 = true;
                        net.minecraft.world.effect.MobEffectInstance native$result$13280 = (new net.minecraft.world.effect.MobEffectInstance(native$operand$13275.value(), native$operand$13276, ArcaneFieldBlock.native$MobEffectPlatform$safeAmplifier(native$operand$13275, native$operand$13277), native$operand$13278, native$operand$13279));
                        yield native$result$13280;
                    }
            }));
        }
    }

    @Override
    public void animateTick(BlockState state, Level level, BlockPos pos, RandomSource random) {
        float height = random.nextFloat() * 0.33F;
        var particle = switch(random.nextInt(3)) {
            case 1 ->
                TCParticles.SHOCK_SPARK_1.get();
            case 2 ->
                TCParticles.SHOCK_SPARK_2.get();
            default ->
                TCParticles.SHOCK_SPARK_0.get();
        };
        double red = this.kind == Kind.STATIC ? 0.65F + random.nextFloat() * 0.1F : 0.3F - random.nextFloat() * 0.1F;
        double blue = this.kind == Kind.SAPPING ? 0.5F + random.nextFloat() * 0.2F : 0.0F;
        level.addParticle(particle, pos.getX() + random.nextFloat(), pos.getY() + 0.1515F + height / 2.0F, pos.getZ() + random.nextFloat(), red, 0.33F + height, blue);
        if (random.nextInt(50) == 0) {
            level.playLocalSound(pos, TCSounds.JACOBS.get(), SoundSource.BLOCKS, 0.5F, 1.0F + (random.nextFloat() - random.nextFloat()) * 0.2F, false);
        }
    }

    /**
     * Native shift-based effects need a smaller ceiling than the stored amplifier byte.
     */
    static private int native$MobEffectPlatform$safeAmplifier(net.minecraft.core.Holder<net.minecraft.world.effect.MobEffect> effect, int amplifier) {
        net.minecraft.world.effect.MobEffect type = effect.value();
        int maximum = type == net.minecraft.world.effect.MobEffects.HEAL || type == net.minecraft.world.effect.MobEffects.HARM ? 16 : type == net.minecraft.world.effect.MobEffects.REGENERATION || type == net.minecraft.world.effect.MobEffects.POISON || type == net.minecraft.world.effect.MobEffects.WITHER ? 31 : 127;
        return java.lang.Math.max(0, java.lang.Math.min(maximum, amplifier));
    }

    static private <B extends net.minecraft.world.level.block.Block> com.mojang.serialization.MapCodec<B> native$BlockCodecPlatform$simple(java.util.function.Function<net.minecraft.world.level.block.state.BlockBehaviour.Properties, B> factory) {
        // Vanilla 1.21's Properties codec is a unit codec. Retain that schema for shared block definitions.
        return com.mojang.serialization.codecs.RecordCodecBuilder.mapCodec(instance -> instance.group(com.mojang.serialization.Codec.unit(net.minecraft.world.level.block.state.BlockBehaviour.Properties::of).fieldOf("properties").forGetter((B block) -> net.minecraft.world.level.block.state.BlockBehaviour.Properties.copy(block))).apply(instance, factory));
    }
}
