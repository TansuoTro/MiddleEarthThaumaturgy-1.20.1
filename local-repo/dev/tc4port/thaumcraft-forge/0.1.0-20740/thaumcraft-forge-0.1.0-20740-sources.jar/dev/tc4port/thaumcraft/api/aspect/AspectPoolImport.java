package dev.tc4port.thaumcraft.api.aspect;

import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.Objects;
import java.util.Set;

/**
 * One atomic discovery-and-pool import request.
 */
public record AspectPoolImport(Set<AspectId> discoveries, AspectAmounts additions) {

    public static final int MAX_ASPECTS = 256;

    public AspectPoolImport {
        Objects.requireNonNull(discoveries, "discoveries");
        LinkedHashSet<AspectId> checked = new LinkedHashSet<>();
        discoveries.forEach(aspect -> checked.add(Objects.requireNonNull(aspect, "discovery aspect")));
        discoveries = Collections.unmodifiableSet(checked);
        additions = Objects.requireNonNull(additions, "additions");
        LinkedHashSet<AspectId> affected = new LinkedHashSet<>(discoveries);
        affected.addAll(additions.amounts().keySet());
        if (affected.size() > MAX_ASPECTS) {
            throw new IllegalArgumentException("Aspect import exceeds " + MAX_ASPECTS + " identities");
        }
    }
}
