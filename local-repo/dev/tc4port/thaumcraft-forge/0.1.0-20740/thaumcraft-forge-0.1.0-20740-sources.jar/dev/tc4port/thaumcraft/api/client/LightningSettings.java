package dev.tc4port.thaumcraft.api.client;

import java.util.Objects;

/**
 * TC's fractal two-pass bolt. Duration 0 selects a random 2–4 ticks; positive
 * duration selects duration + random(duration) - duration/2. Growth precedes fade.
 * Width is in blocks; increment controls growth per client tick, not lifetime.
 */
public record LightningSettings(int duration, double multiplier, int increment, double width, EffectColor outer, EffectColor inner, boolean additive) {

    public static final LightningSettings NODE = new LightningSettings(10, 4, 5, 0.03, new EffectColor(0.6F, 0.3F, 0.6F), new EffectColor(1, 0.6F, 1), true);

    public static final LightningSettings FOCUS = new LightningSettings(6, 0.5, 8, 0.125, new EffectColor(0.1F, 0.1F, 0.6F), new EffectColor(0.1F, 0.1F, 1), true);

    public LightningSettings {
        Objects.requireNonNull(outer, "outer");
        Objects.requireNonNull(inner, "inner");
        if (duration < 0 || duration > 1200 || !Double.isFinite(multiplier) || multiplier < 0 || multiplier > 64 || increment < 1 || increment > 256 || !Double.isFinite(width) || width <= 0 || width > 64) {
            throw new IllegalArgumentException("Invalid lightning settings");
        }
    }
}
