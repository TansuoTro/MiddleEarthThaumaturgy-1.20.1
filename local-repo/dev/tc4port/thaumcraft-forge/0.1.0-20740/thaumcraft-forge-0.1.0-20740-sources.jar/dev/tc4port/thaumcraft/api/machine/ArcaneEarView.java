package dev.tc4port.thaumcraft.api.machine;

public interface ArcaneEarView {

    int note();
}
