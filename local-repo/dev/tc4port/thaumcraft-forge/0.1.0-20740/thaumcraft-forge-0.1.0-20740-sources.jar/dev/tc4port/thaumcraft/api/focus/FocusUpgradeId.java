package dev.tc4port.thaumcraft.api.focus;

import com.mojang.serialization.Codec;
import com.mojang.serialization.DataResult;
import java.util.Objects;
import net.minecraft.resources.ResourceLocation;

/**
 * Stable namespaced identity of one focus-upgrade definition.
 */
public record FocusUpgradeId(ResourceLocation value) {

    public static final int MAX_LENGTH = 256;

    public static final Codec<FocusUpgradeId> CODEC = Codec.STRING.comapFlatMap(value -> {
        try {
            return DataResult.success(parse(value));
        } catch (IllegalArgumentException exception) {
            return DataResult.error(exception::getMessage);
        }
    }, FocusUpgradeId::serialized);

    public FocusUpgradeId {
        Objects.requireNonNull(value, "value");
        if (value.getPath().isEmpty() || value.toString().length() > MAX_LENGTH) {
            throw new IllegalArgumentException("Focus upgrade ID must have a non-empty path and at most " + MAX_LENGTH + " characters");
        }
    }

    public static FocusUpgradeId of(ResourceLocation value) {
        return new FocusUpgradeId(value);
    }

    public static FocusUpgradeId parse(String value) {
        if (value == null || value.isBlank()) {
            throw new IllegalArgumentException("Focus upgrade ID must not be blank");
        }
        ResourceLocation parsed = value.indexOf(':') >= 0 ? ResourceLocation.tryParse(value) : ResourceLocation.tryBuild("thaumcraft", value);
        if (parsed == null) {
            throw new IllegalArgumentException("Invalid focus upgrade ID " + value);
        }
        return new FocusUpgradeId(parsed);
    }

    /**
     * Canonical persisted form; core IDs retain their TC4 bare spelling.
     */
    public String serialized() {
        return this.value.getNamespace().equals("thaumcraft") ? this.value.getPath() : this.value.toString();
    }

    @Override
    public String toString() {
        return this.value.toString();
    }
}
