package dev.tc4port.thaumcraft.api.wand;

import com.mojang.serialization.Codec;
import com.mojang.serialization.DataResult;
import dev.tc4port.thaumcraft.api.aspect.AspectId;
import dev.tc4port.thaumcraft.api.aspect.VisChannel;
import java.util.Objects;
import java.util.Optional;

/**
 * Selects which aspect, if any, passively recharges a wand rod.
 */
public record WandRechargeSpec(Mode mode, Optional<VisChannel> aspect) {

    public static final Codec<WandRechargeSpec> CODEC = Codec.STRING.comapFlatMap(WandRechargeSpec::decode, recharge -> switch(recharge.mode()) {
        case NONE ->
            "none";
        case ANY ->
            "*";
        case ASPECT ->
            recharge.aspect().orElseThrow().aspectId().serialized();
    });

    public enum Mode {

        NONE, ANY, ASPECT
    }

    public WandRechargeSpec {
        mode = Objects.requireNonNull(mode, "mode");
        aspect = Objects.requireNonNull(aspect, "aspect");
        if ((mode == Mode.ASPECT) != aspect.isPresent()) {
            throw new IllegalArgumentException("Only ASPECT recharge accepts an aspect id");
        }
    }

    public static WandRechargeSpec none() {
        return new WandRechargeSpec(Mode.NONE, Optional.empty());
    }

    public static WandRechargeSpec any() {
        return new WandRechargeSpec(Mode.ANY, Optional.empty());
    }

    public static WandRechargeSpec aspect(VisChannel aspect) {
        return new WandRechargeSpec(Mode.ASPECT, Optional.of(Objects.requireNonNull(aspect, "aspect")));
    }

    private static DataResult<WandRechargeSpec> decode(String value) {
        try {
            return DataResult.success(switch(value) {
                case "none" ->
                    none();
                case "*" ->
                    any();
                default ->
                    aspect(VisChannel.fromAspectId(AspectId.parse(value)).orElseThrow(() -> new IllegalArgumentException("Unknown wand recharge channel: " + value)));
            });
        } catch (RuntimeException exception) {
            return DataResult.error(() -> "Invalid wand recharge channel '" + value + "': " + exception.getMessage());
        }
    }
}
