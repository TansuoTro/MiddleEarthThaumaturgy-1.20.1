package dev.tc4port.thaumcraft.api.aspect;

import dev.tc4port.thaumcraft.aspect.AspectCatalog;
import com.mojang.serialization.Codec;
import com.mojang.serialization.DataResult;
import dev.tc4port.thaumcraft.api.aspect.AspectId;
import dev.tc4port.thaumcraft.util.IntBounds;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

/**
 * Modern, typed equivalent of TC4's mutable {@code AspectList}.
 *
 * <p>The collection deliberately keeps insertion order. TC4 exposed that
 * order to recipes, node generation and GUIs through a {@code LinkedHashMap}.
 * {@link #add} sums values while {@link #merge} retains the larger value;
 * those two deceptively similar operations are not interchangeable.</p>
 */
public final class AspectList {

    private static final Codec<Map<String, Integer>> SERIALIZED_CODEC = Codec.unboundedMap(Codec.STRING, Codec.INT);

    public static final Codec<AspectList> CODEC = SERIALIZED_CODEC.comapFlatMap(AspectList::decode, AspectList::serialized);

    private final LinkedHashMap<AspectId, Integer> aspects = new LinkedHashMap<>();

    public AspectList() {
    }

    public AspectList(Map<AspectId, Integer> values) {
        Objects.requireNonNull(values, "values").forEach((id, amount) -> {
            Objects.requireNonNull(id, "aspect id");
            Objects.requireNonNull(amount, "aspect amount");
            if (amount < 0) {
                throw new IllegalArgumentException("Aspect amounts must be non-negative: " + id);
            }
            this.aspects.merge(id, amount, this::saturatingAdd);
        });
    }

    public AspectList copy() {
        return new AspectList(this.aspects);
    }

    public int size() {
        return this.aspects.size();
    }

    public int visSize() {
        long total = this.aspects.values().stream().mapToLong(Integer::longValue).sum();
        return IntBounds.clamp(total, Integer.MIN_VALUE, Integer.MAX_VALUE);
    }

    public boolean contains(AspectId aspect) {
        return this.aspects.containsKey(Objects.requireNonNull(aspect));
    }

    public int amount(AspectId aspect) {
        return this.aspects.getOrDefault(Objects.requireNonNull(aspect), 0);
    }

    public List<AspectId> aspects() {
        return List.copyOf(this.aspects.keySet());
    }

    public List<AspectId> primalAspects() {
        return this.aspects.keySet().stream().filter(aspect -> {
            var definition = AspectCatalog.get(aspect);
            return definition != null && definition.primal();
        }).toList();
    }

    public List<AspectId> aspectsSorted() {
        return this.aspects.keySet().stream().sorted(Comparator.comparing(AspectId::serialized)).toList();
    }

    public List<AspectId> aspectsSortedByAmount() {
        List<AspectId> result = new ArrayList<>(this.aspects.keySet());
        /*
         * Do not replace this with a descending comparator. TC4 swapped a
         * pair only when both values were positive, so a zero left behind by
         * reduce() is an ordering barrier. Equal positive values are stable.
         */
        boolean changed;
        do {
            changed = false;
            for (int index = 0; index < result.size() - 1; index++) {
                AspectId first = result.get(index);
                AspectId second = result.get(index + 1);
                int firstAmount = this.amount(first);
                int secondAmount = this.amount(second);
                if (firstAmount > 0 && secondAmount > 0 && secondAmount > firstAmount) {
                    result.set(index, second);
                    result.set(index + 1, first);
                    changed = true;
                    break;
                }
            }
        } while (changed);
        return List.copyOf(result);
    }

    /**
     * Preserves the legacy quirk that a successful reduction to zero leaves a
     * discovered zero-value entry in the list.
     */
    public boolean reduce(AspectId aspect, int amount) {
        Objects.requireNonNull(aspect, "aspect");
        if (this.amount(aspect) < amount) {
            return false;
        }
        this.aspects.put(aspect, this.amount(aspect) - amount);
        return true;
    }

    public AspectList remove(AspectId aspect, int amount) {
        Objects.requireNonNull(aspect, "aspect");
        int remaining = this.amount(aspect) - amount;
        if (remaining <= 0) {
            this.aspects.remove(aspect);
        } else {
            this.aspects.put(aspect, remaining);
        }
        return this;
    }

    public AspectList remove(AspectId aspect) {
        this.aspects.remove(Objects.requireNonNull(aspect, "aspect"));
        return this;
    }

    public AspectList add(AspectId aspect, int amount) {
        Objects.requireNonNull(aspect, "aspect");
        this.aspects.put(aspect, saturatingAdd(this.amount(aspect), amount));
        return this;
    }

    public AspectList merge(AspectId aspect, int amount) {
        Objects.requireNonNull(aspect, "aspect");
        this.aspects.put(aspect, Math.max(this.amount(aspect), amount));
        return this;
    }

    public AspectList add(AspectList other) {
        other.aspects.forEach(this::add);
        return this;
    }

    public AspectList merge(AspectList other) {
        other.aspects.forEach(this::merge);
        return this;
    }

    public Map<AspectId, Integer> asMap() {
        return Collections.unmodifiableMap(new LinkedHashMap<>(this.aspects));
    }

    private int saturatingAdd(int first, int second) {
        long total = (long) first + second;
        return IntBounds.clamp(total, Integer.MIN_VALUE, Integer.MAX_VALUE);
    }

    private static DataResult<AspectList> decode(Map<String, Integer> serialized) {
        try {
            LinkedHashMap<AspectId, Integer> typed = new LinkedHashMap<>();
            serialized.forEach((id, amount) -> {
                if (amount == null || amount < 0) {
                    throw new IllegalArgumentException("Invalid aspect amount for " + id + ": " + amount);
                }
                typed.merge(AspectId.parse(id), amount, Math::addExact);
            });
            return DataResult.success(new AspectList(typed));
        } catch (RuntimeException exception) {
            return DataResult.error(() -> "Invalid aspect list: " + exception.getMessage());
        }
    }

    private Map<String, Integer> serialized() {
        LinkedHashMap<String, Integer> result = new LinkedHashMap<>();
        this.aspects.forEach((id, amount) -> result.put(id.serialized(), amount));
        return Collections.unmodifiableMap(result);
    }
}
