package dev.tc4port.thaumcraft.api.machine;

import dev.tc4port.thaumcraft.api.aspect.AspectAmounts;
import java.util.Objects;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.ItemStack;

/**
 * The crucible recipe the core would select for one catalyst item.
 *
 * @param id recipe id
 * @param result copy of the recipe output
 * @param aspects aspects the recipe consumes from the crucible
 */
public record CrucibleRecipeMatch(ResourceLocation id, ItemStack result, AspectAmounts aspects) {

    public CrucibleRecipeMatch {
        Objects.requireNonNull(id, "id");
        result = Objects.requireNonNull(result, "result").copy();
        Objects.requireNonNull(aspects, "aspects");
    }

    @Override
    public ItemStack result() {
        return this.result.copy();
    }
}
