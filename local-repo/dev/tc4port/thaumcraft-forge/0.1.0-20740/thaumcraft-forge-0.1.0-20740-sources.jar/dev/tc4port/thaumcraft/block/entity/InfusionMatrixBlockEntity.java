package dev.tc4port.thaumcraft.block.entity;

import net.minecraft.sounds.SoundSource;
import dev.tc4port.thaumcraft.registry.TCSounds;
import dev.tc4port.thaumcraft.api.event.GameplayHooks;
import dev.tc4port.thaumcraft.common.TCGameplayParameters;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.mojang.serialization.JsonOps;
import dev.tc4port.thaumcraft.api.aspect.AspectDefinition;
import dev.tc4port.thaumcraft.aspect.AspectCatalog;
import dev.tc4port.thaumcraft.api.aspect.AspectId;
import dev.tc4port.thaumcraft.api.aspect.AspectAmounts;
import dev.tc4port.thaumcraft.api.aspect.AspectContainerView;
import dev.tc4port.thaumcraft.api.flux.FluxApi;
import dev.tc4port.thaumcraft.api.essentia.EssentiaApi;
import dev.tc4port.thaumcraft.api.event.InfusionComponentConsumedEvent;
import dev.tc4port.thaumcraft.api.event.InfusionEndEvent;
import dev.tc4port.thaumcraft.api.event.InfusionStartEvent;
import dev.tc4port.thaumcraft.api.essentia.EssentiaSearch;
import dev.tc4port.thaumcraft.api.essentia.EssentiaTransferMode;
import dev.tc4port.thaumcraft.api.research.ResearchRequirement;
import dev.tc4port.thaumcraft.api.research.ResearchApi;
import dev.tc4port.thaumcraft.common.RecipeLookup;
import dev.tc4port.thaumcraft.network.InfusionSourcePayload;
import dev.tc4port.thaumcraft.network.NodeBoltPayload;
import dev.tc4port.thaumcraft.recipe.InfusionEnchantmentRecipe;
import dev.tc4port.thaumcraft.recipe.InfusionRecipe;
import dev.tc4port.thaumcraft.api.recipe.InfusionRecipeInput;
import dev.tc4port.thaumcraft.recipe.InfusionRecipeOrdering;
import dev.tc4port.thaumcraft.registry.TCBlockEntities;
import dev.tc4port.thaumcraft.registry.TCFluids;
import dev.tc4port.thaumcraft.registry.TCRecipes;
import dev.tc4port.thaumcraft.registry.TCTags;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.HexFormat;
import java.util.Map;
import java.util.Objects;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import javax.annotation.Nullable;
import net.minecraft.core.BlockPos;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.resources.RegistryOps;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.AbstractSkullBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import java.lang.Math;
import java.lang.Integer;
import dev.tc4port.thaumcraft.nativeimpl.state.ItemFields;
import net.minecraft.world.level.block.entity.BlockEntityType;

/**
 * Server-authoritative reconstruction of TileInfusionMatrix.
 */
public final class InfusionMatrixBlockEntity extends net.minecraft.world.level.block.entity.BlockEntity implements AspectContainerView, ItemFields.Source {

    private static final int ESSENTIA_RANGE = 12;

    private static final int DEFAULT_WORK_DELAY = 10;

    /**
     * Persisted marker selecting the experience drain interval.
     */
    private static final int EXPERIENCE_WORK_DELAY = 20;

    private static final int PEDESTAL_SCAN_RADIUS = 8;

    private static final int PEDESTAL_AXIS_SIZE = PEDESTAL_SCAN_RADIUS * 2 + 1;

    private static final double EJECTION_SPAWN_Y_OFFSET = 1.05;

    private final List<BlockPos> pedestals = new ArrayList<>();

    private int[] pedestalXScanRanks = naturalPedestalAxisRanks();

    private int[] pedestalZScanRanks = naturalPedestalAxisRanks();

    private final LinkedHashMap<AspectId, Integer> recipeEssentia = new LinkedHashMap<>();

    private final List<Integer> remainingIngredients = new ArrayList<>();

    private boolean active;

    private boolean crafting;

    private boolean enchantmentRecipe;

    private boolean checkSurroundings = true;

    private int symmetry;

    private int instability;

    private int recipeInstability;

    private int count;

    private int craftCount;

    private int countDelay = DEFAULT_WORK_DELAY;

    private int itemCount;

    private int recipeXp;

    private float startUp;

    @Nullable
    private ResourceLocation recipeId;

    @Nullable
    private String recipeFingerprint;

    // Keep detecting mutable/custom ingredients on every definition check.
    // Only canonicalization and hashing may be reused when the encoded tree
    // is unchanged; recipe identity alone is not a mutation/reload contract.
    @Nullable
    private JsonElement cachedRecipeDefinition;

    @Nullable
    private String cachedDefinitionFingerprint;

    private ItemStack recipeInput = ItemStack.EMPTY;

    @Nullable
    private String recipePlayer;

    @Nullable
    private BlockPos activePedestal;

    @Nullable
    private BlockPos ingredientPedestal;

    private int ingredientIndex = -1;

    private ItemStack ingredientStack = ItemStack.EMPTY;

    private long ingredientRevision = -1L;

    private int ingredientTransaction;

    private int nextIngredientTransaction;

    /**
     * Per-craft speed chosen at start; zero (older saves) uses the machine parameter.
     */
    private int craftEssentiaPerPulse;

    private int craftAbsorptionPulses;

    /**
     * The start listeners' symmetry change for this craft, shown on top of the live scan.
     */
    private int craftSymmetryAdjustment;

    /**
     * Components of the last scanned symmetry, derived like the symmetry itself.
     */
    private int scannedPedestalSymmetry;

    private float scannedStabilizerSymmetry;

    public InfusionMatrixBlockEntity(BlockPos pos, BlockState state) {
        super(TCBlockEntities.INFUSION_MATRIX.get(), pos, state);
    }

    public static void serverTick(Level level, BlockPos pos, BlockState state, InfusionMatrixBlockEntity matrix) {
        if (matrix.crafting) {
            if (matrix.craftCount == 0) {
                level.playSound(null, pos, TCSounds.INFUSER_START.get(), SoundSource.BLOCKS, 0.5F, 1.0F);
            } else if (matrix.craftCount % 65 == 0) {
                level.playSound(null, pos, TCSounds.INFUSER.get(), SoundSource.BLOCKS, 0.5F, 1.0F);
            }
            matrix.craftCount++;
        } else if (matrix.craftCount > 0) {
            matrix.craftCount = Math.max(0, Math.min(50, matrix.craftCount - 2));
        }
        if (!matrix.surroundingsLoaded()) {
            // Missing chunks are unknown, not a broken altar or empty pedestals.
            matrix.checkSurroundings = true;
            return;
        }
        matrix.count++;
        matrix.refreshSurroundings();
        if (matrix.count % (matrix.crafting ? 20 : 100) == 0 && matrix.structurePositionsLoaded() && !matrix.validLocation()) {
            matrix.active = false;
            matrix.changedAndSync();
            return;
        }
        if (matrix.active && matrix.crafting && matrix.count % matrix.workInterval() == 0) {
            matrix.craftCycle();
            matrix.setChanged();
        }
    }

    public static void clientTick(Level level, BlockPos pos, BlockState state, InfusionMatrixBlockEntity matrix) {
        if (matrix.crafting) {
            matrix.craftCount++;
            if (level instanceof net.minecraft.client.multiplayer.ClientLevel clientLevel) {
                dev.tc4port.thaumcraft.client.EssentiaSourceEffect.queueRune(matrix, clientLevel, 0.5F + level.random.nextFloat() * 0.2F, 0.1F, 0.7F + level.random.nextFloat() * 0.3F);
            }
        } else if (matrix.craftCount > 0) {
            matrix.craftCount = Math.max(0, Math.min(50, matrix.craftCount - 2));
        }
        if (matrix.active && matrix.startUp < 1.0F) {
            matrix.startUp += Math.max(matrix.startUp / 10.0F, 0.001F);
            if (matrix.startUp > 0.999F) {
                matrix.startUp = 1.0F;
            }
        } else if (!matrix.active && matrix.startUp > 0.0F) {
            matrix.startUp -= matrix.startUp / 10.0F;
            if (matrix.startUp < 0.001F) {
                matrix.startUp = 0.0F;
            }
        }
        dev.tc4port.thaumcraft.client.EssentiaSourceEffect.tick(matrix);
    }

    public boolean active() {
        return this.active;
    }

    private int workInterval() {
        return this.countDelay == EXPERIENCE_WORK_DELAY ? TCGameplayParameters.MACHINES_INFUSION_EXPERIENCE_DRAIN_INTERVAL.intValue() : TCGameplayParameters.MACHINES_INFUSION_WORK_INTERVAL.intValue();
    }

    private int absorptionPulses() {
        return this.craftAbsorptionPulses > 0 ? this.craftAbsorptionPulses : TCGameplayParameters.MACHINES_INFUSION_COMPONENT_ABSORPTION_PULSES.intValue();
    }

    private int essentiaPerPulse() {
        return this.craftEssentiaPerPulse > 0 ? this.craftEssentiaPerPulse : TCGameplayParameters.MACHINES_INFUSION_ESSENTIA_PER_PULSE.intValue();
    }

    /**
     * Raises instability by one, capped as TC4's penalty paths were.
     */
    private void raisePenaltyInstability() {
        this.instability = Math.min(TCGameplayParameters.MACHINES_INFUSION_PENALTY_INSTABILITY_CAP.intValue(), this.instability + 1);
    }

    private int missingInputPenaltyBound() {
        return this.penaltyBound(TCGameplayParameters.MACHINES_INFUSION_MISSING_INPUT_PENALTY_BOUND.intValue(), TCGameplayParameters.MACHINES_INFUSION_MISSING_INPUT_PENALTY_SCALING.intValue());
    }

    public boolean crafting() {
        return this.crafting;
    }

    public int symmetry() {
        return this.symmetry;
    }

    /**
     * The scanned symmetry plus this craft's start-listener adjustment.
     */
    public int symmetryForDisplay() {
        return this.crafting ? (int) Math.max(Integer.MIN_VALUE, Math.min(Integer.MAX_VALUE, (long) this.symmetry + this.craftSymmetryAdjustment)) : this.symmetry;
    }

    public int instability() {
        return this.instability;
    }

    public int itemCount() {
        return this.itemCount;
    }

    public int remainingIngredientCount() {
        return this.remainingIngredients.size();
    }

    public int remainingRecipeXp() {
        return this.recipeXp;
    }

    public Map<AspectId, Integer> remainingEssentia() {
        return Collections.unmodifiableMap(new LinkedHashMap<>(this.recipeEssentia));
    }

    @Override
    public AspectAmounts visibleAspects() {
        return new AspectAmounts(this.recipeEssentia);
    }

    /**
     * Captures one fingerprint-validated display view of the active craft.
     * A replacement definition is never presented as the transaction that
     * was started under the previous definition.
     */
    public CraftDisplay craftDisplay() {
        if (!this.crafting || this.level == null) {
            return new CraftDisplay(ItemStack.EMPTY, this.remainingIngredients.size());
        }
        if (this.enchantmentRecipe) {
            InfusionEnchantmentRecipe holder = this.enchantmentRecipe();
            if (holder == null || this.recipeFingerprint == null || !this.recipeFingerprint.equals(this.recipeFingerprint(java.util.Objects.requireNonNull(holder)))) {
                return new CraftDisplay(ItemStack.EMPTY, this.remainingIngredients.size());
            }
            return new CraftDisplay(java.util.Objects.requireNonNull(holder).enchantCentral(this.recipeInput), java.util.Objects.requireNonNull(holder).pedestalComponents().size());
        }
        InfusionRecipe holder = this.recipe();
        if (holder == null || !java.util.Objects.requireNonNull(holder).supportsCentralInput(this.recipeInput) || this.recipeFingerprint == null || !this.recipeFingerprint.equals(this.recipeFingerprint(java.util.Objects.requireNonNull(holder)))) {
            return new CraftDisplay(ItemStack.EMPTY, this.remainingIngredients.size());
        }
        return new CraftDisplay(java.util.Objects.requireNonNull(holder).assembleFromCentral(this.recipeInput, this.level.registryAccess()), java.util.Objects.requireNonNull(holder).pedestalComponents(this.recipeInput).size());
    }

    public ItemStack absorbingIngredientForDisplay() {
        return this.ingredientStack.copy();
    }

    /**
     * Internal immutable view consumed by the Jade compatibility bridge.
     */
    public record CraftDisplay(ItemStack output, int totalIngredientCount) {

        public CraftDisplay {
            output = output.copy();
        }

        @Override
        public ItemStack output() {
            return this.output.copy();
        }
    }

    /**
     * The start packet is pulse one; itemCount then counts down over the
     * configured absorption pulses (five by default) before consumption.
     */
    public int ingredientPulseForDisplay() {
        return this.ingredientPedestal == null ? 0 : dev.tc4port.thaumcraft.util.PortMath.clamp(this.absorptionPulses() + 1 - this.itemCount, 1, this.absorptionPulses());
    }

    /**
     * The start pulse plus the configured absorption pulses.
     */
    public int ingredientPulseTotalForDisplay() {
        return this.absorptionPulses() + 1;
    }

    public boolean enchantmentRecipeForDisplay() {
        return this.enchantmentRecipe;
    }

    public float startUp() {
        return this.startUp;
    }

    public int craftCount() {
        return this.craftCount;
    }

    @Nullable
    public BlockPos activePedestal() {
        return this.activePedestal;
    }

    public void setActive(boolean value) {
        this.active = value;
        if (value) {
            this.checkSurroundings = true;
        }
        this.changedAndSync();
    }

    /**
     * The altar verdict is only taken while every structure position is
     * loaded. Deactivation is latched until a wand reactivates the matrix, so
     * an absent block entity in an unloaded neighbouring chunk must not be
     * read as a broken altar.
     */
    private boolean structurePositionsLoaded() {
        if (!this.level.hasChunkAt(this.worldPosition.below(2))) {
            return false;
        }
        for (int x : new int[] { -1, 1 }) {
            for (int z : new int[] { -1, 1 }) {
                if (!this.level.hasChunkAt(this.worldPosition.offset(x, -2, z))) {
                    return false;
                }
            }
        }
        return true;
    }

    public boolean validLocation() {
        if (this.level == null || !this.structurePositionsLoaded())
            return false;
        if (!(this.level.getBlockEntity(this.worldPosition.below(2)) instanceof ArcanePedestalBlockEntity)) {
            return false;
        }
        for (int x : new int[] { -1, 1 }) {
            for (int z : new int[] { -1, 1 }) {
                BlockEntity entity = this.level.getBlockEntity(this.worldPosition.offset(x, -2, z));
                if (!(entity instanceof InfusionPillarBlockEntity)) {
                    return false;
                }
            }
        }
        return true;
    }

    public boolean startCrafting(Player player) {
        if (!this.surroundingsLoaded()) {
            this.checkSurroundings = true;
            return false;
        }
        if (!(this.level instanceof ServerLevel server) || !this.validLocation()) {
            this.setActive(false);
            return false;
        }
        this.scanSurroundings();
        ArcanePedestalBlockEntity central = this.centralPedestal();
        if (central == null || central.item().isEmpty()) {
            return false;
        }
        List<ItemStack> components = this.pedestals().stream().map(server::getBlockEntity).filter(ArcanePedestalBlockEntity.class::isInstance).map(ArcanePedestalBlockEntity.class::cast).map(ArcanePedestalBlockEntity::item).filter(stack -> !stack.isEmpty()).map(ItemStack::copy).toList();
        if (components.isEmpty()) {
            return false;
        }
        InfusionRecipeInput input = new InfusionRecipeInput(central.item(), components);
        InfusionRecipe selected = InfusionRecipeOrdering.forSelection(RecipeLookup.all(server.getRecipeManager(), TCRecipes.INFUSION.get())).stream().filter(holder -> {
            ResearchRequirement research = java.util.Objects.requireNonNull(holder).research();
            return knowsResearch(player, research) && java.util.Objects.requireNonNull(holder).matches(input, server);
        }).findFirst().orElse(null);
        boolean enchantment;
        ResourceLocation selectedId;
        String fingerprint;
        int quotedInstability;
        Map<AspectId, Integer> quotedEssentia;
        int ingredientCount;
        int quotedXp;
        if (selected != null) {
            fingerprint = this.recipeFingerprint(java.util.Objects.requireNonNull(selected), central.item());
            if (fingerprint == null) {
                return false;
            }
            enchantment = false;
            selectedId = selected.getId();
            quotedInstability = java.util.Objects.requireNonNull(selected).instability(central.item());
            quotedEssentia = java.util.Objects.requireNonNull(selected).aspects(central.item());
            ingredientCount = java.util.Objects.requireNonNull(selected).pedestalComponents(central.item()).size();
            quotedXp = 0;
        } else {
            InfusionEnchantmentRecipe selectedEnchantment = RecipeLookup.all(server.getRecipeManager(), TCRecipes.INFUSION_ENCHANTMENT.get()).stream().filter(holder -> {
                ResearchRequirement research = java.util.Objects.requireNonNull(holder).research();
                return knowsResearch(player, research) && java.util.Objects.requireNonNull(holder).matches(input, server);
            }).findFirst().orElse(null);
            if (selectedEnchantment == null) {
                return false;
            }
            fingerprint = this.recipeFingerprint(java.util.Objects.requireNonNull(selectedEnchantment));
            if (fingerprint == null) {
                return false;
            }
            enchantment = true;
            selectedId = selectedEnchantment.getId();
            var resolved = java.util.Objects.requireNonNull(selectedEnchantment).resolve(central.item()).orElseThrow();
            quotedInstability = resolved.cost().instability();
            quotedEssentia = resolved.cost().aspects().amounts();
            ingredientCount = java.util.Objects.requireNonNull(selectedEnchantment).pedestalComponents().size();
            quotedXp = resolved.cost().experienceLevels();
        }
        // Addons adjust the computed quote for this craft; nothing is
        // committed until no listener cancels the start.
        InfusionStartEvent startEvent = new InfusionStartEvent(server, this.worldPosition, player, selectedId, enchantment, central.item(), this.scannedPedestalSymmetry, this.scannedStabilizerSymmetry, this.symmetry, new AspectAmounts(quotedEssentia), quotedInstability, quotedXp, TCGameplayParameters.MACHINES_INFUSION_ESSENTIA_PER_PULSE.intValue(), TCGameplayParameters.MACHINES_INFUSION_COMPONENT_ABSORPTION_PULSES.intValue());
        if (net.minecraftforge.common.MinecraftForge.EVENT_BUS.post(startEvent)) {
            return false;
        }
        this.enchantmentRecipe = enchantment;
        this.recipeId = selectedId;
        this.recipeFingerprint = fingerprint;
        this.recipeInstability = startEvent.recipeInstability();
        this.recipeEssentia.clear();
        this.recipeEssentia.putAll(startEvent.aspects().amounts());
        this.prepareIngredientIndices(ingredientCount);
        this.recipeXp = startEvent.experienceLevels();
        this.craftEssentiaPerPulse = startEvent.essentiaPerPulse();
        this.craftAbsorptionPulses = startEvent.absorptionPulses();
        this.craftSymmetryAdjustment = (int) Math.max(Integer.MIN_VALUE, Math.min(Integer.MAX_VALUE, (long) startEvent.symmetry() - this.symmetry));
        this.recipeInput = central.item().copy();
        this.recipePlayer = player.getGameProfile().getName();
        this.resetIngredientAbsorption(false);
        this.countDelay = DEFAULT_WORK_DELAY;
        this.instability = (int) Math.min(Integer.MAX_VALUE, (long) startEvent.symmetry() + this.recipeInstability);
        this.crafting = true;
        this.shufflePedestalScanOrder();
        server.playSound(null, this.worldPosition, TCSounds.CRAFT_START.get(), SoundSource.BLOCKS, 0.5F, 1.0F);
        this.changedAndSync();
        return true;
    }

    private static boolean knowsResearch(Player player, ResearchRequirement requirement) {
        return requirement.key().map(key -> ResearchApi.isComplete(player, key)).orElse(true);
    }

    private void prepareIngredientIndices(int ingredientCount) {
        this.remainingIngredients.clear();
        for (int index = 0; index < ingredientCount; index++) {
            this.remainingIngredients.add(index);
        }
    }

    /**
     * One core work step. Requires an active, crafting matrix; prefer
     * {@code InfusionMatrixApi.craftCycle}, which checks that.
     */
    public void craftCycle() {
        if (!this.recipeDefinitionStillMatches()) {
            this.failCrafting();
            return;
        }
        ArcanePedestalBlockEntity central = this.centralPedestal();
        boolean valid = central != null && !central.item().isEmpty() && this.centralStillMatches(central.item());
        if (!valid || this.instability > 0 && this.level.random.nextInt(dev.tc4port.thaumcraft.common.TCGameplayParameters.MACHINES_INFUSION_ACCIDENT_DENOMINATOR.intValue()) <= this.instability) {
            this.applyInstabilityEvent();
            if (valid) {
                return;
            }
        }
        if (!valid) {
            this.failCrafting();
            return;
        }
        // Enchantment recipes quote experience; start listeners may add an
        // experience cost to any recipe, which is drained the same way.
        if (this.recipeXp > 0) {
            this.drainExperienceLevel();
            return;
        }
        this.countDelay = DEFAULT_WORK_DELAY;
        AspectId aspect = this.recipeEssentia.entrySet().stream().filter(entry -> entry.getValue() > 0).map(Map.Entry::getKey).findFirst().orElse(null);
        if (aspect != null) {
            int drained = this.drainEssentia(aspect, Math.min(this.recipeEssentia.get(aspect), this.essentiaPerPulse()));
            if (drained > 0) {
                this.reduceEssentia(aspect, drained);
                this.changedAndSync();
                return;
            }
            if (this.level.random.nextInt(this.penaltyBound(TCGameplayParameters.MACHINES_INFUSION_ESSENTIA_SHORTAGE_PENALTY_BOUND.intValue(), TCGameplayParameters.MACHINES_INFUSION_ESSENTIA_SHORTAGE_PENALTY_SCALING.intValue())) == 0) {
                this.raisePenaltyInstability();
            }
            this.checkSurroundings = true;
            this.changedAndSync();
            return;
        }
        if (this.remainingIngredients.isEmpty()) {
            this.finishCrafting(central);
            return;
        }
        List<Ingredient> recipeComponents = this.currentPedestalComponents();
        if (recipeComponents == null || !this.remainingIngredientIndicesValid(recipeComponents.size())) {
            this.failCrafting();
            return;
        }
        if (this.ingredientPedestal != null) {
            this.advanceIngredientAbsorption(recipeComponents);
            this.changedAndSync();
            return;
        }
        for (int listIndex = 0; listIndex < this.remainingIngredients.size(); listIndex++) {
            int ingredientIndex = this.remainingIngredients.get(listIndex);
            Ingredient ingredient = recipeComponents.get(ingredientIndex);
            ArcanePedestalBlockEntity source = this.findPedestal(ingredient, ingredientIndex);
            if (source == null) {
                this.missingIngredientPenalty(listIndex);
                continue;
            }
            this.beginIngredientAbsorption(source, ingredientIndex);
            this.changedAndSync();
            return;
        }
    }

    private void beginIngredientAbsorption(ArcanePedestalBlockEntity source, int selectedIngredient) {
        this.ingredientPedestal = source.getBlockPos().immutable();
        this.ingredientIndex = selectedIngredient;
        this.ingredientStack = source.item().copy();
        this.ingredientRevision = source.contentRevision();
        this.ingredientTransaction = this.nextIngredientTransaction();
        this.itemCount = this.absorptionPulses();
        this.activePedestal = this.ingredientPedestal;
        this.sendPayload(InfusionSourcePayload.itemStart(this.worldPosition, this.ingredientPedestal, this.ingredientTransaction, this.ingredientStack));
    }

    private void advanceIngredientAbsorption(List<Ingredient> recipeComponents) {
        if (!this.ingredientAbsorptionStillValid(recipeComponents)) {
            /*
             * Do not transfer partial progress to a replacement stack or a
             * different matching pedestal.  The next work pulse performs a
             * fresh selection and starts a new visual transaction.
             */
            this.resetIngredientAbsorption(true);
            return;
        }
        if (this.itemCount-- > 1) {
            return;
        }
        ArcanePedestalBlockEntity source = (ArcanePedestalBlockEntity) this.level.getBlockEntity(this.ingredientPedestal);
        ItemStack consumed = source.item().copy();
        var holder = this.enchantmentRecipe ? null : this.recipe();
        ItemStack remainder = holder == null ? (consumed.hasCraftingRemainingItem() ? consumed.getCraftingRemainingItem() : ItemStack.EMPTY) : java.util.Objects.requireNonNull(holder).completeComponent(this.ingredientIndex, consumed, (ServerLevel) this.level);
        InfusionComponentConsumedEvent consumedEvent = new InfusionComponentConsumedEvent((ServerLevel) this.level, this.worldPosition, this.recipeId, this.ingredientTransaction, this.ingredientPedestal, this.ingredientIndex, consumed, remainder);
        net.minecraftforge.common.MinecraftForge.EVENT_BUS.post(consumedEvent);
        boolean replaced = !ItemStack.matches(remainder, consumedEvent.remainder());
        remainder = consumedEvent.remainder();
        if (replaced || holder != null && java.util.Objects.requireNonNull(holder).hasComponentOperation(this.ingredientIndex)) {
            source.setFromInfusion(remainder);
        } else {
            source.setItem(0, remainder);
        }
        this.remainingIngredients.remove(Integer.valueOf(this.ingredientIndex));
        this.resetIngredientAbsorption(true);
    }

    private boolean ingredientAbsorptionStillValid(List<Ingredient> recipeComponents) {
        if (this.ingredientPedestal == null || this.ingredientIndex < 0 || this.ingredientIndex >= recipeComponents.size() || !this.remainingIngredients.contains(this.ingredientIndex) || !(this.level.getBlockEntity(this.ingredientPedestal) instanceof ArcanePedestalBlockEntity source) || source.contentRevision() != this.ingredientRevision) {
            return false;
        }
        ItemStack current = source.item();
        return current.getCount() == this.ingredientStack.getCount() && net.minecraft.world.item.ItemStack.isSameItemSameTags((net.minecraft.world.item.ItemStack) (current), (net.minecraft.world.item.ItemStack) (this.ingredientStack)) && recipeComponents.get(this.ingredientIndex).test(current) && (this.enchantmentRecipe || java.util.Objects.requireNonNull(this.recipe()).supportsComponentInput(this.ingredientIndex, current));
    }

    private int nextIngredientTransaction() {
        if (this.nextIngredientTransaction == Integer.MAX_VALUE) {
            this.nextIngredientTransaction = 1;
        } else {
            this.nextIngredientTransaction++;
        }
        return this.nextIngredientTransaction;
    }

    private void resetIngredientAbsorption(boolean notifyClient) {
        if (notifyClient && this.ingredientPedestal != null && this.ingredientTransaction != 0) {
            this.sendPayload(InfusionSourcePayload.itemCancel(this.worldPosition, this.ingredientPedestal, this.ingredientTransaction));
        }
        if (Objects.equals(this.activePedestal, this.ingredientPedestal)) {
            this.activePedestal = null;
        }
        this.ingredientPedestal = null;
        this.ingredientIndex = -1;
        this.ingredientStack = ItemStack.EMPTY;
        this.ingredientRevision = -1L;
        this.ingredientTransaction = 0;
        this.itemCount = 0;
    }

    private boolean centralStillMatches(ItemStack current) {
        boolean acceptedIdentity;
        if (this.enchantmentRecipe) {
            acceptedIdentity = current.is(this.recipeInput.getItem());
        } else {
            InfusionRecipe holder = this.recipe();
            acceptedIdentity = holder != null && java.util.Objects.requireNonNull(holder).supportsCentralInput(this.recipeInput) && java.util.Objects.requireNonNull(holder).supportsCentralInput(current) && java.util.Objects.requireNonNull(holder).runicAugmentationCharge(this.recipeInput).equals(java.util.Objects.requireNonNull(holder).runicAugmentationCharge(current));
        }
        if (!acceptedIdentity) {
            return false;
        }
        /*
         * InventoryUtils.areItemStacksEqualForCrafting(..., true, true,
         * false) ignored durability, required every original NBT key, and
         * permitted extra keys on the live stack. Data-component patches are
         * the modern equivalent of those non-default NBT keys.
         */
        if (!current.is(this.recipeInput.getItem())) {
            // The old OreDictionary fast path accepted the equivalent item
            // before comparing tags.
            return true;
        }
        return InfusionMatrixBlockEntity.native$ItemIdentity$matchesRequirements(current, this.recipeInput, true);
    }

    private void drainExperienceLevel() {
        List<Player> players = this.level.getEntitiesOfClass(Player.class, new AABB(this.worldPosition).inflate(TCGameplayParameters.MACHINES_INFUSION_EXPERIENCE_DRAIN_RANGE.value()));
        if (players.isEmpty()) {
            return;
        }
        for (Player player : players) {
            if (player.experienceLevel <= 0) {
                continue;
            }
            int drained = Math.min(Math.min(player.experienceLevel, this.recipeXp), TCGameplayParameters.MACHINES_INFUSION_EXPERIENCE_LEVELS_PER_DRAIN.intValue());
            player.giveExperienceLevels(-drained);
            this.recipeXp -= drained;
            player.hurt(this.level.damageSources().magic(), this.level.random.nextInt(2));
            this.activePedestal = player.blockPosition();
            this.sendInfusionSource(this.worldPosition, InfusionSourcePayload.ENTITY, player.getId());
            this.level.playSound(null, player.blockPosition(), TCSounds.INFUSION_DRAIN_EXPERIENCE.get(), SoundSource.PLAYERS, 1.0F, 2.0F + this.level.random.nextFloat() * 0.4F);
            this.countDelay = EXPERIENCE_WORK_DELAY;
            this.changedAndSync();
            return;
        }
        if (this.level.random.nextInt(TCGameplayParameters.MACHINES_INFUSION_MISSING_EXPERIENCE_ESSENTIA_DENOMINATOR.intValue()) == 0 && !this.recipeEssentia.isEmpty()) {
            List<AspectId> aspects = new ArrayList<>(this.recipeEssentia.keySet());
            AspectId aspect = aspects.get(this.level.random.nextInt(aspects.size()));
            this.recipeEssentia.merge(aspect, 1, InfusionMatrixBlockEntity::saturatingAdd);
            if (this.level.random.nextInt(this.missingInputPenaltyBound()) == 0) {
                this.raisePenaltyInstability();
            }
            this.changedAndSync();
        }
    }

    private void finishCrafting(ArcanePedestalBlockEntity central) {
        ResourceLocation completedId = this.recipeId;
        String completedPlayer = this.recipePlayer;
        net.minecraft.world.item.crafting.Recipe<?> completedRecipe;
        ItemStack output;
        if (this.enchantmentRecipe) {
            InfusionEnchantmentRecipe holder = this.enchantmentRecipe();
            if (holder == null) {
                this.stopCrafting();
                return;
            }
            completedRecipe = holder;
            output = java.util.Objects.requireNonNull(holder).enchantCentral(central.item());
        } else {
            InfusionRecipe holder = this.recipe();
            if (holder == null) {
                this.stopCrafting();
                return;
            }
            completedRecipe = holder;
            output = java.util.Objects.requireNonNull(holder).completeFromCentral(central.item(), (ServerLevel) this.level);
        }
        central.setFromInfusion(output);
        if (this.recipePlayer != null && this.level instanceof ServerLevel server) {
            ServerPlayer player = server.getServer().getPlayerList().getPlayerByName(this.recipePlayer);
            if (player != null) {
                output.onCraftedBy(server, player, output.getCount());
                GameplayHooks.firePlayerCraftingEvent(player, output, /*
                         * recipeIngredients was empty at this source branch;
                         * InventoryFake consequently exposed an empty input
                         * inventory rather than the output pedestal.
                         */
                new SimpleContainer(0));
                {
                    net.minecraft.world.entity.player.Player native$operand$13109 = player;
                    net.minecraft.world.item.crafting.Recipe<?> native$operand$13110 = completedRecipe;
                    native$operand$13109.awardRecipes(java.util.List.of(java.util.Objects.requireNonNull(native$operand$13110)));
                }
            }
        }
        this.instability = 0;
        this.recipeEssentia.clear();
        this.crafting = false;
        this.enchantmentRecipe = false;
        this.recipeId = null;
        this.recipeFingerprint = null;
        this.recipeXp = 0;
        this.craftEssentiaPerPulse = 0;
        this.craftAbsorptionPulses = 0;
        this.craftSymmetryAdjustment = 0;
        this.resetIngredientAbsorption(true);
        this.activePedestal = null;
        this.level.blockEvent(central.getBlockPos(), central.getBlockState().getBlock(), 12, 0);
        this.changedAndSync();
        this.postEnd(InfusionEndEvent.Outcome.COMPLETED, completedId, completedPlayer, output);
    }

    private void postEnd(InfusionEndEvent.Outcome outcome, @Nullable ResourceLocation endedId, @Nullable String endedPlayer, ItemStack output) {
        if (this.level instanceof ServerLevel server) {
            net.minecraftforge.common.MinecraftForge.EVENT_BUS.post(new InfusionEndEvent(server, this.worldPosition, outcome, endedId, endedPlayer, output));
        }
    }

    private void stopCrafting() {
        ResourceLocation endedId = this.recipeId;
        String endedPlayer = this.recipePlayer;
        this.clearAndSync();
        this.postEnd(InfusionEndEvent.Outcome.STOPPED, endedId, endedPlayer, ItemStack.EMPTY);
    }

    private void clearAndSync() {
        this.clearCraftingState();
        this.resetIngredientAbsorption(true);
        this.countDelay = DEFAULT_WORK_DELAY;
        this.changedAndSync();
    }

    /**
     * Clears only the fields represented by an in-flight transaction.
     */
    private void clearCraftingState() {
        this.crafting = false;
        this.enchantmentRecipe = false;
        this.recipeEssentia.clear();
        this.remainingIngredients.clear();
        this.recipeId = null;
        this.recipeFingerprint = null;
        this.recipeInput = ItemStack.EMPTY;
        this.recipePlayer = null;
        this.recipeXp = 0;
        this.craftEssentiaPerPulse = 0;
        this.craftAbsorptionPulses = 0;
        this.craftSymmetryAdjustment = 0;
        this.activePedestal = null;
    }

    @Nullable
    private ArcanePedestalBlockEntity centralPedestal() {
        return this.level.getBlockEntity(this.worldPosition.below(2)) instanceof ArcanePedestalBlockEntity pedestal ? pedestal : null;
    }

    @Nullable
    private InfusionRecipe recipe() {
        if (this.recipeId == null || this.level == null) {
            return null;
        }
        return RecipeLookup.byKey(this.level.getRecipeManager(), this.recipeId, InfusionRecipe.class).orElse(null);
    }

    @Nullable
    private InfusionEnchantmentRecipe enchantmentRecipe() {
        if (this.recipeId == null || this.level == null) {
            return null;
        }
        return RecipeLookup.byKey(this.level.getRecipeManager(), this.recipeId, InfusionEnchantmentRecipe.class).orElse(null);
    }

    @Nullable
    private List<Ingredient> currentPedestalComponents() {
        if (this.enchantmentRecipe) {
            InfusionEnchantmentRecipe holder = this.enchantmentRecipe();
            return holder == null ? null : java.util.Objects.requireNonNull(holder).pedestalComponents();
        }
        InfusionRecipe holder = this.recipe();
        return holder == null || !java.util.Objects.requireNonNull(holder).supportsCentralInput(this.recipeInput) ? null : java.util.Objects.requireNonNull(holder).pedestalComponents(this.recipeInput);
    }

    private boolean recipeDefinitionStillMatches() {
        if (this.recipeFingerprint == null) {
            return false;
        }
        String current;
        if (this.enchantmentRecipe) {
            InfusionEnchantmentRecipe holder = this.enchantmentRecipe();
            current = holder == null ? null : this.recipeFingerprint(java.util.Objects.requireNonNull(holder));
        } else {
            InfusionRecipe holder = this.recipe();
            current = holder == null || !java.util.Objects.requireNonNull(holder).supportsCentralInput(this.recipeInput) ? null : this.recipeFingerprint(java.util.Objects.requireNonNull(holder));
        }
        return this.recipeFingerprint.equals(current);
    }

    private boolean remainingIngredientIndicesValid(int componentCount) {
        for (int index : this.remainingIngredients) {
            if (index < 0 || index >= componentCount) {
                return false;
            }
        }
        return true;
    }

    private void failCrafting() {
        ResourceLocation endedId = this.recipeId;
        String endedPlayer = this.recipePlayer;
        this.instability = 0;
        this.clearAndSync();
        this.level.playSound(null, this.worldPosition, TCSounds.CRAFT_FAIL.get(), SoundSource.BLOCKS, 1.0F, 0.6F);
        this.postEnd(InfusionEndEvent.Outcome.FAILED, endedId, endedPlayer, ItemStack.EMPTY);
    }

    @Nullable
    private String recipeFingerprint(InfusionRecipe recipe) {
        return this.recipeFingerprint(recipe, this.recipeInput);
    }

    @Nullable
    private String recipeFingerprint(InfusionRecipe recipe, ItemStack centralInput) {
        if (this.level == null) {
            return null;
        }
        try {
            RegistryOps<JsonElement> ops = RegistryOps.create(JsonOps.INSTANCE, this.level.registryAccess());
            JsonElement encoded = InfusionMatrixBlockEntity.native$RecipeAccess$encode(TCRecipes.INFUSION_SERIALIZER.get(), ops, recipe);
            var charge = recipe.runicAugmentationCharge(centralInput);
            if (charge.isPresent()) {
                JsonObject resolved = new JsonObject();
                resolved.add("recipe", encoded);
                resolved.addProperty("runic_charge", charge.get());
                encoded = resolved;
            }
            return this.fingerprintEncodedDefinition(encoded);
        } catch (RuntimeException exception) {
            return null;
        }
    }

    @Nullable
    private String recipeFingerprint(InfusionEnchantmentRecipe recipe) {
        if (this.level == null) {
            return null;
        }
        try {
            RegistryOps<JsonElement> ops = RegistryOps.create(JsonOps.INSTANCE, this.level.registryAccess());
            JsonElement encoded = InfusionMatrixBlockEntity.native$RecipeAccess$encode(TCRecipes.INFUSION_ENCHANTMENT_SERIALIZER.get(), ops, recipe);
            return this.fingerprintEncodedDefinition(encoded);
        } catch (RuntimeException exception) {
            return null;
        }
    }

    private String fingerprintEncodedDefinition(JsonElement encoded) {
        if (this.cachedDefinitionFingerprint != null && sameEncodedDefinition(encoded, this.cachedRecipeDefinition)) {
            return this.cachedDefinitionFingerprint;
        }
        JsonElement snapshot = canonicalJson(encoded);
        String fingerprint = sha256(snapshot.toString());
        // canonicalJson also freezes Number values: JsonPrimitive.deepCopy()
        // itself retains AtomicInteger/AtomicLong supplied by a serializer.
        this.cachedRecipeDefinition = snapshot;
        this.cachedDefinitionFingerprint = fingerprint;
        return fingerprint;
    }

    private static boolean sameEncodedDefinition(JsonElement first, @Nullable JsonElement second) {
        if (second == null) {
            return false;
        }
        if (first.isJsonObject() && second.isJsonObject()) {
            JsonObject left = first.getAsJsonObject();
            JsonObject right = second.getAsJsonObject();
            if (left.size() != right.size()) {
                return false;
            }
            for (Map.Entry<String, JsonElement> entry : left.entrySet()) {
                if (!sameEncodedDefinition(entry.getValue(), right.get(entry.getKey()))) {
                    return false;
                }
            }
            return true;
        }
        if (first.isJsonArray() && second.isJsonArray()) {
            JsonArray left = first.getAsJsonArray();
            JsonArray right = second.getAsJsonArray();
            if (left.size() != right.size()) {
                return false;
            }
            for (int index = 0; index < left.size(); index++) {
                if (!sameEncodedDefinition(left.get(index), right.get(index))) {
                    return false;
                }
            }
            return true;
        }
        // Gson considers numeric 1 and 1.0 equal, but the persisted canonical
        // SHA distinguishes their JSON spelling. Retain that exact contract.
        if (first.isJsonPrimitive() && first.getAsJsonPrimitive().isNumber()) {
            return second.isJsonPrimitive() && second.getAsJsonPrimitive().isNumber() && first.toString().equals(second.toString());
        }
        return first.equals(second);
    }

    private static JsonElement canonicalJson(JsonElement input) {
        if (input.isJsonObject()) {
            JsonObject canonical = new JsonObject();
            input.getAsJsonObject().entrySet().stream().sorted(Map.Entry.comparingByKey()).forEach(entry -> canonical.add(entry.getKey(), canonicalJson(entry.getValue())));
            return canonical;
        }
        if (input.isJsonArray()) {
            JsonArray canonical = new JsonArray();
            input.getAsJsonArray().forEach(element -> canonical.add(canonicalJson(element)));
            return canonical;
        }
        if (input.isJsonPrimitive() && input.getAsJsonPrimitive().isNumber()) {
            return new com.google.gson.JsonPrimitive(new com.google.gson.internal.LazilyParsedNumber(input.getAsNumber().toString()));
        }
        return input.deepCopy();
    }

    private static String sha256(String value) {
        try {
            return HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(value.getBytes(StandardCharsets.UTF_8)));
        } catch (NoSuchAlgorithmException exception) {
            throw new IllegalStateException("SHA-256 is unavailable", exception);
        }
    }

    @Nullable
    private ArcanePedestalBlockEntity findPedestal(Ingredient ingredient, int ingredientIndex) {
        var holder = this.enchantmentRecipe ? null : this.recipe();
        for (BlockPos pos : this.pedestals()) {
            if (this.level.getBlockEntity(pos) instanceof ArcanePedestalBlockEntity pedestal && ingredient.test(pedestal.item()) && (holder == null || java.util.Objects.requireNonNull(holder).supportsComponentInput(ingredientIndex, pedestal.item()))) {
                return pedestal;
            }
        }
        return null;
    }

    /**
     * Draws up to {@code maximum} single units in one pulse, each through the
     * ordinary search with its own source feedback, stopping at the first miss.
     *
     * @return the units actually drawn
     */
    private int drainEssentia(AspectId aspect, int maximum) {
        int drained = 0;
        while (drained < maximum && this.drainOneEssentia(aspect)) {
            drained++;
        }
        return drained;
    }

    private boolean drainOneEssentia(AspectId aspect) {
        var extracted = EssentiaApi.extract(this.level, this.worldPosition, aspect, 1, EssentiaSearch.nearby(TCGameplayParameters.MACHINES_INFUSION_ESSENTIA_SEARCH_RANGE.intValue()), EssentiaTransferMode.EXECUTE);
        if (extracted.isPresent()) {
            BlockPos source = extracted.orElseThrow().position();
            this.activePedestal = source;
            AspectDefinition definition = AspectCatalog.get(aspect);
            this.sendInfusionSource(source, InfusionSourcePayload.ESSENTIA, definition == null ? 0xFFFFFF : definition.color());
            return true;
        }
        return false;
    }

    private void reduceEssentia(AspectId aspect, int amount) {
        int left = this.recipeEssentia.getOrDefault(aspect, 0) - amount;
        if (left <= 0) {
            this.recipeEssentia.remove(aspect);
        } else {
            this.recipeEssentia.put(aspect, left);
        }
    }

    private void missingIngredientPenalty(int ingredientIndex) {
        if (this.recipeEssentia.isEmpty() || this.level.random.nextInt(1 + ingredientIndex) != 0) {
            return;
        }
        List<AspectId> aspects = new ArrayList<>(this.recipeEssentia.keySet());
        AspectId aspect = aspects.get(this.level.random.nextInt(aspects.size()));
        this.recipeEssentia.merge(aspect, 1, InfusionMatrixBlockEntity::saturatingAdd);
        if (this.level.random.nextInt(this.missingInputPenaltyBound()) == 0) {
            this.raisePenaltyInstability();
        }
    }

    private void applyInstabilityEvent() {
        if (!(this.level instanceof ServerLevel server))
            return;
        dev.tc4port.thaumcraft.common.GameplayRollCatalog.INFUSION.roll(0, new dev.tc4port.thaumcraft.api.gameplay.GameplayContext(server, Vec3.atCenterOf(this.worldPosition), java.util.Optional.empty(), java.util.Optional.empty(), ItemStack.EMPTY, java.util.Map.of("instability", (double) this.instability)));
    }

    private int penaltyBound(int base, int multiplier) {
        return (int) Math.max(1L, (long) base - (long) this.recipeInstability * multiplier);
    }

    private static int saturatingAdd(int first, int second) {
        return (int) Math.min(Integer.MAX_VALUE, (long) first + second);
    }

    public void ejectItem(int type) {
        if (!(this.level instanceof ServerLevel server) || this.pedestals().isEmpty()) {
            return;
        }
        for (int attempt = 0; attempt < 50; attempt++) {
            BlockPos pos = this.pedestals.get(this.level.random.nextInt(this.pedestals.size()));
            if (!(this.level.getBlockEntity(pos) instanceof ArcanePedestalBlockEntity pedestal) || pedestal.item().isEmpty()) {
                continue;
            }
            /*
             * TilePedestal.decrStackSize/setInventorySlotContents both sent a
             * block update in 1.7.10.  The no-update extraction left the
             * client-side pedestal stack (and its infusion source effect)
             * alive after an instability ejection.
             */
            ItemStack stack = pedestal.removeItem(0, pedestal.item().getCount());
            if (pos.equals(this.ingredientPedestal)) {
                this.resetIngredientAbsorption(true);
            }
            if (type < 3 || type == 5) {
                double spawnX = pos.getX() + 0.1 + server.random.nextFloat() * 0.8;
                double spawnZ = pos.getZ() + 0.1 + server.random.nextFloat() * 0.8;
                ItemEntity dropped = new ItemEntity(server, spawnX, /*
                         * InventoryUtils.dropItems spawned the source entity
                         * at Y + 0.1..0.9, inside the pedestal's full-cube
                         * collision. Modern ItemEntity escape selection can
                         * then squeeze it sideways into the altar. Start just
                         * above the top face while retaining the source
                         * horizontal distribution and launch velocity.
                         */
                pos.getY() + EJECTION_SPAWN_Y_OFFSET, spawnZ, stack);
                dropped.setDeltaMovement(server.random.nextGaussian() * 0.05, server.random.nextGaussian() * 0.05 + 0.2, server.random.nextGaussian() * 0.05);
                server.addFreshEntity(dropped);
            }
            if (type == 1 || type == 3) {
                FluxApi.place(server, pos.above(), TCFluids.FLUX_GOO.get(), 8, Block.UPDATE_ALL);
                server.playSound(null, pos, TCSounds.INFUSION_FLUX_GOO.get(), SoundSource.BLOCKS, 0.3F, 1.0F);
            } else if (type == 2 || type == 4) {
                FluxApi.place(server, pos.above(), TCFluids.FLUX_GAS.get(), 8, Block.UPDATE_ALL);
                server.playSound(null, pos, TCSounds.INFUSION_FLUX_GAS.get(), SoundSource.BLOCKS, 0.3F, 1.0F);
            } else if (type == 5) {
                server.explode(null, pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5, 1.0F, Level.ExplosionInteraction.NONE);
            }
            server.blockEvent(pos, pedestal.getBlockState().getBlock(), 11, 0);
            this.activePedestal = pos;
            this.sendBolt(new Vec3(pos.getX() + 0.5, pos.getY() + 1.5, pos.getZ() + 0.5));
            return;
        }
    }

    public void boltTo(LivingEntity target) {
        this.sendBolt(new Vec3(target.getX(), target.getY() + target.getBbHeight() / 2.0F, target.getZ()));
    }

    private void sendInfusionSource(BlockPos source, int kind, int color) {
        this.sendPayload(new InfusionSourcePayload(this.worldPosition, source, kind, color));
    }

    private void sendPayload(InfusionSourcePayload payload) {
        if (!(this.level instanceof ServerLevel server)) {
            return;
        }
        Vec3 center = Vec3.atCenterOf(this.worldPosition);
        for (ServerPlayer player : server.players()) {
            if (player.distanceToSqr(center) <= 32.0 * 32.0) {
                dev.tc4port.thaumcraft.network.TCPayloads.CHANNEL.sendToPlayer(player, payload);
            }
        }
    }

    private void sendBolt(Vec3 target) {
        if (!(this.level instanceof ServerLevel server)) {
            return;
        }
        Vec3 source = Vec3.atCenterOf(this.worldPosition);
        NodeBoltPayload payload = new NodeBoltPayload(source, target);
        for (ServerPlayer player : server.players()) {
            if (player.distanceToSqr(source) <= 32.0 * 32.0) {
                dev.tc4port.thaumcraft.network.TCPayloads.CHANNEL.sendToPlayer(player, payload);
            }
        }
    }

    /**
     * Rebuilds the derived pedestal and symmetry cache while it is flagged.
     * The cache itself is never persisted, so a load flags it again instead of
     * trusting a stored clean flag.
     */
    private void refreshSurroundings() {
        if (this.checkSurroundings) {
            this.scanSurroundings();
        }
    }

    /**
     * The pedestal positions behind every read, rebuilt on demand. Reading
     * through this accessor keeps a flagged cache from being observed as an
     * empty surrounding scan.
     */
    private List<BlockPos> pedestals() {
        this.refreshSurroundings();
        return this.pedestals;
    }

    private static int[] naturalPedestalAxisRanks() {
        int[] ranks = new int[PEDESTAL_AXIS_SIZE];
        for (int index = 0; index < ranks.length; index++) ranks[index] = index;
        return ranks;
    }

    private int[] shuffledPedestalAxisRanks() {
        int[] ranks = naturalPedestalAxisRanks();
        for (int index = ranks.length - 1; index > 0; index--) {
            int other = this.level.random.nextInt(index + 1);
            int rank = ranks[index];
            ranks[index] = ranks[other];
            ranks[other] = rank;
        }
        return ranks;
    }

    private Comparator<BlockPos> pedestalScanOrder() {
        return Comparator.comparingInt((BlockPos pos) -> this.pedestalXScanRanks[pos.getX() - this.worldPosition.getX() + PEDESTAL_SCAN_RADIUS]).thenComparingInt(pos -> this.pedestalZScanRanks[pos.getZ() - this.worldPosition.getZ() + PEDESTAL_SCAN_RADIUS]).thenComparingInt(BlockPos::getY);
    }

    private void shufflePedestalScanOrder() {
        this.pedestalXScanRanks = this.shuffledPedestalAxisRanks();
        this.pedestalZScanRanks = this.shuffledPedestalAxisRanks();
        this.pedestals.sort(this.pedestalScanOrder());
    }

    private static int[] readPedestalAxisRanks(CompoundTag tag, String key) {
        int[] ranks = tag.getIntArray(key);
        if (ranks.length != PEDESTAL_AXIS_SIZE)
            return naturalPedestalAxisRanks();
        boolean[] seen = new boolean[PEDESTAL_AXIS_SIZE];
        for (int rank : ranks) {
            if (rank < 0 || rank >= ranks.length || seen[rank])
                return naturalPedestalAxisRanks();
            seen[rank] = true;
        }
        return ranks;
    }

    /**
     * Whether every chunk the matrix scans is loaded; the tick waits until it is.
     */
    public boolean surroundingsLoaded() {
        if (this.level == null)
            return false;
        for (int x = (this.worldPosition.getX() - 12) >> 4; x <= (this.worldPosition.getX() + 12) >> 4; x++) {
            for (int z = (this.worldPosition.getZ() - 12) >> 4; z <= (this.worldPosition.getZ() + 12) >> 4; z++) {
                if (!this.level.hasChunk(x, z))
                    return false;
            }
        }
        return true;
    }

    public void scanSurroundings() {
        if (!this.surroundingsLoaded()) {
            this.checkSurroundings = true;
            return;
        }
        this.checkSurroundings = false;
        this.pedestals.clear();
        // Preserve the original x/z/descending-y visit order, including the
        // first pedestal in each column, without probing empty block entities.
        Comparator<BlockPos> scanOrder = Comparator.comparingInt((BlockPos pos) -> pos.getX()).thenComparingInt(BlockPos::getZ).thenComparing(Comparator.comparingInt((BlockPos pos) -> pos.getY()).reversed());
        List<BlockPos> candidates = InfusionMatrixBlockEntity.native$BlockRegionQueries$blockEntityPositions(this.level, this.worldPosition.offset(-8, -10, -8), this.worldPosition.offset(8, -1, 8), false);
        candidates.sort(scanOrder);
        BlockPos previousColumn = null;
        for (BlockPos candidate : candidates) {
            if (candidate.getX() == this.worldPosition.getX() && candidate.getZ() == this.worldPosition.getZ())
                continue;
            if (previousColumn != null && candidate.getX() == previousColumn.getX() && candidate.getZ() == previousColumn.getZ())
                continue;
            if (this.level.getBlockEntity(candidate) instanceof ArcanePedestalBlockEntity) {
                this.pedestals.add(candidate);
                previousColumn = candidate;
            }
        }
        java.util.Set<BlockPos> selectedPedestals = new java.util.HashSet<>(this.pedestals);
        List<BlockPos> stabilizers = InfusionMatrixBlockEntity.native$BlockRegionQueries$matchingPositions(this.level, this.worldPosition.offset(-12, -10, -12), this.worldPosition.offset(12, 5, 12), false, InfusionMatrixBlockEntity::isStabilizer);
        stabilizers.removeIf((net.minecraft.core.BlockPos pos) -> selectedPedestals.contains(pos) || pos.getX() == this.worldPosition.getX() && pos.getZ() == this.worldPosition.getZ());
        stabilizers.sort(scanOrder);
        this.pedestals.sort(this.pedestalScanOrder());
        this.symmetry = 0;
        int pedestalSymmetry = TCGameplayParameters.MACHINES_INFUSION_PEDESTAL_SYMMETRY.intValue();
        int filledSymmetry = TCGameplayParameters.MACHINES_INFUSION_FILLED_PEDESTAL_SYMMETRY.intValue();
        float stabilizerBonus = (float) TCGameplayParameters.MACHINES_INFUSION_STABILIZER_SYMMETRY.value();
        float mirroredStabilizerBonus = (float) TCGameplayParameters.MACHINES_INFUSION_MIRRORED_STABILIZER_SYMMETRY.value();
        for (BlockPos pedestalPos : this.pedestals) {
            boolean item = this.level.getBlockEntity(pedestalPos) instanceof ArcanePedestalBlockEntity pedestal && !pedestal.item().isEmpty();
            this.symmetry += pedestalSymmetry + (item ? filledSymmetry : 0);
            BlockPos mirror = mirror(pedestalPos);
            if (this.level.getBlockEntity(mirror) instanceof ArcanePedestalBlockEntity mirrored) {
                this.symmetry -= pedestalSymmetry;
                if (item && !mirrored.item().isEmpty()) {
                    this.symmetry -= filledSymmetry;
                }
            }
        }
        this.scannedPedestalSymmetry = this.symmetry;
        float stabilizerSymmetry = 0;
        for (BlockPos stabilizer : stabilizers) {
            if (isStabilizer(this.level.getBlockState(stabilizer))) {
                stabilizerSymmetry += stabilizerBonus;
            }
            // TC4 passed the unmirrored position to custom stabilizer
            // predicates here; stabilizers are now matched by state alone.
            BlockPos mirrored = mirror(stabilizer);
            if (isStabilizer(this.level.getBlockState(mirrored))) {
                stabilizerSymmetry -= mirroredStabilizerBonus;
            }
        }
        this.scannedStabilizerSymmetry = stabilizerSymmetry;
        this.symmetry = (int) (this.symmetry + stabilizerSymmetry);
    }

    private BlockPos mirror(BlockPos pos) {
        return new BlockPos(this.worldPosition.getX() + (this.worldPosition.getX() - pos.getX()), pos.getY(), this.worldPosition.getZ() + (this.worldPosition.getZ() - pos.getZ()));
    }

    private static boolean isStabilizer(BlockState state) {
        return state.getBlock() instanceof AbstractSkullBlock || state.is(TCTags.INFUSION_STABILIZERS);
    }

    @Override
    public void load(CompoundTag tag) {
        HolderLookup.Provider registries = persistenceRegistries();
        super.load(tag);
        this.active = tag.getBoolean("active");
        this.crafting = tag.getBoolean("crafting");
        this.pedestalXScanRanks = readPedestalAxisRanks(tag, "pedestalXScanRanks");
        this.pedestalZScanRanks = readPedestalAxisRanks(tag, "pedestalZScanRanks");
        this.enchantmentRecipe = tag.getBoolean("enchantmentRecipe");
        this.symmetry = tag.getInt("symmetry");
        this.instability = tag.getInt("instability");
        this.recipeInstability = tag.getInt("recipeInstability");
        this.count = tag.getInt("count");
        int storedCountDelay = tag.getInt("countDelay");
        boolean invalidCraftingDelay = this.crafting && storedCountDelay != DEFAULT_WORK_DELAY && storedCountDelay != EXPERIENCE_WORK_DELAY;
        this.countDelay = invalidCraftingDelay ? DEFAULT_WORK_DELAY : storedCountDelay;
        /*
         * The ingredient countdown is intentionally transient. A runtime
         * absorption transaction therefore always restarts after a
         * load instead of resuming without a locked pedestal identity.
         */
        this.itemCount = 0;
        this.ingredientPedestal = null;
        this.ingredientIndex = -1;
        this.ingredientStack = ItemStack.EMPTY;
        this.ingredientRevision = -1L;
        this.ingredientTransaction = 0;
        /*
         * The pedestal list and symmetry are derived from the surroundings and
         * are not persisted either. A load always flags them for a rescan; a
         * stored clean flag would otherwise leave a craft with an empty
         * pedestal cache and no way to select its remaining ingredients.
         */
        this.checkSurroundings = true;
        this.recipeXp = tag.getInt("recipeXp");
        this.craftEssentiaPerPulse = Math.max(0, tag.getInt("craftEssentiaPerPulse"));
        this.craftAbsorptionPulses = dev.tc4port.thaumcraft.util.PortMath.clamp(tag.getInt("craftAbsorptionPulses"), 0, 1000);
        this.craftSymmetryAdjustment = tag.getInt("craftSymmetryAdjustment");
        this.recipeEssentia.clear();
        ListTag essentiaTag = tag.getList("recipeEssentia", net.minecraft.nbt.Tag.TAG_COMPOUND);
        for (int index = 0; index < essentiaTag.size(); index++) {
            CompoundTag entry = essentiaTag.getCompound(index);
            AspectId aspect;
            try {
                aspect = AspectId.parse(entry.getString("aspect"));
            } catch (RuntimeException exception) {
                aspect = null;
            }
            if (aspect != null) {
                this.recipeEssentia.put(aspect, entry.getInt("amount"));
            }
        }
        this.remainingIngredients.clear();
        tag.getList("remainingIngredients", CompoundTag.TAG_INT).forEach(value -> this.remainingIngredients.add(((net.minecraft.nbt.IntTag) value).getAsInt()));
        if (tag.contains("recipeId")) {
            this.recipeId = ResourceLocation.tryParse(tag.getString("recipeId"));
        } else {
            this.recipeId = null;
        }
        String storedFingerprint = tag.getString("recipeFingerprint");
        this.recipeFingerprint = storedFingerprint.matches("[0-9a-f]{64}") ? storedFingerprint : null;
        this.recipeInput = (switch(0) {
            default ->
                {
                    net.minecraft.core.HolderLookup.Provider native$operand$14126 = registries;
                    net.minecraft.nbt.CompoundTag native$operand$14127 = tag.getCompound("recipeInput");
                    net.minecraft.world.item.ItemStack native$result$14128 = (net.minecraft.world.item.ItemStack.of(native$operand$14127));
                    yield native$result$14128;
                }
        });
        this.recipePlayer = tag.contains("recipePlayer") ? tag.getString("recipePlayer") : null;
        if (tag.contains("activePedestal")) {
            this.activePedestal = BlockPos.of(tag.getLong("activePedestal"));
        } else {
            this.activePedestal = null;
        }
        if (invalidCraftingDelay) {
            this.clearCraftingState();
        }
    }

    @Override
    protected void saveAdditional(CompoundTag tag) {
        HolderLookup.Provider registries = persistenceRegistries();
        super.saveAdditional(tag);
        tag.putBoolean("active", this.active);
        tag.putBoolean("crafting", this.crafting);
        tag.putIntArray("pedestalXScanRanks", this.pedestalXScanRanks);
        tag.putIntArray("pedestalZScanRanks", this.pedestalZScanRanks);
        tag.putBoolean("enchantmentRecipe", this.enchantmentRecipe);
        tag.putInt("symmetry", this.symmetry);
        tag.putInt("instability", this.instability);
        tag.putInt("recipeInstability", this.recipeInstability);
        tag.putInt("count", this.count);
        tag.putInt("countDelay", this.countDelay);
        tag.putInt("recipeXp", this.recipeXp);
        tag.putInt("craftEssentiaPerPulse", this.craftEssentiaPerPulse);
        tag.putInt("craftAbsorptionPulses", this.craftAbsorptionPulses);
        tag.putInt("craftSymmetryAdjustment", this.craftSymmetryAdjustment);
        ListTag essentiaTag = new ListTag();
        this.recipeEssentia.forEach((aspect, amount) -> {
            CompoundTag entry = new CompoundTag();
            entry.putString("aspect", aspect.serialized());
            entry.putInt("amount", amount);
            essentiaTag.add(entry);
        });
        tag.put("recipeEssentia", essentiaTag);
        ListTag ingredientTag = new ListTag();
        this.remainingIngredients.forEach(index -> ingredientTag.add(net.minecraft.nbt.IntTag.valueOf(index)));
        tag.put("remainingIngredients", ingredientTag);
        if (this.recipeId != null) {
            tag.putString("recipeId", this.recipeId.toString());
        }
        if (this.recipeFingerprint != null) {
            tag.putString("recipeFingerprint", this.recipeFingerprint);
        }
        if (!this.recipeInput.isEmpty()) {
            tag.put("recipeInput", (switch(0) {
                default ->
                    {
                        net.minecraft.world.item.ItemStack native$operand$13332 = this.recipeInput;
                        net.minecraft.core.HolderLookup.Provider native$operand$13333 = registries;
                        net.minecraft.nbt.Tag native$result$13334 = (native$operand$13332.save(new net.minecraft.nbt.CompoundTag()));
                        yield native$result$13334;
                    }
            }));
        }
        if (this.recipePlayer != null) {
            tag.putString("recipePlayer", this.recipePlayer);
        }
        if (this.activePedestal != null) {
            tag.putLong("activePedestal", this.activePedestal.asLong());
        }
    }

    @Override
    public CompoundTag getUpdateTag() {
        return this.saveWithoutMetadata();
    }

    @Nullable
    @Override
    public Packet<ClientGamePacketListener> getUpdatePacket() {
        return ClientboundBlockEntityDataPacket.create(this);
    }

    private void changedAndSync() {
        this.setChanged();
        BlockEntitySync.sendToClient(this);
    }

    protected final HolderLookup.Provider persistenceRegistries() {
        if (level != null)
            return level.registryAccess();
        var server = net.minecraftforge.server.ServerLifecycleHooks.getCurrentServer();
        return server != null ? server.registryAccess() : net.minecraft.core.RegistryAccess.fromRegistryOfRegistries(net.minecraft.core.registries.BuiltInRegistries.REGISTRY);
    }

    protected static net.minecraft.network.chat.Component parseCustomNameSafe(String value, HolderLookup.Provider registries) {
        try {
            return net.minecraft.network.chat.Component.Serializer.fromJson(value);
        } catch (RuntimeException exception) {
            return null;
        }
    }

    protected void readItemFields(ItemFields.Input input) {
    }

    public void copyItemFields(ItemFields.Output output) {
    }

    public void applyComponentsFromItemStack(ItemStack stack) {
        readItemFields(ItemFields.from(stack));
    }

    public void removeComponentsFromTag(CompoundTag tag) {
    }

    @Override
    public void saveToItem(ItemStack stack) {
        CompoundTag tag = saveWithoutMetadata();
        {
            net.minecraft.nbt.CompoundTag native$bodyOperand$6170 = tag;
            native$bodyReturn$6172: {
                if (true) {
                }
            }
        }
        net.minecraft.world.item.BlockItem.setBlockEntityData(stack, getType(), tag);
        copyItemFields(ItemFields.to(stack));
    }

    @Override
    public net.minecraft.world.phys.AABB getRenderBoundingBox() {
        return InfusionMatrixBlockEntity.native$ClientBlockEntityBounds$bounds(this);
    }

    @Override()
    public void onDataPacket(net.minecraft.network.Connection connection, net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket packet) {
        handleUpdateTag(packet.getTag());
    }

    static private <T extends net.minecraft.world.item.crafting.Recipe<?>, V> V native$RecipeAccess$encode(net.minecraft.world.item.crafting.RecipeSerializer<T> serializer, com.mojang.serialization.DynamicOps<V> ops, T recipe) {
        return InfusionMatrixBlockEntity.native$CodecValues$require(((dev.tc4port.thaumcraft.nativeimpl.NativeRecipeSerializer<T>) serializer).codec().codec().encodeStart(ops, recipe));
    }

    static private java.util.List<net.minecraft.core.BlockPos> native$BlockRegionQueries$blockEntityPositions(net.minecraft.world.level.Level level, net.minecraft.core.BlockPos minimum, net.minecraft.core.BlockPos maximum, boolean loadChunks) {
        java.util.Set<net.minecraft.core.BlockPos> positions = new java.util.HashSet<>();
        int minY = java.lang.Math.max(minimum.getY(), level.getMinBuildHeight());
        int maxY = java.lang.Math.min(maximum.getY(), level.getMaxBuildHeight() - 1);
        if (minY > maxY)
            return new java.util.ArrayList<>();
        for (int x = minimum.getX() >> 4; x <= maximum.getX() >> 4; x++) {
            for (int z = minimum.getZ() >> 4; z <= maximum.getZ() >> 4; z++) {
                net.minecraft.world.level.chunk.LevelChunk chunk = InfusionMatrixBlockEntity.native$BlockRegionQueries$chunk(level, x, z, loadChunks);
                if (chunk == null)
                    continue;
                for (net.minecraft.core.BlockPos pos : chunk.getBlockEntitiesPos()) {
                    if (pos.getX() >= minimum.getX() && pos.getX() <= maximum.getX() && pos.getY() >= minY && pos.getY() <= maxY && pos.getZ() >= minimum.getZ() && pos.getZ() <= maximum.getZ()) {
                        positions.add(pos.immutable());
                    }
                }
                // Level.getBlockEntity also creates missing instances from an
                // EntityBlock state. Pending NBT / live-instance maps alone
                // would miss these positions and change immediate lookup semantics.
                InfusionMatrixBlockEntity.native$BlockRegionQueries$appendMatchingPositions(chunk, minimum, maximum, minY, maxY, net.minecraft.world.level.block.state.BlockState::hasBlockEntity, positions);
            }
        }
        return new java.util.ArrayList<>(positions);
    }

    static private java.util.List<net.minecraft.core.BlockPos> native$BlockRegionQueries$matchingPositions(net.minecraft.world.level.Level level, net.minecraft.core.BlockPos minimum, net.minecraft.core.BlockPos maximum, boolean loadChunks, java.util.function.Predicate<net.minecraft.world.level.block.state.BlockState> predicate) {
        java.util.List<net.minecraft.core.BlockPos> positions = new java.util.ArrayList<>();
        int minY = java.lang.Math.max(minimum.getY(), level.getMinBuildHeight());
        int maxY = java.lang.Math.min(maximum.getY(), level.getMaxBuildHeight() - 1);
        if (minY > maxY)
            return positions;
        for (int cx = minimum.getX() >> 4; cx <= maximum.getX() >> 4; cx++) {
            for (int cz = minimum.getZ() >> 4; cz <= maximum.getZ() >> 4; cz++) {
                net.minecraft.world.level.chunk.LevelChunk chunk = InfusionMatrixBlockEntity.native$BlockRegionQueries$chunk(level, cx, cz, loadChunks);
                if (chunk == null)
                    continue;
                InfusionMatrixBlockEntity.native$BlockRegionQueries$appendMatchingPositions(chunk, minimum, maximum, minY, maxY, predicate, positions);
            }
        }
        return positions;
    }

    static private boolean native$ItemIdentity$matchesRequirements(net.minecraft.world.item.ItemStack actual, net.minecraft.world.item.ItemStack expected, boolean ignoreDamage) {
        net.minecraft.nbt.CompoundTag required = expected.getTag(), present = actual.getTag();
        if (required == null)
            return true;
        for (java.lang.String key : required.getAllKeys()) {
            if (ignoreDamage && key.equals("Damage"))
                continue;
            if (present == null || !java.util.Objects.equals(required.get(key), present.get(key)))
                return false;
        }
        return true;
    }

    @SuppressWarnings({ "rawtypes", "unchecked" })
    static private net.minecraft.world.phys.AABB native$ClientBlockEntityBounds$bounds(net.minecraft.world.level.block.entity.BlockEntity blockEntity) {
        var renderer = net.minecraft.client.Minecraft.getInstance().getBlockEntityRenderDispatcher().getRenderer(blockEntity);
        return renderer instanceof dev.tc4port.thaumcraft.nativeimpl.NativeBlockEntityRenderer shared ? shared.getRenderBoundingBox(blockEntity) : new net.minecraft.world.phys.AABB(blockEntity.getBlockPos());
    }

    private static net.minecraft.world.level.chunk.LevelChunk native$BlockRegionQueries$chunk(net.minecraft.world.level.Level level, int x, int z, boolean loadChunks) {
        if (loadChunks)
            return level.getChunk(x, z);
        if (level.getChunkSource() instanceof net.minecraft.server.level.ServerChunkCache server) {
            return server.getChunkNow(x, z);
        }
        var access = level.getChunkSource().getChunk(x, z, net.minecraft.world.level.chunk.ChunkStatus.FULL, false);
        return access instanceof net.minecraft.world.level.chunk.LevelChunk loaded ? loaded : null;
    }

    private static void native$BlockRegionQueries$appendMatchingPositions(net.minecraft.world.level.chunk.LevelChunk chunk, net.minecraft.core.BlockPos minimum, net.minecraft.core.BlockPos maximum, int minY, int maxY, java.util.function.Predicate<net.minecraft.world.level.block.state.BlockState> predicate, java.util.Collection<net.minecraft.core.BlockPos> positions) {
        int minX = java.lang.Math.max(minimum.getX(), chunk.getPos().getMinBlockX());
        int maxX = java.lang.Math.min(maximum.getX(), chunk.getPos().getMaxBlockX());
        int minZ = java.lang.Math.max(minimum.getZ(), chunk.getPos().getMinBlockZ());
        int maxZ = java.lang.Math.min(maximum.getZ(), chunk.getPos().getMaxBlockZ());
        for (int sy = minY >> 4; sy <= maxY >> 4; sy++) {
            net.minecraft.world.level.chunk.LevelChunkSection section = chunk.getSection(chunk.getSectionIndex(sy << 4));
            if (!section.getStates().maybeHas(predicate))
                continue;
            int sectionMinY = java.lang.Math.max(minY, sy << 4);
            int sectionMaxY = java.lang.Math.min(maxY, (sy << 4) + 15);
            for (int x = minX; x <= maxX; x++) {
                for (int z = minZ; z <= maxZ; z++) {
                    for (int y = sectionMinY; y <= sectionMaxY; y++) {
                        if (predicate.test(section.getBlockState(x & 15, y & 15, z & 15))) {
                            positions.add(new net.minecraft.core.BlockPos(x, y, z));
                        }
                    }
                }
            }
        }
    }

    static private <T> T native$CodecValues$require(com.mojang.serialization.DataResult<T> value) {
        return value.result().orElseThrow(() -> new java.lang.IllegalArgumentException(value.error().orElseThrow().message()));
    }
}
