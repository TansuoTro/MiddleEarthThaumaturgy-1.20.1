package dev.tc4port.thaumcraft.api.client;

/**
 * Public rendering helpers accept the shared WorldRenderContext supplied by client subscriptions.
 */
public final class ThaumcraftClientRenderApi extends ThaumcraftClientRenderApiCommon {

    private ThaumcraftClientRenderApi() {
    }
}
