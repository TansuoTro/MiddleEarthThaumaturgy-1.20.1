package dev.tc4port.thaumcraft.api.research;

import dev.tc4port.thaumcraft.common.ObjectAspectCatalog;
import dev.tc4port.thaumcraft.common.PlayerKnowledgeService;
import java.util.Objects;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;

/**
 * Read-only queries using the exact component-sensitive object scan key.
 */
public final class ScanApi {

    private ScanApi() {
    }

    public static boolean isObjectScanned(Player player, ItemStack stack) {
        Objects.requireNonNull(player, "player");
        Objects.requireNonNull(stack, "stack");
        if (stack.isEmpty()) {
            return false;
        }
        String identity = ObjectAspectCatalog.scanIdentity(stack);
        return PlayerKnowledgeService.get(player).scannedObjects().contains("@" + identity.hashCode());
    }
}
