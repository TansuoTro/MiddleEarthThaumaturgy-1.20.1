package dev.tc4port.thaumcraft.api.entity;

import dev.tc4port.thaumcraft.entity.TaintConvertGrassGoal;
import dev.tc4port.thaumcraft.entity.TaintedEntityEffects;
import dev.tc4port.thaumcraft.entity.TargetedMeleeAttackGoal;
import dev.tc4port.thaumcraft.registry.TCSounds;
import dev.tc4port.thaumcraft.nativeimpl.PathTypes;
import dev.tc4port.thaumcraft.api.entity.TaintedMob;
import javax.annotation.Nullable;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.world.DifficultyInstance;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.SpawnGroupData;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.animal.Sheep;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.npc.Villager;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.DyeColor;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.ServerLevelAccessor;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.level.storage.loot.LootTable;
import dev.tc4port.thaumcraft.nativeimpl.EntityGeometry;
import dev.tc4port.thaumcraft.nativeimpl.LootTables;

/**
 * Extensible tainted sheep with the core's combat, sounds, particles, shearing and loot.
 * Subclasses may replace grazing and wool regrowth without reimplementing the mob.
 */
public class TaintSheep extends net.minecraft.world.entity.animal.Sheep implements Enemy, TaintedMob {

    private int nativeLooting;

    private net.minecraft.nbt.CompoundTag nativeSpawnTag;

    private net.minecraft.world.entity.player.Player leashPlayer;

    public TaintSheep(EntityType<? extends net.minecraft.world.entity.animal.Sheep> entityType, Level level) {
        this(entityType, level, entityType, level, true);
    }

    /**
     * Called during construction; overrides must not depend on subclass field initialization.
     */
    protected net.minecraft.world.entity.ai.goal.Goal createGrazingGoal() {
        return new TaintConvertGrassGoal(this, this::canSpreadTaint);
    }

    /**
     * Checked before the conversion goal removes vegetation or changes blocks/biomes.
     */
    protected boolean canSpreadTaint() {
        return true;
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Sheep.createAttributes().add(Attributes.MAX_HEALTH, 20.0).add(Attributes.ATTACK_DAMAGE, 3.0).add(Attributes.MOVEMENT_SPEED, 0.25).add(Attributes.ARMOR, 1.0);
    }

    @Override
    public void tick() {
        super.tick();
        TaintedEntityEffects.tickBirthParticles(this);
    }

    @Override
    public InteractionResult mobInteract(Player player, InteractionHand hand) {
        /*
         * Shearing is provided by NeoForge's Shearable item interaction.
         * Returning PASS prevents dyeing/feeding while leaving shears intact.
         */
        return InteractionResult.PASS;
    }

    /**
     * Sheep normally redirects an unsheared sheep to a color-specific vanilla
     * loot table. TC4 tainted sheep always used their taint-material table.
     */
    public ResourceKey<LootTable> sharedLootTable() {
        return dev.tc4port.thaumcraft.nativeimpl.LootTables.entityDefault(dev.tc4port.thaumcraft.registry.TCEntities.TAINTED_SHEEP.get());
    }

    @Override
    public boolean removeWhenFarAway(double distanceToClosestPlayer) {
        return false;
    }

    @Override
    public ItemEntity spawnAtLocation(ItemStack stack) {
        return super.spawnAtLocation(stack, this.getBbHeight() / 2.0F);
    }

    @Override
    public float getVoicePitch() {
        return 0.7F;
    }

    @Override
    public void ate() {
        // EntityTaintSheep extended EntityMob; eatGrassBonus was a no-op, so
        // its conversion goal never regrew sheared wool.
    }

    @Nullable
    public SpawnGroupData finalizeSharedSpawn(ServerLevelAccessor level, DifficultyInstance difficulty, MobSpawnType spawnType, @Nullable SpawnGroupData spawnGroupData) {
        SpawnGroupData result = (switch(0) {
            default ->
                {
                    net.minecraft.world.level.ServerLevelAccessor native$bodyOperand$4006 = level;
                    net.minecraft.world.DifficultyInstance native$bodyOperand$4007 = difficulty;
                    net.minecraft.world.entity.MobSpawnType native$bodyOperand$4008 = spawnType;
                    net.minecraft.world.entity.SpawnGroupData native$bodyOperand$4009 = spawnGroupData;
                    net.minecraft.world.entity.SpawnGroupData native$bodyResult$4010 = null;
                    native$bodyReturn$4011: {
                        if (true) {
                            {
                                native$bodyResult$4010 = super.finalizeSpawn(native$bodyOperand$4006, native$bodyOperand$4007, native$bodyOperand$4008, native$bodyOperand$4009, nativeSpawnTag);
                                break native$bodyReturn$4011;
                            }
                        }
                    }
                    yield native$bodyResult$4010;
                }
        });
        this.setColor(DyeColor.PURPLE);
        return result;
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        this.setColor(DyeColor.PURPLE);
    }

    @Override
    protected SoundEvent getHurtSound(DamageSource source) {
        return TCSounds.TAINT_SHEEP_HURT.get();
    }

    @Override
    protected SoundEvent getDeathSound() {
        return TCSounds.TAINT_SHEEP_DEATH.get();
    }

    private TaintSheep(net.minecraft.world.entity.EntityType<? extends net.minecraft.world.entity.animal.Sheep> native$NativeSheep$arg0, net.minecraft.world.level.Level native$NativeSheep$arg1, EntityType<? extends net.minecraft.world.entity.animal.Sheep> entityType, Level level, boolean native$NativeSheep$captured) {
        super(native$NativeSheep$arg0, native$NativeSheep$arg1);
        this.setPathfindingMalus(PathTypes.WATER, -1.0F);
        /*
         * Sheep.customServerAiStep retains a private reference to vanilla's
         * EatBlockGoal, but that reference is only used to mirror its
         * animation timer. TaintConvertGrassGoal sends the same entity event
         * directly and preserves TC4's different block-conversion behavior.
         */
        this.goalSelector.removeAllGoals(goal -> true);
        if (!level.isClientSide) {
            this.goalSelector.addGoal(2, this.createGrazingGoal());
        }
        this.targetSelector.removeAllGoals(goal -> true);
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(3, new TargetedMeleeAttackGoal(this, Player.class, 1.0, false));
        this.goalSelector.addGoal(3, new TargetedMeleeAttackGoal(this, Villager.class, 1.0, true));
        this.goalSelector.addGoal(6, new WaterAvoidingRandomStrollGoal(this, 1.0));
        this.goalSelector.addGoal(7, new LookAtPlayerGoal(this, Player.class, 6.0F));
        this.goalSelector.addGoal(8, new RandomLookAroundGoal(this));
        this.targetSelector.addGoal(0, new HurtByTargetGoal(this));
        this.targetSelector.addGoal(3, new NearestAttackableTargetGoal<>(this, Player.class, true));
        this.targetSelector.addGoal(3, new NearestAttackableTargetGoal<>(this, Villager.class, 10, false, false, target -> !(target instanceof TaintedMob)));
        /*
         * TC4 always sheared purple wool (legacy wool metadata 10), regardless
         * of the sheep it replaced.
         */
        this.setColor(DyeColor.PURPLE);
    }

    protected void dropSharedDeathLoot(net.minecraft.server.level.ServerLevel level, net.minecraft.world.damagesource.DamageSource source, boolean hit) {
        super.dropCustomDeathLoot(source, nativeLooting, hit);
    }

    @Override
    protected void dropCustomDeathLoot(net.minecraft.world.damagesource.DamageSource source, int looting, boolean hit) {
        int previous = nativeLooting;
        nativeLooting = looting;
        try {
            dropSharedDeathLoot((net.minecraft.server.level.ServerLevel) level(), source, hit);
        } finally {
            nativeLooting = previous;
        }
    }

    protected void dropAllDeathLoot(net.minecraft.world.damagesource.DamageSource native$callbackInput$1111) {
        net.minecraft.server.level.ServerLevel level = (net.minecraft.server.level.ServerLevel) level();
        net.minecraft.world.damagesource.DamageSource source = native$callbackInput$1111;
        super.dropAllDeathLoot(source);
    }

    @Override
    public net.minecraft.world.entity.SpawnGroupData finalizeSpawn(net.minecraft.world.level.ServerLevelAccessor level, net.minecraft.world.DifficultyInstance difficulty, net.minecraft.world.entity.MobSpawnType reason, net.minecraft.world.entity.SpawnGroupData data, net.minecraft.nbt.CompoundTag tag) {
        var previous = nativeSpawnTag;
        nativeSpawnTag = tag;
        try {
            return finalizeSharedSpawn(level, difficulty, reason, data);
        } finally {
            nativeSpawnTag = previous;
        }
    }

    @Override
    protected float getStandingEyeHeight(net.minecraft.world.entity.Pose pose, net.minecraft.world.entity.EntityDimensions dimensions) {
        return EntityGeometry.eye(this, dimensions, super.getStandingEyeHeight(pose, dimensions));
    }

    @Override
    public double getPassengersRidingOffset() {
        return EntityGeometry.passenger(this, super.getPassengersRidingOffset());
    }

    public net.minecraft.world.phys.Vec3 vehicleAttachment(net.minecraft.world.entity.Entity vehicle) {
        return new net.minecraft.world.phys.Vec3(0, -EntityGeometry.riding(this, super.getMyRidingOffset()), 0);
    }

    @Override
    public double getMyRidingOffset() {
        return -vehicleAttachment(getVehicle()).y;
    }

    public boolean sharedCanBeLeashed() {
        return super.canBeLeashed(leashPlayer);
    }

    @Override
    public boolean canBeLeashed(net.minecraft.world.entity.player.Player player) {
        leashPlayer = player;
        return sharedCanBeLeashed();
    }

    public net.minecraft.core.RegistryAccess registryAccess() {
        return level().registryAccess();
    }

    @Override
    public net.minecraft.resources.ResourceLocation getDefaultLootTable() {
        return sharedLootTable().location();
    }

    protected void dropFromLootTable(net.minecraft.world.damagesource.DamageSource native$callbackInput$1112, boolean native$callbackInput$1113) {
        net.minecraft.server.level.ServerLevel level = (net.minecraft.server.level.ServerLevel) level();
        net.minecraft.world.damagesource.DamageSource source = native$callbackInput$1112;
        boolean hit = native$callbackInput$1113;
        super.dropFromLootTable(source, hit);
    }
}
