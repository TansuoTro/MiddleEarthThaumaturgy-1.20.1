package dev.tc4port.thaumcraft.api.recipe;

import net.minecraft.core.HolderLookup;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.item.ItemStack;

/**
 * Stable-id addon operation for one peripheral infusion component, the
 * pedestal counterpart of {@link InfusionCentralTransformation}.
 *
 * <p>A recipe selects it per component with
 * {@code "component_operations": {"<index>": {"component_transformation": "<id>"}}}.
 * Every input is a defensive copy. The result returns to the source pedestal
 * when that component's absorption commits; an empty result consumes the
 * input. The registration must remain active for as long as a recipe
 * referring to its id may be selected or completed.</p>
 */
public interface InfusionComponentTransformation {

    /**
     * Applies addon-specific eligibility beyond the recipe ingredient; deterministic.
     */
    default boolean matches(ItemStack componentInput) {
        return true;
    }

    /**
     * The deterministic post-use result, used by previews and
     * {@link InfusionComponentOperations#componentRemainder}. Empty means consumed.
     */
    ItemStack preview(ItemStack componentInput, HolderLookup.Provider registries);

    /**
     * Produces the post-use result exactly once, when the component's
     * absorption commits on the server. Random outcomes such as chance-based
     * returns belong here; empty consumes the input. Do not mutate the world
     * or retain arguments.
     */
    default ItemStack transformOnCompletion(ItemStack componentInput, ServerLevel level) {
        return preview(componentInput, level.registryAccess());
    }
}
