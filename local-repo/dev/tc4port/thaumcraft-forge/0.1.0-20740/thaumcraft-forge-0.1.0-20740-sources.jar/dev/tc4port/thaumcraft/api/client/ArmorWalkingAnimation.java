package dev.tc4port.thaumcraft.api.client;

import java.util.Map;
import java.util.WeakHashMap;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.world.entity.LivingEntity;
import net.minecraftforge.client.event.RenderLivingEvent;
import net.minecraftforge.common.MinecraftForge;

/**
 * Actual per-entity render interpolation, including inventory/GUI renders. Client thread only.
 */
public final class ArmorWalkingAnimation {

    private static final Map<LivingEntity, Float> PARTIAL_TICKS = new WeakHashMap<>();

    private static boolean registered;

    private ArmorWalkingAnimation() {
    }

    public static void register() {
        if (registered)
            return;
        registered = true;
        MinecraftForge.EVENT_BUS.addListener(ArmorWalkingAnimation::beforeRender);
    }

    private static void beforeRender(RenderLivingEvent.Pre<?, ?> event) {
        // A cancelled render needs no pop/cleanup. The next render replaces its interpolation,
        // and the weak key never retains an unloaded entity.
        PARTIAL_TICKS.put(event.getEntity(), event.getPartialTick());
    }

    public static float swing(LivingEntity entity, HumanoidModel<?> original) {
        if (original.riding || !entity.isAlive())
            return 0;
        float swing = entity.walkAnimation.position(PARTIAL_TICKS.getOrDefault(entity, 0F));
        return entity.isBaby() ? swing * 3F : swing;
    }

    public static float amount(LivingEntity entity, HumanoidModel<?> original) {
        if (original.riding || !entity.isAlive())
            return 0;
        return Math.min(entity.walkAnimation.speed(PARTIAL_TICKS.getOrDefault(entity, 0F)), 1F);
    }
}
