package dev.tc4port.thaumcraft.block.entity;

import dev.tc4port.thaumcraft.nativeimpl.NativeFluidTank;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.Tag;

/**
 * Canonical bounded component-aware persistence for block fluid tanks.
 */
final class FluidTankStorage {

    private static final String FLUID_KEY = "Fluid";

    private FluidTankStorage() {
    }

    static void load(NativeFluidTank tank, CompoundTag owner, String key, HolderLookup.Provider registries) {
        CompoundTag storedTag = owner.getCompound(key);
        net.minecraftforge.fluids.FluidStack stored = storedTag.contains(FLUID_KEY, Tag.TAG_COMPOUND) ? (switch(0) {
            default ->
                {
                    net.minecraft.core.HolderLookup.Provider native$operand$13329 = registries;
                    net.minecraft.nbt.CompoundTag native$operand$13330 = storedTag.getCompound(FLUID_KEY);
                    net.minecraftforge.fluids.FluidStack native$result$13331 = (net.minecraftforge.fluids.FluidStack.loadFluidStackFromNBT(native$operand$13330));
                    yield native$result$13331;
                }
        }) : net.minecraftforge.fluids.FluidStack.EMPTY;
        setValidated(tank, stored);
    }

    static void setValidated(NativeFluidTank tank, net.minecraftforge.fluids.FluidStack stored) {
        if (stored.isEmpty() || !tank.isFluidValid(stored)) {
            tank.setFluid(net.minecraftforge.fluids.FluidStack.EMPTY);
            return;
        }
        tank.setFluid(FluidTankStorage.native$NativeFluidFunctions$copyWithAmount(stored, Math.min(1_000_000, stored.getAmount())));
    }

    static void save(NativeFluidTank tank, CompoundTag owner, String key, HolderLookup.Provider registries) {
        owner.put(key, FluidTankStorage.native$NativeFluidFunctions$saveTank(tank, registries, new CompoundTag()));
    }

    static private net.minecraftforge.fluids.FluidStack native$NativeFluidFunctions$copyWithAmount(net.minecraftforge.fluids.FluidStack stack, int amount) {
        var copy = stack.copy();
        copy.setAmount(amount);
        return copy;
    }

    static private net.minecraft.nbt.CompoundTag native$NativeFluidFunctions$saveTank(net.minecraftforge.fluids.capability.templates.FluidTank tank, net.minecraft.core.HolderLookup.Provider registries, net.minecraft.nbt.CompoundTag tag) {
        tag.put("Fluid", (switch(0) {
            default ->
                {
                    net.minecraftforge.fluids.FluidStack native$operand$16632 = tank.getFluid();
                    net.minecraft.core.HolderLookup.Provider native$operand$16633 = registries;
                    net.minecraft.nbt.Tag native$result$16634 = (native$operand$16632.isEmpty() ? new net.minecraft.nbt.CompoundTag() : (switch(0) {
                        default ->
                            {
                                net.minecraftforge.fluids.FluidStack native$operand$16731 = native$operand$16632;
                                net.minecraft.core.HolderLookup.Provider native$operand$16732 = native$operand$16633;
                                net.minecraft.nbt.Tag native$result$16733 = (native$operand$16731.writeToNBT(new net.minecraft.nbt.CompoundTag()));
                                yield native$result$16733;
                            }
                    }));
                    yield native$result$16634;
                }
        }));
        return tag;
    }
}
