package dev.tc4port.thaumcraft.api.entity;

import dev.tc4port.thaumcraft.api.aspect.AspectApi;
import dev.tc4port.thaumcraft.api.aspect.AspectId;
import dev.tc4port.thaumcraft.entity.AspectOrbEntity;
import java.util.Objects;
import java.util.Optional;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.Vec3;

/**
 * Controlled public factory for collectable aspect-orb entities.
 */
public final class AspectOrbApi {

    /**
     * Largest value preserved by TC4's stable short-backed orb save field.
     */
    public static final int MAX_VALUE = Short.MAX_VALUE;

    private AspectOrbApi() {
    }

    /**
     * Spawns one aspect orb with an explicit aspect and positive whole-vis
     * value. Invalid identities, non-finite coordinates, off-thread calls and
     * unloaded or out-of-bounds positions fail without creating an entity.
     *
     * <p>The concrete Thaumcraft entity type remains an implementation detail;
     * callers receive the vanilla entity contract.</p>
     */
    public static Optional<Entity> spawn(ServerLevel level, Vec3 position, AspectId aspect, int value) {
        Objects.requireNonNull(level, "level");
        Objects.requireNonNull(position, "position");
        Objects.requireNonNull(aspect, "aspect");
        BlockPos blockPos = BlockPos.containing(position);
        if (!level.getServer().isSameThread() || value <= 0 || value > MAX_VALUE || !Double.isFinite(position.x) || !Double.isFinite(position.y) || !Double.isFinite(position.z) || AspectApi.registry().get(aspect).isEmpty() || !level.hasChunkAt(blockPos) || level.isOutsideBuildHeight(blockPos) || !level.getWorldBorder().isWithinBounds(blockPos)) {
            return Optional.empty();
        }
        return AspectOrbEntity.spawn(level, position, aspect, value).map(orb -> (Entity) orb);
    }
}
