package dev.tc4port.thaumcraft.api.item;

import dev.tc4port.thaumcraft.nativeimpl.AttributeModifiers;
import dev.tc4port.thaumcraft.api.event.AttributeOperation;
import dev.tc4port.thaumcraft.api.item.ToolProperties;
import net.minecraft.world.item.*;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.network.chat.Component;

public final class ItemProperties {

    private ItemProperties() {
    }

    private static final java.util.Set<Item.Properties> UNBREAKABLE_PROPERTIES = java.util.Collections.newSetFromMap(new java.util.WeakHashMap<>());

    private static final java.util.Set<Item> UNBREAKABLE_ITEMS = java.util.Collections.newSetFromMap(new java.util.IdentityHashMap<>());

    private static final java.util.Map<Item.Properties, net.minecraft.world.entity.ai.attributes.AttributeModifier> MOVEMENT = new java.util.WeakHashMap<>();

    public static Component customName(ItemStack stack) {
        return stack.hasCustomHoverName() ? stack.getHoverName() : null;
    }

    public static synchronized Item.Properties unbreakable(Item.Properties props) {
        UNBREAKABLE_PROPERTIES.add(props);
        return props;
    }

    public static synchronized void bind(Item item, Item.Properties props) {
        if (UNBREAKABLE_PROPERTIES.contains(props))
            UNBREAKABLE_ITEMS.add(item);
    }

    public static synchronized void initialize(ItemStack stack) {
        if (!stack.isEmpty() && UNBREAKABLE_ITEMS.contains(stack.getItem())) {
            var tag = stack.getOrCreateTag();
            if (!tag.contains("Unbreakable")) {
                tag.putBoolean("Unbreakable", true);
                tag.putInt("HideFlags", tag.getInt("HideFlags") | 4);
            }
        }
    }

    public static synchronized Item.Properties movementTool(Item.Properties props, Tier tier, float damage, float speed, ResourceLocation id, double bonus) {
        MOVEMENT.put(props, dev.tc4port.thaumcraft.nativeimpl.AttributeModifiers.create(id, bonus, dev.tc4port.thaumcraft.api.event.AttributeOperation.ADD_MULTIPLIED_BASE));
        return dev.tc4port.thaumcraft.api.item.ToolProperties.apply(props, tier, damage, speed);
    }

    public static synchronized com.google.common.collect.Multimap<net.minecraft.world.entity.ai.attributes.Attribute, net.minecraft.world.entity.ai.attributes.AttributeModifier> attributes(Item.Properties props, com.google.common.collect.Multimap<net.minecraft.world.entity.ai.attributes.Attribute, net.minecraft.world.entity.ai.attributes.AttributeModifier> base) {
        var result = com.google.common.collect.ImmutableMultimap.<net.minecraft.world.entity.ai.attributes.Attribute, net.minecraft.world.entity.ai.attributes.AttributeModifier>builder().putAll(base);
        var movement = MOVEMENT.get(props);
        if (movement != null)
            result.put(net.minecraft.world.entity.ai.attributes.Attributes.MOVEMENT_SPEED, movement);
        return result.build();
    }

    public static Item.Properties container(Item.Properties props) {
        return props;
    }

    public static int hashItemAndData(ItemStack stack) {
        return stack.isEmpty() ? 0 : 31 * stack.getItem().hashCode() + java.util.Objects.hashCode(stack.getTag());
    }

    public static net.minecraft.world.level.block.state.BlockState blockState(ItemStack stack, net.minecraft.world.level.block.state.BlockState state) {
        var tag = stack.getTagElement("BlockStateTag");
        if (tag != null)
            for (String name : tag.getAllKeys()) {
                var property = state.getBlock().getStateDefinition().getProperty(name);
                if (property != null)
                    state = property(state, property, tag.getString(name));
            }
        return state;
    }

    private static <T extends Comparable<T>> net.minecraft.world.level.block.state.BlockState property(net.minecraft.world.level.block.state.BlockState state, net.minecraft.world.level.block.state.properties.Property<T> property, String value) {
        return property.getValue(value).map(parsed -> state.setValue(property, parsed)).orElse(state);
    }
}
