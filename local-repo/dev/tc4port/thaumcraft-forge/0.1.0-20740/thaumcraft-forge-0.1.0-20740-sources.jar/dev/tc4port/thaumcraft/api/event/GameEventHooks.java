package dev.tc4port.thaumcraft.api.event;

import dev.tc4port.thaumcraft.api.client.ArmorReduction;
import dev.tc4port.thaumcraft.api.event.Damage;
import java.util.function.Consumer;

/**
 * Shared ownership of Forge's early damage and armor hooks; registration functions have no state.
 */
public final class GameEventHooks {

    private GameEventHooks() {
    }

    private static final java.util.List<Consumer<Damage>> DAMAGE = new java.util.concurrent.CopyOnWriteArrayList<>();

    public static void incomingDamage(Consumer<Damage> callback) {
        DAMAGE.add(callback);
    }

    public static float incomingDamage(net.minecraft.world.entity.LivingEntity entity, net.minecraft.world.damagesource.DamageSource source, float amount) {
        float[] value = { amount };
        var event = new Damage(entity, source, () -> value[0], v -> value[0] = v, cancel -> {
            if (cancel)
                value[0] = 0;
        });
        for (var callback : DAMAGE) callback.accept(event);
        return event.getAmount();
    }

    private static final java.util.List<java.util.function.BiFunction<net.minecraft.world.entity.LivingEntity, net.minecraft.world.damagesource.DamageSource, ArmorReduction>> ARMOR_REDUCTIONS = new java.util.concurrent.CopyOnWriteArrayList<>();

    /**
     * Prepare an armor-phase modifier; return null when this listener does not apply.
     */
    public static void armorReduction(java.util.function.BiFunction<net.minecraft.world.entity.LivingEntity, net.minecraft.world.damagesource.DamageSource, ArmorReduction> callback) {
        ARMOR_REDUCTIONS.add(callback);
    }

    public static float applyArmorReduction(net.minecraft.world.entity.LivingEntity entity, net.minecraft.world.damagesource.DamageSource source, float incoming, float reduction) {
        if (entity.level().isClientSide())
            return reduction;
        for (var callback : ARMOR_REDUCTIONS) {
            ArmorReduction modifier = callback.apply(entity, source);
            if (modifier != null)
                reduction = modifier.apply(source, incoming, reduction);
        }
        return reduction;
    }
}
