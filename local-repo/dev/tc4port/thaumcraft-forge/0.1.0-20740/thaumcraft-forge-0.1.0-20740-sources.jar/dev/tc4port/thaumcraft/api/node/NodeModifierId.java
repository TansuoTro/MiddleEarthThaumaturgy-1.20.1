package dev.tc4port.thaumcraft.api.node;

import com.mojang.serialization.Codec;
import com.mojang.serialization.DataResult;
import java.util.Objects;
import net.minecraft.resources.ResourceLocation;

/**
 * Stable identity of one aura-node modifier.
 */
public record NodeModifierId(ResourceLocation value) implements Comparable<NodeModifierId> {

    public static final NodeModifierId NONE = parse("none");

    public static final NodeModifierId BRIGHT = parse("bright");

    public static final NodeModifierId PALE = parse("pale");

    public static final NodeModifierId FADING = parse("fading");

    public static final Codec<NodeModifierId> CODEC = Codec.STRING.comapFlatMap(NodeModifierId::decode, NodeModifierId::toString);

    public NodeModifierId {
        value = Objects.requireNonNull(value, "value");
        if (value.toString().length() > 256) {
            throw new IllegalArgumentException("Node modifier ID is longer than 256 characters: " + value);
        }
    }

    public static NodeModifierId of(ResourceLocation value) {
        return new NodeModifierId(value);
    }

    /**
     * Parses a compact built-in key or a namespaced stable identity.
     */
    public static NodeModifierId parse(String value) {
        Objects.requireNonNull(value, "value");
        ResourceLocation parsed = value.indexOf(':') < 0 ? ResourceLocation.tryBuild("thaumcraft", value) : ResourceLocation.tryParse(value);
        if (parsed == null) {
            throw new IllegalArgumentException("Invalid node modifier ID: " + value);
        }
        return new NodeModifierId(parsed);
    }

    private static DataResult<NodeModifierId> decode(String value) {
        try {
            return DataResult.success(parse(value));
        } catch (RuntimeException exception) {
            return DataResult.error(() -> "Invalid node modifier ID '" + value + "': " + exception.getMessage());
        }
    }

    /**
     * Current compact spelling for built-ins; addon identities stay namespaced.
     */
    public String serialized() {
        return this.value.getNamespace().equals("thaumcraft") ? this.value.getPath() : this.value.toString();
    }

    @Override
    public int compareTo(NodeModifierId other) {
        return this.value.compareTo(other.value);
    }

    @Override
    public String toString() {
        return this.value.toString();
    }
}
