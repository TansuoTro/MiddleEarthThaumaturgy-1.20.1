package dev.tc4port.thaumcraft.api.research;

import java.util.Map;
import java.util.Objects;

/**
 * An unchanged translation and the semantic boundary preceding it.
 */
public record ResearchTextFragment(String key, Join join, Map<String, Join> localeJoins) {

    public ResearchTextFragment {
        Objects.requireNonNull(key, "key");
        Objects.requireNonNull(join, "join");
        localeJoins = Map.copyOf(localeJoins);
        if (key.isBlank() || key.length() > 256 || localeJoins.size() > 128) {
            throw new IllegalArgumentException("Invalid research text fragment");
        }
        for (String locale : localeJoins.keySet()) {
            if (!locale.matches("[a-z]{2,3}_[a-z0-9]{2,4}")) {
                throw new IllegalArgumentException("Invalid research text locale: " + locale);
            }
        }
    }

    public ResearchTextFragment(String key, Join join) {
        this(key, join, Map.of());
    }

    public Join joinFor(String locale) {
        return localeJoins.getOrDefault(locale, join);
    }

    public enum Join {

        /**
         * First fragment, or an intentional literal adjacency.
         */
        NONE,
        /**
         * Continue a sentence, supplying a space only when its script needs one.
         */
        CONTINUE,
        /**
         * Start a new paragraph without fixing its physical page.
         */
        PARAGRAPH,
        /**
         * Start the next line without a blank line between the fragments.
         */
        LINE_BREAK
    }
}
