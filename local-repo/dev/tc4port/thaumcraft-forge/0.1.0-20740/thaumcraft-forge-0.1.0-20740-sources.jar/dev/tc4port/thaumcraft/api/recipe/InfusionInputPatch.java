package dev.tc4port.thaumcraft.api.recipe;

import net.minecraft.core.HolderLookup;
import net.minecraft.world.item.ItemStack;

/**
 * Addon-owned mutation applied to a copied central or peripheral infusion stack.
 *
 * <p>The recipe value is intentionally a bounded integer so the operation
 * remains deterministic in data packs and over recipe synchronization. The
 * implementation must only mutate {@code output}; it must not retain either
 * argument or perform world side effects.</p>
 */
public interface InfusionInputPatch {

    /**
     * Validates one decoded recipe value and its fixed pedestal count.
     * Implementations should throw {@link IllegalArgumentException} when the
     * definition is invalid.
     */
    void validate(int value, int componentCount);

    /**
     * Applies the already validated value to the copied input stack.
     */
    void apply(ItemStack output, int value, HolderLookup.Provider registries);
}
