package dev.tc4port.thaumcraft.api.client;

import com.mojang.blaze3d.vertex.PoseStack;
import org.joml.Matrix3f;
import org.joml.Matrix4f;
import org.joml.Vector3f;

/**
 * Forge carries the world view in vertex poses; shared effects use camera-relative poses.
 */
public final class WorldRenderTransforms {

    private static final Matrix4f VIEW = new Matrix4f();

    private static final Matrix4f INVERSE_VIEW = new Matrix4f();

    private static final Matrix3f VIEW_NORMAL = new Matrix3f();

    private static final Matrix3f INVERSE_VIEW_NORMAL = new Matrix3f();

    private static final Matrix4f MODEL_VIEW = new Matrix4f();

    private WorldRenderTransforms() {
    }

    /**
     * Capture the actual LevelRenderer input before any object transform is applied.
     */
    public static void capture(PoseStack.Pose worldPose, Matrix4f modelView) {
        VIEW.set(worldPose.pose());
        INVERSE_VIEW.set(VIEW).invert();
        VIEW_NORMAL.set(worldPose.normal());
        INVERSE_VIEW_NORMAL.set(VIEW_NORMAL).invert();
        MODEL_VIEW.set(modelView).mul(VIEW);
    }

    public static Matrix4f modelViewMatrix() {
        return new Matrix4f(MODEL_VIEW);
    }

    public static Vector3f cameraRelativeLight(Vector3f nativeLight) {
        return INVERSE_VIEW_NORMAL.transform(new Vector3f(nativeLight));
    }

    /**
     * Detach a native BER pose for replay under the shared world view, including its normal.
     */
    public static PoseStack.Pose cameraRelativePose(PoseStack.Pose nativePose) {
        PoseStack copy = new PoseStack();
        cameraRelativePose(nativePose, copy.last());
        return copy.last();
    }

    /**
     * Update a retained render pose without allocating a snapshot each frame.
     */
    public static void cameraRelativePose(PoseStack.Pose nativePose, PoseStack.Pose target) {
        target.pose().set(nativePose.pose()).mulLocal(INVERSE_VIEW);
        target.normal().set(nativePose.normal()).mulLocal(INVERSE_VIEW_NORMAL);
    }

    /**
     * Remove a host's transform while retaining the native view for a directly drawn billboard.
     */
    public static void resetWorldPose(PoseStack stack) {
        stack.last().pose().set(VIEW);
        stack.last().normal().set(VIEW_NORMAL);
    }
}
