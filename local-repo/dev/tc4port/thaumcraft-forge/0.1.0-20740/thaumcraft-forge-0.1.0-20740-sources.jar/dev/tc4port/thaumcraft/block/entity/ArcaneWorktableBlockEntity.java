package dev.tc4port.thaumcraft.block.entity;

import dev.tc4port.thaumcraft.api.wand.WandCarrierItem;
import dev.tc4port.thaumcraft.menu.ArcaneWorktableMenu;
import dev.tc4port.thaumcraft.registry.TCBlockEntities;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.HolderLookup;
import net.minecraft.core.NonNullList;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket;
import net.minecraft.network.chat.Component;
import net.minecraft.world.ContainerListener;
import net.minecraft.world.WorldlyContainer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.entity.BaseContainerBlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityType;

/**
 * Persistent eleven-slot layout from TileMagicWorkbench:
 * 0..8 grid, 9 result, 10 wand.
 */
public final class ArcaneWorktableBlockEntity extends net.minecraft.world.level.block.entity.BaseContainerBlockEntity implements WorldlyContainer {

    public static final int GRID_SIZE = 9;

    public static final int RESULT_SLOT = 9;

    public static final int WAND_SLOT = 10;

    public static final int CONTAINER_SIZE = 11;

    private static final int[] AUTOMATION_SLOTS = { WAND_SLOT };

    private final NonNullList<ItemStack> items = NonNullList.withSize(CONTAINER_SIZE, ItemStack.EMPTY);

    private final List<ContainerListener> listeners = new ArrayList<>();

    public ArcaneWorktableBlockEntity(BlockPos pos, BlockState state) {
        super(TCBlockEntities.ARCANE_WORKTABLE.get(), pos, state);
    }

    public void addContentListener(ContainerListener listener) {
        this.listeners.add(listener);
    }

    public void removeContentListener(ContainerListener listener) {
        this.listeners.remove(listener);
    }

    /**
     * Result updates must not recursively trigger another recipe search.
     */
    public void setResultSoftly(ItemStack result) {
        this.items.set(RESULT_SLOT, result);
        super.setChanged();
    }

    /**
     * Native crafting containers share these nine persistent material slots.
     */
    public NonNullList<ItemStack> craftingItems() {
        return new NonNullList<ItemStack>(this.items.subList(0, GRID_SIZE), ItemStack.EMPTY) {
        };
    }

    @Override
    public void setChanged() {
        super.setChanged();
        if (this.level != null && !this.level.isClientSide) {
            this.level.sendBlockUpdated(this.worldPosition, this.getBlockState(), this.getBlockState(), Block.UPDATE_CLIENTS);
        }
        for (ContainerListener listener : List.copyOf(this.listeners)) {
            listener.containerChanged(this);
        }
    }

    @Override
    public int getContainerSize() {
        return CONTAINER_SIZE;
    }

    @Override
    protected Component getDefaultName() {
        return Component.translatable("container.thaumcraft.arcane_worktable");
    }

    @Override
    public void load(CompoundTag tag) {
        HolderLookup.Provider registries = persistenceRegistries();
        super.load(tag);
        this.items.clear();
        {
            net.minecraft.nbt.CompoundTag native$operand$14342 = tag;
            net.minecraft.core.NonNullList<net.minecraft.world.item.ItemStack> native$operand$14343 = this.items;
            net.minecraft.core.HolderLookup.Provider native$operand$14344 = registries;
            net.minecraft.world.ContainerHelper.loadAllItems(native$operand$14342, native$operand$14343);
        }
    }

    @Override
    protected void saveAdditional(CompoundTag tag) {
        HolderLookup.Provider registries = persistenceRegistries();
        super.saveAdditional(tag);
        {
            net.minecraft.nbt.CompoundTag native$operand$14345 = tag;
            net.minecraft.core.NonNullList<net.minecraft.world.item.ItemStack> native$operand$14346 = this.items;
            net.minecraft.core.HolderLookup.Provider native$operand$14347 = registries;
            net.minecraft.nbt.CompoundTag native$result$14348 = (net.minecraft.world.ContainerHelper.saveAllItems(native$operand$14345, native$operand$14346));
        }
    }

    @Override
    public CompoundTag getUpdateTag() {
        return this.saveWithoutMetadata();
    }

    @Override
    public Packet<ClientGamePacketListener> getUpdatePacket() {
        return ClientboundBlockEntityDataPacket.create(this);
    }

    protected NonNullList<ItemStack> getItems() {
        return this.items;
    }

    protected void setItems(NonNullList<ItemStack> items) {
        for (int slot = 0; slot < CONTAINER_SIZE; slot++) {
            this.items.set(slot, items.get(slot));
        }
    }

    @Override
    public boolean canPlaceItem(int slot, ItemStack stack) {
        if (slot != WAND_SLOT) {
            /*
             * TileMagicWorkbench accepted direct insertion into every
             * non-wand index, including its derived result index. The GUI
             * result Slot still rejects player placement and sided exposure
             * remains wand-only, so retaining this unusual low-level answer
             * cannot create an automation input route.
             */
            return true;
        }
        return stack.getItem() instanceof WandCarrierItem wand && !wand.requiresBothHands(stack) && dev.tc4port.thaumcraft.api.wand.WandApi.supportsArcaneCrafting(stack);
    }

    @Override
    public int[] getSlotsForFace(Direction side) {
        return AUTOMATION_SLOTS;
    }

    @Override
    public boolean canPlaceItemThroughFace(int index, ItemStack stack, Direction direction) {
        return index == WAND_SLOT && this.canPlaceItem(index, stack);
    }

    @Override
    public boolean canTakeItemThroughFace(int index, ItemStack stack, Direction direction) {
        return index == WAND_SLOT;
    }

    @Override
    protected AbstractContainerMenu createMenu(int containerId, Inventory inventory) {
        // Vanilla spectator opening bypasses our extra-data menu transport.
        if (inventory.player.isSpectator()) {
            return null;
        }
        return new ArcaneWorktableMenu(containerId, inventory, this);
    }

    protected final HolderLookup.Provider persistenceRegistries() {
        if (level != null)
            return level.registryAccess();
        var server = net.minecraftforge.server.ServerLifecycleHooks.getCurrentServer();
        return server != null ? server.registryAccess() : net.minecraft.core.RegistryAccess.fromRegistryOfRegistries(net.minecraft.core.registries.BuiltInRegistries.REGISTRY);
    }

    protected static net.minecraft.network.chat.Component parseCustomNameSafe(String value, HolderLookup.Provider registries) {
        try {
            return net.minecraft.network.chat.Component.Serializer.fromJson(value);
        } catch (RuntimeException exception) {
            return null;
        }
    }

    @Override
    public boolean isEmpty() {
        return (switch(0) {
            default ->
                {
                    net.minecraft.core.NonNullList<net.minecraft.world.item.ItemStack> native$bodyResult$4854 = null;
                    native$bodyReturn$4855: {
                        if (true) {
                            {
                                native$bodyResult$4854 = this.items;
                                break native$bodyReturn$4855;
                            }
                        }
                    }
                    yield native$bodyResult$4854;
                }
        }).stream().allMatch(ItemStack::isEmpty);
    }

    @Override
    public ItemStack getItem(int index) {
        return (switch(0) {
            default ->
                {
                    net.minecraft.core.NonNullList<net.minecraft.world.item.ItemStack> native$bodyResult$5363 = null;
                    native$bodyReturn$5364: {
                        if (true) {
                            {
                                native$bodyResult$5363 = this.items;
                                break native$bodyReturn$5364;
                            }
                        }
                    }
                    yield native$bodyResult$5363;
                }
        }).get(index);
    }

    @Override
    public ItemStack removeItem(int index, int count) {
        ItemStack removed = net.minecraft.world.ContainerHelper.removeItem((switch(0) {
            default ->
                {
                    net.minecraft.core.NonNullList<net.minecraft.world.item.ItemStack> native$bodyResult$3953 = null;
                    native$bodyReturn$3954: {
                        if (true) {
                            {
                                native$bodyResult$3953 = this.items;
                                break native$bodyReturn$3954;
                            }
                        }
                    }
                    yield native$bodyResult$3953;
                }
        }), index, count);
        if (!removed.isEmpty())
            setChanged();
        return removed;
    }

    @Override
    public ItemStack removeItemNoUpdate(int index) {
        return net.minecraft.world.ContainerHelper.takeItem((switch(0) {
            default ->
                {
                    net.minecraft.core.NonNullList<net.minecraft.world.item.ItemStack> native$bodyResult$5365 = null;
                    native$bodyReturn$5366: {
                        if (true) {
                            {
                                native$bodyResult$5365 = this.items;
                                break native$bodyReturn$5366;
                            }
                        }
                    }
                    yield native$bodyResult$5365;
                }
        }), index);
    }

    @Override
    public void setItem(int index, ItemStack stack) {
        (switch(0) {
            default ->
                {
                    net.minecraft.core.NonNullList<net.minecraft.world.item.ItemStack> native$bodyResult$5367 = null;
                    native$bodyReturn$5368: {
                        if (true) {
                            {
                                native$bodyResult$5367 = this.items;
                                break native$bodyReturn$5368;
                            }
                        }
                    }
                    yield native$bodyResult$5367;
                }
        }).set(index, stack);
        int limit = Math.min(getMaxStackSize(), stack.getMaxStackSize());
        if (stack.getCount() > limit)
            stack.setCount(limit);
        setChanged();
    }

    @Override
    public void clearContent() {
        (switch(0) {
            default ->
                {
                    net.minecraft.core.NonNullList<net.minecraft.world.item.ItemStack> native$bodyResult$5369 = null;
                    native$bodyReturn$5370: {
                        if (true) {
                            {
                                native$bodyResult$5369 = this.items;
                                break native$bodyReturn$5370;
                            }
                        }
                    }
                    yield native$bodyResult$5369;
                }
        }).clear();
    }

    @Override
    public boolean stillValid(net.minecraft.world.entity.player.Player player) {
        return net.minecraft.world.Container.stillValidBlockEntity(this, player);
    }

    @Override
    public net.minecraft.world.phys.AABB getRenderBoundingBox() {
        return ArcaneWorktableBlockEntity.native$ClientBlockEntityBounds$bounds(this);
    }

    @Override()
    public void onDataPacket(net.minecraft.network.Connection connection, net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket packet) {
        handleUpdateTag(packet.getTag());
    }

    @SuppressWarnings({ "rawtypes", "unchecked" })
    static private net.minecraft.world.phys.AABB native$ClientBlockEntityBounds$bounds(net.minecraft.world.level.block.entity.BlockEntity blockEntity) {
        var renderer = net.minecraft.client.Minecraft.getInstance().getBlockEntityRenderDispatcher().getRenderer(blockEntity);
        return renderer instanceof dev.tc4port.thaumcraft.nativeimpl.NativeBlockEntityRenderer shared ? shared.getRenderBoundingBox(blockEntity) : new net.minecraft.world.phys.AABB(blockEntity.getBlockPos());
    }

    private boolean native$capabilitiesInvalid$16973;

    public boolean native$capabilityActive$16816;

    private java.util.Map<net.minecraft.core.Direction, net.minecraftforge.common.util.LazyOptional<net.minecraftforge.items.IItemHandler>> native$capabilityHandle$16817;

    @Override
    public <native$capabilityResultType$16974> net.minecraftforge.common.util.LazyOptional<native$capabilityResultType$16974> getCapability(net.minecraftforge.common.capabilities.Capability<native$capabilityResultType$16974> native$requestedCapability$16975, net.minecraft.core.Direction native$requestedFace$16976) {
        getCapabilities();
        synchronized (this) {
            if (native$capabilitiesInvalid$16973)
                return net.minecraftforge.common.util.LazyOptional.empty();
            if (native$capabilityActive$16816 && native$requestedCapability$16975 == (net.minecraftforge.common.capabilities.ForgeCapabilities.ITEM_HANDLER)) {
                if (native$capabilityHandle$16817 == null)
                    native$capabilityHandle$16817 = new java.util.HashMap<>();
                net.minecraftforge.common.util.LazyOptional<net.minecraftforge.items.IItemHandler> native$capabilityResult$16978 = native$capabilityHandle$16817.computeIfAbsent(native$requestedFace$16976, native$capabilityFace$16818 -> {
                    net.minecraftforge.items.IItemHandler native$endpoint$166 = (switch(0) {
                        default ->
                            {
                                net.minecraft.world.WorldlyContainer native$operand$12767 = dev.tc4port.thaumcraft.block.entity.ArcaneWorktableBlockEntity.this;
                                net.minecraft.core.Direction native$operand$12768 = native$capabilityFace$16818;
                                net.minecraftforge.items.IItemHandler native$result$12769 = (new net.minecraftforge.items.wrapper.SidedInvWrapper(native$operand$12767, native$operand$12768));
                                yield native$result$12769;
                            }
                    });
                    return native$endpoint$166 == null ? net.minecraftforge.common.util.LazyOptional.empty() : net.minecraftforge.common.util.LazyOptional.of(() -> native$endpoint$166);
                });
                if (native$capabilityResult$16978.isPresent())
                    return native$capabilityResult$16978.cast();
            }
        }
        return super.getCapability(native$requestedCapability$16975, native$requestedFace$16976);
    }

    @Override
    public void invalidateCaps() {
        java.util.List<net.minecraftforge.common.util.LazyOptional<?>> native$expiredCapabilities$16977 = new java.util.ArrayList<>();
        synchronized (this) {
            native$capabilitiesInvalid$16973 = true;
            if (native$capabilityHandle$16817 != null) {
                native$expiredCapabilities$16977.addAll(native$capabilityHandle$16817.values());
                native$capabilityHandle$16817 = null;
            }
        }
        try {
            super.invalidateCaps();
        } finally {
            native$expiredCapabilities$16977.forEach(net.minecraftforge.common.util.LazyOptional::invalidate);
        }
    }

    @Override
    public void reviveCaps() {
        super.reviveCaps();
        synchronized (this) {
            native$capabilitiesInvalid$16973 = false;
        }
    }
}
