package dev.tc4port.thaumcraft.api.client;

/**
 * Optional camera-space fade, evaluated for each particle on every frame.
 */
public record ParticleCameraFade(float hiddenDistance, float fullSizeDistance) {

    public static final ParticleCameraFade NONE = new ParticleCameraFade(0.0F, 0.0F);

    public ParticleCameraFade {
        if (!Float.isFinite(hiddenDistance) || !Float.isFinite(fullSizeDistance) || hiddenDistance < 0.0F || fullSizeDistance < hiddenDistance || fullSizeDistance == hiddenDistance && fullSizeDistance != 0.0F) {
            throw new IllegalArgumentException("Invalid particle camera fade distances");
        }
    }

    /**
     * Opacity factor; square this value for a tip that narrows near the camera.
     */
    public float visibility(double viewDepth) {
        if (fullSizeDistance == 0.0F) {
            return 1.0F;
        }
        return (float) Math.max(0.0D, Math.min(1.0D, (viewDepth - hiddenDistance) / (fullSizeDistance - hiddenDistance)));
    }
}
