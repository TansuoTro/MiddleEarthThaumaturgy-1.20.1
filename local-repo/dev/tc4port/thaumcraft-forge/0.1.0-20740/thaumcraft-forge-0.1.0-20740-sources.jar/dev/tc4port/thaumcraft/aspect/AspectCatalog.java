package dev.tc4port.thaumcraft.aspect;

import dev.tc4port.thaumcraft.api.aspect.AspectList;
import dev.tc4port.thaumcraft.api.aspect.AspectDefinition;
import dev.tc4port.thaumcraft.api.aspect.AspectId;
import java.util.List;
import java.util.Map;
import java.util.Set;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.resources.ResourceLocation;

/**
 * Typed runtime view of the reloadable public aspect registry.
 */
public final class AspectCatalog {

    private static final ResourceLocation UNKNOWN_TEXTURE = ResourceLocation.tryBuild("thaumcraft", "textures/aspects/_unknown.png");

    private AspectCatalog() {
    }

    public static long generation() {
        return AspectRegistryManager.current().generation();
    }

    public static Map<AspectId, AspectDefinition> definitions() {
        return AspectRegistryManager.current().definitions();
    }

    public static AspectDefinition get(AspectId id) {
        return AspectRegistryManager.current().get(id).orElse(null);
    }

    public static boolean contains(AspectId id) {
        return AspectRegistryManager.current().get(id).isPresent();
    }

    public static ResourceLocation texture(AspectId id) {
        AspectDefinition definition = get(id);
        return definition == null ? UNKNOWN_TEXTURE : definition.texture();
    }

    public static Set<AspectId> primals() {
        return AspectRegistryManager.current().primals();
    }

    public static Set<AspectId> compounds() {
        return AspectRegistryManager.current().compounds();
    }

    public static List<AspectId> visChannels() {
        return AspectRegistryManager.current().visChannels().stream().map(channel -> channel.aspectId()).toList();
    }

    public static Map<AspectId, Integer> naturalPrimalWeights() {
        return AspectRegistryManager.current().naturalPrimalWeights();
    }

    public static Map<AspectId, Integer> naturalCompoundWeights() {
        return AspectRegistryManager.current().naturalCompoundWeights();
    }

    public static AspectId selectAspect(long entropy) {
        AspectRegistrySnapshot snapshot = AspectRegistryManager.current();
        return snapshot.selectKnown(snapshot.definitions().keySet(), entropy);
    }

    public static AspectId randomAspect(net.minecraft.util.RandomSource random) {
        return selectAspect(random.nextLong());
    }

    public static AspectId randomKnown(java.util.Collection<AspectId> candidates, net.minecraft.util.RandomSource random) {
        return AspectRegistryManager.current().selectKnown(candidates, random.nextLong());
    }

    public static AspectId randomNaturalPrimal(net.minecraft.util.RandomSource random) {
        return AspectRegistryManager.current().selectNaturalPrimal(random.nextLong());
    }

    public static AspectId randomNaturalCompound(net.minecraft.util.RandomSource random) {
        return AspectRegistryManager.current().selectNaturalCompound(random.nextLong());
    }

    public static int visChannelIndex(AspectId aspect) {
        return visChannels().indexOf(aspect);
    }

    public static boolean isVisChannel(AspectId aspect) {
        return visChannelIndex(aspect) >= 0;
    }

    public static List<AspectId> componentIds(AspectDefinition definition) {
        return definition.components();
    }

    /**
     * Returns the source-style display name without exposing a namespaced
     * storage identity when an addon aspect is registered.
     */
    public static MutableComponent name(AspectId id) {
        AspectDefinition definition = get(id);
        return Component.literal(definition == null ? id.serialized() : definition.name());
    }

    /**
     * Resolves the registered aspect's namespace-aware description key.
     */
    public static MutableComponent description(AspectId id) {
        AspectDefinition definition = get(id);
        return definition == null ? Component.literal(id.serialized()) : definition.description().copy();
    }

    public static MutableComponent tooltipName(AspectId id) {
        AspectDefinition definition = get(id);
        MutableComponent name = name(id);
        return definition == null ? name : name.withStyle(style -> style.withColor(definition.color()));
    }

    public static MutableComponent tooltipDescription(AspectId id) {
        AspectDefinition definition = get(id);
        MutableComponent description = description(id);
        return definition == null ? description : description.withStyle(style -> style.withColor(definition.color()));
    }

    public static MutableComponent tooltipEntry(AspectId id, String suffix) {
        return Component.empty().append(tooltipName(id)).append(Component.literal(suffix).withStyle(ChatFormatting.RESET));
    }

    public static java.util.Optional<AspectId> combination(AspectId first, AspectId second) {
        return AspectRegistryManager.current().combination(first, second);
    }

    public static AspectList reduceToPrimals(AspectList input, boolean merge) {
        AspectRegistrySnapshot snapshot = AspectRegistryManager.current();
        return reduceToPrimals(snapshot, input, merge);
    }

    static AspectList reduceToPrimals(AspectRegistrySnapshot snapshot, AspectList input, boolean merge) {
        AspectList output = new AspectList();
        for (AspectId aspect : input.aspects()) {
            AspectDefinition definition = snapshot.get(aspect).orElse(null);
            if (definition == null) {
                continue;
            }
            if (definition.primal()) {
                if (merge) {
                    output.merge(aspect, input.amount(aspect));
                } else {
                    output.add(aspect, input.amount(aspect));
                }
                continue;
            }
            AspectList components = new AspectList().add(definition.components().get(0), input.amount(aspect)).add(definition.components().get(1), input.amount(aspect));
            AspectList reduced = reduceToPrimals(snapshot, components, merge);
            if (merge) {
                output.merge(reduced);
            } else {
                output.add(reduced);
            }
        }
        return output;
    }
}
