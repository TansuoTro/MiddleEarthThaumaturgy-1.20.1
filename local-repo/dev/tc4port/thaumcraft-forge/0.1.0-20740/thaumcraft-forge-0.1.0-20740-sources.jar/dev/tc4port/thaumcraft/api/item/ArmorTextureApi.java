package dev.tc4port.thaumcraft.api.item;

import net.minecraft.resources.ResourceLocation;

/**
 * Shared material textures for armor with an item-provided model and texture.
 */
public final class ArmorTextureApi {

    /**
     * Transparent material artwork for renderers that ignore custom armor models.
     * Both native layer numbers and their {@code _overlay} variants are supplied.
     * Items using this asset must return their real artwork from armorTexture.
     */
    public static final ResourceLocation INVISIBLE_MATERIAL = net.minecraft.resources.ResourceLocation.fromNamespaceAndPath((java.lang.String) ("thaumcraft"), (java.lang.String) ("invisible"));

    private ArmorTextureApi() {
    }
}
