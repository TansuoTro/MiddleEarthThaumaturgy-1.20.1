package dev.tc4port.thaumcraft.api.item;

import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;

/**
 * Dynamic owner-item hook for revealing aura nodes and energized Vis relays.
 *
 * <p>This is intentionally separate from {@link GogglesOverlayGear}: an addon
 * item may reveal aura infrastructure without enabling the machine/container
 * HUD, or vice versa. Static items should use the synchronized
 * equipment-ability Data Map. The callback is read-only and may run on either
 * physical side.</p>
 */
@FunctionalInterface
public interface AuraRevealingGear {

    boolean revealsThaumcraftAura(ItemStack stack, Player wearer);
}
