package dev.tc4port.thaumcraft.api.player;

import dev.tc4port.thaumcraft.state.TCObjectState;
import java.util.Objects;
import net.minecraft.world.entity.player.Player;

/**
 * Side-safe Warp views and server-owned player Warp transactions.
 */
public final class PlayerWarpApi {

    private PlayerWarpApi() {
    }

    /**
     * Reads the player's current synchronized attachment. On a physical
     * client only the local player's value is authoritative for presentation;
     * gameplay decisions must use this view on the owning server thread.
     */
    public static PlayerWarpView view(Player player) {
        Objects.requireNonNull(player, "player");
        var knowledge = TCObjectState.PLAYER_KNOWLEDGE.get(player);
        return new PlayerWarpView(knowledge.permanentWarp(), knowledge.stickyWarp(), knowledge.temporaryWarp());
    }

    /**
     * Remaining native event activity; read on the owning server thread.
     */
    public static int activity(Player player) {
        return TCObjectState.PLAYER_KNOWLEDGE.get(player).warpCounter();
    }

    /**
     * Warp from held gear, armor and equipped accessories, including data packs.
     */
    public static int equipped(Player player) {
        return dev.tc4port.thaumcraft.common.WarpGear.equippedWarp(player);
    }

    /**
     * Allows creative players; respects spectator mode, the server option and Warp Ward.
     */
    public static boolean eventsAllowed(Player player) {
        return !dev.tc4port.thaumcraft.common.TCServerConfig.wussMode() && !player.isSpectator() && !(switch(0) {
            default ->
                {
                    net.minecraft.world.entity.LivingEntity native$operand$13625 = player;
                    net.minecraft.core.Holder<net.minecraft.world.effect.MobEffect> native$operand$13626 = ((net.minecraft.core.Holder<net.minecraft.world.effect.MobEffect>) (net.minecraft.core.Holder<?>) (dev.tc4port.thaumcraft.registry.TCEffects.WARP_WARD).getHolder().orElseThrow());
                    boolean native$result$13627 = (native$operand$13625.hasEffect(native$operand$13626.value()));
                    yield native$result$13627;
                }
        });
    }

    /**
     * Removes temporary, then sticky, then optionally permanent Warp in one
     * synchronized transaction. Each permanent point costs permanentCost units.
     * Activity is reset to the remaining stored pools, as with sanitizing soap.
     * Returns the actual number of stored points removed.
     */
    public static int remove(net.minecraft.server.level.ServerPlayer player, int amount, boolean removePermanent, int permanentCost) {
        if (amount <= 0)
            return 0;
        if (permanentCost < 1)
            throw new IllegalArgumentException("permanentCost must be positive");
        var current = TCObjectState.PLAYER_KNOWLEDGE.get(player);
        int temporary = Math.min(amount, current.temporaryWarp());
        amount -= temporary;
        int sticky = Math.min(amount, current.stickyWarp());
        amount -= sticky;
        int permanent = removePermanent ? (int) Math.min(current.permanentWarp(), ((long) amount + permanentCost - 1) / permanentCost) : 0;
        var updated = current.addTemporaryWarp(-temporary).addStickyWarp(-sticky).addPermanentWarp(-permanent);
        TCObjectState.PLAYER_KNOWLEDGE.set(player, updated.withWarpCounter(updated.totalWarp()));
        return temporary + sticky + permanent;
    }
}
