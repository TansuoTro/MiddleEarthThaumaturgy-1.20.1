package dev.tc4port.thaumcraft.api.aspect;

import java.util.Collections;
import java.util.EnumMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Objects;

/**
 * Immutable, validated cost over the six fixed vis channels.
 *
 * <p>The stored unit is centivis. Factory names make conversion from the
 * whole-vis units used by crafting recipes explicit and overflow-checked.</p>
 */
public final class VisCost {

    private final Map<VisChannel, Integer> amounts;

    private VisCost(Map<VisChannel, Integer> values, int multiplier) {
        Objects.requireNonNull(values, "values");
        if (values.isEmpty()) {
            throw new IllegalArgumentException("A vis cost must not be empty");
        }
        LinkedHashMap<VisChannel, Integer> checked = new LinkedHashMap<>();
        values.forEach((channel, amount) -> {
            Objects.requireNonNull(channel, "channel");
            Objects.requireNonNull(amount, "amount");
            if (amount <= 0) {
                throw new IllegalArgumentException("A vis cost must be positive: " + channel);
            }
            checked.put(channel, Math.multiplyExact(amount, multiplier));
        });
        this.amounts = Collections.unmodifiableMap(checked);
    }

    public static VisCost ofCentivis(Map<VisChannel, Integer> amounts) {
        return new VisCost(amounts, 1);
    }

    public static VisCost ofWholeVis(Map<VisChannel, Integer> amounts) {
        return new VisCost(amounts, 100);
    }

    public static VisCost ofCentivis(VisChannel channel, int amount) {
        return ofCentivis(Map.of(channel, amount));
    }

    public static VisCost ofWholeVis(VisChannel channel, int amount) {
        return ofWholeVis(Map.of(channel, amount));
    }

    /**
     * Validated amounts in centivis, keyed by the typed channel and retaining
     * the caller's declaration order.
     */
    public Map<VisChannel, Integer> amounts() {
        return this.amounts;
    }

    /**
     * Returns whole-vis values when an exact checked conversion is needed.
     * Costs containing a partial vis cannot be represented and are rejected.
     */
    public Map<VisChannel, Integer> wholeVis() {
        EnumMap<VisChannel, Integer> result = new EnumMap<>(VisChannel.class);
        this.amounts.forEach((channel, amount) -> {
            if (amount % 100 != 0) {
                throw new IllegalStateException("Recipe vis cost is not a whole-vis value: " + channel);
            }
            result.put(channel, amount / 100);
        });
        return Collections.unmodifiableMap(result);
    }

    @Override
    public boolean equals(Object other) {
        return other instanceof VisCost cost && this.amounts.equals(cost.amounts);
    }

    @Override
    public int hashCode() {
        return this.amounts.hashCode();
    }

    @Override
    public String toString() {
        return "VisCost" + this.amounts;
    }
}
