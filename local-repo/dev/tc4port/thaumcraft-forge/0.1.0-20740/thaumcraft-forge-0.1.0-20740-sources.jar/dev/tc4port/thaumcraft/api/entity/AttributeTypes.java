package dev.tc4port.thaumcraft.api.entity;

import net.minecraft.world.entity.ai.attributes.*;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.core.Holder;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.registries.BuiltInRegistries;

public final class AttributeTypes {

    public static float baseJumpStrength(LivingEntity entity) {
        // JUMP_STRENGTH in 1.20.1 is horse.jump_strength, not a generic living attribute.
        return 0.42F;
    }

    public static final Attribute SCALE = new RangedAttribute("attribute.name.generic.scale", 1.0, 0.0625, 16.0).setSyncable(true);

    public static final Attribute MAX_ABSORPTION = new RangedAttribute("attribute.name.generic.max_absorption", 0.0, 0.0, 2048.0).setSyncable(true);

    public static double sanitizeAbsorptionCapacity(double value) {
        return MAX_ABSORPTION.sanitizeValue(value);
    }

    public static Attribute stepHeight() {
        return net.minecraftforge.common.ForgeMod.STEP_HEIGHT_ADDITION.get();
    }

    public static double stepBase(double absolute) {
        return absolute - 0.6;
    }

    public static boolean isRegistered(ResourceLocation id) {
        if (id.equals(ResourceLocation.fromNamespaceAndPath("minecraft", "generic.max_absorption")))
            return BuiltInRegistries.ATTRIBUTE.getResourceKey(MAX_ABSORPTION).isPresent();
        return BuiltInRegistries.ATTRIBUTE.containsKey(id);
    }

    public static AttributeInstance resolve(LivingEntity entity, ResourceLocation id) {
        if (id.equals(ResourceLocation.fromNamespaceAndPath("minecraft", "generic.max_absorption")))
            return entity.getAttribute(MAX_ABSORPTION);
        return BuiltInRegistries.ATTRIBUTE.getOptional(id).map(entity::getAttribute).orElse(null);
    }

    @SuppressWarnings("unchecked")
    public static Double registeredBase(net.minecraft.world.entity.EntityType<?> type, ResourceLocation id) {
        var supplier = net.minecraft.world.entity.ai.attributes.DefaultAttributes.getSupplier((net.minecraft.world.entity.EntityType<? extends LivingEntity>) type);
        if (supplier == null)
            return null;
        Attribute attribute = id.equals(ResourceLocation.fromNamespaceAndPath("minecraft", "generic.max_absorption")) ? MAX_ABSORPTION : BuiltInRegistries.ATTRIBUTE.getOptional(id).orElse(null);
        return attribute != null && supplier.hasAttribute(attribute) ? supplier.getBaseValue(attribute) : null;
    }
}
