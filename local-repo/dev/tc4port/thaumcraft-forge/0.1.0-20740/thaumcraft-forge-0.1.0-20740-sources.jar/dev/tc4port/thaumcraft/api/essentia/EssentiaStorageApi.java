package dev.tc4port.thaumcraft.api.essentia;

import dev.tc4port.thaumcraft.common.EssentiaStorageSettings;
import java.util.OptionalInt;
import net.minecraft.resources.ResourceLocation;

/**
 * Datapack capacity lookup for core and addon containers. IDs match resource paths.
 */
public final class EssentiaStorageApi {

    public static final ResourceLocation WARDED_JAR = ResourceLocation.parse("thaumcraft:warded_jar");

    public static final ResourceLocation VOID_JAR = ResourceLocation.parse("thaumcraft:void_jar");

    public static final ResourceLocation ESSENTIA_RESERVOIR = ResourceLocation.parse("thaumcraft:essentia_reservoir");

    public static final ResourceLocation ARCANE_ALEMBIC = ResourceLocation.parse("thaumcraft:arcane_alembic");

    public static final ResourceLocation ESSENTIA_BUFFER = ResourceLocation.parse("thaumcraft:essentia_buffer");

    public static final ResourceLocation ALCHEMICAL_FURNACE = ResourceLocation.parse("thaumcraft:alchemical_furnace");

    public static final ResourceLocation ESSENCE_PHIAL = ResourceLocation.parse("thaumcraft:essence_phial");

    public static final ResourceLocation ADVANCED_ALCHEMICAL_FURNACE = ResourceLocation.parse("thaumcraft:advanced_alchemical_furnace");

    private EssentiaStorageApi() {
    }

    /**
     * Select the server catalog or its synchronized client snapshot.
     */
    public static OptionalInt findCapacity(ResourceLocation storageId, boolean clientSide) {
        Integer value = EssentiaStorageSettings.snapshot(clientSide).entries().get(storageId);
        return value == null ? OptionalInt.empty() : OptionalInt.of(value);
    }

    /**
     * Addons provide their gameplay default when their optional resource is absent.
     */
    public static int capacity(ResourceLocation storageId, int defaultCapacity, boolean clientSide) {
        if (defaultCapacity < 1 || defaultCapacity > 1000000000) {
            throw new IllegalArgumentException("Default capacity must be in 1..1000000000");
        }
        return findCapacity(storageId, clientSide).orElse(defaultCapacity);
    }
}
