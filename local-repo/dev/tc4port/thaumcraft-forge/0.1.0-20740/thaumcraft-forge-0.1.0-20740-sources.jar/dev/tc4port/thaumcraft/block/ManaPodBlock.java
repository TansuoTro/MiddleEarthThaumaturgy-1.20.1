package dev.tc4port.thaumcraft.block;

import com.mojang.serialization.MapCodec;
import dev.tc4port.thaumcraft.block.entity.ManaPodBlockEntity;
import dev.tc4port.thaumcraft.registry.ManaPlants;
import javax.annotation.Nullable;
import net.minecraft.world.phys.HitResult;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.LevelReader;
import net.minecraft.world.level.pathfinder.PathComputationType;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.IntegerProperty;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.VoxelShape;
import dev.tc4port.thaumcraft.nativeimpl.ClientExtensionTarget;
import dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.level.Explosion;

/**
 * Eight growth stages of the underside-hanging TC4 mana pod.
 */
public final class ManaPodBlock extends net.minecraft.world.level.block.BaseEntityBlock implements dev.tc4port.thaumcraft.nativeimpl.ClientExtensionTarget {

    // Forge calls initializeClient from the native superclass constructor. Do not add a field initializer.
    private java.util.function.Consumer<net.minecraftforge.client.extensions.common.IClientBlockExtensions> platform$clientInstaller;

    public static final IntegerProperty AGE = IntegerProperty.create("age", 0, 7);

    private static final VoxelShape[] SHAPES = { Block.box(4.0, 12.0, 4.0, 12.0, 16.0, 12.0), Block.box(4.0, 10.0, 4.0, 12.0, 16.0, 12.0), Block.box(4.0, 8.0, 4.0, 12.0, 16.0, 12.0), Block.box(4.0, 6.0, 4.0, 12.0, 16.0, 12.0), Block.box(4.0, 5.0, 4.0, 12.0, 16.0, 12.0), Block.box(4.0, 4.0, 4.0, 12.0, 16.0, 12.0), Block.box(4.0, 3.0, 4.0, 12.0, 16.0, 12.0), Block.box(4.0, 2.0, 4.0, 12.0, 16.0, 12.0) };

    public ManaPodBlock(BlockBehaviour.Properties properties) {
        this(properties, properties, true);
    }

    @Nullable
    @Override
    public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        return new ManaPodBlockEntity(pos, state);
    }

    @Override
    public RenderShape getRenderShape(BlockState state) {
        return RenderShape.MODEL;
    }

    @Override
    public boolean isRandomlyTicking(BlockState state) {
        /*
         * setTickRandomly(true) applied to every metadata in TC4. Mature pods
         * still occasionally repaired a missing aspect and cleared the
         * temporary non-player-drop cache.
         */
        return true;
    }

    @Override
    public void randomTick(BlockState state, ServerLevel level, BlockPos pos, RandomSource random) {
        if (!state.canSurvive(level, pos)) {
            level.destroyBlock(pos, true);
            return;
        }
        if (random.nextInt(30) == 0 && level.getBlockEntity(pos) instanceof ManaPodBlockEntity pod) {
            pod.checkGrowth(random);
        }
    }

    @Override
    public boolean canSurvive(BlockState state, LevelReader level, BlockPos pos) {
        return level.getBiome(pos).is(ManaPlants.MAGICAL_BIOMES) && level.getBlockState(pos.above()).is(net.minecraft.tags.BlockTags.LOGS);
    }

    @Override
    public BlockState updateShape(BlockState state, net.minecraft.core.Direction direction, BlockState neighborState, LevelAccessor level, BlockPos currentPos, BlockPos neighborPos) {
        if (direction == net.minecraft.core.Direction.UP && !state.canSurvive(level, currentPos)) {
            /*
             * Returning AIR directly can bypass the BlockEntity-aware loot
             * path. Schedule a one-tick destruction so the bean keeps the
             * pod's aspect when its supporting log disappears.
             */
            level.scheduleTick(currentPos, this, 1);
        }
        return super.updateShape(state, direction, neighborState, level, currentPos, neighborPos);
    }

    @Override
    public void tick(BlockState state, ServerLevel level, BlockPos pos, RandomSource random) {
        if (!state.canSurvive(level, pos)) {
            level.destroyBlock(pos, true);
        }
    }

    @Override
    public VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
        return SHAPES[state.getValue(AGE)];
    }

    @Override
    public boolean isPathfindable(BlockState state, BlockGetter level, BlockPos pos, PathComputationType pathType) {
        // Material.plants made 1.7.10 path through pods, but the pod keeps
        // its hanging collision box, so walkers stalled underneath it.
        return false;
    }

    @Override
    public float getDestroyProgress(BlockState state, Player player, BlockGetter level, BlockPos pos) {
        /*
         * getBlockHardness returned 0.5 / (8 - metadata). Modern block
         * properties cannot vary destroy time by state, so scale the
         * resulting progress by the inverse factor.
         */
        return super.getDestroyProgress(state, player, level, pos) * (8 - state.getValue(AGE));
    }

    @Override
    public ItemStack getCloneItemStack(BlockState state, net.minecraft.world.phys.HitResult hit, net.minecraft.world.level.BlockGetter level, net.minecraft.core.BlockPos pos, net.minecraft.world.entity.player.Player player) {
        // BlockManaPod#getItem deliberately returned a bare mana bean.
        return new ItemStack(ManaPlants.bean());
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(AGE);
    }

    public static final MapCodec<ManaPodBlock> CODEC = ManaPodBlock.native$BlockCodecPlatform$simple(ManaPodBlock::new);

    protected MapCodec<? extends ManaPodBlock> codec() {
        return CODEC;
    }

    private ManaPodBlock(net.minecraft.world.level.block.state.BlockBehaviour.Properties native$NativeEntityBlock$arg0, BlockBehaviour.Properties properties, boolean native$NativeEntityBlock$captured) {
        super(native$NativeEntityBlock$arg0);
        this.registerDefaultState(this.stateDefinition.any().setValue(AGE, 0));
    }

    @Override
    public void initializeClient(java.util.function.Consumer<net.minecraftforge.client.extensions.common.IClientBlockExtensions> installer) {
        platform$clientInstaller = installer;
        super.initializeClient(installer);
    }

    @Override
    public void platform$clientExtension(Object extension) {
        java.util.Objects.requireNonNull(platform$clientInstaller, "Forge initializeClient must run before client extension registration").accept((net.minecraftforge.client.extensions.common.IClientBlockExtensions) extension);
    }

    @Override
    public InteractionResult use(BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
        ItemUseResult result = (switch(0) {
            default ->
                {
                    net.minecraft.world.item.ItemStack native$bodyOperand$4584 = player.getItemInHand(hand);
                    net.minecraft.world.level.block.state.BlockState native$bodyOperand$4585 = state;
                    net.minecraft.world.level.Level native$bodyOperand$4586 = level;
                    net.minecraft.core.BlockPos native$bodyOperand$4587 = pos;
                    net.minecraft.world.entity.player.Player native$bodyOperand$4588 = player;
                    net.minecraft.world.InteractionHand native$bodyOperand$4589 = hand;
                    net.minecraft.world.phys.BlockHitResult native$bodyOperand$4590 = hit;
                    dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult native$bodyResult$4591 = null;
                    native$bodyReturn$4592: {
                        if (true) {
                            {
                                native$bodyResult$4591 = dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
                                break native$bodyReturn$4592;
                            }
                        }
                    }
                    yield native$bodyResult$4591;
                }
        });
        return result == ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION ? (hand == InteractionHand.MAIN_HAND ? (switch(0) {
            default ->
                {
                    net.minecraft.world.level.block.state.BlockState native$bodyOperand$3773 = state;
                    net.minecraft.world.level.Level native$bodyOperand$3774 = level;
                    net.minecraft.core.BlockPos native$bodyOperand$3775 = pos;
                    net.minecraft.world.entity.player.Player native$bodyOperand$3776 = player;
                    net.minecraft.world.phys.BlockHitResult native$bodyOperand$3777 = hit;
                    net.minecraft.world.InteractionResult native$bodyResult$3778 = null;
                    native$bodyReturn$3779: {
                        if (true) {
                            {
                                native$bodyResult$3778 = super.use(native$bodyOperand$3773, native$bodyOperand$3774, native$bodyOperand$3775, native$bodyOperand$3776, net.minecraft.world.InteractionHand.MAIN_HAND, native$bodyOperand$3777);
                                break native$bodyReturn$3779;
                            }
                        }
                    }
                    yield native$bodyResult$3778;
                }
        }) : InteractionResult.PASS) : result.result();
    }

    protected ItemUseResult interactWithItem(ItemStack stack, BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
        return dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
    }

    protected InteractionResult interactWithoutItem(BlockState state, Level level, BlockPos pos, Player player, BlockHitResult hit) {
        return super.use(state, level, pos, player, net.minecraft.world.InteractionHand.MAIN_HAND, hit);
    }

    @Override
    public void playerWillDestroy(Level level, BlockPos pos, BlockState state, Player player) {
        {
            net.minecraft.world.level.Level native$bodyOperand$5924 = level;
            net.minecraft.core.BlockPos native$bodyOperand$5925 = pos;
            net.minecraft.world.level.block.state.BlockState native$bodyOperand$5926 = state;
            net.minecraft.world.entity.player.Player native$bodyOperand$5927 = player;
            net.minecraft.world.level.block.state.BlockState native$bodyResult$5928 = null;
            native$bodyReturn$5929: {
                if (true) {
                    super.playerWillDestroy(native$bodyOperand$5924, native$bodyOperand$5925, native$bodyOperand$5926, native$bodyOperand$5927);
                    {
                        native$bodyResult$5928 = native$bodyOperand$5926;
                        break native$bodyReturn$5929;
                    }
                }
            }
        }
    }

    public BlockState beforePlayerDestroy(Level level, BlockPos pos, BlockState state, Player player) {
        super.playerWillDestroy(level, pos, state, player);
        return state;
    }

    protected boolean survivesSharedExplosion() {
        return false;
    }

    public int getExpDrop(net.minecraft.world.level.block.state.BlockState native$callbackInput$1050, net.minecraft.world.level.LevelReader native$callbackInput$1051, net.minecraft.util.RandomSource native$callbackInput$1052, net.minecraft.core.BlockPos native$callbackInput$1053, int native$callbackInput$1054, int native$callbackInput$1055) {
        net.minecraft.world.level.block.state.BlockState state = native$callbackInput$1050;
        net.minecraft.util.RandomSource random = native$callbackInput$1052;
        return 0;
    }

    @Override
    public void onBlockExploded(BlockState state, Level level, BlockPos pos, Explosion explosion) {
        if (!(switch(0) {
            default ->
                {
                    boolean native$bodyResult$5293 = false;
                    native$bodyReturn$5294: {
                        if (true) {
                            {
                                native$bodyResult$5293 = false;
                                break native$bodyReturn$5294;
                            }
                        }
                    }
                    yield native$bodyResult$5293;
                }
        }))
            super.onBlockExploded(state, level, pos, explosion);
    }

    @Override
    public boolean canDropFromExplosion(BlockState state, BlockGetter level, BlockPos pos, Explosion explosion) {
        return !(switch(0) {
            default ->
                {
                    boolean native$bodyResult$4593 = false;
                    native$bodyReturn$4594: {
                        if (true) {
                            {
                                native$bodyResult$4593 = false;
                                break native$bodyReturn$4594;
                            }
                        }
                    }
                    yield native$bodyResult$4593;
                }
        }) && super.canDropFromExplosion(state, level, pos, explosion);
    }

    static private <B extends net.minecraft.world.level.block.Block> com.mojang.serialization.MapCodec<B> native$BlockCodecPlatform$simple(java.util.function.Function<net.minecraft.world.level.block.state.BlockBehaviour.Properties, B> factory) {
        // Vanilla 1.21's Properties codec is a unit codec. Retain that schema for shared block definitions.
        return com.mojang.serialization.codecs.RecordCodecBuilder.mapCodec(instance -> instance.group(com.mojang.serialization.Codec.unit(net.minecraft.world.level.block.state.BlockBehaviour.Properties::of).fieldOf("properties").forGetter((B block) -> net.minecraft.world.level.block.state.BlockBehaviour.Properties.copy(block))).apply(instance, factory));
    }
}
