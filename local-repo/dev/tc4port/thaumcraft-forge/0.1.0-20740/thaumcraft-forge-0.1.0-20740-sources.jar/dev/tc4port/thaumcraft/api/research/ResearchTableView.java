package dev.tc4port.thaumcraft.api.research;

import dev.tc4port.thaumcraft.api.aspect.AspectId;
import net.minecraft.core.BlockPos;
import net.minecraft.world.inventory.AbstractContainerMenu;
import javax.annotation.Nullable;

/**
 * Live table presentation. All gameplay mutations must use ResearchTableApi requests.
 */
public interface ResearchTableView {

    int SCRIBING_SLOT = 0;

    int NOTE_SLOT = 1;

    AbstractContainerMenu menu();

    BlockPos tablePosition();

    ResearchTableNote note();

    int bonusAmount(AspectId aspect);

    @Nullable
    AspectId selectedFirst();

    @Nullable
    AspectId selectedSecond();

    void setSelectedFirst(@Nullable AspectId aspect);

    void setSelectedSecond(@Nullable AspectId aspect);

    /**
     * Client only. Changes coordinates, never container IDs, slot indices, contents or click rules.
     */
    void applyLayout(ResearchTableLayout layout);
}
