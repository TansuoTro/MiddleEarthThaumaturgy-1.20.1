package dev.tc4port.thaumcraft.block;

import com.mojang.serialization.MapCodec;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import dev.tc4port.thaumcraft.nativeimpl.ClientExtensionTarget;
import dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.level.pathfinder.PathComputationType;
import net.minecraft.world.phys.HitResult;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.Explosion;
import net.minecraft.world.level.BlockGetter;

/**
 * The obelisk's upper collision shell, rendered by its base block entity.
 */
public final class EldritchObeliskSegmentBlock extends net.minecraft.world.level.block.Block implements dev.tc4port.thaumcraft.nativeimpl.ClientExtensionTarget {

    // Forge calls initializeClient from the native superclass constructor. Do not add a field initializer.
    private java.util.function.Consumer<net.minecraftforge.client.extensions.common.IClientBlockExtensions> platform$clientInstaller;

    public static final MapCodec<EldritchObeliskSegmentBlock> CODEC = EldritchObeliskSegmentBlock.native$BlockCodecPlatform$simple(EldritchObeliskSegmentBlock::new);

    public EldritchObeliskSegmentBlock(BlockBehaviour.Properties properties) {
        this(properties.noLootTable(), properties, true);
    }

    protected MapCodec<EldritchObeliskSegmentBlock> codec() {
        return CODEC;
    }

    @Override
    public RenderShape getRenderShape(BlockState state) {
        return RenderShape.INVISIBLE;
    }

    @Override
    public void onRemove(BlockState state, Level level, BlockPos pos, BlockState newState, boolean movedByPiston) {
        EldritchStructureBlock.onStructureRemoved(state, level, pos, newState);
        super.onRemove(state, level, pos, newState, movedByPiston);
    }

    private EldritchObeliskSegmentBlock(net.minecraft.world.level.block.state.BlockBehaviour.Properties native$NativeBlock$arg0, BlockBehaviour.Properties properties, boolean native$NativeBlock$captured) {
        super(native$NativeBlock$arg0);
    }

    @Override
    public void initializeClient(java.util.function.Consumer<net.minecraftforge.client.extensions.common.IClientBlockExtensions> installer) {
        platform$clientInstaller = installer;
        super.initializeClient(installer);
    }

    @Override
    public void platform$clientExtension(Object extension) {
        java.util.Objects.requireNonNull(platform$clientInstaller, "Forge initializeClient must run before client extension registration").accept((net.minecraftforge.client.extensions.common.IClientBlockExtensions) extension);
    }

    @Override
    public InteractionResult use(BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
        ItemUseResult result = (switch(0) {
            default ->
                {
                    net.minecraft.world.item.ItemStack native$bodyOperand$4355 = player.getItemInHand(hand);
                    net.minecraft.world.level.block.state.BlockState native$bodyOperand$4356 = state;
                    net.minecraft.world.level.Level native$bodyOperand$4357 = level;
                    net.minecraft.core.BlockPos native$bodyOperand$4358 = pos;
                    net.minecraft.world.entity.player.Player native$bodyOperand$4359 = player;
                    net.minecraft.world.InteractionHand native$bodyOperand$4360 = hand;
                    net.minecraft.world.phys.BlockHitResult native$bodyOperand$4361 = hit;
                    dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult native$bodyResult$4362 = null;
                    native$bodyReturn$4363: {
                        if (true) {
                            {
                                native$bodyResult$4362 = dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
                                break native$bodyReturn$4363;
                            }
                        }
                    }
                    yield native$bodyResult$4362;
                }
        });
        return result == ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION ? (hand == InteractionHand.MAIN_HAND ? (switch(0) {
            default ->
                {
                    net.minecraft.world.level.block.state.BlockState native$bodyOperand$3624 = state;
                    net.minecraft.world.level.Level native$bodyOperand$3625 = level;
                    net.minecraft.core.BlockPos native$bodyOperand$3626 = pos;
                    net.minecraft.world.entity.player.Player native$bodyOperand$3627 = player;
                    net.minecraft.world.phys.BlockHitResult native$bodyOperand$3628 = hit;
                    net.minecraft.world.InteractionResult native$bodyResult$3629 = null;
                    native$bodyReturn$3630: {
                        if (true) {
                            {
                                native$bodyResult$3629 = super.use(native$bodyOperand$3624, native$bodyOperand$3625, native$bodyOperand$3626, native$bodyOperand$3627, net.minecraft.world.InteractionHand.MAIN_HAND, native$bodyOperand$3628);
                                break native$bodyReturn$3630;
                            }
                        }
                    }
                    yield native$bodyResult$3629;
                }
        }) : InteractionResult.PASS) : result.result();
    }

    protected ItemUseResult interactWithItem(ItemStack stack, BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
        return dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
    }

    protected InteractionResult interactWithoutItem(BlockState state, Level level, BlockPos pos, Player player, BlockHitResult hit) {
        return super.use(state, level, pos, player, net.minecraft.world.InteractionHand.MAIN_HAND, hit);
    }

    @Override
    public void playerWillDestroy(Level level, BlockPos pos, BlockState state, Player player) {
        {
            net.minecraft.world.level.Level native$bodyOperand$5799 = level;
            net.minecraft.core.BlockPos native$bodyOperand$5800 = pos;
            net.minecraft.world.level.block.state.BlockState native$bodyOperand$5801 = state;
            net.minecraft.world.entity.player.Player native$bodyOperand$5802 = player;
            net.minecraft.world.level.block.state.BlockState native$bodyResult$5803 = null;
            native$bodyReturn$5804: {
                if (true) {
                    super.playerWillDestroy(native$bodyOperand$5799, native$bodyOperand$5800, native$bodyOperand$5801, native$bodyOperand$5802);
                    {
                        native$bodyResult$5803 = native$bodyOperand$5801;
                        break native$bodyReturn$5804;
                    }
                }
            }
        }
    }

    public BlockState beforePlayerDestroy(Level level, BlockPos pos, BlockState state, Player player) {
        super.playerWillDestroy(level, pos, state, player);
        return state;
    }

    protected boolean survivesSharedExplosion() {
        return false;
    }

    public int getExpDrop(net.minecraft.world.level.block.state.BlockState native$callbackInput$1145, net.minecraft.world.level.LevelReader native$callbackInput$1146, net.minecraft.util.RandomSource native$callbackInput$1147, net.minecraft.core.BlockPos native$callbackInput$1148, int native$callbackInput$1149, int native$callbackInput$1150) {
        net.minecraft.world.level.block.state.BlockState state = native$callbackInput$1145;
        net.minecraft.util.RandomSource random = native$callbackInput$1147;
        return 0;
    }

    @Override
    public void onBlockExploded(BlockState state, Level level, BlockPos pos, Explosion explosion) {
        if (!(switch(0) {
            default ->
                {
                    boolean native$bodyResult$5253 = false;
                    native$bodyReturn$5254: {
                        if (true) {
                            {
                                native$bodyResult$5253 = false;
                                break native$bodyReturn$5254;
                            }
                        }
                    }
                    yield native$bodyResult$5253;
                }
        }))
            super.onBlockExploded(state, level, pos, explosion);
    }

    @Override
    public boolean canDropFromExplosion(BlockState state, BlockGetter level, BlockPos pos, Explosion explosion) {
        return !(switch(0) {
            default ->
                {
                    boolean native$bodyResult$4364 = false;
                    native$bodyReturn$4365: {
                        if (true) {
                            {
                                native$bodyResult$4364 = false;
                                break native$bodyReturn$4365;
                            }
                        }
                    }
                    yield native$bodyResult$4364;
                }
        }) && super.canDropFromExplosion(state, level, pos, explosion);
    }

    static private <B extends net.minecraft.world.level.block.Block> com.mojang.serialization.MapCodec<B> native$BlockCodecPlatform$simple(java.util.function.Function<net.minecraft.world.level.block.state.BlockBehaviour.Properties, B> factory) {
        // Vanilla 1.21's Properties codec is a unit codec. Retain that schema for shared block definitions.
        return com.mojang.serialization.codecs.RecordCodecBuilder.mapCodec(instance -> instance.group(com.mojang.serialization.Codec.unit(net.minecraft.world.level.block.state.BlockBehaviour.Properties::of).fieldOf("properties").forGetter((B block) -> net.minecraft.world.level.block.state.BlockBehaviour.Properties.copy(block))).apply(instance, factory));
    }
}
