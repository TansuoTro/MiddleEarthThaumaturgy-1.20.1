package dev.tc4port.thaumcraft.api.focus;

import java.util.List;
import java.util.Objects;
import java.util.Optional;
import net.minecraft.resources.ResourceLocation;

/**
 * Server-synchronized, data-only description of a mounted focus's optional
 * depth animation and ornament. It contains no executable client callback.
 */
public record FocusClientPresentation(Optional<ResourceLocation> depthTexture, int depthFrameCount, List<Integer> depthFrameSequence, Optional<ResourceLocation> ornamentTexture) {

    public static final int MAX_DEPTH_FRAMES = 256;

    public static final FocusClientPresentation NONE = new FocusClientPresentation(Optional.empty(), 0, List.of(), Optional.empty());

    public FocusClientPresentation {
        depthTexture = Objects.requireNonNull(depthTexture, "depthTexture");
        ornamentTexture = Objects.requireNonNull(ornamentTexture, "ornamentTexture");
        Objects.requireNonNull(depthFrameSequence, "depthFrameSequence");
        depthFrameSequence = List.copyOf(depthFrameSequence);
        if (depthFrameSequence.stream().anyMatch(Objects::isNull)) {
            throw new IllegalArgumentException("Depth frame sequence cannot contain null");
        }
        if (depthTexture.isEmpty()) {
            if (depthFrameCount != 0 || !depthFrameSequence.isEmpty()) {
                throw new IllegalArgumentException("Depth frames require a depth texture");
            }
        } else if (depthFrameCount < 1 || depthFrameCount > MAX_DEPTH_FRAMES || depthFrameSequence.isEmpty() || depthFrameSequence.size() > MAX_DEPTH_FRAMES || depthFrameSequence.stream().anyMatch(frame -> frame < 0 || frame >= depthFrameCount)) {
            throw new IllegalArgumentException("Invalid focus depth animation");
        }
    }
}
