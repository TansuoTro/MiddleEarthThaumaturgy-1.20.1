package dev.tc4port.thaumcraft.api.research;

import com.mojang.serialization.Codec;
import com.mojang.serialization.DataResult;
import java.util.Objects;

/**
 * Bounded, case-preserving prefix for research-entry paths in one namespace.
 *
 * <p>A bare value addresses the {@code thaumcraft} namespace, matching the
 * historical TC4 spelling. Addon prefixes must be namespaced.</p>
 */
public record ResearchKeyPrefix(String namespace, String pathPrefix) {

    public static final Codec<ResearchKeyPrefix> CODEC = Codec.STRING.comapFlatMap(ResearchKeyPrefix::decode, ResearchKeyPrefix::serialized);

    public ResearchKeyPrefix {
        namespace = Objects.requireNonNull(namespace, "namespace");
        pathPrefix = Objects.requireNonNull(pathPrefix, "pathPrefix");
        // ResearchKey is the single validation authority for both parts.
        ResearchKey.of(namespace, pathPrefix);
    }

    public static ResearchKeyPrefix parse(String value) {
        ResearchKey key = ResearchKey.parse(value);
        return new ResearchKeyPrefix(key.namespace(), key.path());
    }

    public boolean matches(ResearchKey key) {
        Objects.requireNonNull(key, "key");
        return this.namespace.equals(key.namespace()) && key.path().startsWith(this.pathPrefix);
    }

    public String serialized() {
        return ResearchKey.of(this.namespace, this.pathPrefix).serialized();
    }

    private static DataResult<ResearchKeyPrefix> decode(String value) {
        try {
            return DataResult.success(parse(value));
        } catch (RuntimeException exception) {
            return DataResult.error(() -> "Invalid research key prefix '" + value + "': " + exception.getMessage());
        }
    }
}
