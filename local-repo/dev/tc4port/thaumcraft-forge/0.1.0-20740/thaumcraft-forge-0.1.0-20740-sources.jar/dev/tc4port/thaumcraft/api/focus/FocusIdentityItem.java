package dev.tc4port.thaumcraft.api.focus;

import java.util.List;
import java.util.Map;
import java.util.Objects;
import net.minecraft.world.item.ItemStack;

/**
 * Owner-class state adapter for a non-stackable addon Focus item. TC stores
 * the complete stack and never asks an addon to expose its private data
 * component type. Implementing items must have a maximum stack size of one.
 */
public interface FocusIdentityItem {

    int MAX_SELECTION_DISCRIMINATOR_LENGTH = 512;

    FocusId focusId(ItemStack stack);

    /**
     * Stable, process-independent owner projection that distinguishes two
     * carriers with otherwise identical public focus state. Keep it empty
     * when no private state affects which physical carrier the user selects.
     */
    default String focusSelectionDiscriminator(ItemStack stack) {
        return "";
    }

    default FocusStateView focusState(ItemStack stack) {
        return new FocusStateView(Objects.requireNonNull(focusId(stack), "focusId"), List.of(), Map.of());
    }

    /**
     * Returns a count-one copy carrying {@code state}. Implementations that
     * support persistent properties/upgrades override this method and update
     * only their own components.
     */
    default ItemStack withFocusState(ItemStack stack, FocusStateView state) {
        FocusStateView current = focusState(stack);
        if (!current.equals(state)) {
            throw new UnsupportedOperationException("This focus item exposes read-only state");
        }
        return stack.copyWithCount(1);
    }
}
