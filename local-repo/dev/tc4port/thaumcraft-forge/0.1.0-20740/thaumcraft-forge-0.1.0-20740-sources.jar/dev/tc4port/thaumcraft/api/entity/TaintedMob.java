package dev.tc4port.thaumcraft.api.entity;

/**
 * Marks an entity as tainted for flux-taint healing, target exclusion and
 * death-conversion rules.
 */
public interface TaintedMob {
}
