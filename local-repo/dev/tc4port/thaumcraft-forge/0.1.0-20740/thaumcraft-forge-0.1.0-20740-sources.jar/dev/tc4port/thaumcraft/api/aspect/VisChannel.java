package dev.tc4port.thaumcraft.api.aspect;

import com.mojang.serialization.Codec;
import com.mojang.serialization.DataResult;
import java.util.Arrays;
import java.util.Optional;

/**
 * The six fixed aspects that can be stored and consumed as wand vis.
 */
public enum VisChannel {

    AER(0, "aer"),
    TERRA(1, "terra"),
    IGNIS(2, "ignis"),
    AQUA(3, "aqua"),
    ORDO(4, "ordo"),
    PERDITIO(5, "perditio");

    public static final Codec<VisChannel> CODEC = Codec.STRING.comapFlatMap(VisChannel::decode, channel -> channel.aspectId().serialized());

    private final int index;

    private final AspectId aspectId;

    VisChannel(int index, String id) {
        this.index = index;
        this.aspectId = AspectId.parse(id);
    }

    public int index() {
        return this.index;
    }

    public AspectId aspectId() {
        return this.aspectId;
    }

    public static Optional<VisChannel> fromIndex(int index) {
        return Arrays.stream(values()).filter(channel -> channel.index == index).findFirst();
    }

    public static Optional<VisChannel> fromAspectId(AspectId id) {
        return Arrays.stream(values()).filter(channel -> channel.aspectId().equals(id)).findFirst();
    }

    private static DataResult<VisChannel> decode(String value) {
        try {
            return fromAspectId(AspectId.parse(value)).map(DataResult::success).orElseGet(() -> DataResult.error(() -> "Unknown vis channel: " + value));
        } catch (RuntimeException exception) {
            return DataResult.error(() -> "Invalid vis channel '" + value + "': " + exception.getMessage());
        }
    }
}
