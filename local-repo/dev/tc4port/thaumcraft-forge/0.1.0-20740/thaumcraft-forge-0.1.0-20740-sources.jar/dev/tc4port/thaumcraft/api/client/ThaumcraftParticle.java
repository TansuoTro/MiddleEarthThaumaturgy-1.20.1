package dev.tc4port.thaumcraft.api.client;

import net.minecraft.resources.ResourceLocation;

/**
 * Every registered TC particle. Use particleType for native packet emission or
 * spawnParticle on the client. Provider arguments are documented in CLIENT_EFFECTS_API.md;
 * they are not universally velocity (some encode RGB, destinations or entity IDs).
 * Configurable named methods on ThaumcraftClientEffectsApi avoid those encodings.
 */
public enum ThaumcraftParticle {

    WISP_MOTE("wisp_mote"),
    WISP_BURST("wisp_burst"),
    SPARKLE("sparkle"),
    DARK_SPARKLE("dark_sparkle"),
    TAINT_SWARM("taint_swarm"),
    TAINT_SPLASH("taint_splash"),
    TAINT_SPLOOSH("taint_sploosh"),
    TAINT_LAND_SPLASH("taint_land_splash"),
    TAINT_DROPLET("taint_droplet"),
    THAUMIC_SLIME_SPLASH("thaumic_slime_splash"),
    ALUMENTUM_MOTE("alumentum_mote"),
    SCAN_RUNE("scan_rune"),
    INFUSION_RUNE("infusion_rune"),
    SHOCK_SPARK_0("shock_spark_0"),
    SHOCK_SPARK_1("shock_spark_1"),
    SHOCK_SPARK_2("shock_spark_2"),
    FROST_SHARD_DEBRIS("frost_shard_debris"),
    DESTINATION_WISP_MAGENTA("destination_wisp_magenta"),
    DESTINATION_WISP_BLUE("destination_wisp_blue"),
    DESTINATION_WISP_GREEN("destination_wisp_green"),
    DESTINATION_WISP_DARK("destination_wisp_dark"),
    PALETTE_WISP("palette_wisp"),
    NODE_JAR_FORMATION("node_jar_formation"),
    FOCAL_MANIPULATOR_SPARKLE("focal_manipulator_sparkle"),
    BORE_SPARKLE("bore_sparkle"),
    INFUSION_SPARKLE("infusion_sparkle"),
    INFUSION_XP_SPARKLE("infusion_xp_sparkle"),
    ESSENTIA_TRAIL("essentia_trail"),
    CRUCIBLE_BUBBLE("crucible_bubble"),
    ADVANCED_FURNACE_BUBBLE("advanced_furnace_bubble"),
    TUBE_VENT("tube_vent"),
    VIS_SPARKLE("vis_sparkle"),
    LIFTER_SPARKLE("lifter_sparkle"),
    FIRE_BAT_SPARK("fire_bat_spark"),
    SMOKE_SPIRAL("smoke_spiral"),
    WARDEN_SMOKE_SPIRAL("warden_smoke_spiral"),
    ELDRITCH_WISP("eldritch_wisp"),
    ELDRITCH_ARC_SPARKLE("eldritch_arc_sparkle"),
    CHAMPION_GENERIC("champion_generic"),
    CHAMPION_SPARK("champion_spark"),
    ELDRITCH_LOCK_SPARK("eldritch_lock_spark"),
    TARGETED_ELDRITCH_WISP("targeted_eldritch_wisp"),
    RUNED_STONE_RUNE("runed_stone_rune"),
    TEMPORARY_HOLE_SPARKLE("temporary_hole_sparkle"),
    WARD_HIT("ward_hit");

    private final String path;

    ThaumcraftParticle(String path) {
        this.path = path;
    }

    public ResourceLocation id() {
        return java.util.Objects.requireNonNull(ResourceLocation.tryBuild("thaumcraft", path));
    }

    /**
     * Side-neutral native type lookup, usable with ServerLevel.sendParticles.
     */
    public net.minecraft.core.particles.SimpleParticleType type() {
        return switch(this) {
            case WISP_MOTE ->
                dev.tc4port.thaumcraft.registry.TCParticles.WISP_MOTE.get();
            case WISP_BURST ->
                dev.tc4port.thaumcraft.registry.TCParticles.WISP_BURST.get();
            case SPARKLE ->
                dev.tc4port.thaumcraft.registry.TCParticles.SPARKLE.get();
            case DARK_SPARKLE ->
                dev.tc4port.thaumcraft.registry.TCParticles.DARK_SPARKLE.get();
            case TAINT_SWARM ->
                dev.tc4port.thaumcraft.registry.TCParticles.TAINT_SWARM.get();
            case TAINT_SPLASH ->
                dev.tc4port.thaumcraft.registry.TCParticles.TAINT_SPLASH.get();
            case TAINT_SPLOOSH ->
                dev.tc4port.thaumcraft.registry.TCParticles.TAINT_SPLOOSH.get();
            case TAINT_LAND_SPLASH ->
                dev.tc4port.thaumcraft.registry.TCParticles.TAINT_LAND_SPLASH.get();
            case TAINT_DROPLET ->
                dev.tc4port.thaumcraft.registry.TCParticles.TAINT_DROPLET.get();
            case THAUMIC_SLIME_SPLASH ->
                dev.tc4port.thaumcraft.registry.TCParticles.THAUMIC_SLIME_SPLASH.get();
            case ALUMENTUM_MOTE ->
                dev.tc4port.thaumcraft.registry.TCParticles.ALUMENTUM_MOTE.get();
            case SCAN_RUNE ->
                dev.tc4port.thaumcraft.registry.TCParticles.SCAN_RUNE.get();
            case INFUSION_RUNE ->
                dev.tc4port.thaumcraft.registry.TCParticles.INFUSION_RUNE.get();
            case SHOCK_SPARK_0 ->
                dev.tc4port.thaumcraft.registry.TCParticles.SHOCK_SPARK_0.get();
            case SHOCK_SPARK_1 ->
                dev.tc4port.thaumcraft.registry.TCParticles.SHOCK_SPARK_1.get();
            case SHOCK_SPARK_2 ->
                dev.tc4port.thaumcraft.registry.TCParticles.SHOCK_SPARK_2.get();
            case FROST_SHARD_DEBRIS ->
                dev.tc4port.thaumcraft.registry.TCParticles.FROST_SHARD_DEBRIS.get();
            case DESTINATION_WISP_MAGENTA ->
                dev.tc4port.thaumcraft.registry.TCParticles.DESTINATION_WISP_MAGENTA.get();
            case DESTINATION_WISP_BLUE ->
                dev.tc4port.thaumcraft.registry.TCParticles.DESTINATION_WISP_BLUE.get();
            case DESTINATION_WISP_GREEN ->
                dev.tc4port.thaumcraft.registry.TCParticles.DESTINATION_WISP_GREEN.get();
            case DESTINATION_WISP_DARK ->
                dev.tc4port.thaumcraft.registry.TCParticles.DESTINATION_WISP_DARK.get();
            case PALETTE_WISP ->
                dev.tc4port.thaumcraft.registry.TCParticles.PALETTE_WISP.get();
            case NODE_JAR_FORMATION ->
                dev.tc4port.thaumcraft.registry.TCParticles.NODE_JAR_FORMATION.get();
            case FOCAL_MANIPULATOR_SPARKLE ->
                dev.tc4port.thaumcraft.registry.TCParticles.FOCAL_MANIPULATOR_SPARKLE.get();
            case BORE_SPARKLE ->
                dev.tc4port.thaumcraft.registry.TCParticles.BORE_SPARKLE.get();
            case INFUSION_SPARKLE ->
                dev.tc4port.thaumcraft.registry.TCParticles.INFUSION_SPARKLE.get();
            case INFUSION_XP_SPARKLE ->
                dev.tc4port.thaumcraft.registry.TCParticles.INFUSION_XP_SPARKLE.get();
            case ESSENTIA_TRAIL ->
                dev.tc4port.thaumcraft.registry.TCParticles.ESSENTIA_TRAIL.get();
            case CRUCIBLE_BUBBLE ->
                dev.tc4port.thaumcraft.registry.TCParticles.CRUCIBLE_BUBBLE.get();
            case ADVANCED_FURNACE_BUBBLE ->
                dev.tc4port.thaumcraft.registry.TCParticles.ADVANCED_FURNACE_BUBBLE.get();
            case TUBE_VENT ->
                dev.tc4port.thaumcraft.registry.TCParticles.TUBE_VENT.get();
            case VIS_SPARKLE ->
                dev.tc4port.thaumcraft.registry.TCParticles.VIS_SPARKLE.get();
            case LIFTER_SPARKLE ->
                dev.tc4port.thaumcraft.registry.TCParticles.LIFTER_SPARKLE.get();
            case FIRE_BAT_SPARK ->
                dev.tc4port.thaumcraft.registry.TCParticles.FIRE_BAT_SPARK.get();
            case SMOKE_SPIRAL ->
                dev.tc4port.thaumcraft.registry.TCParticles.SMOKE_SPIRAL.get();
            case WARDEN_SMOKE_SPIRAL ->
                dev.tc4port.thaumcraft.registry.TCParticles.WARDEN_SMOKE_SPIRAL.get();
            case ELDRITCH_WISP ->
                dev.tc4port.thaumcraft.registry.TCParticles.ELDRITCH_WISP.get();
            case ELDRITCH_ARC_SPARKLE ->
                dev.tc4port.thaumcraft.registry.TCParticles.ELDRITCH_ARC_SPARKLE.get();
            case CHAMPION_GENERIC ->
                dev.tc4port.thaumcraft.registry.TCParticles.CHAMPION_GENERIC.get();
            case CHAMPION_SPARK ->
                dev.tc4port.thaumcraft.registry.TCParticles.CHAMPION_SPARK.get();
            case ELDRITCH_LOCK_SPARK ->
                dev.tc4port.thaumcraft.registry.TCParticles.ELDRITCH_LOCK_SPARK.get();
            case TARGETED_ELDRITCH_WISP ->
                dev.tc4port.thaumcraft.registry.TCParticles.TARGETED_ELDRITCH_WISP.get();
            case RUNED_STONE_RUNE ->
                dev.tc4port.thaumcraft.registry.TCParticles.RUNED_STONE_RUNE.get();
            case TEMPORARY_HOLE_SPARKLE ->
                dev.tc4port.thaumcraft.registry.TCParticles.TEMPORARY_HOLE_SPARKLE.get();
            case WARD_HIT ->
                dev.tc4port.thaumcraft.registry.TCParticles.WARD_HIT.get();
        };
    }
}
