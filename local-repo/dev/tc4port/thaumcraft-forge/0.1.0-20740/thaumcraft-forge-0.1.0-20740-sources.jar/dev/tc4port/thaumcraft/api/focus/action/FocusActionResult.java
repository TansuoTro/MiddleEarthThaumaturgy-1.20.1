package dev.tc4port.thaumcraft.api.focus.action;

public enum FocusActionResult {

    PASS, SUCCESS, START_USING, STOP_USING, FAILED
}
