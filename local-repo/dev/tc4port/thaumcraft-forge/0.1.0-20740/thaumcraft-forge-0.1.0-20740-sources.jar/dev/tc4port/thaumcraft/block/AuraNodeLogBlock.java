package dev.tc4port.thaumcraft.block;

import com.mojang.serialization.MapCodec;
import dev.tc4port.thaumcraft.api.node.AuraNodeState;
import dev.tc4port.thaumcraft.block.entity.AuraNodeBlockEntity;
import dev.tc4port.thaumcraft.registry.TCBlockEntities;
import dev.tc4port.thaumcraft.worldgen.AuraNodeFactory;
import java.util.Optional;
import java.util.UUID;
import javax.annotation.Nullable;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.RotatedPillarBlock;
import net.minecraft.world.level.block.Rotation;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityTicker;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.EnumProperty;
import dev.tc4port.thaumcraft.nativeimpl.ClientExtensionTarget;
import dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.level.pathfinder.PathComputationType;
import net.minecraft.world.phys.HitResult;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.Explosion;

/**
 * Silverwood knot containing a pure aura node.
 *
 * <p>TC4 represented this as metadata 2 of the magical-log block. A dedicated
 * block is the lossless modern equivalent: it keeps normal log collision and
 * axis state while hosting the same persistent node data as a free aura
 * node.</p>
 */
public final class AuraNodeLogBlock extends net.minecraft.world.level.block.BaseEntityBlock implements dev.tc4port.thaumcraft.nativeimpl.ClientExtensionTarget {

    // Forge calls initializeClient from the native superclass constructor. Do not add a field initializer.
    private java.util.function.Consumer<net.minecraftforge.client.extensions.common.IClientBlockExtensions> platform$clientInstaller;

    public static final MapCodec<AuraNodeLogBlock> CODEC = AuraNodeLogBlock.native$BlockCodecPlatform$simple(AuraNodeLogBlock::new);

    public static final EnumProperty<Direction.Axis> AXIS = BlockStateProperties.AXIS;

    public AuraNodeLogBlock(BlockBehaviour.Properties properties) {
        this(properties, properties, true);
    }

    protected MapCodec<AuraNodeLogBlock> codec() {
        return CODEC;
    }

    @Nullable
    @Override
    public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        return new AuraNodeBlockEntity(pos, state);
    }

    @Override
    public void setPlacedBy(Level level, BlockPos pos, BlockState state, @Nullable LivingEntity placer, ItemStack stack) {
        super.setPlacedBy(level, pos, state, placer, stack);
        if (placer instanceof Player && level instanceof ServerLevel serverLevel && level.getBlockEntity(pos) instanceof AuraNodeBlockEntity node) {
            // Use the natural host's biome, environment and node-generation rules.
            AuraNodeState generated = AuraNodeFactory.create(serverLevel, pos, serverLevel.getRandom(), true, false, false);
            // A newly placed node must be scanned again, even at a reused position.
            node.setNodeState(generated.withInstanceId(Optional.of(UUID.randomUUID())));
        }
    }

    @Override
    public RenderShape getRenderShape(BlockState state) {
        return RenderShape.MODEL;
    }

    @Nullable
    @Override
    public <T extends BlockEntity> BlockEntityTicker<T> getTicker(Level level, BlockState state, BlockEntityType<T> type) {
        return createTickerHelper(type, TCBlockEntities.AURA_NODE.get(), level.isClientSide ? AuraNodeBlockEntity::clientTick : AuraNodeBlockEntity::serverTick);
    }

    @Override
    public BlockState rotate(BlockState state, Rotation rotation) {
        return RotatedPillarBlock.rotatePillar(state, rotation);
    }

    @Override
    public BlockState getStateForPlacement(BlockPlaceContext context) {
        return this.defaultBlockState().setValue(AXIS, context.getClickedFace().getAxis());
    }

    @Override
    public int getFlammability(BlockState state, BlockGetter level, BlockPos pos, Direction face) {
        return 5;
    }

    @Override
    public int getFireSpreadSpeed(BlockState state, BlockGetter level, BlockPos pos, Direction face) {
        return 5;
    }

    public BlockState beforePlayerDestroy(Level level, BlockPos pos, BlockState state, Player player) {
        // Creative destruction skips native block loot; preserve node harvest rewards
        // by evaluating the same table here only for that skipped branch.
        if (player.isCreative() && level instanceof net.minecraft.server.level.ServerLevel) {
            net.minecraft.world.level.block.Block.dropResources(state, level, pos, level.getBlockEntity(pos), player, player.getMainHandItem());
        }
        return (switch(0) {
            default ->
                {
                    net.minecraft.world.level.Level native$bodyOperand$5714 = level;
                    net.minecraft.core.BlockPos native$bodyOperand$5715 = pos;
                    net.minecraft.world.level.block.state.BlockState native$bodyOperand$5716 = state;
                    net.minecraft.world.entity.player.Player native$bodyOperand$5717 = player;
                    net.minecraft.world.level.block.state.BlockState native$bodyResult$5718 = null;
                    native$bodyReturn$5719: {
                        if (true) {
                            super.playerWillDestroy(native$bodyOperand$5714, native$bodyOperand$5715, native$bodyOperand$5716, native$bodyOperand$5717);
                            {
                                native$bodyResult$5718 = native$bodyOperand$5716;
                                break native$bodyReturn$5719;
                            }
                        }
                    }
                    yield native$bodyResult$5718;
                }
        });
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(AXIS);
    }

    @Override
    public java.util.List<net.minecraft.world.item.ItemStack> getDrops(BlockState state, net.minecraft.world.level.storage.loot.LootParams.Builder params) {
        params.withParameter(net.minecraft.world.level.storage.loot.parameters.LootContextParams.BLOCK_STATE, state);
        dev.tc4port.thaumcraft.loot.NodeLoot.prepare(params);
        return super.getDrops(state, params);
    }

    private AuraNodeLogBlock(net.minecraft.world.level.block.state.BlockBehaviour.Properties native$NativeEntityBlock$arg0, BlockBehaviour.Properties properties, boolean native$NativeEntityBlock$captured) {
        super(native$NativeEntityBlock$arg0);
        this.registerDefaultState(this.defaultBlockState().setValue(AXIS, Direction.Axis.Y));
    }

    @Override
    public void initializeClient(java.util.function.Consumer<net.minecraftforge.client.extensions.common.IClientBlockExtensions> installer) {
        platform$clientInstaller = installer;
        super.initializeClient(installer);
    }

    @Override
    public void platform$clientExtension(Object extension) {
        java.util.Objects.requireNonNull(platform$clientInstaller, "Forge initializeClient must run before client extension registration").accept((net.minecraftforge.client.extensions.common.IClientBlockExtensions) extension);
    }

    @Override
    public InteractionResult use(BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
        ItemUseResult result = (switch(0) {
            default ->
                {
                    net.minecraft.world.item.ItemStack native$bodyOperand$4229 = player.getItemInHand(hand);
                    net.minecraft.world.level.block.state.BlockState native$bodyOperand$4230 = state;
                    net.minecraft.world.level.Level native$bodyOperand$4231 = level;
                    net.minecraft.core.BlockPos native$bodyOperand$4232 = pos;
                    net.minecraft.world.entity.player.Player native$bodyOperand$4233 = player;
                    net.minecraft.world.InteractionHand native$bodyOperand$4234 = hand;
                    net.minecraft.world.phys.BlockHitResult native$bodyOperand$4235 = hit;
                    dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult native$bodyResult$4236 = null;
                    native$bodyReturn$4237: {
                        if (true) {
                            {
                                native$bodyResult$4236 = dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
                                break native$bodyReturn$4237;
                            }
                        }
                    }
                    yield native$bodyResult$4236;
                }
        });
        return result == ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION ? (hand == InteractionHand.MAIN_HAND ? (switch(0) {
            default ->
                {
                    net.minecraft.world.level.block.state.BlockState native$bodyOperand$3543 = state;
                    net.minecraft.world.level.Level native$bodyOperand$3544 = level;
                    net.minecraft.core.BlockPos native$bodyOperand$3545 = pos;
                    net.minecraft.world.entity.player.Player native$bodyOperand$3546 = player;
                    net.minecraft.world.phys.BlockHitResult native$bodyOperand$3547 = hit;
                    net.minecraft.world.InteractionResult native$bodyResult$3548 = null;
                    native$bodyReturn$3549: {
                        if (true) {
                            {
                                native$bodyResult$3548 = super.use(native$bodyOperand$3543, native$bodyOperand$3544, native$bodyOperand$3545, native$bodyOperand$3546, net.minecraft.world.InteractionHand.MAIN_HAND, native$bodyOperand$3547);
                                break native$bodyReturn$3549;
                            }
                        }
                    }
                    yield native$bodyResult$3548;
                }
        }) : InteractionResult.PASS) : result.result();
    }

    protected ItemUseResult interactWithItem(ItemStack stack, BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
        return dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
    }

    protected InteractionResult interactWithoutItem(BlockState state, Level level, BlockPos pos, Player player, BlockHitResult hit) {
        return super.use(state, level, pos, player, net.minecraft.world.InteractionHand.MAIN_HAND, hit);
    }

    @Override
    public void playerWillDestroy(Level level, BlockPos pos, BlockState state, Player player) {
        {
            net.minecraft.world.level.Level native$bodyOperand$5720 = level;
            net.minecraft.core.BlockPos native$bodyOperand$5721 = pos;
            net.minecraft.world.level.block.state.BlockState native$bodyOperand$5722 = state;
            net.minecraft.world.entity.player.Player native$bodyOperand$5723 = player;
            net.minecraft.world.level.block.state.BlockState native$bodyResult$5724 = null;
            native$bodyReturn$5725: {
                if (true) {
                    // Creative destruction skips native block loot; preserve node harvest rewards
                    // by evaluating the same table here only for that skipped branch.
                    if (native$bodyOperand$5723.isCreative() && native$bodyOperand$5720 instanceof net.minecraft.server.level.ServerLevel) {
                        net.minecraft.world.level.block.Block.dropResources(native$bodyOperand$5722, native$bodyOperand$5720, native$bodyOperand$5721, native$bodyOperand$5720.getBlockEntity(native$bodyOperand$5721), native$bodyOperand$5723, native$bodyOperand$5723.getMainHandItem());
                    }
                    {
                        native$bodyResult$5724 = (switch(0) {
                            default ->
                                {
                                    net.minecraft.world.level.Level native$bodyOperand$8985 = native$bodyOperand$5720;
                                    net.minecraft.core.BlockPos native$bodyOperand$8986 = native$bodyOperand$5721;
                                    net.minecraft.world.level.block.state.BlockState native$bodyOperand$8987 = native$bodyOperand$5722;
                                    net.minecraft.world.entity.player.Player native$bodyOperand$8988 = native$bodyOperand$5723;
                                    net.minecraft.world.level.block.state.BlockState native$bodyResult$8989 = null;
                                    native$bodyReturn$8990: {
                                        if (true) {
                                            super.playerWillDestroy(native$bodyOperand$8985, native$bodyOperand$8986, native$bodyOperand$8987, native$bodyOperand$8988);
                                            {
                                                native$bodyResult$8989 = native$bodyOperand$8987;
                                                break native$bodyReturn$8990;
                                            }
                                        }
                                    }
                                    yield native$bodyResult$8989;
                                }
                        });
                        break native$bodyReturn$5725;
                    }
                }
            }
        }
    }

    protected boolean survivesSharedExplosion() {
        return false;
    }

    public int getExpDrop(net.minecraft.world.level.block.state.BlockState native$callbackInput$1050, net.minecraft.world.level.LevelReader native$callbackInput$1051, net.minecraft.util.RandomSource native$callbackInput$1052, net.minecraft.core.BlockPos native$callbackInput$1053, int native$callbackInput$1054, int native$callbackInput$1055) {
        net.minecraft.world.level.block.state.BlockState state = native$callbackInput$1050;
        net.minecraft.util.RandomSource random = native$callbackInput$1052;
        return 0;
    }

    @Override
    public void onBlockExploded(BlockState state, Level level, BlockPos pos, Explosion explosion) {
        if (!(switch(0) {
            default ->
                {
                    boolean native$bodyResult$5231 = false;
                    native$bodyReturn$5232: {
                        if (true) {
                            {
                                native$bodyResult$5231 = false;
                                break native$bodyReturn$5232;
                            }
                        }
                    }
                    yield native$bodyResult$5231;
                }
        }))
            super.onBlockExploded(state, level, pos, explosion);
    }

    @Override
    public boolean canDropFromExplosion(BlockState state, BlockGetter level, BlockPos pos, Explosion explosion) {
        return !(switch(0) {
            default ->
                {
                    boolean native$bodyResult$4238 = false;
                    native$bodyReturn$4239: {
                        if (true) {
                            {
                                native$bodyResult$4238 = false;
                                break native$bodyReturn$4239;
                            }
                        }
                    }
                    yield native$bodyResult$4238;
                }
        }) && super.canDropFromExplosion(state, level, pos, explosion);
    }

    static private <B extends net.minecraft.world.level.block.Block> com.mojang.serialization.MapCodec<B> native$BlockCodecPlatform$simple(java.util.function.Function<net.minecraft.world.level.block.state.BlockBehaviour.Properties, B> factory) {
        // Vanilla 1.21's Properties codec is a unit codec. Retain that schema for shared block definitions.
        return com.mojang.serialization.codecs.RecordCodecBuilder.mapCodec(instance -> instance.group(com.mojang.serialization.Codec.unit(net.minecraft.world.level.block.state.BlockBehaviour.Properties::of).fieldOf("properties").forGetter((B block) -> net.minecraft.world.level.block.state.BlockBehaviour.Properties.copy(block))).apply(instance, factory));
    }
}
