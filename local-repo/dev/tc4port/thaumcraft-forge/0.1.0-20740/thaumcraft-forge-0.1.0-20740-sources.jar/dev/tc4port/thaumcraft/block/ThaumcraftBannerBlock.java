package dev.tc4port.thaumcraft.block;

import dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult;
import dev.tc4port.thaumcraft.api.aspect.AspectId;
import com.mojang.serialization.MapCodec;
import dev.tc4port.thaumcraft.block.entity.ThaumcraftBannerBlockEntity;
import dev.tc4port.thaumcraft.data.AspectStackData;
import dev.tc4port.thaumcraft.item.EssencePhialItem;
import dev.tc4port.thaumcraft.state.TCItemState;
import javax.annotation.Nullable;
import net.minecraft.world.phys.HitResult;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Mirror;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.Rotation;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.world.level.block.state.properties.IntegerProperty;
import net.minecraft.world.level.block.state.properties.RotationSegment;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;
import dev.tc4port.thaumcraft.nativeimpl.ClientExtensionTarget;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.level.pathfinder.PathComputationType;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.Explosion;

/**
 * TC4 banner: one block identity with 16 item colors, sixteen rotations and
 * the original standing/wall placement modes.
 */
public final class ThaumcraftBannerBlock extends net.minecraft.world.level.block.BaseEntityBlock implements dev.tc4port.thaumcraft.nativeimpl.ClientExtensionTarget {

    // Forge calls initializeClient from the native superclass constructor. Do not add a field initializer.
    private java.util.function.Consumer<net.minecraftforge.client.extensions.common.IClientBlockExtensions> platform$clientInstaller;

    @Override
    public void setPlacedBy(Level level, BlockPos pos, BlockState state, @javax.annotation.Nullable net.minecraft.world.entity.LivingEntity placer, ItemStack stack) {
        super.setPlacedBy(level, pos, state, placer, stack);
        if (level.getBlockEntity(pos) instanceof ThaumcraftBannerBlockEntity placed) {
            placed.applyComponentsFromItemStack(stack);
        }
    }

    public static final MapCodec<ThaumcraftBannerBlock> CODEC = ThaumcraftBannerBlock.native$BlockCodecPlatform$simple(ThaumcraftBannerBlock::new);

    public static final IntegerProperty ROTATION = BlockStateProperties.ROTATION_16;

    public static final BooleanProperty WALL = BooleanProperty.create("wall");

    private static final VoxelShape STANDING_SHAPE = Block.box(5.28, 0.0, 5.28, 10.56, 32.0, 10.56);

    private static final VoxelShape NORTH_SHAPE = Block.box(0.0, 0.0, 0.0, 16.0, 32.0, 4.0);

    private static final VoxelShape WEST_SHAPE = Block.box(12.0, 0.0, 0.0, 16.0, 32.0, 16.0);

    private static final VoxelShape SOUTH_SHAPE = Block.box(0.0, 0.0, 12.0, 16.0, 32.0, 16.0);

    private static final VoxelShape EAST_SHAPE = Block.box(0.0, 0.0, 0.0, 4.0, 32.0, 16.0);

    public ThaumcraftBannerBlock(BlockBehaviour.Properties properties) {
        this(properties, properties, true);
    }

    protected MapCodec<ThaumcraftBannerBlock> codec() {
        return CODEC;
    }

    @Nullable
    @Override
    public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        return new ThaumcraftBannerBlockEntity(pos, state);
    }

    @Override
    public RenderShape getRenderShape(BlockState state) {
        return RenderShape.INVISIBLE;
    }

    @Nullable
    @Override
    public BlockState getStateForPlacement(BlockPlaceContext context) {
        Direction side = context.getClickedFace();
        if (side.getAxis().isVertical()) {
            return this.defaultBlockState().setValue(ROTATION, RotationSegment.convertToSegment(context.getRotation() + 180.0F));
        }
        return this.defaultBlockState().setValue(WALL, true).setValue(ROTATION, wallRotation(side));
    }

    public static void placeAt(LevelAccessor level, BlockPos pos, BlockState state, int flags) {
        level.setBlock(pos, state, flags);
    }

    @Override
    public VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
        if (!state.getValue(WALL)) {
            return STANDING_SHAPE;
        }
        return switch(state.getValue(ROTATION)) {
            case 4 ->
                WEST_SHAPE;
            case 8 ->
                SOUTH_SHAPE;
            case 12 ->
                EAST_SHAPE;
            default ->
                NORTH_SHAPE;
        };
    }

    @Override
    public VoxelShape getCollisionShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
        return Shapes.empty();
    }

    protected ItemUseResult interactWithItem(ItemStack stack, BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hitResult) {
        if (!(level.getBlockEntity(pos) instanceof dev.tc4port.thaumcraft.block.entity.ThaumcraftBannerBlockEntity banner)) {
            return dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
        }
        if (player.isShiftKeyDown()) {
            return dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
        }
        if (!(stack.getItem() instanceof dev.tc4port.thaumcraft.item.EssencePhialItem)) {
            return dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
        }
        dev.tc4port.thaumcraft.data.AspectStackData aspects = (switch(0) {
            default ->
                {
                    dev.tc4port.thaumcraft.api.data.ItemStateKey<dev.tc4port.thaumcraft.data.AspectStackData> native$receiver$534 = dev.tc4port.thaumcraft.state.TCItemState.ASPECTS;
                    net.minecraft.world.item.ItemStack native$argument$535 = stack;
                    java.util.Objects.requireNonNull(native$receiver$534);
                    yield dev.tc4port.thaumcraft.api.item.ItemStatePlatform.get(native$argument$535, native$receiver$534);
                }
        });
        if (!level.isClientSide && banner.color() >= 0) {
            if (aspects != null && !aspects.aspects().isEmpty()) {
                dev.tc4port.thaumcraft.api.aspect.AspectId aspect = aspects.aspects().keySet().iterator().next();
                banner.setAspect(aspect);
                stack.shrink(1);
            }
            playCloth(level, pos);
        }
        return dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.sidedSuccess(level.isClientSide);
    }

    protected InteractionResult interactWithoutItem(BlockState state, Level level, BlockPos pos, Player player, BlockHitResult hitResult) {
        if (player.isShiftKeyDown() && level.getBlockEntity(pos) instanceof dev.tc4port.thaumcraft.block.entity.ThaumcraftBannerBlockEntity banner && banner.color() >= 0 && !level.isClientSide) {
            banner.setAspect(null);
            playCloth(level, pos);
        }
        /* Metadata eight consumed every otherwise-unhandled activation. */
        return net.minecraft.world.InteractionResult.sidedSuccess(level.isClientSide);
    }

    @Override
    public ItemStack getCloneItemStack(BlockState state, HitResult target, net.minecraft.world.level.BlockGetter level, BlockPos pos, Player player) {
        return level.getBlockEntity(pos) instanceof ThaumcraftBannerBlockEntity banner ? banner.asItem() : super.getCloneItemStack(state, target, level, pos, player);
    }

    public BlockState beforePlayerDestroy(Level level, BlockPos pos, BlockState state, Player player) {
        if (!level.isClientSide && player.isCreative() && level.getBlockEntity(pos) instanceof dev.tc4port.thaumcraft.block.entity.ThaumcraftBannerBlockEntity banner) {
            net.minecraft.world.level.block.Block.dropResources(state, (net.minecraft.server.level.ServerLevel) level, pos, banner, player, player.getMainHandItem());
        }
        return (switch(0) {
            default ->
                {
                    net.minecraft.world.level.Level native$bodyOperand$6034 = level;
                    net.minecraft.core.BlockPos native$bodyOperand$6035 = pos;
                    net.minecraft.world.level.block.state.BlockState native$bodyOperand$6036 = state;
                    net.minecraft.world.entity.player.Player native$bodyOperand$6037 = player;
                    net.minecraft.world.level.block.state.BlockState native$bodyResult$6038 = null;
                    native$bodyReturn$6039: {
                        if (true) {
                            super.playerWillDestroy(native$bodyOperand$6034, native$bodyOperand$6035, native$bodyOperand$6036, native$bodyOperand$6037);
                            {
                                native$bodyResult$6038 = native$bodyOperand$6036;
                                break native$bodyReturn$6039;
                            }
                        }
                    }
                    yield native$bodyResult$6038;
                }
        });
    }

    @Override
    public BlockState rotate(BlockState state, Rotation rotation) {
        return state.setValue(ROTATION, rotation.rotate(state.getValue(ROTATION), 16));
    }

    @Override
    public BlockState mirror(BlockState state, Mirror mirror) {
        return state.setValue(ROTATION, mirror.mirror(state.getValue(ROTATION), 16));
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(ROTATION, WALL);
    }

    @Override
    public int getLightBlock(BlockState state, BlockGetter level, BlockPos pos) {
        return 0;
    }

    private static void playCloth(Level level, BlockPos pos) {
        level.playSound(null, pos, SoundEvents.WOOL_STEP, SoundSource.BLOCKS, 1.0F, 1.0F);
    }

    private static int wallRotation(Direction side) {
        return switch(side) {
            case NORTH ->
                8;
            case WEST ->
                4;
            case EAST ->
                12;
            default ->
                0;
        };
    }

    private ThaumcraftBannerBlock(net.minecraft.world.level.block.state.BlockBehaviour.Properties native$NativeEntityBlock$arg0, BlockBehaviour.Properties properties, boolean native$NativeEntityBlock$captured) {
        super(native$NativeEntityBlock$arg0);
        this.registerDefaultState(this.stateDefinition.any().setValue(ROTATION, 0).setValue(WALL, false));
    }

    @Override
    public void initializeClient(java.util.function.Consumer<net.minecraftforge.client.extensions.common.IClientBlockExtensions> installer) {
        platform$clientInstaller = installer;
        super.initializeClient(installer);
    }

    @Override
    public void platform$clientExtension(Object extension) {
        java.util.Objects.requireNonNull(platform$clientInstaller, "Forge initializeClient must run before client extension registration").accept((net.minecraftforge.client.extensions.common.IClientBlockExtensions) extension);
    }

    @Override
    public InteractionResult use(BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
        ItemUseResult result = (switch(0) {
            default ->
                {
                    net.minecraft.world.item.ItemStack native$bodyOperand$4775 = player.getItemInHand(hand);
                    net.minecraft.world.level.block.state.BlockState native$bodyOperand$4776 = state;
                    net.minecraft.world.level.Level native$bodyOperand$4777 = level;
                    net.minecraft.core.BlockPos native$bodyOperand$4778 = pos;
                    net.minecraft.world.entity.player.Player native$bodyOperand$4779 = player;
                    net.minecraft.world.InteractionHand native$bodyOperand$4780 = hand;
                    net.minecraft.world.phys.BlockHitResult native$bodyOperand$4781 = hit;
                    dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult native$bodyResult$4787 = null;
                    native$bodyReturn$4788: {
                        if (true) {
                            if (!(native$bodyOperand$4777.getBlockEntity(native$bodyOperand$4778) instanceof dev.tc4port.thaumcraft.block.entity.ThaumcraftBannerBlockEntity native$bodyBinding$4782)) {
                                {
                                    native$bodyResult$4787 = dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
                                    break native$bodyReturn$4788;
                                }
                            }
                            if (native$bodyOperand$4779.isShiftKeyDown()) {
                                {
                                    native$bodyResult$4787 = dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
                                    break native$bodyReturn$4788;
                                }
                            }
                            if (!(native$bodyOperand$4775.getItem() instanceof dev.tc4port.thaumcraft.item.EssencePhialItem)) {
                                {
                                    native$bodyResult$4787 = dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
                                    break native$bodyReturn$4788;
                                }
                            }
                            dev.tc4port.thaumcraft.data.AspectStackData native$bodyBinding$4783 = (switch(0) {
                                default ->
                                    {
                                        dev.tc4port.thaumcraft.api.data.ItemStateKey<dev.tc4port.thaumcraft.data.AspectStackData> native$bodyBinding$4784 = dev.tc4port.thaumcraft.state.TCItemState.ASPECTS;
                                        net.minecraft.world.item.ItemStack native$bodyBinding$4785 = native$bodyOperand$4775;
                                        java.util.Objects.requireNonNull(native$bodyBinding$4784);
                                        yield dev.tc4port.thaumcraft.api.item.ItemStatePlatform.get(native$bodyBinding$4785, native$bodyBinding$4784);
                                    }
                            });
                            if (!native$bodyOperand$4777.isClientSide && native$bodyBinding$4782.color() >= 0) {
                                if (native$bodyBinding$4783 != null && !native$bodyBinding$4783.aspects().isEmpty()) {
                                    dev.tc4port.thaumcraft.api.aspect.AspectId native$bodyBinding$4786 = native$bodyBinding$4783.aspects().keySet().iterator().next();
                                    native$bodyBinding$4782.setAspect(native$bodyBinding$4786);
                                    native$bodyOperand$4775.shrink(1);
                                }
                                playCloth(native$bodyOperand$4777, native$bodyOperand$4778);
                            }
                            {
                                native$bodyResult$4787 = dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.sidedSuccess(native$bodyOperand$4777.isClientSide);
                                break native$bodyReturn$4788;
                            }
                        }
                    }
                    yield native$bodyResult$4787;
                }
        });
        return result == ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION ? (hand == InteractionHand.MAIN_HAND ? (switch(0) {
            default ->
                {
                    net.minecraft.world.level.block.state.BlockState native$bodyOperand$3902 = state;
                    net.minecraft.world.level.Level native$bodyOperand$3903 = level;
                    net.minecraft.core.BlockPos native$bodyOperand$3904 = pos;
                    net.minecraft.world.entity.player.Player native$bodyOperand$3905 = player;
                    net.minecraft.world.phys.BlockHitResult native$bodyOperand$3906 = hit;
                    net.minecraft.world.InteractionResult native$bodyResult$3908 = null;
                    native$bodyReturn$3909: {
                        if (true) {
                            if (native$bodyOperand$3905.isShiftKeyDown() && native$bodyOperand$3903.getBlockEntity(native$bodyOperand$3904) instanceof dev.tc4port.thaumcraft.block.entity.ThaumcraftBannerBlockEntity native$bodyBinding$3907 && native$bodyBinding$3907.color() >= 0 && !native$bodyOperand$3903.isClientSide) {
                                native$bodyBinding$3907.setAspect(null);
                                playCloth(native$bodyOperand$3903, native$bodyOperand$3904);
                            }
                            {
                                native$bodyResult$3908 = net.minecraft.world.InteractionResult.sidedSuccess(native$bodyOperand$3903.isClientSide);
                                break native$bodyReturn$3909;
                            }
                        }
                    }
                    yield native$bodyResult$3908;
                }
        }) : InteractionResult.PASS) : result.result();
    }

    @Override
    public void playerWillDestroy(Level level, BlockPos pos, BlockState state, Player player) {
        {
            net.minecraft.world.level.Level native$bodyOperand$6040 = level;
            net.minecraft.core.BlockPos native$bodyOperand$6041 = pos;
            net.minecraft.world.level.block.state.BlockState native$bodyOperand$6042 = state;
            net.minecraft.world.entity.player.Player native$bodyOperand$6043 = player;
            net.minecraft.world.level.block.state.BlockState native$bodyResult$6045 = null;
            native$bodyReturn$6046: {
                if (true) {
                    if (!native$bodyOperand$6040.isClientSide && native$bodyOperand$6043.isCreative() && native$bodyOperand$6040.getBlockEntity(native$bodyOperand$6041) instanceof dev.tc4port.thaumcraft.block.entity.ThaumcraftBannerBlockEntity native$bodyBinding$6044) {
                        net.minecraft.world.level.block.Block.dropResources(native$bodyOperand$6042, (net.minecraft.server.level.ServerLevel) native$bodyOperand$6040, native$bodyOperand$6041, native$bodyBinding$6044, native$bodyOperand$6043, native$bodyOperand$6043.getMainHandItem());
                    }
                    {
                        native$bodyResult$6045 = (switch(0) {
                            default ->
                                {
                                    net.minecraft.world.level.Level native$bodyOperand$9009 = native$bodyOperand$6040;
                                    net.minecraft.core.BlockPos native$bodyOperand$9010 = native$bodyOperand$6041;
                                    net.minecraft.world.level.block.state.BlockState native$bodyOperand$9011 = native$bodyOperand$6042;
                                    net.minecraft.world.entity.player.Player native$bodyOperand$9012 = native$bodyOperand$6043;
                                    net.minecraft.world.level.block.state.BlockState native$bodyResult$9013 = null;
                                    native$bodyReturn$9014: {
                                        if (true) {
                                            super.playerWillDestroy(native$bodyOperand$9009, native$bodyOperand$9010, native$bodyOperand$9011, native$bodyOperand$9012);
                                            {
                                                native$bodyResult$9013 = native$bodyOperand$9011;
                                                break native$bodyReturn$9014;
                                            }
                                        }
                                    }
                                    yield native$bodyResult$9013;
                                }
                        });
                        break native$bodyReturn$6046;
                    }
                }
            }
        }
    }

    protected boolean survivesSharedExplosion() {
        return false;
    }

    public int getExpDrop(net.minecraft.world.level.block.state.BlockState native$callbackInput$1050, net.minecraft.world.level.LevelReader native$callbackInput$1051, net.minecraft.util.RandomSource native$callbackInput$1052, net.minecraft.core.BlockPos native$callbackInput$1053, int native$callbackInput$1054, int native$callbackInput$1055) {
        net.minecraft.world.level.block.state.BlockState state = native$callbackInput$1050;
        net.minecraft.util.RandomSource random = native$callbackInput$1052;
        return 0;
    }

    @Override
    public void onBlockExploded(BlockState state, Level level, BlockPos pos, Explosion explosion) {
        if (!(switch(0) {
            default ->
                {
                    boolean native$bodyResult$5327 = false;
                    native$bodyReturn$5328: {
                        if (true) {
                            {
                                native$bodyResult$5327 = false;
                                break native$bodyReturn$5328;
                            }
                        }
                    }
                    yield native$bodyResult$5327;
                }
        }))
            super.onBlockExploded(state, level, pos, explosion);
    }

    @Override
    public boolean canDropFromExplosion(BlockState state, BlockGetter level, BlockPos pos, Explosion explosion) {
        return !(switch(0) {
            default ->
                {
                    boolean native$bodyResult$4789 = false;
                    native$bodyReturn$4790: {
                        if (true) {
                            {
                                native$bodyResult$4789 = false;
                                break native$bodyReturn$4790;
                            }
                        }
                    }
                    yield native$bodyResult$4789;
                }
        }) && super.canDropFromExplosion(state, level, pos, explosion);
    }

    static private <B extends net.minecraft.world.level.block.Block> com.mojang.serialization.MapCodec<B> native$BlockCodecPlatform$simple(java.util.function.Function<net.minecraft.world.level.block.state.BlockBehaviour.Properties, B> factory) {
        // Vanilla 1.21's Properties codec is a unit codec. Retain that schema for shared block definitions.
        return com.mojang.serialization.codecs.RecordCodecBuilder.mapCodec(instance -> instance.group(com.mojang.serialization.Codec.unit(net.minecraft.world.level.block.state.BlockBehaviour.Properties::of).fieldOf("properties").forGetter((B block) -> net.minecraft.world.level.block.state.BlockBehaviour.Properties.copy(block))).apply(instance, factory));
    }
}
