package dev.tc4port.thaumcraft.api.research;

public enum ResearchCompletionResult {

    COMPLETED, ALREADY_COMPLETE, UNKNOWN_RESEARCH, MISSING_PREREQUISITE, DENIED
}
