package dev.tc4port.thaumcraft.api.client;

import net.minecraft.client.model.HumanoidModel;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;

/**
 * Client-only casting poses for core wands and addon-owned wand renderers.
 */
public final class WandRenderApi {

    private WandRenderApi() {
    }

    /**
     * Returns the casting arm pose for an item client extension's getArmPose,
     * or null to leave the ordinary idle pose in place. Custom carriers use
     * NONE as their use animation; registering this pose keeps third-person
     * aiming independent of the native first-person bow charge animation.
     */
    public static HumanoidModel.ArmPose getArmPose(LivingEntity entity, InteractionHand hand, ItemStack stack) {
        return entity.isUsingItem() && entity.getUseItemRemainingTicks() > 0 && entity.getUsedItemHand() == hand && entity.getUseItem().is(stack.getItem()) ? HumanoidModel.ArmPose.BOW_AND_ARROW : null;
    }
}
