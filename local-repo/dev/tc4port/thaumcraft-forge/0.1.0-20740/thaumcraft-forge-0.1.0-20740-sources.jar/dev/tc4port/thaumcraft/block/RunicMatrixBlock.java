package dev.tc4port.thaumcraft.block;

import dev.tc4port.thaumcraft.common.MultiblockFormation;
import dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult;
import com.mojang.serialization.MapCodec;
import dev.tc4port.thaumcraft.api.ThaumcraftApiHelper;
import dev.tc4port.thaumcraft.api.aspect.VisAction;
import dev.tc4port.thaumcraft.api.aspect.VisPaymentResult;
import dev.tc4port.thaumcraft.block.entity.InfusionMatrixBlockEntity;
import dev.tc4port.thaumcraft.common.CompoundBlueprintCatalog;
import dev.tc4port.thaumcraft.common.PlayerKnowledgeService;
import dev.tc4port.thaumcraft.common.WandInteractionTarget;
import dev.tc4port.thaumcraft.common.WandVis;
import dev.tc4port.thaumcraft.api.wand.WandCarrierItem;
import dev.tc4port.thaumcraft.registry.TCBlockEntities;
import dev.tc4port.thaumcraft.registry.TCBlocks;
import dev.tc4port.thaumcraft.registry.TCSounds;
import javax.annotation.Nullable;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityTicker;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;
import dev.tc4port.thaumcraft.nativeimpl.ClientExtensionTarget;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.level.pathfinder.PathComputationType;
import net.minecraft.world.phys.HitResult;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.Explosion;

/**
 * Unformed runic matrix and the active infusion matrix share one block id,
 * as they did under BlockStoneDevice metadata 2.
 */
public final class RunicMatrixBlock extends net.minecraft.world.level.block.BaseEntityBlock implements WandInteractionTarget, dev.tc4port.thaumcraft.nativeimpl.ClientExtensionTarget {

    // Forge calls initializeClient from the native superclass constructor. Do not add a field initializer.
    private java.util.function.Consumer<net.minecraftforge.client.extensions.common.IClientBlockExtensions> platform$clientInstaller;

    public static final MapCodec<RunicMatrixBlock> CODEC = RunicMatrixBlock.native$BlockCodecPlatform$simple(RunicMatrixBlock::new);

    public RunicMatrixBlock(BlockBehaviour.Properties properties) {
        this(properties, properties, true);
    }

    protected MapCodec<RunicMatrixBlock> codec() {
        return CODEC;
    }

    @Nullable
    @Override
    public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        return new InfusionMatrixBlockEntity(pos, state);
    }

    @Nullable
    @Override
    public <T extends BlockEntity> BlockEntityTicker<T> getTicker(Level level, BlockState state, BlockEntityType<T> type) {
        return createTickerHelper(type, TCBlockEntities.INFUSION_MATRIX.get(), level.isClientSide ? InfusionMatrixBlockEntity::clientTick : InfusionMatrixBlockEntity::serverTick);
    }

    @Override
    public RenderShape getRenderShape(BlockState state) {
        return RenderShape.ENTITYBLOCK_ANIMATED;
    }

    @Override
    public VoxelShape getBlockSupportShape(BlockState state, BlockGetter level, BlockPos pos) {
        return Shapes.empty();
    }

    protected ItemUseResult interactWithItem(ItemStack stack, BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
        if (!(stack.getItem() instanceof dev.tc4port.thaumcraft.api.wand.WandCarrierItem) || !dev.tc4port.thaumcraft.common.CompoundBlueprintCatalog.isTrigger(dev.tc4port.thaumcraft.common.CompoundBlueprintCatalog.INFUSION_ALTAR, state) || !(level.getBlockEntity(pos) instanceof dev.tc4port.thaumcraft.block.entity.InfusionMatrixBlockEntity matrix)) {
            return dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
        }
        var blueprint = dev.tc4port.thaumcraft.common.CompoundBlueprintCatalog.require(dev.tc4port.thaumcraft.common.CompoundBlueprintCatalog.INFUSION_ALTAR);
        if (!dev.tc4port.thaumcraft.common.PlayerKnowledgeService.get(player).hasCompletedResearch(blueprint.research())) {
            return dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.FAIL;
        }
        if (!matrix.active()) {
            if (matrix.validLocation()) {
                if (!level.isClientSide) {
                    matrix.setActive(true);
                }
                player.swing(hand);
                return dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.sidedSuccess(level.isClientSide);
            }
            if (!validUnformedAltar(level, pos)) {
                return dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.FAIL;
            }
            var cost = dev.tc4port.thaumcraft.common.WandVis.craftingCost(stack, player, blueprint.aspects());
            if (dev.tc4port.thaumcraft.api.ThaumcraftApiHelper.consumeExactVisFromWand(stack, player, cost, dev.tc4port.thaumcraft.api.aspect.VisAction.SIMULATE) != dev.tc4port.thaumcraft.api.aspect.VisPaymentResult.AVAILABLE) {
                return dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.FAIL;
            }
            if (!level.isClientSide) {
                if (!dev.tc4port.thaumcraft.common.MultiblockFormation.convert((net.minecraft.server.level.ServerLevel) level, player, hit.getDirection(), stack, cost, () -> formAltar((net.minecraft.server.level.ServerLevel) level, pos), () -> {
                    matrix.setActive(true);
                    formationEffects((net.minecraft.server.level.ServerLevel) level, pos);
                })) {
                    return dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.FAIL;
                }
            }
            player.swing(hand);
            return dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.sidedSuccess(level.isClientSide);
        }
        if (!matrix.crafting()) {
            if (!level.isClientSide) {
                matrix.startCrafting(player);
            }
            player.swing(hand);
            return dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.sidedSuccess(level.isClientSide);
        }
        return dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.FAIL;
    }

    public static boolean validUnformedAltar(Level level, BlockPos matrix) {
        return CompoundBlueprintCatalog.matchesFormation(CompoundBlueprintCatalog.INFUSION_ALTAR, level, matrix.offset(-1, 0, -1));
    }

    private static boolean formAltar(ServerLevel level, BlockPos matrixPos) {
        for (int x : new int[] { -1, 1 }) {
            for (int z : new int[] { -1, 1 }) {
                InfusionPillarBlock.Orientation orientation = orientation(x, z);
                if (!level.setBlock(matrixPos.offset(x, -2, z), TCBlocks.INFUSION_PILLAR.get().defaultBlockState().setValue(InfusionPillarBlock.ORIENTATION, orientation), Block.UPDATE_ALL))
                    return false;
                if (!level.setBlock(matrixPos.offset(x, -1, z), TCBlocks.INFUSION_PILLAR_TOP.get().defaultBlockState(), Block.UPDATE_ALL))
                    return false;
            }
        }
        return true;
    }

    private static void formationEffects(ServerLevel level, BlockPos matrixPos) {
        for (int x : new int[] { -1, 1 }) {
            for (int z : new int[] { -1, 1 }) {
                level.blockEvent(matrixPos.offset(x, -2, z), TCBlocks.INFUSION_PILLAR.get(), 1, 0);
                level.blockEvent(matrixPos.offset(x, -1, z), TCBlocks.INFUSION_PILLAR_TOP.get(), 1, 0);
            }
        }
        level.playSound(null, matrixPos.offset(-1, -2, -1), TCSounds.WAND.get(), SoundSource.BLOCKS, 1.0F, 1.0F);
    }

    private static InfusionPillarBlock.Orientation orientation(int x, int z) {
        if (x < 0 && z < 0) {
            return InfusionPillarBlock.Orientation.NORTH_WEST;
        }
        if (x > 0 && z < 0) {
            return InfusionPillarBlock.Orientation.NORTH_EAST;
        }
        if (x < 0) {
            return InfusionPillarBlock.Orientation.SOUTH_WEST;
        }
        return InfusionPillarBlock.Orientation.SOUTH_EAST;
    }

    @Override
    public void onRemove(BlockState state, Level level, BlockPos pos, BlockState newState, boolean movedByPiston) {
        if (!state.is(newState.getBlock()) && !level.isClientSide && level.getBlockEntity(pos) instanceof InfusionMatrixBlockEntity matrix && matrix.crafting()) {
            level.explode(null, pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5, 2.0F, true, Level.ExplosionInteraction.BLOCK);
        }
        super.onRemove(state, level, pos, newState, movedByPiston);
    }

    private RunicMatrixBlock(net.minecraft.world.level.block.state.BlockBehaviour.Properties native$NativeEntityBlock$arg0, BlockBehaviour.Properties properties, boolean native$NativeEntityBlock$captured) {
        super(native$NativeEntityBlock$arg0);
    }

    @Override
    public void initializeClient(java.util.function.Consumer<net.minecraftforge.client.extensions.common.IClientBlockExtensions> installer) {
        platform$clientInstaller = installer;
        super.initializeClient(installer);
    }

    @Override
    public void platform$clientExtension(Object extension) {
        java.util.Objects.requireNonNull(platform$clientInstaller, "Forge initializeClient must run before client extension registration").accept((net.minecraftforge.client.extensions.common.IClientBlockExtensions) extension);
    }

    @Override
    public InteractionResult use(BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
        ItemUseResult result = (switch(0) {
            default ->
                {
                    net.minecraft.world.item.ItemStack native$bodyOperand$4695 = player.getItemInHand(hand);
                    net.minecraft.world.level.block.state.BlockState native$bodyOperand$4696 = state;
                    net.minecraft.world.level.Level native$bodyOperand$4697 = level;
                    net.minecraft.core.BlockPos native$bodyOperand$4698 = pos;
                    net.minecraft.world.entity.player.Player native$bodyOperand$4699 = player;
                    net.minecraft.world.InteractionHand native$bodyOperand$4700 = hand;
                    net.minecraft.world.phys.BlockHitResult native$bodyOperand$4701 = hit;
                    dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult native$bodyResult$4705 = null;
                    native$bodyReturn$4706: {
                        if (true) {
                            if (!(native$bodyOperand$4695.getItem() instanceof dev.tc4port.thaumcraft.api.wand.WandCarrierItem) || !dev.tc4port.thaumcraft.common.CompoundBlueprintCatalog.isTrigger(dev.tc4port.thaumcraft.common.CompoundBlueprintCatalog.INFUSION_ALTAR, native$bodyOperand$4696) || !(native$bodyOperand$4697.getBlockEntity(native$bodyOperand$4698) instanceof dev.tc4port.thaumcraft.block.entity.InfusionMatrixBlockEntity native$bodyBinding$4702)) {
                                {
                                    native$bodyResult$4705 = dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
                                    break native$bodyReturn$4706;
                                }
                            }
                            var native$bodyBinding$4703 = dev.tc4port.thaumcraft.common.CompoundBlueprintCatalog.require(dev.tc4port.thaumcraft.common.CompoundBlueprintCatalog.INFUSION_ALTAR);
                            if (!dev.tc4port.thaumcraft.common.PlayerKnowledgeService.get(native$bodyOperand$4699).hasCompletedResearch(native$bodyBinding$4703.research())) {
                                {
                                    native$bodyResult$4705 = dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.FAIL;
                                    break native$bodyReturn$4706;
                                }
                            }
                            if (!native$bodyBinding$4702.active()) {
                                if (native$bodyBinding$4702.validLocation()) {
                                    if (!native$bodyOperand$4697.isClientSide) {
                                        native$bodyBinding$4702.setActive(true);
                                    }
                                    native$bodyOperand$4699.swing(native$bodyOperand$4700);
                                    {
                                        native$bodyResult$4705 = dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.sidedSuccess(native$bodyOperand$4697.isClientSide);
                                        break native$bodyReturn$4706;
                                    }
                                }
                                if (!validUnformedAltar(native$bodyOperand$4697, native$bodyOperand$4698)) {
                                    {
                                        native$bodyResult$4705 = dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.FAIL;
                                        break native$bodyReturn$4706;
                                    }
                                }
                                var native$bodyBinding$4704 = dev.tc4port.thaumcraft.common.WandVis.craftingCost(native$bodyOperand$4695, native$bodyOperand$4699, native$bodyBinding$4703.aspects());
                                if (dev.tc4port.thaumcraft.api.ThaumcraftApiHelper.consumeExactVisFromWand(native$bodyOperand$4695, native$bodyOperand$4699, native$bodyBinding$4704, dev.tc4port.thaumcraft.api.aspect.VisAction.SIMULATE) != dev.tc4port.thaumcraft.api.aspect.VisPaymentResult.AVAILABLE) {
                                    {
                                        native$bodyResult$4705 = dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.FAIL;
                                        break native$bodyReturn$4706;
                                    }
                                }
                                if (!native$bodyOperand$4697.isClientSide) {
                                    if (!dev.tc4port.thaumcraft.common.MultiblockFormation.convert((net.minecraft.server.level.ServerLevel) native$bodyOperand$4697, native$bodyOperand$4699, native$bodyOperand$4701.getDirection(), native$bodyOperand$4695, native$bodyBinding$4704, () -> formAltar((net.minecraft.server.level.ServerLevel) native$bodyOperand$4697, native$bodyOperand$4698), () -> {
                                        native$bodyBinding$4702.setActive(true);
                                        formationEffects((net.minecraft.server.level.ServerLevel) native$bodyOperand$4697, native$bodyOperand$4698);
                                    })) {
                                        {
                                            native$bodyResult$4705 = dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.FAIL;
                                            break native$bodyReturn$4706;
                                        }
                                    }
                                }
                                native$bodyOperand$4699.swing(native$bodyOperand$4700);
                                {
                                    native$bodyResult$4705 = dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.sidedSuccess(native$bodyOperand$4697.isClientSide);
                                    break native$bodyReturn$4706;
                                }
                            }
                            if (!native$bodyBinding$4702.crafting()) {
                                if (!native$bodyOperand$4697.isClientSide) {
                                    native$bodyBinding$4702.startCrafting(native$bodyOperand$4699);
                                }
                                native$bodyOperand$4699.swing(native$bodyOperand$4700);
                                {
                                    native$bodyResult$4705 = dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.sidedSuccess(native$bodyOperand$4697.isClientSide);
                                    break native$bodyReturn$4706;
                                }
                            }
                            {
                                native$bodyResult$4705 = dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.FAIL;
                                break native$bodyReturn$4706;
                            }
                        }
                    }
                    yield native$bodyResult$4705;
                }
        });
        return result == ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION ? (hand == InteractionHand.MAIN_HAND ? (switch(0) {
            default ->
                {
                    net.minecraft.world.level.block.state.BlockState native$bodyOperand$3847 = state;
                    net.minecraft.world.level.Level native$bodyOperand$3848 = level;
                    net.minecraft.core.BlockPos native$bodyOperand$3849 = pos;
                    net.minecraft.world.entity.player.Player native$bodyOperand$3850 = player;
                    net.minecraft.world.phys.BlockHitResult native$bodyOperand$3851 = hit;
                    net.minecraft.world.InteractionResult native$bodyResult$3852 = null;
                    native$bodyReturn$3853: {
                        if (true) {
                            {
                                native$bodyResult$3852 = super.use(native$bodyOperand$3847, native$bodyOperand$3848, native$bodyOperand$3849, native$bodyOperand$3850, net.minecraft.world.InteractionHand.MAIN_HAND, native$bodyOperand$3851);
                                break native$bodyReturn$3853;
                            }
                        }
                    }
                    yield native$bodyResult$3852;
                }
        }) : InteractionResult.PASS) : result.result();
    }

    protected InteractionResult interactWithoutItem(BlockState state, Level level, BlockPos pos, Player player, BlockHitResult hit) {
        return super.use(state, level, pos, player, net.minecraft.world.InteractionHand.MAIN_HAND, hit);
    }

    @Override
    public void playerWillDestroy(Level level, BlockPos pos, BlockState state, Player player) {
        {
            net.minecraft.world.level.Level native$bodyOperand$5992 = level;
            net.minecraft.core.BlockPos native$bodyOperand$5993 = pos;
            net.minecraft.world.level.block.state.BlockState native$bodyOperand$5994 = state;
            net.minecraft.world.entity.player.Player native$bodyOperand$5995 = player;
            net.minecraft.world.level.block.state.BlockState native$bodyResult$5996 = null;
            native$bodyReturn$5997: {
                if (true) {
                    super.playerWillDestroy(native$bodyOperand$5992, native$bodyOperand$5993, native$bodyOperand$5994, native$bodyOperand$5995);
                    {
                        native$bodyResult$5996 = native$bodyOperand$5994;
                        break native$bodyReturn$5997;
                    }
                }
            }
        }
    }

    public BlockState beforePlayerDestroy(Level level, BlockPos pos, BlockState state, Player player) {
        super.playerWillDestroy(level, pos, state, player);
        return state;
    }

    protected boolean survivesSharedExplosion() {
        return false;
    }

    public int getExpDrop(net.minecraft.world.level.block.state.BlockState native$callbackInput$1050, net.minecraft.world.level.LevelReader native$callbackInput$1051, net.minecraft.util.RandomSource native$callbackInput$1052, net.minecraft.core.BlockPos native$callbackInput$1053, int native$callbackInput$1054, int native$callbackInput$1055) {
        net.minecraft.world.level.block.state.BlockState state = native$callbackInput$1050;
        net.minecraft.util.RandomSource random = native$callbackInput$1052;
        return 0;
    }

    @Override
    public void onBlockExploded(BlockState state, Level level, BlockPos pos, Explosion explosion) {
        if (!(switch(0) {
            default ->
                {
                    boolean native$bodyResult$5313 = false;
                    native$bodyReturn$5314: {
                        if (true) {
                            {
                                native$bodyResult$5313 = false;
                                break native$bodyReturn$5314;
                            }
                        }
                    }
                    yield native$bodyResult$5313;
                }
        }))
            super.onBlockExploded(state, level, pos, explosion);
    }

    @Override
    public boolean canDropFromExplosion(BlockState state, BlockGetter level, BlockPos pos, Explosion explosion) {
        return !(switch(0) {
            default ->
                {
                    boolean native$bodyResult$4707 = false;
                    native$bodyReturn$4708: {
                        if (true) {
                            {
                                native$bodyResult$4707 = false;
                                break native$bodyReturn$4708;
                            }
                        }
                    }
                    yield native$bodyResult$4707;
                }
        }) && super.canDropFromExplosion(state, level, pos, explosion);
    }

    static private <B extends net.minecraft.world.level.block.Block> com.mojang.serialization.MapCodec<B> native$BlockCodecPlatform$simple(java.util.function.Function<net.minecraft.world.level.block.state.BlockBehaviour.Properties, B> factory) {
        // Vanilla 1.21's Properties codec is a unit codec. Retain that schema for shared block definitions.
        return com.mojang.serialization.codecs.RecordCodecBuilder.mapCodec(instance -> instance.group(com.mojang.serialization.Codec.unit(net.minecraft.world.level.block.state.BlockBehaviour.Properties::of).fieldOf("properties").forGetter((B block) -> net.minecraft.world.level.block.state.BlockBehaviour.Properties.copy(block))).apply(instance, factory));
    }
}
