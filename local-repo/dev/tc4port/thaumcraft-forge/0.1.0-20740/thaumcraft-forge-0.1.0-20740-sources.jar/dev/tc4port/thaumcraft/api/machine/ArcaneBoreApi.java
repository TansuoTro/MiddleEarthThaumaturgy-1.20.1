package dev.tc4port.thaumcraft.api.machine;

import dev.tc4port.thaumcraft.api.Registration;
import dev.tc4port.thaumcraft.common.ArcaneBoreDropModifiers;
import net.minecraft.resources.ResourceLocation;

/**
 * Public addon extension points for Arcane Bore harvesting.
 */
public final class ArcaneBoreApi {

    private ArcaneBoreApi() {
    }

    /**
     * Registers a modifier under a unique addon-owned id. Callbacks run in
     * ascending id-string order and see earlier callbacks' edits. Duplicate
     * ids are rejected. Retain the handle for the registration's lifetime;
     * closing it removes only this registration. Register during mod setup.
     */
    public static Registration registerDropModifier(ResourceLocation id, ArcaneBoreDropModifier modifier) {
        return ArcaneBoreDropModifiers.register(id, modifier);
    }
}
