package dev.tc4port.thaumcraft.block;

import dev.tc4port.thaumcraft.nativeimpl.EffectTypes;
import dev.tc4port.thaumcraft.common.TCGameplayParameters;
import com.mojang.serialization.MapCodec;
import dev.tc4port.thaumcraft.block.entity.MagicFluidBlockEntity;
import dev.tc4port.thaumcraft.registry.TCFluids;
import net.minecraft.world.level.block.EntityBlock;
import net.minecraft.world.level.block.entity.BlockEntity;
import dev.tc4port.thaumcraft.api.entity.TaintedMob;
import dev.tc4port.thaumcraft.registry.TCEffects;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;

/**
 * Buoyant finite Flux Gas. Negative density makes the shared finite-fluid
 * automaton flow upward exactly as TC4's densityDir=1 did.
 */
public final class FluxGasBlock extends FiniteFluidBlock implements EntityBlock {

    public static final MapCodec<FluxGasBlock> CODEC = FluxGasBlock.native$BlockCodecPlatform$simple(FluxGasBlock::new);

    public FluxGasBlock(BlockBehaviour.Properties properties) {
        // viscosity 2500 / 200 truncates to 12 ticks; density is -4.
        super(properties, TCFluids.FLUX_GAS::get);
    }

    @Override
    public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        return new MagicFluidBlockEntity(pos, state);
    }

    protected MapCodec<FluxGasBlock> codec() {
        return CODEC;
    }

    @Override
    public void entityInside(BlockState state, Level level, BlockPos pos, Entity entity) {
        if (level.isClientSide || level.random.nextInt(10) != 0 || !(entity instanceof LivingEntity living) || entity instanceof TaintedMob || living.isInvertedHealAndHarm() || (switch(0) {
            default ->
                {
                    net.minecraft.world.entity.LivingEntity native$operand$13632 = living;
                    net.minecraft.core.Holder<net.minecraft.world.effect.MobEffect> native$operand$13633 = ((net.minecraft.core.Holder<net.minecraft.world.effect.MobEffect>) (net.minecraft.core.Holder<?>) (TCEffects.VIS_EXHAUST).getHolder().orElseThrow());
                    boolean native$result$13634 = (native$operand$13632.hasEffect(native$operand$13633.value()));
                    yield native$result$13634;
                }
        }) || (switch(0) {
            default ->
                {
                    net.minecraft.world.entity.LivingEntity native$operand$14101 = living;
                    net.minecraft.core.Holder<net.minecraft.world.effect.MobEffect> native$operand$14102 = EffectTypes.CONFUSION;
                    boolean native$result$14103 = (native$operand$14101.hasEffect(native$operand$14102.value()));
                    yield native$result$14103;
                }
        })) {
            return;
        }
        int metadata = state.getValue(LEVEL);
        if (level.random.nextBoolean()) {
            living.addEffect((switch(0) {
                default ->
                    {
                        net.minecraft.core.Holder<net.minecraft.world.effect.MobEffect> native$operand$13281 = ((net.minecraft.core.Holder<net.minecraft.world.effect.MobEffect>) (net.minecraft.core.Holder<?>) (TCEffects.VIS_EXHAUST).getHolder().orElseThrow());
                        int native$operand$13282 = TCGameplayParameters.EFFECTS_TAINT_CONTACT_GAS_EXHAUSTION_DURATION.intValue();
                        int native$operand$13283 = metadata / TCGameplayParameters.EFFECTS_TAINT_CONTACT_METADATA_AMPLIFIER_DIVISOR.intValue();
                        boolean native$operand$13284 = true;
                        boolean native$operand$13285 = true;
                        net.minecraft.world.effect.MobEffectInstance native$result$13286 = (new net.minecraft.world.effect.MobEffectInstance(native$operand$13281.value(), native$operand$13282, FluxGasBlock.native$MobEffectPlatform$safeAmplifier(native$operand$13281, native$operand$13283), native$operand$13284, native$operand$13285));
                        yield native$result$13286;
                    }
            }));
        } else {
            living.addEffect((switch(0) {
                default ->
                    {
                        net.minecraft.core.Holder<net.minecraft.world.effect.MobEffect> native$operand$13287 = EffectTypes.CONFUSION;
                        int native$operand$13288 = TCGameplayParameters.EFFECTS_TAINT_CONTACT_GAS_CONFUSION_BASE_TICKS.intValue() + metadata * TCGameplayParameters.EFFECTS_TAINT_CONTACT_GAS_CONFUSION_PER_LEVEL.intValue();
                        int native$operand$13289 = 0;
                        boolean native$operand$13290 = false;
                        boolean native$operand$13291 = true;
                        net.minecraft.world.effect.MobEffectInstance native$result$13292 = (new net.minecraft.world.effect.MobEffectInstance(native$operand$13287.value(), native$operand$13288, FluxGasBlock.native$MobEffectPlatform$safeAmplifier(native$operand$13287, native$operand$13289), native$operand$13290, native$operand$13291));
                        yield native$result$13292;
                    }
            }));
        }
        if (metadata > 0) {
            level.setBlock(pos, state.setValue(LEVEL, metadata - 1), 3);
        } else {
            this.clear(level, pos);
        }
    }

    /**
     * Native shift-based effects need a smaller ceiling than the stored amplifier byte.
     */
    static private int native$MobEffectPlatform$safeAmplifier(net.minecraft.core.Holder<net.minecraft.world.effect.MobEffect> effect, int amplifier) {
        net.minecraft.world.effect.MobEffect type = effect.value();
        int maximum = type == net.minecraft.world.effect.MobEffects.HEAL || type == net.minecraft.world.effect.MobEffects.HARM ? 16 : type == net.minecraft.world.effect.MobEffects.REGENERATION || type == net.minecraft.world.effect.MobEffects.POISON || type == net.minecraft.world.effect.MobEffects.WITHER ? 31 : 127;
        return java.lang.Math.max(0, java.lang.Math.min(maximum, amplifier));
    }

    static private <B extends net.minecraft.world.level.block.Block> com.mojang.serialization.MapCodec<B> native$BlockCodecPlatform$simple(java.util.function.Function<net.minecraft.world.level.block.state.BlockBehaviour.Properties, B> factory) {
        // Vanilla 1.21's Properties codec is a unit codec. Retain that schema for shared block definitions.
        return com.mojang.serialization.codecs.RecordCodecBuilder.mapCodec(instance -> instance.group(com.mojang.serialization.Codec.unit(net.minecraft.world.level.block.state.BlockBehaviour.Properties::of).fieldOf("properties").forGetter((B block) -> net.minecraft.world.level.block.state.BlockBehaviour.Properties.copy(block))).apply(instance, factory));
    }
}
