package dev.tc4port.thaumcraft.api.wand;

import dev.tc4port.thaumcraft.api.aspect.VisAction;
import dev.tc4port.thaumcraft.api.aspect.VisCost;
import dev.tc4port.thaumcraft.common.WandTransfers;
import dev.tc4port.thaumcraft.common.WandPartIndex;
import dev.tc4port.thaumcraft.common.WandStackFactory;
import dev.tc4port.thaumcraft.data.WandData;
import dev.tc4port.thaumcraft.state.TCItemState;
import java.util.Objects;
import java.util.Optional;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;

/**
 * Wand construction, inspection and server-authoritative raw Vis transfer.
 */
public final class WandApi {

    private WandApi() {
    }

    /**
     * Whether this is one of the core WandItem implementations (not an arbitrary custom carrier).
     */
    public static boolean isBuiltinWand(net.minecraft.world.item.ItemStack stack) {
        return stack.getItem() instanceof dev.tc4port.thaumcraft.item.WandItem;
    }

    /**
     * Exact whole-Vis recipe cost converted to centivis with this wand and player's crafting modifiers.
     */
    public static java.util.Map<dev.tc4port.thaumcraft.api.aspect.VisChannel, Integer> craftingCost(ItemStack wand, @javax.annotation.Nullable net.minecraft.world.entity.player.Player player, java.util.Map<dev.tc4port.thaumcraft.api.aspect.VisChannel, Integer> wholeVis) {
        return java.util.Map.copyOf(dev.tc4port.thaumcraft.common.WandVis.craftingCost(wand, player, wholeVis));
    }

    /**
     * Effective crafting multiplier, including the carrier, cap and player equipment.
     */
    public static float craftingModifier(ItemStack wand, @javax.annotation.Nullable net.minecraft.world.entity.player.Player player, dev.tc4port.thaumcraft.api.aspect.VisChannel channel) {
        return dev.tc4port.thaumcraft.common.WandVis.consumptionModifier(wand, player, channel, true);
    }

    public static Optional<WandView> view(ItemStack stack) {
        return WandTransfers.view(stack);
    }

    /**
     * Whether held use currently aims at a node that owns the absorption pose.
     * This read-only presentation query uses synchronized held use and visible
     * aim, so observing clients need no private cast session or extra packet.
     * Empty nodes still own that pose; energized nodes do not. The result does
     * not authorize Vis transfer or prove that the node has transferable Vis.
     */
    public static boolean isAbsorbingNode(LivingEntity wielder, float partialTick) {
        return dev.tc4port.thaumcraft.common.WandNodeTapping.isActive(Objects.requireNonNull(wielder, "wielder"), partialTick);
    }

    /**
     * Whether this carrier may be used as an arcane-worktable Vis source.
     */
    public static boolean supportsArcaneCrafting(ItemStack stack) {
        Objects.requireNonNull(stack, "stack");
        if (view(stack).isEmpty()) {
            return false;
        }
        return stack.getItem() instanceof CustomWandItem custom ? custom.thaumcraftWandSpec().supportsArcaneCrafting() : stack.getItem() instanceof WandCarrierItem;
    }

    /**
     * Whether use of this carrier requires the opposite hand to be empty.
     */
    public static boolean requiresBothHands(ItemStack stack) {
        Objects.requireNonNull(stack, "stack");
        return stack.getItem() instanceof WandCarrierItem carrier && carrier.requiresBothHands(stack);
    }

    /**
     * Applies an addon carrier's bounded cooldown policy.
     */
    public static int cooldownTicks(ItemStack stack, int ordinaryTicks) {
        Objects.requireNonNull(stack, "stack");
        return stack.getItem() instanceof CustomWandItem custom ? custom.adjustedCooldownTicks(ordinaryTicks) : Math.max(0, ordinaryTicks);
    }

    /**
     * Carrier policy followed by the caster's focus cooldown attribute; rounded up to ticks.
     */
    public static int cooldownTicks(ItemStack stack, @javax.annotation.Nullable net.minecraft.world.entity.LivingEntity caster, int ordinaryTicks) {
        return (int) Math.min(Integer.MAX_VALUE, Math.ceil(cooldownTicks(stack, ordinaryTicks) * dev.tc4port.thaumcraft.api.MagicAttributes.multiplier(caster, dev.tc4port.thaumcraft.api.MagicAttributes.FOCUS_COOLDOWN_MULTIPLIER)));
    }

    /**
     * Preserves material identities even when their definitions are not currently available.
     */
    public static ItemStack create(WandMaterialId rod, WandMaterialId cap) {
        return WandStackFactory.createCore(rod, cap, false);
    }

    /**
     * Unknown material definitions retain their identities and have zero capacity.
     */
    public static ItemStack createFullyCharged(WandMaterialId rod, WandMaterialId cap) {
        return WandStackFactory.createFullyChargedCore(rod, cap, false);
    }

    /**
     * Creates an independent wand from complete item state; charge is a one-call construction option.
     */
    public static ItemStack assemble(ItemStack template, boolean fullyCharged) {
        if (!isBuiltinWand(template) || template.getCount() != 1) {
            throw new IllegalArgumentException("Wand assembly requires exactly one built-in wand");
        }
        ItemStack result = template.copy();
        WandStackFactory.synchronizeCorePhysicalProfile(result);
        int capacity = dev.tc4port.thaumcraft.common.WandVis.maxVis(result);
        return fullyCharged && capacity > 0 ? WandStackFactory.fillToCapacity(result, capacity) : result;
    }

    public static VisTransferResult extract(ServerPlayer player, ItemStack wand, VisCost amount, VisAction action) {
        return WandTransfers.extract(player, wand, amount, action);
    }

    public static VisTransferResult insert(ServerPlayer player, ItemStack wand, VisCost amount, VisAction action) {
        return WandTransfers.insert(player, wand, amount, action);
    }

    public static VisTransferResult extract(WandMachineContext context, ItemStack wand, VisCost amount, VisAction action) {
        return WandTransfers.extract(context, wand, amount, action);
    }

    public static VisTransferResult insert(WandMachineContext context, ItemStack wand, VisCost amount, VisAction action) {
        return WandTransfers.insert(context, wand, amount, action);
    }

    /**
     * Atomically replaces a wand's rod identity and the core carrier's
     * corresponding staff modifiers. The expected identity prevents stale or
     * repeated transitions, while a lower-capacity rod is rejected instead
     * of truncating stored Vis.
     */
    public static WandPartChangeResult replaceRod(ServerPlayer player, ItemStack wand, WandMaterialId expectedRod, WandMaterialId replacementRod, VisAction action) {
        Objects.requireNonNull(player, "player");
        Objects.requireNonNull(wand, "wand");
        Objects.requireNonNull(expectedRod, "expectedRod");
        Objects.requireNonNull(replacementRod, "replacementRod");
        Objects.requireNonNull(action, "action");
        if (!player.server.isSameThread()) {
            return WandPartChangeResult.OFF_SERVER_THREAD;
        }
        if (view(wand).isEmpty()) {
            return WandPartChangeResult.NOT_A_WAND;
        }
        WandData current = (switch(0) {
            default ->
                {
                    dev.tc4port.thaumcraft.api.data.ItemStateKey<dev.tc4port.thaumcraft.data.WandData> native$receiver$520 = TCItemState.WAND;
                    net.minecraft.world.item.ItemStack native$argument$521 = wand;
                    dev.tc4port.thaumcraft.data.WandData native$argument$522 = WandData.DEFAULT;
                    java.util.Objects.requireNonNull(native$receiver$520);
                    yield dev.tc4port.thaumcraft.api.item.ItemStatePlatform.getOrDefault(native$argument$521, native$receiver$520, native$argument$522);
                }
        });
        if (!current.rod().equals(expectedRod)) {
            return WandPartChangeResult.STALE_EXPECTED_ROD;
        }
        if (WandPartIndex.rod(replacementRod) == null) {
            return WandPartChangeResult.UNKNOWN_REPLACEMENT_ROD;
        }
        if (expectedRod.equals(replacementRod)) {
            return WandPartChangeResult.UNCHANGED;
        }
        int replacementCapacity = wand.getItem() instanceof CustomWandItem custom ? custom.thaumcraftWandSpec().capacityCentivis() : WandPartIndex.maxVis(replacementRod, current.sceptre());
        if (current.vis().values().stream().anyMatch(amount -> amount < 0 || amount > replacementCapacity)) {
            return WandPartChangeResult.INCOMPATIBLE_CAPACITY;
        }
        if (action == VisAction.SIMULATE) {
            return WandPartChangeResult.WOULD_CHANGE;
        }
        {
            dev.tc4port.thaumcraft.api.data.ItemStateKey<dev.tc4port.thaumcraft.data.WandData> native$receiver$861 = TCItemState.WAND;
            net.minecraft.world.item.ItemStack native$argument$862 = wand;
            dev.tc4port.thaumcraft.data.WandData native$argument$863 = current.withRod(replacementRod);
            java.util.Objects.requireNonNull(native$receiver$861);
            dev.tc4port.thaumcraft.api.item.ItemStatePlatform.set(native$argument$862, native$receiver$861, java.util.Objects.requireNonNull(native$argument$863, "value"));
        }
        WandStackFactory.synchronizeCorePhysicalProfile(wand);
        return WandPartChangeResult.CHANGED;
    }
}
