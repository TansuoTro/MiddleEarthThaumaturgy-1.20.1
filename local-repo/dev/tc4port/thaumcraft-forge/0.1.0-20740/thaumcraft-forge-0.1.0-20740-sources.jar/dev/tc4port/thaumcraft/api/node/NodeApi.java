package dev.tc4port.thaumcraft.api.node;

import dev.tc4port.thaumcraft.api.aspect.VisAction;
import dev.tc4port.thaumcraft.block.entity.AuraNodeBlockEntity;
import dev.tc4port.thaumcraft.block.entity.NodeJarBlockEntity;
import dev.tc4port.thaumcraft.common.NodeEcologyCatalog;
import dev.tc4port.thaumcraft.registry.TCBlocks;
import java.util.Objects;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;

/**
 * Stable entry point for the synchronized aura-node catalog.
 */
public final class NodeApi {

    private NodeApi() {
    }

    /**
     * Creates a captured jar, rebuilding its base store from current Vis like core capture.
     */
    public static net.minecraft.world.item.ItemStack createJar(AuraNodeState state) {
        Objects.requireNonNull(state, "state");
        if (state.instanceId().isEmpty()) {
            throw new IllegalArgumentException("A captured node jar requires a persistent identity");
        }
        var stack = new net.minecraft.world.item.ItemStack(dev.tc4port.thaumcraft.api.ThaumcraftContent.item("node_jar_item"));
        {
            dev.tc4port.thaumcraft.api.data.ItemStateKey<dev.tc4port.thaumcraft.api.node.AuraNodeState> native$receiver$852 = dev.tc4port.thaumcraft.state.TCItemState.NODE;
            net.minecraft.world.item.ItemStack native$argument$853 = stack;
            dev.tc4port.thaumcraft.api.node.AuraNodeState native$argument$854 = dev.tc4port.thaumcraft.item.NodeJarItem.normalizeNodeState(state);
            java.util.Objects.requireNonNull(native$receiver$852);
            dev.tc4port.thaumcraft.api.item.ItemStatePlatform.set(native$argument$853, native$receiver$852, java.util.Objects.requireNonNull(native$argument$854, "value"));
        }
        return stack;
    }

    /**
     * Captured state only; a blank creative jar has no captured node.
     */
    public static java.util.Optional<AuraNodeState> jarState(net.minecraft.world.item.ItemStack stack) {
        Objects.requireNonNull(stack, "stack");
        return stack.is(dev.tc4port.thaumcraft.api.ThaumcraftContent.item("node_jar_item")) ? java.util.Optional.ofNullable((switch(0) {
            default ->
                {
                    dev.tc4port.thaumcraft.api.data.ItemStateKey<dev.tc4port.thaumcraft.api.node.AuraNodeState> native$receiver$453 = dev.tc4port.thaumcraft.state.TCItemState.NODE;
                    net.minecraft.world.item.ItemStack native$argument$454 = stack;
                    java.util.Objects.requireNonNull(native$receiver$453);
                    yield dev.tc4port.thaumcraft.api.item.ItemStatePlatform.get(native$argument$454, native$receiver$453);
                }
        })).filter(state -> state.instanceId().isPresent()) : java.util.Optional.empty();
    }

    public static NodeRegistryView registry() {
        return NodeEcologyCatalog.apiView();
    }

    /**
     * Atomically replaces the complete state of one already-loaded mutable
     * aura-node owner. Core ordinary nodes and node jars are mutable owners;
     * energized nodes and third-party inspection-only views are not.
     *
     * <p>The expected value is a compare-and-set witness. Addon machines must
     * read a fresh {@link AuraNodeView#nodeState()} and submit that exact
     * immutable state, so a recharge, drain, chunk lifecycle, or competing
     * machine cannot be overwritten by a stale partial edit. This method
     * never loads a chunk and never permits the node's persistent instance
     * identity to change.</p>
     */
    public static NodeStateChangeResult replaceLoadedState(ServerLevel level, BlockPos position, AuraNodeState expected, AuraNodeState replacement, VisAction action) {
        Objects.requireNonNull(level, "level");
        Objects.requireNonNull(position, "position");
        Objects.requireNonNull(expected, "expected");
        Objects.requireNonNull(replacement, "replacement");
        Objects.requireNonNull(action, "action");
        if (!level.getServer().isSameThread()) {
            return NodeStateChangeResult.OFF_SERVER_THREAD;
        }
        if (!level.hasChunkAt(position)) {
            return NodeStateChangeResult.CHUNK_UNLOADED;
        }
        Object owner = level.getBlockEntity(position);
        AuraNodeState current;
        if (level.getBlockState(position).is(TCBlocks.AURA_NODE.get()) && owner instanceof AuraNodeBlockEntity node) {
            current = node.nodeState();
        } else if (level.getBlockState(position).is(TCBlocks.NODE_JAR.get()) && owner instanceof NodeJarBlockEntity jar) {
            current = jar.nodeState();
        } else {
            return NodeStateChangeResult.NOT_A_MUTABLE_NODE;
        }
        if (!current.equals(expected)) {
            return NodeStateChangeResult.STALE_EXPECTED_STATE;
        }
        if (!current.instanceId().equals(replacement.instanceId())) {
            return NodeStateChangeResult.IDENTITY_CHANGE_DENIED;
        }
        if (current.equals(replacement)) {
            return NodeStateChangeResult.UNCHANGED;
        }
        if (action == VisAction.SIMULATE) {
            return NodeStateChangeResult.WOULD_REPLACE;
        }
        if (owner instanceof AuraNodeBlockEntity node) {
            node.setNodeState(replacement);
        } else {
            ((NodeJarBlockEntity) owner).setNodeState(replacement);
        }
        return NodeStateChangeResult.REPLACED;
    }

    /**
     * Atomically replaces the complete states of two distinct, already-loaded
     * ordinary aura nodes in one dimension.
     *
     * <p>Both compare-and-set witnesses, both persistent identities and both
     * loaded owners are validated before either node is changed. This is the
     * transaction boundary addon links need when one operation removes Vis
     * from a source and adds it to a destination: composing two calls to
     * {@link #replaceLoadedState} could duplicate or lose Vis if the second
     * call failed. No chunk is loaded and no callback runs between the two
     * commits.</p>
     */
    public static NodeStateChangeResult replaceLoadedStates(ServerLevel level, BlockPos firstPosition, AuraNodeState firstExpected, AuraNodeState firstReplacement, BlockPos secondPosition, AuraNodeState secondExpected, AuraNodeState secondReplacement, VisAction action) {
        Objects.requireNonNull(level, "level");
        Objects.requireNonNull(firstPosition, "firstPosition");
        Objects.requireNonNull(firstExpected, "firstExpected");
        Objects.requireNonNull(firstReplacement, "firstReplacement");
        Objects.requireNonNull(secondPosition, "secondPosition");
        Objects.requireNonNull(secondExpected, "secondExpected");
        Objects.requireNonNull(secondReplacement, "secondReplacement");
        Objects.requireNonNull(action, "action");
        if (!level.getServer().isSameThread()) {
            return NodeStateChangeResult.OFF_SERVER_THREAD;
        }
        if (firstPosition.equals(secondPosition)) {
            return NodeStateChangeResult.DUPLICATE_POSITION;
        }
        if (!level.hasChunkAt(firstPosition) || !level.hasChunkAt(secondPosition)) {
            return NodeStateChangeResult.CHUNK_UNLOADED;
        }
        if (!level.getBlockState(firstPosition).is(TCBlocks.AURA_NODE.get()) || !level.getBlockState(secondPosition).is(TCBlocks.AURA_NODE.get()) || !(level.getBlockEntity(firstPosition) instanceof AuraNodeBlockEntity firstNode) || !(level.getBlockEntity(secondPosition) instanceof AuraNodeBlockEntity secondNode)) {
            return NodeStateChangeResult.NOT_AN_ORDINARY_NODE;
        }
        AuraNodeState firstCurrent = firstNode.nodeState();
        AuraNodeState secondCurrent = secondNode.nodeState();
        if (!firstCurrent.equals(firstExpected) || !secondCurrent.equals(secondExpected)) {
            return NodeStateChangeResult.STALE_EXPECTED_STATE;
        }
        if (!firstCurrent.instanceId().equals(firstReplacement.instanceId()) || !secondCurrent.instanceId().equals(secondReplacement.instanceId())) {
            return NodeStateChangeResult.IDENTITY_CHANGE_DENIED;
        }
        if (firstCurrent.equals(firstReplacement) && secondCurrent.equals(secondReplacement)) {
            return NodeStateChangeResult.UNCHANGED;
        }
        if (action == VisAction.SIMULATE) {
            return NodeStateChangeResult.WOULD_REPLACE;
        }
        firstNode.setNodeState(firstReplacement);
        secondNode.setNodeState(secondReplacement);
        return NodeStateChangeResult.REPLACED;
    }
}
