package dev.tc4port.thaumcraft.api.client;

import dev.tc4port.thaumcraft.api.Registration;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Objects;
import java.util.function.UnaryOperator;
import net.minecraft.resources.ResourceLocation;

/**
 * Rendering extension point for world nodes and placed node jars, with radius measured in blocks.
 * Caller-local visual API drawing, item rendering and simulation do not call these hooks.
 */
public final class AuraNodeRenderApi {

    private static final Map<ResourceLocation, UnaryOperator<AuraNodeLayer>> TRANSFORMS = new LinkedHashMap<>();

    private AuraNodeRenderApi() {
    }

    /**
     * Transforms run in registration order on the render thread, receiving the previous result.
     */
    public static synchronized Registration registerLayerTransform(ResourceLocation id, UnaryOperator<AuraNodeLayer> transform) {
        Objects.requireNonNull(id, "id");
        Objects.requireNonNull(transform, "transform");
        if (TRANSFORMS.putIfAbsent(id, transform) != null)
            throw new IllegalArgumentException("Duplicate node transform: " + id);
        return Registration.of(() -> {
            synchronized (AuraNodeRenderApi.class) {
                TRANSFORMS.remove(id, transform);
            }
        });
    }

    /**
     * Core draw boundary. With no callbacks the original layer is returned unchanged.
     */
    public static synchronized AuraNodeLayer transformLayer(AuraNodeLayer layer) {
        for (var transform : TRANSFORMS.values()) layer = Objects.requireNonNull(transform.apply(layer), "layer");
        return layer;
    }
}
