package dev.tc4port.thaumcraft.api.client;

import dev.tc4port.thaumcraft.api.research.ResearchCategoryKey;
import java.util.Objects;

/**
 * A native 24-pixel category tab at caller-supplied GUI coordinates.
 */
public record ThaumonomiconTab(ResearchCategoryKey category, int x, int y, boolean right) {

    public ThaumonomiconTab {
        Objects.requireNonNull(category, "category");
    }
}
