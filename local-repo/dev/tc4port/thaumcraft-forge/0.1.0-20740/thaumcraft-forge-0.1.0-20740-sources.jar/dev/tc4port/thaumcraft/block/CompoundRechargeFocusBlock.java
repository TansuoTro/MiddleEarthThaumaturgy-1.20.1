package dev.tc4port.thaumcraft.block;

import dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult;
import com.mojang.serialization.MapCodec;
import net.minecraft.core.BlockPos;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.pathfinder.PathComputationType;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;
import dev.tc4port.thaumcraft.nativeimpl.ClientExtensionTarget;
import net.minecraft.world.phys.HitResult;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.Explosion;

/**
 * BlockStoneDevice metadata 8. It only changes a recharge pedestal directly
 * below it; the original generic block still allowed it to stand alone.
 */
public final class CompoundRechargeFocusBlock extends net.minecraft.world.level.block.Block implements dev.tc4port.thaumcraft.nativeimpl.ClientExtensionTarget {

    // Forge calls initializeClient from the native superclass constructor. Do not add a field initializer.
    private java.util.function.Consumer<net.minecraftforge.client.extensions.common.IClientBlockExtensions> platform$clientInstaller;

    public static final MapCodec<CompoundRechargeFocusBlock> CODEC = CompoundRechargeFocusBlock.native$BlockCodecPlatform$simple(CompoundRechargeFocusBlock::new);

    private static final VoxelShape OUTLINE = Block.box(1.0, 0.0, 1.0, 15.0, 7.0, 15.0);

    public CompoundRechargeFocusBlock(BlockBehaviour.Properties properties) {
        this(properties, properties, true);
    }

    protected MapCodec<CompoundRechargeFocusBlock> codec() {
        return CODEC;
    }

    @Override
    public RenderShape getRenderShape(BlockState state) {
        return RenderShape.MODEL;
    }

    @Override
    public VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
        return OUTLINE;
    }

    @Override
    public VoxelShape getCollisionShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
        /*
         * addCollisionBoxesToList only special-cased metadata 5. Metadata 8
         * therefore retained a surprising full-cube collision box.
         */
        return Shapes.block();
    }

    @Override
    public VoxelShape getBlockSupportShape(BlockState state, BlockGetter level, BlockPos pos) {
        return Shapes.empty();
    }

    @Override
    public boolean isCollisionShapeFullBlock(BlockState state, BlockGetter level, BlockPos pos) {
        /*
         * Physical collision was full, but isOpaqueCube=false kept the
         * multipart model from being treated as a light-blocking cube.
         */
        return false;
    }

    @Override
    public boolean isPathfindable(BlockState state, net.minecraft.world.level.BlockGetter level, BlockPos pos, PathComputationType pathType) {
        return false;
    }

    protected ItemUseResult interactWithItem(ItemStack stack, BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
        return dev.tc4port.thaumcraft.block.WandRechargePedestalBlock.interactWithItem(level, pos.below(), player, stack);
    }

    protected InteractionResult interactWithoutItem(BlockState state, Level level, BlockPos pos, Player player, BlockHitResult hit) {
        if (!(level.getBlockEntity(pos.below()) instanceof dev.tc4port.thaumcraft.block.entity.WandRechargePedestalBlockEntity pedestal) || pedestal.item().isEmpty()) {
            return net.minecraft.world.InteractionResult.PASS;
        }
        /*
         * Metadata 8 decremented y and entered metadata 5's occupied
         * pedestal branch. Keep that shared path while applying the
         * user-authorized inventory-first retrieval rule to both blocks.
         */
        dev.tc4port.thaumcraft.block.WandRechargePedestalBlock.takeItem(level, pos.below(), player, pedestal);
        return net.minecraft.world.InteractionResult.sidedSuccess(level.isClientSide);
    }

    private CompoundRechargeFocusBlock(net.minecraft.world.level.block.state.BlockBehaviour.Properties native$NativeBlock$arg0, BlockBehaviour.Properties properties, boolean native$NativeBlock$captured) {
        super(native$NativeBlock$arg0);
    }

    @Override
    public void initializeClient(java.util.function.Consumer<net.minecraftforge.client.extensions.common.IClientBlockExtensions> installer) {
        platform$clientInstaller = installer;
        super.initializeClient(installer);
    }

    @Override
    public void platform$clientExtension(Object extension) {
        java.util.Objects.requireNonNull(platform$clientInstaller, "Forge initializeClient must run before client extension registration").accept((net.minecraftforge.client.extensions.common.IClientBlockExtensions) extension);
    }

    @Override
    public InteractionResult use(BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
        ItemUseResult result = (switch(0) {
            default ->
                {
                    net.minecraft.world.item.ItemStack native$bodyOperand$4262 = player.getItemInHand(hand);
                    net.minecraft.world.level.block.state.BlockState native$bodyOperand$4263 = state;
                    net.minecraft.world.level.Level native$bodyOperand$4264 = level;
                    net.minecraft.core.BlockPos native$bodyOperand$4265 = pos;
                    net.minecraft.world.entity.player.Player native$bodyOperand$4266 = player;
                    net.minecraft.world.InteractionHand native$bodyOperand$4267 = hand;
                    net.minecraft.world.phys.BlockHitResult native$bodyOperand$4268 = hit;
                    dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult native$bodyResult$4269 = null;
                    native$bodyReturn$4270: {
                        if (true) {
                            {
                                native$bodyResult$4269 = dev.tc4port.thaumcraft.block.WandRechargePedestalBlock.interactWithItem(native$bodyOperand$4264, native$bodyOperand$4265.below(), native$bodyOperand$4266, native$bodyOperand$4262);
                                break native$bodyReturn$4270;
                            }
                        }
                    }
                    yield native$bodyResult$4269;
                }
        });
        return result == ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION ? (hand == InteractionHand.MAIN_HAND ? (switch(0) {
            default ->
                {
                    net.minecraft.world.level.block.state.BlockState native$bodyOperand$3564 = state;
                    net.minecraft.world.level.Level native$bodyOperand$3565 = level;
                    net.minecraft.core.BlockPos native$bodyOperand$3566 = pos;
                    net.minecraft.world.entity.player.Player native$bodyOperand$3567 = player;
                    net.minecraft.world.phys.BlockHitResult native$bodyOperand$3568 = hit;
                    net.minecraft.world.InteractionResult native$bodyResult$3570 = null;
                    native$bodyReturn$3571: {
                        if (true) {
                            if (!(native$bodyOperand$3565.getBlockEntity(native$bodyOperand$3566.below()) instanceof dev.tc4port.thaumcraft.block.entity.WandRechargePedestalBlockEntity native$bodyBinding$3569) || native$bodyBinding$3569.item().isEmpty()) {
                                {
                                    native$bodyResult$3570 = net.minecraft.world.InteractionResult.PASS;
                                    break native$bodyReturn$3571;
                                }
                            }
                            /*
         * Metadata 8 decremented y and entered metadata 5's occupied
         * pedestal branch. Keep that shared path while applying the
         * user-authorized inventory-first retrieval rule to both blocks.
         */
                            dev.tc4port.thaumcraft.block.WandRechargePedestalBlock.takeItem(native$bodyOperand$3565, native$bodyOperand$3566.below(), native$bodyOperand$3567, native$bodyBinding$3569);
                            {
                                native$bodyResult$3570 = net.minecraft.world.InteractionResult.sidedSuccess(native$bodyOperand$3565.isClientSide);
                                break native$bodyReturn$3571;
                            }
                        }
                    }
                    yield native$bodyResult$3570;
                }
        }) : InteractionResult.PASS) : result.result();
    }

    @Override
    public void playerWillDestroy(Level level, BlockPos pos, BlockState state, Player player) {
        {
            net.minecraft.world.level.Level native$bodyOperand$5751 = level;
            net.minecraft.core.BlockPos native$bodyOperand$5752 = pos;
            net.minecraft.world.level.block.state.BlockState native$bodyOperand$5753 = state;
            net.minecraft.world.entity.player.Player native$bodyOperand$5754 = player;
            net.minecraft.world.level.block.state.BlockState native$bodyResult$5755 = null;
            native$bodyReturn$5756: {
                if (true) {
                    super.playerWillDestroy(native$bodyOperand$5751, native$bodyOperand$5752, native$bodyOperand$5753, native$bodyOperand$5754);
                    {
                        native$bodyResult$5755 = native$bodyOperand$5753;
                        break native$bodyReturn$5756;
                    }
                }
            }
        }
    }

    public BlockState beforePlayerDestroy(Level level, BlockPos pos, BlockState state, Player player) {
        super.playerWillDestroy(level, pos, state, player);
        return state;
    }

    protected boolean survivesSharedExplosion() {
        return false;
    }

    public int getExpDrop(net.minecraft.world.level.block.state.BlockState native$callbackInput$1145, net.minecraft.world.level.LevelReader native$callbackInput$1146, net.minecraft.util.RandomSource native$callbackInput$1147, net.minecraft.core.BlockPos native$callbackInput$1148, int native$callbackInput$1149, int native$callbackInput$1150) {
        net.minecraft.world.level.block.state.BlockState state = native$callbackInput$1145;
        net.minecraft.util.RandomSource random = native$callbackInput$1147;
        return 0;
    }

    @Override
    public void onBlockExploded(BlockState state, Level level, BlockPos pos, Explosion explosion) {
        if (!(switch(0) {
            default ->
                {
                    boolean native$bodyResult$5237 = false;
                    native$bodyReturn$5238: {
                        if (true) {
                            {
                                native$bodyResult$5237 = false;
                                break native$bodyReturn$5238;
                            }
                        }
                    }
                    yield native$bodyResult$5237;
                }
        }))
            super.onBlockExploded(state, level, pos, explosion);
    }

    @Override
    public boolean canDropFromExplosion(BlockState state, BlockGetter level, BlockPos pos, Explosion explosion) {
        return !(switch(0) {
            default ->
                {
                    boolean native$bodyResult$4271 = false;
                    native$bodyReturn$4272: {
                        if (true) {
                            {
                                native$bodyResult$4271 = false;
                                break native$bodyReturn$4272;
                            }
                        }
                    }
                    yield native$bodyResult$4271;
                }
        }) && super.canDropFromExplosion(state, level, pos, explosion);
    }

    static private <B extends net.minecraft.world.level.block.Block> com.mojang.serialization.MapCodec<B> native$BlockCodecPlatform$simple(java.util.function.Function<net.minecraft.world.level.block.state.BlockBehaviour.Properties, B> factory) {
        // Vanilla 1.21's Properties codec is a unit codec. Retain that schema for shared block definitions.
        return com.mojang.serialization.codecs.RecordCodecBuilder.mapCodec(instance -> instance.group(com.mojang.serialization.Codec.unit(net.minecraft.world.level.block.state.BlockBehaviour.Properties::of).fieldOf("properties").forGetter((B block) -> net.minecraft.world.level.block.state.BlockBehaviour.Properties.copy(block))).apply(instance, factory));
    }
}
