package dev.tc4port.thaumcraft.api.client;

import java.util.ArrayDeque;
import java.util.Deque;
import javax.annotation.Nullable;
import net.minecraft.world.entity.LivingEntity;

/**
 * Supplies BEWLR item renderers with the entity omitted from
 * BlockEntityWithoutLevelRenderer#renderByItem.
 */
public final class HeldItemRenderContext {

    private static final ThreadLocal<Deque<LivingEntity>> ENTITIES = ThreadLocal.withInitial(ArrayDeque::new);

    private HeldItemRenderContext() {
    }

    public static void push(LivingEntity entity) {
        ENTITIES.get().push(entity);
    }

    public static void pop() {
        Deque<LivingEntity> entities = ENTITIES.get();
        if (!entities.isEmpty()) {
            entities.pop();
        }
        if (entities.isEmpty()) {
            ENTITIES.remove();
        }
    }

    @Nullable
    public static LivingEntity currentEntity() {
        return ENTITIES.get().peek();
    }
}
