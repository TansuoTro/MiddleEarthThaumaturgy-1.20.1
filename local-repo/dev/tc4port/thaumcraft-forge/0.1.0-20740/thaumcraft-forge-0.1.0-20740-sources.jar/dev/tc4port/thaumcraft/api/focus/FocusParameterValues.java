package dev.tc4port.thaumcraft.api.focus;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;
import net.minecraft.nbt.CompoundTag;

/**
 * Cast-time values retained by projectiles and summons, including across chunk saves.
 */
public record FocusParameterValues(Map<String, Double> values, double damageMultiplier, double damageBonus) {

    public FocusParameterValues(Map<String, Double> values) {
        this(values, 1.0D, 0.0D);
    }

    public FocusParameterValues(Map<String, Double> values, double damageMultiplier) {
        this(values, damageMultiplier, 0.0D);
    }

    public FocusParameterValues {
        new FocusDamageModifiers(damageMultiplier, damageBonus);
        values = Collections.unmodifiableMap(new LinkedHashMap<>(values));
        if (values.size() > FocusParameters.MAX_ENTRIES || values.entrySet().stream().anyMatch(entry -> !entry.getKey().matches("[a-z][a-z0-9_]{0,63}") || entry.getValue() == null || !Double.isFinite(entry.getValue()) || entry.getValue() < 0 || entry.getValue() > FocusParameters.LIMIT)) {
            throw new IllegalArgumentException("Invalid resolved focus parameters");
        }
    }

    public double get(String key) {
        Double value = values.get(key);
        if (value == null)
            throw new IllegalArgumentException("Missing resolved focus parameter: " + key);
        return value;
    }

    public FocusDamageModifiers damageModifiers() {
        return new FocusDamageModifiers(damageMultiplier, damageBonus);
    }

    public static FocusParameterValues resolve(FocusId focus, Map<FocusUpgradeId, Integer> levels) {
        var parameters = FocusApi.registry().profile(focus).orElseThrow().parameters();
        LinkedHashMap<String, Double> values = new LinkedHashMap<>();
        parameters.values().keySet().forEach(key -> values.put(key, parameters.value(key, levels)));
        return new FocusParameterValues(values);
    }

    /**
     * Snapshot the caster's damage attributes without changing the focus's base parameters.
     */
    public static FocusParameterValues resolve(FocusId focus, Map<FocusUpgradeId, Integer> levels, net.minecraft.world.entity.LivingEntity caster) {
        var modifiers = FocusDamageModifiers.capture(caster);
        return new FocusParameterValues(resolve(focus, levels).values(), modifiers.multiplier(), modifiers.bonus());
    }

    public CompoundTag save() {
        CompoundTag tag = new CompoundTag();
        values.forEach(tag::putDouble);
        tag.putDouble("DamageMultiplier", damageMultiplier);
        tag.putDouble("DamageBonus", damageBonus);
        return tag;
    }

    public static FocusParameterValues load(CompoundTag tag) {
        LinkedHashMap<String, Double> values = new LinkedHashMap<>();
        tag.getAllKeys().stream().filter(key -> !key.equals("DamageMultiplier") && !key.equals("DamageBonus")).forEach(key -> values.put(key, tag.getDouble(key)));
        return new FocusParameterValues(values, tag.contains("DamageMultiplier") ? tag.getDouble("DamageMultiplier") : 1.0D, tag.getDouble("DamageBonus"));
    }
}
