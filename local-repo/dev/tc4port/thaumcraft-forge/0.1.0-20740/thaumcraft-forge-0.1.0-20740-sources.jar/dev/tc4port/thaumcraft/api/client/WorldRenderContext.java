package dev.tc4port.thaumcraft.api.client;

import dev.tc4port.thaumcraft.api.client.WorldRenderTransforms;
import dev.tc4port.thaumcraft.api.client.WorldRenderTransforms;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.Camera;
import net.minecraft.client.renderer.culling.Frustum;
import org.joml.Matrix4f;

/**
 * World-pass inputs with camera-relative geometry poses and a separate world view matrix.
 * Native BER poses must pass through WorldRenderTransforms before being retained for this space.
 */
public record WorldRenderContext(Stage getStage, PoseStack getPoseStack, Matrix4f getModelViewMatrix, Matrix4f getProjectionMatrix, float getPartialTick, Camera getCamera, Frustum getFrustum) {

    public enum Stage {

        AFTER_BLOCK_ENTITIES,
        AFTER_TRANSLUCENT_BLOCKS,
        AFTER_PARTICLES,
        AFTER_WEATHER,
        AFTER_LEVEL,
        OTHER
    }
}
