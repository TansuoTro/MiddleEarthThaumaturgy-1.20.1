package dev.tc4port.thaumcraft.api.data;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import dev.tc4port.thaumcraft.api.research.ResearchKey;
import java.util.Optional;

/**
 * Per-item primal capacity in centivis and explicit equipment identity rules.
 */
public record VisAmuletDefinition(int capacityCentivis, Optional<String> requiredResearch, Optional<String> description) {

    private static final Codec<String> DESCRIPTION_CODEC = Codec.STRING.flatXmap(VisAmuletDefinition::validateDescription, VisAmuletDefinition::validateDescription);

    public static final Codec<VisAmuletDefinition> CODEC = RecordCodecBuilder.create(instance -> instance.group(Codec.intRange(1, 1000000000).fieldOf("capacity_centivis").forGetter(VisAmuletDefinition::capacityCentivis), VisAmuletDefinition.native$StrictOptionalFields$of(ResearchKey.CODEC.xmap(ResearchKey::serialized, ResearchKey::parse), "required_research").forGetter(VisAmuletDefinition::requiredResearch), VisAmuletDefinition.native$StrictOptionalFields$of(DESCRIPTION_CODEC, "description").forGetter(VisAmuletDefinition::description)).apply(instance, VisAmuletDefinition::new));

    public VisAmuletDefinition {
        if (capacityCentivis < 1 || capacityCentivis > 1000000000) {
            throw new IllegalArgumentException("Vis amulet capacity must be in 1..1000000000");
        }
        requiredResearch = java.util.Objects.requireNonNull(requiredResearch);
        requiredResearch.ifPresent(ResearchKey::parse);
        description = java.util.Objects.requireNonNull(description);
        description.ifPresent(value -> {
            if (value.length() > 256)
                throw new IllegalArgumentException("Vis amulet description key exceeds 256 characters");
        });
    }

    private static com.mojang.serialization.DataResult<String> validateDescription(String value) {
        return value.length() <= 256 ? com.mojang.serialization.DataResult.success(value) : com.mojang.serialization.DataResult.error(() -> "Vis amulet description key exceeds 256 characters");
    }

    static private <A> com.mojang.serialization.MapCodec<java.util.Optional<A>> native$StrictOptionalFields$of(com.mojang.serialization.Codec<A> codec, java.lang.String name) {
        java.util.Objects.requireNonNull(codec, "codec");
        java.util.Objects.requireNonNull(name, "name");
        return new com.mojang.serialization.MapCodec<>() {

            @Override
            public <T> com.mojang.serialization.DataResult<java.util.Optional<A>> decode(com.mojang.serialization.DynamicOps<T> ops, com.mojang.serialization.MapLike<T> input) {
                T value = input.get(name);
                return value == null ? com.mojang.serialization.DataResult.success(java.util.Optional.empty()) : codec.parse(ops, value).map(java.util.Optional::of);
            }

            @Override
            public <T> com.mojang.serialization.RecordBuilder<T> encode(java.util.Optional<A> input, com.mojang.serialization.DynamicOps<T> ops, com.mojang.serialization.RecordBuilder<T> prefix) {
                return input.isPresent() ? prefix.add(name, codec.encodeStart(ops, input.get())) : prefix;
            }

            @Override
            public <T> java.util.stream.Stream<T> keys(com.mojang.serialization.DynamicOps<T> ops) {
                return java.util.stream.Stream.of(ops.createString(name));
            }

            @Override
            public java.lang.String toString() {
                return "StrictOptionalField[" + name + ": " + codec + "]";
            }
        };
    }

    static private <A> com.mojang.serialization.MapCodec<A> native$StrictOptionalFields$of(com.mojang.serialization.Codec<A> codec, java.lang.String name, A defaultValue) {
        return VisAmuletDefinition.native$StrictOptionalFields$of(codec, name).xmap(value -> value.orElse(defaultValue), value -> java.util.Objects.equals(value, defaultValue) ? java.util.Optional.empty() : java.util.Optional.of(value));
    }
}
