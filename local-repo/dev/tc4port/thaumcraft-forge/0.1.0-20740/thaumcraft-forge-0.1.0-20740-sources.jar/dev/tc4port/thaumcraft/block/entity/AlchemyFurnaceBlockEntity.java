package dev.tc4port.thaumcraft.block.entity;

import dev.tc4port.thaumcraft.nativeimpl.FurnaceFuelPlatform;
import dev.tc4port.thaumcraft.block.AlchemyFurnaceBlock;
import dev.tc4port.thaumcraft.api.machine.ArcaneBellowsApi;
import dev.tc4port.thaumcraft.api.aspect.AspectId;
import dev.tc4port.thaumcraft.api.aspect.AspectQueryApi;
import dev.tc4port.thaumcraft.menu.AlchemyFurnaceMenu;
import dev.tc4port.thaumcraft.registry.TCBlockEntities;
import dev.tc4port.thaumcraft.registry.TCItems;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import javax.annotation.Nullable;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.HolderLookup;
import net.minecraft.core.NonNullList;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.WorldlyContainer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.ContainerData;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import java.lang.Math;
import net.minecraft.world.level.block.entity.BaseContainerBlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityType;

/**
 * TC4's two-slot alchemical furnace and its five-alembic distillation stack.
 */
public final class AlchemyFurnaceBlockEntity extends net.minecraft.world.level.block.entity.BaseContainerBlockEntity implements WorldlyContainer {

    public static final int INPUT_SLOT = 0;

    public static final int FUEL_SLOT = 1;

    public static final int CONTAINER_SIZE = 2;

    public static final int MAX_VIS = 50;

    private static final int[] NO_SLOTS = {};

    private static final int[] INPUT_SLOTS = { INPUT_SLOT };

    private static final int[] FUEL_SLOTS = { FUEL_SLOT };

    private NonNullList<ItemStack> items = NonNullList.withSize(CONTAINER_SIZE, ItemStack.EMPTY);

    private final LinkedHashMap<AspectId, Integer> aspects = new LinkedHashMap<>();

    private int burnTime;

    private int currentBurnTime;

    private int cookTime;

    private int smeltTime = 100;

    private int bellows = -1;

    private boolean speedBoost;

    private int count;

    private final ContainerData data = new ContainerData() {

        @Override
        public int get(int index) {
            return switch(index) {
                case 0 ->
                    (int) Math.min(10000L, (long) AlchemyFurnaceBlockEntity.this.cookTime * 10000 / Math.max(1, AlchemyFurnaceBlockEntity.this.smeltTime));
                case 1 ->
                    AlchemyFurnaceBlockEntity.this.burnTime;
                case 2 ->
                    AlchemyFurnaceBlockEntity.this.currentBurnTime;
                case 3 ->
                    (int) Math.min(10000L, (long) AlchemyFurnaceBlockEntity.this.vis() * 10000 / capacity());
                case 4 ->
                    10000;
                default ->
                    0;
            };
        }

        @Override
        public void set(int index, int value) {
            switch(index) {
                case 1 ->
                    AlchemyFurnaceBlockEntity.this.burnTime = value;
                case 2 ->
                    AlchemyFurnaceBlockEntity.this.currentBurnTime = value;
                default ->
                    {
                    }
            }
        }

        @Override
        public int getCount() {
            return 5;
        }
    };

    public int capacity() {
        return dev.tc4port.thaumcraft.api.essentia.EssentiaStorageApi.capacity(dev.tc4port.thaumcraft.api.essentia.EssentiaStorageApi.ALCHEMICAL_FURNACE, 50, this.level != null && this.level.isClientSide);
    }

    public AlchemyFurnaceBlockEntity(BlockPos pos, BlockState state) {
        super(TCBlockEntities.ALCHEMY_FURNACE.get(), pos, state);
    }

    public static void serverTick(net.minecraft.world.level.Level level, BlockPos pos, BlockState state, AlchemyFurnaceBlockEntity furnace) {
        if (!(level instanceof ServerLevel serverLevel)) {
            return;
        }
        boolean wasBurning = furnace.isBurning();
        boolean changed = false;
        furnace.count++;
        if (furnace.burnTime > 0) {
            furnace.burnTime--;
        }
        if (furnace.bellows < 0) {
            furnace.recountBellows();
        }
        int transferInterval = furnace.speedBoost ? dev.tc4port.thaumcraft.common.TCGameplayParameters.MACHINES_ALCHEMY_FURNACE_BOOSTED_TRANSFER_INTERVAL.intValue() : dev.tc4port.thaumcraft.common.TCGameplayParameters.MACHINES_ALCHEMY_FURNACE_TRANSFER_INTERVAL.intValue();
        if (furnace.count % transferInterval == 0 && !furnace.aspects.isEmpty()) {
            changed |= furnace.transferToAlembics(serverLevel);
        }
        Map<AspectId, Integer> inputAspects = furnace.inputAspects();
        boolean canSmelt = furnace.canSmelt(inputAspects);
        if (furnace.burnTime == 0 && canSmelt) {
            ItemStack fuel = furnace.items.get(FUEL_SLOT);
            int duration = FurnaceFuelPlatform.getBurnTime(fuel, null);
            furnace.currentBurnTime = duration;
            furnace.burnTime = duration;
            if (duration > 0) {
                changed = true;
                furnace.speedBoost = fuel.is(TCItems.ALUMENTUM.get());
                ItemStack remainder = fuel.hasCraftingRemainingItem() ? fuel.getCraftingRemainingItem() : ItemStack.EMPTY;
                fuel.shrink(1);
                if (fuel.isEmpty()) {
                    furnace.items.set(FUEL_SLOT, remainder);
                }
                // Fuel remainder callbacks can be supplied by other mods.
                // Recheck after them, then reuse this result through the
                // otherwise callback-free cooking/consumption path.
                inputAspects = furnace.inputAspects();
                canSmelt = furnace.canSmelt(inputAspects);
            }
        }
        if (furnace.isBurning() && canSmelt) {
            furnace.cookTime++;
            if (furnace.cookTime >= furnace.smeltTime) {
                furnace.cookTime = 0;
                changed |= furnace.smeltOne(inputAspects);
            }
        } else if (furnace.cookTime != 0) {
            furnace.cookTime = 0;
            changed = true;
        }
        if (wasBurning != furnace.isBurning()) {
            changed = true;
        }
        if (changed) {
            furnace.changedAndSync();
        }
    }

    public ContainerData data() {
        return this.data;
    }

    public int vis() {
        return (int) Math.min(Integer.MAX_VALUE, this.aspects.values().stream().mapToLong(Integer::longValue).sum());
    }

    public int aspectAmount(AspectId aspect) {
        return this.aspects.getOrDefault(aspect, 0);
    }

    public Map<AspectId, Integer> aspects() {
        return Collections.unmodifiableMap(new LinkedHashMap<>(this.aspects));
    }

    public boolean isBurning() {
        return this.burnTime > 0;
    }

    public boolean speedBoost() {
        return this.speedBoost;
    }

    public int smeltTime() {
        return this.smeltTime;
    }

    public int bellows() {
        return this.bellows;
    }

    public int cookTime() {
        return this.cookTime;
    }

    public int burnTime() {
        return this.burnTime;
    }

    public void recountBellows() {
        if (this.level == null) {
            this.bellows = 0;
            return;
        }
        this.bellows = 0;
        for (Direction direction : Direction.values()) {
            BlockPos bellowsPos = this.worldPosition.relative(direction);
            if (ArcaneBellowsApi.blowsToward(this.level, bellowsPos, this.worldPosition)) {
                this.bellows++;
            }
        }
    }

    private Map<AspectId, Integer> inputAspects() {
        ItemStack input = this.items.get(INPUT_SLOT);
        return input.isEmpty() ? Map.of() : AspectQueryApi.item(input).amounts();
    }

    public boolean canSmelt() {
        return this.canSmelt(this.inputAspects());
    }

    private boolean canSmelt(Map<AspectId, Integer> objectAspects) {
        if (objectAspects.isEmpty()) {
            return false;
        }
        long objectVis = objectAspects.values().stream().mapToLong(Integer::longValue).sum();
        if (objectVis > capacity() - this.vis()) {
            return false;
        }
        this.smeltTime = Math.max(1, (int) (objectVis * dev.tc4port.thaumcraft.common.TCGameplayParameters.MACHINES_ALCHEMY_FURNACE_TICKS_PER_ASPECT.value() * Math.max(0.0D, 1.0D - dev.tc4port.thaumcraft.common.TCGameplayParameters.MACHINES_ALCHEMY_FURNACE_BELLOWS_SPEED_BONUS.value() * this.bellows)));
        return true;
    }

    public boolean smeltOne() {
        return this.smeltOne(this.inputAspects());
    }

    private boolean smeltOne(Map<AspectId, Integer> objectAspects) {
        if (!this.canSmelt(objectAspects)) {
            return false;
        }
        objectAspects.forEach((aspect, amount) -> this.aspects.merge(aspect, amount, Integer::sum));
        this.items.get(INPUT_SLOT).shrink(1);
        return true;
    }

    /**
     * One core distribution round into the alembic column; does not sync the furnace.
     */
    public boolean transferToAlembics(ServerLevel level) {
        Set<AspectId> excluded = new java.util.LinkedHashSet<>();
        boolean changed = false;
        for (int depth = 1; depth <= 5; depth++) {
            if (!(level.getBlockEntity(this.worldPosition.above(depth)) instanceof ArcaneAlembicBlockEntity alembic)) {
                break;
            }
            AspectId aspect = alembic.aspect();
            if (aspect != null && alembic.amount() < alembic.capacity() && this.take(aspect, 1)) {
                alembic.add(aspect, 1);
                excluded.add(aspect);
                changed = true;
            }
        }
        for (int depth = 1; depth <= 5; depth++) {
            if (!(level.getBlockEntity(this.worldPosition.above(depth)) instanceof ArcaneAlembicBlockEntity alembic)) {
                break;
            }
            if (alembic.aspect() != null && alembic.amount() != 0) {
                continue;
            }
            AspectId selected;
            if (alembic.aspectFilter() == null) {
                selected = this.takeRandom(excluded, level);
            } else {
                AspectId filter = alembic.aspectFilter();
                selected = filter != null && this.take(filter, 1) ? filter : null;
            }
            if (selected != null) {
                alembic.add(selected, 1);
                changed = true;
                break;
            }
        }
        return changed;
    }

    private AspectId takeRandom(Set<AspectId> excluded, ServerLevel level) {
        List<AspectId> candidates = new ArrayList<>();
        this.aspects.forEach((aspect, amount) -> {
            if (amount > 0 && !excluded.contains(aspect)) {
                candidates.add(aspect);
            }
        });
        if (candidates.isEmpty()) {
            return null;
        }
        AspectId selected = candidates.get(level.random.nextInt(candidates.size()));
        return this.take(selected, 1) ? selected : null;
    }

    /**
     * Takes exactly {@code amount} when stored; does not sync.
     */
    public boolean take(AspectId aspect, int amount) {
        int available = this.aspects.getOrDefault(aspect, 0);
        if (available < amount) {
            return false;
        }
        int remaining = available - amount;
        if (remaining <= 0) {
            this.aspects.remove(aspect);
        } else {
            this.aspects.put(aspect, remaining);
        }
        return true;
    }

    /**
     * Saves and updates the lit/filled appearance and clients.
     */
    public void changedAndSync() {
        this.setChanged();
        if (this.level != null && !this.level.isClientSide) {
            BlockState state = this.getBlockState();
            BlockState visual = state.setValue(AlchemyFurnaceBlock.LIT, this.isBurning()).setValue(AlchemyFurnaceBlock.FILLED, this.vis() > 0);
            if (state != visual) {
                this.level.setBlock(this.worldPosition, visual, Block.UPDATE_ALL);
            } else {
                this.level.sendBlockUpdated(this.worldPosition, state, state, Block.UPDATE_CLIENTS);
            }
        }
    }

    @Override
    public int getContainerSize() {
        return CONTAINER_SIZE;
    }

    @Override
    protected Component getDefaultName() {
        return Component.translatable("container.alchemyfurnace");
    }

    protected NonNullList<ItemStack> getItems() {
        return this.items;
    }

    protected void setItems(NonNullList<ItemStack> items) {
        this.items = items;
    }

    @Override
    public boolean canPlaceItem(int slot, ItemStack stack) {
        return slot == INPUT_SLOT ? !AspectQueryApi.item(stack).amounts().isEmpty() : slot == FUEL_SLOT && FurnaceFuelPlatform.getBurnTime(stack, null) > 0;
    }

    @Override
    public int[] getSlotsForFace(Direction side) {
        if (side == Direction.UP) {
            return NO_SLOTS;
        }
        return side == Direction.DOWN ? FUEL_SLOTS : INPUT_SLOTS;
    }

    @Override
    public boolean canPlaceItemThroughFace(int index, ItemStack stack, Direction direction) {
        return direction != Direction.UP && this.canPlaceItem(index, stack);
    }

    @Override
    public boolean canTakeItemThroughFace(int index, ItemStack stack, Direction direction) {
        return direction != Direction.DOWN || index != FUEL_SLOT || stack.is(net.minecraft.world.item.Items.BUCKET);
    }

    @Override
    public void load(CompoundTag tag) {
        HolderLookup.Provider registries = persistenceRegistries();
        super.load(tag);
        this.items = NonNullList.withSize(CONTAINER_SIZE, ItemStack.EMPTY);
        {
            net.minecraft.nbt.CompoundTag native$operand$14313 = tag;
            net.minecraft.core.NonNullList<net.minecraft.world.item.ItemStack> native$operand$14314 = this.items;
            net.minecraft.core.HolderLookup.Provider native$operand$14315 = registries;
            net.minecraft.world.ContainerHelper.loadAllItems(native$operand$14313, native$operand$14314);
        }
        this.burnTime = tag.getInt("BurnTime");
        // TileAlchemyFurnace derived this after loading the fuel slot rather
        // than persisting it. This also keeps the burn bar sane for legacy
        // saves which never carried a separate current-burn-time field.
        this.currentBurnTime = FurnaceFuelPlatform.getBurnTime(this.items.get(FUEL_SLOT), null);
        this.cookTime = tag.getInt("CookTime");
        // The legacy tile resets this transient recipe duration to its
        // default and recalculates it from the next input it can smelt.
        this.smeltTime = 100;
        this.speedBoost = tag.getBoolean("speedBoost");
        this.aspects.clear();
        ListTag aspectTag = tag.getList("Aspects", Tag.TAG_COMPOUND);
        for (int index = 0; index < aspectTag.size(); index++) {
            CompoundTag entry = aspectTag.getCompound(index);
            AspectId key = parsePersistedAspect(entry.getString("key"));
            int amount = entry.getInt("amount");
            if (key != null && amount > 0) {
                this.aspects.merge(key, amount, Integer::sum);
            }
        }
        this.bellows = -1;
    }

    @Override
    protected void saveAdditional(CompoundTag tag) {
        HolderLookup.Provider registries = persistenceRegistries();
        super.saveAdditional(tag);
        {
            net.minecraft.nbt.CompoundTag native$operand$14316 = tag;
            net.minecraft.core.NonNullList<net.minecraft.world.item.ItemStack> native$operand$14317 = this.items;
            net.minecraft.core.HolderLookup.Provider native$operand$14318 = registries;
            net.minecraft.nbt.CompoundTag native$result$14319 = (net.minecraft.world.ContainerHelper.saveAllItems(native$operand$14316, native$operand$14317));
        }
        tag.putInt("BurnTime", this.burnTime);
        tag.putInt("CookTime", this.cookTime);
        tag.putBoolean("speedBoost", this.speedBoost);
        ListTag aspectTag = new ListTag();
        this.aspects.forEach((aspect, amount) -> {
            CompoundTag entry = new CompoundTag();
            entry.putString("key", aspect.serialized());
            entry.putInt("amount", amount);
            aspectTag.add(entry);
        });
        tag.put("Aspects", aspectTag);
    }

    @Nullable
    private static AspectId parsePersistedAspect(@Nullable String value) {
        try {
            return value == null || value.isBlank() ? null : AspectId.parse(value);
        } catch (RuntimeException ignored) {
            return null;
        }
    }

    @Override
    public CompoundTag getUpdateTag() {
        return this.saveWithoutMetadata();
    }

    @Override
    public Packet<ClientGamePacketListener> getUpdatePacket() {
        return ClientboundBlockEntityDataPacket.create(this);
    }

    @Override
    protected AbstractContainerMenu createMenu(int containerId, Inventory inventory) {
        // Vanilla spectator opening bypasses our extra-data menu transport.
        if (inventory.player.isSpectator()) {
            return null;
        }
        return new AlchemyFurnaceMenu(containerId, inventory, this, this.data);
    }

    protected final HolderLookup.Provider persistenceRegistries() {
        if (level != null)
            return level.registryAccess();
        var server = net.minecraftforge.server.ServerLifecycleHooks.getCurrentServer();
        return server != null ? server.registryAccess() : net.minecraft.core.RegistryAccess.fromRegistryOfRegistries(net.minecraft.core.registries.BuiltInRegistries.REGISTRY);
    }

    protected static net.minecraft.network.chat.Component parseCustomNameSafe(String value, HolderLookup.Provider registries) {
        try {
            return net.minecraft.network.chat.Component.Serializer.fromJson(value);
        } catch (RuntimeException exception) {
            return null;
        }
    }

    @Override
    public boolean isEmpty() {
        return (switch(0) {
            default ->
                {
                    net.minecraft.core.NonNullList<net.minecraft.world.item.ItemStack> native$bodyResult$4848 = null;
                    native$bodyReturn$4849: {
                        if (true) {
                            {
                                native$bodyResult$4848 = this.items;
                                break native$bodyReturn$4849;
                            }
                        }
                    }
                    yield native$bodyResult$4848;
                }
        }).stream().allMatch(ItemStack::isEmpty);
    }

    @Override
    public ItemStack getItem(int index) {
        return (switch(0) {
            default ->
                {
                    net.minecraft.core.NonNullList<net.minecraft.world.item.ItemStack> native$bodyResult$5339 = null;
                    native$bodyReturn$5340: {
                        if (true) {
                            {
                                native$bodyResult$5339 = this.items;
                                break native$bodyReturn$5340;
                            }
                        }
                    }
                    yield native$bodyResult$5339;
                }
        }).get(index);
    }

    @Override
    public ItemStack removeItem(int index, int count) {
        ItemStack removed = net.minecraft.world.ContainerHelper.removeItem((switch(0) {
            default ->
                {
                    net.minecraft.core.NonNullList<net.minecraft.world.item.ItemStack> native$bodyResult$3947 = null;
                    native$bodyReturn$3948: {
                        if (true) {
                            {
                                native$bodyResult$3947 = this.items;
                                break native$bodyReturn$3948;
                            }
                        }
                    }
                    yield native$bodyResult$3947;
                }
        }), index, count);
        if (!removed.isEmpty())
            setChanged();
        return removed;
    }

    @Override
    public ItemStack removeItemNoUpdate(int index) {
        return net.minecraft.world.ContainerHelper.takeItem((switch(0) {
            default ->
                {
                    net.minecraft.core.NonNullList<net.minecraft.world.item.ItemStack> native$bodyResult$5341 = null;
                    native$bodyReturn$5342: {
                        if (true) {
                            {
                                native$bodyResult$5341 = this.items;
                                break native$bodyReturn$5342;
                            }
                        }
                    }
                    yield native$bodyResult$5341;
                }
        }), index);
    }

    @Override
    public void setItem(int index, ItemStack stack) {
        (switch(0) {
            default ->
                {
                    net.minecraft.core.NonNullList<net.minecraft.world.item.ItemStack> native$bodyResult$5343 = null;
                    native$bodyReturn$5344: {
                        if (true) {
                            {
                                native$bodyResult$5343 = this.items;
                                break native$bodyReturn$5344;
                            }
                        }
                    }
                    yield native$bodyResult$5343;
                }
        }).set(index, stack);
        int limit = Math.min(getMaxStackSize(), stack.getMaxStackSize());
        if (stack.getCount() > limit)
            stack.setCount(limit);
        setChanged();
    }

    @Override
    public void clearContent() {
        (switch(0) {
            default ->
                {
                    net.minecraft.core.NonNullList<net.minecraft.world.item.ItemStack> native$bodyResult$5345 = null;
                    native$bodyReturn$5346: {
                        if (true) {
                            {
                                native$bodyResult$5345 = this.items;
                                break native$bodyReturn$5346;
                            }
                        }
                    }
                    yield native$bodyResult$5345;
                }
        }).clear();
    }

    @Override
    public boolean stillValid(net.minecraft.world.entity.player.Player player) {
        return net.minecraft.world.Container.stillValidBlockEntity(this, player);
    }

    @Override
    public net.minecraft.world.phys.AABB getRenderBoundingBox() {
        return AlchemyFurnaceBlockEntity.native$ClientBlockEntityBounds$bounds(this);
    }

    @Override()
    public void onDataPacket(net.minecraft.network.Connection connection, net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket packet) {
        handleUpdateTag(packet.getTag());
    }

    @SuppressWarnings({ "rawtypes", "unchecked" })
    static private net.minecraft.world.phys.AABB native$ClientBlockEntityBounds$bounds(net.minecraft.world.level.block.entity.BlockEntity blockEntity) {
        var renderer = net.minecraft.client.Minecraft.getInstance().getBlockEntityRenderDispatcher().getRenderer(blockEntity);
        return renderer instanceof dev.tc4port.thaumcraft.nativeimpl.NativeBlockEntityRenderer shared ? shared.getRenderBoundingBox(blockEntity) : new net.minecraft.world.phys.AABB(blockEntity.getBlockPos());
    }

    private boolean native$capabilitiesInvalid$16955;

    public boolean native$capabilityActive$16804;

    private java.util.Map<net.minecraft.core.Direction, net.minecraftforge.common.util.LazyOptional<net.minecraftforge.items.IItemHandler>> native$capabilityHandle$16805;

    @Override
    public <native$capabilityResultType$16956> net.minecraftforge.common.util.LazyOptional<native$capabilityResultType$16956> getCapability(net.minecraftforge.common.capabilities.Capability<native$capabilityResultType$16956> native$requestedCapability$16957, net.minecraft.core.Direction native$requestedFace$16958) {
        getCapabilities();
        synchronized (this) {
            if (native$capabilitiesInvalid$16955)
                return net.minecraftforge.common.util.LazyOptional.empty();
            if (native$capabilityActive$16804 && native$requestedCapability$16957 == (net.minecraftforge.common.capabilities.ForgeCapabilities.ITEM_HANDLER)) {
                if (native$capabilityHandle$16805 == null)
                    native$capabilityHandle$16805 = new java.util.HashMap<>();
                net.minecraftforge.common.util.LazyOptional<net.minecraftforge.items.IItemHandler> native$capabilityResult$16960 = native$capabilityHandle$16805.computeIfAbsent(native$requestedFace$16958, native$capabilityFace$16806 -> {
                    net.minecraftforge.items.IItemHandler native$endpoint$121 = (switch(0) {
                        default ->
                            {
                                net.minecraft.world.WorldlyContainer native$operand$12761 = dev.tc4port.thaumcraft.block.entity.AlchemyFurnaceBlockEntity.this;
                                net.minecraft.core.Direction native$operand$12762 = native$capabilityFace$16806;
                                net.minecraftforge.items.IItemHandler native$result$12763 = (new net.minecraftforge.items.wrapper.SidedInvWrapper(native$operand$12761, native$operand$12762));
                                yield native$result$12763;
                            }
                    });
                    return native$endpoint$121 == null ? net.minecraftforge.common.util.LazyOptional.empty() : net.minecraftforge.common.util.LazyOptional.of(() -> native$endpoint$121);
                });
                if (native$capabilityResult$16960.isPresent())
                    return native$capabilityResult$16960.cast();
            }
        }
        return super.getCapability(native$requestedCapability$16957, native$requestedFace$16958);
    }

    @Override
    public void invalidateCaps() {
        java.util.List<net.minecraftforge.common.util.LazyOptional<?>> native$expiredCapabilities$16959 = new java.util.ArrayList<>();
        synchronized (this) {
            native$capabilitiesInvalid$16955 = true;
            if (native$capabilityHandle$16805 != null) {
                native$expiredCapabilities$16959.addAll(native$capabilityHandle$16805.values());
                native$capabilityHandle$16805 = null;
            }
        }
        try {
            super.invalidateCaps();
        } finally {
            native$expiredCapabilities$16959.forEach(net.minecraftforge.common.util.LazyOptional::invalidate);
        }
    }

    @Override
    public void reviveCaps() {
        super.reviveCaps();
        synchronized (this) {
            native$capabilitiesInvalid$16955 = false;
        }
    }
}
