package dev.tc4port.thaumcraft.api.machine;

/**
 * Result of one server-authoritative Arcane Ear note write.
 */
public enum ArcaneEarControlResult {

    UPDATED,
    UNCHANGED,
    NOT_AN_ARCANE_EAR,
    TARGET_UNLOADED,
    OFF_SERVER_THREAD,
    INVALID_REQUEST
}
