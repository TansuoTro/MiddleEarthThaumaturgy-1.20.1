package dev.tc4port.thaumcraft.api.machine;

import dev.tc4port.thaumcraft.block.entity.InfusionMatrixBlockEntity;
import java.util.Objects;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.Level;

/**
 * Loaded-only access to single steps of TC's own infusion matrix.
 */
public final class InfusionMatrixApi {

    private InfusionMatrixApi() {
    }

    /**
     * Runs one core infusion work step on an active matrix that is crafting:
     * the same step the matrix tick runs at its work interval, including its
     * instability roll, essentia drain, ingredient absorption and completion
     * or failure.
     *
     * <p>The work interval is not checked and the matrix keeps ticking on its
     * own, so every extra call advances crafting by an extra step. Call rate
     * and its consequences are the caller's responsibility.
     *
     * @return false when not on the owning server thread, unloaded (including
     *         the chunks the matrix scans), not a matrix, or the matrix is not
     *         active and crafting
     */
    public static boolean craftCycle(Level level, BlockPos pos) {
        Objects.requireNonNull(level, "level");
        Objects.requireNonNull(pos, "pos");
        if (!(level instanceof ServerLevel serverLevel) || !serverLevel.getServer().isSameThread() || !level.hasChunkAt(pos) || !(level.getBlockEntity(pos) instanceof InfusionMatrixBlockEntity matrix) || !matrix.surroundingsLoaded() || !matrix.active() || !matrix.crafting()) {
            return false;
        }
        matrix.craftCycle();
        matrix.setChanged();
        return true;
    }
}
