package dev.tc4port.thaumcraft.api.event;

import dev.tc4port.thaumcraft.api.event.CriticalDecision;
import dev.tc4port.thaumcraft.api.event.HookDecision;
import dev.tc4port.thaumcraft.nativeimpl.MobSplitHook;
import dev.tc4port.thaumcraft.api.event.CriticalDecision;
import dev.tc4port.thaumcraft.api.event.HookDecision;
import dev.tc4port.thaumcraft.nativeimpl.MobSplitHook;
import java.util.List;
import net.minecraft.world.Container;
import net.minecraft.world.DifficultyInstance;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.*;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.core.BlockPos;

public final class GameplayHooks {

    private GameplayHooks() {
    }

    /**
     * Runs native harvest-start callbacks without starting the player's break timer or destroying the block.
     */
    public static boolean startBlockHarvest(ServerPlayer player, BlockPos pos, net.minecraft.core.Direction face) {
        var level = player.serverLevel();
        if (!level.mayInteract(player, pos) || player.blockActionRestricted(level, pos, player.gameMode.getGameModeForPlayer()) || level.getBlockState(pos).getDestroySpeed(level, pos) < 0.0F)
            return false;
        var event = net.minecraftforge.common.ForgeHooks.onLeftClickBlock(player, pos, face, net.minecraft.network.protocol.game.ServerboundPlayerActionPacket.Action.START_DESTROY_BLOCK);
        if (event.isCanceled() || event.getUseItem() == net.minecraftforge.eventbus.api.Event.Result.DENY)
            return false;
        var state = level.getBlockState(pos);
        if (state.isAir() || !level.mayInteract(player, pos) || state.getDestroySpeed(level, pos) < 0.0F)
            return false;
        if (event.getUseBlock() != net.minecraftforge.eventbus.api.Event.Result.DENY)
            state.attack(level, pos, player);
        return true;
    }

    public static SpawnGroupData finalizeMobSpawn(Mob mob, ServerLevelAccessor level, DifficultyInstance difficulty, MobSpawnType type, SpawnGroupData data) {
        return net.minecraftforge.event.ForgeEventFactory.onFinalizeSpawn(mob, level, difficulty, type, data, null);
    }

    public static void firePlayerCraftingEvent(Player player, ItemStack output, Container inventory) {
        net.minecraftforge.event.ForgeEventFactory.firePlayerCraftingEvent(player, output, inventory);
    }

    public static InteractionResultHolder<ItemStack> onArrowNock(ItemStack bow, Level level, Player player, InteractionHand hand, boolean ammunition) {
        return net.minecraftforge.event.ForgeEventFactory.onArrowNock(bow, level, player, hand, ammunition);
    }

    public static int onArrowLoose(ItemStack bow, Level level, Player player, int charge, boolean ammunition) {
        return net.minecraftforge.event.ForgeEventFactory.onArrowLoose(bow, level, player, charge, ammunition);
    }

    public static net.minecraftforge.event.entity.EntityTeleportEvent.EnderEntity onEnderTeleport(LivingEntity entity, double x, double y, double z) {
        return net.minecraftforge.event.ForgeEventFactory.onEnderTeleport(entity, x, y, z);
    }

    public static HookDecision onMobSplit(Mob parent, List<Mob> children) {
        return new HookDecision(net.minecraftforge.common.MinecraftForge.EVENT_BUS.post(new MobSplitHook(parent, children)));
    }

    public static HookDecision fireBlockBreak(Level level, GameType mode, ServerPlayer player, BlockPos pos, BlockState state) {
        // This is an authorization hook, also used before in-place replacement
        // and simulated actions. ForgeHooks.onBlockBreakEvent additionally sends
        // a speculative air/fluid update, which would expose an uncommitted edit.
        ItemStack held = player.getMainHandItem();
        boolean preCanceled = !held.isEmpty() && !held.getItem().canAttackBlock(state, level, pos, player);
        if (player.blockActionRestricted(level, pos, mode)) {
            preCanceled = true;
        }
        var event = new net.minecraftforge.event.level.BlockEvent.BreakEvent(level, pos, state, player);
        event.setCanceled(preCanceled);
        net.minecraftforge.common.MinecraftForge.EVENT_BUS.post(event);
        if (event.isCanceled()) {
            player.connection.send(new net.minecraft.network.protocol.game.ClientboundBlockUpdatePacket(level, pos));
            var blockEntity = level.getBlockEntity(pos);
            if (blockEntity != null) {
                var packet = blockEntity.getUpdatePacket();
                if (packet != null) {
                    player.connection.send(packet);
                }
            }
        }
        return new HookDecision(event.isCanceled());
    }

    public static CriticalDecision fireCriticalHit(Player player, Entity target, boolean critical, float multiplier) {
        var event = net.minecraftforge.common.ForgeHooks.getCriticalHit(player, target, critical, multiplier);
        return event == null ? new CriticalDecision(false, multiplier) : new CriticalDecision(true, event.getDamageModifier());
    }

    public record GrowthDecision(boolean isCanceled, boolean isSuccessful) {
    }

    public static GrowthDecision bonemeal(net.minecraft.world.entity.player.Player player, net.minecraft.world.level.Level level, net.minecraft.core.BlockPos pos, net.minecraft.world.level.block.state.BlockState state, net.minecraft.world.item.ItemStack stack) {
        var e = new net.minecraftforge.event.entity.player.BonemealEvent(player, level, pos, state, stack);
        net.minecraftforge.common.MinecraftForge.EVENT_BUS.post(e);
        return new GrowthDecision(e.isCanceled() || e.getResult() != net.minecraftforge.eventbus.api.Event.Result.DEFAULT, !e.isCanceled() && e.getResult() == net.minecraftforge.eventbus.api.Event.Result.ALLOW);
    }

    public static HookDecision rightClickBlock(net.minecraft.world.entity.player.Player player, net.minecraft.world.InteractionHand hand, net.minecraft.core.BlockPos pos, net.minecraft.world.phys.BlockHitResult hit) {
        var e = new net.minecraftforge.event.entity.player.PlayerInteractEvent.RightClickBlock(player, hand, pos, hit);
        net.minecraftforge.common.MinecraftForge.EVENT_BUS.post(e);
        return new HookDecision(e.isCanceled());
    }

    public static HookDecision attackEntity(net.minecraft.world.entity.player.Player player, net.minecraft.world.entity.Entity target) {
        var e = new net.minecraftforge.event.entity.player.AttackEntityEvent(player, target);
        net.minecraftforge.common.MinecraftForge.EVENT_BUS.post(e);
        return new HookDecision(e.isCanceled());
    }

    public static boolean harvestCheck(Player player, BlockState state, BlockGetter level, BlockPos pos) {
        return net.minecraftforge.common.ForgeHooks.isCorrectToolForDrops(state, player);
    }

    public record TeleportDecision(boolean isCanceled, net.minecraft.world.phys.Vec3 getTarget) {
    }

    public static TeleportDecision teleport(Entity entity, double x, double y, double z) {
        var event = new net.minecraftforge.event.entity.EntityTeleportEvent(entity, x, y, z);
        net.minecraftforge.common.MinecraftForge.EVENT_BUS.post(event);
        return new TeleportDecision(event.isCanceled(), event.getTarget());
    }
}
