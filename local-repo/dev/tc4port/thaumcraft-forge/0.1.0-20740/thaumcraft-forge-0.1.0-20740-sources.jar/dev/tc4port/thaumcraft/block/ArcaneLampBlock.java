package dev.tc4port.thaumcraft.block;

import com.mojang.serialization.MapCodec;
import dev.tc4port.thaumcraft.block.entity.ArcaneLampBlockEntity;
import dev.tc4port.thaumcraft.registry.TCBlockEntities;
import javax.annotation.Nullable;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityTicker;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.world.level.block.state.properties.DirectionProperty;
import net.minecraft.world.level.pathfinder.PathComputationType;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.VoxelShape;
import dev.tc4port.thaumcraft.nativeimpl.ClientExtensionTarget;
import dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.Explosion;

/**
 * The three BlockMetalDevice lamp metadata identities.
 */
public final class ArcaneLampBlock extends net.minecraft.world.level.block.BaseEntityBlock implements dev.tc4port.thaumcraft.nativeimpl.ClientExtensionTarget {

    // Forge calls initializeClient from the native superclass constructor. Do not add a field initializer.
    private java.util.function.Consumer<net.minecraftforge.client.extensions.common.IClientBlockExtensions> platform$clientInstaller;

    public static final DirectionProperty FACING = BlockStateProperties.FACING;

    public static final BooleanProperty CHARGED = BooleanProperty.create("charged");

    private static final VoxelShape SHAPE = Block.box(4.0, 2.0, 4.0, 12.0, 14.0, 12.0);

    public enum Kind {

        ARCANE, GROWTH, FERTILITY
    }

    private final Kind kind;

    private final MapCodec<ArcaneLampBlock> codec;

    public ArcaneLampBlock(Kind kind, BlockBehaviour.Properties properties) {
        this(properties, kind, properties, true);
    }

    protected MapCodec<ArcaneLampBlock> codec() {
        return this.codec;
    }

    public Kind kind() {
        return this.kind;
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(FACING, CHARGED);
    }

    @Nullable
    @Override
    public BlockState getStateForPlacement(BlockPlaceContext context) {
        return this.defaultBlockState().setValue(FACING, context.getClickedFace().getOpposite());
    }

    @Nullable
    @Override
    public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        return new ArcaneLampBlockEntity(pos, state);
    }

    @Nullable
    @Override
    public <T extends BlockEntity> BlockEntityTicker<T> getTicker(Level level, BlockState state, BlockEntityType<T> type) {
        return level.isClientSide ? null : createTickerHelper(type, TCBlockEntities.ARCANE_LAMP.get(), ArcaneLampBlockEntity::serverTick);
    }

    @Override
    public RenderShape getRenderShape(BlockState state) {
        return RenderShape.MODEL;
    }

    @Override
    public VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
        return SHAPE;
    }

    @Override
    public VoxelShape getCollisionShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
        return SHAPE;
    }

    @Override
    public void neighborChanged(BlockState state, Level level, BlockPos pos, Block neighborBlock, BlockPos neighborPos, boolean movedByPiston) {
        super.neighborChanged(state, level, pos, neighborBlock, neighborPos, movedByPiston);
        /*
         * The source checked only ordinary Arcane and Growth lamps here.
         * Fertility lamps therefore keep floating after their support is
         * removed; this conspicuous 4.2.3.5 quirk is intentional.
         */
        if (level.isClientSide || this.kind == Kind.FERTILITY || !level.getBlockState(pos.relative(state.getValue(FACING))).isAir()) {
            return;
        }
        BlockEntity blockEntity = level.getBlockEntity(pos);
        Block.dropResources(state, level, pos, blockEntity);
        level.removeBlock(pos, false);
    }

    @Override
    public void onRemove(BlockState state, Level level, BlockPos pos, BlockState newState, boolean movedByPiston) {
        if (!state.is(newState.getBlock()) && this.kind == Kind.ARCANE && level instanceof ServerLevel serverLevel && level.getBlockEntity(pos) instanceof ArcaneLampBlockEntity lamp) {
            lamp.removeSecondaryLights(serverLevel);
        }
        super.onRemove(state, level, pos, newState, movedByPiston);
    }

    @Override
    public boolean isPathfindable(BlockState state, BlockGetter level, BlockPos pos, PathComputationType pathType) {
        // The lamp body floats above the floor, so the cell is never open.
        return false;
    }

    private ArcaneLampBlock(net.minecraft.world.level.block.state.BlockBehaviour.Properties native$NativeEntityBlock$arg0, Kind kind, BlockBehaviour.Properties properties, boolean native$NativeEntityBlock$captured) {
        super(native$NativeEntityBlock$arg0);
        this.kind = kind;
        this.codec = ArcaneLampBlock.native$BlockCodecPlatform$simple(value -> new ArcaneLampBlock(kind, value));
        this.registerDefaultState(this.stateDefinition.any().setValue(FACING, Direction.DOWN).setValue(CHARGED, kind == Kind.ARCANE));
    }

    @Override
    public void initializeClient(java.util.function.Consumer<net.minecraftforge.client.extensions.common.IClientBlockExtensions> installer) {
        platform$clientInstaller = installer;
        super.initializeClient(installer);
    }

    @Override
    public void platform$clientExtension(Object extension) {
        java.util.Objects.requireNonNull(platform$clientInstaller, "Forge initializeClient must run before client extension registration").accept((net.minecraftforge.client.extensions.common.IClientBlockExtensions) extension);
    }

    @Override
    public InteractionResult use(BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
        ItemUseResult result = (switch(0) {
            default ->
                {
                    net.minecraft.world.item.ItemStack native$bodyOperand$4145 = player.getItemInHand(hand);
                    net.minecraft.world.level.block.state.BlockState native$bodyOperand$4146 = state;
                    net.minecraft.world.level.Level native$bodyOperand$4147 = level;
                    net.minecraft.core.BlockPos native$bodyOperand$4148 = pos;
                    net.minecraft.world.entity.player.Player native$bodyOperand$4149 = player;
                    net.minecraft.world.InteractionHand native$bodyOperand$4150 = hand;
                    net.minecraft.world.phys.BlockHitResult native$bodyOperand$4151 = hit;
                    dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult native$bodyResult$4152 = null;
                    native$bodyReturn$4153: {
                        if (true) {
                            {
                                native$bodyResult$4152 = dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
                                break native$bodyReturn$4153;
                            }
                        }
                    }
                    yield native$bodyResult$4152;
                }
        });
        return result == ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION ? (hand == InteractionHand.MAIN_HAND ? (switch(0) {
            default ->
                {
                    net.minecraft.world.level.block.state.BlockState native$bodyOperand$3484 = state;
                    net.minecraft.world.level.Level native$bodyOperand$3485 = level;
                    net.minecraft.core.BlockPos native$bodyOperand$3486 = pos;
                    net.minecraft.world.entity.player.Player native$bodyOperand$3487 = player;
                    net.minecraft.world.phys.BlockHitResult native$bodyOperand$3488 = hit;
                    net.minecraft.world.InteractionResult native$bodyResult$3489 = null;
                    native$bodyReturn$3490: {
                        if (true) {
                            {
                                native$bodyResult$3489 = super.use(native$bodyOperand$3484, native$bodyOperand$3485, native$bodyOperand$3486, native$bodyOperand$3487, net.minecraft.world.InteractionHand.MAIN_HAND, native$bodyOperand$3488);
                                break native$bodyReturn$3490;
                            }
                        }
                    }
                    yield native$bodyResult$3489;
                }
        }) : InteractionResult.PASS) : result.result();
    }

    protected ItemUseResult interactWithItem(ItemStack stack, BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
        return dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
    }

    protected InteractionResult interactWithoutItem(BlockState state, Level level, BlockPos pos, Player player, BlockHitResult hit) {
        return super.use(state, level, pos, player, net.minecraft.world.InteractionHand.MAIN_HAND, hit);
    }

    @Override
    public void playerWillDestroy(Level level, BlockPos pos, BlockState state, Player player) {
        {
            net.minecraft.world.level.Level native$bodyOperand$5666 = level;
            net.minecraft.core.BlockPos native$bodyOperand$5667 = pos;
            net.minecraft.world.level.block.state.BlockState native$bodyOperand$5668 = state;
            net.minecraft.world.entity.player.Player native$bodyOperand$5669 = player;
            net.minecraft.world.level.block.state.BlockState native$bodyResult$5670 = null;
            native$bodyReturn$5671: {
                if (true) {
                    super.playerWillDestroy(native$bodyOperand$5666, native$bodyOperand$5667, native$bodyOperand$5668, native$bodyOperand$5669);
                    {
                        native$bodyResult$5670 = native$bodyOperand$5668;
                        break native$bodyReturn$5671;
                    }
                }
            }
        }
    }

    public BlockState beforePlayerDestroy(Level level, BlockPos pos, BlockState state, Player player) {
        super.playerWillDestroy(level, pos, state, player);
        return state;
    }

    protected boolean survivesSharedExplosion() {
        return false;
    }

    public int getExpDrop(net.minecraft.world.level.block.state.BlockState native$callbackInput$1050, net.minecraft.world.level.LevelReader native$callbackInput$1051, net.minecraft.util.RandomSource native$callbackInput$1052, net.minecraft.core.BlockPos native$callbackInput$1053, int native$callbackInput$1054, int native$callbackInput$1055) {
        net.minecraft.world.level.block.state.BlockState state = native$callbackInput$1050;
        net.minecraft.util.RandomSource random = native$callbackInput$1052;
        return 0;
    }

    @Override
    public void onBlockExploded(BlockState state, Level level, BlockPos pos, Explosion explosion) {
        if (!(switch(0) {
            default ->
                {
                    boolean native$bodyResult$5217 = false;
                    native$bodyReturn$5218: {
                        if (true) {
                            {
                                native$bodyResult$5217 = false;
                                break native$bodyReturn$5218;
                            }
                        }
                    }
                    yield native$bodyResult$5217;
                }
        }))
            super.onBlockExploded(state, level, pos, explosion);
    }

    @Override
    public boolean canDropFromExplosion(BlockState state, BlockGetter level, BlockPos pos, Explosion explosion) {
        return !(switch(0) {
            default ->
                {
                    boolean native$bodyResult$4154 = false;
                    native$bodyReturn$4155: {
                        if (true) {
                            {
                                native$bodyResult$4154 = false;
                                break native$bodyReturn$4155;
                            }
                        }
                    }
                    yield native$bodyResult$4154;
                }
        }) && super.canDropFromExplosion(state, level, pos, explosion);
    }

    static private <B extends net.minecraft.world.level.block.Block> com.mojang.serialization.MapCodec<B> native$BlockCodecPlatform$simple(java.util.function.Function<net.minecraft.world.level.block.state.BlockBehaviour.Properties, B> factory) {
        // Vanilla 1.21's Properties codec is a unit codec. Retain that schema for shared block definitions.
        return com.mojang.serialization.codecs.RecordCodecBuilder.mapCodec(instance -> instance.group(com.mojang.serialization.Codec.unit(net.minecraft.world.level.block.state.BlockBehaviour.Properties::of).fieldOf("properties").forGetter((B block) -> net.minecraft.world.level.block.state.BlockBehaviour.Properties.copy(block))).apply(instance, factory));
    }
}
