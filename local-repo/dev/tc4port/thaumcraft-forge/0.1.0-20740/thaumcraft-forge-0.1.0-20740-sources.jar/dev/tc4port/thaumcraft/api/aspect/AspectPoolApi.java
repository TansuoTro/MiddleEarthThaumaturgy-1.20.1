package dev.tc4port.thaumcraft.api.aspect;

import dev.tc4port.thaumcraft.util.RuntimeWarnings;
import dev.tc4port.thaumcraft.state.TCObjectState;
import dev.tc4port.thaumcraft.data.PlayerKnowledgeData;
import dev.tc4port.thaumcraft.network.message.AspectGainMessage;
import dev.tc4port.thaumcraft.platform.AspectGainPlatform;
import java.util.LinkedHashMap;
import java.util.Objects;
import java.util.LinkedHashSet;
import java.util.Set;
import net.minecraft.server.level.ServerPlayer;

/**
 * Controlled server-side additions to a player's whole-aspect knowledge pool.
 */
public final class AspectPoolApi {

    private AspectPoolApi() {
    }

    /**
     * Current data-pack reward, including zero for discovery without points.
     */
    public static int firstDiscoveryBonus() {
        return dev.tc4port.thaumcraft.common.TCGameplayParameters.RESEARCH_KNOWLEDGE_FIRST_DISCOVERY_BONUS.intValue();
    }

    /**
     * Server command update without gain/discovery particles or messages.
     * A positive grant that first reveals the aspect still includes the
     * mandatory discovery bonus.
     */
    public static boolean addSilently(ServerPlayer player, AspectId aspect, int amount) {
        Objects.requireNonNull(player, "player");
        Objects.requireNonNull(aspect, "aspect");
        if (!player.server.isSameThread())
            return false;
        if (amount <= 0) {
            return dev.tc4port.thaumcraft.common.PlayerKnowledgeService.addAspectPool(player, aspect, amount);
        }
        PlayerKnowledgeData current = TCObjectState.PLAYER_KNOWLEDGE.get(player);
        int accepted = acceptedPositiveAddition(current, aspect, amount);
        return accepted > 0 && dev.tc4port.thaumcraft.common.PlayerKnowledgeService.addAspectPool(player, aspect, accepted);
    }

    public static int add(ServerPlayer player, AspectId aspect, int requested, VisAction action) {
        return add(player, aspect, requested, AspectPoolFeedback.POOL_GAIN, action);
    }

    public static int add(ServerPlayer player, AspectId aspect, int requested, AspectPoolFeedback feedback, VisAction action) {
        if (player == null || aspect == null || feedback == null || action == null || requested <= 0) {
            RuntimeWarnings.warnOnce("aspect-pool-add", "Ignoring invalid aspect pool addition request");
            return 0;
        }
        if (!player.server.isSameThread() || AspectApi.registry().get(aspect).isEmpty()) {
            return 0;
        }
        PlayerKnowledgeData current = TCObjectState.PLAYER_KNOWLEDGE.get(player);
        boolean newlyDiscovered = !current.knowsAspect(aspect);
        int accepted = acceptedPositiveAddition(current, aspect, requested);
        if (accepted <= 0 || action == VisAction.SIMULATE) {
            return accepted;
        }
        boolean discovered = feedback == AspectPoolFeedback.DISCOVER_IF_NEW && newlyDiscovered;
        PlayerKnowledgeData updated = current.addToAspectPool(aspect, accepted);
        if (updated.equals(current)) {
            return 0;
        }
        TCObjectState.PLAYER_KNOWLEDGE.set(player, updated);
        AspectGainPlatform.send(player, new AspectGainMessage(aspect, accepted, discovered));
        return accepted;
    }

    /**
     * Discovers an aspect and grants its configured one-time discovery reward.
     * The return value is whether the request would discover (or did discover)
     * a new aspect.
     */
    public static boolean discover(ServerPlayer player, AspectId aspect, VisAction action) {
        Objects.requireNonNull(player, "player");
        Objects.requireNonNull(aspect, "aspect");
        Objects.requireNonNull(action, "action");
        if (!player.server.isSameThread() || AspectApi.registry().get(aspect).isEmpty()) {
            return false;
        }
        PlayerKnowledgeData current = TCObjectState.PLAYER_KNOWLEDGE.get(player);
        if (current.knowsAspect(aspect)) {
            return false;
        }
        if (action == VisAction.EXECUTE) {
            TCObjectState.PLAYER_KNOWLEDGE.set(player, current.discoverAspect(aspect, firstDiscoveryBonus()));
            AspectGainPlatform.send(player, new AspectGainMessage(aspect, firstDiscoveryBonus(), true));
        }
        return true;
    }

    /**
     * Applies every discovery and positive pool addition as one attachment
     * replacement. Unknown identities and integer overflow reject the whole
     * request before any player state or feedback is changed.
     */
    public static AspectPoolImportResult importBatch(ServerPlayer player, AspectPoolImport request, VisAction action) {
        Objects.requireNonNull(player, "player");
        Objects.requireNonNull(request, "request");
        Objects.requireNonNull(action, "action");
        if (!player.server.isSameThread()) {
            return result(AspectPoolImportResult.Status.OFF_SERVER_THREAD, Set.of(), AspectAmounts.EMPTY);
        }
        LinkedHashSet<AspectId> affected = new LinkedHashSet<>(request.discoveries());
        affected.addAll(request.additions().amounts().keySet());
        for (AspectId aspect : affected) {
            if (AspectApi.registry().get(aspect).isEmpty()) {
                return result(AspectPoolImportResult.Status.UNKNOWN_ASPECT, Set.of(), AspectAmounts.EMPTY);
            }
        }
        PlayerKnowledgeData current = TCObjectState.PLAYER_KNOWLEDGE.get(player);
        LinkedHashSet<AspectId> discovered = new LinkedHashSet<>();
        for (AspectId aspect : affected) {
            if (!current.knowsAspect(aspect)) {
                discovered.add(aspect);
            }
        }
        LinkedHashMap<AspectId, Integer> creditedAmounts = new LinkedHashMap<>();
        for (AspectId aspect : affected) {
            long credited = request.additions().amount(aspect);
            if (discovered.contains(aspect)) {
                credited += firstDiscoveryBonus();
            }
            if (credited > 0L && (long) current.aspectPool(aspect) + credited > Integer.MAX_VALUE) {
                return result(AspectPoolImportResult.Status.OVERFLOW, Set.of(), AspectAmounts.EMPTY);
            }
            if (credited > 0L) {
                creditedAmounts.put(aspect, (int) credited);
            }
        }
        AspectAmounts credited = new AspectAmounts(creditedAmounts);
        if (credited.amounts().isEmpty() && discovered.isEmpty()) {
            return result(AspectPoolImportResult.Status.NO_CHANGE, Set.of(), AspectAmounts.EMPTY);
        }
        AspectPoolImportResult.Status status = action == VisAction.SIMULATE ? AspectPoolImportResult.Status.SIMULATED : AspectPoolImportResult.Status.EXECUTED;
        if (action == VisAction.SIMULATE) {
            return result(status, discovered, credited);
        }
        PlayerKnowledgeData updated = current;
        for (AspectId aspect : discovered) {
            updated = updated.discoverAspect(aspect, 0);
        }
        for (var entry : credited.amounts().entrySet()) {
            updated = updated.addToAspectPool(entry.getKey(), entry.getValue());
        }
        TCObjectState.PLAYER_KNOWLEDGE.set(player, updated);
        for (AspectId aspect : affected) {
            int added = credited.amount(aspect);
            boolean isDiscovery = discovered.contains(aspect);
            if (added > 0 || isDiscovery) {
                AspectGainPlatform.send(player, new AspectGainMessage(aspect, added, isDiscovery));
            }
        }
        return result(status, discovered, credited);
    }

    private static int acceptedPositiveAddition(PlayerKnowledgeData current, AspectId aspect, int requested) {
        long credited = requested;
        if (!current.knowsAspect(aspect)) {
            credited += firstDiscoveryBonus();
        }
        return (int) Math.min(credited, (long) Integer.MAX_VALUE - current.aspectPool(aspect));
    }

    private static AspectPoolImportResult result(AspectPoolImportResult.Status status, Set<AspectId> discovered, AspectAmounts additions) {
        return new AspectPoolImportResult(status, discovered, additions);
    }
}
