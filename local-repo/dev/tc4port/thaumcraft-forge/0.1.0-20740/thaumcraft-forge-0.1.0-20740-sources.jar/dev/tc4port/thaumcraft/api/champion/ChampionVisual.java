package dev.tc4port.thaumcraft.api.champion;

/**
 * Closed built-in particle presentation selectable by champion data.
 */
public enum ChampionVisual {

    BOLD,
    SPINE,
    ARMOR,
    MIGHTY,
    GRIM,
    WARDED,
    WARP,
    UNDYING,
    FIERY,
    SICKLY,
    VENOMOUS,
    VAMPIRIC,
    INFESTED
}
