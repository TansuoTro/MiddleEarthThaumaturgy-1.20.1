package dev.tc4port.thaumcraft.api.client;

import dev.tc4port.thaumcraft.api.Registration;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.function.Function;
import net.minecraft.client.gui.components.AbstractWidget;
import net.minecraft.resources.ResourceLocation;

/**
 * Client-only native widget extension point. Register from a client entrypoint.
 */
public final class ThaumonomiconApi {

    private static final Map<ResourceLocation, Function<ThaumonomiconAccess, AbstractWidget>> WIDGETS = new LinkedHashMap<>();

    private ThaumonomiconApi() {
    }

    /**
     * One widget instance per open book, retained on resize. Widgets receive native
     * rendering, pointer and character events. keyPressed is also offered before book
     * shortcuts, so a widget may implement a global focus shortcut. It must otherwise
     * return false when unfocused. Consumed keys focus that widget. Pointer hits suppress
     * the book's underlying tooltips. Registration changes apply to subsequently opened books.
     */
    public static synchronized Registration registerWidget(ResourceLocation id, Function<ThaumonomiconAccess, AbstractWidget> factory) {
        Objects.requireNonNull(id, "id");
        Objects.requireNonNull(factory, "factory");
        if (WIDGETS.putIfAbsent(id, factory) != null)
            throw new IllegalArgumentException("Duplicate book widget: " + id);
        return Registration.of(() -> {
            synchronized (ThaumonomiconApi.class) {
                WIDGETS.remove(id, factory);
            }
        });
    }

    /**
     * Core lifecycle entrypoint; factories must not retain a book beyond its screen lifetime.
     */
    public static List<AbstractWidget> createWidgets(ThaumonomiconAccess book) {
        List<Function<ThaumonomiconAccess, AbstractWidget>> factories;
        synchronized (ThaumonomiconApi.class) {
            factories = List.copyOf(WIDGETS.values());
        }
        return factories.stream().map(factory -> Objects.requireNonNull(factory.apply(book), "widget")).toList();
    }
}
