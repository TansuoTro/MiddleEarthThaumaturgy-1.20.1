package dev.tc4port.thaumcraft.api.wand;

import dev.tc4port.thaumcraft.api.research.ResearchRequirement;
import java.util.Objects;
import net.minecraft.resources.ResourceLocation;

/**
 * Programmatically installed, declarative wand-rod definition.
 * Capacity is whole Vis; craft cost is the legacy assembly coefficient.
 */
public record WandRodSpec(ResourceLocation itemId, WandMaterialId materialId, int capacity, int craftCost, WandRechargeSpec recharge, ResearchRequirement research, ResourceLocation texture, WandPartAssemblyMode assemblyMode, boolean staff, boolean glowing, boolean runes, int order) {

    public WandRodSpec {
        itemId = Objects.requireNonNull(itemId, "itemId");
        materialId = Objects.requireNonNull(materialId, "materialId");
        recharge = Objects.requireNonNull(recharge, "recharge");
        research = Objects.requireNonNull(research, "research");
        texture = Objects.requireNonNull(texture, "texture");
        assemblyMode = Objects.requireNonNull(assemblyMode, "assemblyMode");
        if (texture.toString().length() > 256) {
            throw new IllegalArgumentException("Wand rod texture ID must not exceed 256 characters");
        }
        if (capacity <= 0 || capacity > Integer.MAX_VALUE / 150 || craftCost < 0 || craftCost > WandPartApi.MAX_CRAFT_COST) {
            throw new IllegalArgumentException("Wand rods require positive capacity and craft cost " + "from 0 to " + WandPartApi.MAX_CRAFT_COST);
        }
    }

    /**
     * Compatibility constructor for ordinary, recipe-visible parts.
     */
    public WandRodSpec(ResourceLocation itemId, WandMaterialId materialId, int capacity, int craftCost, WandRechargeSpec recharge, ResearchRequirement research, ResourceLocation texture, boolean staff, boolean glowing, boolean runes, int order) {
        this(itemId, materialId, capacity, craftCost, recharge, research, texture, WandPartAssemblyMode.NORMAL, staff, glowing, runes, order);
    }
}
