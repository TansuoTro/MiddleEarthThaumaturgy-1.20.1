package dev.tc4port.thaumcraft.api.golem;

/**
 * Result of one server-authoritative golem state-write request.
 */
public enum GolemControlResult {

    UPDATED,
    UNCHANGED,
    NOT_A_GOLEM,
    WRONG_LEVEL,
    INVALID_TARGET,
    OFF_SERVER_THREAD
}
