package dev.tc4port.thaumcraft.api.aspect;

import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.Objects;
import java.util.Set;

/**
 * Exact result of an all-or-nothing aspect import. {@code additions} contains
 * the amounts actually credited, including first-discovery rewards.
 */
public record AspectPoolImportResult(Status status, Set<AspectId> newlyDiscovered, AspectAmounts additions) {

    public AspectPoolImportResult {
        status = Objects.requireNonNull(status, "status");
        Objects.requireNonNull(newlyDiscovered, "newlyDiscovered");
        newlyDiscovered = Collections.unmodifiableSet(new LinkedHashSet<>(newlyDiscovered));
        additions = Objects.requireNonNull(additions, "additions");
    }

    public enum Status {

        EXECUTED,
        SIMULATED,
        NO_CHANGE,
        UNKNOWN_ASPECT,
        OVERFLOW,
        OFF_SERVER_THREAD
    }
}
