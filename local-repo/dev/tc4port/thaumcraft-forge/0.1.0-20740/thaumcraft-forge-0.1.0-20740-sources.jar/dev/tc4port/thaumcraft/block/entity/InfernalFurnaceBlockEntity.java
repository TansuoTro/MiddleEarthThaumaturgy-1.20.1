package dev.tc4port.thaumcraft.block.entity;

import dev.tc4port.thaumcraft.registry.TCSounds;
import dev.tc4port.thaumcraft.api.aspect.VisChannel;
import dev.tc4port.thaumcraft.block.InfernalFurnaceBlock;
import dev.tc4port.thaumcraft.api.machine.ArcaneBellowsApi;
import dev.tc4port.thaumcraft.recipe.InfernalRecipes;
import dev.tc4port.thaumcraft.common.InfernalFurnaceSettings;
import dev.tc4port.thaumcraft.recipe.InfernalProcessing;
import dev.tc4port.thaumcraft.common.VisNetwork;
import dev.tc4port.thaumcraft.registry.TCBlockEntities;
import dev.tc4port.thaumcraft.registry.TCBlocks;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.HolderLookup;
import net.minecraft.core.NonNullList;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.ExperienceOrb;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.LevelEvent;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;
import java.lang.Math;
import dev.tc4port.thaumcraft.nativeimpl.state.ItemFields;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityType;

/**
 * TC4's central TileArcaneFurnace: a 32-stack, fuel-free smelting queue.
 */
public final class InfernalFurnaceBlockEntity extends net.minecraft.world.level.block.entity.BlockEntity implements ItemFields.Source {

    public static final int SLOT_COUNT = 32;

    private NonNullList<ItemStack> items = NonNullList.withSize(SLOT_COUNT, ItemStack.EMPTY);

    private int furnaceCookTime;

    private int furnaceMaxCookTime;

    private int speedyTime;

    private int activeSlot = -1;

    private InfernalRecipes.Resolved activeRecipe;

    private CompoundTag activeDefinition;

    private ItemStack activeInput = ItemStack.EMPTY;

    private VisChannel reserveAspect = VisChannel.IGNIS;

    public InfernalFurnaceBlockEntity(BlockPos pos, BlockState state) {
        super(TCBlockEntities.INFERNAL_FURNACE.get(), pos, state);
    }

    public static void serverTick(Level level, BlockPos pos, BlockState state, InfernalFurnaceBlockEntity furnace) {
        var machine = InfernalFurnaceSettings.get(level);
        // Missing machine configuration pauses the machine, rather than deleting its queued recipes.
        if (machine.isEmpty())
            return;
        Work work = furnace.findWork(true);
        InfernalProcessing settings = work != null ? work.recipe().processing() : machine.get().processingFor(InfernalProcessing.EMPTY);
        // Retain already saved CookTime when the save predates recipe validation metadata.
        if (work != null && furnace.furnaceCookTime > 0 && furnace.activeRecipe == null && furnace.activeDefinition == null) {
            furnace.activeRecipe = work.recipe();
            furnace.activeSlot = work.slot();
            furnace.activeInput = furnace.items.get(work.slot()).copyWithCount(1);
        }
        boolean invalidated = furnace.furnaceCookTime > 0 && !furnace.matchesActiveRecipe(work);
        if (invalidated || work == null) {
            furnace.furnaceCookTime = 0;
            furnace.clearActiveRecipe();
        }
        boolean wasCooking = furnace.furnaceCookTime > 0;
        if (wasCooking) {
            furnace.furnaceCookTime--;
            if (furnace.speedyTime > 0)
                furnace.speedyTime--;
        }
        if (furnace.reserveAspect != settings.aspect() && (work != null || furnace.speedyTime == 0)) {
            furnace.speedyTime = 0;
            furnace.reserveAspect = settings.aspect();
        }
        if (settings.boosted() && furnace.speedyTime <= 0 && settings.get("vis_per_request") > 0 && settings.get("vis_ticks_per_unit") > 0 && level instanceof ServerLevel server) {
            furnace.speedyTime = VisNetwork.drain(server, pos, settings.aspect(), settings.get("vis_per_request")) * settings.get("vis_ticks_per_unit");
        }
        if (furnace.furnaceMaxCookTime == 0 || invalidated) {
            furnace.furnaceMaxCookTime = settings.ticks(furnace.speedyTime > 0, furnace.machineBellows());
        }
        if (furnace.furnaceCookTime > furnace.furnaceMaxCookTime)
            furnace.furnaceCookTime = furnace.furnaceMaxCookTime;
        boolean changed = wasCooking || invalidated;
        if (work != null && furnace.furnaceCookTime == 0 && wasCooking) {
            changed |= furnace.smelt(work);
            furnace.clearActiveRecipe();
        } else if (work != null && furnace.furnaceCookTime == 0) {
            furnace.furnaceMaxCookTime = settings.ticks(furnace.speedyTime > 0, furnace.machineBellows());
            furnace.furnaceCookTime = furnace.furnaceMaxCookTime;
            changed = true;
        }
        if (work != null && furnace.furnaceCookTime > 0) {
            furnace.activeRecipe = work.recipe();
            furnace.activeSlot = work.slot();
            furnace.activeInput = furnace.items.get(work.slot()).copyWithCount(1);
            if (furnace.activeDefinition == null) {
                furnace.activeDefinition = work.recipe().progressDefinition(furnace.activeInput, level.registryAccess());
            }
        }
        if (changed)
            furnace.changedAndSync();
    }

    public boolean addDroppedStack(ItemStack offered) {
        if (offered.isEmpty() || this.level == null || InfernalFurnaceSettings.get(this.level).isEmpty()) {
            return false;
        }
        for (int slot = 0; slot < this.items.size(); slot++) {
            ItemStack present = this.items.get(slot);
            if (!present.isEmpty() && (!net.minecraft.world.item.ItemStack.isSameItemSameTags((net.minecraft.world.item.ItemStack) (present), (net.minecraft.world.item.ItemStack) (offered)) || present.getCount() + offered.getCount() > present.getMaxStackSize()))
                continue;
            // Check the new drop before merging: a disabled queued stack must wait for its own turn.
            if (this.level == null || InfernalRecipes.resolve(this.level, offered).isEmpty()) {
                this.playDestroyEffect();
                return true;
            }
            // Retain a partial ingredient stack until enough items arrive for its recipe.
            if (present.isEmpty())
                this.items.set(slot, offered.copy());
            else
                present.grow(offered.getCount());
            this.changedAndSync();
            return true;
        }
        return false;
    }

    private void destroySlot(int slot) {
        this.items.set(slot, ItemStack.EMPTY);
        this.playDestroyEffect();
    }

    private void playDestroyEffect() {
        if (this.level != null) {
            this.level.playSound(null, this.worldPosition, TCSounds.INFERNAL_FURNACE_DESTROY.get(), SoundSource.BLOCKS, 0.3F, 2.6F + (this.level.random.nextFloat() - this.level.random.nextFloat()) * 0.8F);
            if (this.level instanceof ServerLevel server) {
                server.sendParticles(net.minecraft.core.particles.ParticleTypes.LAVA, this.worldPosition.getX() + this.level.random.nextFloat(), this.worldPosition.getY() + 1.0, this.worldPosition.getZ() + this.level.random.nextFloat(), 1, 0.0, 0.0, 0.0, 0.0);
            }
        }
    }

    private boolean smelt(Work work) {
        if (!(this.level instanceof ServerLevel server))
            return false;
        ItemStack input = this.items.get(work.slot()).copy();
        if (!this.hasInputs(input, work.recipe().inputCount()))
            return false;
        int remaining = work.recipe().inputCount();
        for (ItemStack stack : this.items) {
            if (!net.minecraft.world.item.ItemStack.isSameItemSameTags((net.minecraft.world.item.ItemStack) (stack), (net.minecraft.world.item.ItemStack) (input)))
                continue;
            int consumed = Math.min(remaining, stack.getCount());
            stack.shrink(consumed);
            remaining -= consumed;
            if (remaining == 0)
                break;
        }
        this.eject(work.recipe());
        server.levelEvent(LevelEvent.LAVA_FIZZ, this.worldPosition, 0);
        return true;
    }

    private boolean matchesActiveRecipe(Work work) {
        if (work == null || work.slot() != this.activeSlot || !net.minecraft.world.item.ItemStack.isSameItemSameTags((net.minecraft.world.item.ItemStack) (this.activeInput), (net.minecraft.world.item.ItemStack) (this.items.get(work.slot()))))
            return false;
        if (work.recipe().sameDefinition(this.activeRecipe))
            return true;
        // A fresh recipe object after load/reload can still describe the same processing.
        return this.activeDefinition != null && this.activeDefinition.equals(work.recipe().progressDefinition(this.items.get(work.slot()), this.level.registryAccess()));
    }

    private void clearActiveRecipe() {
        this.activeRecipe = null;
        this.activeDefinition = null;
        this.activeInput = ItemStack.EMPTY;
        this.activeSlot = -1;
    }

    private Work findWork() {
        return this.findWork(false);
    }

    private Work findWork(boolean discardInvalid) {
        if (this.level == null)
            return null;
        if (this.activeSlot >= 0) {
            Work active = this.workAt(this.activeSlot, discardInvalid);
            if (active != null)
                return active;
        }
        for (int slot = 0; slot < this.items.size(); slot++) {
            Work work = this.workAt(slot, discardInvalid);
            if (work != null)
                return work;
        }
        return null;
    }

    private Work workAt(int slot, boolean discardInvalid) {
        ItemStack stack = this.items.get(slot);
        if (stack.isEmpty())
            return null;
        var found = InfernalRecipes.resolve(this.level, stack);
        if (found.isEmpty()) {
            // Only the processing tick discards a reached slot; Jade/nozzle queries are read-only.
            if (discardInvalid) {
                this.destroySlot(slot);
                this.changedAndSync();
            }
            return null;
        }
        return this.hasInputs(stack, found.get().inputCount()) ? new Work(slot, found.get()) : null;
    }

    private boolean hasInputs(ItemStack input, int required) {
        for (ItemStack stack : this.items) {
            if (net.minecraft.world.item.ItemStack.isSameItemSameTags((net.minecraft.world.item.ItemStack) (stack), (net.minecraft.world.item.ItemStack) (input)))
                required -= stack.getCount();
            if (required <= 0)
                return true;
        }
        return false;
    }

    @javax.annotation.Nullable
    public InfernalProcessing processing() {
        Work work = findWork();
        return work != null ? work.recipe().processing() : this.level == null ? null : InfernalFurnaceSettings.get(this.level).map(machine -> machine.processingFor(InfernalProcessing.EMPTY)).orElse(null);
    }

    private record Work(int slot, InfernalRecipes.Resolved recipe) {
    }

    public int bellows() {
        var settings = this.processing();
        return settings == null ? 0 : Math.min(settings.maxBellows(), this.machineBellows());
    }

    /**
     * Attached bellows accepted by the machine, before a recipe applies its own limit.
     */
    public int machineBellows() {
        if (this.level == null) {
            return 0;
        }
        int found = 0;
        for (Direction direction : Direction.values()) {
            if (direction == Direction.UP) {
                continue;
            }
            BlockPos check = this.worldPosition.relative(direction, 2);
            if (ArcaneBellowsApi.blowsToward(this.level, check, this.worldPosition.relative(direction))) {
                found++;
            }
        }
        return Math.min(found, InfernalFurnaceSettings.get(this.level).map(machine -> machine.maxBellows()).orElse(0));
    }

    private void eject(InfernalRecipes.Resolved recipe) {
        if (!(this.level instanceof ServerLevel server))
            return;
        Direction facing = this.outputFacing();
        double x = this.worldPosition.getX() + 0.5 + facing.getStepX() * 1.2;
        double z = this.worldPosition.getZ() + 0.5 + facing.getStepZ() * 1.2;
        double y = this.worldPosition.getY() + 0.4;
        int bellows = Math.min(recipe.processing().maxBellows(), machineBellows());
        for (var output : recipe.outputs()) {
            int count = output.roll(server.random, bellows);
            while (count > 0) {
                int size = Math.min(count, output.result().getMaxStackSize());
                this.spawnOutput(server, output.result().copyWithCount(size), x, y, z, facing, 0.13F);
                count -= size;
            }
        }
        float exactExperience = recipe.experience();
        int xp = Mth.floor(exactExperience);
        if (Mth.frac(exactExperience) != 0.0F && server.random.nextFloat() < Mth.frac(exactExperience)) {
            xp++;
        }
        if (xp > 0) {
            ExperienceOrb.award(server, new Vec3(x, y, z), xp);
        }
    }

    private void spawnOutput(ServerLevel server, ItemStack stack, double x, double y, double z, Direction facing, float forwardSpeed) {
        ItemEntity entity = new ItemEntity(server, x, y, z, stack);
        entity.setDeltaMovement(facing.getStepX() == 0 ? (server.random.nextFloat() - server.random.nextFloat()) * 0.03F : facing.getStepX() * forwardSpeed, 0.0, facing.getStepZ() == 0 ? (server.random.nextFloat() - server.random.nextFloat()) * 0.03F : facing.getStepZ() * forwardSpeed);
        server.addFreshEntity(entity);
    }

    public Direction outputFacing() {
        if (this.level != null) {
            for (Direction direction : Direction.Plane.HORIZONTAL) {
                BlockState neighbor = this.level.getBlockState(this.worldPosition.relative(direction));
                if (neighbor.is(TCBlocks.INFERNAL_FURNACE.get()) && neighbor.getValue(InfernalFurnaceBlock.PART) == InfernalFurnaceBlock.OUTLET_PART) {
                    return direction;
                }
            }
        }
        return Direction.SOUTH;
    }

    public int cookTime() {
        return this.furnaceCookTime;
    }

    public int maxCookTime() {
        return this.furnaceMaxCookTime;
    }

    public int speedyTime() {
        return this.speedyTime;
    }

    public VisChannel reserveAspect() {
        return this.reserveAspect;
    }

    @javax.annotation.Nullable
    public dev.tc4port.thaumcraft.api.aspect.AspectId essentiaSuctionType() {
        var settings = this.processing();
        return settings == null || !settings.boosted() ? null : settings.aspect().aspectId();
    }

    public int essentiaSuction() {
        var settings = this.processing();
        return settings != null && settings.boosted() && this.acceptsBoost(settings.aspect()) && settings.get("essentia_ticks_per_unit") > 0 && this.speedyTime < settings.get("essentia_suction_threshold") ? settings.get("essentia_suction") : 0;
    }

    public boolean acceptsBoost(VisChannel aspect) {
        return this.speedyTime == 0 || this.reserveAspect == aspect;
    }

    public void addSpeedyTime(int amount) {
        var settings = this.processing();
        if (settings == null || !this.acceptsBoost(settings.aspect()))
            return;
        this.reserveAspect = settings.aspect();
        this.speedyTime = (int) Math.max(0L, Math.min(Integer.MAX_VALUE, (long) this.speedyTime + amount));
        this.changedAndSync();
    }

    public ItemStack item(int slot) {
        return this.items.get(slot);
    }

    private void changedAndSync() {
        this.setChanged();
        BlockEntitySync.sendToClient(this);
    }

    @Override
    public void load(CompoundTag tag) {
        HolderLookup.Provider registries = persistenceRegistries();
        super.load(tag);
        this.items = NonNullList.withSize(SLOT_COUNT, ItemStack.EMPTY);
        {
            net.minecraft.nbt.CompoundTag native$operand$14363 = tag;
            net.minecraft.core.NonNullList<net.minecraft.world.item.ItemStack> native$operand$14364 = this.items;
            net.minecraft.core.HolderLookup.Provider native$operand$14365 = registries;
            net.minecraft.world.ContainerHelper.loadAllItems(native$operand$14363, native$operand$14364);
        }
        this.furnaceCookTime = Math.max(0, tag.getInt("CookTime"));
        this.furnaceMaxCookTime = Math.max(0, tag.getInt("MaxCookTime"));
        this.speedyTime = Math.max(0, tag.getInt("SpeedyTime"));
        this.reserveAspect = tag.contains("BoostAspect") ? VisChannel.fromIndex(tag.getInt("BoostAspect")).orElse(VisChannel.IGNIS) : VisChannel.IGNIS;
        this.activeSlot = tag.contains("ActiveSlot") ? tag.getInt("ActiveSlot") : -1;
        if (this.activeSlot < 0 || this.activeSlot >= SLOT_COUNT)
            this.activeSlot = -1;
        this.activeInput = this.activeSlot < 0 ? ItemStack.EMPTY : this.items.get(this.activeSlot).copyWithCount(1);
        this.activeDefinition = tag.contains("RecipeDefinition") ? tag.getCompound("RecipeDefinition").copy() : null;
        this.activeRecipe = null;
    }

    @Override
    protected void saveAdditional(CompoundTag tag) {
        HolderLookup.Provider registries = persistenceRegistries();
        super.saveAdditional(tag);
        {
            net.minecraft.nbt.CompoundTag native$operand$14366 = tag;
            net.minecraft.core.NonNullList<net.minecraft.world.item.ItemStack> native$operand$14367 = this.items;
            net.minecraft.core.HolderLookup.Provider native$operand$14368 = registries;
            net.minecraft.nbt.CompoundTag native$result$14369 = (net.minecraft.world.ContainerHelper.saveAllItems(native$operand$14366, native$operand$14367));
        }
        tag.putInt("CookTime", this.furnaceCookTime);
        tag.putInt("MaxCookTime", this.furnaceMaxCookTime);
        if (this.furnaceCookTime > 0 && this.activeDefinition != null) {
            tag.putInt("ActiveSlot", this.activeSlot);
            tag.put("RecipeDefinition", this.activeDefinition.copy());
        }
        tag.putInt("SpeedyTime", this.speedyTime);
        tag.putInt("BoostAspect", this.reserveAspect.index());
    }

    protected final HolderLookup.Provider persistenceRegistries() {
        if (level != null)
            return level.registryAccess();
        var server = net.minecraftforge.server.ServerLifecycleHooks.getCurrentServer();
        return server != null ? server.registryAccess() : net.minecraft.core.RegistryAccess.fromRegistryOfRegistries(net.minecraft.core.registries.BuiltInRegistries.REGISTRY);
    }

    protected static net.minecraft.network.chat.Component parseCustomNameSafe(String value, HolderLookup.Provider registries) {
        try {
            return net.minecraft.network.chat.Component.Serializer.fromJson(value);
        } catch (RuntimeException exception) {
            return null;
        }
    }

    protected void readItemFields(ItemFields.Input input) {
    }

    public void copyItemFields(ItemFields.Output output) {
    }

    public void applyComponentsFromItemStack(ItemStack stack) {
        readItemFields(ItemFields.from(stack));
    }

    public void removeComponentsFromTag(CompoundTag tag) {
    }

    @Override
    public void saveToItem(ItemStack stack) {
        CompoundTag tag = saveWithoutMetadata();
        {
            net.minecraft.nbt.CompoundTag native$bodyOperand$6164 = tag;
            native$bodyReturn$6166: {
                if (true) {
                }
            }
        }
        net.minecraft.world.item.BlockItem.setBlockEntityData(stack, getType(), tag);
        copyItemFields(ItemFields.to(stack));
    }

    @Override
    public net.minecraft.world.phys.AABB getRenderBoundingBox() {
        return InfernalFurnaceBlockEntity.native$ClientBlockEntityBounds$bounds(this);
    }

    @Override()
    public void onDataPacket(net.minecraft.network.Connection connection, net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket packet) {
        handleUpdateTag(packet.getTag());
    }

    @SuppressWarnings({ "rawtypes", "unchecked" })
    static private net.minecraft.world.phys.AABB native$ClientBlockEntityBounds$bounds(net.minecraft.world.level.block.entity.BlockEntity blockEntity) {
        var renderer = net.minecraft.client.Minecraft.getInstance().getBlockEntityRenderDispatcher().getRenderer(blockEntity);
        return renderer instanceof dev.tc4port.thaumcraft.nativeimpl.NativeBlockEntityRenderer shared ? shared.getRenderBoundingBox(blockEntity) : new net.minecraft.world.phys.AABB(blockEntity.getBlockPos());
    }
}
