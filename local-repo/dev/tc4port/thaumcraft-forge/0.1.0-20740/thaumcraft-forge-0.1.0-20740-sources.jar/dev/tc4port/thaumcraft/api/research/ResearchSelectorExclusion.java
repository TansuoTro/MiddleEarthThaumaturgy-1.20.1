package dev.tc4port.thaumcraft.api.research;

import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.Objects;
import java.util.Set;

/**
 * Bounded exclusion contribution shared by one or more prerequisite selectors.
 */
public record ResearchSelectorExclusion(Set<String> namespaces, Set<ResearchKeyPrefix> keyPrefixes, Set<ResearchKey> keys) {

    public static final int MAX_NAMESPACES = 64;

    public static final int MAX_KEY_PREFIXES = 128;

    public static final int MAX_KEYS = 256;

    public ResearchSelectorExclusion {
        namespaces = immutableCopy(namespaces, "namespaces");
        keyPrefixes = immutableCopy(keyPrefixes, "keyPrefixes");
        keys = immutableCopy(keys, "keys");
        if (namespaces.size() > MAX_NAMESPACES) {
            throw new IllegalArgumentException("A selector exclusion supports at most " + MAX_NAMESPACES + " namespaces");
        }
        if (keyPrefixes.size() > MAX_KEY_PREFIXES) {
            throw new IllegalArgumentException("A selector exclusion supports at most " + MAX_KEY_PREFIXES + " key prefixes");
        }
        if (keys.size() > MAX_KEYS) {
            throw new IllegalArgumentException("A selector exclusion supports at most " + MAX_KEYS + " exact keys");
        }
        namespaces.forEach(namespace -> ResearchKey.of(namespace, "selector_validation"));
    }

    public static ResearchSelectorExclusion empty() {
        return new ResearchSelectorExclusion(Set.of(), Set.of(), Set.of());
    }

    public boolean excludes(ResearchKey key) {
        Objects.requireNonNull(key, "key");
        return this.namespaces.contains(key.namespace()) || this.keys.contains(key) || this.keyPrefixes.stream().anyMatch(prefix -> prefix.matches(key));
    }

    public ResearchSelectorExclusion merge(ResearchSelectorExclusion other) {
        Objects.requireNonNull(other, "other");
        return new ResearchSelectorExclusion(union(this.namespaces, other.namespaces), union(this.keyPrefixes, other.keyPrefixes), union(this.keys, other.keys));
    }

    private static <T> Set<T> immutableCopy(Set<T> values, String field) {
        Objects.requireNonNull(values, field);
        LinkedHashSet<T> copy = new LinkedHashSet<>();
        values.forEach(value -> copy.add(Objects.requireNonNull(value, field)));
        return Collections.unmodifiableSet(copy);
    }

    private static <T> Set<T> union(Set<T> first, Set<T> second) {
        LinkedHashSet<T> result = new LinkedHashSet<>(first);
        result.addAll(second);
        return result;
    }
}
