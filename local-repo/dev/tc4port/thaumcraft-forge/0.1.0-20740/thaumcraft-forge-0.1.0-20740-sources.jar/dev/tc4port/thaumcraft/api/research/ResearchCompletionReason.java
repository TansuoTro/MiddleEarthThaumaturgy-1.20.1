package dev.tc4port.thaumcraft.api.research;

/**
 * Auditable policy category for a server-side research grant.
 */
public enum ResearchCompletionReason {

    GAMEPLAY_REWARD, SHARED_KNOWLEDGE, ADMIN_COMMAND
}
