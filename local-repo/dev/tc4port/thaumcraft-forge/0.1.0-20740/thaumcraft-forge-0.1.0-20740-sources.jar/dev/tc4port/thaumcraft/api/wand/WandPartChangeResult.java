package dev.tc4port.thaumcraft.api.wand;

/**
 * Exact outcome of one server-authoritative wand-part identity change.
 */
public enum WandPartChangeResult {

    CHANGED,
    WOULD_CHANGE,
    UNCHANGED,
    NOT_A_WAND,
    STALE_EXPECTED_ROD,
    UNKNOWN_REPLACEMENT_ROD,
    INCOMPATIBLE_CAPACITY,
    OFF_SERVER_THREAD
}
