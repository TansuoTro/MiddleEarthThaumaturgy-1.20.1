package dev.tc4port.thaumcraft.api.focus;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;

/**
 * Immutable, synchronized gameplay values. The first matching override for a key wins.
 */
public record FocusParameters(Map<String, Value> values, List<Override> overrides) {

    public static final int MAX_ENTRIES = 128;

    public static final double LIMIT = 1_000_000;

    public static final FocusParameters EMPTY = new FocusParameters(Map.of(), List.of());

    public FocusParameters {
        values = checkedValues(values);
        overrides = List.copyOf(overrides);
        if (overrides.size() > MAX_ENTRIES)
            throw new IllegalArgumentException("Too many parameter overrides");
        for (Override override : overrides) {
            if (!values.keySet().containsAll(override.values().keySet())) {
                throw new IllegalArgumentException("Parameter overrides must target declared parameters");
            }
        }
    }

    public double value(String key, Map<FocusUpgradeId, Integer> levels) {
        Value selected = values.get(key);
        if (selected == null)
            throw new IllegalArgumentException("Missing focus parameter: " + key);
        for (Override override : overrides) {
            if (override.values().containsKey(key) && override.matches(levels)) {
                selected = override.values().get(key);
                break;
            }
        }
        return selected.evaluate(levels);
    }

    public double minimum(String key) {
        return bounds(key, false);
    }

    public double maximum(String key) {
        return bounds(key, true);
    }

    private double bounds(String key, boolean upper) {
        Value value = values.get(key);
        if (value == null)
            throw new IllegalArgumentException("Missing focus parameter: " + key);
        double result = value.bound(upper);
        for (Override override : overrides) {
            value = override.values().get(key);
            if (value != null)
                result = upper ? Math.max(result, value.bound(true)) : Math.min(result, value.bound(false));
        }
        return result;
    }

    /**
     * Validates upgrade references after the complete catalog has loaded.
     */
    public void validate(Set<FocusUpgradeId> upgrades) {
        values.values().forEach(value -> value.validate(upgrades));
        for (Override override : overrides) {
            if (!upgrades.containsAll(override.requireAll()) || !upgrades.containsAll(override.rejectAny())) {
                throw new IllegalArgumentException("Unknown upgrade in focus parameter override");
            }
            override.values().values().forEach(value -> value.validate(upgrades));
        }
    }

    private static Map<String, Value> checkedValues(Map<String, Value> values) {
        if (values.size() > MAX_ENTRIES)
            throw new IllegalArgumentException("Too many focus parameters");
        LinkedHashMap<String, Value> result = new LinkedHashMap<>();
        values.forEach((key, value) -> {
            if (key == null || !key.matches("[a-z][a-z0-9_]{0,63}")) {
                throw new IllegalArgumentException("Invalid focus parameter name: " + key);
            }
            result.put(key, Objects.requireNonNull(value));
        });
        return Collections.unmodifiableMap(result);
    }

    /**
     * base + sum(perLevel * installedLevel), clamped to the declared inclusive bounds.
     */
    public record Value(double base, Map<FocusUpgradeId, Double> perLevel, double min, double max) {

        public Value {
            if (!finite(base) || !finite(min) || !finite(max) || min < 0 || max < min) {
                throw new IllegalArgumentException("Invalid focus parameter value or bounds");
            }
            perLevel = Collections.unmodifiableMap(new LinkedHashMap<>(perLevel));
            if (perLevel.size() > MAX_ENTRIES || perLevel.entrySet().stream().anyMatch(entry -> entry.getKey() == null || entry.getValue() == null || !finite(entry.getValue()))) {
                throw new IllegalArgumentException("Invalid focus parameter upgrade coefficients");
            }
        }

        private static boolean finite(double value) {
            return Double.isFinite(value) && Math.abs(value) <= LIMIT;
        }

        public double evaluate(Map<FocusUpgradeId, Integer> levels) {
            double result = base;
            for (var entry : perLevel.entrySet()) {
                result += entry.getValue() * levels.getOrDefault(entry.getKey(), 0);
            }
            return Math.max(min, Math.min(max, result));
        }

        private double bound(boolean upper) {
            double value = base;
            for (double coefficient : perLevel.values()) {
                value += (upper ? Math.max(0, coefficient) : Math.min(0, coefficient)) * 6;
            }
            return Math.max(min, Math.min(max, value));
        }

        private void validate(Set<FocusUpgradeId> upgrades) {
            if (!upgrades.containsAll(perLevel.keySet()))
                throw new IllegalArgumentException("Unknown upgrade in focus parameter");
        }
    }

    public record Override(Set<FocusUpgradeId> requireAll, Set<FocusUpgradeId> rejectAny, Map<String, Value> values) {

        public Override {
            requireAll = Set.copyOf(requireAll);
            rejectAny = Set.copyOf(rejectAny);
            values = checkedValues(values);
            if (requireAll.size() > MAX_ENTRIES || rejectAny.size() > MAX_ENTRIES)
                throw new IllegalArgumentException("Too many focus parameter conditions");
            if (requireAll.isEmpty() && rejectAny.isEmpty())
                throw new IllegalArgumentException("Unconditional parameter override");
        }

        public boolean matches(Map<FocusUpgradeId, Integer> levels) {
            return requireAll.stream().allMatch(id -> levels.getOrDefault(id, 0) > 0) && rejectAny.stream().noneMatch(id -> levels.getOrDefault(id, 0) > 0);
        }
    }
}
