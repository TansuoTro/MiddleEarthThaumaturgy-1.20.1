package dev.tc4port.thaumcraft.api.presentation;

import dev.tc4port.thaumcraft.common.ActionPresentationService;
import java.util.Objects;
import javax.annotation.Nullable;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;

/**
 * Side-aware presentation for an interaction that runs on both logical sides.
 *
 * <p>Call {@link #present} once from the shared interaction path after all
 * locally knowable preconditions have passed. On the casting client the
 * registered presentation runs immediately. On the logical server the same
 * call sends it only to nearby observers, excluding the casting player. The
 * event is visual/audio feedback only and never authorizes gameplay.</p>
 */
public final class ActionPresentationApi {

    private ActionPresentationApi() {
    }

    public static void present(Player source, InteractionHand hand, ResourceLocation presentationId, Vec3 origin) {
        present(source, hand, presentationId, origin, origin, null, 0.0D, 0, ActionPresentationAudience.PREDICTED);
    }

    /**
     * Presents one bounded event. {@code targetEntity} is optional and is
     * resolved independently on each observing client.
     */
    public static void present(Player source, InteractionHand hand, ResourceLocation presentationId, Vec3 origin, Vec3 target, @Nullable Entity targetEntity, double detail, int value) {
        present(source, hand, presentationId, origin, target, targetEntity, detail, value, ActionPresentationAudience.PREDICTED);
    }

    /**
     * Presents one bounded actor-owned event with an explicit prediction or
     * confirmation audience.
     */
    public static void present(Player source, InteractionHand hand, ResourceLocation presentationId, Vec3 origin, Vec3 target, @Nullable Entity targetEntity, double detail, int value, ActionPresentationAudience audience) {
        Objects.requireNonNull(source, "source");
        ActionPresentationService.present(source, Objects.requireNonNull(hand, "hand"), Objects.requireNonNull(presentationId, "presentationId"), Objects.requireNonNull(origin, "origin"), Objects.requireNonNull(target, "target"), targetEntity, detail, value, false, Objects.requireNonNull(audience, "audience"));
    }

    /**
     * Sends one server-confirmed source-less block or world presentation to
     * all players within Thaumcraft's standard 64-block observer radius.
     */
    public static void presentAt(ServerLevel level, ResourceLocation presentationId, Vec3 origin, Vec3 target, @Nullable Entity targetEntity, double detail, int value) {
        ActionPresentationService.presentAt(Objects.requireNonNull(level, "level"), Objects.requireNonNull(presentationId, "presentationId"), Objects.requireNonNull(origin, "origin"), Objects.requireNonNull(target, "target"), targetEntity, detail, value);
    }
}
