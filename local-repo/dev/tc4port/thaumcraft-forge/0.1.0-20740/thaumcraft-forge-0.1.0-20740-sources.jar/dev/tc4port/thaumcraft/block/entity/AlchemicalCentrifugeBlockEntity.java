package dev.tc4port.thaumcraft.block.entity;

import dev.tc4port.thaumcraft.registry.TCSounds;
import dev.tc4port.thaumcraft.common.TCGameplayParameters;
import dev.tc4port.thaumcraft.api.ThaumcraftApiHelper;
import dev.tc4port.thaumcraft.api.aspect.AspectDefinition;
import dev.tc4port.thaumcraft.aspect.AspectCatalog;
import dev.tc4port.thaumcraft.api.aspect.AspectId;
import dev.tc4port.thaumcraft.api.aspect.AspectAmounts;
import dev.tc4port.thaumcraft.api.aspect.AspectContainerView;
import dev.tc4port.thaumcraft.api.essentia.EssentiaApi;
import dev.tc4port.thaumcraft.api.essentia.EssentiaTransferMode;
import dev.tc4port.thaumcraft.api.essentia.EssentiaTransport;
import dev.tc4port.thaumcraft.registry.TCBlockEntities;
import javax.annotation.Nullable;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import java.lang.Math;
import dev.tc4port.thaumcraft.nativeimpl.state.ItemFields;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityType;

/**
 * Exact one-unit compound splitter from TileCentrifuge.
 */
public final class AlchemicalCentrifugeBlockEntity extends net.minecraft.world.level.block.entity.BlockEntity implements EssentiaTransport, AspectContainerView, ItemFields.Source {

    private AspectId aspectIn;

    private AspectId aspectOut;

    private int count;

    private int process;

    private float rotationSpeed;

    private float rotation;

    public AlchemicalCentrifugeBlockEntity(BlockPos pos, BlockState state) {
        super(TCBlockEntities.ALCHEMICAL_CENTRIFUGE.get(), pos, state);
    }

    public static void serverTick(Level level, BlockPos pos, BlockState state, AlchemicalCentrifugeBlockEntity centrifuge) {
        if (!level.hasChunksAt(pos.offset(-2, 0, -2), pos.offset(2, 0, 2)) || level.hasNeighborSignal(pos)) {
            return;
        }
        if (centrifuge.aspectOut == null && centrifuge.aspectIn == null && ++centrifuge.count % TCGameplayParameters.ALCHEMY_ALCHEMICAL_CENTRIFUGE_INTAKE_INTERVAL.intValue() == 0) {
            centrifuge.drawEssentia();
        }
        if (centrifuge.process > 0) {
            centrifuge.process--;
        }
        if (centrifuge.aspectOut == null && centrifuge.aspectIn != null && centrifuge.process == 0) {
            centrifuge.processEssentia();
        }
    }

    public static void clientTick(Level level, BlockPos pos, BlockState state, AlchemicalCentrifugeBlockEntity centrifuge) {
        boolean powered = level.hasNeighborSignal(pos);
        if (centrifuge.aspectIn != null && !powered && centrifuge.rotationSpeed < 20.0F) {
            centrifuge.rotationSpeed += 2.0F;
        }
        if ((centrifuge.aspectIn == null || powered) && centrifuge.rotationSpeed > 0.0F) {
            centrifuge.rotationSpeed = Math.max(0.0F, centrifuge.rotationSpeed - 0.5F);
        }
        int previous = (int) centrifuge.rotation;
        centrifuge.rotation += centrifuge.rotationSpeed;
        if (centrifuge.rotation % 180.0F <= 20.0F && previous % 180 >= 160 && centrifuge.rotationSpeed > 0.0F) {
            level.playLocalSound(pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5, dev.tc4port.thaumcraft.registry.TCSounds.CENTRIFUGE_WORK.get(), SoundSource.BLOCKS, 1.0F, 1.0F, false);
        }
    }

    @Nullable
    public AspectId inputAspect() {
        return this.aspectIn;
    }

    @Nullable
    public AspectId outputAspect() {
        return this.aspectOut;
    }

    @Override
    public AspectAmounts visibleAspects() {
        return this.aspectOut == null ? AspectAmounts.EMPTY : AspectAmounts.of(this.aspectOut, 1);
    }

    public int process() {
        return this.process;
    }

    public float rotation() {
        /*
         * TileCentrifugeRenderer sampled the completed client-tick field
         * directly.  Do not add a second partial-tick step here: it advances
         * the pump ahead of its source animation and changes the crossing
         * moment relative to the pump sound.
         */
        return this.rotation;
    }

    private void drawEssentia() {
        EssentiaTransport below = this.transportAt(Direction.DOWN);
        if (below == null || !below.canOutputTo(Direction.UP)) {
            return;
        }
        AspectId candidate = null;
        if (below.essentiaAmount(Direction.UP) > 0 && below.suctionAmount(Direction.UP) < this.suctionAmount(Direction.DOWN) && this.suctionAmount(Direction.DOWN) >= below.minimumSuction()) {
            candidate = below.essentiaType(Direction.UP);
        }
        AspectDefinition definition = candidate == null ? null : AspectCatalog.get(candidate);
        if (definition != null && !definition.primal() && below.suctionAmount(Direction.UP) < this.suctionAmount(Direction.DOWN) && EssentiaApi.take(this.level, below, candidate, 1, Direction.UP, EssentiaTransferMode.EXECUTE) == 1) {
            this.aspectIn = candidate;
            this.process = TCGameplayParameters.ALCHEMY_ALCHEMICAL_CENTRIFUGE_PROCESS_COUNTDOWN.intValue();
            this.changedAndSync();
        }
    }

    private void processEssentia() {
        AspectDefinition definition = AspectCatalog.get(this.aspectIn);
        if (definition == null) {
            // Preserve essentia owned by a temporarily missing data pack.
            return;
        }
        if (definition.primal()) {
            this.aspectIn = null;
            this.changedAndSync();
            return;
        }
        this.aspectOut = AspectCatalog.componentIds(definition).get(this.level.random.nextInt(2));
        this.aspectIn = null;
        this.changedAndSync();
    }

    @Nullable
    private EssentiaTransport transportAt(Direction direction) {
        if (this.level == null) {
            return null;
        }
        return ThaumcraftApiHelper.getConnectableTransport(this.level, this.worldPosition, direction);
    }

    @Override
    public boolean isConnectable(Direction face) {
        return face == Direction.UP || face == Direction.DOWN;
    }

    @Override
    public boolean canInputFrom(Direction face) {
        return face == Direction.DOWN;
    }

    @Override
    public boolean canOutputTo(Direction face) {
        return face == Direction.UP;
    }

    @Nullable
    @Override
    public AspectId suctionType(Direction face) {
        return null;
    }

    @Override
    public int suctionAmount(Direction face) {
        if (this.level != null && (!this.level.hasChunksAt(this.worldPosition.offset(-2, 0, -2), this.worldPosition.offset(2, 0, 2)) || this.level.hasNeighborSignal(this.worldPosition))) {
            return 0;
        }
        return face == Direction.DOWN ? this.aspectIn == null ? 128 : 64 : 0;
    }

    @Override
    public int takeEssentia(AspectId aspect, int amount, Direction face, EssentiaTransferMode mode) {
        if (!this.canOutputTo(face) || this.aspectOut == null || !AspectCatalog.contains(this.aspectOut) || amount <= 0 || !this.aspectOut.equals(aspect)) {
            return 0;
        }
        if (!mode.executes()) {
            return 1;
        }
        this.aspectOut = null;
        this.changedAndSync();
        return 1;
    }

    @Override
    public int addEssentia(AspectId aspect, int amount, Direction face, EssentiaTransferMode mode) {
        AspectDefinition definition = AspectCatalog.get(aspect);
        if (amount <= 0 || this.aspectIn != null || definition == null || definition.primal()) {
            return 0;
        }
        if (!mode.executes()) {
            return 1;
        }
        this.aspectIn = aspect;
        this.process = TCGameplayParameters.ALCHEMY_ALCHEMICAL_CENTRIFUGE_PROCESS_COUNTDOWN.intValue();
        this.changedAndSync();
        return 1;
    }

    @Nullable
    @Override
    public AspectId essentiaType(Direction face) {
        return AspectCatalog.contains(this.aspectOut) ? this.aspectOut : null;
    }

    @Override
    public int essentiaAmount(Direction face) {
        return AspectCatalog.contains(this.aspectOut) ? 1 : 0;
    }

    @Override
    public int minimumSuction() {
        return 0;
    }

    @Override
    public boolean renderExtendedTube() {
        return false;
    }

    private void changedAndSync() {
        this.setChanged();
        BlockEntitySync.sendToClient(this);
    }

    @Override
    public void load(CompoundTag tag) {
        super.load(tag);
        this.aspectIn = tag.contains("aspectIn") ? stored(tag.getString("aspectIn")) : null;
        this.aspectOut = tag.contains("aspectOut") ? stored(tag.getString("aspectOut")) : null;
        // TC4 did not persist process/count; a loaded input immediately
        // resolves on its next active tick.
        this.process = 0;
    }

    @Override
    protected void saveAdditional(CompoundTag tag) {
        super.saveAdditional(tag);
        if (this.aspectIn != null) {
            tag.putString("aspectIn", this.aspectIn.serialized());
        }
        if (this.aspectOut != null) {
            tag.putString("aspectOut", this.aspectOut.serialized());
        }
    }

    @Override
    public CompoundTag getUpdateTag() {
        return this.saveWithoutMetadata();
    }

    @Override
    public Packet<ClientGamePacketListener> getUpdatePacket() {
        return ClientboundBlockEntityDataPacket.create(this);
    }

    private static AspectId stored(String value) {
        try {
            return AspectId.parse(value);
        } catch (IllegalArgumentException ignored) {
            return null;
        }
    }

    protected final HolderLookup.Provider persistenceRegistries() {
        if (level != null)
            return level.registryAccess();
        var server = net.minecraftforge.server.ServerLifecycleHooks.getCurrentServer();
        return server != null ? server.registryAccess() : net.minecraft.core.RegistryAccess.fromRegistryOfRegistries(net.minecraft.core.registries.BuiltInRegistries.REGISTRY);
    }

    protected static net.minecraft.network.chat.Component parseCustomNameSafe(String value, HolderLookup.Provider registries) {
        try {
            return net.minecraft.network.chat.Component.Serializer.fromJson(value);
        } catch (RuntimeException exception) {
            return null;
        }
    }

    protected void readItemFields(ItemFields.Input input) {
    }

    public void copyItemFields(ItemFields.Output output) {
    }

    public void applyComponentsFromItemStack(ItemStack stack) {
        readItemFields(ItemFields.from(stack));
    }

    public void removeComponentsFromTag(CompoundTag tag) {
    }

    @Override
    public void saveToItem(ItemStack stack) {
        CompoundTag tag = saveWithoutMetadata();
        {
            net.minecraft.nbt.CompoundTag native$bodyOperand$6087 = tag;
            native$bodyReturn$6089: {
                if (true) {
                }
            }
        }
        net.minecraft.world.item.BlockItem.setBlockEntityData(stack, getType(), tag);
        copyItemFields(ItemFields.to(stack));
    }

    @Override
    public net.minecraft.world.phys.AABB getRenderBoundingBox() {
        return AlchemicalCentrifugeBlockEntity.native$ClientBlockEntityBounds$bounds(this);
    }

    @Override()
    public void onDataPacket(net.minecraft.network.Connection connection, net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket packet) {
        handleUpdateTag(packet.getTag());
    }

    @SuppressWarnings({ "rawtypes", "unchecked" })
    static private net.minecraft.world.phys.AABB native$ClientBlockEntityBounds$bounds(net.minecraft.world.level.block.entity.BlockEntity blockEntity) {
        var renderer = net.minecraft.client.Minecraft.getInstance().getBlockEntityRenderDispatcher().getRenderer(blockEntity);
        return renderer instanceof dev.tc4port.thaumcraft.nativeimpl.NativeBlockEntityRenderer shared ? shared.getRenderBoundingBox(blockEntity) : new net.minecraft.world.phys.AABB(blockEntity.getBlockPos());
    }

    private boolean native$capabilitiesInvalid$16869;

    public boolean native$capabilityActive$16765;

    public net.minecraftforge.common.capabilities.Capability<dev.tc4port.thaumcraft.api.essentia.EssentiaTransport> native$capabilityCapture$16764;

    private net.minecraftforge.common.util.LazyOptional<dev.tc4port.thaumcraft.api.essentia.EssentiaTransport> native$capabilityHandle$16766;

    @Override
    public <native$capabilityResultType$16870> net.minecraftforge.common.util.LazyOptional<native$capabilityResultType$16870> getCapability(net.minecraftforge.common.capabilities.Capability<native$capabilityResultType$16870> native$requestedCapability$16871, net.minecraft.core.Direction native$requestedFace$16872) {
        getCapabilities();
        synchronized (this) {
            if (native$capabilitiesInvalid$16869)
                return net.minecraftforge.common.util.LazyOptional.empty();
            if (native$capabilityActive$16765 && native$requestedCapability$16871 == (this.native$capabilityCapture$16764)) {
                if (native$capabilityHandle$16766 == null)
                    native$capabilityHandle$16766 = net.minecraftforge.common.util.LazyOptional.of(() -> this);
                return native$capabilityHandle$16766.cast();
            }
        }
        return super.getCapability(native$requestedCapability$16871, native$requestedFace$16872);
    }

    @Override
    public void invalidateCaps() {
        java.util.List<net.minecraftforge.common.util.LazyOptional<?>> native$expiredCapabilities$16873 = new java.util.ArrayList<>();
        synchronized (this) {
            native$capabilitiesInvalid$16869 = true;
            if (native$capabilityHandle$16766 != null) {
                native$expiredCapabilities$16873.add(native$capabilityHandle$16766);
                native$capabilityHandle$16766 = null;
            }
        }
        try {
            super.invalidateCaps();
        } finally {
            native$expiredCapabilities$16873.forEach(net.minecraftforge.common.util.LazyOptional::invalidate);
        }
    }

    @Override
    public void reviveCaps() {
        super.reviveCaps();
        synchronized (this) {
            native$capabilitiesInvalid$16869 = false;
        }
    }
}
