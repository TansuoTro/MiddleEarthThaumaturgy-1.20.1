package dev.tc4port.thaumcraft.api.client;

import dev.tc4port.thaumcraft.api.Registration;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Objects;
import java.util.function.BiConsumer;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.crafting.Recipe;

/**
 * Client-only custom rendering of supported PROCESS_CRAFTING pages.
 */
public final class ResearchRecipeRendererApi {

    private static final Map<ResourceLocation, Renderer<?>> RENDERERS = new LinkedHashMap<>();

    private ResearchRecipeRendererApi() {
    }

    /**
     * Register during client setup, behind the optional mod's presence check.
     * Retain and close the returned handle when replacing the registration.
     * The first matching recipe class wins. Rendering never grants page support:
     * the common ResearchRecipeDisplayApi provider still owns that decision.
     */
    public static synchronized <R extends Recipe<?>> Registration register(ResourceLocation id, Class<R> recipeClass, BiConsumer<R, ResearchRecipeRenderContext> draw) {
        Objects.requireNonNull(id, "id");
        Renderer<R> renderer = new Renderer<>(Objects.requireNonNull(recipeClass, "recipeClass"), Objects.requireNonNull(draw, "draw"));
        if (RENDERERS.putIfAbsent(id, renderer) != null) {
            throw new IllegalArgumentException("Duplicate recipe renderer: " + id);
        }
        return Registration.of(() -> {
            synchronized (ResearchRecipeRendererApi.class) {
                RENDERERS.remove(id, renderer);
            }
        });
    }

    /**
     * Draw a live recipe, returning false when it has no custom renderer.
     */
    public static boolean render(Recipe<?> recipe, ResearchRecipeRenderContext context) {
        Renderer<?> renderer;
        synchronized (ResearchRecipeRendererApi.class) {
            renderer = RENDERERS.values().stream().filter(candidate -> candidate.recipeClass().isInstance(recipe)).findFirst().orElse(null);
        }
        if (renderer == null) {
            return false;
        }
        renderer.render(recipe, context);
        return true;
    }

    private record Renderer<R extends Recipe<?>>(Class<R> recipeClass, BiConsumer<R, ResearchRecipeRenderContext> draw) {

        private void render(Recipe<?> recipe, ResearchRecipeRenderContext context) {
            draw.accept(recipeClass.cast(recipe), context);
        }
    }
}
