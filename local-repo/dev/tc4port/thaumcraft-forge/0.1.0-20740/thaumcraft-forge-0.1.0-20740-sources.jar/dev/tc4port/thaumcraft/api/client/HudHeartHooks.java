package dev.tc4port.thaumcraft.api.client;

import dev.tc4port.thaumcraft.api.client.HudHeartPass;
import java.util.*;
import java.util.function.Supplier;
import net.minecraft.client.gui.GuiGraphics;

public final class HudHeartHooks {

    private static final List<Supplier<? extends HudHeartPass>> FACTORIES = new ArrayList<>();

    private HudHeartHooks() {
    }

    public static void register(Supplier<? extends HudHeartPass> factory) {
        FACTORIES.add(factory);
    }

    public static final class Passes implements HudHeartPass {

        private List<HudHeartPass> passes;

        public void begin(float maximum, int absorption) {
            if (passes == null) {
                passes = new ArrayList<>();
                FACTORIES.forEach(factory -> passes.add(factory.get()));
            }
            passes.forEach(pass -> pass.begin(maximum, absorption));
        }

        public void beforeHeart(GuiGraphics graphics, int x, int y) {
            passes.forEach(pass -> pass.beforeHeart(graphics, x, y));
        }

        public void finish(GuiGraphics graphics) {
            passes.forEach(pass -> pass.finish(graphics));
        }
    }
}
