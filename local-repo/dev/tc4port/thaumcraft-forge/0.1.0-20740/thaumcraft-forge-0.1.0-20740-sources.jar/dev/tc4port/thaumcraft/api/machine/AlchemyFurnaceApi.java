package dev.tc4port.thaumcraft.api.machine;

import dev.tc4port.thaumcraft.api.aspect.AspectApi;
import dev.tc4port.thaumcraft.api.aspect.AspectId;
import dev.tc4port.thaumcraft.block.entity.AlchemyFurnaceBlockEntity;
import dev.tc4port.thaumcraft.util.RuntimeWarnings;
import java.util.Objects;
import javax.annotation.Nullable;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.Level;

/**
 * Loaded-only access to single steps of TC's own alchemical furnace.
 *
 * <p>Steps keep their original values and do not run the checks of the
 * furnace tick that normally precedes them. Calls run only on the owning
 * server thread and return {@code false} for an unloaded or non-furnace
 * target.
 */
public final class AlchemyFurnaceApi {

    private AlchemyFurnaceApi() {
    }

    /**
     * Runs one core distribution round into the alembic column above the
     * furnace (at most five high, one essentia per alembic). Alembics
     * synchronize themselves; call {@link #changedAndSync} for the furnace.
     *
     * @return whether any essentia moved
     */
    public static boolean transferToAlembics(Level level, BlockPos pos) {
        AlchemyFurnaceBlockEntity furnace = serverFurnace(level, pos);
        return furnace != null && !furnace.aspects().isEmpty() && furnace.transferToAlembics((ServerLevel) level);
    }

    /**
     * Takes exactly {@code amount} of one stored aspect, or nothing when less
     * is stored. Does not save or synchronize.
     */
    public static boolean take(Level level, BlockPos pos, AspectId aspect, int amount) {
        if (aspect == null || amount <= 0 || AspectApi.registry().get(aspect).isEmpty()) {
            RuntimeWarnings.warnOnce("alchemy-furnace-take", "Ignoring invalid alchemical furnace take request");
            return false;
        }
        AlchemyFurnaceBlockEntity furnace = serverFurnace(level, pos);
        return furnace != null && furnace.take(aspect, amount);
    }

    /**
     * Saves the furnace and updates its lit/filled appearance and clients.
     */
    public static boolean changedAndSync(Level level, BlockPos pos) {
        AlchemyFurnaceBlockEntity furnace = serverFurnace(level, pos);
        if (furnace == null) {
            return false;
        }
        furnace.changedAndSync();
        return true;
    }

    @Nullable
    private static AlchemyFurnaceBlockEntity serverFurnace(Level level, BlockPos pos) {
        Objects.requireNonNull(level, "level");
        Objects.requireNonNull(pos, "pos");
        if (!(level instanceof ServerLevel serverLevel) || !serverLevel.getServer().isSameThread() || !level.hasChunkAt(pos) || !(level.getBlockEntity(pos) instanceof AlchemyFurnaceBlockEntity furnace)) {
            return null;
        }
        return furnace;
    }
}
