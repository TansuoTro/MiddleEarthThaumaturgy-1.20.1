package dev.tc4port.thaumcraft.api.client;

import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import dev.tc4port.thaumcraft.api.aspect.AspectDefinition;
import dev.tc4port.thaumcraft.api.aspect.AspectId;
import dev.tc4port.thaumcraft.api.research.ResearchTableNote;
import dev.tc4port.thaumcraft.aspect.AspectCatalog;
import dev.tc4port.thaumcraft.client.AspectGuiRender;
import dev.tc4port.thaumcraft.client.GuiAlphaCutoffBlitter;
import dev.tc4port.thaumcraft.client.TCClientRenderTypes;
import dev.tc4port.thaumcraft.common.TCClientConfig;
import dev.tc4port.thaumcraft.research.HexCoordinate;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;

/**
 * The built-in research page renderer, shared by replacement screens.
 * Own one instance per screen for rune animation state. All coordinates use the
 * caller's current GUI pose: the paper is 150 square, centered on the anchor,
 * the hex radius is 9 and aspect sprites are 16 square. Rendering never edits a
 * note or submits research actions. Call on the render thread only.
 */
public final class ResearchTableRendering {

    private static final ResourceLocation PARCHMENT = texture("textures/misc/parchment3.png");

    private static final ResourceLocation HEX = texture("textures/gui/hex1.png");

    private static final ResourceLocation HEX_HIGHLIGHT = texture("textures/gui/hex2.png");

    private static final ResourceLocation UNKNOWN = texture("textures/aspects/_unknown.png");

    private static final ResourceLocation SCRIPT = texture("textures/misc/script.png");

    private static final int HEX_SIZE = 9;

    private final Map<String, Rune> runes = new HashMap<>();

    private long nextRune;

    public ResearchTableRendering() {
    }

    /**
     * Draws the complete built-in paper and effects. Empty notes clear this screen's rune state.
     */
    public void renderNote(GuiGraphics graphics, ResearchTableNote note, Set<AspectId> discovered, int anchorX, int anchorY, int mouseX, int mouseY) {
        if (note.research().isEmpty()) {
            this.runes.clear();
            return;
        }
        graphics.flush();
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        graphics.setColor(1.0F, 1.0F, 1.0F, 1.0F);
        GuiAlphaCutoffBlitter.blit(graphics, PARCHMENT, anchorX - 75, anchorY - 75, 0, 0, 150, 150, 256, 256);
        graphics.flush();
        RenderSystem.disableBlend();
        drawRunes(graphics, note, anchorX, anchorY);
        ConnectionView connections = connections(note, discovered);
        for (HexConnection connection : connections.lines()) {
            drawConnection(graphics, connection.first(), connection.second(), anchorX, anchorY);
        }
        HexCoordinate hovered = HexCoordinate.fromPixel(mouseX - anchorX, mouseY - anchorY, HEX_SIZE);
        for (ResearchTableNote.Cell entry : note.cells()) {
            HexCoordinate coordinate = new HexCoordinate(entry.q(), entry.r());
            int centerX = anchorX + (int) Math.round(coordinate.pixelX(HEX_SIZE));
            int centerY = anchorY + (int) Math.round(coordinate.pixelY(HEX_SIZE));
            if (!note.complete() && entry.kind() != ResearchTableNote.Kind.FIXED) {
                if (hovered.equals(coordinate)) {
                    blitWithBlend(graphics, HEX_HIGHLIGHT, centerX - 8, centerY - 8, 1.0F, 1.0F, 1.0F, 1.0F, true);
                }
                /*
                 * GuiResearchTable submitted the additive hover sprite
                 * first, then the quarter-alpha ordinary hex over it.
                 * Reversing these passes makes the border too bright and
                 * gives it a visibly different silhouette.
                 */
                blitWithBlend(graphics, HEX, centerX - 8, centerY - 8, 1.0F, 1.0F, 1.0F, 0.25F, false);
            } else if (!note.complete() && entry.kind() == ResearchTableNote.Kind.FIXED) {
                drawPulsingOrb(graphics, centerX - 8, centerY - 8, pulsingOrbColor(centerX - 8, centerY - 8));
            }
            if (entry.aspect().isEmpty()) {
                continue;
            }
            if (!discovered.contains(entry.aspect().orElseThrow())) {
                blitWithBlend(graphics, UNKNOWN, centerX - 8, centerY - 8, 0.0F, 0.0F, 0.0F, 0.5F, false);
            } else {
                boolean highlighted = entry.kind() == ResearchTableNote.Kind.FIXED || connections.highlighted().contains(key(entry));
                drawAspect(graphics, entry.aspect().orElseThrow(), centerX - 8, centerY - 8, highlighted ? 1.0F : 0.66F, 0, 0, !highlighted && entry.kind() == ResearchTableNote.Kind.PLACED);
            }
        }
    }

    private static void drawConnection(GuiGraphics graphics, HexCoordinate first, HexCoordinate second, int anchorX, int anchorY) {
        float x1 = anchorX + (float) first.pixelX(HEX_SIZE);
        float y1 = anchorY + (float) first.pixelY(HEX_SIZE);
        float x2 = anchorX + (float) second.pixelX(HEX_SIZE);
        float y2 = anchorY + (float) second.pixelY(HEX_SIZE);
        float alpha = 0.6F + (float) Math.sin((Minecraft.getInstance().player == null ? 0 : Minecraft.getInstance().player.tickCount) + (double) (switch(0) {
            default ->
                {
                    float native$result$12816 = (net.minecraft.client.Minecraft.getInstance().getFrameTime());
                    yield native$result$12816;
                }
        }) + x1) * 0.3F;
        float deltaX = x2 - x1;
        float deltaY = y2 - y1;
        float inverseLength = Mth.invSqrt(deltaX * deltaX + deltaY * deltaY);
        /*
         * GuiResearchTable used GL_LINE_STRIP with a 3-pixel line width.
         * Core-profile OpenGL implementations (notably macOS) are allowed
         * to clamp wide lines to one pixel, and DEBUG_LINE_STRIP is not a
         * reliable GUI primitive in the modern renderer. Build the line from
         * a quad, but convert the legacy framebuffer-pixel width back into
         * GUI units: unlike geometry, glLineWidth was not multiplied by the
         * GUI scale. Screen-local pose scaling must not change that width either.
         */
        float guiUnitsPerFramebufferPixel = (float) (1.0D / (Minecraft.getInstance().getWindow().getGuiScale() * graphics.pose().last().pose().transformDirection(new org.joml.Vector3f(-deltaY * inverseLength, deltaX * inverseLength, 0)).length()));
        float halfWidth = 1.5F * guiUnitsPerFramebufferPixel;
        float normalX = -deltaY * inverseLength * halfWidth;
        float normalY = deltaX * inverseLength * halfWidth;
        graphics.flush();
        VertexConsumer vertices = graphics.bufferSource().getBuffer(TCClientRenderTypes.guiAdditiveLineQuads());
        {
            com.mojang.blaze3d.vertex.VertexConsumer native$operand$14277 = vertices;
            org.joml.Matrix4f native$operand$14278 = graphics.pose().last().pose();
            float native$operand$14279 = x1 + normalX;
            float native$operand$14280 = y1 + normalY;
            float native$operand$14281 = 0.0F;
            float native$operand$14282 = 0.0F;
            float native$operand$14283 = 0.6F;
            float native$operand$14284 = 0.8F;
            float native$operand$14285 = alpha;
            native$operand$14277.vertex(native$operand$14278, native$operand$14279, native$operand$14280, native$operand$14281).color(native$operand$14282, native$operand$14283, native$operand$14284, native$operand$14285).endVertex();
        }
        {
            com.mojang.blaze3d.vertex.VertexConsumer native$operand$14286 = vertices;
            org.joml.Matrix4f native$operand$14287 = graphics.pose().last().pose();
            float native$operand$14288 = x1 - normalX;
            float native$operand$14289 = y1 - normalY;
            float native$operand$14290 = 0.0F;
            float native$operand$14291 = 0.0F;
            float native$operand$14292 = 0.6F;
            float native$operand$14293 = 0.8F;
            float native$operand$14294 = alpha;
            native$operand$14286.vertex(native$operand$14287, native$operand$14288, native$operand$14289, native$operand$14290).color(native$operand$14291, native$operand$14292, native$operand$14293, native$operand$14294).endVertex();
        }
        {
            com.mojang.blaze3d.vertex.VertexConsumer native$operand$14295 = vertices;
            org.joml.Matrix4f native$operand$14296 = graphics.pose().last().pose();
            float native$operand$14297 = x2 - normalX;
            float native$operand$14298 = y2 - normalY;
            float native$operand$14299 = 0.0F;
            float native$operand$14300 = 0.0F;
            float native$operand$14301 = 0.6F;
            float native$operand$14302 = 0.8F;
            float native$operand$14303 = alpha;
            native$operand$14295.vertex(native$operand$14296, native$operand$14297, native$operand$14298, native$operand$14299).color(native$operand$14300, native$operand$14301, native$operand$14302, native$operand$14303).endVertex();
        }
        {
            com.mojang.blaze3d.vertex.VertexConsumer native$operand$14304 = vertices;
            org.joml.Matrix4f native$operand$14305 = graphics.pose().last().pose();
            float native$operand$14306 = x2 + normalX;
            float native$operand$14307 = y2 + normalY;
            float native$operand$14308 = 0.0F;
            float native$operand$14309 = 0.0F;
            float native$operand$14310 = 0.6F;
            float native$operand$14311 = 0.8F;
            float native$operand$14312 = alpha;
            native$operand$14304.vertex(native$operand$14305, native$operand$14306, native$operand$14307, native$operand$14308).color(native$operand$14309, native$operand$14310, native$operand$14311, native$operand$14312).endVertex();
        }
        /*
         * Submit before another GUI primitive can share or replace the
         * buffer. The RenderType owns blend/depth/cull setup and cleanup.
         */
        graphics.flush();
    }

    private static ConnectionView connections(ResearchTableNote note, Set<AspectId> discovered) {
        Map<String, ResearchTableNote.Cell> byPosition = new HashMap<>();
        for (ResearchTableNote.Cell entry : note.cells()) {
            byPosition.put(key(entry), entry);
        }
        Set<String> checked = new HashSet<>();
        Set<String> highlighted = new HashSet<>();
        Set<String> lineKeys = new HashSet<>();
        List<HexConnection> lines = new ArrayList<>();
        for (ResearchTableNote.Cell entry : note.cells()) {
            if (entry.kind() != ResearchTableNote.Kind.FIXED || entry.aspect().isEmpty() || !discovered.contains(entry.aspect().orElseThrow()) || checked.contains(key(entry))) {
                continue;
            }
            ArrayDeque<ResearchTableNote.Cell> open = new ArrayDeque<>();
            open.push(entry);
            while (!open.isEmpty()) {
                ResearchTableNote.Cell current = open.pop();
                if (!checked.add(key(current))) {
                    continue;
                }
                HexCoordinate currentHex = new HexCoordinate(current.q(), current.r());
                for (int direction = 0; direction < 6; direction++) {
                    HexCoordinate neighbor = currentHex.neighbor(direction);
                    ResearchTableNote.Cell target = byPosition.get(neighbor.key());
                    if (target == null || target.kind() == ResearchTableNote.Kind.BLANK || target.aspect().isEmpty() || checked.contains(key(target)) || !connects(current.aspect().orElseThrow(), target.aspect().orElseThrow(), discovered)) {
                        continue;
                    }
                    String forward = key(current) + ":" + key(target);
                    String reverse = key(target) + ":" + key(current);
                    if (!lineKeys.contains(reverse) && lineKeys.add(forward)) {
                        lines.add(new HexConnection(currentHex, neighbor));
                        highlighted.add(key(target));
                    }
                    open.push(target);
                }
            }
        }
        return new ConnectionView(List.copyOf(lines), Set.copyOf(highlighted));
    }

    private static boolean connects(AspectId first, AspectId second, Set<AspectId> discovered) {
        if (!discovered.contains(first) || !discovered.contains(second)) {
            return false;
        }
        AspectDefinition firstDefinition = AspectCatalog.get(first);
        AspectDefinition secondDefinition = AspectCatalog.get(second);
        return firstDefinition != null && firstDefinition.components().contains(second) || secondDefinition != null && secondDefinition.components().contains(first);
    }

    /**
     * Draws the built-in 16-square orb animation, including the colorblind brightness policy.
     */
    public static void drawPulsingOrb(GuiGraphics graphics, int x, int y, int color) {
        Minecraft minecraft = Minecraft.getInstance();
        int tick = minecraft.player == null ? 0 : minecraft.player.tickCount;
        int frameU = 128 + Math.floorMod(tick, 8) * 16;
        graphics.flush();
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        graphics.setColor((color >> 16 & 0xFF) / 255.0F / (TCClientConfig.colorBlind() ? 1.8F : 1.0F), (color >> 8 & 0xFF) / 255.0F / (TCClientConfig.colorBlind() ? 1.8F : 1.0F), (color & 0xFF) / 255.0F / (TCClientConfig.colorBlind() ? 1.8F : 1.0F), 1.0F);
        /*
         * GuiResearchTable's drawOrb never established its own alpha-test:
         * two callers inherited 0.1 while the dragged foreground caller could
         * inherit RenderItem state. Apply the user-selected no-cutoff policy
         * to the shared helper so all three contexts have one stable result.
         */
        graphics.blit(EffectSequence.ASPECT_ORB.texture(frameU / 16), x, y, EffectSequence.ASPECT_ORB.x(frameU / 16), EffectSequence.ASPECT_ORB.y(frameU / 16), 16, 16, EffectSequence.ASPECT_ORB.textureWidth(frameU / 16), EffectSequence.ASPECT_ORB.textureHeight(frameU / 16));
        graphics.flush();
        graphics.setColor(1.0F, 1.0F, 1.0F, 1.0F);
        RenderSystem.disableBlend();
    }

    /**
     * The built-in fixed-node color cycle at a local GUI position.
     */
    public static int pulsingOrbColor(int x, int y) {
        Minecraft minecraft = Minecraft.getInstance();
        double tick = minecraft.player == null ? 0.0 : minecraft.player.tickCount + (double) (switch(0) {
            default ->
                {
                    float native$result$12962 = (net.minecraft.client.Minecraft.getInstance().getFrameTime());
                    yield native$result$12962;
                }
        });
        float red = 0.85F + (float) Math.sin((tick + x) / 10.0F) * 0.15F;
        float green = 0.85F + (float) Math.sin((tick + x + y) / 11.0F) * 0.15F;
        float blue = 0.85F + (float) Math.sin((tick + y) / 12.0F) * 0.15F;
        return Mth.clamp((int) (red * 255.0F), 0, 255) << 16 | Mth.clamp((int) (green * 255.0F), 0, 255) << 8 | Mth.clamp((int) (blue * 255.0F), 0, 255);
    }

    private void drawRunes(GuiGraphics graphics, ResearchTableNote note, int anchorX, int anchorY) {
        long now = System.currentTimeMillis();
        if (this.nextRune < now && Minecraft.getInstance().level != null) {
            this.nextRune = now + 250L;
            int pixelX = Minecraft.getInstance().level.random.nextInt(120) - 60;
            int pixelY = Minecraft.getInstance().level.random.nextInt(120) - 60;
            HexCoordinate coordinate = HexCoordinate.fromPixel(pixelX, pixelY, HEX_SIZE);
            if (!this.runes.containsKey(coordinate.key()) && note.cells().stream().noneMatch(cell -> cell.q() == coordinate.q() && cell.r() == coordinate.r())) {
                this.runes.put(coordinate.key(), new Rune(coordinate, now, this.nextRune + 15_000L + Minecraft.getInstance().level.random.nextInt(10_000), Minecraft.getInstance().level.random.nextInt(16)));
            }
        }
        Iterator<Rune> iterator = this.runes.values().iterator();
        while (iterator.hasNext()) {
            Rune rune = iterator.next();
            if (rune.decay() < now) {
                iterator.remove();
                continue;
            }
            float progress = (float) (now - rune.start()) / (rune.decay() - rune.start());
            float alpha = 0.5F;
            if (progress < 0.25F) {
                alpha = progress * 2.0F;
            } else if (progress > 0.5F) {
                alpha = 1.0F - progress;
            }
            int centerX = anchorX + (int) Math.round(rune.coordinate().pixelX(HEX_SIZE));
            int centerY = anchorY + (int) Math.round(rune.coordinate().pixelY(HEX_SIZE));
            drawRune(graphics, centerX, centerY, rune.glyph(), alpha * 0.66F);
        }
    }

    private static void drawRune(GuiGraphics graphics, int centerX, int centerY, int glyph, float alpha) {
        graphics.flush();
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        graphics.setColor(0.0F, 0.0F, 0.0F, alpha);
        graphics.pose().pushPose();
        graphics.pose().translate(centerX, centerY, 0.0F);
        graphics.pose().mulPose(Axis.ZN.rotationDegrees(90.0F));
        GuiAlphaCutoffBlitter.blit(graphics, SCRIPT, -5, -5, 10, 10, glyph * 16.0F, 0.0F, 16, 16, 256, 16);
        graphics.pose().popPose();
        graphics.flush();
        graphics.setColor(1.0F, 1.0F, 1.0F, 1.0F);
        RenderSystem.disableBlend();
    }

    public static void drawAspect(GuiGraphics graphics, AspectId aspect, int x, int y, float alpha, int pool, int bonus) {
        drawAspect(graphics, aspect, x, y, alpha, pool, bonus, false);
    }

    public static void drawAspect(GuiGraphics graphics, AspectId aspect, int x, int y, float alpha, int pool, int bonus, boolean monochrome) {
        /*
         * TC4 aspect sprites are intentionally grayscale. UtilsFX.drawTag
         * multiplied every sprite by Aspect#getColor; rendering them white
         * leaves the entire research pool gray.
         */
        if (monochrome) {
            AspectGuiRender.blitMonochrome(graphics, aspect, x, y, alpha);
        } else {
            AspectGuiRender.blit(graphics, aspect, x, y, alpha);
        }
        if (pool > 0) {
            String amount = Integer.toString(pool);
            graphics.pose().pushPose();
            graphics.pose().translate(x + 16, y + 16, 0.0F);
            graphics.pose().scale(0.5F, 0.5F, 1.0F);
            drawLegacyOutlinedString(graphics, amount, -Minecraft.getInstance().font.width(amount), -Minecraft.getInstance().font.lineHeight);
            graphics.pose().popPose();
        }
        if (bonus > 0) {
            int frameU = ((Minecraft.getInstance().player == null ? 0 : Minecraft.getInstance().player.tickCount) % 16) * 16;
            graphics.flush();
            RenderSystem.enableBlend();
            RenderSystem.defaultBlendFunc();
            graphics.blit(EffectSequence.PULSE.texture(frameU / 16), x - 4, y - 4, EffectSequence.PULSE.x(frameU / 16), EffectSequence.PULSE.y(frameU / 16), 16, 16, EffectSequence.PULSE.textureWidth(frameU / 16), EffectSequence.PULSE.textureHeight(frameU / 16));
            graphics.flush();
            RenderSystem.disableBlend();
            if (bonus > 1) {
                String amount = Integer.toString(bonus);
                graphics.pose().pushPose();
                graphics.pose().translate(x + 4, y + 15, 0.0F);
                graphics.pose().scale(0.5F, 0.5F, 1.0F);
                drawLegacyOutlinedString(graphics, amount, -Minecraft.getInstance().font.width(amount) / 2, -Minecraft.getInstance().font.lineHeight);
                graphics.pose().popPose();
            }
        }
    }

    /**
     * UtilsFX.drawTag outlined quantities on all four cardinal pixels.
     * Vanilla's modern shadow is only a single diagonal offset.
     */
    private static void drawLegacyOutlinedString(GuiGraphics graphics, String text, int x, int y) {
        graphics.drawString(Minecraft.getInstance().font, text, x - 1, y, 0xFF000000, false);
        graphics.drawString(Minecraft.getInstance().font, text, x + 1, y, 0xFF000000, false);
        graphics.drawString(Minecraft.getInstance().font, text, x, y - 1, 0xFF000000, false);
        graphics.drawString(Minecraft.getInstance().font, text, x, y + 1, 0xFF000000, false);
        graphics.drawString(Minecraft.getInstance().font, text, x, y, 0xFFFFFFFF, false);
    }

    private static void blitWithBlend(GuiGraphics graphics, ResourceLocation texture, int x, int y, float red, float green, float blue, float alpha, boolean additive) {
        graphics.flush();
        RenderSystem.enableBlend();
        RenderSystem.blendFunc(GlStateManager.SourceFactor.SRC_ALPHA, additive ? GlStateManager.DestFactor.ONE : GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA);
        graphics.setColor(red, green, blue, alpha);
        if (texture == HEX || texture == HEX_HIGHLIGHT) {
            /* Both source hex passes temporarily lowered alpha-test to 1/255. */
            graphics.blit(texture, x, y, 0, 0, 16, 16, 16, 16);
        } else {
            GuiAlphaCutoffBlitter.blit(graphics, texture, x, y, 0, 0, 16, 16, 16, 16);
        }
        graphics.flush();
        graphics.setColor(1.0F, 1.0F, 1.0F, 1.0F);
        RenderSystem.defaultBlendFunc();
        RenderSystem.disableBlend();
    }

    private static String key(ResearchTableNote.Cell cell) {
        return cell.q() + ":" + cell.r();
    }

    private static ResourceLocation texture(String path) {
        return net.minecraft.resources.ResourceLocation.fromNamespaceAndPath((java.lang.String) ("thaumcraft"), (java.lang.String) (path));
    }

    private record HexConnection(HexCoordinate first, HexCoordinate second) {
    }

    private record Rune(HexCoordinate coordinate, long start, long decay, int glyph) {
    }

    private record ConnectionView(List<HexConnection> lines, Set<String> highlighted) {
    }
}
