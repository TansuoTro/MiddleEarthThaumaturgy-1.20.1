package dev.tc4port.thaumcraft.api.golem;

import java.util.Objects;
import java.util.Optional;
import net.minecraft.core.GlobalPos;

/**
 * What a golem is doing right now, and why it is not doing anything else.
 *
 * <p>Server-side only: the runtime already holds every field, so reading this
 * costs nothing and needs no per-golem synchronization. It exists so that an
 * idle golem can be diagnosed by asking it rather than by nudging it.</p>
 *
 * @param ticks how long the golem has been in this activity with this target
 * @param blocked why the previous engagement ended, while that still applies
 */
public record GolemActivityView(Activity activity, Optional<GlobalPos> target, int ticks, Optional<Blocked> blocked) {

    public GolemActivityView {
        Objects.requireNonNull(activity, "activity");
        Objects.requireNonNull(target, "target");
        Objects.requireNonNull(blocked, "blocked");
        if (ticks < 0) {
            throw new IllegalArgumentException("ticks must not be negative");
        }
    }

    public enum Activity {

        /**
         * No core work available: waiting at home, or with no home.
         */
        IDLE,
        /**
         * Escaping a primed creeper.
         */
        FLEEING,
        /**
         * Guard or butcher combat.
         */
        FIGHTING,
        /**
         * Walking to an accepted work target.
         */
        TRAVELLING,
        /**
         * In range of the work target and performing the transaction.
         */
        WORKING,
        /**
         * Walking back home with no work engaged; the target is home.
         */
        RETURNING,
        /**
         * Waiting, at home or with no home, between steps of work already
         * under way: part way through a sweep of its area, or holding after a
         * transfer before the next.
         */
        PLANNING
    }

    public enum Blocked {

        /**
         * No path reached the target before the recovery ladder ran out.
         */
        UNREACHABLE,
        /**
         * The engagement outlived its budget.
         */
        EXPIRED,
        /**
         * The target stopped existing or stopped qualifying.
         */
        TARGET_GONE
    }
}
