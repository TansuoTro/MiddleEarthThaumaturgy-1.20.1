/**
 * Supported addon contracts for the modern Thaumcraft port.
 *
 * <p>Public types outside this package tree are implementation details unless
 * an API document explicitly says otherwise.</p>
 */
package dev.tc4port.thaumcraft.api;

