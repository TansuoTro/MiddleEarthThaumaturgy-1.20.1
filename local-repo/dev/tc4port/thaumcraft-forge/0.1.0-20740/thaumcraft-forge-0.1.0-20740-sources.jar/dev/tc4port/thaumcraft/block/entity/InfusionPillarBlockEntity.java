package dev.tc4port.thaumcraft.block.entity;

import dev.tc4port.thaumcraft.block.InfusionPillarBlock;
import dev.tc4port.thaumcraft.registry.TCBlockEntities;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.block.state.BlockState;
import dev.tc4port.thaumcraft.nativeimpl.state.ItemFields;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityType;

/**
 * The original TileInfusionPillar only persisted one orientation byte.
 * Orientation is a block state in the modern port, so the block entity is a
 * marker used by the matrix's exact structure validation.
 */
public final class InfusionPillarBlockEntity extends net.minecraft.world.level.block.entity.BlockEntity implements ItemFields.Source {

    public InfusionPillarBlockEntity(BlockPos pos, BlockState state) {
        super(TCBlockEntities.INFUSION_PILLAR.get(), pos, state);
    }

    public InfusionPillarBlock.Orientation orientation() {
        return this.getBlockState().getValue(InfusionPillarBlock.ORIENTATION);
    }

    protected final HolderLookup.Provider persistenceRegistries() {
        if (level != null)
            return level.registryAccess();
        var server = net.minecraftforge.server.ServerLifecycleHooks.getCurrentServer();
        return server != null ? server.registryAccess() : net.minecraft.core.RegistryAccess.fromRegistryOfRegistries(net.minecraft.core.registries.BuiltInRegistries.REGISTRY);
    }

    protected static net.minecraft.network.chat.Component parseCustomNameSafe(String value, HolderLookup.Provider registries) {
        try {
            return net.minecraft.network.chat.Component.Serializer.fromJson(value);
        } catch (RuntimeException exception) {
            return null;
        }
    }

    protected void readItemFields(ItemFields.Input input) {
    }

    public void copyItemFields(ItemFields.Output output) {
    }

    public void applyComponentsFromItemStack(ItemStack stack) {
        readItemFields(ItemFields.from(stack));
    }

    public void removeComponentsFromTag(CompoundTag tag) {
    }

    @Override
    public void saveToItem(ItemStack stack) {
        CompoundTag tag = saveWithoutMetadata();
        {
            net.minecraft.nbt.CompoundTag native$bodyOperand$6173 = tag;
            native$bodyReturn$6175: {
                if (true) {
                }
            }
        }
        net.minecraft.world.item.BlockItem.setBlockEntityData(stack, getType(), tag);
        copyItemFields(ItemFields.to(stack));
    }

    @Override
    public net.minecraft.world.phys.AABB getRenderBoundingBox() {
        return InfusionPillarBlockEntity.native$ClientBlockEntityBounds$bounds(this);
    }

    @Override()
    public void onDataPacket(net.minecraft.network.Connection connection, net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket packet) {
        handleUpdateTag(packet.getTag());
    }

    @SuppressWarnings({ "rawtypes", "unchecked" })
    static private net.minecraft.world.phys.AABB native$ClientBlockEntityBounds$bounds(net.minecraft.world.level.block.entity.BlockEntity blockEntity) {
        var renderer = net.minecraft.client.Minecraft.getInstance().getBlockEntityRenderDispatcher().getRenderer(blockEntity);
        return renderer instanceof dev.tc4port.thaumcraft.nativeimpl.NativeBlockEntityRenderer shared ? shared.getRenderBoundingBox(blockEntity) : new net.minecraft.world.phys.AABB(blockEntity.getBlockPos());
    }
}
