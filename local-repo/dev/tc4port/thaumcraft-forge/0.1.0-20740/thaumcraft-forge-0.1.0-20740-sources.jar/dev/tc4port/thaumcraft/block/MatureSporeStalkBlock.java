package dev.tc4port.thaumcraft.block;

import com.mojang.serialization.MapCodec;
import dev.tc4port.thaumcraft.common.TaintDecayCatalog;
import dev.tc4port.thaumcraft.entity.TaintSporeEntity;
import dev.tc4port.thaumcraft.registry.TCBlocks;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelReader;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.block.BushBlock;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.VoxelShape;

/**
 * Metadata-4 stalk while its attached TaintSpore is alive.
 */
public final class MatureSporeStalkBlock extends BushBlock {

    public static final MapCodec<MatureSporeStalkBlock> CODEC = MatureSporeStalkBlock.native$BlockCodecPlatform$simple(MatureSporeStalkBlock::new);

    public MatureSporeStalkBlock(BlockBehaviour.Properties properties) {
        super(properties);
    }

    protected MapCodec<MatureSporeStalkBlock> codec() {
        return CODEC;
    }

    @Override
    public VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
        return TaintedPlantBlock.SHAPE;
    }

    @Override
    public boolean canSurvive(BlockState state, LevelReader level, BlockPos pos) {
        BlockPos below = pos.below();
        return level.getBlockState(below).isFaceSturdy(level, below, Direction.UP);
    }

    @Override
    public void randomTick(BlockState state, ServerLevel level, BlockPos pos, RandomSource random) {
        TaintSpreadLogic.spreadBiome(level, pos, random);
        if (!TaintSpreadLogic.isTaintedAt(level, pos)) {
            TaintDecayCatalog.apply(state.getBlock(), TaintDecayCatalog.Trigger.OUTSIDE_TAINTED_BIOME, level, pos, random);
            return;
        }
        boolean spread = TaintSpreadLogic.tickFibreSpreadTarget(level, pos, random).fibresSpread();
        if (spread) {
            return;
        }
        AABB attachedSpace = new AABB(pos.getX(), pos.getY() + 1.0, pos.getZ(), pos.getX() + 1.0, pos.getY() + 2.0, pos.getZ() + 1.0);
        if (level.getEntitiesOfClass(TaintSporeEntity.class, attachedSpace).isEmpty()) {
            level.setBlock(pos, TCBlocks.SPORE_STALK.get().defaultBlockState(), 3);
        }
    }

    @Override
    public void entityInside(BlockState state, Level level, BlockPos pos, Entity entity) {
        TaintSpreadLogic.applyFibrousContact(level, entity);
        super.entityInside(state, level, pos, entity);
    }

    static private <B extends net.minecraft.world.level.block.Block> com.mojang.serialization.MapCodec<B> native$BlockCodecPlatform$simple(java.util.function.Function<net.minecraft.world.level.block.state.BlockBehaviour.Properties, B> factory) {
        // Vanilla 1.21's Properties codec is a unit codec. Retain that schema for shared block definitions.
        return com.mojang.serialization.codecs.RecordCodecBuilder.mapCodec(instance -> instance.group(com.mojang.serialization.Codec.unit(net.minecraft.world.level.block.state.BlockBehaviour.Properties::of).fieldOf("properties").forGetter((B block) -> net.minecraft.world.level.block.state.BlockBehaviour.Properties.copy(block))).apply(instance, factory));
    }
}
