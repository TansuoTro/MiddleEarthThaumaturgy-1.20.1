package dev.tc4port.thaumcraft.block;

import com.mojang.serialization.MapCodec;
import dev.tc4port.thaumcraft.registry.TCBlocks;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelReader;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.pathfinder.PathComputationType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.DirectionProperty;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;
import dev.tc4port.thaumcraft.nativeimpl.ClientExtensionTarget;
import dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.Explosion;

/**
 * Modern block-state form of TileBrainbox's single persisted facing.
 */
public final class MnemonicMatrixBlock extends net.minecraft.world.level.block.Block implements dev.tc4port.thaumcraft.nativeimpl.ClientExtensionTarget {

    // Forge calls initializeClient from the native superclass constructor. Do not add a field initializer.
    private java.util.function.Consumer<net.minecraftforge.client.extensions.common.IClientBlockExtensions> platform$clientInstaller;

    public static final MapCodec<MnemonicMatrixBlock> CODEC = MnemonicMatrixBlock.native$BlockCodecPlatform$simple(MnemonicMatrixBlock::new);

    public static final DirectionProperty FACING = BlockStateProperties.FACING;

    private static final VoxelShape BODY = Block.box(3.0, 3.0, 3.0, 13.0, 13.0, 13.0);

    public MnemonicMatrixBlock(BlockBehaviour.Properties properties) {
        this(properties, properties, true);
    }

    protected MapCodec<MnemonicMatrixBlock> codec() {
        return CODEC;
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(FACING);
    }

    @Override
    public BlockState getStateForPlacement(BlockPlaceContext context) {
        /*
         * BlockMetalDeviceItem only delegated metadata 12 placement when the
         * block that was clicked was a formed lower/upper thaumatorium. The
         * stored direction points from the matrix back into that host.
         */
        BlockState placed = this.defaultBlockState().setValue(FACING, context.getClickedFace().getOpposite());
        BlockState support = context.getLevel().getBlockState(context.getClickedPos().relative(placed.getValue(FACING)));
        return support.is(TCBlocks.THAUMATORIUM.get()) || support.is(TCBlocks.THAUMATORIUM_TOP.get()) ? placed : null;
    }

    @Override
    public boolean canSurvive(BlockState state, LevelReader level, BlockPos pos) {
        /*
         * TileBrainbox's neighbor check intentionally tested only for air.
         * Once placed on a formed machine, any non-air replacement continued
         * supporting it.
         */
        return !level.isEmptyBlock(pos.relative(state.getValue(FACING)));
    }

    @Override
    public void neighborChanged(BlockState state, Level level, BlockPos pos, Block neighborBlock, BlockPos neighborPos, boolean movedByPiston) {
        super.neighborChanged(state, level, pos, neighborBlock, neighborPos, movedByPiston);
        if (!level.isClientSide && !state.canSurvive(level, pos)) {
            level.destroyBlock(pos, true);
        }
    }

    @Override
    public VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
        return BODY;
    }

    @Override
    public VoxelShape getCollisionShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
        /*
         * BlockMetalDevice used its current 3..13 bounds for both selection
         * and collision. The narrow visual connector was never collidable.
         */
        return BODY;
    }

    @Override
    public VoxelShape getBlockSupportShape(BlockState state, BlockGetter level, BlockPos pos) {
        return Shapes.empty();
    }

    @Override
    public boolean isCollisionShapeFullBlock(BlockState state, BlockGetter level, BlockPos pos) {
        return false;
    }

    @Override
    public boolean isPathfindable(BlockState state, net.minecraft.world.level.BlockGetter level, BlockPos pos, PathComputationType pathType) {
        return false;
    }

    private MnemonicMatrixBlock(net.minecraft.world.level.block.state.BlockBehaviour.Properties native$NativeBlock$arg0, BlockBehaviour.Properties properties, boolean native$NativeBlock$captured) {
        super(native$NativeBlock$arg0);
        this.registerDefaultState(this.stateDefinition.any().setValue(FACING, Direction.DOWN));
    }

    @Override
    public void initializeClient(java.util.function.Consumer<net.minecraftforge.client.extensions.common.IClientBlockExtensions> installer) {
        platform$clientInstaller = installer;
        super.initializeClient(installer);
    }

    @Override
    public void platform$clientExtension(Object extension) {
        java.util.Objects.requireNonNull(platform$clientInstaller, "Forge initializeClient must run before client extension registration").accept((net.minecraftforge.client.extensions.common.IClientBlockExtensions) extension);
    }

    @Override
    public InteractionResult use(BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
        ItemUseResult result = (switch(0) {
            default ->
                {
                    net.minecraft.world.item.ItemStack native$bodyOperand$4606 = player.getItemInHand(hand);
                    net.minecraft.world.level.block.state.BlockState native$bodyOperand$4607 = state;
                    net.minecraft.world.level.Level native$bodyOperand$4608 = level;
                    net.minecraft.core.BlockPos native$bodyOperand$4609 = pos;
                    net.minecraft.world.entity.player.Player native$bodyOperand$4610 = player;
                    net.minecraft.world.InteractionHand native$bodyOperand$4611 = hand;
                    net.minecraft.world.phys.BlockHitResult native$bodyOperand$4612 = hit;
                    dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult native$bodyResult$4613 = null;
                    native$bodyReturn$4614: {
                        if (true) {
                            {
                                native$bodyResult$4613 = dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
                                break native$bodyReturn$4614;
                            }
                        }
                    }
                    yield native$bodyResult$4613;
                }
        });
        return result == ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION ? (hand == InteractionHand.MAIN_HAND ? (switch(0) {
            default ->
                {
                    net.minecraft.world.level.block.state.BlockState native$bodyOperand$3787 = state;
                    net.minecraft.world.level.Level native$bodyOperand$3788 = level;
                    net.minecraft.core.BlockPos native$bodyOperand$3789 = pos;
                    net.minecraft.world.entity.player.Player native$bodyOperand$3790 = player;
                    net.minecraft.world.phys.BlockHitResult native$bodyOperand$3791 = hit;
                    net.minecraft.world.InteractionResult native$bodyResult$3792 = null;
                    native$bodyReturn$3793: {
                        if (true) {
                            {
                                native$bodyResult$3792 = super.use(native$bodyOperand$3787, native$bodyOperand$3788, native$bodyOperand$3789, native$bodyOperand$3790, net.minecraft.world.InteractionHand.MAIN_HAND, native$bodyOperand$3791);
                                break native$bodyReturn$3793;
                            }
                        }
                    }
                    yield native$bodyResult$3792;
                }
        }) : InteractionResult.PASS) : result.result();
    }

    protected ItemUseResult interactWithItem(ItemStack stack, BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
        return dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
    }

    protected InteractionResult interactWithoutItem(BlockState state, Level level, BlockPos pos, Player player, BlockHitResult hit) {
        return super.use(state, level, pos, player, net.minecraft.world.InteractionHand.MAIN_HAND, hit);
    }

    @Override
    public void playerWillDestroy(Level level, BlockPos pos, BlockState state, Player player) {
        {
            net.minecraft.world.level.Level native$bodyOperand$5936 = level;
            net.minecraft.core.BlockPos native$bodyOperand$5937 = pos;
            net.minecraft.world.level.block.state.BlockState native$bodyOperand$5938 = state;
            net.minecraft.world.entity.player.Player native$bodyOperand$5939 = player;
            net.minecraft.world.level.block.state.BlockState native$bodyResult$5940 = null;
            native$bodyReturn$5941: {
                if (true) {
                    super.playerWillDestroy(native$bodyOperand$5936, native$bodyOperand$5937, native$bodyOperand$5938, native$bodyOperand$5939);
                    {
                        native$bodyResult$5940 = native$bodyOperand$5938;
                        break native$bodyReturn$5941;
                    }
                }
            }
        }
    }

    public BlockState beforePlayerDestroy(Level level, BlockPos pos, BlockState state, Player player) {
        super.playerWillDestroy(level, pos, state, player);
        return state;
    }

    protected boolean survivesSharedExplosion() {
        return false;
    }

    public int getExpDrop(net.minecraft.world.level.block.state.BlockState native$callbackInput$1145, net.minecraft.world.level.LevelReader native$callbackInput$1146, net.minecraft.util.RandomSource native$callbackInput$1147, net.minecraft.core.BlockPos native$callbackInput$1148, int native$callbackInput$1149, int native$callbackInput$1150) {
        net.minecraft.world.level.block.state.BlockState state = native$callbackInput$1145;
        net.minecraft.util.RandomSource random = native$callbackInput$1147;
        return 0;
    }

    @Override
    public void onBlockExploded(BlockState state, Level level, BlockPos pos, Explosion explosion) {
        if (!(switch(0) {
            default ->
                {
                    boolean native$bodyResult$5297 = false;
                    native$bodyReturn$5298: {
                        if (true) {
                            {
                                native$bodyResult$5297 = false;
                                break native$bodyReturn$5298;
                            }
                        }
                    }
                    yield native$bodyResult$5297;
                }
        }))
            super.onBlockExploded(state, level, pos, explosion);
    }

    @Override
    public boolean canDropFromExplosion(BlockState state, BlockGetter level, BlockPos pos, Explosion explosion) {
        return !(switch(0) {
            default ->
                {
                    boolean native$bodyResult$4615 = false;
                    native$bodyReturn$4616: {
                        if (true) {
                            {
                                native$bodyResult$4615 = false;
                                break native$bodyReturn$4616;
                            }
                        }
                    }
                    yield native$bodyResult$4615;
                }
        }) && super.canDropFromExplosion(state, level, pos, explosion);
    }

    static private <B extends net.minecraft.world.level.block.Block> com.mojang.serialization.MapCodec<B> native$BlockCodecPlatform$simple(java.util.function.Function<net.minecraft.world.level.block.state.BlockBehaviour.Properties, B> factory) {
        // Vanilla 1.21's Properties codec is a unit codec. Retain that schema for shared block definitions.
        return com.mojang.serialization.codecs.RecordCodecBuilder.mapCodec(instance -> instance.group(com.mojang.serialization.Codec.unit(net.minecraft.world.level.block.state.BlockBehaviour.Properties::of).fieldOf("properties").forGetter((B block) -> net.minecraft.world.level.block.state.BlockBehaviour.Properties.copy(block))).apply(instance, factory));
    }
}
