package dev.tc4port.thaumcraft.api.client;

/**
 * Linear particle vertex RGB, normalized to [0, 1]; no overflowing byte conversion.
 */
public record EffectColor(float red, float green, float blue) {

    public EffectColor {
        if (!valid(red) || !valid(green) || !valid(blue)) {
            throw new IllegalArgumentException("Effect RGB components must be finite and in [0, 1]");
        }
    }

    public static EffectColor rgb(int rgb) {
        return new EffectColor((rgb >> 16 & 255) / 255.0F, (rgb >> 8 & 255) / 255.0F, (rgb & 255) / 255.0F);
    }

    private static boolean valid(float value) {
        return Float.isFinite(value) && value >= 0.0F && value <= 1.0F;
    }
}
