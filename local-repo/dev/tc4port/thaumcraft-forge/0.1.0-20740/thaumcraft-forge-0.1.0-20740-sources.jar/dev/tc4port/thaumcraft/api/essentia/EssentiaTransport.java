package dev.tc4port.thaumcraft.api.essentia;

import dev.tc4port.thaumcraft.api.aspect.AspectId;
import javax.annotation.Nullable;
import net.minecraft.core.Direction;

/**
 * Directional essentia endpoint used by tubes and adjacent machines.
 *
 * <p>Faces are always viewed from the implementing block entity toward its
 * neighbour. Suction is pressure advertised by a destination; essentia moves
 * only when downstream suction exceeds upstream suction and meets the source
 * minimum. Amounts are whole essentia units. Transfer methods return the
 * number actually accepted or extracted, between zero and the requested
 * positive amount. Mutation and suction updates run on the logical server;
 * connection, displayed contents and render-shape queries may run on either
 * side, so implementations must synchronize client-visible state.</p>
 */
public interface EssentiaTransport {

    /**
     * Resolves a view for one synchronous neighbour query/transfer. Callers
     * must not retain it across operations or world mutations. Implementations
     * may resolve a multiblock endpoint once; contents must remain live.
     */
    default EssentiaTransport transferView() {
        return this;
    }

    boolean isConnectable(Direction face);

    boolean canInputFrom(Direction face);

    boolean canOutputTo(Direction face);

    @Nullable
    AspectId suctionType(Direction face);

    int suctionAmount(Direction face);

    int takeEssentia(AspectId aspect, int amount, Direction face, EssentiaTransferMode mode);

    int addEssentia(AspectId aspect, int amount, Direction face, EssentiaTransferMode mode);

    @Nullable
    AspectId essentiaType(Direction face);

    int essentiaAmount(Direction face);

    /**
     * Selects an arbitrary currently extractable type before a face has bound
     * the transfer. Mixed stores may override; the default has none.
     */
    @Nullable
    default AspectId extractableAspect(Direction face) {
        return null;
    }

    /**
     * Whole units of one type currently extractable through a face. The
     * default covers single-type transports; mixed stores override it.
     */
    default int availableEssentia(AspectId aspect, Direction face) {
        AspectId visible = this.essentiaType(face);
        return aspect.equals(visible) ? this.essentiaAmount(face) : 0;
    }

    int minimumSuction();

    boolean renderExtendedTube();
}
