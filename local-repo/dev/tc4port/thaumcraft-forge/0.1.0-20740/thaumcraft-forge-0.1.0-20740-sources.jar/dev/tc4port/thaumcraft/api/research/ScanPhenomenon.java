package dev.tc4port.thaumcraft.api.research;

import dev.tc4port.thaumcraft.nativeimpl.ComponentStatePlatform;
import dev.tc4port.thaumcraft.api.aspect.AspectAmounts;
import java.util.Objects;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;

/**
 * Immutable addon result for a non-block, non-entity scan phenomenon.
 * The namespaced ID is persisted as the discovery identity and must remain
 * stable across ticks, positions, players and restarts.
 */
public record ScanPhenomenon(ResourceLocation id, AspectAmounts aspects, Component displayName) {

    public static final int MAX_ID_LENGTH = 256;

    public static final int MAX_DISPLAY_JSON_LENGTH = 4_096;

    public static final int MAX_ASPECTS = 64;

    public ScanPhenomenon {
        id = Objects.requireNonNull(id, "id");
        if (id.toString().length() > MAX_ID_LENGTH) {
            throw new IllegalArgumentException("A scan phenomenon ID must not exceed " + MAX_ID_LENGTH + " characters");
        }
        aspects = Objects.requireNonNull(aspects, "aspects");
        if (aspects.amounts().isEmpty() || aspects.amounts().size() > MAX_ASPECTS) {
            throw new IllegalArgumentException("A scan phenomenon must expose from 1 to " + MAX_ASPECTS + " aspects");
        }
        displayName = Objects.requireNonNull(displayName, "displayName").copy();
        if (ComponentStatePlatform.encodedLength(displayName) > MAX_DISPLAY_JSON_LENGTH) {
            throw new IllegalArgumentException("A scan phenomenon display component must not exceed " + MAX_DISPLAY_JSON_LENGTH + " encoded characters");
        }
    }

    @Override
    public Component displayName() {
        return this.displayName.copy();
    }
}
