package dev.tc4port.thaumcraft.api.data;

import com.mojang.serialization.Codec;
import dev.tc4port.thaumcraft.api.item.ItemStatePlatform;
import java.util.Objects;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.ItemStack;

/**
 * A typed current-format item field; native storage is supplied by the target platform.
 */
public class ItemStateKey<T> {

    private final ResourceLocation id;

    private final Codec<T> codec;

    public ItemStateKey(ResourceLocation id, Codec<T> codec) {
        this.id = Objects.requireNonNull(id);
        this.codec = Objects.requireNonNull(codec, "codec");
    }

    public ItemStateKey(ResourceLocation id, Codec<T> codec, dev.tc4port.thaumcraft.api.network.MessageCodec<net.minecraft.network.FriendlyByteBuf, T> wire) {
        this(id, codec);
        Objects.requireNonNull(wire, "wire");
    }

    public ResourceLocation id() {
        return this.id;
    }

    public Codec<T> codec() {
        return this.codec;
    }
}
