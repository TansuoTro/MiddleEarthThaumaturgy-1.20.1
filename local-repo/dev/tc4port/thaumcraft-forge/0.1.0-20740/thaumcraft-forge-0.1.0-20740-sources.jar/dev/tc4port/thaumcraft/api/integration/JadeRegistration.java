package dev.tc4port.thaumcraft.api.integration;

import java.util.LinkedHashMap;
import java.util.Map;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraftforge.network.NetworkDirection;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.simple.SimpleChannel;
import snownee.jade.api.*;

/**
 * Block providers use Jade's native BE path and an owned accessor for parts without a BE.
 */
public final class JadeRegistration {

    public static final Map<Class<? extends Block>, IServerDataProvider<BlockAccessor>> BLOCK_PROVIDERS = new LinkedHashMap<>();

    private static final java.util.Set<IServerDataProvider<BlockAccessor>> REGISTERED = new java.util.HashSet<>();

    private static final Map<String, SimpleChannel> CHANNELS = new LinkedHashMap<>();

    private static final java.util.Set<IWailaClientRegistration> CLIENTS = java.util.Collections.newSetFromMap(new java.util.IdentityHashMap<>());

    private static final String BLOCK = "native_part_block";

    private static final String DIMENSION = "native_part_dimension";

    private JadeRegistration() {
    }

    public static void blockData(IWailaCommonRegistration registration, IServerDataProvider<BlockAccessor> provider, Class<? extends Block> type) {
        BLOCK_PROVIDERS.put(type, provider);
        if (REGISTERED.add(provider))
            registration.registerBlockDataProvider(provider, net.minecraft.world.level.block.entity.BlockEntity.class);
        CHANNELS.computeIfAbsent(provider.getUid().getNamespace(), namespace -> {
            var channel = NetworkRegistry.newSimpleChannel(ResourceLocation.fromNamespaceAndPath(namespace, "jade_block_data"), () -> "1", NetworkRegistry.acceptMissingOr("1"), NetworkRegistry.acceptMissingOr("1"));
            channel.messageBuilder(Request.class, 0, NetworkDirection.PLAY_TO_SERVER).encoder((request, buffer) -> {
                buffer.writeBlockHitResult(request.hit());
                buffer.writeBoolean(request.details());
                buffer.writeItem(request.fakeBlock());
            }).decoder(buffer -> new Request(buffer.readBlockHitResult(), buffer.readBoolean(), buffer.readItem())).consumerMainThread((request, context) -> {
                var player = context.get().getSender();
                if (player != null) {
                    var data = serverData(player, request.hit(), request.details(), request.fakeBlock(), namespace);
                    if (data != null)
                        snownee.jade.util.CommonProxy.NETWORK.sendTo(new snownee.jade.network.ReceiveDataPacket(data), player.connection.connection, NetworkDirection.PLAY_TO_CLIENT);
                }
            }).add();
            return channel;
        });
    }

    public static IServerDataProvider<BlockAccessor> provider(Block block) {
        for (var entry : BLOCK_PROVIDERS.entrySet()) if (entry.getKey().isInstance(block))
            return entry.getValue();
        return null;
    }

    private record Request(BlockHitResult hit, boolean details, ItemStack fakeBlock) {
    }

    /**
     * Authoritative snapshot for the native request transport; null means no valid current target.
     */
    public static CompoundTag serverData(ServerPlayer player, BlockHitResult hit, boolean details, ItemStack fakeBlock, String namespace) {
        var pos = hit.getBlockPos();
        var level = player.serverLevel();
        if (pos.distSqr(player.blockPosition()) > snownee.jade.Jade.MAX_DISTANCE_SQR || !level.isLoaded(pos) || level.getBlockEntity(pos) != null)
            return null;
        var state = level.getBlockState(pos);
        var provider = provider(state.getBlock());
        if (provider == null || !provider.getUid().getNamespace().equals(namespace))
            return null;
        // Neither the target state nor the BE is accepted from the requesting client.
        var accessor = new snownee.jade.impl.BlockAccessorImpl.Builder().level(level).player(player).hit(hit).blockState(state).showDetails(details).fakeBlock(fakeBlock).build();
        var data = accessor.getServerData();
        try {
            provider.appendServerData(data, accessor);
        } catch (Exception exception) {
            snownee.jade.util.WailaExceptionHandler.handleErr(exception, provider, null);
            return null;
        }
        data.putInt("x", pos.getX());
        data.putInt("y", pos.getY());
        data.putInt("z", pos.getZ());
        data.putString(BLOCK, net.minecraft.core.registries.BuiltInRegistries.BLOCK.getKey(state.getBlock()).toString());
        data.putString(DIMENSION, level.dimension().location().toString());
        return data;
    }

    public static void client(IWailaClientRegistration registration) {
        if (!CLIENTS.add(registration))
            return;
        registration.registerAccessorHandler(PartAccessor.class, new Accessor.ClientHandler<PartAccessor>() {

            private Accessor.ClientHandler<Accessor<?>> delegate() {
                return registration.getAccessorHandler(BlockAccessor.class);
            }

            @Override
            public boolean shouldDisplay(PartAccessor accessor) {
                return delegate().shouldDisplay(accessor.delegate);
            }

            @Override
            public boolean shouldRequestData(PartAccessor accessor) {
                return connected(accessor) != null;
            }

            @Override
            public void requestData(PartAccessor accessor) {
                var channel = connected(accessor);
                if (channel != null)
                    channel.sendToServer(new Request(accessor.getHitResult(), accessor.showDetails(), accessor.getFakeBlock()));
            }

            @Override
            public snownee.jade.api.ui.IElement getIcon(PartAccessor accessor) {
                return delegate().getIcon(accessor);
            }

            @Override
            public void gatherComponents(PartAccessor accessor, java.util.function.Function<IJadeProvider, ITooltip> tooltips) {
                delegate().gatherComponents(accessor, tooltips);
            }

            private SimpleChannel connected(PartAccessor accessor) {
                var provider = provider(accessor.getBlock());
                var connection = net.minecraft.client.Minecraft.getInstance().getConnection();
                if (provider == null || connection == null || !accessor.isServerConnected())
                    return null;
                var channel = CHANNELS.get(provider.getUid().getNamespace());
                return channel != null && channel.isRemotePresent(connection.getConnection()) ? channel : null;
            }
        });
        registration.addRayTraceCallback((hit, current, original) -> current instanceof BlockAccessor block ? accessor(block) : current);
    }

    public static BlockAccessor accessor(BlockAccessor block) {
        return !(block instanceof PartAccessor) && block.getBlockEntity() == null && provider(block.getBlock()) != null ? new PartAccessor(block) : block;
    }

    private static final class PartAccessor implements BlockAccessor {

        private final BlockAccessor delegate;

        private PartAccessor(BlockAccessor delegate) {
            this.delegate = delegate;
        }

        @Override
        public Class<? extends Accessor<?>> getAccessorType() {
            return PartAccessor.class;
        }

        @Override
        public net.minecraft.world.level.Level getLevel() {
            return delegate.getLevel();
        }

        @Override
        public net.minecraft.world.entity.player.Player getPlayer() {
            return delegate.getPlayer();
        }

        @Override
        public CompoundTag getServerData() {
            var data = delegate.getServerData();
            return (switch(0) {
                default ->
                    {
                        net.minecraft.nbt.CompoundTag native$bodyOperand$3985 = data;
                        boolean native$bodyResult$3987 = false;
                        native$bodyReturn$3988: {
                            if (true) {
                                var native$bodyBinding$3986 = (switch(0) {
                                    default ->
                                        {
                                            net.minecraft.core.BlockPos native$bodyResult$8928 = null;
                                            native$bodyReturn$8929: {
                                                if (true) {
                                                    {
                                                        native$bodyResult$8928 = delegate.getPosition();
                                                        break native$bodyReturn$8929;
                                                    }
                                                }
                                            }
                                            yield native$bodyResult$8928;
                                        }
                                });
                                {
                                    native$bodyResult$3987 = native$bodyOperand$3985.contains("x", 3) && native$bodyOperand$3985.contains("y", 3) && native$bodyOperand$3985.contains("z", 3) && native$bodyOperand$3985.getInt("x") == native$bodyBinding$3986.getX() && native$bodyOperand$3985.getInt("y") == native$bodyBinding$3986.getY() && native$bodyOperand$3985.getInt("z") == native$bodyBinding$3986.getZ() && native$bodyOperand$3985.getString(dev.tc4port.thaumcraft.api.integration.JadeRegistration.BLOCK).equals(net.minecraft.core.registries.BuiltInRegistries.BLOCK.getKey((switch(0) {
                                        default ->
                                            {
                                                net.minecraft.world.level.block.Block native$bodyResult$8914 = null;
                                                native$bodyReturn$8915: {
                                                    if (true) {
                                                        {
                                                            native$bodyResult$8914 = delegate.getBlock();
                                                            break native$bodyReturn$8915;
                                                        }
                                                    }
                                                }
                                                yield native$bodyResult$8914;
                                            }
                                    })).toString()) && native$bodyOperand$3985.getString(dev.tc4port.thaumcraft.api.integration.JadeRegistration.DIMENSION).equals((switch(0) {
                                        default ->
                                            {
                                                net.minecraft.world.level.Level native$bodyResult$8916 = null;
                                                native$bodyReturn$8917: {
                                                    if (true) {
                                                        {
                                                            native$bodyResult$8916 = delegate.getLevel();
                                                            break native$bodyReturn$8917;
                                                        }
                                                    }
                                                }
                                                yield native$bodyResult$8916;
                                            }
                                    }).dimension().location().toString());
                                    break native$bodyReturn$3988;
                                }
                            }
                        }
                        yield native$bodyResult$3987;
                    }
            }) ? data : new CompoundTag();
        }

        @Override
        public BlockHitResult getHitResult() {
            return delegate.getHitResult();
        }

        @Override
        public boolean isServerConnected() {
            return delegate.isServerConnected();
        }

        @Override
        public ItemStack getPickedResult() {
            return delegate.getPickedResult();
        }

        @Override
        public boolean showDetails() {
            return delegate.showDetails();
        }

        @Override
        public Object getTarget() {
            return delegate.getTarget();
        }

        @Override
        public void toNetwork(net.minecraft.network.FriendlyByteBuf buffer) {
            delegate.toNetwork(buffer);
        }

        @Override
        public boolean verifyData(CompoundTag data) {
            var pos = (switch(0) {
                default ->
                    {
                        net.minecraft.core.BlockPos native$bodyResult$3390 = null;
                        native$bodyReturn$3391: {
                            if (true) {
                                {
                                    native$bodyResult$3390 = delegate.getPosition();
                                    break native$bodyReturn$3391;
                                }
                            }
                        }
                        yield native$bodyResult$3390;
                    }
            });
            return data.contains("x", 3) && data.contains("y", 3) && data.contains("z", 3) && data.getInt("x") == pos.getX() && data.getInt("y") == pos.getY() && data.getInt("z") == pos.getZ() && data.getString(dev.tc4port.thaumcraft.api.integration.JadeRegistration.BLOCK).equals(net.minecraft.core.registries.BuiltInRegistries.BLOCK.getKey((switch(0) {
                default ->
                    {
                        net.minecraft.world.level.block.Block native$bodyResult$3322 = null;
                        native$bodyReturn$3323: {
                            if (true) {
                                {
                                    native$bodyResult$3322 = delegate.getBlock();
                                    break native$bodyReturn$3323;
                                }
                            }
                        }
                        yield native$bodyResult$3322;
                    }
            })).toString()) && data.getString(dev.tc4port.thaumcraft.api.integration.JadeRegistration.DIMENSION).equals((switch(0) {
                default ->
                    {
                        net.minecraft.world.level.Level native$bodyResult$3324 = null;
                        native$bodyReturn$3325: {
                            if (true) {
                                {
                                    native$bodyResult$3324 = delegate.getLevel();
                                    break native$bodyReturn$3325;
                                }
                            }
                        }
                        yield native$bodyResult$3324;
                    }
            }).dimension().location().toString());
        }

        @Override
        public Block getBlock() {
            return delegate.getBlock();
        }

        @Override
        public net.minecraft.world.level.block.state.BlockState getBlockState() {
            return delegate.getBlockState();
        }

        @Override
        public net.minecraft.world.level.block.entity.BlockEntity getBlockEntity() {
            return delegate.getBlockEntity();
        }

        @Override
        public net.minecraft.core.BlockPos getPosition() {
            return delegate.getPosition();
        }

        @Override
        public net.minecraft.core.Direction getSide() {
            return delegate.getSide();
        }

        @Override
        public boolean isFakeBlock() {
            return delegate.isFakeBlock();
        }

        @Override
        public ItemStack getFakeBlock() {
            return delegate.getFakeBlock();
        }
    }
}
