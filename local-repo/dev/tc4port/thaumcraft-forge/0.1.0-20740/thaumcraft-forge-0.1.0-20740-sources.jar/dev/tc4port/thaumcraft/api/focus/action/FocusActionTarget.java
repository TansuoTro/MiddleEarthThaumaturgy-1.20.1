package dev.tc4port.thaumcraft.api.focus.action;

import dev.tc4port.thaumcraft.api.focus.FocusId;
import dev.tc4port.thaumcraft.api.focus.FocusUpgradeId;
import java.util.Objects;

public sealed interface FocusActionTarget {

    record Focus(FocusId id) implements FocusActionTarget {

        public Focus {
            Objects.requireNonNull(id, "id");
        }
    }

    record Upgrade(FocusUpgradeId id) implements FocusActionTarget {

        public Upgrade {
            Objects.requireNonNull(id, "id");
        }
    }
}
