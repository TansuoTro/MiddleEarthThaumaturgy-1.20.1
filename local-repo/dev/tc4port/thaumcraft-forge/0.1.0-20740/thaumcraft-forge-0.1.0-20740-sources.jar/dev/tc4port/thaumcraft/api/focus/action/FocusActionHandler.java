package dev.tc4port.thaumcraft.api.focus.action;

import dev.tc4port.thaumcraft.api.aspect.VisAction;
import dev.tc4port.thaumcraft.api.focus.FocusStateView;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;

@FunctionalInterface
public interface FocusActionHandler {

    /**
     * SIMULATE must be side-effect free and return the same non-PASS result
     * that the immediately following EXECUTE returns. TC validates the whole
     * chain, runs any registered authorization, and commits its planned Vis
     * debit before invoking EXECUTE. The authorization token is then exposed
     * through {@link FocusActionContext#authorization()}.
     */
    FocusActionResult handle(FocusActionContext context, VisAction action);

    /**
     * Predicts an owned action on the controlling client, like native item use.
     * Check local eligibility without debiting resources; payment and gameplay
     * authorization remain in the server action. Observers never execute this.
     */
    default void predict(Player player, InteractionHand hand, ItemStack wand, FocusStateView focus, FocusActivation activation) {
    }
}
