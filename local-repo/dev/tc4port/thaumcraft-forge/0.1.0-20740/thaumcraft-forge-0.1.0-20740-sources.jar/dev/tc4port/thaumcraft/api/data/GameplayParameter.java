package dev.tc4port.thaumcraft.api.data;

import dev.tc4port.thaumcraft.common.GameplayParameterCatalog;
import net.minecraft.resources.ResourceLocation;

/**
 * A declared, reloadable gameplay number. Declare parameters during mod initialization.
 * Bounds describe consumer safety, not the default balance. Reads observe the latest
 * server snapshot; do not cache a read in a static field or a long-lived capacity.
 */
public record GameplayParameter(ResourceLocation id, double defaultValue, double minimum, double maximum, boolean integral) {

    public GameplayParameter {
        if (id == null || id.getPath().indexOf('/') <= 0 || id.getPath().lastIndexOf('/') <= id.getPath().indexOf('/') || id.getPath().endsWith("/") || !Double.isFinite(defaultValue) || !Double.isFinite(minimum) || !Double.isFinite(maximum) || minimum > defaultValue || defaultValue > maximum || (integral && (minimum < Integer.MIN_VALUE || maximum > Integer.MAX_VALUE || Math.rint(defaultValue) != defaultValue))) {
            throw new IllegalArgumentException("Invalid gameplay parameter declaration: " + id);
        }
    }

    public static GameplayParameter integer(String id, int value, int minimum, int maximum) {
        return declare(id, value, minimum, maximum, true);
    }

    public static GameplayParameter number(String id, double value, double minimum, double maximum) {
        return declare(id, value, minimum, maximum, false);
    }

    public static GameplayParameter flag(String id, boolean value) {
        return declare(id, value ? 1 : 0, 0, 1, true);
    }

    private static GameplayParameter declare(String id, double value, double min, double max, boolean integral) {
        GameplayParameter parameter = new GameplayParameter(ResourceLocation.parse(id), value, min, max, integral);
        GameplayParameterCatalog.declare(parameter);
        return parameter;
    }

    public static void requireAtMost(GameplayParameter lower, GameplayParameter upper) {
        GameplayParameterCatalog.requireAtMost(lower, upper);
    }

    public static void requireLessThan(GameplayParameter lower, GameplayParameter upper) {
        GameplayParameterCatalog.requireLessThan(lower, upper);
    }

    /**
     * Other fields in this content definition belong to an existing data reader.
     */
    public static void sharedFields(String resourceId, String... fields) {
        GameplayParameterCatalog.sharedFields(ResourceLocation.parse(resourceId), fields);
    }

    /**
     * Custom data types belong to the declaring mod, independently of their provider.
     */
    public String dataDirectory() {
        return id.getNamespace() + "/" + id.getPath().substring(0, id.getPath().indexOf('/'));
    }

    public ResourceLocation resourceId() {
        return ResourceLocation.fromNamespaceAndPath(id.getNamespace(), id.getPath().substring(0, id.getPath().lastIndexOf('/')));
    }

    public double value() {
        return GameplayParameterCatalog.value(this);
    }

    /**
     * Changes whenever the installed override snapshot changes, including disconnect.
     */
    public static long generation() {
        return GameplayParameterCatalog.generation();
    }

    /**
     * Observes completed snapshot changes. Schedule world mutations onto the server thread.
     */
    public static dev.tc4port.thaumcraft.api.Registration onChanged(Runnable listener) {
        return GameplayParameterCatalog.onChanged(listener);
    }

    /**
     * Use the current server configuration when no datapack supplied this parameter.
     */
    public double valueOr(double fallback) {
        return GameplayParameterCatalog.valueOr(this, fallback);
    }

    public int intValueOr(int fallback) {
        if (!integral)
            throw new IllegalStateException("Not an integer parameter: " + id);
        return (int) valueOr(fallback);
    }

    public boolean enabledOr(boolean fallback) {
        return valueOr(fallback ? 1 : 0) != 0;
    }

    public int intValue() {
        if (!integral)
            throw new IllegalStateException("Not an integer parameter: " + id);
        return (int) value();
    }

    public float floatValue() {
        return (float) value();
    }

    public boolean enabled() {
        return value() != 0;
    }

    public void validate(double value) {
        if (!Double.isFinite(value) || value < minimum || value > maximum || (integral && Math.rint(value) != value)) {
            throw new IllegalArgumentException(id + " must be " + (integral ? "an integer " : "") + "in [" + minimum + ", " + maximum + "]");
        }
    }
}
