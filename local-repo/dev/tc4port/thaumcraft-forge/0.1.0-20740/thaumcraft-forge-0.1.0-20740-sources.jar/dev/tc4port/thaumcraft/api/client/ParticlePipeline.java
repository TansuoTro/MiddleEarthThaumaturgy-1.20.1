package dev.tc4port.thaumcraft.api.client;

import java.util.*;
import java.util.function.*;
import net.minecraft.client.particle.ParticleRenderType;
import net.minecraft.client.renderer.texture.TextureManager;

/**
 * Native particle bucket boundaries and ordering; each participant owns its render state.
 */
public final class ParticlePipeline {

    private static final List<ToIntFunction<ParticleRenderType>> ORDERS = new ArrayList<>();

    private static final List<BiConsumer<ParticleRenderType, TextureManager>> BEFORE = new ArrayList<>();

    private static final List<Runnable> AFTER = new ArrayList<>();

    private ParticlePipeline() {
    }

    public static void register(ToIntFunction<ParticleRenderType> order, BiConsumer<ParticleRenderType, TextureManager> before, Runnable after) {
        ORDERS.add(order);
        BEFORE.add(before);
        AFTER.add(after);
    }

    public static void prepare(ParticleRenderType type, TextureManager textures) {
        BEFORE.forEach(listener -> listener.accept(type, textures));
    }

    public static void finish() {
        AFTER.forEach(Runnable::run);
    }

    public static Comparator<ParticleRenderType> comparator(List<ParticleRenderType> vanilla, Comparator<ParticleRenderType> fallback) {
        // Keep the registrations live: the engine may construct its comparator before client setup.
        return ParticlePipeline.native$ParticleLayerOrder$stabilize(vanilla, fallback, type -> {
            for (var order : ORDERS) {
                int rank = order.applyAsInt(type);
                if (rank >= 0)
                    return rank;
            }
            return -1;
        });
    }

    static private java.util.Comparator<net.minecraft.client.particle.ParticleRenderType> native$ParticleLayerOrder$stabilize(java.util.List<net.minecraft.client.particle.ParticleRenderType> vanillaOrder, java.util.Comparator<net.minecraft.client.particle.ParticleRenderType> fallback, java.util.function.ToIntFunction<net.minecraft.client.particle.ParticleRenderType> layerOrder) {
        return (left, right) -> {
            if (left == right) {
                return 0;
            }
            boolean leftCustom = left == net.minecraft.client.particle.ParticleRenderType.CUSTOM;
            boolean rightCustom = right == net.minecraft.client.particle.ParticleRenderType.CUSTOM;
            boolean leftVanilla = vanillaOrder.contains(left);
            boolean rightVanilla = vanillaOrder.contains(right);
            if (leftCustom && !rightVanilla && layerOrder.applyAsInt(right) >= 0) {
                return 1;
            }
            if (rightCustom && !leftVanilla && layerOrder.applyAsInt(left) >= 0) {
                return -1;
            }
            if (leftVanilla || rightVanilla) {
                return fallback.compare(left, right);
            }
            int leftOrder = layerOrder.applyAsInt(left);
            int rightOrder = layerOrder.applyAsInt(right);
            if (leftOrder >= 0 && rightOrder >= 0) {
                int order = java.lang.Integer.compare(leftOrder, rightOrder);
                /*
                 * TreeMap treats comparator equality as key equality. Never
                 * merge distinct texture-backed render buckets if a future
                 * layer is accidentally assigned the same coarse order.
                 */
                return order != 0 ? order : fallback.compare(left, right);
            }
            if (leftOrder >= 0) {
                return -1;
            }
            if (rightOrder >= 0) {
                return 1;
            }
            return fallback.compare(left, right);
        };
    }
}
