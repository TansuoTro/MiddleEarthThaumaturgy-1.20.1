package dev.tc4port.thaumcraft.api.taint;

/**
 * Outcome of one server-authoritative loaded-column taint request.
 */
public enum TaintBiomeChangeResult {

    APPLIED, CHUNK_UNLOADED, OFF_SERVER_THREAD
}
