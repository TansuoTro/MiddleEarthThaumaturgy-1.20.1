package dev.tc4port.thaumcraft.api.essentia;

import dev.tc4port.thaumcraft.api.aspect.AspectContainerView;

/**
 * Opt-in resonator view for transports whose meaningful contents span more
 * than the clicked face. Ordinary transports retain directional inspection.
 */
public interface EssentiaMultiStoreView extends AspectContainerView {
}
