package dev.tc4port.thaumcraft.block;

import com.mojang.serialization.MapCodec;
import dev.tc4port.thaumcraft.block.entity.ThaumatoriumBlockEntity;
import dev.tc4port.thaumcraft.block.entity.ThaumatoriumTopBlockEntity;
import dev.tc4port.thaumcraft.registry.TCBlockEntities;
import dev.tc4port.thaumcraft.registry.TCBlocks;
import java.util.Optional;
import javax.annotation.Nullable;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityTicker;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.DirectionProperty;
import net.minecraft.world.level.pathfinder.PathComputationType;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;
import dev.tc4port.thaumcraft.nativeimpl.ClientExtensionTarget;
import dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.phys.HitResult;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.Explosion;

/**
 * Formed upper proxy block (legacy metadata 11).
 */
public final class ThaumatoriumTopBlock extends net.minecraft.world.level.block.BaseEntityBlock implements dev.tc4port.thaumcraft.nativeimpl.ClientExtensionTarget {

    // Forge calls initializeClient from the native superclass constructor. Do not add a field initializer.
    private java.util.function.Consumer<net.minecraftforge.client.extensions.common.IClientBlockExtensions> platform$clientInstaller;

    public static final MapCodec<ThaumatoriumTopBlock> CODEC = ThaumatoriumTopBlock.native$BlockCodecPlatform$simple(ThaumatoriumTopBlock::new);

    public static final DirectionProperty FACING = BlockStateProperties.FACING;

    public ThaumatoriumTopBlock(BlockBehaviour.Properties properties) {
        this(properties, properties, true);
    }

    protected MapCodec<ThaumatoriumTopBlock> codec() {
        return CODEC;
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(FACING);
    }

    @Nullable
    @Override
    public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        return new ThaumatoriumTopBlockEntity(pos, state);
    }

    @Nullable
    @Override
    public <T extends BlockEntity> BlockEntityTicker<T> getTicker(Level level, BlockState state, BlockEntityType<T> type) {
        return level.isClientSide ? null : createTickerHelper(type, TCBlockEntities.THAUMATORIUM_TOP.get(), ThaumatoriumTopBlockEntity::serverTick);
    }

    @Override
    public RenderShape getRenderShape(BlockState state) {
        return RenderShape.MODEL;
    }

    @Override
    public VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
        // Metadata 11 selected the same two-block OBJ from its upper half.
        return Shapes.box(0.0, -1.0, 0.0, 1.0, 1.0, 1.0);
    }

    @Override
    public VoxelShape getCollisionShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
        return Shapes.block();
    }

    @Override
    public VoxelShape getBlockSupportShape(BlockState state, BlockGetter level, BlockPos pos) {
        return Shapes.empty();
    }

    @Override
    public boolean isCollisionShapeFullBlock(BlockState state, BlockGetter level, BlockPos pos) {
        return false;
    }

    @Override
    public boolean isPathfindable(BlockState state, net.minecraft.world.level.BlockGetter level, BlockPos pos, PathComputationType pathType) {
        return false;
    }

    protected InteractionResult interactWithoutItem(BlockState state, Level level, BlockPos pos, Player player, BlockHitResult hit) {
        if (level.isClientSide) {
            return net.minecraft.world.InteractionResult.SUCCESS;
        }
        if (!player.isShiftKeyDown() && player instanceof net.minecraft.server.level.ServerPlayer serverPlayer) {
            base(level, pos).ifPresent(thaumatorium -> net.minecraftforge.network.NetworkHooks.openScreen((net.minecraft.server.level.ServerPlayer) (serverPlayer), (net.minecraft.world.MenuProvider) (thaumatorium), (java.util.function.Consumer<net.minecraft.network.FriendlyByteBuf>) (buffer -> buffer.writeBlockPos(pos.below()))));
        }
        return net.minecraft.world.InteractionResult.CONSUME;
    }

    @Override
    public void neighborChanged(BlockState state, Level level, BlockPos pos, Block neighborBlock, BlockPos neighborPos, boolean movedByPiston) {
        super.neighborChanged(state, level, pos, neighborBlock, neighborPos, movedByPiston);
        if (level.isClientSide) {
            return;
        }
        Optional<ThaumatoriumBlockEntity> base = base(level, pos);
        if (base.isPresent()) {
            base.get().recountUpgrades();
        } else if (level.getBlockState(pos).is(TCBlocks.THAUMATORIUM_TOP.get())) {
            level.setBlock(pos, TCBlocks.ALCHEMICAL_CONSTRUCT.get().defaultBlockState(), Block.UPDATE_ALL);
        }
    }

    private static Optional<ThaumatoriumBlockEntity> base(Level level, BlockPos top) {
        return level.getBlockEntity(top.below()) instanceof ThaumatoriumBlockEntity thaumatorium ? Optional.of(thaumatorium) : Optional.empty();
    }

    private ThaumatoriumTopBlock(net.minecraft.world.level.block.state.BlockBehaviour.Properties native$NativeEntityBlock$arg0, BlockBehaviour.Properties properties, boolean native$NativeEntityBlock$captured) {
        super(native$NativeEntityBlock$arg0);
        this.registerDefaultState(this.stateDefinition.any().setValue(FACING, Direction.NORTH));
    }

    @Override
    public void initializeClient(java.util.function.Consumer<net.minecraftforge.client.extensions.common.IClientBlockExtensions> installer) {
        platform$clientInstaller = installer;
        super.initializeClient(installer);
    }

    @Override
    public void platform$clientExtension(Object extension) {
        java.util.Objects.requireNonNull(platform$clientInstaller, "Forge initializeClient must run before client extension registration").accept((net.minecraftforge.client.extensions.common.IClientBlockExtensions) extension);
    }

    @Override
    public InteractionResult use(BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
        ItemUseResult result = (switch(0) {
            default ->
                {
                    net.minecraft.world.item.ItemStack native$bodyOperand$4764 = player.getItemInHand(hand);
                    net.minecraft.world.level.block.state.BlockState native$bodyOperand$4765 = state;
                    net.minecraft.world.level.Level native$bodyOperand$4766 = level;
                    net.minecraft.core.BlockPos native$bodyOperand$4767 = pos;
                    net.minecraft.world.entity.player.Player native$bodyOperand$4768 = player;
                    net.minecraft.world.InteractionHand native$bodyOperand$4769 = hand;
                    net.minecraft.world.phys.BlockHitResult native$bodyOperand$4770 = hit;
                    dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult native$bodyResult$4771 = null;
                    native$bodyReturn$4772: {
                        if (true) {
                            {
                                native$bodyResult$4771 = dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
                                break native$bodyReturn$4772;
                            }
                        }
                    }
                    yield native$bodyResult$4771;
                }
        });
        return result == ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION ? (hand == InteractionHand.MAIN_HAND ? (switch(0) {
            default ->
                {
                    net.minecraft.world.level.block.state.BlockState native$bodyOperand$3892 = state;
                    net.minecraft.world.level.Level native$bodyOperand$3893 = level;
                    net.minecraft.core.BlockPos native$bodyOperand$3894 = pos;
                    net.minecraft.world.entity.player.Player native$bodyOperand$3895 = player;
                    net.minecraft.world.phys.BlockHitResult native$bodyOperand$3896 = hit;
                    net.minecraft.world.InteractionResult native$bodyResult$3900 = null;
                    native$bodyReturn$3901: {
                        if (true) {
                            if (native$bodyOperand$3893.isClientSide) {
                                {
                                    native$bodyResult$3900 = net.minecraft.world.InteractionResult.SUCCESS;
                                    break native$bodyReturn$3901;
                                }
                            }
                            if (!native$bodyOperand$3895.isShiftKeyDown() && native$bodyOperand$3895 instanceof net.minecraft.server.level.ServerPlayer native$bodyBinding$3897) {
                                base(native$bodyOperand$3893, native$bodyOperand$3894).ifPresent(native$bodyBinding$3898 -> net.minecraftforge.network.NetworkHooks.openScreen((net.minecraft.server.level.ServerPlayer) (native$bodyBinding$3897), (net.minecraft.world.MenuProvider) (native$bodyBinding$3898), (java.util.function.Consumer<net.minecraft.network.FriendlyByteBuf>) (native$bodyBinding$3899 -> native$bodyBinding$3899.writeBlockPos(native$bodyOperand$3894.below()))));
                            }
                            {
                                native$bodyResult$3900 = net.minecraft.world.InteractionResult.CONSUME;
                                break native$bodyReturn$3901;
                            }
                        }
                    }
                    yield native$bodyResult$3900;
                }
        }) : InteractionResult.PASS) : result.result();
    }

    protected ItemUseResult interactWithItem(ItemStack stack, BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
        return dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
    }

    @Override
    public void playerWillDestroy(Level level, BlockPos pos, BlockState state, Player player) {
        {
            net.minecraft.world.level.Level native$bodyOperand$6028 = level;
            net.minecraft.core.BlockPos native$bodyOperand$6029 = pos;
            net.minecraft.world.level.block.state.BlockState native$bodyOperand$6030 = state;
            net.minecraft.world.entity.player.Player native$bodyOperand$6031 = player;
            net.minecraft.world.level.block.state.BlockState native$bodyResult$6032 = null;
            native$bodyReturn$6033: {
                if (true) {
                    super.playerWillDestroy(native$bodyOperand$6028, native$bodyOperand$6029, native$bodyOperand$6030, native$bodyOperand$6031);
                    {
                        native$bodyResult$6032 = native$bodyOperand$6030;
                        break native$bodyReturn$6033;
                    }
                }
            }
        }
    }

    public BlockState beforePlayerDestroy(Level level, BlockPos pos, BlockState state, Player player) {
        super.playerWillDestroy(level, pos, state, player);
        return state;
    }

    protected boolean survivesSharedExplosion() {
        return false;
    }

    public int getExpDrop(net.minecraft.world.level.block.state.BlockState native$callbackInput$1050, net.minecraft.world.level.LevelReader native$callbackInput$1051, net.minecraft.util.RandomSource native$callbackInput$1052, net.minecraft.core.BlockPos native$callbackInput$1053, int native$callbackInput$1054, int native$callbackInput$1055) {
        net.minecraft.world.level.block.state.BlockState state = native$callbackInput$1050;
        net.minecraft.util.RandomSource random = native$callbackInput$1052;
        return 0;
    }

    @Override
    public void onBlockExploded(BlockState state, Level level, BlockPos pos, Explosion explosion) {
        if (!(switch(0) {
            default ->
                {
                    boolean native$bodyResult$5325 = false;
                    native$bodyReturn$5326: {
                        if (true) {
                            {
                                native$bodyResult$5325 = false;
                                break native$bodyReturn$5326;
                            }
                        }
                    }
                    yield native$bodyResult$5325;
                }
        }))
            super.onBlockExploded(state, level, pos, explosion);
    }

    @Override
    public boolean canDropFromExplosion(BlockState state, BlockGetter level, BlockPos pos, Explosion explosion) {
        return !(switch(0) {
            default ->
                {
                    boolean native$bodyResult$4773 = false;
                    native$bodyReturn$4774: {
                        if (true) {
                            {
                                native$bodyResult$4773 = false;
                                break native$bodyReturn$4774;
                            }
                        }
                    }
                    yield native$bodyResult$4773;
                }
        }) && super.canDropFromExplosion(state, level, pos, explosion);
    }

    static private <B extends net.minecraft.world.level.block.Block> com.mojang.serialization.MapCodec<B> native$BlockCodecPlatform$simple(java.util.function.Function<net.minecraft.world.level.block.state.BlockBehaviour.Properties, B> factory) {
        // Vanilla 1.21's Properties codec is a unit codec. Retain that schema for shared block definitions.
        return com.mojang.serialization.codecs.RecordCodecBuilder.mapCodec(instance -> instance.group(com.mojang.serialization.Codec.unit(net.minecraft.world.level.block.state.BlockBehaviour.Properties::of).fieldOf("properties").forGetter((B block) -> net.minecraft.world.level.block.state.BlockBehaviour.Properties.copy(block))).apply(instance, factory));
    }
}
