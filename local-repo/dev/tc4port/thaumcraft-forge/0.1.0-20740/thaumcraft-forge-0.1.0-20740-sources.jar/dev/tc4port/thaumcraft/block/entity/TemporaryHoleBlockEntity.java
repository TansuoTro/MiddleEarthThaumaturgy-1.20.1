package dev.tc4port.thaumcraft.block.entity;

import dev.tc4port.thaumcraft.nativeimpl.RelocationBlocks;
import dev.tc4port.thaumcraft.client.InfusionSparkleEffects;
import dev.tc4port.thaumcraft.common.PortableHoleBlacklist;
import dev.tc4port.thaumcraft.common.PortableHoleRestorationQueue;
import dev.tc4port.thaumcraft.network.BlockSparklePayload;
import dev.tc4port.thaumcraft.registry.TCBlockEntities;
import dev.tc4port.thaumcraft.registry.TCBlocks;
import dev.tc4port.thaumcraft.registry.TCParticles;
import java.util.UUID;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.NbtOps;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;
import java.lang.Math;
import dev.tc4port.thaumcraft.nativeimpl.state.ItemFields;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityType;

/**
 * Stores the exact modern BlockState displaced by a portable hole.
 *
 * <p>Like TC4's TileHole, blocks with block entities are rejected before this
 * object is created, so no inventory or machine NBT can be lost.</p>
 */
public final class TemporaryHoleBlockEntity extends net.minecraft.world.level.block.entity.BlockEntity implements ItemFields.Source {

    // A temporary proxy must not alter adjacent connections or remove supported
    // blocks before their original states can be saved or restored.
    private static final int SWAP_FLAGS = Block.UPDATE_CLIENTS | Block.UPDATE_KNOWN_SHAPE;

    private BlockState originalState = net.minecraft.world.level.block.Blocks.STONE.defaultBlockState();

    private int remainingTicks = 120;

    private int propagationCount;

    private Direction propagationDirection;

    private boolean propagated;

    private boolean abandoned;

    private int clientAge;

    public TemporaryHoleBlockEntity(BlockPos pos, BlockState state) {
        super(TCBlockEntities.TEMPORARY_HOLE.get(), pos, state);
    }

    private void initialize(BlockState originalState, int remainingTicks, int propagationCount, Direction propagationDirection) {
        this.originalState = originalState;
        this.remainingTicks = Math.max(1, remainingTicks);
        this.propagationCount = Math.max(0, propagationCount);
        this.propagationDirection = propagationDirection;
        this.propagated = false;
        this.setChanged();
    }

    public static void serverTick(Level level, BlockPos pos, BlockState state, TemporaryHoleBlockEntity hole) {
        if (hole.abandoned || !(level instanceof ServerLevel serverLevel) || level.getBlockEntity(pos) != hole || !level.getBlockState(pos).is(TCBlocks.TEMPORARY_HOLE.get()))
            return;
        PortableHoleRestorationQueue restorations = PortableHoleRestorationQueue.get(serverLevel);
        UUID tunnelId = restorations.tunnelFor(pos);
        if (!hole.propagated) {
            hole.propagated = true;
            hole.propagate(level, pos, tunnelId);
        }
        // Child callbacks can synchronously replace their parent, too.
        if (level.getBlockEntity(pos) != hole || !level.getBlockState(pos).is(TCBlocks.TEMPORARY_HOLE.get()))
            return;
        if (--hole.remainingTicks > 0) {
            if (hole.remainingTicks % 20 == 0) {
                hole.setChanged();
            }
            return;
        }
        var change = new RelocationBlocks.Change(serverLevel, pos, SWAP_FLAGS);
        try {
            change.replace(hole.originalState, null);
            change.verify();
            restorations.restored(tunnelId, pos);
        } catch (RuntimeException failure) {
            abandon(serverLevel, pos, change, hole, "restoration", failure);
            restorations.abandoned(tunnelId, pos);
            return;
        }
        level.scheduleTick(pos, hole.originalState.getBlock(), 2);
        var originalFluid = hole.originalState.getFluidState();
        if (!originalFluid.isEmpty()) {
            level.scheduleTick(pos, originalFluid.getType(), 2);
        }
    }

    public static void clientTick(Level level, BlockPos pos, BlockState state, TemporaryHoleBlockEntity hole) {
        hole.surroundWithSparkles(level, pos);
        hole.clientAge++;
        if (hole.clientAge == hole.remainingTicks) {
            InfusionSparkleEffects.blockSparkle(level, pos, 0x400040, 1);
        }
    }

    /**
     * Exact 24 edge tests from TileHole.surroundwithsparkles.
     */
    private void surroundWithSparkles(Level level, BlockPos pos) {
        boolean yp = opaque(level, pos.above());
        boolean xp = opaque(level, pos.east());
        boolean zp = opaque(level, pos.south());
        boolean yn = opaque(level, pos.below());
        boolean xn = opaque(level, pos.west());
        boolean zn = opaque(level, pos.north());
        boolean b1 = notHole(level, pos.above());
        boolean b2 = notHole(level, pos.below());
        boolean b3 = notHole(level, pos.north());
        boolean b4 = notHole(level, pos.south());
        boolean b5 = notHole(level, pos.west());
        boolean b6 = notHole(level, pos.east());
        if (!xp && yp && b6)
            sparkle(level, pos.getX() + 1, pos.getY() + 1, pos.getZ() + level.random.nextFloat());
        if (!xn && yp && b5)
            sparkle(level, pos.getX(), pos.getY() + 1, pos.getZ() + level.random.nextFloat());
        if (!zp && yp && b4)
            sparkle(level, pos.getX() + level.random.nextFloat(), pos.getY() + 1, pos.getZ() + 1);
        if (!zn && yp && b3)
            sparkle(level, pos.getX() + level.random.nextFloat(), pos.getY() + 1, pos.getZ());
        if (!xp && yn && b6)
            sparkle(level, pos.getX() + 1, pos.getY(), pos.getZ() + level.random.nextFloat());
        if (!xn && yn && b5)
            sparkle(level, pos.getX(), pos.getY(), pos.getZ() + level.random.nextFloat());
        if (!zp && yn && b4)
            sparkle(level, pos.getX() + level.random.nextFloat(), pos.getY(), pos.getZ() + 1);
        if (!zn && yn && b3)
            sparkle(level, pos.getX() + level.random.nextFloat(), pos.getY(), pos.getZ());
        if (!yp && xp && b1)
            sparkle(level, pos.getX() + 1, pos.getY() + 1, pos.getZ() + level.random.nextFloat());
        if (!yn && xp && b2)
            sparkle(level, pos.getX() + 1, pos.getY(), pos.getZ() + level.random.nextFloat());
        if (!zp && xp && b4)
            sparkle(level, pos.getX() + 1, pos.getY() + level.random.nextFloat(), pos.getZ() + 1);
        if (!zn && xp && b3)
            sparkle(level, pos.getX() + 1, pos.getY() + level.random.nextFloat(), pos.getZ());
        if (!yp && xn && b1)
            sparkle(level, pos.getX(), pos.getY() + 1, pos.getZ() + level.random.nextFloat());
        if (!yn && xn && b2)
            sparkle(level, pos.getX(), pos.getY(), pos.getZ() + level.random.nextFloat());
        if (!zp && xn && b4)
            sparkle(level, pos.getX(), pos.getY() + level.random.nextFloat(), pos.getZ() + 1);
        if (!zn && xn && b3)
            sparkle(level, pos.getX(), pos.getY() + level.random.nextFloat(), pos.getZ());
        if (!xp && zp && b6)
            sparkle(level, pos.getX() + 1, pos.getY() + level.random.nextFloat(), pos.getZ() + 1);
        if (!xn && zp && b5)
            sparkle(level, pos.getX(), pos.getY() + level.random.nextFloat(), pos.getZ() + 1);
        if (!yp && zp && b1)
            sparkle(level, pos.getX() + level.random.nextFloat(), pos.getY() + 1, pos.getZ() + 1);
        if (!yn && zp && b2)
            sparkle(level, pos.getX() + level.random.nextFloat(), pos.getY(), pos.getZ() + 1);
        if (!xp && zn && b6)
            sparkle(level, pos.getX() + 1, pos.getY() + level.random.nextFloat(), pos.getZ());
        if (!xn && zn && b5)
            sparkle(level, pos.getX(), pos.getY() + level.random.nextFloat(), pos.getZ());
        if (!yp && zn && b1)
            sparkle(level, pos.getX() + level.random.nextFloat(), pos.getY() + 1, pos.getZ());
        if (!yn && zn && b2)
            sparkle(level, pos.getX() + level.random.nextFloat(), pos.getY(), pos.getZ());
    }

    private static boolean opaque(Level level, BlockPos pos) {
        return level.getBlockState(pos).canOcclude();
    }

    private static boolean notHole(Level level, BlockPos pos) {
        return !level.getBlockState(pos).is(TCBlocks.TEMPORARY_HOLE.get());
    }

    private static void sparkle(Level level, double x, double y, double z) {
        if (level.random.nextInt(6) >= InfusionSparkleEffects.particleCount(2)) {
            return;
        }
        level.addParticle(TCParticles.TEMPORARY_HOLE_SPARKLE.get(), x, y, z, 0.0, 0.0, 0.0);
    }

    private void propagate(Level level, BlockPos pos, UUID tunnelId) {
        if (this.propagationCount <= 1 || this.propagationDirection == null) {
            return;
        }
        Direction.Axis axis = this.propagationDirection.getAxis();
        for (int first = -1; first <= 1; first++) {
            for (int second = -1; second <= 1; second++) {
                if (first == 0 && second == 0) {
                    continue;
                }
                BlockPos around = switch(axis) {
                    case Y ->
                        pos.offset(first, 0, second);
                    case Z ->
                        pos.offset(first, second, 0);
                    case X ->
                        pos.offset(0, first, second);
                };
                createHole(level, around, null, 1, this.remainingTicks, tunnelId);
            }
        }
        if (!createHole(level, pos.relative(this.propagationDirection), this.propagationDirection, this.propagationCount - 1, this.remainingTicks, tunnelId)) {
            this.propagationCount = 0;
        }
    }

    public static boolean createHole(Level level, BlockPos pos, Direction propagationDirection, int propagationCount, int duration) {
        return createHole(level, pos, propagationDirection, propagationCount, duration, UUID.randomUUID());
    }

    private static boolean createHole(Level level, BlockPos pos, Direction propagationDirection, int propagationCount, int duration, UUID tunnelId) {
        if (!(level instanceof ServerLevel serverLevel) || !level.isLoaded(pos))
            return false;
        PortableHoleRestorationQueue restorations = PortableHoleRestorationQueue.get(serverLevel);
        BlockState original = level.getBlockState(pos);
        if (original.isAir() || original.is(TCBlocks.TEMPORARY_HOLE.get()) || PortableHoleBlacklist.contains(original) || original.hasBlockEntity() || level.getBlockEntity(pos) != null || original.getDestroySpeed(level, pos) < 0.0F) {
            return false;
        }
        var holeState = TCBlocks.TEMPORARY_HOLE.get().defaultBlockState();
        TemporaryHoleBlockEntity hole = new TemporaryHoleBlockEntity(pos, holeState);
        hole.initialize(original, duration, propagationCount, propagationDirection);
        var change = new RelocationBlocks.Change(serverLevel, pos, SWAP_FLAGS);
        try {
            change.replace(holeState, hole);
            change.verify();
            restorations.opened(tunnelId, pos);
        } catch (RuntimeException failure) {
            abandon(serverLevel, pos, change, hole, "opening", failure);
            restorations.abandoned(tunnelId, pos);
            return false;
        }
        BlockSparklePayload payload = new BlockSparklePayload(pos, 0x400040, 1);
        Vec3 center = Vec3.atCenterOf(pos);
        for (ServerPlayer player : serverLevel.players()) {
            if (player.distanceToSqr(center) <= 32.0 * 32.0) {
                dev.tc4port.thaumcraft.network.TCPayloads.CHANNEL.sendToPlayer(player, payload);
            }
        }
        return true;
    }

    private static void abandon(ServerLevel level, BlockPos pos, RelocationBlocks.Change change, TemporaryHoleBlockEntity hole, String phase, RuntimeException failure) {
        // Discard the old original even if cleanup fails; it must never be replayed.
        hole.abandoned = true;
        hole.originalState = net.minecraft.world.level.block.Blocks.AIR.defaultBlockState();
        hole.propagated = true;
        hole.propagationCount = 0;
        hole.propagationDirection = null;
        hole.remainingTicks = 1;
        try {
            hole.setChanged();
            change.verify();
            if (!change.unchanged() || level.getBlockState(pos).is(TCBlocks.TEMPORARY_HOLE.get())) {
                change.replace(net.minecraft.world.level.block.Blocks.AIR.defaultBlockState(), null);
            }
        } catch (RuntimeException cleanupFailure) {
            if (cleanupFailure != failure)
                failure.addSuppressed(cleanupFailure);
        }
        dev.tc4port.thaumcraft.Thaumcraft.LOGGER.warn("Portable hole {} at {} in {} abandoned", phase, pos, level.dimension().location(), failure);
    }

    @Override
    public void load(CompoundTag tag) {
        super.load(tag);
        this.remainingTicks = Math.max(1, tag.getInt("Remaining"));
        this.propagationCount = tag.getInt("Count");
        int direction = tag.getByte("Direction");
        this.propagationDirection = direction < 0 ? null : Direction.from3DDataValue(direction);
        this.propagated = tag.getBoolean("Propagated");
        if (tag.contains("Original")) {
            BlockState.CODEC.parse(NbtOps.INSTANCE, tag.get("Original")).result().ifPresent(state -> this.originalState = state);
        }
    }

    @Override
    protected void saveAdditional(CompoundTag tag) {
        super.saveAdditional(tag);
        tag.putInt("Remaining", this.remainingTicks);
        tag.putInt("Count", this.propagationCount);
        tag.putByte("Direction", (byte) (this.propagationDirection == null ? -1 : this.propagationDirection.get3DDataValue()));
        tag.putBoolean("Propagated", this.propagated);
        BlockState.CODEC.encodeStart(NbtOps.INSTANCE, this.originalState).result().ifPresent(encoded -> tag.put("Original", encoded));
    }

    protected final HolderLookup.Provider persistenceRegistries() {
        if (level != null)
            return level.registryAccess();
        var server = net.minecraftforge.server.ServerLifecycleHooks.getCurrentServer();
        return server != null ? server.registryAccess() : net.minecraft.core.RegistryAccess.fromRegistryOfRegistries(net.minecraft.core.registries.BuiltInRegistries.REGISTRY);
    }

    protected static net.minecraft.network.chat.Component parseCustomNameSafe(String value, HolderLookup.Provider registries) {
        try {
            return net.minecraft.network.chat.Component.Serializer.fromJson(value);
        } catch (RuntimeException exception) {
            return null;
        }
    }

    protected void readItemFields(ItemFields.Input input) {
    }

    public void copyItemFields(ItemFields.Output output) {
    }

    public void applyComponentsFromItemStack(ItemStack stack) {
        readItemFields(ItemFields.from(stack));
    }

    public void removeComponentsFromTag(CompoundTag tag) {
    }

    @Override
    public void saveToItem(ItemStack stack) {
        CompoundTag tag = saveWithoutMetadata();
        {
            net.minecraft.nbt.CompoundTag native$bodyOperand$6220 = tag;
            native$bodyReturn$6222: {
                if (true) {
                }
            }
        }
        net.minecraft.world.item.BlockItem.setBlockEntityData(stack, getType(), tag);
        copyItemFields(ItemFields.to(stack));
    }

    @Override
    public net.minecraft.world.phys.AABB getRenderBoundingBox() {
        return TemporaryHoleBlockEntity.native$ClientBlockEntityBounds$bounds(this);
    }

    @Override()
    public void onDataPacket(net.minecraft.network.Connection connection, net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket packet) {
        handleUpdateTag(packet.getTag());
    }

    @SuppressWarnings({ "rawtypes", "unchecked" })
    static private net.minecraft.world.phys.AABB native$ClientBlockEntityBounds$bounds(net.minecraft.world.level.block.entity.BlockEntity blockEntity) {
        var renderer = net.minecraft.client.Minecraft.getInstance().getBlockEntityRenderDispatcher().getRenderer(blockEntity);
        return renderer instanceof dev.tc4port.thaumcraft.nativeimpl.NativeBlockEntityRenderer shared ? shared.getRenderBoundingBox(blockEntity) : new net.minecraft.world.phys.AABB(blockEntity.getBlockPos());
    }
}
