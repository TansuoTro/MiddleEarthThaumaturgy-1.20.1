package dev.tc4port.thaumcraft.api.recipe;

import dev.tc4port.thaumcraft.api.research.ResearchKey;
import dev.tc4port.thaumcraft.api.research.ResearchRequirement;
import dev.tc4port.thaumcraft.api.aspect.VisChannel;
import java.util.Map;
import java.util.List;
import dev.tc4port.thaumcraft.api.recipe.NativeRecipeIds;
import dev.tc4port.thaumcraft.api.recipe.RecipeInputView;
import net.minecraft.core.HolderLookup;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.crafting.Recipe;

/**
 * Common contract for TC4 shaped and shapeless arcane recipes.
 *
 * <p>Research and vis are worktable concerns rather than vanilla recipe
 * matching concerns because the modern Recipe API has no player context.</p>
 *
 * <p>This is an independent recipe type. Sharing a crafting grid with vanilla
 * crafting does not make arcane recipes eligible for ordinary automation.</p>
 */
public interface ArcaneCraftingRecipe extends net.minecraft.world.item.crafting.Recipe<net.minecraft.world.inventory.CraftingContainer> {

    ResearchRequirement research();

    /**
     * Whole-vis values as declared by ConfigRecipes. WandVis converts these to
     * centivis and applies the current wand/player modifiers.
     */
    Map<VisChannel, Integer> vis();

    default Map<VisChannel, Integer> vis(net.minecraft.world.inventory.CraftingContainer input) {
        return vis();
    }

    default List<ResearchKey> requiredResearch(net.minecraft.world.inventory.CraftingContainer input) {
        return research().key().stream().toList();
    }

    @Override
    default net.minecraft.resources.ResourceLocation getId() {
        return dev.tc4port.thaumcraft.api.recipe.NativeRecipeIds.id(this);
    }
}
