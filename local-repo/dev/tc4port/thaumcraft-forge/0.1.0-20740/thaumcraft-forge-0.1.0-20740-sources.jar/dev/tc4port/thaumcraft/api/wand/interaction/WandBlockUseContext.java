package dev.tc4port.thaumcraft.api.wand.interaction;

import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.BlockHitResult;

/**
 * One logical side's block-owned wand use. The wand is the live stack.
 * {@code useTicks} counts this block session, starting at zero, independently
 * of any focus use that preceded it. Stop receives the last valid hit and the
 * original level; the target may already have disappeared.
 */
public record WandBlockUseContext(Level level, Player player, InteractionHand hand, ItemStack wand, BlockHitResult hit, int useTicks) {
}
