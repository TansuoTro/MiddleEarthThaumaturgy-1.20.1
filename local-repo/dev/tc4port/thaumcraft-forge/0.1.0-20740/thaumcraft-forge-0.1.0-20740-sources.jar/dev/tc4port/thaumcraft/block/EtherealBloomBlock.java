package dev.tc4port.thaumcraft.block;

import com.mojang.serialization.MapCodec;
import dev.tc4port.thaumcraft.block.entity.EtherealBloomBlockEntity;
import dev.tc4port.thaumcraft.registry.TCBlockEntities;
import javax.annotation.Nullable;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.EntityBlock;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityTicker;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;

public final class EtherealBloomBlock extends TCPlantBlock implements EntityBlock {

    public static final MapCodec<EtherealBloomBlock> CODEC = EtherealBloomBlock.native$BlockCodecPlatform$simple(EtherealBloomBlock::new);

    public EtherealBloomBlock(BlockBehaviour.Properties properties) {
        super(properties);
    }

    protected MapCodec<? extends EtherealBloomBlock> codec() {
        return CODEC;
    }

    @Override
    protected boolean mayPlaceOn(BlockState state, BlockGetter level, BlockPos pos) {
        return super.mayPlaceOn(state, level, pos) || state.isFaceSturdy(level, pos, Direction.UP);
    }

    @Nullable
    @Override
    public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        return new EtherealBloomBlockEntity(pos, state);
    }

    @Nullable
    @Override
    public <T extends BlockEntity> BlockEntityTicker<T> getTicker(Level level, BlockState state, BlockEntityType<T> type) {
        if (type != TCBlockEntities.ETHEREAL_BLOOM.get()) {
            return null;
        }
        return (tickerLevel, pos, tickerState, blockEntity) -> EtherealBloomBlockEntity.tick(tickerLevel, pos, tickerState, (EtherealBloomBlockEntity) blockEntity);
    }

    static private <B extends net.minecraft.world.level.block.Block> com.mojang.serialization.MapCodec<B> native$BlockCodecPlatform$simple(java.util.function.Function<net.minecraft.world.level.block.state.BlockBehaviour.Properties, B> factory) {
        // Vanilla 1.21's Properties codec is a unit codec. Retain that schema for shared block definitions.
        return com.mojang.serialization.codecs.RecordCodecBuilder.mapCodec(instance -> instance.group(com.mojang.serialization.Codec.unit(net.minecraft.world.level.block.state.BlockBehaviour.Properties::of).fieldOf("properties").forGetter((B block) -> net.minecraft.world.level.block.state.BlockBehaviour.Properties.copy(block))).apply(instance, factory));
    }
}
