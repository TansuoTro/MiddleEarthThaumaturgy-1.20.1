package dev.tc4port.thaumcraft.api.node;

/**
 * Result of a loaded-position aura-node compare-and-set operation.
 */
public enum NodeStateChangeResult {

    OFF_SERVER_THREAD,
    DUPLICATE_POSITION,
    CHUNK_UNLOADED,
    NOT_A_MUTABLE_NODE,
    NOT_AN_ORDINARY_NODE,
    STALE_EXPECTED_STATE,
    IDENTITY_CHANGE_DENIED,
    UNCHANGED,
    WOULD_REPLACE,
    REPLACED;

    public boolean successful() {
        return this == UNCHANGED || this == WOULD_REPLACE || this == REPLACED;
    }

    public boolean changed() {
        return this == REPLACED;
    }
}
