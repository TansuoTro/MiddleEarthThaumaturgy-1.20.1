package dev.tc4port.thaumcraft.block;

import dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult;
import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import dev.tc4port.thaumcraft.api.ThaumcraftApiHelper;
import dev.tc4port.thaumcraft.api.aspect.VisAction;
import dev.tc4port.thaumcraft.api.aspect.VisPaymentResult;
import dev.tc4port.thaumcraft.block.entity.EldritchAltarBlockEntity;
import dev.tc4port.thaumcraft.block.entity.AuraNodeBlockEntity;
import dev.tc4port.thaumcraft.block.entity.EldritchCapBlockEntity;
import dev.tc4port.thaumcraft.block.entity.EldritchObeliskBlockEntity;
import dev.tc4port.thaumcraft.api.node.NodeTypeId;
import dev.tc4port.thaumcraft.api.aspect.VisChannel;
import dev.tc4port.thaumcraft.common.PlayerKnowledgeService;
import dev.tc4port.thaumcraft.common.WandVis;
import dev.tc4port.thaumcraft.api.wand.WandCarrierItem;
import dev.tc4port.thaumcraft.registry.TCBlockEntities;
import dev.tc4port.thaumcraft.registry.TCBlocks;
import dev.tc4port.thaumcraft.registry.TCItems;
import dev.tc4port.thaumcraft.registry.TCSounds;
import javax.annotation.Nullable;
import java.util.Map;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.StringRepresentable;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityTicker;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;
import dev.tc4port.thaumcraft.nativeimpl.ClientExtensionTarget;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.level.pathfinder.PathComputationType;
import net.minecraft.world.phys.HitResult;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.Explosion;
import net.minecraft.world.level.BlockGetter;

/**
 * The block entity variants of TC4's eldritch structure block.
 */
public final class EldritchStructureBlock extends net.minecraft.world.level.block.BaseEntityBlock implements dev.tc4port.thaumcraft.nativeimpl.ClientExtensionTarget {

    // Forge calls initializeClient from the native superclass constructor. Do not add a field initializer.
    private java.util.function.Consumer<net.minecraftforge.client.extensions.common.IClientBlockExtensions> platform$clientInstaller;

    private static final Map<VisChannel, Integer> OCULUS_COST = Map.of(VisChannel.AER, 100, VisChannel.IGNIS, 100, VisChannel.TERRA, 100, VisChannel.AQUA, 100, VisChannel.ORDO, 100, VisChannel.PERDITIO, 100);

    public static final MapCodec<EldritchStructureBlock> CODEC = RecordCodecBuilder.mapCodec(instance -> instance.group(Kind.CODEC.fieldOf("kind").forGetter(EldritchStructureBlock::kind), EldritchStructureBlock.native$BlockCodecPlatform$properties()).apply(instance, EldritchStructureBlock::new));

    private final Kind kind;

    public EldritchStructureBlock(Kind kind, BlockBehaviour.Properties properties) {
        this(properties.noLootTable(), kind, properties, true);
    }

    public Kind kind() {
        return this.kind;
    }

    /**
     * WandManager#createOculus: four eyes plus a directly stacked dark node
     * become the Outer Lands portal after paying one hundred of every primal.
     */
    public static InteractionResult tryOpenOculus(UseOnContext context) {
        Player player = context.getPlayer();
        Level level = context.getLevel();
        BlockPos altarPos = context.getClickedPos();
        ItemStack wand = context.getItemInHand();
        if (player == null || !(wand.getItem() instanceof WandCarrierItem) || !(level.getBlockState(altarPos).getBlock() instanceof EldritchStructureBlock structure) || structure.kind != Kind.ALTAR) {
            return InteractionResult.PASS;
        }
        if (!PlayerKnowledgeService.get(player).hasCompletedResearch(dev.tc4port.thaumcraft.api.research.ResearchKey.parse("OCULUS")) || !(level.getBlockEntity(altarPos) instanceof EldritchAltarBlockEntity altar) || altar.eyes() != 4 || altar.open()) {
            return InteractionResult.FAIL;
        }
        BlockPos nodePos = altarPos.above();
        if (!(level.getBlockEntity(nodePos) instanceof AuraNodeBlockEntity node) || !node.nodeState().type().equals(NodeTypeId.DARK)) {
            return InteractionResult.FAIL;
        }
        Map<VisChannel, Integer> cost = WandVis.craftingCost(wand, player, OCULUS_COST);
        if (ThaumcraftApiHelper.consumeExactVisFromWand(wand, player, cost, VisAction.SIMULATE) != VisPaymentResult.AVAILABLE) {
            return InteractionResult.FAIL;
        }
        if (!level.isClientSide) {
            /*
             * The source checked/queued its maze before charging the wand.
             * Eye insertion normally generated it already, but retaining the
             * false result avoids opening an altar with no matching graph.
             */
            if (!altar.checkForMaze() || ThaumcraftApiHelper.consumeExactVisFromWand(wand, player, cost, VisAction.EXECUTE) != VisPaymentResult.CONSUMED) {
                return InteractionResult.FAIL;
            }
            level.playSound(null, altarPos, TCSounds.WAND.get(), SoundSource.BLOCKS, 1.0F, 1.0F);
            altar.setOpen(true);
            level.setBlock(nodePos, TCBlocks.byId("eldritch_portal").get().defaultBlockState(), 3);
        }
        player.swing(context.getHand());
        return InteractionResult.sidedSuccess(level.isClientSide);
    }

    protected MapCodec<EldritchStructureBlock> codec() {
        return CODEC;
    }

    @Nullable
    @Override
    public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        return switch(this.kind) {
            case ALTAR ->
                new EldritchAltarBlockEntity(pos, state);
            case OBELISK ->
                new EldritchObeliskBlockEntity(pos, state);
            case CAPSTONE ->
                new EldritchCapBlockEntity(pos, state);
        };
    }

    @Nullable
    @Override
    public <T extends BlockEntity> BlockEntityTicker<T> getTicker(Level level, BlockState state, BlockEntityType<T> type) {
        if (level.isClientSide) {
            return this.kind == Kind.OBELISK ? createTickerHelper(type, TCBlockEntities.ELDRITCH_OBELISK.get(), EldritchObeliskBlockEntity::clientTick) : null;
        }
        return switch(this.kind) {
            case ALTAR ->
                createTickerHelper(type, TCBlockEntities.ELDRITCH_ALTAR.get(), EldritchAltarBlockEntity::serverTick);
            case OBELISK ->
                createTickerHelper(type, TCBlockEntities.ELDRITCH_OBELISK.get(), EldritchObeliskBlockEntity::serverTick);
            case CAPSTONE ->
                null;
        };
    }

    @Override
    public RenderShape getRenderShape(BlockState state) {
        // The obelisk retains its animated renderer and invisible collision shell.
        return kind == Kind.CAPSTONE || kind == Kind.ALTAR ? RenderShape.MODEL : RenderShape.INVISIBLE;
    }

    protected ItemUseResult interactWithItem(ItemStack stack, BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
        if (this.kind != dev.tc4port.thaumcraft.block.EldritchStructureBlock.Kind.ALTAR || player.isShiftKeyDown() || !stack.is(dev.tc4port.thaumcraft.registry.TCItems.ELDRITCH_OBJECT.get()) || !(level.getBlockEntity(pos) instanceof dev.tc4port.thaumcraft.block.entity.EldritchAltarBlockEntity altar) || altar.eyes() >= 4) {
            return dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
        }
        if (!level.isClientSide) {
            altar.insertEye();
            stack.shrink(1);
            level.playSound(null, pos, dev.tc4port.thaumcraft.registry.TCSounds.CRYSTAL.get(), net.minecraft.sounds.SoundSource.BLOCKS, 0.2F, 1.0F);
        }
        player.swing(hand);
        return dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.sidedSuccess(level.isClientSide);
    }

    @Override
    public void onRemove(BlockState state, Level level, BlockPos pos, BlockState newState, boolean movedByPiston) {
        onStructureRemoved(state, level, pos, newState);
        super.onRemove(state, level, pos, newState, movedByPiston);
    }

    static void onStructureRemoved(BlockState state, Level level, BlockPos pos, BlockState newState) {
        if (!level.isClientSide && state.getBlock() != newState.getBlock()) {
            collapseNearbyStructure((ServerLevel) level, pos);
            level.explode(null, pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5, 1.0F, false, Level.ExplosionInteraction.BLOCK);
        }
    }

    private static void collapseNearbyStructure(ServerLevel level, BlockPos origin) {
        for (BlockPos target : BlockPos.betweenClosed(origin.offset(-3, -2, -3), origin.offset(3, 2, 3))) {
            if (isStructurePart(level.getBlockState(target))) {
                level.removeBlock(target, false);
            }
        }
    }

    static boolean isStructurePart(BlockState state) {
        return state.getBlock() instanceof EldritchStructureBlock || state.getBlock() instanceof EldritchObeliskSegmentBlock;
    }

    public enum Kind implements StringRepresentable {

        ALTAR("altar"), OBELISK("obelisk"), CAPSTONE("capstone");

        public static final Codec<Kind> CODEC = StringRepresentable.fromEnum(Kind::values);

        private final String serializedName;

        Kind(String serializedName) {
            this.serializedName = serializedName;
        }

        @Override
        public String getSerializedName() {
            return this.serializedName;
        }
    }

    private EldritchStructureBlock(net.minecraft.world.level.block.state.BlockBehaviour.Properties native$NativeEntityBlock$arg0, Kind kind, BlockBehaviour.Properties properties, boolean native$NativeEntityBlock$captured) {
        super(native$NativeEntityBlock$arg0);
        this.kind = kind;
    }

    @Override
    public void initializeClient(java.util.function.Consumer<net.minecraftforge.client.extensions.common.IClientBlockExtensions> installer) {
        platform$clientInstaller = installer;
        super.initializeClient(installer);
    }

    @Override
    public void platform$clientExtension(Object extension) {
        java.util.Objects.requireNonNull(platform$clientInstaller, "Forge initializeClient must run before client extension registration").accept((net.minecraftforge.client.extensions.common.IClientBlockExtensions) extension);
    }

    @Override
    public InteractionResult use(BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
        ItemUseResult result = (switch(0) {
            default ->
                {
                    net.minecraft.world.item.ItemStack native$bodyOperand$4388 = player.getItemInHand(hand);
                    net.minecraft.world.level.block.state.BlockState native$bodyOperand$4389 = state;
                    net.minecraft.world.level.Level native$bodyOperand$4390 = level;
                    net.minecraft.core.BlockPos native$bodyOperand$4391 = pos;
                    net.minecraft.world.entity.player.Player native$bodyOperand$4392 = player;
                    net.minecraft.world.InteractionHand native$bodyOperand$4393 = hand;
                    net.minecraft.world.phys.BlockHitResult native$bodyOperand$4394 = hit;
                    dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult native$bodyResult$4396 = null;
                    native$bodyReturn$4397: {
                        if (true) {
                            if (this.kind != dev.tc4port.thaumcraft.block.EldritchStructureBlock.Kind.ALTAR || native$bodyOperand$4392.isShiftKeyDown() || !native$bodyOperand$4388.is(dev.tc4port.thaumcraft.registry.TCItems.ELDRITCH_OBJECT.get()) || !(native$bodyOperand$4390.getBlockEntity(native$bodyOperand$4391) instanceof dev.tc4port.thaumcraft.block.entity.EldritchAltarBlockEntity native$bodyBinding$4395) || native$bodyBinding$4395.eyes() >= 4) {
                                {
                                    native$bodyResult$4396 = dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
                                    break native$bodyReturn$4397;
                                }
                            }
                            if (!native$bodyOperand$4390.isClientSide) {
                                native$bodyBinding$4395.insertEye();
                                native$bodyOperand$4388.shrink(1);
                                native$bodyOperand$4390.playSound(null, native$bodyOperand$4391, dev.tc4port.thaumcraft.registry.TCSounds.CRYSTAL.get(), net.minecraft.sounds.SoundSource.BLOCKS, 0.2F, 1.0F);
                            }
                            native$bodyOperand$4392.swing(native$bodyOperand$4393);
                            {
                                native$bodyResult$4396 = dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.sidedSuccess(native$bodyOperand$4390.isClientSide);
                                break native$bodyReturn$4397;
                            }
                        }
                    }
                    yield native$bodyResult$4396;
                }
        });
        return result == ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION ? (hand == InteractionHand.MAIN_HAND ? (switch(0) {
            default ->
                {
                    net.minecraft.world.level.block.state.BlockState native$bodyOperand$3645 = state;
                    net.minecraft.world.level.Level native$bodyOperand$3646 = level;
                    net.minecraft.core.BlockPos native$bodyOperand$3647 = pos;
                    net.minecraft.world.entity.player.Player native$bodyOperand$3648 = player;
                    net.minecraft.world.phys.BlockHitResult native$bodyOperand$3649 = hit;
                    net.minecraft.world.InteractionResult native$bodyResult$3650 = null;
                    native$bodyReturn$3651: {
                        if (true) {
                            {
                                native$bodyResult$3650 = super.use(native$bodyOperand$3645, native$bodyOperand$3646, native$bodyOperand$3647, native$bodyOperand$3648, net.minecraft.world.InteractionHand.MAIN_HAND, native$bodyOperand$3649);
                                break native$bodyReturn$3651;
                            }
                        }
                    }
                    yield native$bodyResult$3650;
                }
        }) : InteractionResult.PASS) : result.result();
    }

    protected InteractionResult interactWithoutItem(BlockState state, Level level, BlockPos pos, Player player, BlockHitResult hit) {
        return super.use(state, level, pos, player, net.minecraft.world.InteractionHand.MAIN_HAND, hit);
    }

    @Override
    public void playerWillDestroy(Level level, BlockPos pos, BlockState state, Player player) {
        {
            net.minecraft.world.level.Level native$bodyOperand$5817 = level;
            net.minecraft.core.BlockPos native$bodyOperand$5818 = pos;
            net.minecraft.world.level.block.state.BlockState native$bodyOperand$5819 = state;
            net.minecraft.world.entity.player.Player native$bodyOperand$5820 = player;
            net.minecraft.world.level.block.state.BlockState native$bodyResult$5821 = null;
            native$bodyReturn$5822: {
                if (true) {
                    super.playerWillDestroy(native$bodyOperand$5817, native$bodyOperand$5818, native$bodyOperand$5819, native$bodyOperand$5820);
                    {
                        native$bodyResult$5821 = native$bodyOperand$5819;
                        break native$bodyReturn$5822;
                    }
                }
            }
        }
    }

    public BlockState beforePlayerDestroy(Level level, BlockPos pos, BlockState state, Player player) {
        super.playerWillDestroy(level, pos, state, player);
        return state;
    }

    protected boolean survivesSharedExplosion() {
        return false;
    }

    public int getExpDrop(net.minecraft.world.level.block.state.BlockState native$callbackInput$1050, net.minecraft.world.level.LevelReader native$callbackInput$1051, net.minecraft.util.RandomSource native$callbackInput$1052, net.minecraft.core.BlockPos native$callbackInput$1053, int native$callbackInput$1054, int native$callbackInput$1055) {
        net.minecraft.world.level.block.state.BlockState state = native$callbackInput$1050;
        net.minecraft.util.RandomSource random = native$callbackInput$1052;
        return 0;
    }

    @Override
    public void onBlockExploded(BlockState state, Level level, BlockPos pos, Explosion explosion) {
        if (!(switch(0) {
            default ->
                {
                    boolean native$bodyResult$5259 = false;
                    native$bodyReturn$5260: {
                        if (true) {
                            {
                                native$bodyResult$5259 = false;
                                break native$bodyReturn$5260;
                            }
                        }
                    }
                    yield native$bodyResult$5259;
                }
        }))
            super.onBlockExploded(state, level, pos, explosion);
    }

    @Override
    public boolean canDropFromExplosion(BlockState state, BlockGetter level, BlockPos pos, Explosion explosion) {
        return !(switch(0) {
            default ->
                {
                    boolean native$bodyResult$4398 = false;
                    native$bodyReturn$4399: {
                        if (true) {
                            {
                                native$bodyResult$4398 = false;
                                break native$bodyReturn$4399;
                            }
                        }
                    }
                    yield native$bodyResult$4398;
                }
        }) && super.canDropFromExplosion(state, level, pos, explosion);
    }

    static private <B extends net.minecraft.world.level.block.Block> com.mojang.serialization.codecs.RecordCodecBuilder<B, net.minecraft.world.level.block.state.BlockBehaviour.Properties> native$BlockCodecPlatform$properties() {
        return com.mojang.serialization.Codec.unit(net.minecraft.world.level.block.state.BlockBehaviour.Properties::of).fieldOf("properties").forGetter(block -> net.minecraft.world.level.block.state.BlockBehaviour.Properties.copy(block));
    }
}
