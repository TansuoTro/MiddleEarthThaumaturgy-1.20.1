package dev.tc4port.thaumcraft.api.client;

import dev.tc4port.thaumcraft.api.research.ResearchCategoryKey;
import dev.tc4port.thaumcraft.api.research.ResearchKey;
import java.util.List;
import java.util.Optional;
import net.minecraft.client.gui.screens.Screen;

/**
 * Client-thread access to one open book. All visibility and navigation checks remain core-owned.
 * Outside the active book screen, or without a live player/world, queries return empty
 * and navigation returns false. The screen reference remains available for widget layout.
 */
public interface ThaumonomiconAccess {

    Screen screen();

    /**
     * Live geometry for addon controls; a reader keeps its original two-page layout.
     */
    ThaumonomiconLayout layout();

    /**
     * Set the tree panel in GUI coordinates. The caller owns sizing and placement policy.
     */
    void setTreeBounds(int left, int top, int width, int height);

    /**
     * Visible categories, in the book's native order.
     */
    List<ResearchCategoryKey> categories();

    /**
     * Replace tab placements for this book. Null restores the native arrangement.
     */
    void setCategoryTabs(List<ThaumonomiconTab> tabs);

    /**
     * Current visible reader pagination, or empty outside a readable entry.
     */
    Optional<ThaumonomiconReading> reading();

    /**
     * Open a valid, even-numbered visible reader page. Out-of-range requests return false.
     */
    boolean showSpread(int firstPage);

    Optional<ResearchCategoryKey> selectedCategory();

    /**
     * Current visible, non-virtual entries. Unread research never exposes recipe outputs.
     */
    List<ThaumonomiconEntry> entries();

    /**
     * A lightweight visibility snapshot can omit recipe-output resolution.
     */
    List<ThaumonomiconEntry> entries(boolean includeRecipeOutputs);

    /**
     * Navigate to a visible entry. Completed entries can open the reader; other entries
     * are centered on the tree without purchasing research. A negative sourcePage opens
     * the first spread; other values are definition-page indices from RecipeOutput.
     * Revalidates knowledge, category and page prerequisites at the moment of use.
     */
    boolean navigate(ResearchKey key, int sourcePage, boolean read);
}
