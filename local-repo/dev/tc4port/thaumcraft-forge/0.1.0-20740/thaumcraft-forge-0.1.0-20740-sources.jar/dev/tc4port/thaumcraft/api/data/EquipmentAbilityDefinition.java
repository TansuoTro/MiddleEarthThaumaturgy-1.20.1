package dev.tc4port.thaumcraft.api.data;

import com.mojang.serialization.Codec;
import com.mojang.serialization.DataResult;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import dev.tc4port.thaumcraft.api.aspect.VisChannel;
import dev.tc4port.thaumcraft.api.item.RunicGear;
import java.util.Collections;
import java.util.EnumMap;
import java.util.Map;
import java.util.Objects;

/**
 * Synced data-pack definition for gameplay abilities granted by an item.
 * Vis discounts are integer percentages; fall-distance reduction is an
 * absolute per-tick distance decrement rather than a ratio.
 */
public record EquipmentAbilityDefinition(int visDiscount, Map<VisChannel, Integer> aspectVisDiscounts, boolean gogglesOverlay, boolean auraRevealing, boolean infusionGogglesReveal, boolean runic, int runicCharge, RunicTrait runicTrait, float fallDistanceReduction, boolean hoverFuelEfficiency) {

    private static final Codec<RunicTrait> TRAIT_CODEC = Codec.STRING.comapFlatMap(RunicTrait::decode, RunicTrait::serialized);

    private static final Codec<Serialized> SERIALIZED_CODEC = RecordCodecBuilder.create(instance -> instance.group(EquipmentAbilityDefinition.native$StrictOptionalFields$of(Codec.INT, "vis_discount", 0).forGetter(Serialized::visDiscount), EquipmentAbilityDefinition.native$StrictOptionalFields$of(Codec.unboundedMap(VisChannel.CODEC, Codec.INT), "aspect_vis_discounts", Map.of()).forGetter(Serialized::aspectVisDiscounts), EquipmentAbilityDefinition.native$StrictOptionalFields$of(Codec.BOOL, "goggles_overlay", false).forGetter(Serialized::gogglesOverlay), EquipmentAbilityDefinition.native$StrictOptionalFields$of(Codec.BOOL, "aura_revealing", false).forGetter(Serialized::auraRevealing), EquipmentAbilityDefinition.native$StrictOptionalFields$of(Codec.BOOL, "infusion_goggles_reveal", false).forGetter(Serialized::infusionGogglesReveal), EquipmentAbilityDefinition.native$StrictOptionalFields$of(Codec.BOOL, "runic", false).forGetter(Serialized::runic), EquipmentAbilityDefinition.native$StrictOptionalFields$of(Codec.intRange(0, RunicGear.MAX_CHARGE), "runic_charge", 0).forGetter(Serialized::runicCharge), EquipmentAbilityDefinition.native$StrictOptionalFields$of(TRAIT_CODEC, "runic_trait", RunicTrait.NONE).forGetter(Serialized::runicTrait), EquipmentAbilityDefinition.native$StrictOptionalFields$of(Codec.FLOAT, "fall_distance_reduction", 0.0F).forGetter(Serialized::fallDistanceReduction), EquipmentAbilityDefinition.native$StrictOptionalFields$of(Codec.BOOL, "hover_fuel_efficiency", false).forGetter(Serialized::hoverFuelEfficiency)).apply(instance, Serialized::new));

    public static final Codec<EquipmentAbilityDefinition> CODEC = SERIALIZED_CODEC.comapFlatMap(EquipmentAbilityDefinition::decode, EquipmentAbilityDefinition::serialized);

    public EquipmentAbilityDefinition {
        if (visDiscount < 0 || !Float.isFinite(fallDistanceReduction) || fallDistanceReduction < 0.0F) {
            throw new IllegalArgumentException("Equipment ability values cannot be negative");
        }
        if (runicCharge < 0 || runicCharge > RunicGear.MAX_CHARGE) {
            throw new IllegalArgumentException("Runic charge must be between 0 and " + RunicGear.MAX_CHARGE);
        }
        EnumMap<VisChannel, Integer> canonical = new EnumMap<>(VisChannel.class);
        Objects.requireNonNull(aspectVisDiscounts, "aspectVisDiscounts").forEach((aspect, amount) -> {
            Objects.requireNonNull(aspect, "aspect channel");
            Objects.requireNonNull(amount, "aspect discount");
            if (amount < 0) {
                throw new IllegalArgumentException("Aspect vis discounts cannot be negative");
            }
            canonical.put(aspect, amount);
        });
        aspectVisDiscounts = Collections.unmodifiableMap(canonical);
        runicTrait = Objects.requireNonNull(runicTrait, "runicTrait");
        if (!runic && (runicCharge != 0 || runicTrait != RunicTrait.NONE)) {
            throw new IllegalArgumentException("Runic charge and traits require runic=true");
        }
    }

    public enum RunicTrait {

        NONE("none"), FASTER_RECHARGE("faster_recharge"), KINETIC("kinetic"), HEALING("healing"), EMERGENCY("emergency");

        private final String serialized;

        RunicTrait(String serialized) {
            this.serialized = serialized;
        }

        public String serialized() {
            return this.serialized;
        }

        private static RunicTrait fromSerialized(String value) {
            for (RunicTrait trait : values()) {
                if (trait.serialized.equals(value)) {
                    return trait;
                }
            }
            throw new IllegalArgumentException("Unknown runic trait " + value);
        }

        private static DataResult<RunicTrait> decode(String value) {
            try {
                return DataResult.success(fromSerialized(value));
            } catch (RuntimeException exception) {
                return DataResult.error(() -> "Invalid runic trait '" + value + "': " + exception.getMessage());
            }
        }
    }

    private static DataResult<EquipmentAbilityDefinition> decode(Serialized value) {
        try {
            return DataResult.success(new EquipmentAbilityDefinition(value.visDiscount(), value.aspectVisDiscounts(), value.gogglesOverlay(), value.auraRevealing(), value.infusionGogglesReveal(), value.runic(), value.runicCharge(), value.runicTrait(), value.fallDistanceReduction(), value.hoverFuelEfficiency()));
        } catch (RuntimeException exception) {
            return DataResult.error(() -> "Invalid equipment ability definition: " + exception.getMessage());
        }
    }

    private Serialized serialized() {
        return new Serialized(this.visDiscount, this.aspectVisDiscounts, this.gogglesOverlay, this.auraRevealing, this.infusionGogglesReveal, this.runic, this.runicCharge, this.runicTrait, this.fallDistanceReduction, this.hoverFuelEfficiency);
    }

    private record Serialized(int visDiscount, Map<VisChannel, Integer> aspectVisDiscounts, boolean gogglesOverlay, boolean auraRevealing, boolean infusionGogglesReveal, boolean runic, int runicCharge, RunicTrait runicTrait, float fallDistanceReduction, boolean hoverFuelEfficiency) {
    }

    static private <A> com.mojang.serialization.MapCodec<A> native$StrictOptionalFields$of(com.mojang.serialization.Codec<A> codec, java.lang.String name, A defaultValue) {
        return EquipmentAbilityDefinition.native$StrictOptionalFields$of(codec, name).xmap(value -> value.orElse(defaultValue), value -> java.util.Objects.equals(value, defaultValue) ? java.util.Optional.empty() : java.util.Optional.of(value));
    }

    static private <A> com.mojang.serialization.MapCodec<java.util.Optional<A>> native$StrictOptionalFields$of(com.mojang.serialization.Codec<A> codec, java.lang.String name) {
        java.util.Objects.requireNonNull(codec, "codec");
        java.util.Objects.requireNonNull(name, "name");
        return new com.mojang.serialization.MapCodec<>() {

            @Override
            public <T> com.mojang.serialization.DataResult<java.util.Optional<A>> decode(com.mojang.serialization.DynamicOps<T> ops, com.mojang.serialization.MapLike<T> input) {
                T value = input.get(name);
                return value == null ? com.mojang.serialization.DataResult.success(java.util.Optional.empty()) : codec.parse(ops, value).map(java.util.Optional::of);
            }

            @Override
            public <T> com.mojang.serialization.RecordBuilder<T> encode(java.util.Optional<A> input, com.mojang.serialization.DynamicOps<T> ops, com.mojang.serialization.RecordBuilder<T> prefix) {
                return input.isPresent() ? prefix.add(name, codec.encodeStart(ops, input.get())) : prefix;
            }

            @Override
            public <T> java.util.stream.Stream<T> keys(com.mojang.serialization.DynamicOps<T> ops) {
                return java.util.stream.Stream.of(ops.createString(name));
            }

            @Override
            public java.lang.String toString() {
                return "StrictOptionalField[" + name + ": " + codec + "]";
            }
        };
    }
}
