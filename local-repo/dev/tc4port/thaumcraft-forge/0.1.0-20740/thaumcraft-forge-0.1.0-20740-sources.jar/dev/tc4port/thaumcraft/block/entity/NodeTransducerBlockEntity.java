package dev.tc4port.thaumcraft.block.entity;

import net.minecraft.sounds.SoundSource;
import dev.tc4port.thaumcraft.registry.TCSounds;
import dev.tc4port.thaumcraft.common.TCGameplayParameters;
import dev.tc4port.thaumcraft.api.aspect.AspectId;
import dev.tc4port.thaumcraft.api.node.AuraNodeState;
import dev.tc4port.thaumcraft.api.node.NodeVis;
import dev.tc4port.thaumcraft.block.AuraNodeBlock;
import dev.tc4port.thaumcraft.registry.TCBlockEntities;
import dev.tc4port.thaumcraft.registry.TCBlocks;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.core.BlockPos;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;
import java.lang.Math;
import dev.tc4port.thaumcraft.nativeimpl.state.ItemFields;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityType;

/**
 * Complete TileNodeConverter state machine: gradual aspect drain, reversible
 * ordinary/energized conversion and the unsafe-structure failure.
 */
public final class NodeTransducerBlockEntity extends net.minecraft.world.level.block.entity.BlockEntity implements ItemFields.Source {

    public static final int STATUS_IDLE = 0;

    public static final int STATUS_CHARGING = 1;

    public static final int STATUS_ENERGIZED = 2;

    public static final int MAX_COUNT = 1_000;

    private static final int SAFE_COLLAPSE_COUNT = 50;

    private static final int CONVERSION_EVENT = 10;

    private int count = -1;

    private int status;

    private boolean statusCheckPending;

    public NodeTransducerBlockEntity(BlockPos pos, BlockState state) {
        super(TCBlockEntities.NODE_TRANSDUCER.get(), pos, state);
    }

    public int count() {
        return this.count;
    }

    public int status() {
        return this.status;
    }

    public float pistonExtension(float partialTick) {
        float interpolated = this.count;
        if (this.level != null) {
            boolean extending = this.status != STATUS_IDLE && this.level.hasNeighborSignal(this.worldPosition) && this.count < TCGameplayParameters.MACHINES_NODE_TRANSDUCER_CONVERSION_TICKS.intValue();
            boolean retracting = !extending && this.count > 0;
            if (extending) {
                interpolated += partialTick;
            } else if (retracting) {
                interpolated -= partialTick;
            }
        }
        return Math.min(50.0F, Math.max(0.0F, interpolated)) / 137.0F;
    }

    public static void serverTick(Level level, BlockPos pos, BlockState state, NodeTransducerBlockEntity transducer) {
        if (!(level instanceof ServerLevel serverLevel)) {
            return;
        }
        if (!level.hasChunksAt(pos.offset(-2, 0, -2), pos.offset(2, 0, 2))) {
            transducer.statusCheckPending = true;
            return;
        }
        if (transducer.count == -1 || transducer.statusCheckPending) {
            transducer.checkStatus();
        }
        if (transducer.status == STATUS_CHARGING && transducer.count >= TCGameplayParameters.MACHINES_NODE_TRANSDUCER_CONVERSION_TICKS.intValue()) {
            transducer.energizeNode(serverLevel);
        } else if (transducer.status == STATUS_ENERGIZED && transducer.count <= TCGameplayParameters.MACHINES_NODE_TRANSDUCER_SAFE_COLLAPSE_TICKS.intValue()) {
            transducer.deEnergizeNode(serverLevel);
        }
        if (transducer.status != STATUS_IDLE && level.hasNeighborSignal(pos)) {
            if (transducer.count < TCGameplayParameters.MACHINES_NODE_TRANSDUCER_CONVERSION_TICKS.intValue()) {
                transducer.count++;
                if (transducer.status == STATUS_CHARGING) {
                    transducer.drainRandomAspect(serverLevel);
                }
            }
        } else if (transducer.count > 0) {
            transducer.count--;
        }
        transducer.count = Math.min(TCGameplayParameters.MACHINES_NODE_TRANSDUCER_CONVERSION_TICKS.intValue(), transducer.count);
    }

    public static void clientTick(Level level, BlockPos pos, BlockState state, NodeTransducerBlockEntity transducer) {
        if (transducer.count == -1) {
            transducer.checkStatus();
        }
        boolean powered = level.hasNeighborSignal(pos);
        boolean spawnBolts = shouldSpawnClientBolts(transducer.status, transducer.count, powered);
        if (transducer.status != STATUS_IDLE && powered) {
            transducer.count = Math.min(TCGameplayParameters.MACHINES_NODE_TRANSDUCER_CONVERSION_TICKS.intValue(), transducer.count + 1);
        } else if (transducer.count > 0) {
            transducer.count--;
        }
        if (spawnBolts && level instanceof net.minecraft.client.multiplayer.ClientLevel clientLevel) {
            Vec3 node = Vec3.atCenterOf(pos.below());
            if (level.random.nextBoolean()) {
                dev.tc4port.thaumcraft.client.NodeTransducerRenderer.queueBolt(transducer, clientLevel, new Vec3(pos.getX() + 0.25 + level.random.nextFloat() * 0.5, pos.getY() + 0.5, pos.getZ() + 0.25 + level.random.nextFloat() * 0.5), node);
            }
            if (level.random.nextBoolean() && transducer.hasStabilizer()) {
                dev.tc4port.thaumcraft.client.NodeTransducerRenderer.queueBolt(transducer, clientLevel, new Vec3(pos.getX() + 0.25 + level.random.nextFloat() * 0.5, pos.getY() - 1.5, pos.getZ() + 0.25 + level.random.nextFloat() * 0.5), node);
            }
        }
    }

    public static boolean shouldSpawnClientBolts(int status, int count, boolean powered) {
        boolean extending = status != STATUS_IDLE && powered && count < TCGameplayParameters.MACHINES_NODE_TRANSDUCER_CONVERSION_TICKS.intValue();
        boolean retracting = !(status != STATUS_IDLE && powered) && count > 0;
        int nextCount = count + (extending ? 1 : retracting ? -1 : 0);
        return (extending || retracting) && nextCount > TCGameplayParameters.MACHINES_NODE_TRANSDUCER_SAFE_COLLAPSE_TICKS.intValue();
    }

    public void checkStatus() {
        if (this.level == null || !this.level.hasChunksAt(this.worldPosition.offset(-2, 0, -2), this.worldPosition.offset(2, 0, 2))) {
            this.statusCheckPending = true;
            return;
        }
        this.statusCheckPending = false;
        if (this.count == -1) {
            this.count = 0;
        }
        BlockState nodeState = this.level.getBlockState(this.worldPosition.below());
        boolean validEnergized = this.hasStabilizer() && nodeState.is(TCBlocks.ENERGIZED_AURA_NODE.get());
        if (this.status == STATUS_ENERGIZED && this.count > TCGameplayParameters.MACHINES_NODE_TRANSDUCER_SAFE_COLLAPSE_TICKS.intValue() && !validEnergized) {
            if (this.level instanceof ServerLevel serverLevel) {
                AuraNodeBlock.explodeEnergizedNode(serverLevel, this.worldPosition.below());
            }
            this.status = STATUS_IDLE;
            this.count = TCGameplayParameters.MACHINES_NODE_TRANSDUCER_SAFE_COLLAPSE_TICKS.intValue();
            this.changedAndSync();
            return;
        }
        int nextStatus = this.statusForStructure(nodeState);
        if (this.status == nextStatus) {
            return;
        }
        this.status = nextStatus;
        if (nextStatus == STATUS_ENERGIZED) {
            // Initialize only when entering this state. Repeated structure
            // notifications must not restart the powered-down retraction.
            this.count = TCGameplayParameters.MACHINES_NODE_TRANSDUCER_CONVERSION_TICKS.intValue();
        }
        this.changedAndSync();
    }

    private int statusForStructure(BlockState nodeState) {
        if (nodeState.is(TCBlocks.ENERGIZED_AURA_NODE.get())) {
            return STATUS_ENERGIZED;
        }
        return nodeState.is(TCBlocks.AURA_NODE.get()) && this.level.hasNeighborSignal(this.worldPosition) && this.hasStabilizer() ? STATUS_CHARGING : STATUS_IDLE;
    }

    public boolean hasStabilizer() {
        if (this.level == null || !this.level.hasChunksAt(this.worldPosition.offset(-2, 0, -2), this.worldPosition.offset(2, 0, 2))) {
            return false;
        }
        BlockPos stabilizerPos = this.worldPosition.below(2);
        return !this.level.hasNeighborSignal(stabilizerPos) && this.level.getBlockEntity(stabilizerPos) instanceof NodeStabilizerBlockEntity;
    }

    private void drainRandomAspect(ServerLevel level) {
        if (!(level.getBlockEntity(this.worldPosition.below()) instanceof AuraNodeBlockEntity node)) {
            return;
        }
        List<AspectId> present = node.nodeState().currentVis().amounts().entrySet().stream().filter(entry -> entry.getValue() > 0).map(Map.Entry::getKey).toList();
        if (present.isEmpty()) {
            return;
        }
        AspectId aspect = present.get(level.random.nextInt(present.size()));
        LinkedHashMap<AspectId, Integer> current = new LinkedHashMap<>(node.nodeState().currentVis().amounts());
        current.put(aspect, current.get(aspect) - 1);
        node.setNodeState(node.nodeState().withCurrentVis(new NodeVis(current)));
    }

    private void energizeNode(ServerLevel level) {
        // Neighbor delivery can lag behind a structure change. Validate at
        // the conversion boundary before replacing the node.
        this.checkStatus();
        if (this.status != STATUS_CHARGING) {
            return;
        }
        BlockPos nodePos = this.worldPosition.below();
        if (!(level.getBlockEntity(nodePos) instanceof AuraNodeBlockEntity oldNode) || !level.getBlockState(nodePos).is(TCBlocks.AURA_NODE.get())) {
            return;
        }
        AuraNodeState oldData = oldNode.nodeState();
        level.setBlock(nodePos, TCBlocks.ENERGIZED_AURA_NODE.get().defaultBlockState(), 3);
        if (level.getBlockEntity(nodePos) instanceof AuraNodeBlockEntity energized) {
            energized.setNodeState(new AuraNodeState(oldData.instanceId(), oldData.type(), oldData.modifier(), oldData.baseVis(), new NodeVis(zeroAspects(oldData.baseVis().amounts()))));
            energized.energizedBase();
        }
        this.checkStatus();
        this.conversionEffect(level);
    }

    private void deEnergizeNode(ServerLevel level) {
        BlockPos nodePos = this.worldPosition.below();
        if (!(level.getBlockEntity(nodePos) instanceof AuraNodeBlockEntity oldNode) || !level.getBlockState(nodePos).is(TCBlocks.ENERGIZED_AURA_NODE.get())) {
            return;
        }
        AuraNodeState oldData = oldNode.nodeState();
        level.setBlock(nodePos, TCBlocks.AURA_NODE.get().defaultBlockState(), 3);
        if (level.getBlockEntity(nodePos) instanceof AuraNodeBlockEntity regular) {
            regular.setNodeState(new AuraNodeState(oldData.instanceId(), oldData.type(), oldData.modifier(), oldData.baseVis(), new NodeVis(zeroAspects(oldData.baseVis().amounts()))));
        }
        this.conversionEffect(level);
        this.status = STATUS_IDLE;
        this.changedAndSync();
    }

    private void conversionEffect(ServerLevel level) {
        level.blockEvent(this.worldPosition, this.getBlockState().getBlock(), CONVERSION_EVENT, CONVERSION_EVENT);
    }

    @Override
    public boolean triggerEvent(int id, int type) {
        if (id == CONVERSION_EVENT && type == CONVERSION_EVENT) {
            if (this.level != null && this.level.isClientSide() && this.level instanceof net.minecraft.client.multiplayer.ClientLevel clientLevel) {
                clientLevel.playLocalSound(this.worldPosition.getX() + 0.5, this.worldPosition.getY() - 0.5, this.worldPosition.getZ() + 0.5, TCSounds.NODE_CONVERT.get(), SoundSource.BLOCKS, 0.5F, 1.0F, false);
                dev.tc4port.thaumcraft.client.NodeTransducerRenderer.queueConversionEffect(this, clientLevel);
            }
            return true;
        }
        return super.triggerEvent(id, type);
    }

    @Override
    public void load(CompoundTag tag) {
        super.load(tag);
        this.status = tag.getInt("status");
        this.count = tag.getInt("count");
        // Revalidate restored status without resetting conversion progress.
        this.statusCheckPending = true;
    }

    @Override
    protected void saveAdditional(CompoundTag tag) {
        super.saveAdditional(tag);
        tag.putInt("status", this.status);
        tag.putInt("count", this.count);
    }

    @Override
    public CompoundTag getUpdateTag() {
        return this.saveWithoutMetadata();
    }

    @Override
    public Packet<ClientGamePacketListener> getUpdatePacket() {
        return ClientboundBlockEntityDataPacket.create(this);
    }

    private void changedAndSync() {
        this.setChanged();
        if (this.level != null) {
            this.level.sendBlockUpdated(this.worldPosition, this.getBlockState(), this.getBlockState(), 3);
        }
    }

    private static Map<AspectId, Integer> zeroAspects(Map<AspectId, Integer> aspects) {
        LinkedHashMap<AspectId, Integer> result = new LinkedHashMap<>();
        aspects.keySet().forEach(aspect -> result.put(aspect, 0));
        return result;
    }

    protected final HolderLookup.Provider persistenceRegistries() {
        if (level != null)
            return level.registryAccess();
        var server = net.minecraftforge.server.ServerLifecycleHooks.getCurrentServer();
        return server != null ? server.registryAccess() : net.minecraft.core.RegistryAccess.fromRegistryOfRegistries(net.minecraft.core.registries.BuiltInRegistries.REGISTRY);
    }

    protected static net.minecraft.network.chat.Component parseCustomNameSafe(String value, HolderLookup.Provider registries) {
        try {
            return net.minecraft.network.chat.Component.Serializer.fromJson(value);
        } catch (RuntimeException exception) {
            return null;
        }
    }

    protected void readItemFields(ItemFields.Input input) {
    }

    public void copyItemFields(ItemFields.Output output) {
    }

    public void applyComponentsFromItemStack(ItemStack stack) {
        readItemFields(ItemFields.from(stack));
    }

    public void removeComponentsFromTag(CompoundTag tag) {
    }

    @Override
    public void saveToItem(ItemStack stack) {
        CompoundTag tag = saveWithoutMetadata();
        {
            net.minecraft.nbt.CompoundTag native$bodyOperand$6211 = tag;
            native$bodyReturn$6213: {
                if (true) {
                }
            }
        }
        net.minecraft.world.item.BlockItem.setBlockEntityData(stack, getType(), tag);
        copyItemFields(ItemFields.to(stack));
    }

    @Override
    public net.minecraft.world.phys.AABB getRenderBoundingBox() {
        return NodeTransducerBlockEntity.native$ClientBlockEntityBounds$bounds(this);
    }

    @Override()
    public void onDataPacket(net.minecraft.network.Connection connection, net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket packet) {
        handleUpdateTag(packet.getTag());
    }

    @SuppressWarnings({ "rawtypes", "unchecked" })
    static private net.minecraft.world.phys.AABB native$ClientBlockEntityBounds$bounds(net.minecraft.world.level.block.entity.BlockEntity blockEntity) {
        var renderer = net.minecraft.client.Minecraft.getInstance().getBlockEntityRenderDispatcher().getRenderer(blockEntity);
        return renderer instanceof dev.tc4port.thaumcraft.nativeimpl.NativeBlockEntityRenderer shared ? shared.getRenderBoundingBox(blockEntity) : new net.minecraft.world.phys.AABB(blockEntity.getBlockPos());
    }
}
