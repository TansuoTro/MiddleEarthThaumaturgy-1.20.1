package dev.tc4port.thaumcraft.api.event;

import java.util.function.Consumer;
import net.minecraft.world.entity.Entity;

public final class NativeEntityTicks {

    private NativeEntityTicks() {
    }

    private static final java.util.List<Consumer<Entity>> LISTENERS = new java.util.concurrent.CopyOnWriteArrayList<>();

    public static void onTick(java.util.function.Predicate<Entity> subjects, Consumer<Entity> listener) {
        onTick(entity -> {
            if (subjects.test(entity))
                listener.accept(entity);
        });
    }

    public static void onTick(Consumer<Entity> listener) {
        LISTENERS.add(listener);
    }

    public static void afterTick(Entity entity) {
        if (entity.isRemoved())
            return;
        for (var listener : LISTENERS) listener.accept(entity);
    }
}
