package dev.tc4port.thaumcraft.api.data;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;

/**
 * Explicit value of an item offered to a Pech.
 */
public record PechValueDefinition(int value) {

    public static final Codec<PechValueDefinition> CODEC = RecordCodecBuilder.create(instance -> instance.group(Codec.intRange(1, 32).fieldOf("value").forGetter(PechValueDefinition::value)).apply(instance, PechValueDefinition::new));

    public PechValueDefinition {
        if (value < 1 || value > 32) {
            throw new IllegalArgumentException("Pech value must be between 1 and 32");
        }
    }
}
