package dev.tc4port.thaumcraft.api.focus;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import dev.tc4port.thaumcraft.api.MagicAttributes;
import javax.annotation.Nullable;
import net.minecraft.world.entity.LivingEntity;

/**
 * A cast snapshot. Fixed damage is added before the multiplier, as with native attack attributes.
 */
public record FocusDamageModifiers(double multiplier, double bonus) {

    public static final double MAX_BONUS = 1_000_000;

    public static final FocusDamageModifiers IDENTITY = new FocusDamageModifiers(1, 0);

    public static final Codec<FocusDamageModifiers> CODEC = RecordCodecBuilder.create(instance -> instance.group(Codec.doubleRange(0, 1024).fieldOf("multiplier").forGetter(FocusDamageModifiers::multiplier), Codec.doubleRange(-MAX_BONUS, MAX_BONUS).optionalFieldOf("bonus", 0.0).forGetter(FocusDamageModifiers::bonus)).apply(instance, FocusDamageModifiers::new));

    public FocusDamageModifiers {
        if (!Double.isFinite(multiplier) || multiplier < 0 || multiplier > 1024 || !Double.isFinite(bonus) || Math.abs(bonus) > MAX_BONUS) {
            throw new IllegalArgumentException("Invalid focus damage modifiers");
        }
    }

    public static FocusDamageModifiers capture(@Nullable LivingEntity caster) {
        return new FocusDamageModifiers(MagicAttributes.multiplier(caster, MagicAttributes.FOCUS_DAMAGE_MULTIPLIER), MagicAttributes.damageBonus(caster));
    }

    /**
     * Nonpositive input stays zero; the native damage pipeline decides hit behavior.
     */
    public double apply(double damage) {
        return damage <= 0 ? 0 : Math.min(Float.MAX_VALUE, Math.max(0, (damage + bonus) * multiplier));
    }
}
