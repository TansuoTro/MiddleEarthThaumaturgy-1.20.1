package dev.tc4port.thaumcraft.api.golem;

import java.util.Objects;
import java.util.Set;
import net.minecraft.core.BlockPos;
import net.minecraft.world.phys.Vec3;

/**
 * Optional adapter contribution when an ordinary path makes no progress.
 * The core remains responsible for executing either action and additionally
 * rejects unloaded or excessively distant explicit path targets.
 */
public sealed interface GolemRecoveryAction permits GolemRecoveryAction.Path, GolemRecoveryAction.ControlledStep {

    record Path(Set<BlockPos> targets) implements GolemRecoveryAction {

        public Path {
            Objects.requireNonNull(targets, "targets");
            if (targets.size() > GolemTravelFrame.MAX_PATH_TARGETS) {
                throw new IllegalArgumentException("targets must not exceed " + GolemTravelFrame.MAX_PATH_TARGETS);
            }
            targets = targets.stream().map(BlockPos::immutable).collect(java.util.stream.Collectors.toUnmodifiableSet());
            if (targets.isEmpty()) {
                throw new IllegalArgumentException("targets must not be empty");
            }
        }
    }

    /**
     * A short, physics-resolved walk used to cross a boundary which cannot be
     * represented by either side's path graph. It never teleports the golem.
     */
    record ControlledStep(Vec3 target, int maxTicks) implements GolemRecoveryAction {

        public ControlledStep {
            target = Objects.requireNonNull(target, "target");
            if (!Double.isFinite(target.x) || !Double.isFinite(target.y) || !Double.isFinite(target.z)) {
                throw new IllegalArgumentException("target must be finite");
            }
            if (maxTicks < 1 || maxTicks > 100) {
                throw new IllegalArgumentException("maxTicks must be between 1 and 100");
            }
        }
    }
}
