package dev.tc4port.thaumcraft.block;

import com.mojang.serialization.MapCodec;
import dev.tc4port.thaumcraft.block.entity.RunedStoneTrapBlockEntity;
import dev.tc4port.thaumcraft.registry.TCBlockEntities;
import dev.tc4port.thaumcraft.registry.TCParticles;
import javax.annotation.Nullable;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityTicker;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import dev.tc4port.thaumcraft.nativeimpl.ClientExtensionTarget;
import dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.level.pathfinder.PathComputationType;
import net.minecraft.world.phys.HitResult;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.Explosion;
import net.minecraft.world.level.BlockGetter;

/**
 * BlockEldritch metadata ten and TileEldritchTrap.
 */
public final class RunedStoneTrapBlock extends net.minecraft.world.level.block.BaseEntityBlock implements dev.tc4port.thaumcraft.nativeimpl.ClientExtensionTarget {

    // Forge calls initializeClient from the native superclass constructor. Do not add a field initializer.
    private java.util.function.Consumer<net.minecraftforge.client.extensions.common.IClientBlockExtensions> platform$clientInstaller;

    public static final MapCodec<RunedStoneTrapBlock> CODEC = RunedStoneTrapBlock.native$BlockCodecPlatform$simple(RunedStoneTrapBlock::new);

    public RunedStoneTrapBlock(BlockBehaviour.Properties properties) {
        this(properties.noLootTable(), properties, true);
    }

    protected MapCodec<RunedStoneTrapBlock> codec() {
        return CODEC;
    }

    @Nullable
    @Override
    public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        return new RunedStoneTrapBlockEntity(pos, state);
    }

    @Override
    public RenderShape getRenderShape(BlockState state) {
        return RenderShape.MODEL;
    }

    @Override
    public void animateTick(BlockState state, Level level, BlockPos pos, net.minecraft.util.RandomSource random) {
        int x = pos.getX() + random.nextInt(2) - random.nextInt(2);
        int y = pos.getY() + random.nextInt(2) - random.nextInt(2);
        int z = pos.getZ() + random.nextInt(2) - random.nextInt(2);
        BlockPos runePos = new BlockPos(x, y, z);
        if (!level.isEmptyBlock(runePos)) {
            return;
        }
        float spawnX = x + random.nextFloat() + 0.5F;
        float spawnY = y + random.nextFloat() + 0.5F;
        float spawnZ = z + random.nextFloat() + 0.5F;
        float red = 0.5F + random.nextFloat() * 0.5F;
        float green = random.nextFloat() * 0.3F;
        float blue = 0.9F + random.nextFloat() * 0.1F;
        int duration = 16 + random.nextInt(4);
        /*
         * SimpleParticleType supplies only three transport doubles. Preserve
         * every visual channel by carrying duration in red's integer part.
         */
        level.addParticle(TCParticles.RUNED_STONE_RUNE.get(), spawnX, spawnY, spawnZ, duration + red, green, blue);
    }

    @Nullable
    @Override
    public <T extends BlockEntity> BlockEntityTicker<T> getTicker(Level level, BlockState state, BlockEntityType<T> type) {
        if (level.isClientSide) {
            return null;
        }
        return createTickerHelper(type, TCBlockEntities.RUNED_STONE_TRAP.get(), RunedStoneTrapBlockEntity::serverTick);
    }

    public int getExpDrop(net.minecraft.world.level.block.state.BlockState native$callbackInput$1062, net.minecraft.world.level.LevelReader native$callbackInput$1063, net.minecraft.util.RandomSource native$callbackInput$1064, net.minecraft.core.BlockPos native$callbackInput$1065, int native$callbackInput$1066, int native$callbackInput$1067) {
        net.minecraft.world.level.block.state.BlockState state = native$callbackInput$1062;
        net.minecraft.util.RandomSource random = native$callbackInput$1064;
        return 1 + random.nextInt(4);
    }

    private RunedStoneTrapBlock(net.minecraft.world.level.block.state.BlockBehaviour.Properties native$NativeEntityBlock$arg0, BlockBehaviour.Properties properties, boolean native$NativeEntityBlock$captured) {
        super(native$NativeEntityBlock$arg0);
    }

    @Override
    public void initializeClient(java.util.function.Consumer<net.minecraftforge.client.extensions.common.IClientBlockExtensions> installer) {
        platform$clientInstaller = installer;
        super.initializeClient(installer);
    }

    @Override
    public void platform$clientExtension(Object extension) {
        java.util.Objects.requireNonNull(platform$clientInstaller, "Forge initializeClient must run before client extension registration").accept((net.minecraftforge.client.extensions.common.IClientBlockExtensions) extension);
    }

    @Override
    public InteractionResult use(BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
        ItemUseResult result = (switch(0) {
            default ->
                {
                    net.minecraft.world.item.ItemStack native$bodyOperand$4684 = player.getItemInHand(hand);
                    net.minecraft.world.level.block.state.BlockState native$bodyOperand$4685 = state;
                    net.minecraft.world.level.Level native$bodyOperand$4686 = level;
                    net.minecraft.core.BlockPos native$bodyOperand$4687 = pos;
                    net.minecraft.world.entity.player.Player native$bodyOperand$4688 = player;
                    net.minecraft.world.InteractionHand native$bodyOperand$4689 = hand;
                    net.minecraft.world.phys.BlockHitResult native$bodyOperand$4690 = hit;
                    dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult native$bodyResult$4691 = null;
                    native$bodyReturn$4692: {
                        if (true) {
                            {
                                native$bodyResult$4691 = dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
                                break native$bodyReturn$4692;
                            }
                        }
                    }
                    yield native$bodyResult$4691;
                }
        });
        return result == ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION ? (hand == InteractionHand.MAIN_HAND ? (switch(0) {
            default ->
                {
                    net.minecraft.world.level.block.state.BlockState native$bodyOperand$3840 = state;
                    net.minecraft.world.level.Level native$bodyOperand$3841 = level;
                    net.minecraft.core.BlockPos native$bodyOperand$3842 = pos;
                    net.minecraft.world.entity.player.Player native$bodyOperand$3843 = player;
                    net.minecraft.world.phys.BlockHitResult native$bodyOperand$3844 = hit;
                    net.minecraft.world.InteractionResult native$bodyResult$3845 = null;
                    native$bodyReturn$3846: {
                        if (true) {
                            {
                                native$bodyResult$3845 = super.use(native$bodyOperand$3840, native$bodyOperand$3841, native$bodyOperand$3842, native$bodyOperand$3843, net.minecraft.world.InteractionHand.MAIN_HAND, native$bodyOperand$3844);
                                break native$bodyReturn$3846;
                            }
                        }
                    }
                    yield native$bodyResult$3845;
                }
        }) : InteractionResult.PASS) : result.result();
    }

    protected ItemUseResult interactWithItem(ItemStack stack, BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
        return dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
    }

    protected InteractionResult interactWithoutItem(BlockState state, Level level, BlockPos pos, Player player, BlockHitResult hit) {
        return super.use(state, level, pos, player, net.minecraft.world.InteractionHand.MAIN_HAND, hit);
    }

    @Override
    public void playerWillDestroy(Level level, BlockPos pos, BlockState state, Player player) {
        {
            net.minecraft.world.level.Level native$bodyOperand$5986 = level;
            net.minecraft.core.BlockPos native$bodyOperand$5987 = pos;
            net.minecraft.world.level.block.state.BlockState native$bodyOperand$5988 = state;
            net.minecraft.world.entity.player.Player native$bodyOperand$5989 = player;
            net.minecraft.world.level.block.state.BlockState native$bodyResult$5990 = null;
            native$bodyReturn$5991: {
                if (true) {
                    super.playerWillDestroy(native$bodyOperand$5986, native$bodyOperand$5987, native$bodyOperand$5988, native$bodyOperand$5989);
                    {
                        native$bodyResult$5990 = native$bodyOperand$5988;
                        break native$bodyReturn$5991;
                    }
                }
            }
        }
    }

    public BlockState beforePlayerDestroy(Level level, BlockPos pos, BlockState state, Player player) {
        super.playerWillDestroy(level, pos, state, player);
        return state;
    }

    protected boolean survivesSharedExplosion() {
        return false;
    }

    @Override
    public void onBlockExploded(BlockState state, Level level, BlockPos pos, Explosion explosion) {
        if (!(switch(0) {
            default ->
                {
                    boolean native$bodyResult$5311 = false;
                    native$bodyReturn$5312: {
                        if (true) {
                            {
                                native$bodyResult$5311 = false;
                                break native$bodyReturn$5312;
                            }
                        }
                    }
                    yield native$bodyResult$5311;
                }
        }))
            super.onBlockExploded(state, level, pos, explosion);
    }

    @Override
    public boolean canDropFromExplosion(BlockState state, BlockGetter level, BlockPos pos, Explosion explosion) {
        return !(switch(0) {
            default ->
                {
                    boolean native$bodyResult$4693 = false;
                    native$bodyReturn$4694: {
                        if (true) {
                            {
                                native$bodyResult$4693 = false;
                                break native$bodyReturn$4694;
                            }
                        }
                    }
                    yield native$bodyResult$4693;
                }
        }) && super.canDropFromExplosion(state, level, pos, explosion);
    }

    static private <B extends net.minecraft.world.level.block.Block> com.mojang.serialization.MapCodec<B> native$BlockCodecPlatform$simple(java.util.function.Function<net.minecraft.world.level.block.state.BlockBehaviour.Properties, B> factory) {
        // Vanilla 1.21's Properties codec is a unit codec. Retain that schema for shared block definitions.
        return com.mojang.serialization.codecs.RecordCodecBuilder.mapCodec(instance -> instance.group(com.mojang.serialization.Codec.unit(net.minecraft.world.level.block.state.BlockBehaviour.Properties::of).fieldOf("properties").forGetter((B block) -> net.minecraft.world.level.block.state.BlockBehaviour.Properties.copy(block))).apply(instance, factory));
    }
}
