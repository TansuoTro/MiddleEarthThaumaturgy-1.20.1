package dev.tc4port.thaumcraft.api.research;

import java.util.Objects;
import net.minecraft.resources.ResourceLocation;

/**
 * Names the addon/system and controlled policy used for a research grant.
 */
public record ResearchCompletionContext(ResourceLocation source, ResearchCompletionReason reason) {

    public ResearchCompletionContext {
        Objects.requireNonNull(source, "source");
        Objects.requireNonNull(reason, "reason");
    }
}
