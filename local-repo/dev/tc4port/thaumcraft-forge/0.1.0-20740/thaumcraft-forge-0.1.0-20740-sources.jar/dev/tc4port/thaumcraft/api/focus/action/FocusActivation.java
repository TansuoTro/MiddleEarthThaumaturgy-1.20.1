package dev.tc4port.thaumcraft.api.focus.action;

public enum FocusActivation {

    USE_AIR, USE_BLOCK, USE_ENTITY, USING_TICK, STOP_USING
}
