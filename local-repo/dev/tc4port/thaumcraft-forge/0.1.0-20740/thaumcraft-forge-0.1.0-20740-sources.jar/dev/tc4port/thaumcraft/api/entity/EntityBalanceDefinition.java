package dev.tc4port.thaumcraft.api.entity;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.Map;
import net.minecraft.resources.ResourceLocation;

/**
 * Attribute defaults and a small set of ability values, keyed by entity type.
 */
public record EntityBalanceDefinition(Map<ResourceLocation, Double> attributes, Map<String, Double> abilities) {

    public static final EntityBalanceDefinition EMPTY = new EntityBalanceDefinition(Map.of(), Map.of());

    public static final Codec<EntityBalanceDefinition> CODEC = RecordCodecBuilder.create(i -> i.group(EntityBalanceDefinition.native$StrictOptionalFields$of(Codec.unboundedMap(ResourceLocation.CODEC, Codec.doubleRange(0, 1_000_000)), "attributes", Map.of()).forGetter(EntityBalanceDefinition::attributes), EntityBalanceDefinition.native$StrictOptionalFields$of(Codec.unboundedMap(Codec.STRING, Codec.doubleRange(0, 1_000_000)), "abilities", Map.of()).forGetter(EntityBalanceDefinition::abilities)).apply(i, EntityBalanceDefinition::new));

    public EntityBalanceDefinition {
        attributes = Map.copyOf(attributes);
        abilities = Map.copyOf(abilities);
        if (attributes.size() > 32 || abilities.size() > 32)
            throw new IllegalArgumentException("Too many balance values");
        attributes.forEach((id, value) -> {
            if (!Double.isFinite(value) || value < 0 || value > 1_000_000)
                throw new IllegalArgumentException("Invalid attribute value " + id);
        });
        abilities.forEach((key, value) -> {
            if (!java.util.Set.of("damage_cap", "heal_interval", "heal_amount", "enrage_ticks", "enrage_heal_divisor", "enrage_damage_divisor", "attack_cooldown", "attack_cooldown_choices", "wither_ticks", "weakness_ticks").contains(key) || !Double.isFinite(value) || value < 0 || value > 1_000_000 || (key.contains("interval") || key.contains("divisor") || key.endsWith("choices")) && value < 1)
                throw new IllegalArgumentException("Invalid ability value " + key);
            if ((key.endsWith("ticks") || key.contains("interval") || key.startsWith("attack_cooldown")) && value != Math.rint(value))
                throw new IllegalArgumentException("Ability requires an integer " + key);
        });
    }

    static private <A> com.mojang.serialization.MapCodec<A> native$StrictOptionalFields$of(com.mojang.serialization.Codec<A> codec, java.lang.String name, A defaultValue) {
        return EntityBalanceDefinition.native$StrictOptionalFields$of(codec, name).xmap(value -> value.orElse(defaultValue), value -> java.util.Objects.equals(value, defaultValue) ? java.util.Optional.empty() : java.util.Optional.of(value));
    }

    static private <A> com.mojang.serialization.MapCodec<java.util.Optional<A>> native$StrictOptionalFields$of(com.mojang.serialization.Codec<A> codec, java.lang.String name) {
        java.util.Objects.requireNonNull(codec, "codec");
        java.util.Objects.requireNonNull(name, "name");
        return new com.mojang.serialization.MapCodec<>() {

            @Override
            public <T> com.mojang.serialization.DataResult<java.util.Optional<A>> decode(com.mojang.serialization.DynamicOps<T> ops, com.mojang.serialization.MapLike<T> input) {
                T value = input.get(name);
                return value == null ? com.mojang.serialization.DataResult.success(java.util.Optional.empty()) : codec.parse(ops, value).map(java.util.Optional::of);
            }

            @Override
            public <T> com.mojang.serialization.RecordBuilder<T> encode(java.util.Optional<A> input, com.mojang.serialization.DynamicOps<T> ops, com.mojang.serialization.RecordBuilder<T> prefix) {
                return input.isPresent() ? prefix.add(name, codec.encodeStart(ops, input.get())) : prefix;
            }

            @Override
            public <T> java.util.stream.Stream<T> keys(com.mojang.serialization.DynamicOps<T> ops) {
                return java.util.stream.Stream.of(ops.createString(name));
            }

            @Override
            public java.lang.String toString() {
                return "StrictOptionalField[" + name + ": " + codec + "]";
            }
        };
    }
}
