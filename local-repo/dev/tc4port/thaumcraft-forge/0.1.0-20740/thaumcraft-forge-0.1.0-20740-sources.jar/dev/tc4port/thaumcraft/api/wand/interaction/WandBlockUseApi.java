package dev.tc4port.thaumcraft.api.wand.interaction;

import dev.tc4port.thaumcraft.api.Registration;
import dev.tc4port.thaumcraft.common.WandBlockInteractions;
import java.util.Objects;
import net.minecraft.core.registries.Registries;
import net.minecraft.tags.TagKey;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.entity.LivingEntity;

/**
 * Block-owned held use for standard TC wands and {@code CustomWandItem}s.
 */
public final class WandBlockUseApi {

    /**
     * Blocks in this tag claim held use even without a registered callback.
     * Includes the three tappable node blocks by default. Built-in absorption
     * is itself a handler registered to this tag; other members are passive
     * unless a matching handler accepts them.
     */
    public static final TagKey<Block> SUPPRESSES_FOCUS = TagKey.create(Registries.BLOCK, net.minecraft.resources.ResourceLocation.fromNamespaceAndPath((java.lang.String) ("thaumcraft"), (java.lang.String) ("wand/suppresses_focus")));

    private WandBlockUseApi() {
    }

    /**
     * Read-only presentation query for a currently used wand. Includes nodes,
     * callbacks and passive tag members. Before a local tick or for a remote
     * player, resolves the same handlers from interpolated aim. An existing
     * block session suppresses focus until native use ends, even after looking
     * away. Addon renderers can use this to suppress their focus effects.
     */
    public static boolean isSuppressingFocus(LivingEntity caster, float partialTick) {
        return WandBlockInteractions.isSuppressingFocus(caster, partialTick);
    }

    /**
     * Latest matching live registration whose canStart accepts wins. Closing
     * its handle restores earlier registrations for future sessions and ends
     * its existing sessions on their next tick; it never switches their owner.
     */
    public static Registration register(Block block, WandBlockUseHandler handler) {
        Objects.requireNonNull(block, "block");
        return Registration.of(WandBlockInteractions.register(state -> state.is(block), Objects.requireNonNull(handler, "handler")));
    }

    /**
     * Uses current native tag membership, including data pack reloads.
     */
    public static Registration register(TagKey<Block> tag, WandBlockUseHandler handler) {
        Objects.requireNonNull(tag, "tag");
        return Registration.of(WandBlockInteractions.register(state -> state.is(tag), Objects.requireNonNull(handler, "handler")));
    }
}
