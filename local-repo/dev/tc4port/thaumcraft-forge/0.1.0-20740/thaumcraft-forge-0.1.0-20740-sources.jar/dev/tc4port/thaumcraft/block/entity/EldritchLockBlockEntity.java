package dev.tc4port.thaumcraft.block.entity;

import dev.tc4port.thaumcraft.registry.TCBlockEntities;
import dev.tc4port.thaumcraft.registry.TCSounds;
import dev.tc4port.thaumcraft.worldgen.outer.OuterBossSpawner;
import net.minecraft.core.BlockPos;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import dev.tc4port.thaumcraft.nativeimpl.state.ItemFields;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityType;

/**
 * Persistent opening timer from {@code TileEldritchLock}.
 *
 * <p>Completion delegates the graph lookup, persistent boss rotation, exact
 * room transformation, spawn, Airy cleanup and removal to
 * {@link OuterBossSpawner}.</p>
 */
public final class EldritchLockBlockEntity extends net.minecraft.world.level.block.entity.BlockEntity implements ItemFields.Source {

    private int count = -1;

    public EldritchLockBlockEntity(BlockPos pos, BlockState state) {
        super(TCBlockEntities.ELDRITCH_LOCK.get(), pos, state);
    }

    public static void serverTick(Level level, BlockPos pos, BlockState state, EldritchLockBlockEntity lock) {
        if (!(level instanceof ServerLevel server) || lock.count == -1) {
            return;
        }
        lock.count++;
        if (lock.count % 5 == 0) {
            server.playSound(null, pos, TCSounds.PUMP.get(), SoundSource.BLOCKS, 1.0F, 1.0F);
        }
        if (lock.count > 100) {
            completeOpening(server, pos);
        }
    }

    public static void clientTick(Level level, BlockPos pos, BlockState state, EldritchLockBlockEntity lock) {
        /*
         * TileEldritchLock advanced the synchronized start value locally.
         * Do not resend NBT every tick: that restarts interpolation and was
         * never part of the source network path.
         */
        if (lock.count >= 0 && lock.count <= 100) {
            lock.count++;
        }
    }

    private static void completeOpening(ServerLevel level, BlockPos pos) {
        level.playSound(null, pos, TCSounds.ICE.get(), SoundSource.BLOCKS, 1.0F, 1.0F);
        OuterBossSpawner.complete(level, pos);
    }

    public int count() {
        return this.count;
    }

    public void startOpening() {
        if (this.count < 0) {
            this.count = 0;
            this.changedAndSync();
        }
    }

    private void changedAndSync() {
        this.setChanged();
        if (this.level != null) {
            this.level.sendBlockUpdated(this.worldPosition, this.getBlockState(), this.getBlockState(), 3);
        }
    }

    @Override
    public void load(CompoundTag tag) {
        super.load(tag);
        this.count = tag.getShort("count");
    }

    @Override
    protected void saveAdditional(CompoundTag tag) {
        super.saveAdditional(tag);
        tag.putShort("count", (short) this.count);
    }

    @Override
    public CompoundTag getUpdateTag() {
        return this.saveWithoutMetadata();
    }

    @Override
    public Packet<ClientGamePacketListener> getUpdatePacket() {
        return ClientboundBlockEntityDataPacket.create(this);
    }

    protected final HolderLookup.Provider persistenceRegistries() {
        if (level != null)
            return level.registryAccess();
        var server = net.minecraftforge.server.ServerLifecycleHooks.getCurrentServer();
        return server != null ? server.registryAccess() : net.minecraft.core.RegistryAccess.fromRegistryOfRegistries(net.minecraft.core.registries.BuiltInRegistries.REGISTRY);
    }

    protected static net.minecraft.network.chat.Component parseCustomNameSafe(String value, HolderLookup.Provider registries) {
        try {
            return net.minecraft.network.chat.Component.Serializer.fromJson(value);
        } catch (RuntimeException exception) {
            return null;
        }
    }

    protected void readItemFields(ItemFields.Input input) {
    }

    public void copyItemFields(ItemFields.Output output) {
    }

    public void applyComponentsFromItemStack(ItemStack stack) {
        readItemFields(ItemFields.from(stack));
    }

    public void removeComponentsFromTag(CompoundTag tag) {
    }

    @Override
    public void saveToItem(ItemStack stack) {
        CompoundTag tag = saveWithoutMetadata();
        {
            net.minecraft.nbt.CompoundTag native$bodyOperand$6132 = tag;
            native$bodyReturn$6134: {
                if (true) {
                }
            }
        }
        net.minecraft.world.item.BlockItem.setBlockEntityData(stack, getType(), tag);
        copyItemFields(ItemFields.to(stack));
    }

    @Override
    public net.minecraft.world.phys.AABB getRenderBoundingBox() {
        return EldritchLockBlockEntity.native$ClientBlockEntityBounds$bounds(this);
    }

    @Override()
    public void onDataPacket(net.minecraft.network.Connection connection, net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket packet) {
        handleUpdateTag(packet.getTag());
    }

    @SuppressWarnings({ "rawtypes", "unchecked" })
    static private net.minecraft.world.phys.AABB native$ClientBlockEntityBounds$bounds(net.minecraft.world.level.block.entity.BlockEntity blockEntity) {
        var renderer = net.minecraft.client.Minecraft.getInstance().getBlockEntityRenderDispatcher().getRenderer(blockEntity);
        return renderer instanceof dev.tc4port.thaumcraft.nativeimpl.NativeBlockEntityRenderer shared ? shared.getRenderBoundingBox(blockEntity) : new net.minecraft.world.phys.AABB(blockEntity.getBlockPos());
    }
}
