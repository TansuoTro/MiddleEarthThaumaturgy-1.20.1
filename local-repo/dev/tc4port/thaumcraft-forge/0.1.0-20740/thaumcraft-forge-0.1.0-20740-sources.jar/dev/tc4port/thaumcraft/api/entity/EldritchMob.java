package dev.tc4port.thaumcraft.api.entity;

/**
 * Marks an entity as part of the complete TC4 eldritch alliance: allied
 * targeting, obelisk buffs, Arcane Field exemption and the eldritch champion
 * absorption-shield branch.
 */
public interface EldritchMob {
}
