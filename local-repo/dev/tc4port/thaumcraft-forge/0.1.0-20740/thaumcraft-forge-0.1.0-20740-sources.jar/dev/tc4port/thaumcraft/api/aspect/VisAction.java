package dev.tc4port.thaumcraft.api.aspect;

/**
 * Whether a successful Vis operation is only checked or actually applied.
 * Stack-payment APIs retain TC4's client affordability prediction without
 * mutation; server-only transfer APIs never accept a client level.
 */
public enum VisAction {

    SIMULATE, EXECUTE
}
