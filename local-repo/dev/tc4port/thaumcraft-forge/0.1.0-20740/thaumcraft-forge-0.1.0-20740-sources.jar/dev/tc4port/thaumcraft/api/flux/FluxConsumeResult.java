package dev.tc4port.thaumcraft.api.flux;

/**
 * Integer finite-fluid result; a rejected nonpositive request is represented by (0, 0, 0).
 */
public record FluxConsumeResult(int requestedQuanta, int consumedQuanta, int affectedBlocks) {

    public FluxConsumeResult {
        if (requestedQuanta < 0 || consumedQuanta < 0 || consumedQuanta > requestedQuanta || affectedBlocks < 0 || affectedBlocks > consumedQuanta) {
            throw new IllegalArgumentException("Invalid flux consume result");
        }
    }
}
