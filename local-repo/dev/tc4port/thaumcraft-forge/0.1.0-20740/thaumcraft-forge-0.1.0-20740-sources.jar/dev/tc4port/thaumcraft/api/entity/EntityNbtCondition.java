package dev.tc4port.thaumcraft.api.entity;

import java.util.Objects;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.Tag;

/**
 * One top-level saved-NBT predicate for an entity-aspect rule. A matching
 * condition contributes {@code name + scanHashContribution} to the scan-hash
 * preimage.
 */
public record EntityNbtCondition(String name, Tag expected, String scanHashContribution) {

    public EntityNbtCondition {
        if (name == null || name.isBlank()) {
            throw new IllegalArgumentException("NBT condition requires a name");
        }
        expected = Objects.requireNonNull(expected, "expected").copy();
        scanHashContribution = scanHashContribution == null ? expected.getAsString() : scanHashContribution;
    }

    @Override
    public Tag expected() {
        return this.expected.copy();
    }

    public boolean matches(CompoundTag saved) {
        return this.expected.equals(saved.get(this.name));
    }
}
