package dev.tc4port.thaumcraft.block;

import com.mojang.serialization.MapCodec;
import dev.tc4port.thaumcraft.api.ThaumcraftTags;
import dev.tc4port.thaumcraft.block.entity.WardingAuraBlockEntity;
import dev.tc4port.thaumcraft.registry.TCBlockEntities;
import dev.tc4port.thaumcraft.registry.TCBlocks;
import javax.annotation.Nullable;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityTicker;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.world.level.pathfinder.PathComputationType;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.EntityCollisionContext;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;
import dev.tc4port.thaumcraft.nativeimpl.ClientExtensionTarget;
import dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.Explosion;

/**
 * Invisible two-block-high creature fence created by a warding paving stone.
 */
public final class WardingAuraBlock extends net.minecraft.world.level.block.BaseEntityBlock implements dev.tc4port.thaumcraft.nativeimpl.ClientExtensionTarget {

    // Forge calls initializeClient from the native superclass constructor. Do not add a field initializer.
    private java.util.function.Consumer<net.minecraftforge.client.extensions.common.IClientBlockExtensions> platform$clientInstaller;

    public static final MapCodec<WardingAuraBlock> CODEC = WardingAuraBlock.native$BlockCodecPlatform$simple(WardingAuraBlock::new);

    public static final BooleanProperty BLOCKING = BooleanProperty.create("blocking");

    public WardingAuraBlock(BlockBehaviour.Properties properties) {
        this(properties, properties, true);
    }

    protected MapCodec<WardingAuraBlock> codec() {
        return CODEC;
    }

    @Nullable
    @Override
    public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        return new WardingAuraBlockEntity(pos, state);
    }

    @Nullable
    @Override
    public <T extends BlockEntity> BlockEntityTicker<T> getTicker(Level level, BlockState state, BlockEntityType<T> type) {
        if (level.isClientSide) {
            return null;
        }
        return createTickerHelper(type, TCBlockEntities.WARDING_AURA.get(), WardingAuraBlockEntity::tick);
    }

    @Override
    public RenderShape getRenderShape(BlockState state) {
        return RenderShape.INVISIBLE;
    }

    @Override
    public VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
        return Shapes.empty();
    }

    @Override
    public VoxelShape getCollisionShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
        if (!(context instanceof EntityCollisionContext entityContext) || !(entityContext.getEntity() instanceof LivingEntity) || entityContext.getEntity() instanceof Player) {
            return Shapes.empty();
        }
        BlockPos source = sourcePosition(level, pos);
        if (level instanceof Level world && !world.hasChunksAt(source.offset(-2, 0, -2), source.offset(2, 0, 2))) {
            return state.getValue(BLOCKING) ? Shapes.block() : Shapes.empty();
        }
        return level instanceof Level world && world.hasNeighborSignal(source) ? Shapes.empty() : Shapes.block();
    }

    @Override
    public boolean isPathfindable(BlockState state, net.minecraft.world.level.BlockGetter level, BlockPos pos, PathComputationType type) {
        return !state.getValue(BLOCKING);
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<net.minecraft.world.level.block.Block, BlockState> builder) {
        builder.add(BLOCKING);
    }

    @Override
    public void onPlace(BlockState state, Level level, BlockPos pos, BlockState oldState, boolean movedByPiston) {
        super.onPlace(state, level, pos, oldState, movedByPiston);
        syncBlockingState(level, pos);
    }

    public static boolean syncBlockingState(Level level, BlockPos auraPos) {
        if (!(level instanceof ServerLevel serverLevel) || !serverLevel.getServer().isSameThread() || serverLevel.isOutsideBuildHeight(auraPos) || serverLevel.isOutsideBuildHeight(auraPos.below(2)) || !serverLevel.getWorldBorder().isWithinBounds(auraPos) || !serverLevel.hasChunkAt(auraPos)) {
            return false;
        }
        BlockState aura = level.getBlockState(auraPos);
        if (!aura.is(TCBlocks.WARDING_AURA.get())) {
            return false;
        }
        BlockPos source = sourcePosition(level, auraPos);
        if (!level.hasChunksAt(source.offset(-2, 0, -2), source.offset(2, 0, 2))) {
            return false;
        }
        boolean supported = level.getBlockState(source).is(ThaumcraftTags.WARDING_AURA_SOURCES);
        boolean blocking = supported && !level.hasNeighborSignal(source);
        if (aura.getValue(BLOCKING) != blocking) {
            level.setBlock(auraPos, aura.setValue(BLOCKING, blocking), net.minecraft.world.level.block.Block.UPDATE_ALL);
            return true;
        }
        return false;
    }

    public static BlockPos sourcePosition(BlockGetter level, BlockPos auraPos) {
        BlockPos oneBelow = auraPos.below();
        return level.getBlockState(oneBelow).is(ThaumcraftTags.WARDING_AURA_SOURCES) ? oneBelow : auraPos.below(2);
    }

    private WardingAuraBlock(net.minecraft.world.level.block.state.BlockBehaviour.Properties native$NativeEntityBlock$arg0, BlockBehaviour.Properties properties, boolean native$NativeEntityBlock$captured) {
        super(native$NativeEntityBlock$arg0);
        this.registerDefaultState(this.stateDefinition.any().setValue(BLOCKING, false));
    }

    @Override
    public void initializeClient(java.util.function.Consumer<net.minecraftforge.client.extensions.common.IClientBlockExtensions> installer) {
        platform$clientInstaller = installer;
        super.initializeClient(installer);
    }

    @Override
    public void platform$clientExtension(Object extension) {
        java.util.Objects.requireNonNull(platform$clientInstaller, "Forge initializeClient must run before client extension registration").accept((net.minecraftforge.client.extensions.common.IClientBlockExtensions) extension);
    }

    @Override
    public InteractionResult use(BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
        ItemUseResult result = (switch(0) {
            default ->
                {
                    net.minecraft.world.item.ItemStack native$bodyOperand$4837 = player.getItemInHand(hand);
                    net.minecraft.world.level.block.state.BlockState native$bodyOperand$4838 = state;
                    net.minecraft.world.level.Level native$bodyOperand$4839 = level;
                    net.minecraft.core.BlockPos native$bodyOperand$4840 = pos;
                    net.minecraft.world.entity.player.Player native$bodyOperand$4841 = player;
                    net.minecraft.world.InteractionHand native$bodyOperand$4842 = hand;
                    net.minecraft.world.phys.BlockHitResult native$bodyOperand$4843 = hit;
                    dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult native$bodyResult$4844 = null;
                    native$bodyReturn$4845: {
                        if (true) {
                            {
                                native$bodyResult$4844 = dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
                                break native$bodyReturn$4845;
                            }
                        }
                    }
                    yield native$bodyResult$4844;
                }
        });
        return result == ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION ? (hand == InteractionHand.MAIN_HAND ? (switch(0) {
            default ->
                {
                    net.minecraft.world.level.block.state.BlockState native$bodyOperand$3940 = state;
                    net.minecraft.world.level.Level native$bodyOperand$3941 = level;
                    net.minecraft.core.BlockPos native$bodyOperand$3942 = pos;
                    net.minecraft.world.entity.player.Player native$bodyOperand$3943 = player;
                    net.minecraft.world.phys.BlockHitResult native$bodyOperand$3944 = hit;
                    net.minecraft.world.InteractionResult native$bodyResult$3945 = null;
                    native$bodyReturn$3946: {
                        if (true) {
                            {
                                native$bodyResult$3945 = super.use(native$bodyOperand$3940, native$bodyOperand$3941, native$bodyOperand$3942, native$bodyOperand$3943, net.minecraft.world.InteractionHand.MAIN_HAND, native$bodyOperand$3944);
                                break native$bodyReturn$3946;
                            }
                        }
                    }
                    yield native$bodyResult$3945;
                }
        }) : InteractionResult.PASS) : result.result();
    }

    protected ItemUseResult interactWithItem(ItemStack stack, BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
        return dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
    }

    protected InteractionResult interactWithoutItem(BlockState state, Level level, BlockPos pos, Player player, BlockHitResult hit) {
        return super.use(state, level, pos, player, net.minecraft.world.InteractionHand.MAIN_HAND, hit);
    }

    @Override
    public void playerWillDestroy(Level level, BlockPos pos, BlockState state, Player player) {
        {
            net.minecraft.world.level.Level native$bodyOperand$6078 = level;
            net.minecraft.core.BlockPos native$bodyOperand$6079 = pos;
            net.minecraft.world.level.block.state.BlockState native$bodyOperand$6080 = state;
            net.minecraft.world.entity.player.Player native$bodyOperand$6081 = player;
            net.minecraft.world.level.block.state.BlockState native$bodyResult$6082 = null;
            native$bodyReturn$6083: {
                if (true) {
                    super.playerWillDestroy(native$bodyOperand$6078, native$bodyOperand$6079, native$bodyOperand$6080, native$bodyOperand$6081);
                    {
                        native$bodyResult$6082 = native$bodyOperand$6080;
                        break native$bodyReturn$6083;
                    }
                }
            }
        }
    }

    public BlockState beforePlayerDestroy(Level level, BlockPos pos, BlockState state, Player player) {
        super.playerWillDestroy(level, pos, state, player);
        return state;
    }

    protected boolean survivesSharedExplosion() {
        return false;
    }

    public int getExpDrop(net.minecraft.world.level.block.state.BlockState native$callbackInput$1050, net.minecraft.world.level.LevelReader native$callbackInput$1051, net.minecraft.util.RandomSource native$callbackInput$1052, net.minecraft.core.BlockPos native$callbackInput$1053, int native$callbackInput$1054, int native$callbackInput$1055) {
        net.minecraft.world.level.block.state.BlockState state = native$callbackInput$1050;
        net.minecraft.util.RandomSource random = native$callbackInput$1052;
        return 0;
    }

    @Override
    public void onBlockExploded(BlockState state, Level level, BlockPos pos, Explosion explosion) {
        if (!(switch(0) {
            default ->
                {
                    boolean native$bodyResult$5337 = false;
                    native$bodyReturn$5338: {
                        if (true) {
                            {
                                native$bodyResult$5337 = false;
                                break native$bodyReturn$5338;
                            }
                        }
                    }
                    yield native$bodyResult$5337;
                }
        }))
            super.onBlockExploded(state, level, pos, explosion);
    }

    @Override
    public boolean canDropFromExplosion(BlockState state, BlockGetter level, BlockPos pos, Explosion explosion) {
        return !(switch(0) {
            default ->
                {
                    boolean native$bodyResult$4846 = false;
                    native$bodyReturn$4847: {
                        if (true) {
                            {
                                native$bodyResult$4846 = false;
                                break native$bodyReturn$4847;
                            }
                        }
                    }
                    yield native$bodyResult$4846;
                }
        }) && super.canDropFromExplosion(state, level, pos, explosion);
    }

    static private <B extends net.minecraft.world.level.block.Block> com.mojang.serialization.MapCodec<B> native$BlockCodecPlatform$simple(java.util.function.Function<net.minecraft.world.level.block.state.BlockBehaviour.Properties, B> factory) {
        // Vanilla 1.21's Properties codec is a unit codec. Retain that schema for shared block definitions.
        return com.mojang.serialization.codecs.RecordCodecBuilder.mapCodec(instance -> instance.group(com.mojang.serialization.Codec.unit(net.minecraft.world.level.block.state.BlockBehaviour.Properties::of).fieldOf("properties").forGetter((B block) -> net.minecraft.world.level.block.state.BlockBehaviour.Properties.copy(block))).apply(instance, factory));
    }
}
