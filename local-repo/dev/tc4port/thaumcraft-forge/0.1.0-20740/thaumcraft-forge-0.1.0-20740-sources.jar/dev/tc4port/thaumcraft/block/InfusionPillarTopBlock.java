package dev.tc4port.thaumcraft.block;

import com.mojang.serialization.MapCodec;
import dev.tc4port.thaumcraft.registry.TCBlocks;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.core.BlockPos;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.LevelEvent;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;
import dev.tc4port.thaumcraft.nativeimpl.ClientExtensionTarget;
import dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.level.pathfinder.PathComputationType;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.Explosion;

/**
 * Formed upper half of an infusion pillar. It intentionally has no block
 * entity, just like BlockStoneDevice metadata 4.
 */
public final class InfusionPillarTopBlock extends net.minecraft.world.level.block.Block implements dev.tc4port.thaumcraft.nativeimpl.ClientExtensionTarget {

    // Forge calls initializeClient from the native superclass constructor. Do not add a field initializer.
    private java.util.function.Consumer<net.minecraftforge.client.extensions.common.IClientBlockExtensions> platform$clientInstaller;

    public static final MapCodec<InfusionPillarTopBlock> CODEC = InfusionPillarTopBlock.native$BlockCodecPlatform$simple(InfusionPillarTopBlock::new);

    private static final VoxelShape SHAPE = Block.box(0, -16, 0, 16, -8, 16);

    private static final VoxelShape COLLISION_SHAPE = Block.box(0, 0, 0, 16, 16, 16);

    public InfusionPillarTopBlock(BlockBehaviour.Properties properties) {
        this(properties, properties, true);
    }

    protected MapCodec<InfusionPillarTopBlock> codec() {
        return CODEC;
    }

    @Override
    public VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
        return SHAPE;
    }

    @Override
    public VoxelShape getCollisionShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
        /*
         * The legacy metadata 4 selection box pointed down into the lower
         * half, while entity collision still occupied this entire block.
         */
        return COLLISION_SHAPE;
    }

    @Override
    public VoxelShape getBlockSupportShape(BlockState state, BlockGetter level, BlockPos pos) {
        return Shapes.empty();
    }

    @Override
    public RenderShape getRenderShape(BlockState state) {
        return RenderShape.MODEL;
    }

    @Override
    public void neighborChanged(BlockState state, Level level, BlockPos pos, Block neighborBlock, BlockPos neighborPos, boolean movedByPiston) {
        super.neighborChanged(state, level, pos, neighborBlock, neighborPos, movedByPiston);
        if (!level.isClientSide && !level.getBlockState(pos.below()).is(TCBlocks.INFUSION_PILLAR.get())) {
            level.destroyBlock(pos, true);
        }
    }

    @Override
    public boolean triggerEvent(BlockState state, Level level, BlockPos pos, int id, int parameter) {
        if (id == 1) {
            if (level.isClientSide) {
                dev.tc4port.thaumcraft.client.InfusionSparkleEffects.blockSparkle(level, pos, 11960575, 2);
                level.levelEvent(LevelEvent.PARTICLES_DESTROY_BLOCK, pos, Block.getId(Blocks.STONE_BRICKS.defaultBlockState()));
            }
            return true;
        }
        return super.triggerEvent(state, level, pos, id, parameter);
    }

    @Override
    public ItemStack getCloneItemStack(BlockState state, HitResult target, net.minecraft.world.level.BlockGetter level, BlockPos pos, Player player) {
        // Formed upper metadata 4 dropped the arcane-stone base.
        return new ItemStack(TCBlocks.ARCANE_STONE.get());
    }

    private InfusionPillarTopBlock(net.minecraft.world.level.block.state.BlockBehaviour.Properties native$NativeBlock$arg0, BlockBehaviour.Properties properties, boolean native$NativeBlock$captured) {
        super(native$NativeBlock$arg0);
    }

    @Override
    public void initializeClient(java.util.function.Consumer<net.minecraftforge.client.extensions.common.IClientBlockExtensions> installer) {
        platform$clientInstaller = installer;
        super.initializeClient(installer);
    }

    @Override
    public void platform$clientExtension(Object extension) {
        java.util.Objects.requireNonNull(platform$clientInstaller, "Forge initializeClient must run before client extension registration").accept((net.minecraftforge.client.extensions.common.IClientBlockExtensions) extension);
    }

    @Override
    public InteractionResult use(BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
        ItemUseResult result = (switch(0) {
            default ->
                {
                    net.minecraft.world.item.ItemStack native$bodyOperand$4529 = player.getItemInHand(hand);
                    net.minecraft.world.level.block.state.BlockState native$bodyOperand$4530 = state;
                    net.minecraft.world.level.Level native$bodyOperand$4531 = level;
                    net.minecraft.core.BlockPos native$bodyOperand$4532 = pos;
                    net.minecraft.world.entity.player.Player native$bodyOperand$4533 = player;
                    net.minecraft.world.InteractionHand native$bodyOperand$4534 = hand;
                    net.minecraft.world.phys.BlockHitResult native$bodyOperand$4535 = hit;
                    dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult native$bodyResult$4536 = null;
                    native$bodyReturn$4537: {
                        if (true) {
                            {
                                native$bodyResult$4536 = dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
                                break native$bodyReturn$4537;
                            }
                        }
                    }
                    yield native$bodyResult$4536;
                }
        });
        return result == ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION ? (hand == InteractionHand.MAIN_HAND ? (switch(0) {
            default ->
                {
                    net.minecraft.world.level.block.state.BlockState native$bodyOperand$3735 = state;
                    net.minecraft.world.level.Level native$bodyOperand$3736 = level;
                    net.minecraft.core.BlockPos native$bodyOperand$3737 = pos;
                    net.minecraft.world.entity.player.Player native$bodyOperand$3738 = player;
                    net.minecraft.world.phys.BlockHitResult native$bodyOperand$3739 = hit;
                    net.minecraft.world.InteractionResult native$bodyResult$3740 = null;
                    native$bodyReturn$3741: {
                        if (true) {
                            {
                                native$bodyResult$3740 = super.use(native$bodyOperand$3735, native$bodyOperand$3736, native$bodyOperand$3737, native$bodyOperand$3738, net.minecraft.world.InteractionHand.MAIN_HAND, native$bodyOperand$3739);
                                break native$bodyReturn$3741;
                            }
                        }
                    }
                    yield native$bodyResult$3740;
                }
        }) : InteractionResult.PASS) : result.result();
    }

    protected ItemUseResult interactWithItem(ItemStack stack, BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
        return dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
    }

    protected InteractionResult interactWithoutItem(BlockState state, Level level, BlockPos pos, Player player, BlockHitResult hit) {
        return super.use(state, level, pos, player, net.minecraft.world.InteractionHand.MAIN_HAND, hit);
    }

    @Override
    public void playerWillDestroy(Level level, BlockPos pos, BlockState state, Player player) {
        {
            net.minecraft.world.level.Level native$bodyOperand$5889 = level;
            net.minecraft.core.BlockPos native$bodyOperand$5890 = pos;
            net.minecraft.world.level.block.state.BlockState native$bodyOperand$5891 = state;
            net.minecraft.world.entity.player.Player native$bodyOperand$5892 = player;
            net.minecraft.world.level.block.state.BlockState native$bodyResult$5893 = null;
            native$bodyReturn$5894: {
                if (true) {
                    super.playerWillDestroy(native$bodyOperand$5889, native$bodyOperand$5890, native$bodyOperand$5891, native$bodyOperand$5892);
                    {
                        native$bodyResult$5893 = native$bodyOperand$5891;
                        break native$bodyReturn$5894;
                    }
                }
            }
        }
    }

    public BlockState beforePlayerDestroy(Level level, BlockPos pos, BlockState state, Player player) {
        super.playerWillDestroy(level, pos, state, player);
        return state;
    }

    protected boolean survivesSharedExplosion() {
        return false;
    }

    public int getExpDrop(net.minecraft.world.level.block.state.BlockState native$callbackInput$1145, net.minecraft.world.level.LevelReader native$callbackInput$1146, net.minecraft.util.RandomSource native$callbackInput$1147, net.minecraft.core.BlockPos native$callbackInput$1148, int native$callbackInput$1149, int native$callbackInput$1150) {
        net.minecraft.world.level.block.state.BlockState state = native$callbackInput$1145;
        net.minecraft.util.RandomSource random = native$callbackInput$1147;
        return 0;
    }

    @Override
    public void onBlockExploded(BlockState state, Level level, BlockPos pos, Explosion explosion) {
        if (!(switch(0) {
            default ->
                {
                    boolean native$bodyResult$5283 = false;
                    native$bodyReturn$5284: {
                        if (true) {
                            {
                                native$bodyResult$5283 = false;
                                break native$bodyReturn$5284;
                            }
                        }
                    }
                    yield native$bodyResult$5283;
                }
        }))
            super.onBlockExploded(state, level, pos, explosion);
    }

    @Override
    public boolean canDropFromExplosion(BlockState state, BlockGetter level, BlockPos pos, Explosion explosion) {
        return !(switch(0) {
            default ->
                {
                    boolean native$bodyResult$4538 = false;
                    native$bodyReturn$4539: {
                        if (true) {
                            {
                                native$bodyResult$4538 = false;
                                break native$bodyReturn$4539;
                            }
                        }
                    }
                    yield native$bodyResult$4538;
                }
        }) && super.canDropFromExplosion(state, level, pos, explosion);
    }

    static private <B extends net.minecraft.world.level.block.Block> com.mojang.serialization.MapCodec<B> native$BlockCodecPlatform$simple(java.util.function.Function<net.minecraft.world.level.block.state.BlockBehaviour.Properties, B> factory) {
        // Vanilla 1.21's Properties codec is a unit codec. Retain that schema for shared block definitions.
        return com.mojang.serialization.codecs.RecordCodecBuilder.mapCodec(instance -> instance.group(com.mojang.serialization.Codec.unit(net.minecraft.world.level.block.state.BlockBehaviour.Properties::of).fieldOf("properties").forGetter((B block) -> net.minecraft.world.level.block.state.BlockBehaviour.Properties.copy(block))).apply(instance, factory));
    }
}
