package dev.tc4port.thaumcraft.api.machine;

import dev.tc4port.thaumcraft.api.aspect.AspectId;
import javax.annotation.Nullable;

/**
 * Immutable public view of one loaded TC arcane alembic.
 * Existing contents may exceed capacity after a datapack reduces the limit.
 */
public record AlembicSnapshot(@Nullable AspectId storedAspect, @Nullable AspectId filter, int amount, int capacity) {

    public AlembicSnapshot {
        if (amount < 0 || capacity < 0) {
            throw new IllegalArgumentException("Invalid alembic amount/capacity " + amount + "/" + capacity);
        }
    }

    public int remainingCapacity() {
        return Math.max(0, this.capacity - this.amount);
    }
}
