package dev.tc4port.thaumcraft.api.client;

import net.minecraft.client.gui.GuiGraphics;

public interface HudHeartPass {

    void begin(float maximum, int absorption);

    void beforeHeart(GuiGraphics graphics, int x, int y);

    void finish(GuiGraphics graphics);
}
