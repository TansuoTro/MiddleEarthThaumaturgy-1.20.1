package dev.tc4port.thaumcraft.block;

import dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult;
import com.mojang.serialization.MapCodec;
import dev.tc4port.thaumcraft.block.entity.EldritchLockBlockEntity;
import dev.tc4port.thaumcraft.registry.TCBlockEntities;
import dev.tc4port.thaumcraft.registry.TCItems;
import dev.tc4port.thaumcraft.registry.TCParticles;
import dev.tc4port.thaumcraft.registry.TCSounds;
import javax.annotation.Nullable;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Mirror;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.Rotation;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityTicker;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.DirectionProperty;
import net.minecraft.world.phys.BlockHitResult;
import dev.tc4port.thaumcraft.nativeimpl.ClientExtensionTarget;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.level.pathfinder.PathComputationType;
import net.minecraft.world.phys.HitResult;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.Explosion;
import net.minecraft.world.level.BlockGetter;

/**
 * BlockEldritch metadata eight, the sealed Outer Lands boss-room opening.
 */
public final class EldritchLockBlock extends net.minecraft.world.level.block.BaseEntityBlock implements dev.tc4port.thaumcraft.nativeimpl.ClientExtensionTarget {

    // Forge calls initializeClient from the native superclass constructor. Do not add a field initializer.
    private java.util.function.Consumer<net.minecraftforge.client.extensions.common.IClientBlockExtensions> platform$clientInstaller;

    public static final MapCodec<EldritchLockBlock> CODEC = EldritchLockBlock.native$BlockCodecPlatform$simple(EldritchLockBlock::new);

    public static final DirectionProperty FACING = BlockStateProperties.FACING;

    public EldritchLockBlock(BlockBehaviour.Properties properties) {
        this(properties.noLootTable(), properties, true);
    }

    protected MapCodec<EldritchLockBlock> codec() {
        return CODEC;
    }

    @Nullable
    @Override
    public BlockState getStateForPlacement(BlockPlaceContext context) {
        return this.defaultBlockState().setValue(FACING, context.getClickedFace());
    }

    @Nullable
    @Override
    public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        return new EldritchLockBlockEntity(pos, state);
    }

    @Nullable
    @Override
    public <T extends BlockEntity> BlockEntityTicker<T> getTicker(Level level, BlockState state, BlockEntityType<T> type) {
        if (level.isClientSide) {
            return createTickerHelper(type, TCBlockEntities.ELDRITCH_LOCK.get(), EldritchLockBlockEntity::clientTick);
        }
        return createTickerHelper(type, TCBlockEntities.ELDRITCH_LOCK.get(), EldritchLockBlockEntity::serverTick);
    }

    @Override
    public RenderShape getRenderShape(BlockState state) {
        return RenderShape.MODEL;
    }

    @Override
    public void animateTick(BlockState state, Level level, BlockPos pos, net.minecraft.util.RandomSource random) {
        if (!(level.getBlockEntity(pos) instanceof EldritchLockBlockEntity lock) || lock.count() < 0) {
            return;
        }
        level.addParticle(TCParticles.ELDRITCH_LOCK_SPARK.get(), pos.getX() + random.nextFloat(), pos.getY() + random.nextFloat(), pos.getZ() + random.nextFloat(), 0.65F + random.nextFloat() * 0.1F, 1.0F, 1.0F);
    }

    protected ItemUseResult interactWithItem(ItemStack stack, BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
        if (!stack.is(dev.tc4port.thaumcraft.registry.TCItems.RUNED_TABLET.get()) || !(level.getBlockEntity(pos) instanceof dev.tc4port.thaumcraft.block.entity.EldritchLockBlockEntity lock) || lock.count() >= 0) {
            return dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
        }
        if (!level.isClientSide) {
            lock.startOpening();
            /*
             * ItemEldritchObject decremented the tablet even for creative
             * players. Preserve that unusual contract.
             */
            stack.shrink(1);
            level.playSound(null, pos, dev.tc4port.thaumcraft.registry.TCSounds.RUNIC_SHIELD_CHARGE.get(), net.minecraft.sounds.SoundSource.BLOCKS, 1.0F, 1.0F);
        }
        player.swing(hand);
        return dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.sidedSuccess(level.isClientSide);
    }

    @Override
    public BlockState rotate(BlockState state, Rotation rotation) {
        return state.setValue(FACING, rotation.rotate(state.getValue(FACING)));
    }

    @Override
    public BlockState mirror(BlockState state, Mirror mirror) {
        return this.rotate(state, mirror.getRotation(state.getValue(FACING)));
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<net.minecraft.world.level.block.Block, BlockState> builder) {
        builder.add(FACING);
    }

    private EldritchLockBlock(net.minecraft.world.level.block.state.BlockBehaviour.Properties native$NativeEntityBlock$arg0, BlockBehaviour.Properties properties, boolean native$NativeEntityBlock$captured) {
        super(native$NativeEntityBlock$arg0);
        this.registerDefaultState(this.stateDefinition.any().setValue(FACING, Direction.DOWN));
    }

    @Override
    public void initializeClient(java.util.function.Consumer<net.minecraftforge.client.extensions.common.IClientBlockExtensions> installer) {
        platform$clientInstaller = installer;
        super.initializeClient(installer);
    }

    @Override
    public void platform$clientExtension(Object extension) {
        java.util.Objects.requireNonNull(platform$clientInstaller, "Forge initializeClient must run before client extension registration").accept((net.minecraftforge.client.extensions.common.IClientBlockExtensions) extension);
    }

    @Override
    public InteractionResult use(BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
        ItemUseResult result = (switch(0) {
            default ->
                {
                    net.minecraft.world.item.ItemStack native$bodyOperand$4332 = player.getItemInHand(hand);
                    net.minecraft.world.level.block.state.BlockState native$bodyOperand$4333 = state;
                    net.minecraft.world.level.Level native$bodyOperand$4334 = level;
                    net.minecraft.core.BlockPos native$bodyOperand$4335 = pos;
                    net.minecraft.world.entity.player.Player native$bodyOperand$4336 = player;
                    net.minecraft.world.InteractionHand native$bodyOperand$4337 = hand;
                    net.minecraft.world.phys.BlockHitResult native$bodyOperand$4338 = hit;
                    dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult native$bodyResult$4340 = null;
                    native$bodyReturn$4341: {
                        if (true) {
                            if (!native$bodyOperand$4332.is(dev.tc4port.thaumcraft.registry.TCItems.RUNED_TABLET.get()) || !(native$bodyOperand$4334.getBlockEntity(native$bodyOperand$4335) instanceof dev.tc4port.thaumcraft.block.entity.EldritchLockBlockEntity native$bodyBinding$4339) || native$bodyBinding$4339.count() >= 0) {
                                {
                                    native$bodyResult$4340 = dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
                                    break native$bodyReturn$4341;
                                }
                            }
                            if (!native$bodyOperand$4334.isClientSide) {
                                native$bodyBinding$4339.startOpening();
                                /*
             * ItemEldritchObject decremented the tablet even for creative
             * players. Preserve that unusual contract.
             */
                                native$bodyOperand$4332.shrink(1);
                                native$bodyOperand$4334.playSound(null, native$bodyOperand$4335, dev.tc4port.thaumcraft.registry.TCSounds.RUNIC_SHIELD_CHARGE.get(), net.minecraft.sounds.SoundSource.BLOCKS, 1.0F, 1.0F);
                            }
                            native$bodyOperand$4336.swing(native$bodyOperand$4337);
                            {
                                native$bodyResult$4340 = dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.sidedSuccess(native$bodyOperand$4334.isClientSide);
                                break native$bodyReturn$4341;
                            }
                        }
                    }
                    yield native$bodyResult$4340;
                }
        });
        return result == ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION ? (hand == InteractionHand.MAIN_HAND ? (switch(0) {
            default ->
                {
                    net.minecraft.world.level.block.state.BlockState native$bodyOperand$3610 = state;
                    net.minecraft.world.level.Level native$bodyOperand$3611 = level;
                    net.minecraft.core.BlockPos native$bodyOperand$3612 = pos;
                    net.minecraft.world.entity.player.Player native$bodyOperand$3613 = player;
                    net.minecraft.world.phys.BlockHitResult native$bodyOperand$3614 = hit;
                    net.minecraft.world.InteractionResult native$bodyResult$3615 = null;
                    native$bodyReturn$3616: {
                        if (true) {
                            {
                                native$bodyResult$3615 = super.use(native$bodyOperand$3610, native$bodyOperand$3611, native$bodyOperand$3612, native$bodyOperand$3613, net.minecraft.world.InteractionHand.MAIN_HAND, native$bodyOperand$3614);
                                break native$bodyReturn$3616;
                            }
                        }
                    }
                    yield native$bodyResult$3615;
                }
        }) : InteractionResult.PASS) : result.result();
    }

    protected InteractionResult interactWithoutItem(BlockState state, Level level, BlockPos pos, Player player, BlockHitResult hit) {
        return super.use(state, level, pos, player, net.minecraft.world.InteractionHand.MAIN_HAND, hit);
    }

    @Override
    public void playerWillDestroy(Level level, BlockPos pos, BlockState state, Player player) {
        {
            net.minecraft.world.level.Level native$bodyOperand$5787 = level;
            net.minecraft.core.BlockPos native$bodyOperand$5788 = pos;
            net.minecraft.world.level.block.state.BlockState native$bodyOperand$5789 = state;
            net.minecraft.world.entity.player.Player native$bodyOperand$5790 = player;
            net.minecraft.world.level.block.state.BlockState native$bodyResult$5791 = null;
            native$bodyReturn$5792: {
                if (true) {
                    super.playerWillDestroy(native$bodyOperand$5787, native$bodyOperand$5788, native$bodyOperand$5789, native$bodyOperand$5790);
                    {
                        native$bodyResult$5791 = native$bodyOperand$5789;
                        break native$bodyReturn$5792;
                    }
                }
            }
        }
    }

    public BlockState beforePlayerDestroy(Level level, BlockPos pos, BlockState state, Player player) {
        super.playerWillDestroy(level, pos, state, player);
        return state;
    }

    protected boolean survivesSharedExplosion() {
        return false;
    }

    public int getExpDrop(net.minecraft.world.level.block.state.BlockState native$callbackInput$1050, net.minecraft.world.level.LevelReader native$callbackInput$1051, net.minecraft.util.RandomSource native$callbackInput$1052, net.minecraft.core.BlockPos native$callbackInput$1053, int native$callbackInput$1054, int native$callbackInput$1055) {
        net.minecraft.world.level.block.state.BlockState state = native$callbackInput$1050;
        net.minecraft.util.RandomSource random = native$callbackInput$1052;
        return 0;
    }

    @Override
    public void onBlockExploded(BlockState state, Level level, BlockPos pos, Explosion explosion) {
        if (!(switch(0) {
            default ->
                {
                    boolean native$bodyResult$5249 = false;
                    native$bodyReturn$5250: {
                        if (true) {
                            {
                                native$bodyResult$5249 = false;
                                break native$bodyReturn$5250;
                            }
                        }
                    }
                    yield native$bodyResult$5249;
                }
        }))
            super.onBlockExploded(state, level, pos, explosion);
    }

    @Override
    public boolean canDropFromExplosion(BlockState state, BlockGetter level, BlockPos pos, Explosion explosion) {
        return !(switch(0) {
            default ->
                {
                    boolean native$bodyResult$4342 = false;
                    native$bodyReturn$4343: {
                        if (true) {
                            {
                                native$bodyResult$4342 = false;
                                break native$bodyReturn$4343;
                            }
                        }
                    }
                    yield native$bodyResult$4342;
                }
        }) && super.canDropFromExplosion(state, level, pos, explosion);
    }

    static private <B extends net.minecraft.world.level.block.Block> com.mojang.serialization.MapCodec<B> native$BlockCodecPlatform$simple(java.util.function.Function<net.minecraft.world.level.block.state.BlockBehaviour.Properties, B> factory) {
        // Vanilla 1.21's Properties codec is a unit codec. Retain that schema for shared block definitions.
        return com.mojang.serialization.codecs.RecordCodecBuilder.mapCodec(instance -> instance.group(com.mojang.serialization.Codec.unit(net.minecraft.world.level.block.state.BlockBehaviour.Properties::of).fieldOf("properties").forGetter((B block) -> net.minecraft.world.level.block.state.BlockBehaviour.Properties.copy(block))).apply(instance, factory));
    }
}
