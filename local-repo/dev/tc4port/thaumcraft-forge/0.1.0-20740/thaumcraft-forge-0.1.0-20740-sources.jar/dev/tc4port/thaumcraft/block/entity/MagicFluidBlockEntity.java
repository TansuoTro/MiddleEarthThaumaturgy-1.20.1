package dev.tc4port.thaumcraft.block.entity;

import dev.tc4port.thaumcraft.api.event.WorldProtection;
import dev.tc4port.thaumcraft.block.FiniteFluidBlock;
import dev.tc4port.thaumcraft.fluid.BlockBackedFluid;
import dev.tc4port.thaumcraft.registry.TCBlockEntities;
import net.minecraft.core.BlockPos;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.Tag;
import net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import java.lang.Math;
import dev.tc4port.thaumcraft.nativeimpl.state.ItemFields;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityType;

/**
 * Non-ticking, exact world-fluid storage for finite liquids and classic source blocks.
 */
public final class MagicFluidBlockEntity extends net.minecraft.world.level.block.entity.BlockEntity implements net.minecraftforge.fluids.capability.IFluidHandler, ItemFields.Source {

    public static final int CAPACITY = 1000;

    private final int quantum;

    private final int maximum;

    private final boolean finite;

    private int volume;

    public MagicFluidBlockEntity(BlockPos pos, BlockState state) {
        super(TCBlockEntities.MAGIC_FLUID.get(), pos, state);
        this.finite = state.getBlock() instanceof FiniteFluidBlock;
        BlockBackedFluid fluid = (BlockBackedFluid) state.getFluidState().getType();
        this.quantum = this.finite ? CAPACITY / fluid.quantaPerBlock() : CAPACITY;
        this.maximum = this.finite ? fluid.maximumQuanta() * this.quantum : CAPACITY;
        this.volume = this.finite ? ((FiniteFluidBlock) state.getBlock()).amount(state) * this.quantum : state.getFluidState().isSource() ? CAPACITY : 0;
    }

    public int volume() {
        return this.volume;
    }

    /**
     * Called after a block-state edit, including legacy ecology/scrubber edits.
     */
    public void onLayerChange(BlockState previous, BlockState next) {
        if (!this.finite) {
            if (previous.getFluidState().isSource() != next.getFluidState().isSource()) {
                this.volume = next.getFluidState().isSource() ? CAPACITY : 0;
                this.setChanged();
            }
            return;
        }
        int delta = next.getValue(FiniteFluidBlock.LEVEL) - previous.getValue(FiniteFluidBlock.LEVEL);
        this.volume = Math.max(this.finite ? 1 : 0, Math.min(this.maximum, this.volume + delta * this.quantum));
        this.setChanged();
    }

    /**
     * The caller has already written the corresponding visible layer state.
     */
    public void setStoredVolume(int amount) {
        this.volume = Math.max(this.finite ? 1 : 0, Math.min(this.maximum, amount));
        this.setChanged();
        if (this.level != null && !this.level.isClientSide) {
            BlockState state = this.getBlockState();
            this.level.sendBlockUpdated(this.worldPosition, state, state, 2);
        }
    }

    private boolean usable() {
        return !this.isRemoved() && this.level != null && this.level.hasChunkAt(this.worldPosition) && this.level.getBlockState(this.worldPosition).is(this.getBlockState().getBlock());
    }

    private void writeVolume(int amount) {
        if (amount <= 0) {
            this.level.setBlock(this.worldPosition, Blocks.AIR.defaultBlockState(), 3);
            return;
        }
        BlockState state = this.finite ? ((BlockBackedFluid) this.getBlockState().getFluidState().getType()).blockStateForQuanta((amount + this.quantum - 1) / this.quantum) : this.getBlockState().getBlock().defaultBlockState();
        this.level.setBlock(this.worldPosition, state, 3);
        this.setStoredVolume(amount);
    }

    @Override
    public int getTanks() {
        return 1;
    }

    @Override
    public net.minecraftforge.fluids.FluidStack getFluidInTank(int tank) {
        return tank == 0 && this.usable() ? new net.minecraftforge.fluids.FluidStack(this.getBlockState().getFluidState().getType(), this.volume) : net.minecraftforge.fluids.FluidStack.EMPTY;
    }

    @Override
    public int getTankCapacity(int tank) {
        return tank == 0 ? this.maximum : 0;
    }

    @Override
    public boolean isFluidValid(int tank, net.minecraftforge.fluids.FluidStack stack) {
        return tank == 0 && (switch(0) {
            default ->
                {
                    net.minecraftforge.fluids.FluidStack native$operand$13669 = stack;
                    net.minecraft.world.level.material.Fluid native$operand$13670 = this.getBlockState().getFluidState().getType();
                    boolean native$result$13671 = (native$operand$13669.getFluid() == native$operand$13670);
                    yield native$result$13671;
                }
        }) && (switch(0) {
            default ->
                {
                    net.minecraftforge.fluids.FluidStack native$operand$14129 = stack;
                    boolean native$result$14130 = (native$operand$14129.getTag() == null || native$operand$14129.getTag().isEmpty());
                    yield native$result$14130;
                }
        });
    }

    @Override
    public int fill(net.minecraftforge.fluids.FluidStack resource, net.minecraftforge.fluids.capability.IFluidHandler.FluidAction action) {
        if (!this.usable() || !this.isFluidValid(0, resource))
            return 0;
        if (!WorldProtection.allow(this.level, this.worldPosition, WorldProtection.Action.FILL_FLUID, null))
            return 0;
        // Only legacy producers create overfull cells; machines fill to one bucket.
        int accepted = Math.min(resource.getAmount(), Math.max(0, CAPACITY - this.volume));
        // Classic flowing cells carry no independent bucket. A new source requires a full bucket.
        if (!this.finite && this.volume == 0 && accepted < CAPACITY)
            return 0;
        if (accepted > 0 && action.execute() && !this.level.isClientSide)
            this.writeVolume(this.volume + accepted);
        return accepted;
    }

    @Override
    public net.minecraftforge.fluids.FluidStack drain(net.minecraftforge.fluids.FluidStack resource, net.minecraftforge.fluids.capability.IFluidHandler.FluidAction action) {
        return this.isFluidValid(0, resource) ? this.drain(resource.getAmount(), action) : net.minecraftforge.fluids.FluidStack.EMPTY;
    }

    @Override
    public net.minecraftforge.fluids.FluidStack drain(int maxDrain, net.minecraftforge.fluids.capability.IFluidHandler.FluidAction action) {
        if (!this.usable() || maxDrain <= 0 || this.volume <= 0)
            return net.minecraftforge.fluids.FluidStack.EMPTY;
        int extracted = Math.min(maxDrain, this.volume);
        if (action.execute() && !this.level.isClientSide)
            this.writeVolume(this.volume - extracted);
        return new net.minecraftforge.fluids.FluidStack(this.getBlockState().getFluidState().getType(), extracted);
    }

    @Override
    protected void saveAdditional(CompoundTag tag) {
        super.saveAdditional(tag);
        tag.putInt("VolumeMb", this.volume);
    }

    @Override
    public void load(CompoundTag tag) {
        super.load(tag);
        if (tag.contains("VolumeMb", Tag.TAG_INT)) {
            this.volume = Math.max(this.finite ? 1 : 0, Math.min(this.maximum, tag.getInt("VolumeMb")));
        }
    }

    @Override
    public CompoundTag getUpdateTag() {
        return this.saveWithoutMetadata();
    }

    @Override
    public ClientboundBlockEntityDataPacket getUpdatePacket() {
        return ClientboundBlockEntityDataPacket.create(this);
    }

    protected final HolderLookup.Provider persistenceRegistries() {
        if (level != null)
            return level.registryAccess();
        var server = net.minecraftforge.server.ServerLifecycleHooks.getCurrentServer();
        return server != null ? server.registryAccess() : net.minecraft.core.RegistryAccess.fromRegistryOfRegistries(net.minecraft.core.registries.BuiltInRegistries.REGISTRY);
    }

    protected static net.minecraft.network.chat.Component parseCustomNameSafe(String value, HolderLookup.Provider registries) {
        try {
            return net.minecraft.network.chat.Component.Serializer.fromJson(value);
        } catch (RuntimeException exception) {
            return null;
        }
    }

    protected void readItemFields(ItemFields.Input input) {
    }

    public void copyItemFields(ItemFields.Output output) {
    }

    public void applyComponentsFromItemStack(ItemStack stack) {
        readItemFields(ItemFields.from(stack));
    }

    public void removeComponentsFromTag(CompoundTag tag) {
    }

    @Override
    public void saveToItem(ItemStack stack) {
        CompoundTag tag = saveWithoutMetadata();
        {
            net.minecraft.nbt.CompoundTag native$bodyOperand$6182 = tag;
            native$bodyReturn$6184: {
                if (true) {
                }
            }
        }
        net.minecraft.world.item.BlockItem.setBlockEntityData(stack, getType(), tag);
        copyItemFields(ItemFields.to(stack));
    }

    @Override
    public net.minecraft.world.phys.AABB getRenderBoundingBox() {
        return MagicFluidBlockEntity.native$ClientBlockEntityBounds$bounds(this);
    }

    @Override()
    public void onDataPacket(net.minecraft.network.Connection connection, net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket packet) {
        handleUpdateTag(packet.getTag());
    }

    @SuppressWarnings({ "rawtypes", "unchecked" })
    static private net.minecraft.world.phys.AABB native$ClientBlockEntityBounds$bounds(net.minecraft.world.level.block.entity.BlockEntity blockEntity) {
        var renderer = net.minecraft.client.Minecraft.getInstance().getBlockEntityRenderDispatcher().getRenderer(blockEntity);
        return renderer instanceof dev.tc4port.thaumcraft.nativeimpl.NativeBlockEntityRenderer shared ? shared.getRenderBoundingBox(blockEntity) : new net.minecraft.world.phys.AABB(blockEntity.getBlockPos());
    }

    private boolean native$capabilitiesInvalid$16936;

    public boolean native$capabilityActive$16788;

    private java.util.Map<net.minecraft.core.Direction, net.minecraftforge.common.util.LazyOptional<net.minecraftforge.fluids.capability.IFluidHandler>> native$capabilityHandle$16789;

    @Override
    public <native$capabilityResultType$16937> net.minecraftforge.common.util.LazyOptional<native$capabilityResultType$16937> getCapability(net.minecraftforge.common.capabilities.Capability<native$capabilityResultType$16937> native$requestedCapability$16938, net.minecraft.core.Direction native$requestedFace$16939) {
        getCapabilities();
        synchronized (this) {
            if (native$capabilitiesInvalid$16936)
                return net.minecraftforge.common.util.LazyOptional.empty();
            if (native$capabilityActive$16788 && native$requestedCapability$16938 == (net.minecraftforge.common.capabilities.ForgeCapabilities.FLUID_HANDLER)) {
                if (native$capabilityHandle$16789 == null)
                    native$capabilityHandle$16789 = new java.util.HashMap<>();
                net.minecraftforge.common.util.LazyOptional<net.minecraftforge.fluids.capability.IFluidHandler> native$capabilityResult$16941 = native$capabilityHandle$16789.computeIfAbsent(native$requestedFace$16939, native$capabilityFace$16790 -> {
                    net.minecraftforge.fluids.capability.IFluidHandler native$endpoint$61 = (switch(0) {
                        default ->
                            {
                                dev.tc4port.thaumcraft.block.entity.MagicFluidBlockEntity fluid = dev.tc4port.thaumcraft.block.entity.MagicFluidBlockEntity.this;
                                net.minecraft.core.Direction side = native$capabilityFace$16790;
                                yield fluid;
                            }
                    });
                    return native$endpoint$61 == null ? net.minecraftforge.common.util.LazyOptional.empty() : net.minecraftforge.common.util.LazyOptional.of(() -> native$endpoint$61);
                });
                if (native$capabilityResult$16941.isPresent())
                    return native$capabilityResult$16941.cast();
            }
        }
        return super.getCapability(native$requestedCapability$16938, native$requestedFace$16939);
    }

    @Override
    public void invalidateCaps() {
        java.util.List<net.minecraftforge.common.util.LazyOptional<?>> native$expiredCapabilities$16940 = new java.util.ArrayList<>();
        synchronized (this) {
            native$capabilitiesInvalid$16936 = true;
            if (native$capabilityHandle$16789 != null) {
                native$expiredCapabilities$16940.addAll(native$capabilityHandle$16789.values());
                native$capabilityHandle$16789 = null;
            }
        }
        try {
            super.invalidateCaps();
        } finally {
            native$expiredCapabilities$16940.forEach(net.minecraftforge.common.util.LazyOptional::invalidate);
        }
    }

    @Override
    public void reviveCaps() {
        super.reviveCaps();
        synchronized (this) {
            native$capabilitiesInvalid$16936 = false;
        }
    }
}
