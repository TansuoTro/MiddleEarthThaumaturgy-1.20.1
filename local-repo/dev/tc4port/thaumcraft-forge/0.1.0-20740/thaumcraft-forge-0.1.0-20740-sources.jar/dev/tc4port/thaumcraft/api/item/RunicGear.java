package dev.tc4port.thaumcraft.api.item;

import net.minecraft.world.item.ItemStack;

/**
 * Dynamic owner-item hook for base runic shielding capacity.
 *
 * <p>Static capacity should use the synchronized equipment-ability Data Map.
 * The callback is read-only and must return a charge from zero through
 * {@link #MAX_CHARGE}; out-of-range results are clamped. Infusion hardening is
 * applied afterward as a bounded signed integer, while positive
 * final capacity remains upper-bounded for integer storage. Infusion recipes
 * independently reject inputs whose material expansion exceeds their budget.</p>
 */
@FunctionalInterface
public interface RunicGear {

    /**
     * Upper bound accepted by all public and data-defined base capacities.
     */
    int MAX_CHARGE = 1_000_000;

    int thaumcraftRunicCharge(ItemStack stack);
}
