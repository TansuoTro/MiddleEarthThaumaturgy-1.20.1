package dev.tc4port.thaumcraft.api.wand;

import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import dev.tc4port.thaumcraft.nativeimpl.ClientExtensionTarget;
import dev.tc4port.thaumcraft.nativeimpl.ItemStorage;
import dev.tc4port.thaumcraft.api.item.OwnedItemStack;
import java.util.List;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.Rarity;

/**
 * Common item identity for TC wand and focus-casting carriers.
 *
 * <p>Addons should normally extend {@link CustomWandItem}; this type exists
 * so every TC subsystem can recognize addon carriers without depending on
 * an implementation-package item class.</p>
 */
public abstract class WandCarrierItem extends net.minecraft.world.item.Item implements dev.tc4port.thaumcraft.api.item.OwnedItemStack {

    // Forge calls initializeClient from the native superclass constructor. Do not add a field initializer.
    private java.util.function.Consumer<net.minecraftforge.client.extensions.common.IClientItemExtensions> platform$clientInstaller;

    protected WandCarrierItem(Properties properties) {
        this(properties.stacksTo(1), properties, true);
    }

    /**
     * Whether use requires the opposite hand to be empty.
     */
    public abstract boolean requiresBothHands(ItemStack stack);

    private WandCarrierItem(net.minecraft.world.item.Item.Properties native$NativeItem$arg0, Properties properties, boolean native$NativeItem$captured) {
        super(native$NativeItem$arg0);
    }

    @Override
    public void initializeClient(java.util.function.Consumer<net.minecraftforge.client.extensions.common.IClientItemExtensions> installer) {
        platform$clientInstaller = installer;
        super.initializeClient(installer);
    }

    public void platform$clientExtension(Object extension) {
        java.util.Objects.requireNonNull(platform$clientInstaller, "Forge initializeClient must run before client extension registration").accept((net.minecraftforge.client.extensions.common.IClientItemExtensions) extension);
    }

    @Override
    public Rarity getRarity(ItemStack stack) {
        return ItemStorage.rarity(stack, super.getRarity(stack));
    }

    /**
     * Override registered defaults while retaining explicit stack properties.
     */
    protected int maximumDurability(ItemStack stack, int fallback) {
        return fallback;
    }

    public net.minecraft.world.food.FoodProperties getFoodProperties(net.minecraft.world.item.ItemStack native$callbackInput$1166, net.minecraft.world.entity.LivingEntity native$callbackInput$1167) {
        net.minecraft.world.item.ItemStack stack = native$callbackInput$1166;
        net.minecraft.world.entity.LivingEntity entity = native$callbackInput$1167;
        net.minecraft.world.food.FoodProperties fallback = super.getFoodProperties(native$callbackInput$1166, native$callbackInput$1167);
        return fallback;
    }

    @Override
    public int getMaxDamage(ItemStack stack) {
        int base = WandCarrierItem.native$ItemDurability$maximumOverride(stack).orElse(super.getMaxDamage(stack));
        if (WandCarrierItem.native$ItemDurability$maximumOverride(stack).isPresent())
            return base;
        return maximumDurability(stack, base);
    }

    static private java.util.OptionalInt native$ItemDurability$maximumOverride(net.minecraft.world.item.ItemStack stack) {
        var tag = stack.getTag();
        int value = tag == null ? 0 : tag.getInt("minecraft:max_damage");
        return value > 0 ? java.util.OptionalInt.of(value) : java.util.OptionalInt.empty();
    }
}
