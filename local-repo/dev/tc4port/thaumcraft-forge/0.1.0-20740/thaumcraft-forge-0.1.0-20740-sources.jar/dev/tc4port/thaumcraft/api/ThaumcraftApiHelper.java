package dev.tc4port.thaumcraft.api;

import dev.tc4port.thaumcraft.aspect.AspectCatalog;
import dev.tc4port.thaumcraft.api.aspect.VisAction;
import dev.tc4port.thaumcraft.api.aspect.AspectAmounts;
import dev.tc4port.thaumcraft.api.aspect.AspectApi;
import dev.tc4port.thaumcraft.api.aspect.AspectId;
import dev.tc4port.thaumcraft.api.aspect.VisChannel;
import dev.tc4port.thaumcraft.api.aspect.AspectRegistryView;
import dev.tc4port.thaumcraft.api.aspect.VisConsumptionContext;
import dev.tc4port.thaumcraft.api.aspect.VisCost;
import dev.tc4port.thaumcraft.api.aspect.VisPaymentResult;
import dev.tc4port.thaumcraft.api.essentia.EssentiaTransport;
import dev.tc4port.thaumcraft.common.PlayerKnowledgeService;
import dev.tc4port.thaumcraft.common.WandPayments;
import dev.tc4port.thaumcraft.api.wand.WandMachineContext;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import javax.annotation.Nullable;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.shapes.CollisionContext;

/**
 * The supported 1.21 counterpart of TC4's public helper surface.
 *
 * <p>Player instances replace username-indexed global maps, item identities
 * replace the ore-dictionary metadata namespace, and data components replace
 * recipe components. Those are engine translations; method ordering, vis
 * units, simulation flags and source-side mutation rules remain the TC4
 * contracts.</p>
 */
public final class ThaumcraftApiHelper {

    /**
     * Maximum candidate amounts examined by one partial inventory payment.
     */
    public static final int MAX_PARTIAL_VIS_REQUEST = 1024;

    private static final int MAX_ASPECT_CACHE_ENTRIES = 16;

    private static final Object ASPECT_CACHE_LOCK = new Object();

    private static final LinkedHashMap<Integer, AspectAmounts> ALL_ASPECTS = new LinkedHashMap<>(16, 0.75F, true);

    private static final LinkedHashMap<Integer, AspectAmounts> ALL_COMPOUND_ASPECTS = new LinkedHashMap<>(16, 0.75F, true);

    private static long aspectCacheGeneration = Long.MIN_VALUE;

    private ThaumcraftApiHelper() {
    }

    public static boolean hasDiscoveredAspect(Player player, AspectId aspect) {
        return PlayerKnowledgeService.get(player).knowsAspect(aspect);
    }

    public static Set<AspectId> getDiscoveredAspectIds(Player player) {
        java.util.LinkedHashSet<AspectId> result = new java.util.LinkedHashSet<>();
        result.addAll(PlayerKnowledgeService.get(player).aspectPools().keySet());
        return Collections.unmodifiableSet(result);
    }

    public static AspectAmounts getAspectPools(Player player) {
        return new AspectAmounts(PlayerKnowledgeService.get(player).aspectPools());
    }

    /**
     * The first coordinate is the source helper's x/column argument and the
     * second is y/row, despite their historical parameter names.
     */
    public static ItemStack getStackInRowAndColumn(net.minecraft.world.inventory.CraftingContainer input, int row, int column) {
        if (row < 0 || row >= input.getWidth() || column < 0 || column >= input.getHeight()) {
            return ItemStack.EMPTY;
        }
        return input.getItem(row + column * input.getWidth());
    }

    /**
     * A recipe component patch is a subset requirement, matching TC4's rule
     * that extra keys on the crafting-slot stack were accepted.
     */
    public static boolean areItemStackTagsEqualForCrafting(ItemStack slotItem, ItemStack recipeItem) {
        if (slotItem == null || recipeItem == null || slotItem.isEmpty() || recipeItem.isEmpty()) {
            return false;
        }
        return ThaumcraftApiHelper.native$ItemIdentity$matchesRequirements(slotItem, recipeItem, false);
    }

    @Nullable
    public static EssentiaTransport getConnectableTransport(BlockGetter level, BlockPos position, Direction face) {
        BlockPos neighborPos = position.relative(face);
        if (level instanceof net.minecraft.world.level.LevelReader reader && !reader.hasChunk(neighborPos.getX() >> 4, neighborPos.getZ() >> 4)) {
            return null;
        }
        EssentiaTransport transport = dev.tc4port.thaumcraft.api.essentia.EssentiaApi.transport(level, neighborPos, face.getOpposite());
        return transport != null && transport.isConnectable(face.getOpposite()) ? transport : null;
    }

    public static AspectAmounts getAllAspects(int amount) {
        if (amount <= 0) {
            throw new IllegalArgumentException("All-aspect amount must be positive");
        }
        AspectRegistryView snapshot = AspectApi.registry();
        return cachedAspects(snapshot, amount, false);
    }

    public static AspectAmounts getAllCompoundAspects(int amount) {
        if (amount <= 0) {
            throw new IllegalArgumentException("All-aspect amount must be positive");
        }
        AspectRegistryView snapshot = AspectApi.registry();
        return cachedAspects(snapshot, amount, true);
    }

    private static AspectAmounts cachedAspects(AspectRegistryView snapshot, int amount, boolean compoundsOnly) {
        synchronized (ASPECT_CACHE_LOCK) {
            if (aspectCacheGeneration != snapshot.generation()) {
                ALL_ASPECTS.clear();
                ALL_COMPOUND_ASPECTS.clear();
                aspectCacheGeneration = snapshot.generation();
            }
            LinkedHashMap<Integer, AspectAmounts> cache = compoundsOnly ? ALL_COMPOUND_ASPECTS : ALL_ASPECTS;
            AspectAmounts cached = cache.get(amount);
            if (cached != null) {
                return cached;
            }
            LinkedHashMap<AspectId, Integer> result = new LinkedHashMap<>();
            snapshot.definitions().forEach((aspect, definition) -> {
                if (!compoundsOnly || !definition.primal()) {
                    result.put(aspect, amount);
                }
            });
            AspectAmounts created = new AspectAmounts(result);
            cache.put(amount, created);
            while (cache.size() > MAX_ASPECT_CACHE_ENTRIES) {
                cache.remove(cache.keySet().iterator().next());
            }
            return created;
        }
    }

    public static VisPaymentResult consumeVisFromWand(ItemStack wand, Player player, VisCost cost, VisAction action, VisConsumptionContext context) {
        return WandPayments.consumeVisFromWand(wand, player, cost, action, context);
    }

    /**
     * Pays a base Vis cost for a loaded server-side machine, applying the
     * wand's cap and sceptre modifiers without requiring a synthetic player.
     */
    public static VisPaymentResult consumeVisFromWand(ItemStack wand, WandMachineContext machine, VisCost cost, VisAction action, VisConsumptionContext context) {
        return WandPayments.consumeVisFromWand(wand, machine, cost, action, context);
    }

    /**
     * Pays an already-discounted, exact centivis cost atomically.
     * Callers that still have a base cost should use
     * {@link #consumeVisFromWand} so the consumption context is applied once.
     */
    public static VisPaymentResult consumeExactVisFromWand(ItemStack wand, Player player, Map<VisChannel, Integer> centivisCost, VisAction action) {
        return WandPayments.consumeExactVisFromWand(wand, player, centivisCost, action);
    }

    /**
     * Exact typed counterpart for already-discounted transaction plans.
     */
    public static VisPaymentResult consumeExactVisFromWand(ItemStack wand, Player player, VisCost rawCost, VisAction action) {
        return WandPayments.consumeExactVisFromWand(wand, player, rawCost, action);
    }

    public static VisPaymentResult consumeVisFromInventory(Player player, VisCost cost, VisAction action) {
        return WandPayments.consumeVisFromInventory(player, cost, action);
    }

    /**
     * Pays the largest accepted single-channel base cost up to the smaller of
     * {@code maximum} and {@link #MAX_PARTIAL_VIS_REQUEST}
     * from the normal ordered inventory sources. Returns paid base centivis;
     * wand discounts and single-source payment rules remain unchanged. The bounded
     * descending search supports providers with non-monotonic acceptance.
     */
    public static int consumeUpToVisFromInventory(Player player, VisChannel channel, int maximum) {
        return dev.tc4port.thaumcraft.common.VisStorage.consumeUpToFromInventory(player, channel, maximum);
    }

    /**
     * Mutates authoritative player Warp on the logical server.
     */
    public static void addWarpToPlayer(ServerPlayer player, int amount, boolean temporary) {
        if (temporary) {
            PlayerKnowledgeService.addTemporaryWarp(player, amount);
        } else {
            PlayerKnowledgeService.addPermanentWarp(player, amount);
        }
    }

    /**
     * Mutates authoritative sticky Warp on the logical server.
     */
    public static void addStickyWarpToPlayer(ServerPlayer player, int amount) {
        PlayerKnowledgeService.addStickyWarp(player, amount);
    }

    /**
     * Ray trace that deliberately starts just beyond the source voxel. This
     * preserves the source helper's defining omission while delegating modern
     * collision/fluid shapes to the 1.21 engine.
     */
    @Nullable
    public static BlockHitResult rayTraceIgnoringSource(Level level, Vec3 from, Vec3 to, boolean stopOnFluid, boolean ignoreBlocksWithoutBoundingBox, boolean returnLastMiss) {
        if (!finite(from) || !finite(to) || BlockPos.containing(from).equals(BlockPos.containing(to))) {
            return null;
        }
        Vec3 start = advanceBeyondSourceVoxel(from, to);
        BlockPos first = BlockPos.containing(start);
        BlockPos last = BlockPos.containing(to);
        if (!level.hasChunksAt(Math.min(first.getX(), last.getX()), Math.min(first.getZ(), last.getZ()), Math.max(first.getX(), last.getX()), Math.max(first.getZ(), last.getZ()))) {
            return null;
        }
        BlockHitResult result = level.clip((switch(0) {
            default ->
                {
                    net.minecraft.world.phys.Vec3 native$operand$13270 = start;
                    net.minecraft.world.phys.Vec3 native$operand$13271 = to;
                    net.minecraft.world.level.ClipContext.Block native$operand$13272 = ignoreBlocksWithoutBoundingBox ? ClipContext.Block.COLLIDER : ClipContext.Block.OUTLINE;
                    net.minecraft.world.level.ClipContext.Fluid native$operand$13273 = stopOnFluid ? ClipContext.Fluid.ANY : ClipContext.Fluid.NONE;
                    net.minecraft.world.level.ClipContext native$result$13274 = (new net.minecraft.world.level.ClipContext(native$operand$13270, native$operand$13271, native$operand$13272, native$operand$13273, null));
                    yield native$result$13274;
                }
        }));
        return result.getType() != HitResult.Type.MISS || returnLastMiss ? result : null;
    }

    private static Vec3 advanceBeyondSourceVoxel(Vec3 from, Vec3 to) {
        Vec3 delta = to.subtract(from);
        BlockPos source = BlockPos.containing(from);
        double fraction = 1.0;
        if (delta.x != 0.0) {
            double boundary = delta.x > 0.0 ? source.getX() + 1.0 : source.getX();
            fraction = Math.min(fraction, (boundary - from.x) / delta.x);
        }
        if (delta.y != 0.0) {
            double boundary = delta.y > 0.0 ? source.getY() + 1.0 : source.getY();
            fraction = Math.min(fraction, (boundary - from.y) / delta.y);
        }
        if (delta.z != 0.0) {
            double boundary = delta.z > 0.0 ? source.getZ() + 1.0 : source.getZ();
            fraction = Math.min(fraction, (boundary - from.z) / delta.z);
        }
        double epsilon = 1.0E-7 / Math.max(delta.length(), 1.0E-7);
        return from.add(delta.scale(Math.min(1.0, fraction + epsilon)));
    }

    private static boolean finite(Vec3 vector) {
        return Double.isFinite(vector.x) && Double.isFinite(vector.y) && Double.isFinite(vector.z);
    }

    static private boolean native$ItemIdentity$matchesRequirements(net.minecraft.world.item.ItemStack actual, net.minecraft.world.item.ItemStack expected, boolean ignoreDamage) {
        net.minecraft.nbt.CompoundTag required = expected.getTag(), present = actual.getTag();
        if (required == null)
            return true;
        for (java.lang.String key : required.getAllKeys()) {
            if (ignoreDamage && key.equals("Damage"))
                continue;
            if (present == null || !java.util.Objects.equals(required.get(key), present.get(key)))
                return false;
        }
        return true;
    }
}
