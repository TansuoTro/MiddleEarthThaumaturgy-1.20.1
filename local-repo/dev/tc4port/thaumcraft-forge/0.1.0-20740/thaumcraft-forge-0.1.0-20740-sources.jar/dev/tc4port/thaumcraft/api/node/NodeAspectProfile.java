package dev.tc4port.thaumcraft.api.node;

/**
 * Closed built-in profile used only when generating a node's initial Vis.
 */
public enum NodeAspectProfile {

    NORMAL, HUNGRY, PURE, DARK
}
