package dev.tc4port.thaumcraft.api.research;

/**
 * Stable public identity for TC4's server research progression mode.
 */
public enum ResearchDifficulty {

    EASY(-1), NORMAL(0), HARD(1);

    private final int legacyValue;

    ResearchDifficulty(int legacyValue) {
        this.legacyValue = legacyValue;
    }

    /**
     * Returns the original TC4 configuration value.
     */
    public int legacyValue() {
        return this.legacyValue;
    }

    static ResearchDifficulty fromLegacyValue(int value) {
        return switch(value) {
            case -1 ->
                EASY;
            case 0 ->
                NORMAL;
            case 1 ->
                HARD;
            default ->
                throw new IllegalStateException("Invalid TC4 research difficulty: " + value);
        };
    }
}
