package dev.tc4port.thaumcraft.api.focus.action;

import dev.tc4port.thaumcraft.api.focus.FocusStateView;
import dev.tc4port.thaumcraft.api.focus.FocusUpgradeId;
import java.util.Map;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.HitResult;

/**
 * Read-only inputs available after simulation and before Vis is debited.
 */
public interface FocusAuthorizationContext {

    ServerPlayer player();

    InteractionHand hand();

    /**
     * A defensive copy of the current wand.
     */
    ItemStack wand();

    FocusStateView installedFocus();

    Map<FocusUpgradeId, Integer> installedUpgrades();

    default double parameter(String key) {
        return dev.tc4port.thaumcraft.api.focus.FocusApi.registry().profile(installedFocus().focusId()).orElseThrow().parameters().value(key, installedUpgrades());
    }

    FocusActivation activation();

    HitResult authoritativeHit();

    int useTicks();
}
