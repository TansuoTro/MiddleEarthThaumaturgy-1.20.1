package dev.tc4port.thaumcraft.api.recipe;

import dev.tc4port.thaumcraft.api.Registration;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Objects;
import net.minecraft.core.HolderLookup;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.ItemStack;

/**
 * Registry for deterministic, namespaced addon infusion stack patches.
 */
public final class InfusionInputPatchApi {

    private static final Map<ResourceLocation, InfusionInputPatch> PATCHES = new LinkedHashMap<>();

    private InfusionInputPatchApi() {
    }

    /**
     * Registers one addon-owned {@code input_patch} key.
     *
     * <p>The ID must be explicitly namespaced and must not use the
     * {@code minecraft} or {@code thaumcraft} namespaces, which are reserved
     * for built-in recipe semantics. Install the same registration during
     * common mod construction on both physical sides and retain the returned
     * handle for the complete mod lifetime.</p>
     */
    public static Registration register(ResourceLocation id, InfusionInputPatch patch) {
        Objects.requireNonNull(id, "id");
        Objects.requireNonNull(patch, "patch");
        if (id.getNamespace().equals(ResourceLocation.DEFAULT_NAMESPACE) || id.getNamespace().equals("thaumcraft")) {
            throw new IllegalArgumentException("Addon infusion patch uses reserved namespace: " + id);
        }
        synchronized (PATCHES) {
            if (PATCHES.putIfAbsent(id, patch) != null) {
                throw new IllegalArgumentException("Duplicate infusion input patch: " + id);
            }
        }
        return Registration.of(() -> {
            synchronized (PATCHES) {
                PATCHES.remove(id, patch);
            }
        });
    }

    /**
     * Validates a namespaced extension value during recipe decoding.
     */
    public static void validate(ResourceLocation id, int value, int componentCount) {
        find(id).validate(value, componentCount);
    }

    /**
     * Applies a previously validated extension to a copied central or peripheral stack.
     */
    public static void apply(ResourceLocation id, ItemStack output, int value, HolderLookup.Provider registries) {
        Objects.requireNonNull(output, "output");
        Objects.requireNonNull(registries, "registries");
        find(id).apply(output, value, registries);
    }

    private static InfusionInputPatch find(ResourceLocation id) {
        Objects.requireNonNull(id, "id");
        synchronized (PATCHES) {
            InfusionInputPatch patch = PATCHES.get(id);
            if (patch == null) {
                throw new IllegalArgumentException("Unregistered infusion input patch: " + id);
            }
            return patch;
        }
    }
}
