package dev.tc4port.thaumcraft.block.entity;

import dev.tc4port.thaumcraft.nativeimpl.EnchantmentKeys;
import dev.tc4port.thaumcraft.common.MachineItemOutput;
import dev.tc4port.thaumcraft.common.TCGameplayParameters;
import dev.tc4port.thaumcraft.api.aspect.AspectId;
import dev.tc4port.thaumcraft.api.aspect.VisChannel;
import com.mojang.authlib.GameProfile;
import dev.tc4port.thaumcraft.block.ArcaneBoreBlock;
import dev.tc4port.thaumcraft.common.ArcaneBoreHarvest;
import dev.tc4port.thaumcraft.common.ArcaneBoreDropModifiers;
import dev.tc4port.thaumcraft.api.machine.ArcaneBoreDropContext;
import dev.tc4port.thaumcraft.common.SpecialMiningDrops;
import dev.tc4port.thaumcraft.common.RepairSystem;
import dev.tc4port.thaumcraft.common.VisNetwork;
import dev.tc4port.thaumcraft.api.focus.FocusApi;
import dev.tc4port.thaumcraft.api.focus.FocusId;
import dev.tc4port.thaumcraft.api.focus.FocusUpgradeId;
import dev.tc4port.thaumcraft.menu.ArcaneBoreMenu;
import dev.tc4port.thaumcraft.registry.TCBlockEntities;
import dev.tc4port.thaumcraft.registry.TCBlocks;
import dev.tc4port.thaumcraft.registry.TCSounds;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import javax.annotation.Nullable;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.SectionPos;
import net.minecraft.core.HolderLookup;
import net.minecraft.core.NonNullList;
import net.minecraft.core.registries.Registries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.WorldlyContainer;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.ContainerData;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.PickaxeItem;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import java.lang.Math;
import java.lang.System;
import net.minecraft.world.level.block.entity.BaseContainerBlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityType;

/**
 * TC4's autonomous Arcane Bore, translated without flattening its state
 * machine into vanilla block breaking.
 */
public final class ArcaneBoreBlockEntity extends net.minecraft.world.level.block.entity.BaseContainerBlockEntity implements WorldlyContainer, dev.tc4port.thaumcraft.api.machine.ArcaneBoreView {

    private static final FocusUpgradeId TREASURE = FocusUpgradeId.parse("treasure");

    private static final FocusUpgradeId ENLARGE = FocusUpgradeId.parse("enlarge");

    private static final FocusUpgradeId POTENCY = FocusUpgradeId.parse("potency");

    private static final FocusUpgradeId SILK_TOUCH = FocusUpgradeId.parse("silktouch");

    private static final FocusUpgradeId DOWSING = FocusUpgradeId.parse("dowsing");

    public static final int FOCUS_SLOT = 0;

    public static final int PICKAXE_SLOT = 1;

    public static final int CONTAINER_SIZE = 2;

    public static final int BASE_RADIUS = 2;

    public static final int SEARCH_DEPTH = 64;

    private static final int[] ALL_SLOTS = { FOCUS_SLOT, PICKAXE_SLOT };

    private static final GameProfile BORE_PROFILE = new GameProfile(UUID.fromString("7edab6f7-b76a-4f1e-b475-1fd44a56dce7"), "FakeThaumcraftBore");

    private NonNullList<ItemStack> items = NonNullList.withSize(CONTAINER_SIZE, ItemStack.EMPTY);

    private final LinkedHashMap<AspectId, Integer> repairCost = new LinkedHashMap<>();

    private final LinkedHashMap<AspectId, Integer> currentRepairVis = new LinkedHashMap<>();

    private int spiral;

    private float currentRadius;

    private float radiusIncrement;

    private BlockPos lastSpiralPos = BlockPos.ZERO;

    @Nullable
    private BlockPos digPos;

    private boolean pendingDig;

    private int digCountdown;

    private int digDuration = 1;

    @Nullable
    private BlockPos breakProgressPos;

    private int blockCount;

    private float speedyTime;

    private long repairCounter;

    private List<RepairSystem.Active> repairEffects = List.of();

    private boolean baseDiscovered;

    private boolean hasFocus;

    private boolean hasPickaxe;

    private int fortune;

    private int speed;

    private int area;

    private boolean silkTouch;

    private boolean nativeClusters;

    private int rotX;

    private int rotZ;

    private int targetRotX;

    private int targetRotZ;

    private int rotationSpeedX;

    private int rotationSpeedZ;

    private Direction appliedFacing = Direction.UP;

    private int paused = 100;

    private int maxPause = 100;

    private int beamLength;

    private int topRotation;

    private float visibleRadX;

    private float visibleRadZ;

    private float targetRadX;

    private float targetRadZ;

    private float motionRadX;

    private float motionRadZ;

    private long soundDelay;

    private long focusCatalogGeneration = Long.MIN_VALUE;

    private long lastParticleGameTime = Long.MIN_VALUE;

    private long lastClientAnimationGameTime = Long.MIN_VALUE;

    private final ContainerData data = new ContainerData() {

        @Override
        public int get(int index) {
            return switch(index) {
                case 0 ->
                    ArcaneBoreBlockEntity.this.area;
                case 1 ->
                    ArcaneBoreBlockEntity.this.speed;
                case 2 ->
                    ArcaneBoreBlockEntity.this.fortune;
                case 3 ->
                    ArcaneBoreBlockEntity.this.silkTouch ? 1 : 0;
                case 4 ->
                    ArcaneBoreBlockEntity.this.nativeClusters ? 1 : 0;
                case 5 ->
                    Math.round(ArcaneBoreBlockEntity.this.speedyTime * 100.0F);
                default ->
                    0;
            };
        }

        @Override
        public void set(int index, int value) {
            switch(index) {
                case 0 ->
                    ArcaneBoreBlockEntity.this.area = value;
                case 1 ->
                    ArcaneBoreBlockEntity.this.speed = value;
                case 2 ->
                    ArcaneBoreBlockEntity.this.fortune = value;
                case 3 ->
                    ArcaneBoreBlockEntity.this.silkTouch = value != 0;
                case 4 ->
                    ArcaneBoreBlockEntity.this.nativeClusters = value != 0;
                case 5 ->
                    ArcaneBoreBlockEntity.this.speedyTime = value / 100.0F;
                default ->
                    {
                    }
            }
        }

        @Override
        public int getCount() {
            return 6;
        }
    };

    public ArcaneBoreBlockEntity(BlockPos pos, BlockState state) {
        super(TCBlockEntities.ARCANE_BORE.get(), pos, state);
        this.applyOrientation(true);
    }

    public static void serverTick(Level level, BlockPos pos, BlockState state, ArcaneBoreBlockEntity bore) {
        if (!(level instanceof ServerLevel serverLevel)) {
            return;
        }
        bore.refreshFocusCatalog();
        bore.chargeSpeedReserve(serverLevel);
        bore.updateMountRotation();
        if (bore.isPowered() && bore.hasValidItems()) {
            bore.digServer(serverLevel);
        } else {
            bore.clearBreakProgress(serverLevel);
        }
        bore.tickRepair(serverLevel);
    }

    public static void clientTick(Level level, BlockPos pos, BlockState state, ArcaneBoreBlockEntity bore) {
        bore.advanceClientAnimation(level.getGameTime());
    }

    /**
     * Keeps renderer-visible client animation alive when an alternate level
     * renders this block entity without invoking its registered ticker.
     * Normal ticking and this render fallback share the same per-tick guard.
     */
    public void prepareClientAnimationForRender(long gameTime) {
        this.advanceClientAnimation(gameTime);
    }

    private void advanceClientAnimation(long gameTime) {
        if (this.lastClientAnimationGameTime == gameTime) {
            return;
        }
        this.lastClientAnimationGameTime = gameTime;
        this.refreshFocusCatalog();
        this.updateMountRotation();
        if (this.isPowered() && this.hasValidItems()) {
            this.digClient();
        } else {
            this.parkClientAnimation();
        }
    }

    private void chargeSpeedReserve(ServerLevel level) {
        if (this.speedyTime >= 20.0F) {
            return;
        }
        this.speedyTime += VisNetwork.drain(level, this.worldPosition, VisChannel.PERDITIO, 100) / 5.0F;
        if (this.speedyTime < 20.0F && this.baseDiscovered && this.base() != null && this.base().drawEssentia()) {
            this.speedyTime += 20.0F;
        }
    }

    private void tickRepair(ServerLevel level) {
        if (!this.hasPickaxe || this.items.get(PICKAXE_SLOT).isEmpty()) {
            this.repairCost.clear();
            this.repairEffects = List.of();
            return;
        }
        ItemStack tool = this.items.get(PICKAXE_SLOT);
        net.minecraft.server.level.ServerPlayer fakePlayer = (switch(0) {
            default ->
                {
                    net.minecraft.server.level.ServerLevel native$operand$13645 = level;
                    com.mojang.authlib.GameProfile native$operand$13646 = BORE_PROFILE;
                    net.minecraft.server.level.ServerPlayer native$result$13647 = (net.minecraftforge.common.util.FakePlayerFactory.get(native$operand$13645, native$operand$13646));
                    yield native$result$13647;
                }
        });
        var effects = RepairSystem.isRepairable(tool) ? RepairSystem.active(tool, fakePlayer, net.minecraft.world.entity.EquipmentSlot.MAINHAND) : List.<RepairSystem.Active>of();
        if (!effects.equals(this.repairEffects)) {
            this.repairCost.clear();
            this.repairEffects = effects;
        }
        long tick = this.repairCounter++;
        if (tool.isDamaged() && effects.stream().anyMatch(effect -> effect.due(tick))) {
            // Recalculate the reserve target so changed data or equipment cannot retain an old price.
            this.repairCost.clear();
            for (var active : effects) {
                Map<AspectId, Integer> cost = active.cost(tool);
                cost.forEach((aspect, amount) -> this.repairCost.merge(aspect, amount, Math::max));
                if (active.due(tick) && !cost.isEmpty())
                    this.tryRepair(tool, fakePlayer, active, cost);
            }
        }
        int chargeInterval = effects.stream().mapToInt(active -> active.effect().boreChargeIntervalTicks()).min().orElse(1);
        if (!this.repairCost.isEmpty() && this.repairCounter % chargeInterval == 0) {
            for (var cost : this.repairCost.entrySet()) {
                int current = this.currentRepairVis.getOrDefault(cost.getKey(), 0);
                if (current < cost.getValue()) {
                    int drained = VisChannel.fromAspectId(cost.getKey()).map(channel -> VisNetwork.drain(level, this.worldPosition, channel, cost.getValue() - current)).orElse(0);
                    this.currentRepairVis.merge(cost.getKey(), drained, Integer::sum);
                }
            }
        }
        fakePlayer.tickCount = (int) this.repairCounter;
        try {
            tool.inventoryTick(level, fakePlayer, 0, true);
        } catch (RuntimeException ignored) {
            // TC4 deliberately isolated third-party item tick failures here.
        }
    }

    private void tryRepair(ItemStack tool, net.minecraft.server.level.ServerPlayer fakePlayer, RepairSystem.Active active, Map<AspectId, Integer> cost) {
        // Keep the addon veto before checking or consuming the bore's accumulated vis.
        if (!tool.isDamaged() || !RepairSystem.permitsRepair(tool, fakePlayer, active))
            return;
        for (var entry : cost.entrySet()) {
            if (this.currentRepairVis.getOrDefault(entry.getKey(), 0) < entry.getValue())
                return;
        }
        cost.forEach((aspect, amount) -> this.currentRepairVis.compute(aspect, (ignored, current) -> Math.max(0, (current == null ? 0 : current) - amount)));
        RepairSystem.restoreDurability(tool, active);
        this.changedAndSync();
    }

    private void digServer(ServerLevel level) {
        if (this.rotX != this.targetRotX || this.rotZ != this.targetRotZ) {
            this.clearBreakProgress(level);
            return;
        }
        /*
         * The legacy tile did not cache its base until dig() was first
         * entered. Consequently an assembled but never-started bore could
         * drain aura vis, but could not consume the base's Perditio yet.
         */
        this.baseDiscovered = true;
        if (--this.digCountdown > 0) {
            this.publishBreakProgress(level);
            return;
        }
        boolean dug = false;
        if (this.pendingDig && this.digPos != null) {
            this.clearBreakProgress(level);
            this.pendingDig = false;
            dug = this.breakTarget(level, this.digPos);
        }
        this.findNextBlockToDig(level);
        if (dug && this.speedyTime > 0.0F) {
            this.speedyTime--;
        }
    }

    private boolean breakTarget(ServerLevel level, BlockPos target) {
        if (!level.hasChunk(SectionPos.blockToSectionCoord(target.getX()), SectionPos.blockToSectionCoord(target.getZ()))) {
            return false;
        }
        BlockState state = level.getBlockState(target);
        ItemStack installedTool = this.items.get(PICKAXE_SLOT);
        net.minecraft.server.level.ServerPlayer fakePlayer = (switch(0) {
            default ->
                {
                    net.minecraft.server.level.ServerLevel native$operand$13648 = level;
                    com.mojang.authlib.GameProfile native$operand$13649 = BORE_PROFILE;
                    net.minecraft.server.level.ServerPlayer native$result$13650 = (net.minecraftforge.common.util.FakePlayerFactory.get(native$operand$13648, native$operand$13649));
                    yield native$result$13650;
                }
        });
        if (!state.isAir()) {
            ItemStack harvestTool = this.harvestTool(level, installedTool);
            var context = new ArcaneBoreDropContext(level, this.worldPosition, target, state, harvestTool, this.silkTouch ? 0 : this.fortune, this.silkTouch);
            boolean dowsing = FocusApi.installedState(this.items.get(FOCUS_SLOT)).map(focus -> focus.level(DOWSING) > 0).orElse(false);
            var result = ArcaneBoreHarvest.mine(fakePlayer, target, this.facing(), harvestTool, dowsing);
            this.restoreFocusEnchantments(level, installedTool, result.tool());
            this.items.set(PICKAXE_SLOT, result.tool());
            if (!result.destroyed()) {
                // Native break cancellation/removal veto must not be followed by setBlock(AIR).
                for (ItemStack drop : result.drops()) this.output(level, drop);
                this.changedAndSync();
                return false;
            }
            List<ItemStack> drops = result.drops();
            ArcaneBoreDropModifiers.apply(context, drops);
            for (ItemEntity entity : level.getEntitiesOfClass(ItemEntity.class, new AABB(target).inflate(1.0))) {
                drops.add(entity.getItem().copy());
                entity.discard();
            }
            for (ItemStack drop : drops) this.output(level, drop);
            // Keep the two completion bursts only after this Bore actually harvested the target.
            for (int pass = 0; pass < 2; pass++) this.sendCompletionDebris(level, target, state);
        } else {
            // Preserve the bore's queued-target race cost; native mining owns normal tool damage.
            dev.tc4port.thaumcraft.block.entity.ArcaneBoreBlockEntity.native$subscription$11248(installedTool, 1, level, fakePlayer);
            if (installedTool.isEmpty())
                this.items.set(PICKAXE_SLOT, ItemStack.EMPTY);
        }
        this.placeArcaneLampLight(level);
        this.changedAndSync();
        return true;
    }

    private void sendCompletionDebris(ServerLevel level, BlockPos source, BlockState state) {
        if (state.isAir())
            return;
        var payload = new dev.tc4port.thaumcraft.network.BoreDigPayload(this.worldPosition, source, Block.getId(state));
        var center = Vec3.atCenterOf(this.worldPosition);
        for (var player : level.players()) {
            if (player.distanceToSqr(center) <= 64.0 * 64.0) {
                dev.tc4port.thaumcraft.network.TCPayloads.CHANNEL.sendToPlayer(player, payload);
            }
        }
    }

    private void restoreFocusEnchantments(ServerLevel level, ItemStack original, ItemStack result) {
        if (result.isEmpty() || result.getItem() != original.getItem())
            return;
        var enchantments = level.registryAccess().lookupOrThrow(Registries.ENCHANTMENT);
        var fortune = enchantments.getOrThrow(EnchantmentKeys.FORTUNE);
        var silk = enchantments.getOrThrow(EnchantmentKeys.SILK_TOUCH);
        int originalFortune = dev.tc4port.thaumcraft.nativeimpl.EnchantmentPlatform.level(original, fortune);
        int originalSilk = dev.tc4port.thaumcraft.nativeimpl.EnchantmentPlatform.level(original, silk);
        dev.tc4port.thaumcraft.nativeimpl.EnchantmentPlatform.update(result, mutable -> {
            mutable.set(fortune, originalFortune);
            mutable.set(silk, originalSilk);
        });
    }

    private ItemStack harvestTool(ServerLevel level, ItemStack installedTool) {
        ItemStack result = installedTool.copy();
        var enchantments = level.registryAccess().lookupOrThrow(Registries.ENCHANTMENT);
        var fortuneEnchantment = enchantments.getOrThrow(EnchantmentKeys.FORTUNE);
        var silkEnchantment = enchantments.getOrThrow(EnchantmentKeys.SILK_TOUCH);
        dev.tc4port.thaumcraft.nativeimpl.EnchantmentPlatform.update(result, mutable -> {
            if (this.silkTouch) {
                mutable.set(silkEnchantment, 1);
                mutable.removeIf(holder -> holder.equals(fortuneEnchantment));
            } else if (this.fortune > mutable.getLevel(fortuneEnchantment)) {
                mutable.set(fortuneEnchantment, this.fortune);
            }
        });
        return result;
    }

    private void output(ServerLevel level, ItemStack stack) {
        if (stack.isEmpty()) {
            return;
        }
        ArcaneBoreBaseBlockEntity base = this.base();
        if (base == null) {
            return;
        }
        Direction output = base.outputDirection();
        net.minecraftforge.items.IItemHandler destination = MachineItemOutput.destination(level, base.getBlockPos().relative(output), output.getOpposite());
        ItemStack remainder = destination == null ? stack.copy() : net.minecraftforge.items.ItemHandlerHelper.insertItemStacked((net.minecraftforge.items.IItemHandler) (destination), (net.minecraft.world.item.ItemStack) (stack.copy()), (boolean) (false));
        if (remainder.isEmpty()) {
            return;
        }
        Direction baseDirection = this.baseDirection();
        ItemEntity entity = new ItemEntity(level, this.worldPosition.getX() + 0.5 + output.getStepX() * 0.66, this.worldPosition.getY() + 0.4 + baseDirection.getOpposite().getStepY(), this.worldPosition.getZ() + 0.5 + output.getStepZ() * 0.66, remainder);
        entity.setDeltaMovement(0.075F * output.getStepX(), 0.025F, 0.075F * output.getStepZ());
        level.addFreshEntity(entity);
    }

    private void findNextBlockToDig(ServerLevel level) {
        if (this.radiusIncrement == 0.0F) {
            this.radiusIncrement = (TCGameplayParameters.MACHINES_ARCANE_BORE_BASE_RADIUS.intValue() + this.area) / 360.0F;
        }
        BlockPos spiralPos = this.lastSpiralPos;
        while (spiralPos.equals(this.lastSpiralPos)) {
            this.spiral += 2;
            if (this.spiral >= 360) {
                this.spiral -= 360;
            }
            this.currentRadius += this.radiusIncrement;
            int radius = TCGameplayParameters.MACHINES_ARCANE_BORE_BASE_RADIUS.intValue() + this.area;
            if (this.currentRadius > radius || this.currentRadius < -radius) {
                this.radiusIncrement *= -1.0F;
            }
            spiralPos = this.spiralPosition();
        }
        this.lastSpiralPos = spiralPos;
        Direction facing = this.facing();
        BlockPos cursor = spiralPos.relative(facing);
        for (int depth = 0; depth < TCGameplayParameters.MACHINES_ARCANE_BORE_SEARCH_DEPTH.intValue(); depth++) {
            cursor = cursor.relative(facing);
            if (!level.hasChunk(SectionPos.blockToSectionCoord(cursor.getX()), SectionPos.blockToSectionCoord(cursor.getZ()))) {
                break;
            }
            BlockState state = level.getBlockState(cursor);
            float hardness = state.getDestroySpeed(level, cursor);
            if (hardness < 0.0F) {
                break;
            }
            if (state.isAir() || state.getCollisionShape(level, cursor).isEmpty()) {
                continue;
            }
            BlockPos selected = this.nearestCollider(level, cursor);
            if (selected == null)
                break;
            BlockState selectedState = level.getBlockState(selected);
            this.digPos = selected.immutable();
            if (++this.blockCount > 2) {
                this.blockCount = 0;
            }
            this.digCountdown = this.breakDelay(selectedState.getDestroySpeed(level, selected));
            this.digDuration = Math.max(1, this.digCountdown);
            this.pendingDig = true;
            this.publishBreakProgress(level);
            this.changedAndSync();
            break;
        }
    }

    private void publishBreakProgress(ServerLevel level) {
        if (!this.pendingDig || this.digPos == null) {
            this.clearBreakProgress(level);
            return;
        }
        if (this.breakProgressPos != null && !this.breakProgressPos.equals(this.digPos)) {
            level.destroyBlockProgress(this.breakProgressId(), this.breakProgressPos, -1);
        }
        this.breakProgressPos = this.digPos;
        int remaining = Math.max(0, this.digCountdown);
        int elapsed = Math.max(0, this.digDuration - remaining);
        int stage = Math.min(9, (int) ((long) elapsed * 10L / this.digDuration));
        level.destroyBlockProgress(this.breakProgressId(), this.digPos, stage);
    }

    private void clearBreakProgress(ServerLevel level) {
        if (this.breakProgressPos == null) {
            return;
        }
        level.destroyBlockProgress(this.breakProgressId(), this.breakProgressPos, -1);
        this.breakProgressPos = null;
    }

    private int breakProgressId() {
        /*
         * ServerLevel excludes the entity whose id matches the breaker. A
         * stable negative id cannot hide this machine-owned overlay from a
         * nearby player, while the lower 31 position bits distinguish bores
         * within the level without introducing persistent state.
         */
        return -1 - (this.worldPosition.hashCode() & Integer.MAX_VALUE);
    }

    @Nullable
    private BlockPos nearestCollider(ServerLevel level, BlockPos candidate) {
        Vec3 start = Vec3.atCenterOf(this.worldPosition.relative(this.facing()));
        Vec3 end = Vec3.atCenterOf(candidate);
        if (!level.hasChunksAt(BlockPos.containing(Math.min(start.x, end.x), Math.min(start.y, end.y), Math.min(start.z, end.z)), BlockPos.containing(Math.max(start.x, end.x), Math.max(start.y, end.y), Math.max(start.z, end.z)))) {
            return null;
        }
        net.minecraft.server.level.ServerPlayer fakePlayer = (switch(0) {
            default ->
                {
                    net.minecraft.server.level.ServerLevel native$operand$13651 = level;
                    com.mojang.authlib.GameProfile native$operand$13652 = BORE_PROFILE;
                    net.minecraft.server.level.ServerPlayer native$result$13653 = (net.minecraftforge.common.util.FakePlayerFactory.get(native$operand$13651, native$operand$13652));
                    yield native$result$13653;
                }
        });
        BlockHitResult hit = level.clip(new ClipContext(start, end, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, fakePlayer));
        if (hit.getType() != HitResult.Type.BLOCK) {
            return candidate;
        }
        BlockPos hitPos = hit.getBlockPos();
        BlockState hitState = level.getBlockState(hitPos);
        return hitState.getDestroySpeed(level, hitPos) > -1.0F && !hitState.getCollisionShape(level, hitPos).isEmpty() ? hitPos : candidate;
    }

    private BlockPos spiralPosition() {
        Direction facing = this.facing();
        double angle = this.spiral / 180.0 * Math.PI;
        double x = this.currentRadius * Math.sin(angle);
        double y = this.currentRadius * Math.cos(angle);
        double z = 0.0;
        double yaw = Math.PI / 2.0 * facing.getStepX();
        double rotatedX = x * Math.cos(yaw) + z * Math.sin(yaw);
        double rotatedZ = z * Math.cos(yaw) - x * Math.sin(yaw);
        x = rotatedX;
        z = rotatedZ;
        double pitch = Math.PI / 2.0 * facing.getStepY();
        double rotatedY = y * Math.cos(pitch) + z * Math.sin(pitch);
        rotatedZ = z * Math.cos(pitch) - y * Math.sin(pitch);
        Vec3 source = Vec3.atCenterOf(this.worldPosition.relative(facing));
        return BlockPos.containing(source.x + x, source.y + rotatedY, source.z + rotatedZ);
    }

    private int breakDelay(float hardness) {
        long delay = Math.max((long) TCGameplayParameters.MACHINES_ARCANE_BORE_BASE_BREAK_TICKS.intValue() - this.speed, (long) (int) (hardness * TCGameplayParameters.MACHINES_ARCANE_BORE_HARDNESS_TICKS.floatValue()) - (long) this.speed * TCGameplayParameters.MACHINES_ARCANE_BORE_SPEED_TICKS.intValue());
        return (int) Math.min(Integer.MAX_VALUE, this.speedyTime < 1.0F ? delay * TCGameplayParameters.MACHINES_ARCANE_BORE_UNPOWERED_DELAY_MULTIPLIER.intValue() : delay);
    }

    private void placeArcaneLampLight(ServerLevel level) {
        ArcaneBoreBaseBlockEntity base = this.base();
        if (base == null) {
            return;
        }
        boolean lamp = false;
        for (Direction direction : Direction.Plane.HORIZONTAL) {
            BlockPos lampPos = base.getBlockPos().relative(direction);
            if (level.isLoaded(lampPos) && level.getBlockState(lampPos).is(TCBlocks.byId("arcane_lamp").get())) {
                lamp = true;
                break;
            }
        }
        if (!lamp) {
            return;
        }
        Direction facing = this.facing();
        int distance = level.random.nextInt(32) * 2;
        BlockPos lightPos = this.worldPosition.relative(facing, distance + 1);
        int pattern = distance / 2 % 4;
        if (facing.getStepX() != 0) {
            lightPos = lightPos.offset(0, 0, pattern == 0 ? 3 : pattern == 2 ? -3 : 0);
        } else {
            lightPos = lightPos.offset(pattern == 0 ? 3 : pattern == 2 ? -3 : 0, 0, 0);
        }
        if (pattern == 3 && facing.getStepY() == 0) {
            lightPos = lightPos.below(2);
        }
        if (!level.isLoaded(lightPos))
            return;
        BlockState lightState = level.getBlockState(lightPos);
        if (lightState.isAir() && !isLegacyAiry(lightState) && level.getRawBrightness(lightPos, 0) < 15) {
            level.setBlock(lightPos, TCBlocks.GLIMMER_OF_LIGHT_DIM.get().defaultBlockState(), Block.UPDATE_ALL);
        }
    }

    private static boolean isLegacyAiry(BlockState state) {
        return state.is(TCBlocks.GLIMMER_OF_LIGHT.get()) || state.is(TCBlocks.GLIMMER_OF_LIGHT_DIM.get()) || state.is(TCBlocks.byId("static_field").get()) || state.is(TCBlocks.byId("sapping_field").get()) || state.is(TCBlocks.SHOCK_AIR.get());
    }

    private void digClient() {
        this.paused++;
        long now = System.currentTimeMillis();
        if (this.paused < this.maxPause && this.soundDelay < now && this.level != null) {
            this.soundDelay = now + 1200L + this.level.random.nextInt(100);
            this.level.playLocalSound(this.worldPosition, TCSounds.BORE_WORK.get(), SoundSource.BLOCKS, 0.25F, 0.9F + this.level.random.nextFloat() * 0.2F, false);
        }
        if (this.pendingDig && this.digPos != null && this.level != null) {
            this.paused = 0;
            this.beamLength = clientBeamLength(this.worldPosition, this.digPos);
            float hardness = this.level.getBlockState(this.digPos).getDestroySpeed(this.level, this.digPos);
            long pause = 10L + Math.max((long) TCGameplayParameters.MACHINES_ARCANE_BORE_BASE_BREAK_TICKS.intValue() - this.speed, (long) (int) (hardness * TCGameplayParameters.MACHINES_ARCANE_BORE_HARDNESS_TICKS.floatValue()) - (long) this.speed * TCGameplayParameters.MACHINES_ARCANE_BORE_SPEED_TICKS.intValue());
            this.maxPause = (int) Math.min(Integer.MAX_VALUE, this.speedyTime <= 0.0F ? pause * TCGameplayParameters.MACHINES_ARCANE_BORE_UNPOWERED_DELAY_MULTIPLIER.intValue() : pause);
            this.pendingDig = false;
            this.updateVisibleAim(this.digPos);
            if (this.speedyTime > 0.0F) {
                this.speedyTime--;
            }
        }
        if (this.beamLength > 0 && this.paused > this.maxPause) {
            this.beamLength--;
        }
        if (this.paused < this.maxPause) {
            this.visibleRadX = approach(this.visibleRadX, this.targetRadX, this.motionRadX);
            this.visibleRadZ = approach(this.visibleRadZ, this.targetRadZ, this.motionRadZ);
        } else {
            this.visibleRadX *= 0.9F;
            this.visibleRadZ *= 0.9F;
        }
        this.motionRadX *= 0.9F;
        this.motionRadZ *= 0.9F;
        this.topRotation += this.beamLength / 6;
    }

    static int clientBeamLength(BlockPos source, BlockPos target) {
        /*
         * The old effect used SEARCH_DEPTH both as its ray budget and as its
         * visible length. Once the mined block became air, clipping stopped
         * and that hidden 64-block tail appeared for a frame sequence. Keep
         * the same maximum, but make the visible/retracting beam no longer
         * than the synchronized target ever was.
         */
        double distance = Vec3.atCenterOf(source).distanceTo(Vec3.atCenterOf(target));
        return Mth.clamp((int) Math.ceil(distance), 1, TCGameplayParameters.MACHINES_ARCANE_BORE_SEARCH_DEPTH.intValue());
    }

    private void updateVisibleAim(BlockPos target) {
        double x = this.worldPosition.getX() + 0.5 - (target.getX() + 0.5);
        double y = this.worldPosition.getY() + 0.5 - (target.getY() + 0.5);
        double z = this.worldPosition.getZ() + 0.5 - (target.getZ() + 0.5);
        double horizontal = Math.sqrt(x * x + z * z);
        float rx = (float) Math.toDegrees(Math.atan2(z, x));
        float rz = (float) -Math.toDegrees(Math.atan2(y, horizontal)) + 90.0F;
        this.targetRadX = wrapDegrees(this.rotX) + rx;
        if (this.facing() == Direction.EAST) {
            if (this.targetRadX > 180.0F) {
                this.targetRadX -= 360.0F;
            }
            if (this.targetRadX < -180.0F) {
                this.targetRadX += 360.0F;
            }
        }
        this.targetRadZ = rz - this.rotZ;
        if (this.facing().get3DDataValue() <= 1) {
            this.targetRadZ += 180.0F;
            if (this.visibleRadX - this.targetRadX >= 180.0F) {
                this.visibleRadX -= 360.0F;
            }
            if (this.visibleRadX - this.targetRadX <= -180.0F) {
                this.visibleRadX += 360.0F;
            }
        }
        this.motionRadX = Math.abs((this.visibleRadX - this.targetRadX) / 6.0F);
        this.motionRadZ = Math.abs((this.visibleRadZ - this.targetRadZ) / 6.0F);
    }

    private static float approach(float value, float target, float amount) {
        if (value < target) {
            return value + amount;
        }
        if (value > target) {
            return value - amount;
        }
        return value;
    }

    private static float wrapDegrees(float degrees) {
        float result = degrees % 360.0F;
        if (result >= 180.0F) {
            result -= 360.0F;
        }
        if (result < -180.0F) {
            result += 360.0F;
        }
        return result;
    }

    private void parkClientAnimation() {
        // The beam is client-local animation state. Stop drawing it as soon
        // as power or a usable focus/pickaxe is lost.
        this.beamLength = 0;
        if (this.topRotation % 90 != 0) {
            this.topRotation += Math.min(10, 90 - this.topRotation % 90);
        }
        this.visibleRadX *= 0.9F;
        this.visibleRadZ *= 0.9F;
    }

    private void updateMountRotation() {
        if (this.facing() != this.appliedFacing) {
            this.applyOrientation(false);
        }
        if (this.rotX < this.targetRotX) {
            this.rotX += this.rotationSpeedX;
            if (this.rotX < this.targetRotX) {
                this.rotationSpeedX++;
            } else {
                this.rotationSpeedX = (int) (this.rotationSpeedX / 3.0F);
            }
        } else if (this.rotX > this.targetRotX) {
            this.rotX += this.rotationSpeedX;
            if (this.rotX > this.targetRotX) {
                this.rotationSpeedX--;
            } else {
                this.rotationSpeedX = (int) (this.rotationSpeedX / 3.0F);
            }
        } else {
            this.rotationSpeedX = 0;
        }
        if (this.rotZ < this.targetRotZ) {
            this.rotZ += this.rotationSpeedZ;
            if (this.rotZ < this.targetRotZ) {
                this.rotationSpeedZ++;
            } else {
                this.rotationSpeedZ = (int) (this.rotationSpeedZ / 3.0F);
            }
        } else if (this.rotZ > this.targetRotZ) {
            this.rotZ += this.rotationSpeedZ;
            if (this.rotZ > this.targetRotZ) {
                this.rotationSpeedZ--;
            } else {
                this.rotationSpeedZ = (int) (this.rotationSpeedZ / 3.0F);
            }
        } else {
            this.rotationSpeedZ = 0;
        }
    }

    public void orientationChanged(boolean initial) {
        this.applyOrientation(initial);
        this.changedAndSync();
    }

    private void applyOrientation(boolean initial) {
        if (this.level instanceof ServerLevel serverLevel) {
            this.clearBreakProgress(serverLevel);
        }
        Direction orientation = this.facing();
        this.appliedFacing = orientation;
        switch(orientation) {
            case DOWN ->
                {
                    this.targetRotZ = 180;
                    this.targetRotX = 0;
                }
            case UP ->
                {
                    this.targetRotZ = 0;
                    this.targetRotX = 0;
                }
            case NORTH ->
                {
                    this.targetRotZ = 90;
                    this.targetRotX = 270;
                }
            case SOUTH ->
                {
                    this.targetRotZ = 90;
                    this.targetRotX = 90;
                }
            case WEST ->
                {
                    this.targetRotZ = 90;
                    this.targetRotX = 0;
                }
            case EAST ->
                {
                    this.targetRotZ = 90;
                    this.targetRotX = 180;
                }
        }
        if (initial) {
            this.rotX = this.targetRotX;
            this.rotZ = this.targetRotZ;
        }
        /* setOrientation cleared lastX/lastZ but deliberately retained Y. */
        this.lastSpiralPos = new BlockPos(0, this.lastSpiralPos.getY(), 0);
        this.pendingDig = false;
        this.radiusIncrement = 0.0F;
        this.paused = 100;
        this.targetRadX = 0.0F;
        this.targetRadZ = 0.0F;
        this.motionRadX = 0.0F;
        this.motionRadZ = 0.0F;
        this.digPos = null;
    }

    private void refreshFocusCatalog() {
        if (this.focusCatalogGeneration != FocusApi.registry().generation()) {
            int previousArea = this.area;
            boolean previouslyHadFocus = this.hasFocus;
            this.recalculateUpgrades();
            if (this.area != previousArea || this.hasFocus != previouslyHadFocus) {
                this.currentRadius = 0.0F;
                this.spiral = 0;
                this.applyOrientation(false);
            }
            if (this.level != null && !this.level.isClientSide) {
                this.level.sendBlockUpdated(this.worldPosition, getBlockState(), getBlockState(), 3);
            }
        }
    }

    private void recalculateUpgrades() {
        this.focusCatalogGeneration = FocusApi.registry().generation();
        this.fortune = 0;
        this.area = 0;
        this.speed = 0;
        this.silkTouch = false;
        this.nativeClusters = false;
        ItemStack focusStack = this.items.get(FOCUS_SLOT);
        var state = FocusApi.installedState(focusStack).orElse(null);
        if (state != null && FocusApi.registry().profile(state.focusId()).isPresent() && state.focusId().equals(FocusId.parse("thaumcraft:focus_excavation"))) {
            this.fortune = (int) FocusApi.parameter(state, "bore_fortune");
            this.area = (int) FocusApi.parameter(state, "bore_area");
            this.speed = (int) FocusApi.parameter(state, "bore_speed");
            this.silkTouch = state.level(SILK_TOUCH) > 0;
            this.nativeClusters = state.level(DOWSING) > 0;
            this.hasFocus = true;
        } else {
            this.hasFocus = false;
        }
        ItemStack tool = this.items.get(PICKAXE_SLOT);
        if (tool.getItem() instanceof PickaxeItem) {
            this.hasPickaxe = true;
            if (this.level != null) {
                var enchantments = this.level.registryAccess().lookupOrThrow(Registries.ENCHANTMENT);
                this.fortune = Math.max(this.fortune, dev.tc4port.thaumcraft.nativeimpl.EnchantmentPlatform.level(tool, enchantments.getOrThrow(EnchantmentKeys.FORTUNE)));
                this.speed += dev.tc4port.thaumcraft.nativeimpl.EnchantmentPlatform.level(tool, enchantments.getOrThrow(EnchantmentKeys.EFFICIENCY));
                this.silkTouch |= dev.tc4port.thaumcraft.nativeimpl.EnchantmentPlatform.level(tool, enchantments.getOrThrow(EnchantmentKeys.SILK_TOUCH)) > 0;
            }
            this.nativeClusters |= SpecialMiningDrops.hasNativeClusters(tool);
        } else {
            this.hasPickaxe = false;
        }
    }

    private boolean hasValidItems() {
        ItemStack tool = this.items.get(PICKAXE_SLOT);
        return this.hasFocus && this.hasPickaxe && tool.isDamageableItem() && tool.getDamageValue() + 1 < tool.getMaxDamage();
    }

    public boolean isPowered() {
        if (this.level == null || !this.level.hasChunksAt(this.worldPosition.offset(-3, 0, -3), this.worldPosition.offset(3, 0, 3))) {
            return false;
        }
        return this.level.hasNeighborSignal(this.worldPosition) || this.level.hasNeighborSignal(this.worldPosition.relative(this.baseDirection().getOpposite()));
    }

    @Nullable
    private ArcaneBoreBaseBlockEntity base() {
        if (this.level == null) {
            return null;
        }
        BlockPos basePos = this.worldPosition.relative(this.baseDirection().getOpposite());
        if (!this.level.isLoaded(basePos))
            return null;
        BlockEntity base = this.level.getBlockEntity(basePos);
        return base instanceof ArcaneBoreBaseBlockEntity boreBase ? boreBase : null;
    }

    public Direction facing() {
        BlockState state = this.getBlockState();
        return state.hasProperty(ArcaneBoreBlock.FACING) ? state.getValue(ArcaneBoreBlock.FACING) : Direction.UP;
    }

    public Direction baseDirection() {
        BlockState state = this.getBlockState();
        return state.hasProperty(ArcaneBoreBlock.BASE_DIRECTION) ? state.getValue(ArcaneBoreBlock.BASE_DIRECTION) : Direction.UP;
    }

    public ContainerData data() {
        return this.data;
    }

    public int area() {
        return this.area;
    }

    public int speed() {
        return this.speed;
    }

    public int fortune() {
        return this.fortune;
    }

    public boolean silkTouch() {
        return this.silkTouch;
    }

    public boolean nativeClusters() {
        return this.nativeClusters;
    }

    public float speedyTime() {
        return this.speedyTime;
    }

    @Nullable
    public BlockPos digPos() {
        return this.digPos;
    }

    public int beamLength() {
        return this.beamLength;
    }

    public int topRotation() {
        return this.topRotation;
    }

    public int rotX() {
        return this.rotX;
    }

    public int rotZ() {
        return this.rotZ;
    }

    public int rotationSpeedX() {
        return this.rotationSpeedX;
    }

    public int rotationSpeedZ() {
        return this.rotationSpeedZ;
    }

    public float visibleRadX() {
        return this.visibleRadX;
    }

    public float visibleRadZ() {
        return this.visibleRadZ;
    }

    public boolean hasFocus() {
        return this.hasFocus;
    }

    @Override
    public boolean hasPickaxe() {
        return this.hasPickaxe;
    }

    @Override
    public boolean isPickaxeBroken() {
        ItemStack pickaxe = this.items.get(PICKAXE_SLOT);
        return !pickaxe.isEmpty() && pickaxe.isDamageableItem() && pickaxe.getDamageValue() + 1 >= pickaxe.getMaxDamage();
    }

    @Override
    public boolean isWorking() {
        return this.digPos != null && this.hasFocus && this.hasPickaxe;
    }

    @Override
    public int radius() {
        return TCGameplayParameters.MACHINES_ARCANE_BORE_BASE_RADIUS.intValue() + this.area;
    }

    @Override
    public boolean hasNativeClusters() {
        return this.nativeClusters;
    }

    @Override
    public boolean hasSilkTouch() {
        return this.silkTouch;
    }

    public boolean consumeParticleTick(long gameTime) {
        if (this.lastParticleGameTime == gameTime) {
            return false;
        }
        this.lastParticleGameTime = gameTime;
        return true;
    }

    @Override
    public void setRemoved() {
        if (this.level instanceof ServerLevel serverLevel) {
            this.clearBreakProgress(serverLevel);
        }
        super.setRemoved();
    }

    private void changedAndSync() {
        super.setChanged();
        BlockEntitySync.sendToClient(this);
    }

    @Override
    public void setChanged() {
        this.recalculateUpgrades();
        this.changedAndSync();
    }

    @Override
    public int getContainerSize() {
        return CONTAINER_SIZE;
    }

    @Override
    public int getMaxStackSize() {
        return 64;
    }

    @Override
    protected Component getDefaultName() {
        return Component.translatable("container.thaumcraft.arcane_bore");
    }

    protected NonNullList<ItemStack> getItems() {
        return this.items;
    }

    protected void setItems(NonNullList<ItemStack> items) {
        this.items = items;
        this.recalculateUpgrades();
    }

    @Override
    public boolean canPlaceItem(int slot, ItemStack stack) {
        // TileArcaneBore returned true; its GUI supplied the class filters.
        return true;
    }

    @Override
    public int[] getSlotsForFace(Direction side) {
        return ALL_SLOTS;
    }

    @Override
    public boolean canPlaceItemThroughFace(int index, ItemStack stack, @Nullable Direction direction) {
        return true;
    }

    @Override
    public boolean canTakeItemThroughFace(int index, ItemStack stack, Direction direction) {
        return true;
    }

    @Override
    public void load(CompoundTag tag) {
        HolderLookup.Provider registries = persistenceRegistries();
        super.load(tag);
        this.items = NonNullList.withSize(CONTAINER_SIZE, ItemStack.EMPTY);
        {
            net.minecraft.nbt.CompoundTag native$operand$14320 = tag;
            net.minecraft.core.NonNullList<net.minecraft.world.item.ItemStack> native$operand$14321 = this.items;
            net.minecraft.core.HolderLookup.Provider native$operand$14322 = registries;
            net.minecraft.world.ContainerHelper.loadAllItems(native$operand$14320, native$operand$14321);
        }
        this.speedyTime = tag.getShort("SpeedyTime");
        this.recalculateUpgrades();
        this.pendingDig = tag.getBoolean("BoreDigPending");
        if (this.pendingDig) {
            this.digPos = new BlockPos(tag.getInt("BoreDigX"), tag.getInt("BoreDigY"), tag.getInt("BoreDigZ"));
        } else if (this.level == null || !this.level.isClientSide) {
            this.digPos = null;
        }
    }

    @Override
    protected void saveAdditional(CompoundTag tag) {
        HolderLookup.Provider registries = persistenceRegistries();
        super.saveAdditional(tag);
        {
            net.minecraft.nbt.CompoundTag native$operand$14323 = tag;
            net.minecraft.core.NonNullList<net.minecraft.world.item.ItemStack> native$operand$14324 = this.items;
            net.minecraft.core.HolderLookup.Provider native$operand$14325 = registries;
            net.minecraft.nbt.CompoundTag native$result$14326 = (net.minecraft.world.ContainerHelper.saveAllItems(native$operand$14323, native$operand$14324));
        }
        tag.putShort("SpeedyTime", (short) this.speedyTime);
    }

    @Override
    public CompoundTag getUpdateTag() {
        CompoundTag tag = this.saveWithoutMetadata();
        if (this.pendingDig && this.digPos != null) {
            tag.putBoolean("BoreDigPending", true);
            tag.putInt("BoreDigX", this.digPos.getX());
            tag.putInt("BoreDigY", this.digPos.getY());
            tag.putInt("BoreDigZ", this.digPos.getZ());
        }
        return tag;
    }

    @Override
    public Packet<ClientGamePacketListener> getUpdatePacket() {
        return ClientboundBlockEntityDataPacket.create(this);
    }

    @Nullable
    @Override
    protected AbstractContainerMenu createMenu(int containerId, Inventory inventory) {
        // Vanilla spectator opening bypasses our extra-data menu transport.
        if (inventory.player.isSpectator()) {
            return null;
        }
        return new ArcaneBoreMenu(containerId, inventory, this, this.data);
    }

    protected final HolderLookup.Provider persistenceRegistries() {
        if (level != null)
            return level.registryAccess();
        var server = net.minecraftforge.server.ServerLifecycleHooks.getCurrentServer();
        return server != null ? server.registryAccess() : net.minecraft.core.RegistryAccess.fromRegistryOfRegistries(net.minecraft.core.registries.BuiltInRegistries.REGISTRY);
    }

    protected static net.minecraft.network.chat.Component parseCustomNameSafe(String value, HolderLookup.Provider registries) {
        try {
            return net.minecraft.network.chat.Component.Serializer.fromJson(value);
        } catch (RuntimeException exception) {
            return null;
        }
    }

    @Override
    public boolean isEmpty() {
        return (switch(0) {
            default ->
                {
                    net.minecraft.core.NonNullList<net.minecraft.world.item.ItemStack> native$bodyResult$4850 = null;
                    native$bodyReturn$4851: {
                        if (true) {
                            {
                                native$bodyResult$4850 = this.items;
                                break native$bodyReturn$4851;
                            }
                        }
                    }
                    yield native$bodyResult$4850;
                }
        }).stream().allMatch(ItemStack::isEmpty);
    }

    @Override
    public ItemStack getItem(int index) {
        return (switch(0) {
            default ->
                {
                    net.minecraft.core.NonNullList<net.minecraft.world.item.ItemStack> native$bodyResult$5347 = null;
                    native$bodyReturn$5348: {
                        if (true) {
                            {
                                native$bodyResult$5347 = this.items;
                                break native$bodyReturn$5348;
                            }
                        }
                    }
                    yield native$bodyResult$5347;
                }
        }).get(index);
    }

    @Override
    public ItemStack removeItem(int index, int count) {
        ItemStack removed = net.minecraft.world.ContainerHelper.removeItem((switch(0) {
            default ->
                {
                    net.minecraft.core.NonNullList<net.minecraft.world.item.ItemStack> native$bodyResult$3949 = null;
                    native$bodyReturn$3950: {
                        if (true) {
                            {
                                native$bodyResult$3949 = this.items;
                                break native$bodyReturn$3950;
                            }
                        }
                    }
                    yield native$bodyResult$3949;
                }
        }), index, count);
        if (!removed.isEmpty())
            setChanged();
        return removed;
    }

    @Override
    public ItemStack removeItemNoUpdate(int index) {
        return net.minecraft.world.ContainerHelper.takeItem((switch(0) {
            default ->
                {
                    net.minecraft.core.NonNullList<net.minecraft.world.item.ItemStack> native$bodyResult$5349 = null;
                    native$bodyReturn$5350: {
                        if (true) {
                            {
                                native$bodyResult$5349 = this.items;
                                break native$bodyReturn$5350;
                            }
                        }
                    }
                    yield native$bodyResult$5349;
                }
        }), index);
    }

    @Override
    public void setItem(int index, ItemStack stack) {
        (switch(0) {
            default ->
                {
                    net.minecraft.core.NonNullList<net.minecraft.world.item.ItemStack> native$bodyResult$5351 = null;
                    native$bodyReturn$5352: {
                        if (true) {
                            {
                                native$bodyResult$5351 = this.items;
                                break native$bodyReturn$5352;
                            }
                        }
                    }
                    yield native$bodyResult$5351;
                }
        }).set(index, stack);
        int limit = Math.min(getMaxStackSize(), stack.getMaxStackSize());
        if (stack.getCount() > limit)
            stack.setCount(limit);
        setChanged();
    }

    @Override
    public void clearContent() {
        (switch(0) {
            default ->
                {
                    net.minecraft.core.NonNullList<net.minecraft.world.item.ItemStack> native$bodyResult$5353 = null;
                    native$bodyReturn$5354: {
                        if (true) {
                            {
                                native$bodyResult$5353 = this.items;
                                break native$bodyReturn$5354;
                            }
                        }
                    }
                    yield native$bodyResult$5353;
                }
        }).clear();
    }

    @Override
    public boolean stillValid(net.minecraft.world.entity.player.Player player) {
        return net.minecraft.world.Container.stillValidBlockEntity(this, player);
    }

    @Override
    public net.minecraft.world.phys.AABB getRenderBoundingBox() {
        return ArcaneBoreBlockEntity.native$ClientBlockEntityBounds$bounds(this);
    }

    @Override()
    public void onDataPacket(net.minecraft.network.Connection connection, net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket packet) {
        handleUpdateTag(packet.getTag());
    }

    private static void native$listener$11247(net.minecraft.world.item.Item broken) {
    }

    static private void native$subscription$11248(net.minecraft.world.item.ItemStack stack, int amount, net.minecraft.server.level.ServerLevel level, net.minecraft.server.level.ServerPlayer player) {
        if (stack.hurt(amount, level.random, player)) {
            net.minecraft.world.item.Item item = stack.getItem();
            stack.shrink(1);
            stack.setDamageValue(0);
            dev.tc4port.thaumcraft.block.entity.ArcaneBoreBlockEntity.native$listener$11247((net.minecraft.world.item.Item) (item));
        }
    }

    @SuppressWarnings({ "rawtypes", "unchecked" })
    static private net.minecraft.world.phys.AABB native$ClientBlockEntityBounds$bounds(net.minecraft.world.level.block.entity.BlockEntity blockEntity) {
        var renderer = net.minecraft.client.Minecraft.getInstance().getBlockEntityRenderDispatcher().getRenderer(blockEntity);
        return renderer instanceof dev.tc4port.thaumcraft.nativeimpl.NativeBlockEntityRenderer shared ? shared.getRenderBoundingBox(blockEntity) : new net.minecraft.world.phys.AABB(blockEntity.getBlockPos());
    }

    private boolean native$capabilitiesInvalid$16961;

    public boolean native$capabilityActive$16808;

    private java.util.Map<net.minecraft.core.Direction, net.minecraftforge.common.util.LazyOptional<net.minecraftforge.items.IItemHandler>> native$capabilityHandle$16809;

    @Override
    public <native$capabilityResultType$16962> net.minecraftforge.common.util.LazyOptional<native$capabilityResultType$16962> getCapability(net.minecraftforge.common.capabilities.Capability<native$capabilityResultType$16962> native$requestedCapability$16963, net.minecraft.core.Direction native$requestedFace$16964) {
        getCapabilities();
        synchronized (this) {
            if (native$capabilitiesInvalid$16961)
                return net.minecraftforge.common.util.LazyOptional.empty();
            if (native$capabilityActive$16808 && native$requestedCapability$16963 == (net.minecraftforge.common.capabilities.ForgeCapabilities.ITEM_HANDLER)) {
                if (native$capabilityHandle$16809 == null)
                    native$capabilityHandle$16809 = new java.util.HashMap<>();
                net.minecraftforge.common.util.LazyOptional<net.minecraftforge.items.IItemHandler> native$capabilityResult$16966 = native$capabilityHandle$16809.computeIfAbsent(native$requestedFace$16964, native$capabilityFace$16810 -> {
                    net.minecraftforge.items.IItemHandler native$endpoint$136 = (switch(0) {
                        default ->
                            {
                                dev.tc4port.thaumcraft.block.entity.ArcaneBoreBlockEntity bore = dev.tc4port.thaumcraft.block.entity.ArcaneBoreBlockEntity.this;
                                net.minecraft.core.Direction side = native$capabilityFace$16810;
                                yield (switch(0) {
                                    default ->
                                        {
                                            net.minecraft.world.Container native$operand$12746 = bore;
                                            net.minecraftforge.items.IItemHandler native$result$12747 = (new net.minecraftforge.items.wrapper.InvWrapper(native$operand$12746));
                                            yield native$result$12747;
                                        }
                                });
                            }
                    });
                    return native$endpoint$136 == null ? net.minecraftforge.common.util.LazyOptional.empty() : net.minecraftforge.common.util.LazyOptional.of(() -> native$endpoint$136);
                });
                if (native$capabilityResult$16966.isPresent())
                    return native$capabilityResult$16966.cast();
            }
        }
        return super.getCapability(native$requestedCapability$16963, native$requestedFace$16964);
    }

    @Override
    public void invalidateCaps() {
        java.util.List<net.minecraftforge.common.util.LazyOptional<?>> native$expiredCapabilities$16965 = new java.util.ArrayList<>();
        synchronized (this) {
            native$capabilitiesInvalid$16961 = true;
            if (native$capabilityHandle$16809 != null) {
                native$expiredCapabilities$16965.addAll(native$capabilityHandle$16809.values());
                native$capabilityHandle$16809 = null;
            }
        }
        try {
            super.invalidateCaps();
        } finally {
            native$expiredCapabilities$16965.forEach(net.minecraftforge.common.util.LazyOptional::invalidate);
        }
    }

    @Override
    public void reviveCaps() {
        super.reviveCaps();
        synchronized (this) {
            native$capabilitiesInvalid$16961 = false;
        }
    }
}
