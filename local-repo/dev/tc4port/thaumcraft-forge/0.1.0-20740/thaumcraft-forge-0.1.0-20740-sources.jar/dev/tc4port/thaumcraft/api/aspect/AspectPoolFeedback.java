package dev.tc4port.thaumcraft.api.aspect;

/**
 * Controls whether a pool grant is also an explicit aspect discovery.
 */
public enum AspectPoolFeedback {

    /**
     * Ordinary TC4 pool feedback. A first grant still receives the mandatory
     * two-point discovery reward, but does not emit the discovery presentation.
     */
    POOL_GAIN,
    /**
     * Reports a first discovery in addition to granting its reward.
     */
    DISCOVER_IF_NEW
}
