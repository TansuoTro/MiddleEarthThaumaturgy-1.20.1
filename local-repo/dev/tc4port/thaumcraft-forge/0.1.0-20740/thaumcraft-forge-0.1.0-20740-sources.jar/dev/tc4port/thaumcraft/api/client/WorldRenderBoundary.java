package dev.tc4port.thaumcraft.api.client;

import java.util.*;

/**
 * Opaque/translucent native boundaries, including the Fabulous depth-copy boundary.
 */
public final class WorldRenderBoundary {

    private static final List<Runnable> AFTER_OPAQUE = new ArrayList<>();

    private static final List<Runnable> BEFORE_TRANSLUCENT = new ArrayList<>();

    private WorldRenderBoundary() {
    }

    /**
     * Once per level frame, after native entity/block-entity buffers close and before the transparency branch.
     */
    public static void afterOpaque(Runnable listener) {
        AFTER_OPAQUE.add(listener);
    }

    public static void beforeTranslucent(Runnable listener) {
        BEFORE_TRANSLUCENT.add(listener);
    }

    public static void dispatchAfterOpaque() {
        AFTER_OPAQUE.forEach(Runnable::run);
    }

    public static void dispatch() {
        BEFORE_TRANSLUCENT.forEach(Runnable::run);
    }
}
