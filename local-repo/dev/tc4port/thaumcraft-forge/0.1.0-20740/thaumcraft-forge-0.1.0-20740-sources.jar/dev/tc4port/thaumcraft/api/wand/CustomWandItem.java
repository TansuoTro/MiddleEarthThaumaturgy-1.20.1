package dev.tc4port.thaumcraft.api.wand;

import dev.tc4port.thaumcraft.api.item.ItemStatePlatform;
import dev.tc4port.thaumcraft.state.TCItemState;
import dev.tc4port.thaumcraft.data.WandData;
import dev.tc4port.thaumcraft.common.CustomWandSpecifications;
import dev.tc4port.thaumcraft.item.WandItem;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.UseAnim;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;

/**
 * Public addon base for a real TC focus/Vis carrier with custom physical
 * behavior. It delegates to the core wand transaction coordinator while its
 * public inheritance remains entirely inside the supported API surface.
 * Its use animation is NONE. Addon item client extensions can return
 * {@code WandRenderApi.getArmPose(entity, hand, stack)} from getArmPose to
 * retain the standard casting arms alongside their own item renderer.
 */
public class CustomWandItem extends WandCarrierItem {

    private final CustomWandSpec spec;

    public CustomWandItem(Properties properties, CustomWandSpec spec) {
        super(ItemStatePlatform.withDefault(properties, TCItemState.WAND, defaultData(spec)));
        ItemStatePlatform.bindDefaults(this, properties);
        this.spec = Objects.requireNonNull(spec, "spec");
        CustomWandSpecifications.bind(this, this.spec);
    }

    public final CustomWandSpec thaumcraftWandSpec() {
        return this.spec;
    }

    @Override
    public boolean requiresBothHands(ItemStack stack) {
        return this.spec.requiresBothHands();
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        return behavior().use(level, player, hand);
    }

    @Override
    public InteractionResult onItemUseFirst(ItemStack stack, UseOnContext context) {
        return behavior().onItemUseFirst(stack, context);
    }

    @Override
    public InteractionResult useOn(UseOnContext context) {
        return behavior().useOn(context);
    }

    @Override
    public InteractionResult interactLivingEntity(ItemStack stack, Player player, LivingEntity target, InteractionHand hand) {
        return behavior().interactLivingEntity(stack, player, target, hand);
    }

    @Override
    public void appendHoverText(ItemStack stack, net.minecraft.world.level.Level context, List<Component> tooltip, TooltipFlag flag) {
        behavior().appendHoverText(stack, context, tooltip, flag);
    }

    @Override
    public void onUseTick(Level level, LivingEntity livingEntity, ItemStack stack, int remainingUseDuration) {
        behavior().onUseTick(level, livingEntity, stack, remainingUseDuration);
    }

    @Override
    public int getUseDuration(ItemStack stack) {
        return behavior().getUseDuration(stack);
    }

    @Override
    public UseAnim getUseAnimation(ItemStack stack) {
        return behavior().getUseAnimation(stack);
    }

    @Override
    public boolean shouldCauseReequipAnimation(ItemStack oldStack, ItemStack newStack, boolean slotChanged) {
        return slotChanged || !oldStack.is(this) || !newStack.is(this);
    }

    @Override
    public void inventoryTick(ItemStack stack, Level level, Entity entity, int slotId, boolean isSelected) {
        behavior().inventoryTick(stack, level, entity, slotId, isSelected);
    }

    @Override
    public void onStopUsing(ItemStack stack, LivingEntity livingEntity, int count) {
        behavior().onStopUsing(stack, livingEntity, count);
    }

    public final int adjustedCooldownTicks(int ticks) {
        if (ticks <= 0) {
            return 0;
        }
        return Math.max(1, (int) Math.floor(ticks * (double) this.spec.cooldownMultiplier()));
    }

    private static WandItem behavior() {
        return (WandItem) dev.tc4port.thaumcraft.registry.TCItems.WAND.get();
    }

    private static WandData defaultData(CustomWandSpec spec) {
        Objects.requireNonNull(spec, "spec");
        return new WandData(spec.rod(), spec.cap(), Optional.empty(), Map.of(), List.of(), false);
    }
}
