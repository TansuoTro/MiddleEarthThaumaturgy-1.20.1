package dev.tc4port.thaumcraft.api.machine;

public interface BrainJarView {

    int experience();
}
