package dev.tc4port.thaumcraft.api.node;

/**
 * Native Vis source identity used by core nodes, addons and foreign block providers.
 */
public final class VisCapabilities {

    private VisCapabilities() {
    }

    /**
     * Null face queries wireless sources at the host position. A face queries
     * the source supplying the adjacent relay on that face. Providers return
     * their live endpoint even while disabled; canSupplyVis owns availability.
     * On mixed hosts, the actual incoming relay's enabled face takes priority
     * over wireless supply. A selected provider returning zero does not fall
     * through to another reservoir.
     * Capability identity changes must invalidate native caches. Source load,
     * removal and connection changes also call VisNetworkApi registration.
     */
    public static final net.minecraftforge.common.capabilities.Capability<VisSource> SOURCE = (switch(0) {
        default ->
            {
                java.util.Objects.requireNonNull(net.minecraft.resources.ResourceLocation.fromNamespaceAndPath((java.lang.String) ("thaumcraft"), (java.lang.String) ("vis_source")));
                yield java.util.Objects.requireNonNull(net.minecraftforge.common.capabilities.CapabilityManager.get(new net.minecraftforge.common.capabilities.CapabilityToken<dev.tc4port.thaumcraft.api.node.VisSource>() {
                }));
            }
    });
}
