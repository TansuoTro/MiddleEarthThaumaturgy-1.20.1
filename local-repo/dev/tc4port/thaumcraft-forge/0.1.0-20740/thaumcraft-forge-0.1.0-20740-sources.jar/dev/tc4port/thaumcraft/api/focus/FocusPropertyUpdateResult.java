package dev.tc4port.thaumcraft.api.focus;

public enum FocusPropertyUpdateResult {

    UPDATED,
    WOULD_UPDATE,
    UNCHANGED,
    NO_FOCUS,
    INVALID_PROPERTIES,
    READ_ONLY_CARRIER,
    DENIED
}
