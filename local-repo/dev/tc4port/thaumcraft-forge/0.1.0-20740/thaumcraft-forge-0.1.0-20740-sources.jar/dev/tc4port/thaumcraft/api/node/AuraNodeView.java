package dev.tc4port.thaumcraft.api.node;

import dev.tc4port.thaumcraft.api.aspect.AspectAmounts;
import dev.tc4port.thaumcraft.api.aspect.AspectContainerView;
import dev.tc4port.thaumcraft.api.aspect.AspectId;
import java.util.List;

/**
 * Owner-class SPI for aura-node inspection. Core scanning, the thaumometer
 * HUD and aspect-container goggles consume this view. Mutation, jarring and
 * Vis-network source/relay topology are deliberately not part of this SPI.
 */
public interface AuraNodeView extends AspectContainerView {

    AuraNodeState nodeState();

    /**
     * Presentation-only aspect quantities visible to scanners and goggles.
     * Ordinary nodes expose whole-Vis storage; energized nodes expose their
     * derived sqrt-scaled display output. Do not use this view for payment or
     * network transfer units. Implementations with derived presentation must
     * override both this method and {@link #visibleAspectOrder()}.
     */
    default AspectAmounts inspectionAspects() {
        return this.nodeState().currentVis().positiveAmounts();
    }

    @Override
    default AspectAmounts visibleAspects() {
        return this.inspectionAspects();
    }

    @Override
    default List<AspectId> visibleAspectOrder() {
        return List.copyOf(this.nodeState().currentVis().amounts().keySet());
    }
}
