package dev.tc4port.thaumcraft.block;

import com.mojang.serialization.MapCodec;
import dev.tc4port.thaumcraft.block.entity.AlchemyFurnaceBlockEntity;
import dev.tc4port.thaumcraft.registry.TCBlockEntities;
import javax.annotation.Nullable;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.RandomSource;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityTicker;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;
import dev.tc4port.thaumcraft.nativeimpl.ClientExtensionTarget;
import dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.level.pathfinder.PathComputationType;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.level.Explosion;

/**
 * Metadata-zero BlockStoneDevice split into a dedicated modern block.
 */
public final class AlchemyFurnaceBlock extends net.minecraft.world.level.block.BaseEntityBlock implements dev.tc4port.thaumcraft.nativeimpl.ClientExtensionTarget {

    // Forge calls initializeClient from the native superclass constructor. Do not add a field initializer.
    private java.util.function.Consumer<net.minecraftforge.client.extensions.common.IClientBlockExtensions> platform$clientInstaller;

    public static final MapCodec<AlchemyFurnaceBlock> CODEC = AlchemyFurnaceBlock.native$BlockCodecPlatform$simple(AlchemyFurnaceBlock::new);

    public static final BooleanProperty LIT = BlockStateProperties.LIT;

    public static final BooleanProperty FILLED = BooleanProperty.create("filled");

    public AlchemyFurnaceBlock(BlockBehaviour.Properties properties) {
        this(properties, properties, true);
    }

    protected MapCodec<AlchemyFurnaceBlock> codec() {
        return CODEC;
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<net.minecraft.world.level.block.Block, BlockState> builder) {
        builder.add(LIT, FILLED);
    }

    @Nullable
    @Override
    public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        return new AlchemyFurnaceBlockEntity(pos, state);
    }

    @Nullable
    @Override
    public <T extends BlockEntity> BlockEntityTicker<T> getTicker(Level level, BlockState state, BlockEntityType<T> type) {
        return level.isClientSide ? null : createTickerHelper(type, TCBlockEntities.ALCHEMY_FURNACE.get(), AlchemyFurnaceBlockEntity::serverTick);
    }

    @Override
    public RenderShape getRenderShape(BlockState state) {
        return RenderShape.MODEL;
    }

    protected InteractionResult interactWithoutItem(BlockState state, Level level, BlockPos pos, Player player, BlockHitResult hit) {
        if (level.isClientSide) {
            return net.minecraft.world.InteractionResult.SUCCESS;
        }
        if (!player.isShiftKeyDown() && player instanceof net.minecraft.server.level.ServerPlayer serverPlayer && level.getBlockEntity(pos) instanceof dev.tc4port.thaumcraft.block.entity.AlchemyFurnaceBlockEntity furnace) {
            net.minecraftforge.network.NetworkHooks.openScreen((net.minecraft.server.level.ServerPlayer) (serverPlayer), (net.minecraft.world.MenuProvider) (furnace), (java.util.function.Consumer<net.minecraft.network.FriendlyByteBuf>) (buffer -> buffer.writeBlockPos(pos)));
        }
        return net.minecraft.world.InteractionResult.CONSUME;
    }

    @Override
    public void animateTick(BlockState state, Level level, BlockPos pos, RandomSource random) {
        if (!state.getValue(LIT)) {
            return;
        }
        double x = pos.getX() + 0.5;
        double y = pos.getY() + 0.2 + random.nextFloat() * 5.0F / 16.0F;
        double z = pos.getZ() + 0.5;
        double edge = 0.52;
        double offset = random.nextFloat() * 0.5F - 0.25F;
        for (Direction direction : Direction.Plane.HORIZONTAL) {
            /*
             * The source reused the same signed offset on all four faces:
             * west/east varied z + offset and north/south varied x + offset.
             * Multiplying the offset by the facing sign would reflect the
             * west and north samples for a given RNG sequence.
             */
            boolean xAxis = direction.getAxis() == Direction.Axis.X;
            double particleX = x + (xAxis ? direction.getStepX() * edge : offset);
            double particleZ = z + (xAxis ? offset : direction.getStepZ() * edge);
            level.addParticle(ParticleTypes.SMOKE, particleX, y, particleZ, 0.0, 0.0, 0.0);
            level.addParticle(ParticleTypes.FLAME, particleX, y, particleZ, 0.0, 0.0, 0.0);
        }
    }

    @Override
    public int getAnalogOutputSignal(BlockState state, Level level, BlockPos pos) {
        return level.getBlockEntity(pos) instanceof AlchemyFurnaceBlockEntity furnace ? AbstractContainerMenuSignal.signal(furnace) : 0;
    }

    @Override
    public boolean hasAnalogOutputSignal(BlockState state) {
        return true;
    }

    @Override
    public int getLightBlock(BlockState state, BlockGetter level, BlockPos pos) {
        return 0;
    }

    @Override
    public VoxelShape getBlockSupportShape(BlockState state, BlockGetter level, BlockPos pos) {
        return Shapes.empty();
    }

    @Override
    public void neighborChanged(BlockState state, Level level, BlockPos pos, net.minecraft.world.level.block.Block neighborBlock, BlockPos neighborPos, boolean movedByPiston) {
        super.neighborChanged(state, level, pos, neighborBlock, neighborPos, movedByPiston);
        if (level.getBlockEntity(pos) instanceof AlchemyFurnaceBlockEntity furnace) {
            furnace.recountBellows();
        }
    }

    @Override
    public void onRemove(BlockState state, Level level, BlockPos pos, BlockState newState, boolean isMoving) {
        if (!dev.tc4port.thaumcraft.common.MultiblockFormation.deferInventoryDrop(level, pos, state, newState)) {
            AlchemyFurnaceBlock.native$BlockActions$dropContentsOnDestroy(state, newState, level, pos);
        }
        super.onRemove(state, level, pos, newState, isMoving);
    }

    /**
     * Kept local so the block does not depend on the screen/menu package.
     */
    private static final class AbstractContainerMenuSignal {

        private AbstractContainerMenuSignal() {
        }

        private static int signal(AlchemyFurnaceBlockEntity furnace) {
            return net.minecraft.world.inventory.AbstractContainerMenu.getRedstoneSignalFromContainer(furnace);
        }
    }

    private AlchemyFurnaceBlock(net.minecraft.world.level.block.state.BlockBehaviour.Properties native$NativeEntityBlock$arg0, BlockBehaviour.Properties properties, boolean native$NativeEntityBlock$captured) {
        super(native$NativeEntityBlock$arg0);
        this.registerDefaultState(this.stateDefinition.any().setValue(LIT, false).setValue(FILLED, false));
    }

    @Override
    public void initializeClient(java.util.function.Consumer<net.minecraftforge.client.extensions.common.IClientBlockExtensions> installer) {
        platform$clientInstaller = installer;
        super.initializeClient(installer);
    }

    @Override
    public void platform$clientExtension(Object extension) {
        java.util.Objects.requireNonNull(platform$clientInstaller, "Forge initializeClient must run before client extension registration").accept((net.minecraftforge.client.extensions.common.IClientBlockExtensions) extension);
    }

    @Override
    public InteractionResult use(BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
        ItemUseResult result = (switch(0) {
            default ->
                {
                    net.minecraft.world.item.ItemStack native$bodyOperand$4061 = player.getItemInHand(hand);
                    net.minecraft.world.level.block.state.BlockState native$bodyOperand$4062 = state;
                    net.minecraft.world.level.Level native$bodyOperand$4063 = level;
                    net.minecraft.core.BlockPos native$bodyOperand$4064 = pos;
                    net.minecraft.world.entity.player.Player native$bodyOperand$4065 = player;
                    net.minecraft.world.InteractionHand native$bodyOperand$4066 = hand;
                    net.minecraft.world.phys.BlockHitResult native$bodyOperand$4067 = hit;
                    dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult native$bodyResult$4068 = null;
                    native$bodyReturn$4069: {
                        if (true) {
                            {
                                native$bodyResult$4068 = dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
                                break native$bodyReturn$4069;
                            }
                        }
                    }
                    yield native$bodyResult$4068;
                }
        });
        return result == ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION ? (hand == InteractionHand.MAIN_HAND ? (switch(0) {
            default ->
                {
                    net.minecraft.world.level.block.state.BlockState native$bodyOperand$3422 = state;
                    net.minecraft.world.level.Level native$bodyOperand$3423 = level;
                    net.minecraft.core.BlockPos native$bodyOperand$3424 = pos;
                    net.minecraft.world.entity.player.Player native$bodyOperand$3425 = player;
                    net.minecraft.world.phys.BlockHitResult native$bodyOperand$3426 = hit;
                    net.minecraft.world.InteractionResult native$bodyResult$3430 = null;
                    native$bodyReturn$3431: {
                        if (true) {
                            if (native$bodyOperand$3423.isClientSide) {
                                {
                                    native$bodyResult$3430 = net.minecraft.world.InteractionResult.SUCCESS;
                                    break native$bodyReturn$3431;
                                }
                            }
                            if (!native$bodyOperand$3425.isShiftKeyDown() && native$bodyOperand$3425 instanceof net.minecraft.server.level.ServerPlayer native$bodyBinding$3427 && native$bodyOperand$3423.getBlockEntity(native$bodyOperand$3424) instanceof dev.tc4port.thaumcraft.block.entity.AlchemyFurnaceBlockEntity native$bodyBinding$3428) {
                                net.minecraftforge.network.NetworkHooks.openScreen((net.minecraft.server.level.ServerPlayer) (native$bodyBinding$3427), (net.minecraft.world.MenuProvider) (native$bodyBinding$3428), (java.util.function.Consumer<net.minecraft.network.FriendlyByteBuf>) (native$bodyBinding$3429 -> native$bodyBinding$3429.writeBlockPos(native$bodyOperand$3424)));
                            }
                            {
                                native$bodyResult$3430 = net.minecraft.world.InteractionResult.CONSUME;
                                break native$bodyReturn$3431;
                            }
                        }
                    }
                    yield native$bodyResult$3430;
                }
        }) : InteractionResult.PASS) : result.result();
    }

    protected ItemUseResult interactWithItem(ItemStack stack, BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
        return dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
    }

    @Override
    public void playerWillDestroy(Level level, BlockPos pos, BlockState state, Player player) {
        {
            net.minecraft.world.level.Level native$bodyOperand$5620 = level;
            net.minecraft.core.BlockPos native$bodyOperand$5621 = pos;
            net.minecraft.world.level.block.state.BlockState native$bodyOperand$5622 = state;
            net.minecraft.world.entity.player.Player native$bodyOperand$5623 = player;
            net.minecraft.world.level.block.state.BlockState native$bodyResult$5624 = null;
            native$bodyReturn$5625: {
                if (true) {
                    super.playerWillDestroy(native$bodyOperand$5620, native$bodyOperand$5621, native$bodyOperand$5622, native$bodyOperand$5623);
                    {
                        native$bodyResult$5624 = native$bodyOperand$5622;
                        break native$bodyReturn$5625;
                    }
                }
            }
        }
    }

    public BlockState beforePlayerDestroy(Level level, BlockPos pos, BlockState state, Player player) {
        super.playerWillDestroy(level, pos, state, player);
        return state;
    }

    protected boolean survivesSharedExplosion() {
        return false;
    }

    public int getExpDrop(net.minecraft.world.level.block.state.BlockState native$callbackInput$1050, net.minecraft.world.level.LevelReader native$callbackInput$1051, net.minecraft.util.RandomSource native$callbackInput$1052, net.minecraft.core.BlockPos native$callbackInput$1053, int native$callbackInput$1054, int native$callbackInput$1055) {
        net.minecraft.world.level.block.state.BlockState state = native$callbackInput$1050;
        net.minecraft.util.RandomSource random = native$callbackInput$1052;
        return 0;
    }

    @Override
    public void onBlockExploded(BlockState state, Level level, BlockPos pos, Explosion explosion) {
        if (!(switch(0) {
            default ->
                {
                    boolean native$bodyResult$5203 = false;
                    native$bodyReturn$5204: {
                        if (true) {
                            {
                                native$bodyResult$5203 = false;
                                break native$bodyReturn$5204;
                            }
                        }
                    }
                    yield native$bodyResult$5203;
                }
        }))
            super.onBlockExploded(state, level, pos, explosion);
    }

    @Override
    public boolean canDropFromExplosion(BlockState state, BlockGetter level, BlockPos pos, Explosion explosion) {
        return !(switch(0) {
            default ->
                {
                    boolean native$bodyResult$4070 = false;
                    native$bodyReturn$4071: {
                        if (true) {
                            {
                                native$bodyResult$4070 = false;
                                break native$bodyReturn$4071;
                            }
                        }
                    }
                    yield native$bodyResult$4070;
                }
        }) && super.canDropFromExplosion(state, level, pos, explosion);
    }

    static private void native$BlockActions$dropContentsOnDestroy(net.minecraft.world.level.block.state.BlockState state, net.minecraft.world.level.block.state.BlockState replacement, net.minecraft.world.level.Level level, net.minecraft.core.BlockPos pos) {
        if (!state.is(replacement.getBlock()) && level.getBlockEntity(pos) instanceof net.minecraft.world.Container container) {
            net.minecraft.world.Containers.dropContents(level, pos, container);
            level.updateNeighbourForOutputSignal(pos, state.getBlock());
        }
    }

    static private <B extends net.minecraft.world.level.block.Block> com.mojang.serialization.MapCodec<B> native$BlockCodecPlatform$simple(java.util.function.Function<net.minecraft.world.level.block.state.BlockBehaviour.Properties, B> factory) {
        // Vanilla 1.21's Properties codec is a unit codec. Retain that schema for shared block definitions.
        return com.mojang.serialization.codecs.RecordCodecBuilder.mapCodec(instance -> instance.group(com.mojang.serialization.Codec.unit(net.minecraft.world.level.block.state.BlockBehaviour.Properties::of).fieldOf("properties").forGetter((B block) -> net.minecraft.world.level.block.state.BlockBehaviour.Properties.copy(block))).apply(instance, factory));
    }
}
