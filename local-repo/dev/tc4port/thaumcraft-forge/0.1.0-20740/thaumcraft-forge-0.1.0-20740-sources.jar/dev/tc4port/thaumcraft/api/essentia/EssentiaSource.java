package dev.tc4port.thaumcraft.api.essentia;

import dev.tc4port.thaumcraft.api.aspect.AspectId;

/**
 * Remote extraction contract exposed by {@link EssentiaCapabilities#SOURCE}.
 *
 * <p>This is deliberately separate from {@link EssentiaTransport}. A tube
 * endpoint does not become remotely drainable merely because it transports
 * essentia. Query through {@link EssentiaApi#source}; the block entity itself
 * need not implement this interface when a native provider supplies it.
 * Calls are made on the logical server thread. {@code aspect} is a
 * canonical active aspect ID, {@code amount} is positive, and implementations
 * must return either the complete requested amount or zero. Simulation must
 * not mutate observable state.</p>
 */
@FunctionalInterface
public interface EssentiaSource {

    int extractEssentia(AspectId aspect, int amount, EssentiaTransferMode mode);
}
