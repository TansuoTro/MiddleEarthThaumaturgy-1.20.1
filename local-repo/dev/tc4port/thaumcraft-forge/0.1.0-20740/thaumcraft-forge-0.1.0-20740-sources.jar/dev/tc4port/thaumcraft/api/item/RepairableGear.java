package dev.tc4port.thaumcraft.api.item;

/**
 * Opts an item into Thaumcraft's runtime Repair enchantment loop.
 *
 * <p>The item must also be present in
 * {@code thaumcraft:repairable} for enchanting-table support.</p>
 */
public interface RepairableGear {
}
