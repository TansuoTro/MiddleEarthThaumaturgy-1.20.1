package dev.tc4port.thaumcraft.api.champion;

import dev.tc4port.thaumcraft.api.event.AttributeOperation;
import java.util.Objects;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;

/**
 * Immutable attribute rule reconciled while a mob has a champion identity.
 */
public record ChampionAttributeModifier(ResourceLocation attribute, ResourceLocation modifierId, double amount, dev.tc4port.thaumcraft.api.event.AttributeOperation operation) {

    public ChampionAttributeModifier {
        Objects.requireNonNull(attribute, "attribute");
        Objects.requireNonNull(modifierId, "modifierId");
        Objects.requireNonNull(operation, "operation");
        if (attribute.toString().length() > 256 || modifierId.toString().length() > 256) {
            throw new IllegalArgumentException("Champion attribute identities are limited to 256 " + "characters");
        }
        if (!Double.isFinite(amount)) {
            throw new IllegalArgumentException("Champion attribute amount must be finite");
        }
    }
}
