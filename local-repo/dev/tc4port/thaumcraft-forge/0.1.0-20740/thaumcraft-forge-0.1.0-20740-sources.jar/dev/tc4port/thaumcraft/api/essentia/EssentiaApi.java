package dev.tc4port.thaumcraft.api.essentia;

import dev.tc4port.thaumcraft.util.RuntimeWarnings;
import dev.tc4port.thaumcraft.api.aspect.AspectApi;
import dev.tc4port.thaumcraft.api.aspect.AspectId;
import java.util.Optional;
import java.util.function.Predicate;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.SectionPos;
import net.minecraft.world.level.Level;

/**
 * Stable capability lookup, directional transfer and direct-source extraction entry point.
 */
public final class EssentiaApi {

    private EssentiaApi() {
    }

    /**
     * Finds an endpoint through the native capability without loading chunks.
     * The face is viewed from the endpoint, and may be null for inspection.
     * Connections and transfers still follow the returned interface's rules.
     * Non-world render views retain direct interface inspection.
     */
    @javax.annotation.Nullable
    public static EssentiaTransport transport(net.minecraft.world.level.BlockGetter view, BlockPos pos, @javax.annotation.Nullable Direction face) {
        if (view instanceof net.minecraft.world.level.LevelReader reader && !reader.hasChunk(pos.getX() >> 4, pos.getZ() >> 4))
            return null;
        if (view instanceof Level level) {
            return (switch(0) {
                default ->
                    {
                        net.minecraftforge.common.capabilities.Capability<dev.tc4port.thaumcraft.api.essentia.EssentiaTransport> native$capability$964 = EssentiaCapabilities.TRANSPORT;
                        net.minecraft.world.level.Level native$level$965 = level;
                        net.minecraft.core.BlockPos native$position$966 = pos;
                        net.minecraft.core.Direction native$side$967 = face;
                        var native$blockEntity$968 = native$level$965.getBlockEntity(native$position$966);
                        yield native$blockEntity$968 == null ? null : native$blockEntity$968.getCapability(java.util.Objects.requireNonNull(native$capability$964), native$side$967).orElse(null);
                    }
            });
        }
        return view.getBlockEntity(pos) instanceof EssentiaTransport transport ? transport : null;
    }

    /**
     * Finds a remote extraction endpoint without loading chunks. This capability
     * is queried without a face and is independent of directional transport.
     * A non-null source permits requests, but may lack the requested contents;
     * use findSource or extract to apply simulation and server-thread checks.
     */
    @javax.annotation.Nullable
    public static EssentiaSource source(Level level, BlockPos pos) {
        if (!level.hasChunkAt(pos))
            return null;
        return (switch(0) {
            default ->
                {
                    net.minecraftforge.common.capabilities.Capability<dev.tc4port.thaumcraft.api.essentia.EssentiaSource> native$capability$969 = EssentiaCapabilities.SOURCE;
                    net.minecraft.world.level.Level native$level$970 = level;
                    net.minecraft.core.BlockPos native$position$971 = pos;
                    net.minecraft.core.Direction native$side$972 = null;
                    var native$blockEntity$973 = native$level$970.getBlockEntity(native$position$971);
                    yield native$blockEntity$973 == null ? null : native$blockEntity$973.getCapability(java.util.Objects.requireNonNull(native$capability$969), native$side$972).orElse(null);
                }
        });
    }

    /**
     * Finds the first source that can satisfy the complete request without
     * mutation. Traversal retains TC4's deterministic aa/bb/cc loop order and
     * never loads chunks.
     */
    public static Optional<EssentiaSourceRef> findSource(Level level, BlockPos origin, AspectId aspect, int amount, EssentiaSearch search) {
        return findSource(level, origin, aspect, amount, search, ignored -> true);
    }

    /**
     * Validates and invokes a directional extraction. Core consumers use this
     * boundary so a third-party endpoint cannot report a negative or
     * over-request transfer. Client execution is rejected without invoking
     * the endpoint; simulation remains available on either side.
     */
    public static int take(Level level, EssentiaTransport transport, AspectId aspect, int amount, Direction face, EssentiaTransferMode mode) {
        if (level == null || transport == null || face == null || mode == null) {
            RuntimeWarnings.warnOnce("essentia-take-request", "Ignoring invalid essentia transport extraction request");
            return 0;
        }
        if (!validAspect(aspect, amount))
            return 0;
        if (level.isClientSide && mode.executes() || !onOwningThread(level)) {
            return 0;
        }
        try {
            transport = transport.transferView();
            if (transport == null) {
                RuntimeWarnings.warnOnce("essentia-transfer-view", "Ignoring null essentia transport transfer view");
                return 0;
            }
            if (!transport.canOutputTo(face) || transport.availableEssentia(aspect, face) <= 0)
                return 0;
            int moved = transport.takeEssentia(aspect, amount, face, mode);
            return validateTransferResult(moved, amount, "extract");
        } catch (RuntimeException exception) {
            RuntimeWarnings.warnOnce("essentia-take-failure", "Skipping failed essentia transport extraction: {}", exception.toString());
            return 0;
        }
    }

    /**
     * Validates and invokes a directional insertion. Client execution is
     * rejected without invoking the endpoint; simulation remains available
     * on either side for prediction and presentation.
     */
    public static int add(Level level, EssentiaTransport transport, AspectId aspect, int amount, Direction face, EssentiaTransferMode mode) {
        if (level == null || transport == null || face == null || mode == null) {
            RuntimeWarnings.warnOnce("essentia-add-request", "Ignoring invalid essentia transport insertion request");
            return 0;
        }
        if (!validAspect(aspect, amount))
            return 0;
        if (level.isClientSide && mode.executes() || !onOwningThread(level)) {
            return 0;
        }
        try {
            if (!transport.canInputFrom(face))
                return 0;
            int moved = transport.addEssentia(aspect, amount, face, mode);
            return validateTransferResult(moved, amount, "insert");
        } catch (RuntimeException exception) {
            RuntimeWarnings.warnOnce("essentia-add-failure", "Skipping failed essentia transport insertion: {}", exception.toString());
            return 0;
        }
    }

    /**
     * Variant that filters loaded source references before simulation.
     */
    public static Optional<EssentiaSourceRef> findSource(Level level, BlockPos origin, AspectId aspect, int amount, EssentiaSearch search, Predicate<EssentiaSourceRef> filter) {
        if (level == null || origin == null || search == null || filter == null) {
            RuntimeWarnings.warnOnce("essentia-search-request", "Ignoring invalid essentia source search request");
            return Optional.empty();
        }
        if (!validAspect(aspect, amount))
            return Optional.empty();
        if (level.isClientSide || !onOwningThread(level)) {
            return Optional.empty();
        }
        int start = search.directional() ? 0 : -search.range();
        Direction direction = search.directional() ? search.direction() : Direction.UP;
        BlockPos first = offset(origin, direction, -search.range(), -search.range(), start);
        BlockPos last = offset(origin, direction, search.range(), search.range(), search.range() - 1);
        BlockPos minimum = new BlockPos(Math.min(first.getX(), last.getX()), Math.min(first.getY(), last.getY()), Math.min(first.getZ(), last.getZ()));
        BlockPos maximum = new BlockPos(Math.max(first.getX(), last.getX()), Math.max(first.getY(), last.getY()), Math.max(first.getZ(), last.getZ()));
        var candidates = EssentiaApi.native$BlockRegionQueries$blockEntityPositions(level, minimum, maximum, false);
        // Sorting the sparse positions preserves the exact aa/bb/cc selection
        // order, including negative faces and pending block-entity NBT.
        candidates.sort(java.util.Comparator.comparingInt((BlockPos pos) -> searchA(origin, direction, pos)).thenComparingInt((net.minecraft.core.BlockPos pos) -> searchB(origin, direction, pos)).thenComparingInt(pos -> searchC(origin, direction, pos)));
        for (BlockPos candidate : candidates) {
            if (candidate.equals(origin))
                continue;
            EssentiaSource source = source(level, candidate);
            if (source == null)
                continue;
            EssentiaSourceRef reference = new EssentiaSourceRef(level.dimension(), candidate);
            try {
                if (!filter.test(reference))
                    continue;
            } catch (RuntimeException exception) {
                RuntimeWarnings.warnOnce("essentia-filter-failure", "Skipping essentia search with failed source filter: {}", exception.toString());
                return Optional.empty();
            }
            int available = sourceAmount(source, aspect, amount, EssentiaTransferMode.SIMULATE, candidate);
            if (available == amount)
                return Optional.of(reference);
        }
        return Optional.empty();
    }

    /**
     * Finds and conditionally commits one all-or-nothing source extraction.
     * The returned source is the one that satisfied the request.
     */
    public static Optional<EssentiaSourceRef> extract(Level level, BlockPos origin, AspectId aspect, int amount, EssentiaSearch search, EssentiaTransferMode mode) {
        return extract(level, origin, aspect, amount, search, mode, ignored -> true);
    }

    /**
     * Filtered extraction used when a consumer excludes source families.
     */
    public static Optional<EssentiaSourceRef> extract(Level level, BlockPos origin, AspectId aspect, int amount, EssentiaSearch search, EssentiaTransferMode mode, Predicate<EssentiaSourceRef> filter) {
        if (mode == null) {
            RuntimeWarnings.warnOnce("essentia-extract-mode", "Ignoring essentia extraction without a transfer mode");
            return Optional.empty();
        }
        if (!validAspect(aspect, amount))
            return Optional.empty();
        Optional<EssentiaSourceRef> found = findSource(level, origin, aspect, amount, search, filter);
        if (found.isEmpty() || mode == EssentiaTransferMode.SIMULATE) {
            return found;
        }
        EssentiaSourceRef reference = found.orElseThrow();
        int extracted = extract(level, reference, aspect, amount, EssentiaTransferMode.EXECUTE);
        return extracted == amount ? found : Optional.empty();
    }

    /**
     * Re-resolves a previously found identity and conditionally extracts from
     * the current capability at that position. Removed, unloaded or
     * cross-dimension sources return zero; replaced providers are re-queried.
     */
    public static int extract(Level level, EssentiaSourceRef reference, AspectId aspect, int amount, EssentiaTransferMode mode) {
        if (level == null || reference == null || mode == null) {
            RuntimeWarnings.warnOnce("essentia-source-request", "Ignoring invalid essentia source extraction request");
            return 0;
        }
        if (!validAspect(aspect, amount))
            return 0;
        if (level.isClientSide || !onOwningThread(level) || !reference.dimension().equals(level.dimension())) {
            return 0;
        }
        EssentiaSource source = source(level, reference.position());
        if (source == null)
            return 0;
        int available = sourceAmount(source, aspect, amount, EssentiaTransferMode.SIMULATE, reference.position());
        if (available == 0 || mode == EssentiaTransferMode.SIMULATE) {
            return available;
        }
        return sourceAmount(source, aspect, amount, EssentiaTransferMode.EXECUTE, reference.position());
    }

    private static boolean validAspect(AspectId aspect, int amount) {
        if (aspect == null || amount <= 0 || AspectApi.registry().get(aspect).isEmpty()) {
            RuntimeWarnings.warnOnce("essentia-request", "Ignoring essentia request with invalid aspect or amount: {} / {}", aspect, amount);
            return false;
        }
        return true;
    }

    private static boolean onOwningThread(Level level) {
        if (level instanceof net.minecraft.server.level.ServerLevel server && !server.getServer().isSameThread()) {
            RuntimeWarnings.warnOnce("essentia-thread", "Ignoring essentia world access off the owning server thread");
            return false;
        }
        return true;
    }

    private static int sourceAmount(EssentiaSource source, AspectId aspect, int requested, EssentiaTransferMode mode, BlockPos position) {
        try {
            int result = source.extractEssentia(aspect, requested, mode);
            if (result == 0 || result == requested)
                return result;
            RuntimeWarnings.warnOnce("essentia-source-result", "Ignoring invalid all-or-nothing essentia result at {}: {} for {}", position, result, requested);
        } catch (RuntimeException exception) {
            RuntimeWarnings.warnOnce("essentia-source-failure", "Skipping failed essentia source at {}: {}", position, exception.toString());
        }
        return 0;
    }

    private static int validateTransferResult(int result, int requested, String operation) {
        if (result < 0 || result > requested) {
            RuntimeWarnings.warnOnce("essentia-transport-result", "Ignoring invalid essentia {} result: {} for {}", operation, result, requested);
            return 0;
        }
        return result;
    }

    private static int searchA(BlockPos origin, Direction direction, BlockPos pos) {
        return direction.getStepX() != 0 ? pos.getY() - origin.getY() : pos.getX() - origin.getX();
    }

    private static int searchB(BlockPos origin, Direction direction, BlockPos pos) {
        return direction.getStepY() != 0 || direction.getStepX() != 0 ? pos.getZ() - origin.getZ() : pos.getY() - origin.getY();
    }

    private static int searchC(BlockPos origin, Direction direction, BlockPos pos) {
        return direction.getStepY() != 0 ? (pos.getY() - origin.getY()) * direction.getStepY() : direction.getStepX() != 0 ? (pos.getX() - origin.getX()) * direction.getStepX() : (pos.getZ() - origin.getZ()) * direction.getStepZ();
    }

    private static BlockPos offset(BlockPos origin, Direction direction, int aa, int bb, int cc) {
        if (direction.getStepY() != 0) {
            return origin.offset(aa, cc * direction.getStepY(), bb);
        }
        if (direction.getStepX() == 0) {
            return origin.offset(aa, bb, cc * direction.getStepZ());
        }
        return origin.offset(cc * direction.getStepX(), aa, bb);
    }

    static private java.util.List<net.minecraft.core.BlockPos> native$BlockRegionQueries$blockEntityPositions(net.minecraft.world.level.Level level, net.minecraft.core.BlockPos minimum, net.minecraft.core.BlockPos maximum, boolean loadChunks) {
        java.util.Set<net.minecraft.core.BlockPos> positions = new java.util.HashSet<>();
        int minY = java.lang.Math.max(minimum.getY(), level.getMinBuildHeight());
        int maxY = java.lang.Math.min(maximum.getY(), level.getMaxBuildHeight() - 1);
        if (minY > maxY)
            return new java.util.ArrayList<>();
        for (int x = minimum.getX() >> 4; x <= maximum.getX() >> 4; x++) {
            for (int z = minimum.getZ() >> 4; z <= maximum.getZ() >> 4; z++) {
                net.minecraft.world.level.chunk.LevelChunk chunk = EssentiaApi.native$BlockRegionQueries$chunk(level, x, z, loadChunks);
                if (chunk == null)
                    continue;
                for (net.minecraft.core.BlockPos pos : chunk.getBlockEntitiesPos()) {
                    if (pos.getX() >= minimum.getX() && pos.getX() <= maximum.getX() && pos.getY() >= minY && pos.getY() <= maxY && pos.getZ() >= minimum.getZ() && pos.getZ() <= maximum.getZ()) {
                        positions.add(pos.immutable());
                    }
                }
                // Level.getBlockEntity also creates missing instances from an
                // EntityBlock state. Pending NBT / live-instance maps alone
                // would miss these positions and change immediate lookup semantics.
                EssentiaApi.native$BlockRegionQueries$appendMatchingPositions(chunk, minimum, maximum, minY, maxY, net.minecraft.world.level.block.state.BlockState::hasBlockEntity, positions);
            }
        }
        return new java.util.ArrayList<>(positions);
    }

    private static net.minecraft.world.level.chunk.LevelChunk native$BlockRegionQueries$chunk(net.minecraft.world.level.Level level, int x, int z, boolean loadChunks) {
        if (loadChunks)
            return level.getChunk(x, z);
        if (level.getChunkSource() instanceof net.minecraft.server.level.ServerChunkCache server) {
            return server.getChunkNow(x, z);
        }
        var access = level.getChunkSource().getChunk(x, z, net.minecraft.world.level.chunk.ChunkStatus.FULL, false);
        return access instanceof net.minecraft.world.level.chunk.LevelChunk loaded ? loaded : null;
    }

    private static void native$BlockRegionQueries$appendMatchingPositions(net.minecraft.world.level.chunk.LevelChunk chunk, net.minecraft.core.BlockPos minimum, net.minecraft.core.BlockPos maximum, int minY, int maxY, java.util.function.Predicate<net.minecraft.world.level.block.state.BlockState> predicate, java.util.Collection<net.minecraft.core.BlockPos> positions) {
        int minX = java.lang.Math.max(minimum.getX(), chunk.getPos().getMinBlockX());
        int maxX = java.lang.Math.min(maximum.getX(), chunk.getPos().getMaxBlockX());
        int minZ = java.lang.Math.max(minimum.getZ(), chunk.getPos().getMinBlockZ());
        int maxZ = java.lang.Math.min(maximum.getZ(), chunk.getPos().getMaxBlockZ());
        for (int sy = minY >> 4; sy <= maxY >> 4; sy++) {
            net.minecraft.world.level.chunk.LevelChunkSection section = chunk.getSection(chunk.getSectionIndex(sy << 4));
            if (!section.getStates().maybeHas(predicate))
                continue;
            int sectionMinY = java.lang.Math.max(minY, sy << 4);
            int sectionMaxY = java.lang.Math.min(maxY, (sy << 4) + 15);
            for (int x = minX; x <= maxX; x++) {
                for (int z = minZ; z <= maxZ; z++) {
                    for (int y = sectionMinY; y <= sectionMaxY; y++) {
                        if (predicate.test(section.getBlockState(x & 15, y & 15, z & 15))) {
                            positions.add(new net.minecraft.core.BlockPos(x, y, z));
                        }
                    }
                }
            }
        }
    }
}
