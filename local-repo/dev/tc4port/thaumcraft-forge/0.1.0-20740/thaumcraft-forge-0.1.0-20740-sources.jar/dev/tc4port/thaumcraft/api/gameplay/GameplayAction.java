package dev.tc4port.thaumcraft.api.gameplay;

/**
 * A compiled action or action group. Dispatch checks group conditions; each step checks its own requirements.
 * Groups use the native function queue and may finish after execute returns to a command caller.
 */
@FunctionalInterface
public interface GameplayAction {

    /**
     * Low-level execution after canExecute; callers normally use GameplayEventApi.dispatch.
     */
    void execute(GameplayContext context);

    default java.util.Set<String> requiredValues() {
        return java.util.Set.of();
    }

    default boolean canExecute(GameplayContext context) {
        return requiredValues().stream().allMatch(context.values()::containsKey);
    }

    static GameplayAction requiring(java.util.Set<String> values, GameplayAction action) {
        return requiring(values, action::canExecute, action);
    }

    static GameplayAction requiring(java.util.Set<String> values, java.util.function.Predicate<GameplayContext> requirement, GameplayAction action) {
        var required = java.util.Set.copyOf(values);
        return new GameplayAction() {

            @Override
            public java.util.Set<String> requiredValues() {
                return required;
            }

            @Override
            public boolean canExecute(GameplayContext context) {
                return required.stream().allMatch(context.values()::containsKey) && requirement.test(context);
            }

            @Override
            public void execute(GameplayContext context) {
                action.execute(context);
            }
        };
    }
}
