package dev.tc4port.thaumcraft.api.champion;

import java.util.Map;

/**
 * Bounds for the supported built-in behavior and assignment inputs.
 */
final class ChampionNumbers {

    private ChampionNumbers() {
    }

    static Map<String, Double> validate(Map<String, Double> numbers, boolean spawn) {
        if (numbers.size() > 16)
            throw new IllegalArgumentException("Too many champion parameters");
        numbers.forEach((name, value) -> {
            double minimum = 0, maximum = 1000000;
            boolean integral = false;
            if (spawn) {
                switch(name) {
                    case "roll_bound" ->
                        {
                            minimum = 1;
                            integral = true;
                        }
                    case "easy_offset", "hard_offset", "outer_offset", "special_room_offset", "disabled_room_offset", "hostile_biome_offset", "disabled_biome_offset" ->
                        {
                            minimum = -1000000;
                            integral = true;
                        }
                    case "minimum_health" ->
                        {
                        }
                    default ->
                        throw new IllegalArgumentException("Unknown champion spawn rule " + name);
                }
            } else {
                switch(name) {
                    case "chance", "damage_multiplier" ->
                        maximum = 1;
                    case "duration_ticks" ->
                        {
                            maximum = 1000000000;
                            integral = true;
                        }
                    case "tick_interval", "damage_choices" ->
                        {
                            minimum = 1;
                            integral = true;
                        }
                    case "damage_heal_divisor", "absorption_health_divisor" ->
                        minimum = .001;
                    case "burn_seconds", "damage_min", "minimum_heal", "heal_amount", "absorption_amount" ->
                        {
                        }
                    default ->
                        throw new IllegalArgumentException("Unknown champion parameter " + name);
                }
            }
            if (value == null || !Double.isFinite(value) || value < minimum || value > maximum || integral && Math.rint(value) != value) {
                throw new IllegalArgumentException("Invalid champion parameter " + name);
            }
        });
        return Map.copyOf(numbers);
    }
}
