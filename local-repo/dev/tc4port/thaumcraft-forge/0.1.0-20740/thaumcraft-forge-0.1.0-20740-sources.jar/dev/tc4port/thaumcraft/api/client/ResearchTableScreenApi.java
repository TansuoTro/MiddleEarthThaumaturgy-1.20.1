package dev.tc4port.thaumcraft.api.client;

import dev.tc4port.thaumcraft.api.Registration;
import dev.tc4port.thaumcraft.api.research.ResearchTableView;
import java.util.Objects;
import javax.annotation.Nullable;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.player.Inventory;

/**
 * Client-only screen replacement, installed during client setup. No extra menu or network channel is created.
 */
public final class ResearchTableScreenApi {

    private static ResourceLocation owner;

    private static Factory factory;

    private ResearchTableScreenApi() {
    }

    @FunctionalInterface
    public interface Factory {

        AbstractContainerScreen<?> create(ResearchTableView table, Inventory inventory, Component title);
    }

    /**
     * Exactly one active replacement. Close the handle to restore the built-in screen on the next open.
     */
    public static synchronized Registration register(ResourceLocation id, Factory replacement) {
        Objects.requireNonNull(id, "id");
        Objects.requireNonNull(replacement, "replacement");
        if (factory != null)
            throw new IllegalStateException("Research table screen already registered by " + owner);
        owner = id;
        factory = replacement;
        return Registration.of(() -> {
            synchronized (ResearchTableScreenApi.class) {
                if (factory == replacement) {
                    factory = null;
                    owner = null;
                }
            }
        });
    }

    /**
     * Returns null when the built-in screen should be used. The replacement must retain the supplied menu.
     */
    @Nullable
    public static synchronized AbstractContainerScreen<?> create(ResearchTableView table, Inventory inventory, Component title) {
        if (factory == null)
            return null;
        AbstractContainerScreen<?> screen = Objects.requireNonNull(factory.create(table, inventory, title), "screen");
        if (screen.getMenu() != table.menu())
            throw new IllegalArgumentException("Replacement must retain the research table menu");
        return screen;
    }
}
