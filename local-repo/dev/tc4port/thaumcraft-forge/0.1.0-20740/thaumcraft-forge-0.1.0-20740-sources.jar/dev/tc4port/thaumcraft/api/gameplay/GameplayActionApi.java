package dev.tc4port.thaumcraft.api.gameplay;

import com.mojang.serialization.Codec;
import dev.tc4port.thaumcraft.api.Registration;
import dev.tc4port.thaumcraft.common.GameplayActionRegistry;
import java.util.function.BiConsumer;
import net.minecraft.resources.ResourceLocation;

/**
 * Register custom actions and action parsers at startup. Registrations do not add events
 * to random pools. Closing a handle disables its already-compiled instances.
 */
public final class GameplayActionApi {

    private GameplayActionApi() {
    }

    /**
     * Register a namespaced JSON type. The parser receives a copy of the complete step and
     * returns an action without executing it. The common pipeline owns type, actor, target and chance.
     * Register ordinary callbacks with register(), then reference them through type: custom.
     */
    public static Registration registerType(ResourceLocation id, java.util.function.Function<com.google.gson.JsonObject, GameplayAction> parser) {
        return GameplayActionRegistry.registerType(id, parser);
    }

    public static <P> Registration register(ResourceLocation id, Codec<P> codec, BiConsumer<GameplayContext, P> action) {
        return GameplayActionRegistry.register(id, codec, action);
    }

    /**
     * Declare the expression inputs required by compiled actions.
     */
    public static <P> Registration register(ResourceLocation id, Codec<P> codec, java.util.function.Function<P, java.util.Set<String>> requiredValues, BiConsumer<GameplayContext, P> action) {
        return GameplayActionRegistry.register(id, codec, requiredValues, action);
    }

    /**
     * Context and numeric inputs are checked when this action runs.
     */
    public static <P> Registration register(ResourceLocation id, Codec<P> codec, java.util.function.Function<P, java.util.Set<String>> requiredValues, java.util.function.Predicate<GameplayContext> requirement, BiConsumer<GameplayContext, P> action) {
        return GameplayActionRegistry.register(id, codec, requiredValues, requirement, action);
    }

    public static <P> Registration register(ResourceLocation id, Codec<P> codec, GameplayTarget target, BiConsumer<GameplayContext, P> action) {
        return register(id, codec, ignored -> java.util.Set.of(), target, action);
    }

    public static <P> Registration register(ResourceLocation id, Codec<P> codec, java.util.function.Function<P, java.util.Set<String>> requiredValues, java.util.function.BiPredicate<GameplayContext, P> requirement, BiConsumer<GameplayContext, P> action) {
        return GameplayActionRegistry.register(id, codec, requiredValues, requirement, action);
    }

    /**
     * Parse one action group with the same schema used by named groups and owner roll files.
     */
    public static GameplayAction compileGroup(com.google.gson.JsonElement definition) {
        return dev.tc4port.thaumcraft.common.GameplayActionGroups.compile(definition.getAsJsonObject());
    }
}
