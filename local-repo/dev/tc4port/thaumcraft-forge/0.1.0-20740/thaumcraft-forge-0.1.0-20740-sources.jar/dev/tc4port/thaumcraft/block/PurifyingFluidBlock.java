package dev.tc4port.thaumcraft.block;

import dev.tc4port.thaumcraft.registry.TCSounds;
import com.mojang.serialization.MapCodec;
import dev.tc4port.thaumcraft.block.entity.MagicFluidBlockEntity;
import dev.tc4port.thaumcraft.nativeimpl.NativeBucketPickup;
import dev.tc4port.thaumcraft.common.PlayerKnowledgeService;
import dev.tc4port.thaumcraft.registry.TCEffects;
import dev.tc4port.thaumcraft.registry.TCFluids;
import dev.tc4port.thaumcraft.registry.TCItems;
import java.util.Optional;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.EntityBlock;
import net.minecraft.world.level.block.HalfTransparentBlock;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.IntegerProperty;
import net.minecraft.world.level.material.Fluid;
import net.minecraft.world.level.material.FluidState;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;
import net.minecraft.world.level.block.BucketPickup;

/**
 * World state, rendering and contact behavior for classic Purifying Fluid.
 */
public final class PurifyingFluidBlock extends HalfTransparentBlock implements NativeBucketPickup, MetadataFluidRenderBlock, EntityBlock {

    public static final MapCodec<PurifyingFluidBlock> CODEC = PurifyingFluidBlock.native$BlockCodecPlatform$simple(PurifyingFluidBlock::new);

    public static final IntegerProperty LEVEL = IntegerProperty.create("level", 0, 7);

    public PurifyingFluidBlock(BlockBehaviour.Properties properties) {
        super(properties);
        this.registerDefaultState(this.stateDefinition.any().setValue(LEVEL, 0));
    }

    @Override
    public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        return new MagicFluidBlockEntity(pos, state);
    }

    protected MapCodec<PurifyingFluidBlock> codec() {
        return CODEC;
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(LEVEL);
    }

    @Override
    public FluidState getFluidState(BlockState state) {
        return TCFluids.PURIFYING_FLUID.get().stateForAmount(this.amount(state));
    }

    @Override
    public int quantaPerBlock() {
        return TCFluids.PURIFYING_FLUID.get().quantaPerBlock();
    }

    @Override
    public boolean flowsUpward() {
        return false;
    }

    @Override
    public boolean hasContinuousRenderOrigin(BlockState origin) {
        return !origin.getFluidState().isEmpty() || origin.is(this) || origin.getBlock() instanceof LiquidDeathBlock;
    }

    @Override
    public int amount(BlockState state) {
        return state.is(this) ? this.quantaPerBlock() - state.getValue(LEVEL) : 0;
    }

    @Override
    public float filledPercentage(BlockState state) {
        return this.amount(state) / (float) this.quantaPerBlock();
    }

    @Override
    public VoxelShape getCollisionShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
        return Shapes.empty();
    }

    @Override
    public VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
        return Shapes.empty();
    }

    @Override
    public boolean canBeReplaced(BlockState state, BlockPlaceContext context) {
        return true;
    }

    @Override
    public boolean canBeReplaced(BlockState state, Fluid fluid) {
        return true;
    }

    @Override
    public void onPlace(BlockState state, Level level, BlockPos pos, BlockState oldState, boolean movedByPiston) {
        if (!level.isClientSide) {
            if (oldState.is(this) && level.getBlockEntity(pos) instanceof MagicFluidBlockEntity stored) {
                stored.onLayerChange(oldState, state);
            }
            TCFluids.PURIFYING_FLUID.get().schedule(level, pos);
        }
    }

    @Override
    public void neighborChanged(BlockState state, Level level, BlockPos pos, Block neighborBlock, BlockPos neighborPos, boolean movedByPiston) {
        if (!level.isClientSide) {
            TCFluids.PURIFYING_FLUID.get().schedule(level, pos);
        }
    }

    @Override
    public void randomTick(BlockState state, ServerLevel level, BlockPos pos, RandomSource random) {
        state.getFluidState().tick(level, pos);
    }

    @Override
    public void entityInside(BlockState state, Level level, BlockPos pos, Entity entity) {
        if (level.isClientSide || state.getValue(LEVEL) != 0 || !(entity instanceof Player player) || (switch(0) {
            default ->
                {
                    net.minecraft.world.entity.LivingEntity native$operand$14112 = player;
                    net.minecraft.core.Holder<net.minecraft.world.effect.MobEffect> native$operand$14113 = ((net.minecraft.core.Holder<net.minecraft.world.effect.MobEffect>) (net.minecraft.core.Holder<?>) (TCEffects.WARP_WARD).getHolder().orElseThrow());
                    boolean native$result$14114 = (native$operand$14112.hasEffect(native$operand$14113.value()));
                    yield native$result$14114;
                }
        })) {
            return;
        }
        int permanentWarp = PlayerKnowledgeService.get(player).permanentWarp();
        int divisor = permanentWarp > 0 ? Math.max(1, (int) Math.sqrt(permanentWarp)) : 1;
        player.addEffect((switch(0) {
            default ->
                {
                    net.minecraft.core.Holder<net.minecraft.world.effect.MobEffect> native$operand$14115 = ((net.minecraft.core.Holder<net.minecraft.world.effect.MobEffect>) (net.minecraft.core.Holder<?>) (TCEffects.WARP_WARD).getHolder().orElseThrow());
                    int native$operand$14116 = Math.min(dev.tc4port.thaumcraft.common.TCGameplayParameters.BLOCKS_PURIFYING_FLUID_MAXIMUM_WARD_DURATION.intValue(), dev.tc4port.thaumcraft.common.TCGameplayParameters.BLOCKS_PURIFYING_FLUID_WARD_DURATION_NUMERATOR.intValue() / divisor);
                    int native$operand$14117 = 0;
                    boolean native$operand$14118 = true;
                    boolean native$operand$14119 = true;
                    net.minecraft.world.effect.MobEffectInstance native$result$14120 = (new net.minecraft.world.effect.MobEffectInstance(native$operand$14115.value(), native$operand$14116, PurifyingFluidBlock.native$MobEffectPlatform$safeAmplifier(native$operand$14115, native$operand$14117), native$operand$14118, native$operand$14119));
                    yield native$result$14120;
                }
        }));
        level.setBlock(pos, Blocks.AIR.defaultBlockState(), 3);
    }

    @Override
    public void animateTick(BlockState state, Level level, BlockPos pos, RandomSource random) {
        int metadata = state.getValue(LEVEL);
        dev.tc4port.thaumcraft.client.CrucibleBubbleParticle.tickPurifyingFluid(level, pos, metadata, random);
        if (random.nextInt(25) == 0) {
            level.playLocalSound(pos, TCSounds.PURIFYING_FLUID_BUBBLE.get(), SoundSource.BLOCKS, 0.1F + random.nextFloat() * 0.1F, 0.9F + random.nextFloat() * 0.15F, false);
        }
    }

    public ItemStack pickupBlock(net.minecraft.world.level.LevelAccessor native$callbackInput$1163, net.minecraft.core.BlockPos native$callbackInput$1164, net.minecraft.world.level.block.state.BlockState native$callbackInput$1165) {
        net.minecraft.world.entity.player.Player player = null;
        net.minecraft.world.level.LevelAccessor level = native$callbackInput$1163;
        net.minecraft.core.BlockPos pos = native$callbackInput$1164;
        net.minecraft.world.level.block.state.BlockState state = native$callbackInput$1165;
        if (level.getBlockEntity(pos) instanceof MagicFluidBlockEntity stored && stored.volume() < 1000) {
            return ItemStack.EMPTY;
        }
        if (state.getValue(LEVEL) != 0) {
            return ItemStack.EMPTY;
        }
        level.setBlock(pos, Blocks.AIR.defaultBlockState(), 11);
        return new ItemStack(TCItems.PURIFYING_FLUID_BUCKET.get());
    }

    @Override
    public Optional<SoundEvent> getPickupSound() {
        return Optional.of(SoundEvents.BUCKET_FILL);
    }

    /**
     * Native shift-based effects need a smaller ceiling than the stored amplifier byte.
     */
    static private int native$MobEffectPlatform$safeAmplifier(net.minecraft.core.Holder<net.minecraft.world.effect.MobEffect> effect, int amplifier) {
        net.minecraft.world.effect.MobEffect type = effect.value();
        int maximum = type == net.minecraft.world.effect.MobEffects.HEAL || type == net.minecraft.world.effect.MobEffects.HARM ? 16 : type == net.minecraft.world.effect.MobEffects.REGENERATION || type == net.minecraft.world.effect.MobEffects.POISON || type == net.minecraft.world.effect.MobEffects.WITHER ? 31 : 127;
        return java.lang.Math.max(0, java.lang.Math.min(maximum, amplifier));
    }

    static private <B extends net.minecraft.world.level.block.Block> com.mojang.serialization.MapCodec<B> native$BlockCodecPlatform$simple(java.util.function.Function<net.minecraft.world.level.block.state.BlockBehaviour.Properties, B> factory) {
        // Vanilla 1.21's Properties codec is a unit codec. Retain that schema for shared block definitions.
        return com.mojang.serialization.codecs.RecordCodecBuilder.mapCodec(instance -> instance.group(com.mojang.serialization.Codec.unit(net.minecraft.world.level.block.state.BlockBehaviour.Properties::of).fieldOf("properties").forGetter((B block) -> net.minecraft.world.level.block.state.BlockBehaviour.Properties.copy(block))).apply(instance, factory));
    }
}
