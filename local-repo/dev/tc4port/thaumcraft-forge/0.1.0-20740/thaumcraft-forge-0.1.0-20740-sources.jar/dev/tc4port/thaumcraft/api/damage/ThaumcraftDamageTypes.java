package dev.tc4port.thaumcraft.api.damage;

import net.minecraft.core.Holder;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageType;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.Level;

/**
 * Stable keys and attributed factories for Thaumcraft damage identities.
 */
public final class ThaumcraftDamageTypes {

    public static final ResourceKey<DamageType> FLUX_TAINT = key("flux_taint");

    public static final ResourceKey<DamageType> DISSOLVE = key("dissolve");

    public static final ResourceKey<DamageType> TENTACLE = key("tentacle");

    public static final ResourceKey<DamageType> AIR_ARROW = key("air_arrow");

    public static final ResourceKey<DamageType> FIRE_ARROW = key("fire_arrow");

    public static final ResourceKey<DamageType> ORDER_ARROW = key("order_arrow");

    private ThaumcraftDamageTypes() {
    }

    public static DamageSource fluxTaint(Level level) {
        return source(level, FLUX_TAINT);
    }

    public static DamageSource dissolve(Level level) {
        return source(level, DISSOLVE);
    }

    public static DamageSource tentacle(Level level, LivingEntity attacker) {
        return direct(level, TENTACLE, attacker);
    }

    /**
     * Creates one of the exposed primal-arrow identities with direct-arrow
     * and causing-owner attribution.
     */
    public static DamageSource primalArrow(Level level, ResourceKey<DamageType> kind, Entity arrow, Entity owner) {
        if (!kind.equals(AIR_ARROW) && !kind.equals(FIRE_ARROW) && !kind.equals(ORDER_ARROW)) {
            throw new IllegalArgumentException("Not a Thaumcraft primal-arrow damage type: " + kind);
        }
        return new DamageSource(holder(level, kind), arrow, owner);
    }

    private static ResourceKey<DamageType> key(String path) {
        return ResourceKey.create(Registries.DAMAGE_TYPE, java.util.Objects.requireNonNull(ResourceLocation.tryBuild("thaumcraft", path)));
    }

    private static DamageSource source(Level level, ResourceKey<DamageType> kind) {
        return new DamageSource(holder(level, kind));
    }

    private static DamageSource direct(Level level, ResourceKey<DamageType> kind, Entity attacker) {
        return new DamageSource(holder(level, kind), attacker);
    }

    private static Holder.Reference<DamageType> holder(Level level, ResourceKey<DamageType> kind) {
        return level.registryAccess().registryOrThrow(Registries.DAMAGE_TYPE).getHolderOrThrow(kind);
    }
}
