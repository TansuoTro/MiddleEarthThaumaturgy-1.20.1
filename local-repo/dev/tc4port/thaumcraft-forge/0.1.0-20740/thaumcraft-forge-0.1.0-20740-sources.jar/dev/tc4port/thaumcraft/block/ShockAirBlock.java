package dev.tc4port.thaumcraft.block;

import dev.tc4port.thaumcraft.registry.TCSounds;
import dev.tc4port.thaumcraft.common.TCGameplayParameters;
import com.mojang.serialization.MapCodec;
import dev.tc4port.thaumcraft.registry.TCParticles;
import net.minecraft.core.BlockPos;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;

/**
 * Split identity for {@code BlockAiry} metadata 10, the temporary electrified
 * air left by an earth-shock orb.
 */
public final class ShockAirBlock extends TemporaryAirBlock implements dev.tc4port.thaumcraft.nativeimpl.ClientExtensionTarget {

    public static final MapCodec<ShockAirBlock> CODEC = ShockAirBlock.native$BlockCodecPlatform$simple(ShockAirBlock::new);

    public ShockAirBlock(BlockBehaviour.Properties properties) {
        super(properties);
    }

    protected MapCodec<ShockAirBlock> codec() {
        return CODEC;
    }

    @Override
    public RenderShape getRenderShape(BlockState state) {
        return RenderShape.INVISIBLE;
    }

    @Override
    public VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
        return Shapes.empty();
    }

    @Override
    public VoxelShape getCollisionShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
        return Shapes.empty();
    }

    @Override
    public void entityInside(BlockState state, Level level, BlockPos pos, Entity entity) {
        Vec3 movement = entity.getDeltaMovement();
        entity.setDeltaMovement(movement.x * TCGameplayParameters.EFFECTS_ARCANE_FIELDS_SHOCK_HORIZONTAL_DAMPING.floatValue(), movement.y, movement.z * TCGameplayParameters.EFFECTS_ARCANE_FIELDS_SHOCK_HORIZONTAL_DAMPING.floatValue());
        if (level.isClientSide) {
            return;
        }
        entity.hurt(dev.tc4port.thaumcraft.common.FocusFieldDamage.source(level, pos), TCGameplayParameters.EFFECTS_ARCANE_FIELDS_SHOCK_BASE_DAMAGE.floatValue() + level.random.nextInt(TCGameplayParameters.EFFECTS_ARCANE_FIELDS_SHOCK_DAMAGE_CHOICES.intValue()));
        if (level.random.nextInt(TCGameplayParameters.EFFECTS_ARCANE_FIELDS_SHOCK_REMOVAL_DENOMINATOR.intValue()) == 0) {
            level.removeBlock(pos, false);
        }
    }

    @Override
    public void animateTick(BlockState state, Level level, BlockPos pos, RandomSource random) {
        float height = random.nextFloat() * 0.33F;
        var particle = switch(random.nextInt(3)) {
            case 1 ->
                TCParticles.SHOCK_SPARK_1.get();
            case 2 ->
                TCParticles.SHOCK_SPARK_2.get();
            default ->
                TCParticles.SHOCK_SPARK_0.get();
        };
        level.addParticle(particle, pos.getX() + random.nextFloat(), pos.getY() + 0.1515F + height / 2.0F, pos.getZ() + random.nextFloat(), 0.65F + random.nextFloat() * 0.1F, 0.33F + height, 0.0);
        if (random.nextInt(50) == 0) {
            level.playLocalSound(pos, TCSounds.JACOBS.get(), SoundSource.BLOCKS, 0.5F, 1.0F + (random.nextFloat() - random.nextFloat()) * 0.2F, false);
        }
    }

    static private <B extends net.minecraft.world.level.block.Block> com.mojang.serialization.MapCodec<B> native$BlockCodecPlatform$simple(java.util.function.Function<net.minecraft.world.level.block.state.BlockBehaviour.Properties, B> factory) {
        // Vanilla 1.21's Properties codec is a unit codec. Retain that schema for shared block definitions.
        return com.mojang.serialization.codecs.RecordCodecBuilder.mapCodec(instance -> instance.group(com.mojang.serialization.Codec.unit(net.minecraft.world.level.block.state.BlockBehaviour.Properties::of).fieldOf("properties").forGetter((B block) -> net.minecraft.world.level.block.state.BlockBehaviour.Properties.copy(block))).apply(instance, factory));
    }
}
