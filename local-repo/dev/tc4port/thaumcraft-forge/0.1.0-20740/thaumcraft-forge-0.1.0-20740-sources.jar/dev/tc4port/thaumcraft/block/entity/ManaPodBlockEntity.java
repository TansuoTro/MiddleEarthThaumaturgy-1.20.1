package dev.tc4port.thaumcraft.block.entity;

import dev.tc4port.thaumcraft.aspect.AspectCatalog;
import dev.tc4port.thaumcraft.api.aspect.AspectAmounts;
import dev.tc4port.thaumcraft.api.aspect.AspectContainerView;
import dev.tc4port.thaumcraft.api.aspect.AspectId;
import dev.tc4port.thaumcraft.block.ManaPodBlock;
import dev.tc4port.thaumcraft.registry.ManaPlants;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.entity.BlockEntityType;

public final class ManaPodBlockEntity extends net.minecraft.world.level.block.entity.BlockEntity implements AspectContainerView {

    private static final String ASPECT_KEY = "aspect";

    private AspectId aspect;

    public ManaPodBlockEntity(BlockPos pos, BlockState state) {
        super(ManaPlants.podType(), pos, state);
    }

    public AspectId aspect() {
        return this.aspect;
    }

    @Override
    public AspectAmounts visibleAspects() {
        return this.getBlockState().getBlock() instanceof ManaPodBlock && this.getBlockState().getValue(ManaPodBlock.AGE) == 7 && this.aspect != null ? AspectAmounts.of(this.aspect, 1) : AspectAmounts.EMPTY;
    }

    public void setAspect(AspectId aspect) {
        this.aspect = aspect;
        this.markUpdated();
    }

    public void checkGrowth(RandomSource random) {
        if (this.level == null || this.level.isClientSide) {
            return;
        }
        BlockState state = this.getBlockState();
        if (!(state.getBlock() instanceof ManaPodBlock)) {
            return;
        }
        int age = state.getValue(ManaPodBlock.AGE);
        if (age < 7) {
            age++;
            this.level.setBlock(this.worldPosition, state.setValue(ManaPodBlock.AGE, age), 3);
        }
        if (age <= 2) {
            return;
        }
        LinkedHashMap<AspectId, Integer> nearby = new LinkedHashMap<>();
        addAspect(nearby, this.aspect);
        for (Direction direction : List.of(Direction.NORTH, Direction.SOUTH, Direction.WEST, Direction.EAST)) {
            BlockPos neighborPos = this.worldPosition.relative(direction);
            if (!this.level.isLoaded(neighborPos))
                continue;
            BlockEntity adjacent = this.level.getBlockEntity(neighborPos);
            if (adjacent instanceof ManaPodBlockEntity pod) {
                addAspect(nearby, pod.aspect);
            }
        }
        if (age == 3 && nearby.size() > 1) {
            List<AspectId> aspects = List.copyOf(nearby.keySet());
            List<AspectId> outcomes = new ArrayList<>();
            for (int first = 0; first < aspects.size(); first++) {
                outcomes.add(aspects.get(first));
                for (int second = 0; second < aspects.size(); second++) {
                    if (first == second) {
                        continue;
                    }
                    AspectId combination = combination(aspects.get(first), aspects.get(second));
                    if (combination != null) {
                        outcomes.add(combination);
                        outcomes.add(combination);
                    }
                }
            }
            if (!outcomes.isEmpty()) {
                this.aspect = outcomes.get(random.nextInt(outcomes.size()));
            }
        }
        if (this.aspect == null && !nearby.isEmpty()) {
            this.aspect = nearby.entrySet().stream().max(Comparator.comparingInt(Map.Entry::getValue)).orElseThrow().getKey();
        }
        if (this.aspect == null) {
            this.aspect = random.nextInt(8) == 0 ? AspectId.parse("herba") : AspectCatalog.randomNaturalPrimal(random);
        }
        this.markUpdated();
    }

    private static void addAspect(Map<AspectId, Integer> aspects, AspectId aspect) {
        if (AspectCatalog.contains(aspect)) {
            aspects.merge(aspect, 1, Integer::sum);
        }
    }

    private static AspectId combination(AspectId first, AspectId second) {
        return AspectCatalog.combination(first, second).orElse(null);
    }

    private void markUpdated() {
        this.setChanged();
        if (this.level != null) {
            this.level.sendBlockUpdated(this.worldPosition, this.getBlockState(), this.getBlockState(), 3);
        }
    }

    protected void readState(CompoundTag tag) {
        java.lang.String stored = tag.contains(dev.tc4port.thaumcraft.block.entity.ManaPodBlockEntity.ASPECT_KEY) ? tag.getString(dev.tc4port.thaumcraft.block.entity.ManaPodBlockEntity.ASPECT_KEY) : "";
        dev.tc4port.thaumcraft.api.aspect.AspectId previous = this.aspect;
        this.aspect = stored(stored);
        if (level != null && level.isClientSide && !java.util.Objects.equals(previous, aspect)) {
            level.sendBlockUpdated(worldPosition, getBlockState(), getBlockState(), 3);
        }
    }

    protected void writeState(CompoundTag tag) {
        if (this.aspect != null) {
            tag.putString(dev.tc4port.thaumcraft.block.entity.ManaPodBlockEntity.ASPECT_KEY, this.aspect.serialized());
        }
    }

    @Override
    public Packet<ClientGamePacketListener> getUpdatePacket() {
        return ClientboundBlockEntityDataPacket.create(this);
    }

    private static AspectId stored(String value) {
        try {
            return value == null || value.isEmpty() ? null : AspectId.parse(value);
        } catch (IllegalArgumentException ignored) {
            return null;
        }
    }

    @Override
    public void load(CompoundTag tag) {
        super.load(tag);
        {
            net.minecraft.nbt.CompoundTag native$bodyOperand$6185 = tag;
            native$bodyReturn$6189: {
                if (true) {
                    java.lang.String native$bodyBinding$6186 = native$bodyOperand$6185.contains(dev.tc4port.thaumcraft.block.entity.ManaPodBlockEntity.ASPECT_KEY) ? native$bodyOperand$6185.getString(dev.tc4port.thaumcraft.block.entity.ManaPodBlockEntity.ASPECT_KEY) : "";
                    dev.tc4port.thaumcraft.api.aspect.AspectId native$bodyBinding$6187 = this.aspect;
                    this.aspect = stored(native$bodyBinding$6186);
                    if (level != null && level.isClientSide && !java.util.Objects.equals(native$bodyBinding$6187, aspect)) {
                        level.sendBlockUpdated(worldPosition, getBlockState(), getBlockState(), 3);
                    }
                }
            }
        }
    }

    @Override
    protected void saveAdditional(CompoundTag tag) {
        super.saveAdditional(tag);
        {
            net.minecraft.nbt.CompoundTag native$bodyOperand$6190 = tag;
            native$bodyReturn$6192: {
                if (true) {
                    if (this.aspect != null) {
                        native$bodyOperand$6190.putString(dev.tc4port.thaumcraft.block.entity.ManaPodBlockEntity.ASPECT_KEY, this.aspect.serialized());
                    }
                }
            }
        }
    }

    @Override
    public CompoundTag getUpdateTag() {
        return saveWithoutMetadata();
    }
}
