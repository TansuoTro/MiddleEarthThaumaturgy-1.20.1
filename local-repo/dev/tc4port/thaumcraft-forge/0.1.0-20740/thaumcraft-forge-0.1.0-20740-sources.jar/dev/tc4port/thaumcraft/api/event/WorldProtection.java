package dev.tc4port.thaumcraft.api.event;

import dev.tc4port.thaumcraft.api.event.OrderedCallbacks;
import javax.annotation.Nullable;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.BlockGetter;

/**
 * Shared server-side policy for public events, native operation guards and owned world edits.
 */
public final class WorldProtection {

    public enum Action {

        BREAK,
        PLACE,
        MODIFY,
        GROW,
        MOVE,
        EXPLODE,
        FILL_FLUID,
        TICK
    }

    @FunctionalInterface
    public interface Permission {

        /**
         * Actor is null for natural changes, automation or events without actor information.
         */
        boolean allow(ServerLevel level, BlockPos pos, Action action, @Nullable Entity actor);
    }

    private static final OrderedCallbacks<Permission> RULES = new OrderedCallbacks<>();

    private static boolean eventsRegistered;

    private WorldProtection() {
    }

    /**
     * Register during common initialization, before gameplay event listeners. Any rule may veto.
     */
    public static synchronized void register(int priority, String id, Permission permission) {
        RULES.register(priority, id, permission);
        if (!eventsRegistered) {
            registerEvents();
            eventsRegistered = true;
        }
    }

    /**
     * No context allocation, world mutation or chunk loading; policies only query the destination.
     */
    public static boolean allow(BlockGetter level, BlockPos pos, Action action, @Nullable Entity actor) {
        if (!(level instanceof ServerLevel server))
            return true;
        var rules = RULES.values();
        for (int i = 0; i < rules.size(); i++) {
            if (!rules.get(i).allow(server, pos, action, actor))
                return false;
        }
        return true;
    }

    private static void registerEvents() {
        dev.tc4port.thaumcraft.api.event.WorldProtection.native$subscription$11203("HIGHEST", false);
        dev.tc4port.thaumcraft.api.event.WorldProtection.native$subscription$11205();
        dev.tc4port.thaumcraft.api.event.WorldProtection.native$subscription$11207();
        dev.tc4port.thaumcraft.api.event.WorldProtection.native$subscription$11209();
        dev.tc4port.thaumcraft.api.event.WorldProtection.native$subscription$11211();
        {
            dev.tc4port.thaumcraft.api.event.WorldProtection.native$subscription$12482("NORMAL", false);
        }
        dev.tc4port.thaumcraft.api.event.WorldProtection.native$subscription$11216();
        dev.tc4port.thaumcraft.api.event.WorldProtection.native$subscription$11218();
        dev.tc4port.thaumcraft.api.event.WorldProtection.native$subscription$11220();
        dev.tc4port.thaumcraft.api.event.WorldProtection.native$subscription$11222();
    }

    static private void native$subscription$11203(java.lang.String priority, boolean receiveCancelled) {
        net.minecraftforge.common.MinecraftForge.EVENT_BUS.addListener(net.minecraftforge.eventbus.api.EventPriority.valueOf(priority), receiveCancelled, (net.minecraftforge.event.level.BlockEvent.BreakEvent e) -> {
            net.minecraft.world.level.LevelAccessor native$snapshot$12301 = e.getLevel();
            net.minecraft.core.BlockPos native$snapshot$12302 = e.getPos();
            net.minecraft.world.level.block.state.BlockState native$snapshot$12303 = e.getState();
            net.minecraft.world.entity.player.Player native$snapshot$12304 = e.getPlayer();
            java.util.function.Consumer<java.lang.Boolean> native$snapshot$12305 = e::setCanceled;
            java.lang.Object native$snapshot$12306 = e;
            java.util.function.BooleanSupplier native$snapshot$12307 = e::isCanceled;
            dev.tc4port.thaumcraft.api.event.WorldProtection.native$snapshotHandler$11469(native$snapshot$12301, native$snapshot$12302, native$snapshot$12303, native$snapshot$12304, native$snapshot$12305, native$snapshot$12306, native$snapshot$12307);
        });
    }

    static private void native$subscription$11205() {
        net.minecraftforge.common.MinecraftForge.EVENT_BUS.addListener((net.minecraftforge.event.level.BlockEvent.EntityPlaceEvent event) -> {
            {
                net.minecraft.world.level.LevelAccessor native$snapshot$12270 = event.getLevel();
                net.minecraft.core.BlockPos native$snapshot$12271 = event.getPos();
                net.minecraft.world.entity.Entity native$snapshot$12272 = event.getEntity();
                java.util.List<net.minecraft.core.BlockPos> native$snapshot$12273 = event instanceof net.minecraftforge.event.level.BlockEvent.EntityMultiPlaceEvent multi ? multi.getReplacedBlockSnapshots().stream().map(snapshot -> snapshot.getPos()).toList() : java.util.List.of(event.getPos());
                java.util.function.Consumer<java.lang.Boolean> native$snapshot$12274 = event::setCanceled;
                dev.tc4port.thaumcraft.api.event.WorldProtection.native$snapshotHandler$11485(native$snapshot$12270, native$snapshot$12271, native$snapshot$12272, native$snapshot$12273, native$snapshot$12274);
            }
        });
    }

    static private void native$subscription$11207() {
        net.minecraftforge.common.MinecraftForge.EVENT_BUS.addListener((net.minecraftforge.event.level.BlockEvent.FluidPlaceBlockEvent e) -> {
            net.minecraft.world.level.LevelAccessor native$snapshot$12308 = e.getLevel();
            net.minecraft.core.BlockPos native$snapshot$12309 = e.getPos();
            net.minecraftforge.event.level.BlockEvent.FluidPlaceBlockEvent native$snapshotCapture$12310 = e;
            dev.tc4port.thaumcraft.api.event.WorldProtection.native$subscription$12479(native$snapshot$12308, native$snapshot$12309, native$snapshotCapture$12310);
        });
    }

    static private void native$subscription$11209() {
        net.minecraftforge.common.MinecraftForge.EVENT_BUS.addListener((net.minecraftforge.event.level.BlockEvent.FarmlandTrampleEvent e) -> {
            net.minecraft.world.level.LevelAccessor native$snapshot$12311 = e.getLevel();
            net.minecraft.core.BlockPos native$snapshot$12312 = e.getPos();
            java.util.function.Consumer<java.lang.Boolean> native$snapshot$12313 = e::setCanceled;
            dev.tc4port.thaumcraft.api.event.WorldProtection.native$snapshotHandler$11505(native$snapshot$12311, native$snapshot$12312, native$snapshot$12313);
        });
    }

    static private void native$subscription$11211() {
        net.minecraftforge.common.MinecraftForge.EVENT_BUS.addListener((net.minecraftforge.event.level.BlockEvent.BlockToolModificationEvent e) -> {
            net.minecraft.world.level.LevelAccessor native$snapshot$12314 = e.getLevel();
            net.minecraft.core.BlockPos native$snapshot$12315 = e.getPos();
            java.util.function.Consumer<java.lang.Boolean> native$snapshot$12316 = e::setCanceled;
            dev.tc4port.thaumcraft.api.event.WorldProtection.native$snapshotHandler$11509(native$snapshot$12314, native$snapshot$12315, native$snapshot$12316);
        });
    }

    static private void native$subscription$11216() {
        net.minecraftforge.common.MinecraftForge.EVENT_BUS.addListener((net.minecraftforge.event.level.BlockEvent.CropGrowEvent.Pre e) -> {
            net.minecraft.world.level.LevelAccessor native$snapshot$12317 = e.getLevel();
            net.minecraft.core.BlockPos native$snapshot$12318 = e.getPos();
            net.minecraftforge.event.level.BlockEvent.CropGrowEvent.Pre native$snapshotCapture$12319 = e;
            dev.tc4port.thaumcraft.api.event.WorldProtection.native$subscription$12485(native$snapshot$12317, native$snapshot$12318, native$snapshotCapture$12319);
        });
    }

    static private void native$subscription$11218() {
        net.minecraftforge.common.MinecraftForge.EVENT_BUS.addListener((net.minecraftforge.event.entity.living.LivingDestroyBlockEvent e) -> {
            net.minecraft.world.entity.LivingEntity native$snapshot$12320 = e.getEntity();
            net.minecraft.core.BlockPos native$snapshot$12321 = e.getPos();
            java.util.function.Consumer<java.lang.Boolean> native$snapshot$12322 = e::setCanceled;
            dev.tc4port.thaumcraft.api.event.WorldProtection.native$snapshotHandler$11521(native$snapshot$12320, native$snapshot$12321, native$snapshot$12322);
        });
    }

    static private void native$subscription$11220() {
        net.minecraftforge.common.MinecraftForge.EVENT_BUS.addListener((net.minecraftforge.event.level.ExplosionEvent.Detonate e) -> {
            net.minecraft.world.level.Level native$snapshot$12323 = e.getLevel();
            java.util.List<net.minecraft.core.BlockPos> native$snapshot$12324 = e.getAffectedBlocks();
            dev.tc4port.thaumcraft.api.event.WorldProtection.native$snapshotHandler$11529(native$snapshot$12323, native$snapshot$12324);
        });
    }

    static private void native$subscription$11222() {
        net.minecraftforge.common.MinecraftForge.EVENT_BUS.addListener((net.minecraftforge.event.level.PistonEvent.Pre e) -> {
            net.minecraft.world.level.LevelAccessor native$snapshot$12325 = e.getLevel();
            net.minecraft.core.BlockPos native$snapshot$12326 = e.getPos();
            net.minecraft.core.BlockPos native$snapshot$12327 = e.getFaceOffsetPos();
            net.minecraft.world.level.block.piston.PistonStructureResolver native$snapshot$12328 = e.getStructureHelper();
            java.util.function.Consumer<java.lang.Boolean> native$snapshot$12329 = e::setCanceled;
            dev.tc4port.thaumcraft.api.event.WorldProtection.native$snapshotHandler$11532(native$snapshot$12325, native$snapshot$12326, native$snapshot$12327, native$snapshot$12328, native$snapshot$12329);
        });
    }

    private static void native$snapshotHandler$11469(net.minecraft.world.level.LevelAccessor native$snapshotValue$11478, net.minecraft.core.BlockPos native$snapshotValue$11479, net.minecraft.world.level.block.state.BlockState native$snapshotValue$11480, net.minecraft.world.entity.player.Player native$snapshotValue$11481, java.util.function.Consumer<java.lang.Boolean> native$snapshotValue$11482, java.lang.Object native$snapshotValue$11483, java.util.function.BooleanSupplier native$snapshotValue$11484) {
        if (!allow(native$snapshotValue$11478, native$snapshotValue$11479, dev.tc4port.thaumcraft.api.event.WorldProtection.Action.BREAK, native$snapshotValue$11481)) {
            net.minecraft.world.level.LevelAccessor native$operand$16582 = native$snapshotValue$11478;
            net.minecraft.core.BlockPos native$operand$16583 = native$snapshotValue$11479;
            net.minecraft.world.level.block.state.BlockState native$operand$16584 = native$snapshotValue$11480;
            net.minecraft.world.entity.player.Player native$operand$16585 = native$snapshotValue$11481;
            java.util.function.Consumer<java.lang.Boolean> native$operand$16586 = native$snapshotValue$11482;
            java.lang.Object native$operand$16587 = native$snapshotValue$11483;
            java.util.function.BooleanSupplier native$operand$16588 = native$snapshotValue$11484;
            boolean native$operand$16589 = true;
            native$operand$16586.accept(native$operand$16589);
        }
    }

    private static void native$snapshotHandler$11485(net.minecraft.world.level.LevelAccessor native$snapshotValue$11492, net.minecraft.core.BlockPos native$snapshotValue$11493, net.minecraft.world.entity.Entity native$snapshotValue$11494, java.util.List<net.minecraft.core.BlockPos> native$snapshotValue$11495, java.util.function.Consumer<java.lang.Boolean> native$snapshotValue$11496) {
        for (var pos : native$snapshotValue$11495) {
            if (!allow(native$snapshotValue$11492, pos, dev.tc4port.thaumcraft.api.event.WorldProtection.Action.PLACE, native$snapshotValue$11494)) {
                {
                    net.minecraft.world.level.LevelAccessor native$operand$16082 = native$snapshotValue$11492;
                    net.minecraft.core.BlockPos native$operand$16083 = native$snapshotValue$11493;
                    net.minecraft.world.entity.Entity native$operand$16084 = native$snapshotValue$11494;
                    java.util.List<net.minecraft.core.BlockPos> native$operand$16085 = native$snapshotValue$11495;
                    java.util.function.Consumer<java.lang.Boolean> native$operand$16086 = native$snapshotValue$11496;
                    boolean native$operand$16087 = true;
                    native$operand$16086.accept(native$operand$16087);
                }
                break;
            }
        }
    }

    private static void native$snapshotHandler$11505(net.minecraft.world.level.LevelAccessor native$snapshotValue$11506, net.minecraft.core.BlockPos native$snapshotValue$11507, java.util.function.Consumer<java.lang.Boolean> native$snapshotValue$11508) {
        if (!allow(native$snapshotValue$11506, native$snapshotValue$11507, dev.tc4port.thaumcraft.api.event.WorldProtection.Action.MODIFY, null)) {
            net.minecraft.world.level.LevelAccessor native$operand$16594 = native$snapshotValue$11506;
            net.minecraft.core.BlockPos native$operand$16595 = native$snapshotValue$11507;
            java.util.function.Consumer<java.lang.Boolean> native$operand$16596 = native$snapshotValue$11508;
            boolean native$operand$16597 = true;
            native$operand$16596.accept(native$operand$16597);
        }
    }

    private static void native$snapshotHandler$11509(net.minecraft.world.level.LevelAccessor native$snapshotValue$11510, net.minecraft.core.BlockPos native$snapshotValue$11511, java.util.function.Consumer<java.lang.Boolean> native$snapshotValue$11512) {
        if (!allow(native$snapshotValue$11510, native$snapshotValue$11511, dev.tc4port.thaumcraft.api.event.WorldProtection.Action.MODIFY, null)) {
            net.minecraft.world.level.LevelAccessor native$operand$16598 = native$snapshotValue$11510;
            net.minecraft.core.BlockPos native$operand$16599 = native$snapshotValue$11511;
            java.util.function.Consumer<java.lang.Boolean> native$operand$16600 = native$snapshotValue$11512;
            boolean native$operand$16601 = true;
            native$operand$16600.accept(native$operand$16601);
        }
    }

    private static void native$snapshotHandler$11521(net.minecraft.world.entity.LivingEntity native$snapshotValue$11526, net.minecraft.core.BlockPos native$snapshotValue$11527, java.util.function.Consumer<java.lang.Boolean> native$snapshotValue$11528) {
        if (!allow(native$snapshotValue$11526.level(), native$snapshotValue$11527, dev.tc4port.thaumcraft.api.event.WorldProtection.Action.BREAK, native$snapshotValue$11526)) {
            net.minecraft.world.entity.LivingEntity native$operand$16605 = native$snapshotValue$11526;
            net.minecraft.core.BlockPos native$operand$16606 = native$snapshotValue$11527;
            java.util.function.Consumer<java.lang.Boolean> native$operand$16607 = native$snapshotValue$11528;
            boolean native$operand$16608 = true;
            native$operand$16607.accept(native$operand$16608);
        }
    }

    private static void native$snapshotHandler$11529(net.minecraft.world.level.Level native$snapshotValue$11530, java.util.List<net.minecraft.core.BlockPos> native$snapshotValue$11531) {
        native$snapshotValue$11531.removeIf((net.minecraft.core.BlockPos pos) -> !allow(native$snapshotValue$11530, pos, dev.tc4port.thaumcraft.api.event.WorldProtection.Action.EXPLODE, null));
    }

    private static void native$snapshotHandler$11532(net.minecraft.world.level.LevelAccessor native$snapshotValue$11539, net.minecraft.core.BlockPos native$snapshotValue$11540, net.minecraft.core.BlockPos native$snapshotValue$11541, net.minecraft.world.level.block.piston.PistonStructureResolver native$snapshotValue$11542, java.util.function.Consumer<java.lang.Boolean> native$snapshotValue$11543) {
        var level = native$snapshotValue$11539;
        if (!(level instanceof net.minecraft.server.level.ServerLevel))
            return;
        // Even an empty extension occupies the head cell; retraction removes that head.
        if (!allow(level, native$snapshotValue$11540, dev.tc4port.thaumcraft.api.event.WorldProtection.Action.MOVE, null) || !allow(level, native$snapshotValue$11541, dev.tc4port.thaumcraft.api.event.WorldProtection.Action.MOVE, null)) {
            {
                net.minecraft.world.level.LevelAccessor native$operand$16250 = native$snapshotValue$11539;
                net.minecraft.core.BlockPos native$operand$16251 = native$snapshotValue$11540;
                net.minecraft.core.BlockPos native$operand$16252 = native$snapshotValue$11541;
                net.minecraft.world.level.block.piston.PistonStructureResolver native$operand$16253 = native$snapshotValue$11542;
                java.util.function.Consumer<java.lang.Boolean> native$operand$16254 = native$snapshotValue$11543;
                boolean native$operand$16255 = true;
                native$operand$16254.accept(native$operand$16255);
            }
            return;
        }
    }

    private static void native$listener$12478(java.lang.Boolean cancelled, net.minecraftforge.event.level.BlockEvent.FluidPlaceBlockEvent native$listenerCapture$12477) {
        native$listenerCapture$12477.setCanceled(cancelled);
        if (cancelled)
            native$listenerCapture$12477.setNewState(native$listenerCapture$12477.getOriginalState());
    }

    private static void native$subscription$12479(net.minecraft.world.level.LevelAccessor native$snapshotValue$11502, net.minecraft.core.BlockPos native$snapshotValue$11503, net.minecraftforge.event.level.BlockEvent.FluidPlaceBlockEvent native$listenerCapture$12477) {
        if (!dev.tc4port.thaumcraft.api.event.WorldProtection.allow(native$snapshotValue$11502, native$snapshotValue$11503, dev.tc4port.thaumcraft.api.event.WorldProtection.Action.MODIFY, null)) {
            net.minecraft.world.level.LevelAccessor native$operand$16609 = native$snapshotValue$11502;
            net.minecraft.core.BlockPos native$operand$16610 = native$snapshotValue$11503;
            net.minecraftforge.event.level.BlockEvent.FluidPlaceBlockEvent native$operand$16611 = native$listenerCapture$12477;
            boolean native$operand$16612 = true;
            {
                java.lang.Boolean native$operand$16735 = (java.lang.Boolean) (native$operand$16612);
                net.minecraftforge.event.level.BlockEvent.FluidPlaceBlockEvent native$operand$16736 = native$operand$16611;
                dev.tc4port.thaumcraft.api.event.WorldProtection.native$listener$12478((java.lang.Boolean) (native$operand$16735), native$operand$16736);
            }
        }
    }

    private static void native$subscription$12485(net.minecraft.world.level.LevelAccessor native$snapshotValue$11518, net.minecraft.core.BlockPos native$snapshotValue$11519, net.minecraftforge.event.level.BlockEvent.CropGrowEvent.Pre native$listenerCapture$12483) {
        if (!dev.tc4port.thaumcraft.api.event.WorldProtection.allow(native$snapshotValue$11518, native$snapshotValue$11519, dev.tc4port.thaumcraft.api.event.WorldProtection.Action.GROW, null)) {
            net.minecraft.world.level.LevelAccessor native$operand$16613 = native$snapshotValue$11518;
            net.minecraft.core.BlockPos native$operand$16614 = native$snapshotValue$11519;
            net.minecraftforge.event.level.BlockEvent.CropGrowEvent.Pre native$operand$16615 = native$listenerCapture$12483;
            {
                net.minecraftforge.event.level.BlockEvent.CropGrowEvent.Pre native$operand$16737 = native$operand$16615;
                {
                    net.minecraftforge.event.level.BlockEvent.CropGrowEvent.Pre native$operand$16752 = native$operand$16737;
                    native$operand$16752.setResult(net.minecraftforge.eventbus.api.Event.Result.DENY);
                }
            }
        }
    }

    static private void native$subscription$12482(java.lang.String priority, boolean receiveCancelled) {
        net.minecraftforge.common.MinecraftForge.EVENT_BUS.addListener(net.minecraftforge.eventbus.api.EventPriority.valueOf(priority), receiveCancelled, (net.minecraftforge.event.entity.player.BonemealEvent e) -> {
            net.minecraft.world.entity.player.Player native$snapshot$12629 = e.getEntity();
            net.minecraft.world.level.Level native$snapshot$12630 = e.getLevel();
            net.minecraft.core.BlockPos native$snapshot$12631 = e.getPos();
            net.minecraft.world.level.block.state.BlockState native$snapshot$12632 = e.getBlock();
            net.minecraft.world.item.ItemStack native$snapshot$12633 = e.getStack();
            net.minecraftforge.event.entity.player.BonemealEvent native$snapshotCapture$12634 = e;
            net.minecraftforge.event.entity.player.BonemealEvent native$snapshotCapture$12635 = e;
            net.minecraftforge.event.entity.player.BonemealEvent native$snapshotCapture$12636 = e;
            {
                net.minecraft.world.entity.player.Player native$operand$16088 = native$snapshot$12629;
                net.minecraft.world.level.Level native$operand$16089 = native$snapshot$12630;
                net.minecraft.core.BlockPos native$operand$16090 = native$snapshot$12631;
                net.minecraft.world.level.block.state.BlockState native$operand$16091 = native$snapshot$12632;
                net.minecraft.world.item.ItemStack native$operand$16092 = native$snapshot$12633;
                net.minecraftforge.event.entity.player.BonemealEvent native$operand$16093 = native$snapshotCapture$12634;
                net.minecraftforge.event.entity.player.BonemealEvent native$operand$16094 = native$snapshotCapture$12635;
                net.minecraftforge.event.entity.player.BonemealEvent native$operand$16095 = native$snapshotCapture$12636;
                dev.tc4port.thaumcraft.api.event.WorldProtection.native$subscription$12716(native$operand$16088, native$operand$16089, native$operand$16090, native$operand$16091, native$operand$16092, native$operand$16093, native$operand$16094, native$operand$16095);
            }
        });
    }

    private static void native$subscription$12716(net.minecraft.world.entity.player.Player native$snapshotValue$12516, net.minecraft.world.level.Level native$snapshotValue$12517, net.minecraft.core.BlockPos native$snapshotValue$12518, net.minecraft.world.level.block.state.BlockState native$snapshotValue$12519, net.minecraft.world.item.ItemStack native$snapshotValue$12520, net.minecraftforge.event.entity.player.BonemealEvent native$listenerCapture$12710, net.minecraftforge.event.entity.player.BonemealEvent native$listenerCapture$12712, net.minecraftforge.event.entity.player.BonemealEvent native$listenerCapture$12714) {
        if (!dev.tc4port.thaumcraft.api.event.WorldProtection.allow(native$snapshotValue$12517, native$snapshotValue$12518, dev.tc4port.thaumcraft.api.event.WorldProtection.Action.GROW, native$snapshotValue$12516)) {
            net.minecraft.world.entity.player.Player native$operand$16624 = native$snapshotValue$12516;
            net.minecraft.world.level.Level native$operand$16625 = native$snapshotValue$12517;
            net.minecraft.core.BlockPos native$operand$16626 = native$snapshotValue$12518;
            net.minecraft.world.level.block.state.BlockState native$operand$16627 = native$snapshotValue$12519;
            net.minecraft.world.item.ItemStack native$operand$16628 = native$snapshotValue$12520;
            net.minecraftforge.event.entity.player.BonemealEvent native$operand$16629 = native$listenerCapture$12710;
            net.minecraftforge.event.entity.player.BonemealEvent native$operand$16630 = native$listenerCapture$12712;
            net.minecraftforge.event.entity.player.BonemealEvent native$operand$16631 = native$listenerCapture$12714;
            {
                net.minecraftforge.event.entity.player.BonemealEvent native$operand$16738 = native$operand$16631;
                {
                    net.minecraftforge.event.entity.player.BonemealEvent native$operand$16753 = native$operand$16738;
                    {
                        net.minecraftforge.event.entity.player.BonemealEvent native$operand$16758 = native$operand$16753;
                        native$operand$16758.setCanceled(true);
                    }
                }
            }
        }
    }
}
