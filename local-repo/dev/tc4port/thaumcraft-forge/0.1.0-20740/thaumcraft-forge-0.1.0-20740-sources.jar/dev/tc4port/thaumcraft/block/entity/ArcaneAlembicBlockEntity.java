package dev.tc4port.thaumcraft.block.entity;

import dev.tc4port.thaumcraft.aspect.AspectCatalog;
import dev.tc4port.thaumcraft.block.ArcaneAlembicBlock;
import dev.tc4port.thaumcraft.api.aspect.AspectId;
import dev.tc4port.thaumcraft.api.aspect.AspectAmounts;
import dev.tc4port.thaumcraft.api.aspect.AspectContainerView;
import dev.tc4port.thaumcraft.api.essentia.EssentiaTransferMode;
import dev.tc4port.thaumcraft.api.essentia.EssentiaTransport;
import dev.tc4port.thaumcraft.registry.TCBlockEntities;
import java.util.Map;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket;
import net.minecraft.world.level.block.state.BlockState;
import java.lang.Math;
import dev.tc4port.thaumcraft.nativeimpl.state.ItemFields;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityType;

/**
 * One-aspect, 32-unit storage used by the alchemical furnace stack.
 */
public final class ArcaneAlembicBlockEntity extends net.minecraft.world.level.block.entity.BlockEntity implements EssentiaTransport, AspectContainerView, ItemFields.Source {

    public static final int CAPACITY = 32;

    private AspectId aspect;

    private AspectId aspectFilter;

    private int lastCapacity;

    private int amount;

    public static void serverTick(net.minecraft.world.level.Level level, BlockPos pos, BlockState state, ArcaneAlembicBlockEntity alembic) {
        if (alembic.lastCapacity != alembic.capacity()) {
            alembic.lastCapacity = alembic.capacity();
            alembic.changedAndSync();
        }
    }

    public int capacity() {
        return dev.tc4port.thaumcraft.api.essentia.EssentiaStorageApi.capacity(dev.tc4port.thaumcraft.api.essentia.EssentiaStorageApi.ARCANE_ALEMBIC, 32, this.level != null && this.level.isClientSide);
    }

    public ArcaneAlembicBlockEntity(BlockPos pos, BlockState state) {
        super(TCBlockEntities.ARCANE_ALEMBIC.get(), pos, state);
    }

    public AspectId aspect() {
        return this.aspect;
    }

    public AspectId aspectFilter() {
        return this.aspectFilter;
    }

    public int amount() {
        return this.amount;
    }

    public Map<AspectId, Integer> aspects() {
        return this.aspect == null || this.amount <= 0 ? Map.of() : Map.of(this.aspect, this.amount);
    }

    @Override
    public AspectAmounts visibleAspects() {
        return new AspectAmounts(this.aspects());
    }

    public boolean canAccept(AspectId candidate, int requested) {
        if (!AspectCatalog.contains(candidate)) {
            return false;
        }
        return requested >= 0 && requested <= capacity() - this.amount && (this.amount == 0 || candidate.equals(this.aspect));
    }

    /**
     * @return the unaccepted remainder, matching IAspectContainer.
     */
    public int add(AspectId candidate, int requested) {
        if (requested <= 0 || !this.canAccept(candidate, 0)) {
            return requested;
        }
        if (this.amount == 0) {
            this.aspect = candidate;
        }
        int accepted = Math.min(requested, capacity() - this.amount);
        this.amount += accepted;
        this.changedAndSync();
        return requested - accepted;
    }

    public boolean take(AspectId candidate, int requested) {
        if (!AspectCatalog.contains(candidate) || requested < 0 || this.amount < requested) {
            return false;
        }
        if (!candidate.equals(this.aspect)) {
            return false;
        }
        this.amount -= requested;
        if (this.amount <= 0) {
            this.amount = 0;
            this.aspect = null;
        }
        this.changedAndSync();
        return true;
    }

    public void clearContents() {
        this.aspect = null;
        this.amount = 0;
        this.changedAndSync();
    }

    public boolean setFilter(AspectId filter) {
        if (!AspectCatalog.contains(filter)) {
            return false;
        }
        if (this.amount == 0) {
            this.aspect = filter;
        }
        this.aspectFilter = filter;
        this.changedAndSync();
        return true;
    }

    public boolean clearFilter() {
        if (this.aspectFilter == null) {
            return false;
        }
        this.aspectFilter = null;
        this.changedAndSync();
        return true;
    }

    public int comparatorOutput() {
        int total = this.amount;
        int capacity = capacity();
        int filled = Math.min(total, capacity);
        return (int) ((long) filled * 14 / capacity) + (total > 0 ? 1 : 0);
    }

    @Override
    public boolean isConnectable(Direction face) {
        Direction facing = this.getBlockState().getValue(ArcaneAlembicBlock.FACING);
        return face != facing && face != Direction.DOWN;
    }

    @Override
    public boolean canInputFrom(Direction face) {
        return false;
    }

    @Override
    public boolean canOutputTo(Direction face) {
        return this.isConnectable(face);
    }

    @Override
    public AspectId suctionType(Direction face) {
        return null;
    }

    @Override
    public int suctionAmount(Direction face) {
        return 0;
    }

    @Override
    public int takeEssentia(AspectId aspect, int amount, Direction face, EssentiaTransferMode mode) {
        if (!this.canOutputTo(face) || amount <= 0 || this.amount < amount || !aspect.equals(this.aspect)) {
            return 0;
        }
        return !mode.executes() || this.take(aspect, amount) ? amount : 0;
    }

    @Override
    public int addEssentia(AspectId aspect, int amount, Direction face, EssentiaTransferMode mode) {
        return 0;
    }

    @Override
    public AspectId essentiaType(Direction face) {
        return AspectCatalog.contains(this.aspect) ? this.aspect : null;
    }

    @Override
    public int essentiaAmount(Direction face) {
        return AspectCatalog.contains(this.aspect) ? this.amount : 0;
    }

    @Override
    public int minimumSuction() {
        return 0;
    }

    @Override
    public boolean renderExtendedTube() {
        return true;
    }

    private void changedAndSync() {
        this.setChanged();
        BlockEntitySync.sendToClientAndUpdateComparator(this);
    }

    @Override
    public void load(CompoundTag tag) {
        var previousFilter = this.aspectFilter;
        super.load(tag);
        String storedAspect = tag.contains("aspect") ? tag.getString("aspect") : null;
        this.aspect = stored(storedAspect);
        String storedFilter = tag.contains("AspectFilter") ? tag.getString("AspectFilter") : null;
        this.aspectFilter = stored(storedFilter);
        this.amount = Math.max(0, tag.getInt("amount"));
        if (this.amount == 0 && this.aspectFilter == null) {
            this.aspect = null;
        }
        if (level != null && level.isClientSide && !java.util.Objects.equals(previousFilter, aspectFilter)) {
            level.sendBlockUpdated(worldPosition, getBlockState(), getBlockState(), 3);
        }
    }

    @Override
    protected void saveAdditional(CompoundTag tag) {
        super.saveAdditional(tag);
        if (this.aspect != null) {
            tag.putString("aspect", this.aspect.serialized());
        }
        if (this.aspectFilter != null) {
            tag.putString("AspectFilter", this.aspectFilter.serialized());
        }
        tag.putInt("amount", this.amount);
    }

    @Override
    public CompoundTag getUpdateTag() {
        return this.saveWithoutMetadata();
    }

    @Override
    public Packet<ClientGamePacketListener> getUpdatePacket() {
        return ClientboundBlockEntityDataPacket.create(this);
    }

    private static AspectId stored(String value) {
        try {
            return value == null ? null : AspectId.parse(value);
        } catch (IllegalArgumentException ignored) {
            return null;
        }
    }

    protected final HolderLookup.Provider persistenceRegistries() {
        if (level != null)
            return level.registryAccess();
        var server = net.minecraftforge.server.ServerLifecycleHooks.getCurrentServer();
        return server != null ? server.registryAccess() : net.minecraft.core.RegistryAccess.fromRegistryOfRegistries(net.minecraft.core.registries.BuiltInRegistries.REGISTRY);
    }

    protected static net.minecraft.network.chat.Component parseCustomNameSafe(String value, HolderLookup.Provider registries) {
        try {
            return net.minecraft.network.chat.Component.Serializer.fromJson(value);
        } catch (RuntimeException exception) {
            return null;
        }
    }

    protected void readItemFields(ItemFields.Input input) {
    }

    public void copyItemFields(ItemFields.Output output) {
    }

    public void applyComponentsFromItemStack(ItemStack stack) {
        readItemFields(ItemFields.from(stack));
    }

    public void removeComponentsFromTag(CompoundTag tag) {
    }

    @Override
    public void saveToItem(ItemStack stack) {
        CompoundTag tag = saveWithoutMetadata();
        {
            net.minecraft.nbt.CompoundTag native$bodyOperand$6090 = tag;
            native$bodyReturn$6092: {
                if (true) {
                }
            }
        }
        net.minecraft.world.item.BlockItem.setBlockEntityData(stack, getType(), tag);
        copyItemFields(ItemFields.to(stack));
    }

    @Override
    public net.minecraft.world.phys.AABB getRenderBoundingBox() {
        return ArcaneAlembicBlockEntity.native$ClientBlockEntityBounds$bounds(this);
    }

    @Override()
    public void onDataPacket(net.minecraft.network.Connection connection, net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket packet) {
        handleUpdateTag(packet.getTag());
    }

    @SuppressWarnings({ "rawtypes", "unchecked" })
    static private net.minecraft.world.phys.AABB native$ClientBlockEntityBounds$bounds(net.minecraft.world.level.block.entity.BlockEntity blockEntity) {
        var renderer = net.minecraft.client.Minecraft.getInstance().getBlockEntityRenderDispatcher().getRenderer(blockEntity);
        return renderer instanceof dev.tc4port.thaumcraft.nativeimpl.NativeBlockEntityRenderer shared ? shared.getRenderBoundingBox(blockEntity) : new net.minecraft.world.phys.AABB(blockEntity.getBlockPos());
    }

    private boolean native$capabilitiesInvalid$16874;

    public boolean native$capabilityActive$16765;

    public net.minecraftforge.common.capabilities.Capability<dev.tc4port.thaumcraft.api.essentia.EssentiaTransport> native$capabilityCapture$16764;

    private net.minecraftforge.common.util.LazyOptional<dev.tc4port.thaumcraft.api.essentia.EssentiaTransport> native$capabilityHandle$16766;

    @Override
    public <native$capabilityResultType$16875> net.minecraftforge.common.util.LazyOptional<native$capabilityResultType$16875> getCapability(net.minecraftforge.common.capabilities.Capability<native$capabilityResultType$16875> native$requestedCapability$16876, net.minecraft.core.Direction native$requestedFace$16877) {
        getCapabilities();
        synchronized (this) {
            if (native$capabilitiesInvalid$16874)
                return net.minecraftforge.common.util.LazyOptional.empty();
            if (native$capabilityActive$16765 && native$requestedCapability$16876 == (this.native$capabilityCapture$16764)) {
                if (native$capabilityHandle$16766 == null)
                    native$capabilityHandle$16766 = net.minecraftforge.common.util.LazyOptional.of(() -> this);
                return native$capabilityHandle$16766.cast();
            }
        }
        return super.getCapability(native$requestedCapability$16876, native$requestedFace$16877);
    }

    @Override
    public void invalidateCaps() {
        java.util.List<net.minecraftforge.common.util.LazyOptional<?>> native$expiredCapabilities$16878 = new java.util.ArrayList<>();
        synchronized (this) {
            native$capabilitiesInvalid$16874 = true;
            if (native$capabilityHandle$16766 != null) {
                native$expiredCapabilities$16878.add(native$capabilityHandle$16766);
                native$capabilityHandle$16766 = null;
            }
        }
        try {
            super.invalidateCaps();
        } finally {
            native$expiredCapabilities$16878.forEach(net.minecraftforge.common.util.LazyOptional::invalidate);
        }
    }

    @Override
    public void reviveCaps() {
        super.reviveCaps();
        synchronized (this) {
            native$capabilitiesInvalid$16874 = false;
        }
    }
}
