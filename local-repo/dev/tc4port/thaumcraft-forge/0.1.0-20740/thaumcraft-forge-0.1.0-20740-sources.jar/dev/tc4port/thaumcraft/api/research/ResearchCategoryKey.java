package dev.tc4port.thaumcraft.api.research;

import com.mojang.serialization.Codec;
import java.util.Objects;

/**
 * Case-preserving category identity used by the read-only research view.
 */
public record ResearchCategoryKey(ResearchKey value) implements Comparable<ResearchCategoryKey> {

    public static final Codec<ResearchCategoryKey> CODEC = ResearchKey.CODEC.xmap(ResearchCategoryKey::new, ResearchCategoryKey::value);

    public ResearchCategoryKey {
        value = Objects.requireNonNull(value, "value");
    }

    public static ResearchCategoryKey parse(String value) {
        return new ResearchCategoryKey(ResearchKey.parse(value));
    }

    public String serialized() {
        return this.value.serialized();
    }

    public String nameTranslationKey() {
        return "tc.research_category." + this.serialized();
    }

    @Override
    public int compareTo(ResearchCategoryKey other) {
        return this.value.compareTo(other.value);
    }

    @Override
    public String toString() {
        return this.value.toString();
    }
}
