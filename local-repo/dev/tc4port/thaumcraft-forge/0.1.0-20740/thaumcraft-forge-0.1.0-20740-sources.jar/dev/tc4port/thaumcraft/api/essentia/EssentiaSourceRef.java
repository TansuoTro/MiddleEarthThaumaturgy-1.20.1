package dev.tc4port.thaumcraft.api.essentia;

import java.util.Objects;
import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.level.Level;

/**
 * Stable identity of a source found during one lookup. The source may unload
 * or be replaced afterward; callers must execute through {@link EssentiaApi}
 * rather than caching a live block-entity reference.
 */
public record EssentiaSourceRef(ResourceKey<Level> dimension, BlockPos position) {

    public EssentiaSourceRef {
        dimension = Objects.requireNonNull(dimension, "dimension");
        position = Objects.requireNonNull(position, "position").immutable();
    }
}
