package dev.tc4port.thaumcraft.api;

/**
 * Selects when an object-aspect edit participates in catalog construction.
 *
 * <p>{@link #BEFORE_INFERENCE} becomes part of the seed catalog used by
 * complex, derived, and recipe inference on the next data reload.
 * {@link #AFTER_INFERENCE} changes only the final presented aspects.</p>
 */
public enum ObjectAspectPhase {

    BEFORE_INFERENCE, AFTER_INFERENCE
}
