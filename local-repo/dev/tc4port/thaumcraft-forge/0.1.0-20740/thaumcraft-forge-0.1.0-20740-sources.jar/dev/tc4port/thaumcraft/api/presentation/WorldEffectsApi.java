package dev.tc4port.thaumcraft.api.presentation;

import dev.tc4port.thaumcraft.Thaumcraft;
import dev.tc4port.thaumcraft.network.BlockSparklePayload;
import dev.tc4port.thaumcraft.network.TCPayloads;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;

/**
 * Server broadcast of core particle effects; recipients stay in the supplied level.
 * Invalid requests are skipped and warned once per validation reason.
 */
public final class WorldEffectsApi {

    private static final Set<String> WARNED_INVALID_REQUESTS = ConcurrentHashMap.newKeySet();

    private WorldEffectsApi() {
    }

    public static void blockSparkle(ServerLevel level, BlockPos pos, double range, int color, int baseCount) {
        if (level == null || pos == null) {
            warn("Level and position must not be null");
            return;
        }
        if (!Double.isFinite(range) || range < 0 || baseCount < 0 || baseCount > 400) {
            warn("Invalid block sparkle range or count");
            return;
        }
        if (!level.getServer().isSameThread()) {
            warn("World effect broadcast must run on the owning server thread");
            return;
        }
        TCPayloads.CHANNEL.sendToPlayersNear(level, null, pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5, range, new BlockSparklePayload(pos, color, baseCount));
    }

    private static void warn(String reason) {
        if (WARNED_INVALID_REQUESTS.add(reason)) {
            Thaumcraft.LOGGER.warn("Ignoring invalid world effect request: {}", reason);
        }
    }
}
