package dev.tc4port.thaumcraft.api.wand.behavior;

import dev.tc4port.thaumcraft.api.Registration;
import dev.tc4port.thaumcraft.api.wand.WandMaterialId;
import dev.tc4port.thaumcraft.common.WandBehaviorRegistry;
import java.util.Objects;

public final class WandBehaviorApi {

    private WandBehaviorApi() {
    }

    /**
     * Registers behavior for a wand rod material. The latest live
     * registration for that rod runs on the owning server thread once per
     * held hand every 20 ticks; closing it restores the previous entry.
     */
    public static Registration register(WandMaterialId material, WandServerBehavior behavior) {
        return Registration.of(WandBehaviorRegistry.register(Objects.requireNonNull(material, "material"), Objects.requireNonNull(behavior, "behavior")));
    }

    public static long generation() {
        return WandBehaviorRegistry.generation();
    }
}
