package dev.tc4port.thaumcraft.block;

import dev.tc4port.thaumcraft.nativeimpl.EffectTypes;
import com.mojang.serialization.MapCodec;
import dev.tc4port.thaumcraft.network.BlockSparklePayload;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;
import dev.tc4port.thaumcraft.nativeimpl.ClientExtensionTarget;
import dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.level.pathfinder.PathComputationType;
import net.minecraft.world.phys.HitResult;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.Explosion;
import net.minecraft.world.level.BlockGetter;

/**
 * BlockCosmeticSolid metadata two.
 */
public final class TravelPavingStoneBlock extends net.minecraft.world.level.block.Block implements dev.tc4port.thaumcraft.nativeimpl.ClientExtensionTarget {

    // Forge calls initializeClient from the native superclass constructor. Do not add a field initializer.
    private java.util.function.Consumer<net.minecraftforge.client.extensions.common.IClientBlockExtensions> platform$clientInstaller;

    public static final MapCodec<TravelPavingStoneBlock> CODEC = TravelPavingStoneBlock.native$BlockCodecPlatform$simple(TravelPavingStoneBlock::new);

    public TravelPavingStoneBlock(BlockBehaviour.Properties properties) {
        this(properties, properties, true);
    }

    protected MapCodec<TravelPavingStoneBlock> codec() {
        return CODEC;
    }

    @Override
    public void stepOn(Level level, BlockPos pos, BlockState state, Entity entity) {
        if (level instanceof ServerLevel serverLevel && entity instanceof LivingEntity living) {
            living.addEffect((switch(0) {
                default ->
                    {
                        net.minecraft.core.Holder<net.minecraft.world.effect.MobEffect> native$operand$13311 = EffectTypes.MOVEMENT_SPEED;
                        int native$operand$13312 = 40;
                        int native$operand$13313 = 1;
                        net.minecraft.world.effect.MobEffectInstance native$result$13314 = (new net.minecraft.world.effect.MobEffectInstance(native$operand$13311.value(), native$operand$13312, TravelPavingStoneBlock.native$MobEffectPlatform$safeAmplifier(native$operand$13311, native$operand$13313)));
                        yield native$result$13314;
                    }
            }));
            living.addEffect((switch(0) {
                default ->
                    {
                        net.minecraft.core.Holder<net.minecraft.world.effect.MobEffect> native$operand$13315 = EffectTypes.JUMP;
                        int native$operand$13316 = 40;
                        int native$operand$13317 = 0;
                        net.minecraft.world.effect.MobEffectInstance native$result$13318 = (new net.minecraft.world.effect.MobEffectInstance(native$operand$13315.value(), native$operand$13316, TravelPavingStoneBlock.native$MobEffectPlatform$safeAmplifier(native$operand$13315, native$operand$13317)));
                        yield native$result$13318;
                    }
            }));
            BlockSparklePayload payload = new BlockSparklePayload(pos, 0x008000, 5);
            Vec3 center = Vec3.atCenterOf(pos);
            for (ServerPlayer player : serverLevel.players()) {
                if (player.distanceToSqr(center) <= 32.0 * 32.0) {
                    dev.tc4port.thaumcraft.network.TCPayloads.CHANNEL.sendToPlayer(player, payload);
                }
            }
        }
        super.stepOn(level, pos, state, entity);
    }

    private TravelPavingStoneBlock(net.minecraft.world.level.block.state.BlockBehaviour.Properties native$NativeBlock$arg0, BlockBehaviour.Properties properties, boolean native$NativeBlock$captured) {
        super(native$NativeBlock$arg0);
    }

    @Override
    public void initializeClient(java.util.function.Consumer<net.minecraftforge.client.extensions.common.IClientBlockExtensions> installer) {
        platform$clientInstaller = installer;
        super.initializeClient(installer);
    }

    @Override
    public void platform$clientExtension(Object extension) {
        java.util.Objects.requireNonNull(platform$clientInstaller, "Forge initializeClient must run before client extension registration").accept((net.minecraftforge.client.extensions.common.IClientBlockExtensions) extension);
    }

    @Override
    public InteractionResult use(BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
        ItemUseResult result = (switch(0) {
            default ->
                {
                    net.minecraft.world.item.ItemStack native$bodyOperand$4791 = player.getItemInHand(hand);
                    net.minecraft.world.level.block.state.BlockState native$bodyOperand$4792 = state;
                    net.minecraft.world.level.Level native$bodyOperand$4793 = level;
                    net.minecraft.core.BlockPos native$bodyOperand$4794 = pos;
                    net.minecraft.world.entity.player.Player native$bodyOperand$4795 = player;
                    net.minecraft.world.InteractionHand native$bodyOperand$4796 = hand;
                    net.minecraft.world.phys.BlockHitResult native$bodyOperand$4797 = hit;
                    dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult native$bodyResult$4798 = null;
                    native$bodyReturn$4799: {
                        if (true) {
                            {
                                native$bodyResult$4798 = dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
                                break native$bodyReturn$4799;
                            }
                        }
                    }
                    yield native$bodyResult$4798;
                }
        });
        return result == ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION ? (hand == InteractionHand.MAIN_HAND ? (switch(0) {
            default ->
                {
                    net.minecraft.world.level.block.state.BlockState native$bodyOperand$3910 = state;
                    net.minecraft.world.level.Level native$bodyOperand$3911 = level;
                    net.minecraft.core.BlockPos native$bodyOperand$3912 = pos;
                    net.minecraft.world.entity.player.Player native$bodyOperand$3913 = player;
                    net.minecraft.world.phys.BlockHitResult native$bodyOperand$3914 = hit;
                    net.minecraft.world.InteractionResult native$bodyResult$3915 = null;
                    native$bodyReturn$3916: {
                        if (true) {
                            {
                                native$bodyResult$3915 = super.use(native$bodyOperand$3910, native$bodyOperand$3911, native$bodyOperand$3912, native$bodyOperand$3913, net.minecraft.world.InteractionHand.MAIN_HAND, native$bodyOperand$3914);
                                break native$bodyReturn$3916;
                            }
                        }
                    }
                    yield native$bodyResult$3915;
                }
        }) : InteractionResult.PASS) : result.result();
    }

    protected ItemUseResult interactWithItem(ItemStack stack, BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
        return dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
    }

    protected InteractionResult interactWithoutItem(BlockState state, Level level, BlockPos pos, Player player, BlockHitResult hit) {
        return super.use(state, level, pos, player, net.minecraft.world.InteractionHand.MAIN_HAND, hit);
    }

    @Override
    public void playerWillDestroy(Level level, BlockPos pos, BlockState state, Player player) {
        {
            net.minecraft.world.level.Level native$bodyOperand$6047 = level;
            net.minecraft.core.BlockPos native$bodyOperand$6048 = pos;
            net.minecraft.world.level.block.state.BlockState native$bodyOperand$6049 = state;
            net.minecraft.world.entity.player.Player native$bodyOperand$6050 = player;
            net.minecraft.world.level.block.state.BlockState native$bodyResult$6051 = null;
            native$bodyReturn$6052: {
                if (true) {
                    super.playerWillDestroy(native$bodyOperand$6047, native$bodyOperand$6048, native$bodyOperand$6049, native$bodyOperand$6050);
                    {
                        native$bodyResult$6051 = native$bodyOperand$6049;
                        break native$bodyReturn$6052;
                    }
                }
            }
        }
    }

    public BlockState beforePlayerDestroy(Level level, BlockPos pos, BlockState state, Player player) {
        super.playerWillDestroy(level, pos, state, player);
        return state;
    }

    protected boolean survivesSharedExplosion() {
        return false;
    }

    public int getExpDrop(net.minecraft.world.level.block.state.BlockState native$callbackInput$1145, net.minecraft.world.level.LevelReader native$callbackInput$1146, net.minecraft.util.RandomSource native$callbackInput$1147, net.minecraft.core.BlockPos native$callbackInput$1148, int native$callbackInput$1149, int native$callbackInput$1150) {
        net.minecraft.world.level.block.state.BlockState state = native$callbackInput$1145;
        net.minecraft.util.RandomSource random = native$callbackInput$1147;
        return 0;
    }

    @Override
    public void onBlockExploded(BlockState state, Level level, BlockPos pos, Explosion explosion) {
        if (!(switch(0) {
            default ->
                {
                    boolean native$bodyResult$5329 = false;
                    native$bodyReturn$5330: {
                        if (true) {
                            {
                                native$bodyResult$5329 = false;
                                break native$bodyReturn$5330;
                            }
                        }
                    }
                    yield native$bodyResult$5329;
                }
        }))
            super.onBlockExploded(state, level, pos, explosion);
    }

    @Override
    public boolean canDropFromExplosion(BlockState state, BlockGetter level, BlockPos pos, Explosion explosion) {
        return !(switch(0) {
            default ->
                {
                    boolean native$bodyResult$4800 = false;
                    native$bodyReturn$4801: {
                        if (true) {
                            {
                                native$bodyResult$4800 = false;
                                break native$bodyReturn$4801;
                            }
                        }
                    }
                    yield native$bodyResult$4800;
                }
        }) && super.canDropFromExplosion(state, level, pos, explosion);
    }

    /**
     * Native shift-based effects need a smaller ceiling than the stored amplifier byte.
     */
    static private int native$MobEffectPlatform$safeAmplifier(net.minecraft.core.Holder<net.minecraft.world.effect.MobEffect> effect, int amplifier) {
        net.minecraft.world.effect.MobEffect type = effect.value();
        int maximum = type == net.minecraft.world.effect.MobEffects.HEAL || type == net.minecraft.world.effect.MobEffects.HARM ? 16 : type == net.minecraft.world.effect.MobEffects.REGENERATION || type == net.minecraft.world.effect.MobEffects.POISON || type == net.minecraft.world.effect.MobEffects.WITHER ? 31 : 127;
        return java.lang.Math.max(0, java.lang.Math.min(maximum, amplifier));
    }

    static private <B extends net.minecraft.world.level.block.Block> com.mojang.serialization.MapCodec<B> native$BlockCodecPlatform$simple(java.util.function.Function<net.minecraft.world.level.block.state.BlockBehaviour.Properties, B> factory) {
        // Vanilla 1.21's Properties codec is a unit codec. Retain that schema for shared block definitions.
        return com.mojang.serialization.codecs.RecordCodecBuilder.mapCodec(instance -> instance.group(com.mojang.serialization.Codec.unit(net.minecraft.world.level.block.state.BlockBehaviour.Properties::of).fieldOf("properties").forGetter((B block) -> net.minecraft.world.level.block.state.BlockBehaviour.Properties.copy(block))).apply(instance, factory));
    }
}
