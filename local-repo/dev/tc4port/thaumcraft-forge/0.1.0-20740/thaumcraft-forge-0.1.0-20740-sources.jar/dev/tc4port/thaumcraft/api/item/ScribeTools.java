package dev.tc4port.thaumcraft.api.item;

import net.minecraft.world.item.ItemStack;

/**
 * Item accepted by Thaumcraft research-table scribing-tool slots.
 */
public interface ScribeTools {

    /**
     * Returns whether this stack can supply one research-table ink use.
     * Owners with a non-durability fuel model may override this method.
     */
    default boolean hasInk(ItemStack stack) {
        return stack.getDamageValue() < stack.getMaxDamage();
    }

    /**
     * Consumes one previously authorized ink use. TC4 calls this only after
     * {@link #hasInk(ItemStack)} returned true for the same stack on the
     * authoritative thread. Permanent tools may deliberately do nothing.
     */
    default void consumeInk(ItemStack stack) {
        stack.setDamageValue(Math.addExact(stack.getDamageValue(), 1));
    }

    /**
     * Returns whether a marked stack can currently supply ink. Zero-durability
     * marker items remain valid slot/display occupants but are not usable by
     * the default durability-backed implementation.
     */
    static boolean isUsable(ItemStack stack) {
        return stack.getItem() instanceof ScribeTools tools && tools.hasInk(stack);
    }

    /**
     * Dispatches one ink use to the stack owner. Callers must first establish
     * {@link #isUsable(ItemStack)} and must not invoke this from client-side
     * prediction.
     */
    static void consume(ItemStack stack) {
        if (!(stack.getItem() instanceof ScribeTools tools) || !tools.hasInk(stack)) {
            throw new IllegalStateException("Cannot consume ink from an unusable scribing tool");
        }
        tools.consumeInk(stack);
    }
}
