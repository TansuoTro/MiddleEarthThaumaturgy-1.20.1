package dev.tc4port.thaumcraft.block.entity;

import dev.tc4port.thaumcraft.common.TCGameplayParameters;
import dev.tc4port.thaumcraft.aspect.AspectCatalog;
import dev.tc4port.thaumcraft.data.PlayerKnowledgeData;
import dev.tc4port.thaumcraft.data.ResearchHexData;
import dev.tc4port.thaumcraft.data.ResearchNoteData;
import dev.tc4port.thaumcraft.item.ResearchNotesItem;
import dev.tc4port.thaumcraft.api.item.ScribeTools;
import dev.tc4port.thaumcraft.api.aspect.AspectId;
import dev.tc4port.thaumcraft.api.aspect.AspectPoolApi;
import dev.tc4port.thaumcraft.api.aspect.VisAction;
import dev.tc4port.thaumcraft.menu.ResearchTableMenu;
import dev.tc4port.thaumcraft.research.ResearchCatalog;
import dev.tc4port.thaumcraft.research.ResearchEntryDefinition;
import dev.tc4port.thaumcraft.research.ResearchEnvironmentCatalog;
import dev.tc4port.thaumcraft.research.ResearchNoteManager;
import dev.tc4port.thaumcraft.common.PlayerKnowledgeService;
import dev.tc4port.thaumcraft.common.ScanManager;
import dev.tc4port.thaumcraft.registry.TCBlockEntities;
import dev.tc4port.thaumcraft.registry.TCSounds;
import java.util.LinkedHashMap;
import java.util.Map;
import net.minecraft.core.BlockPos;
import net.minecraft.core.HolderLookup;
import net.minecraft.core.NonNullList;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.StringTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import java.lang.Math;
import net.minecraft.world.level.block.entity.BaseContainerBlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityType;

/**
 * Two slots, environmental aspect pool and research-hex state machine from
 * TileResearchTable.
 */
public final class ResearchTableBlockEntity extends net.minecraft.world.level.block.entity.BaseContainerBlockEntity {

    public static final int SCRIBING_SLOT = 0;

    public static final int NOTE_SLOT = 1;

    public static final int CONTAINER_SIZE = 2;

    private NonNullList<ItemStack> items = NonNullList.withSize(CONTAINER_SIZE, ItemStack.EMPTY);

    private final LinkedHashMap<AspectId, Integer> bonusAspects = new LinkedHashMap<>();

    private int nextRecalculation;

    private int lastModelAppearance;

    public ResearchTableBlockEntity(BlockPos pos, BlockState state) {
        super(TCBlockEntities.RESEARCH_TABLE.get(), pos, state);
    }

    public static void serverTick(net.minecraft.world.level.Level level, BlockPos pos, BlockState state, ResearchTableBlockEntity table) {
        if (++table.nextRecalculation > 600) {
            table.nextRecalculation = 0;
            table.recalculateBonus();
            table.markUpdated();
        }
    }

    public int bonusAmount(AspectId aspect) {
        return this.bonusAspects.getOrDefault(aspect, 0);
    }

    public ResearchNoteData noteData() {
        ItemStack stack = this.getItem(NOTE_SLOT);
        if (!(stack.getItem() instanceof ResearchNotesItem)) {
            return ResearchNoteData.EMPTY;
        }
        return ResearchNoteManager.data(stack);
    }

    public boolean placeAspect(int q, int r, AspectId aspectId, Player player) {
        ResearchNoteData note = this.noteData();
        ResearchHexData target = note.hex(q, r);
        if (note.researchKey().isEmpty() || note.complete() || target == null || target.type() != 0 || !AspectCatalog.contains(aspectId) || !this.hasInk()) {
            return false;
        }
        PlayerKnowledgeData knowledge = PlayerKnowledgeService.get(player);
        // The mastery discount may waive the cost, never the requirement to
        // hold the aspect; otherwise free placements could solve notes with
        // unowned aspects and erasing them would mint refunds.
        if (knowledge.aspectPool(aspectId) <= 0 && this.bonusAmount(aspectId) <= 0) {
            return false;
        }
        boolean mastery = knowledge.hasCompletedResearch(dev.tc4port.thaumcraft.api.research.ResearchKey.parse("RESEARCHER2"));
        if (!mastery || this.level.getRandom().nextFloat() >= TCGameplayParameters.MACHINES_RESEARCH_TABLE_MASTERY_FREE_CHANCE.floatValue()) {
            if (!this.consumeAvailableAspect(player, aspectId)) {
                return false;
            }
        } else {
            player.playNotifySound(TCSounds.ASPECT_GAIN.get(), SoundSource.PLAYERS, 0.2F, 0.9F + player.getRandom().nextFloat() * 0.2F);
        }
        note = ResearchNoteManager.withHex(note, q, r, aspectId, 2);
        this.consumeInk();
        note = ResearchNoteManager.checkCompletion(note, PlayerKnowledgeService.get(player));
        ResearchNoteManager.setData(this.getItem(NOTE_SLOT), note);
        if (note.complete()) {
            player.playNotifySound(TCSounds.LEARN.get(), SoundSource.PLAYERS, 1.0F, 1.0F);
        }
        this.markUpdated();
        return true;
    }

    public boolean eraseAspect(int q, int r, Player player) {
        ResearchNoteData note = this.noteData();
        ResearchHexData target = note.hex(q, r);
        if (note.researchKey().isEmpty() || note.complete() || target == null || target.type() != 2 || !this.hasInk()) {
            return false;
        }
        PlayerKnowledgeData knowledge = PlayerKnowledgeService.get(player);
        float refundChance = knowledge.hasCompletedResearch(dev.tc4port.thaumcraft.api.research.ResearchKey.parse("RESEARCHER2")) ? TCGameplayParameters.MACHINES_RESEARCH_TABLE_MASTER_REFUND_CHANCE.floatValue() : knowledge.hasCompletedResearch(dev.tc4port.thaumcraft.api.research.ResearchKey.parse("RESEARCHER1")) ? TCGameplayParameters.MACHINES_RESEARCH_TABLE_RESEARCHER_REFUND_CHANCE.floatValue() : 0.0F;
        if (this.level.getRandom().nextFloat() < refundChance) {
            AspectId refunded = target.aspect().orElseThrow();
            if (player instanceof ServerPlayer serverPlayer) {
                // The aspect gain payload also owns the refund's local sound.
                AspectPoolApi.add(serverPlayer, refunded, 1, VisAction.EXECUTE);
            } else {
                PlayerKnowledgeService.addAspectPool(player, refunded, 1);
            }
        }
        note = ResearchNoteManager.withHex(note, q, r, null, 0);
        ResearchNoteManager.setData(this.getItem(NOTE_SLOT), note);
        this.consumeInk();
        this.markUpdated();
        return true;
    }

    public boolean combine(AspectId canonicalFirst, AspectId canonicalSecond, ServerPlayer player) {
        if (!AspectCatalog.contains(canonicalFirst) || !AspectCatalog.contains(canonicalSecond) || !this.hasAvailableAspect(player, canonicalFirst) || !this.hasAvailableAspect(player, canonicalSecond)) {
            return false;
        }
        this.consumeAvailableAspect(player, canonicalFirst);
        this.consumeAvailableAspect(player, canonicalSecond);
        AspectCatalog.combination(canonicalFirst, canonicalSecond).ifPresent(result -> ScanManager.checkAndSyncAspectKnowledge(player, result, 1));
        this.markUpdated();
        return true;
    }

    public boolean duplicate(ServerPlayer player) {
        ResearchNoteData note = this.noteData();
        ResearchEntryDefinition research = note.researchKey().map(ResearchCatalog::get).orElse(null);
        if (!note.complete() || note.copies() >= ResearchNoteData.MAX_COPIES || research == null || findInventoryItem(player, Items.PAPER) < 0 || findInventoryItem(player, Items.INK_SAC) < 0) {
            return false;
        }
        for (Map.Entry<AspectId, Integer> cost : research.aspects().entrySet()) {
            long amount = (long) cost.getValue() + note.copies();
            if (amount > Integer.MAX_VALUE) {
                return false;
            }
            if (PlayerKnowledgeService.get(player).aspectPool(cost.getKey()) < amount) {
                return false;
            }
        }
        for (Map.Entry<AspectId, Integer> cost : research.aspects().entrySet()) {
            PlayerKnowledgeService.addAspectPool(player, cost.getKey(), -Math.addExact(cost.getValue(), note.copies()));
        }
        consumeInventoryItem(player, Items.PAPER);
        consumeInventoryItem(player, Items.INK_SAC);
        ResearchNoteData updated = new ResearchNoteData(note.researchKey(), note.color(), note.hexes(), note.state().completedState(), Math.incrementExact(note.copies()));
        ItemStack notes = this.getItem(NOTE_SLOT);
        ResearchNoteManager.setData(notes, updated);
        notes.grow(1);
        player.playNotifySound(TCSounds.LEARN.get(), SoundSource.PLAYERS, 1.0F, 1.0F);
        this.markUpdated();
        return true;
    }

    private boolean hasAvailableAspect(Player player, AspectId aspect) {
        return PlayerKnowledgeService.get(player).aspectPool(aspect) > 0 || this.bonusAmount(aspect) > 0;
    }

    private boolean consumeAvailableAspect(Player player, AspectId aspect) {
        if (PlayerKnowledgeService.get(player).aspectPool(aspect) > 0) {
            return PlayerKnowledgeService.addAspectPool(player, aspect, -1);
        }
        int bonus = this.bonusAmount(aspect);
        if (bonus <= 0) {
            return false;
        }
        if (bonus == 1) {
            this.bonusAspects.remove(aspect);
        } else {
            this.bonusAspects.put(aspect, bonus - 1);
        }
        return true;
    }

    private boolean hasInk() {
        ItemStack tools = this.getItem(SCRIBING_SLOT);
        return ScribeTools.isUsable(tools);
    }

    private void consumeInk() {
        ItemStack tools = this.getItem(SCRIBING_SLOT);
        ScribeTools.consume(tools);
    }

    private void recalculateBonus() {
        if (!(this.level instanceof ServerLevel serverLevel)) {
            return;
        }
        ResearchEnvironmentCatalog.recalculate(serverLevel, this.worldPosition, this::bonusAmount, this::addBonus);
    }

    private void addBonus(AspectId aspect) {
        // TC4 AspectList.merge keeps the larger amount: each bonus is 0 or 1.
        this.bonusAspects.merge(aspect, 1, Math::max);
    }

    private static int findInventoryItem(Player player, net.minecraft.world.item.Item item) {
        for (int slot = 0; slot < player.getInventory().items.size(); slot++) {
            if (player.getInventory().getItem(slot).is(item)) {
                return slot;
            }
        }
        return -1;
    }

    private static void consumeInventoryItem(Player player, net.minecraft.world.item.Item item) {
        int slot = findInventoryItem(player, item);
        if (slot >= 0) {
            player.getInventory().removeItem(slot, 1);
        }
    }

    private void markUpdated() {
        super.setChanged();
        if (this.level != null) {
            this.level.sendBlockUpdated(this.worldPosition, this.getBlockState(), this.getBlockState(), Block.UPDATE_CLIENTS);
        }
    }

    @Override
    public void setChanged() {
        super.setChanged();
        this.updateModelAppearance();
    }

    private void updateModelAppearance() {
        int current = this.modelAppearance();
        if (this.lastModelAppearance == current)
            return;
        this.lastModelAppearance = current;
        if (this.level == null)
            return;
        this.level.sendBlockUpdated(this.worldPosition, this.getBlockState(), this.getBlockState(), Block.UPDATE_CLIENTS);
        if (this.level.isClientSide) {
            BlockPos other = this.worldPosition.relative(this.getBlockState().getValue(dev.tc4port.thaumcraft.block.ResearchTableBlock.FACING));
            BlockState otherState = this.level.getBlockState(other);
            this.level.sendBlockUpdated(other, otherState, otherState, Block.UPDATE_CLIENTS);
        }
    }

    @Override
    public int getContainerSize() {
        return CONTAINER_SIZE;
    }

    @Override
    protected Component getDefaultName() {
        return Component.translatable("container.thaumcraft.research_table");
    }

    @Override
    protected AbstractContainerMenu createMenu(int containerId, Inventory inventory) {
        // Vanilla spectator opening bypasses our extra-data menu transport.
        if (inventory.player.isSpectator()) {
            return null;
        }
        return new ResearchTableMenu(containerId, inventory, this);
    }

    @Override
    public boolean canPlaceItem(int slot, ItemStack stack) {
        return slot == SCRIBING_SLOT ? stack.getItem() instanceof ScribeTools : slot == NOTE_SLOT && stack.getItem() instanceof ResearchNotesItem && !ResearchNoteManager.data(stack).complete();
    }

    private int modelAppearance() {
        boolean tools = getItem(SCRIBING_SLOT).getItem() instanceof ScribeTools;
        boolean note = getItem(NOTE_SLOT).getItem() instanceof ResearchNotesItem;
        return (tools ? 1 : 0) | (note ? 2 | noteData().color() << 2 : 0);
    }

    @Override
    public void load(CompoundTag tag) {
        HolderLookup.Provider registries = persistenceRegistries();
        super.load(tag);
        this.items = NonNullList.withSize(this.getContainerSize(), ItemStack.EMPTY);
        {
            net.minecraft.nbt.CompoundTag native$operand$14370 = tag;
            net.minecraft.core.NonNullList<net.minecraft.world.item.ItemStack> native$operand$14371 = this.items;
            net.minecraft.core.HolderLookup.Provider native$operand$14372 = registries;
            net.minecraft.world.ContainerHelper.loadAllItems(native$operand$14370, native$operand$14371);
        }
        this.nextRecalculation = tag.getInt("nextRecalc");
        this.bonusAspects.clear();
        ListTag bonuses = tag.getList("bonusAspects", 8);
        for (int index = 0; index < bonuses.size(); index++) {
            String aspect = bonuses.getString(index);
            try {
                this.bonusAspects.merge(AspectId.parse(aspect), 1, Math::max);
            } catch (IllegalArgumentException ignored) {
            }
        }
        if (this.level != null && this.level.isClientSide) {
            this.updateModelAppearance();
        } else {
            // Establish the saved appearance even when loading precedes level attachment.
            this.lastModelAppearance = this.modelAppearance();
        }
    }

    @Override
    protected void saveAdditional(CompoundTag tag) {
        HolderLookup.Provider registries = persistenceRegistries();
        super.saveAdditional(tag);
        {
            net.minecraft.nbt.CompoundTag native$operand$14373 = tag;
            net.minecraft.core.NonNullList<net.minecraft.world.item.ItemStack> native$operand$14374 = this.items;
            net.minecraft.core.HolderLookup.Provider native$operand$14375 = registries;
            net.minecraft.nbt.CompoundTag native$result$14376 = (net.minecraft.world.ContainerHelper.saveAllItems(native$operand$14373, native$operand$14374));
        }
        tag.putInt("nextRecalc", this.nextRecalculation);
        ListTag bonuses = new ListTag();
        for (Map.Entry<AspectId, Integer> entry : this.bonusAspects.entrySet()) {
            if (entry.getValue() > 0) {
                bonuses.add(StringTag.valueOf(entry.getKey().serialized()));
            }
        }
        tag.put("bonusAspects", bonuses);
    }

    @Override
    public CompoundTag getUpdateTag() {
        return this.saveWithoutMetadata();
    }

    @Override
    public Packet<ClientGamePacketListener> getUpdatePacket() {
        return ClientboundBlockEntityDataPacket.create(this);
    }

    protected NonNullList<ItemStack> getItems() {
        return this.items;
    }

    protected void setItems(NonNullList<ItemStack> items) {
        this.items = items;
        this.updateModelAppearance();
    }

    protected final HolderLookup.Provider persistenceRegistries() {
        if (level != null)
            return level.registryAccess();
        var server = net.minecraftforge.server.ServerLifecycleHooks.getCurrentServer();
        return server != null ? server.registryAccess() : net.minecraft.core.RegistryAccess.fromRegistryOfRegistries(net.minecraft.core.registries.BuiltInRegistries.REGISTRY);
    }

    protected static net.minecraft.network.chat.Component parseCustomNameSafe(String value, HolderLookup.Provider registries) {
        try {
            return net.minecraft.network.chat.Component.Serializer.fromJson(value);
        } catch (RuntimeException exception) {
            return null;
        }
    }

    @Override
    public boolean isEmpty() {
        return (switch(0) {
            default ->
                {
                    net.minecraft.core.NonNullList<net.minecraft.world.item.ItemStack> native$bodyResult$4860 = null;
                    native$bodyReturn$4861: {
                        if (true) {
                            {
                                native$bodyResult$4860 = this.items;
                                break native$bodyReturn$4861;
                            }
                        }
                    }
                    yield native$bodyResult$4860;
                }
        }).stream().allMatch(ItemStack::isEmpty);
    }

    @Override
    public ItemStack getItem(int index) {
        return (switch(0) {
            default ->
                {
                    net.minecraft.core.NonNullList<net.minecraft.world.item.ItemStack> native$bodyResult$5385 = null;
                    native$bodyReturn$5386: {
                        if (true) {
                            {
                                native$bodyResult$5385 = this.items;
                                break native$bodyReturn$5386;
                            }
                        }
                    }
                    yield native$bodyResult$5385;
                }
        }).get(index);
    }

    @Override
    public ItemStack removeItem(int index, int count) {
        ItemStack removed = net.minecraft.world.ContainerHelper.removeItem((switch(0) {
            default ->
                {
                    net.minecraft.core.NonNullList<net.minecraft.world.item.ItemStack> native$bodyResult$3959 = null;
                    native$bodyReturn$3960: {
                        if (true) {
                            {
                                native$bodyResult$3959 = this.items;
                                break native$bodyReturn$3960;
                            }
                        }
                    }
                    yield native$bodyResult$3959;
                }
        }), index, count);
        if (!removed.isEmpty())
            setChanged();
        return removed;
    }

    @Override
    public ItemStack removeItemNoUpdate(int index) {
        return net.minecraft.world.ContainerHelper.takeItem((switch(0) {
            default ->
                {
                    net.minecraft.core.NonNullList<net.minecraft.world.item.ItemStack> native$bodyResult$5387 = null;
                    native$bodyReturn$5388: {
                        if (true) {
                            {
                                native$bodyResult$5387 = this.items;
                                break native$bodyReturn$5388;
                            }
                        }
                    }
                    yield native$bodyResult$5387;
                }
        }), index);
    }

    @Override
    public void setItem(int index, ItemStack stack) {
        (switch(0) {
            default ->
                {
                    net.minecraft.core.NonNullList<net.minecraft.world.item.ItemStack> native$bodyResult$5389 = null;
                    native$bodyReturn$5390: {
                        if (true) {
                            {
                                native$bodyResult$5389 = this.items;
                                break native$bodyReturn$5390;
                            }
                        }
                    }
                    yield native$bodyResult$5389;
                }
        }).set(index, stack);
        int limit = Math.min(getMaxStackSize(), stack.getMaxStackSize());
        if (stack.getCount() > limit)
            stack.setCount(limit);
        setChanged();
    }

    @Override
    public void clearContent() {
        (switch(0) {
            default ->
                {
                    net.minecraft.core.NonNullList<net.minecraft.world.item.ItemStack> native$bodyResult$5391 = null;
                    native$bodyReturn$5392: {
                        if (true) {
                            {
                                native$bodyResult$5391 = this.items;
                                break native$bodyReturn$5392;
                            }
                        }
                    }
                    yield native$bodyResult$5391;
                }
        }).clear();
    }

    @Override
    public boolean stillValid(net.minecraft.world.entity.player.Player player) {
        return net.minecraft.world.Container.stillValidBlockEntity(this, player);
    }

    @Override
    public net.minecraft.world.phys.AABB getRenderBoundingBox() {
        return ResearchTableBlockEntity.native$ClientBlockEntityBounds$bounds(this);
    }

    @Override()
    public void onDataPacket(net.minecraft.network.Connection connection, net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket packet) {
        handleUpdateTag(packet.getTag());
    }

    @SuppressWarnings({ "rawtypes", "unchecked" })
    static private net.minecraft.world.phys.AABB native$ClientBlockEntityBounds$bounds(net.minecraft.world.level.block.entity.BlockEntity blockEntity) {
        var renderer = net.minecraft.client.Minecraft.getInstance().getBlockEntityRenderDispatcher().getRenderer(blockEntity);
        return renderer instanceof dev.tc4port.thaumcraft.nativeimpl.NativeBlockEntityRenderer shared ? shared.getRenderBoundingBox(blockEntity) : new net.minecraft.world.phys.AABB(blockEntity.getBlockPos());
    }

    private boolean native$capabilitiesInvalid$16997;

    public boolean native$capabilityActive$16832;

    private java.util.Map<net.minecraft.core.Direction, net.minecraftforge.common.util.LazyOptional<net.minecraftforge.items.IItemHandler>> native$capabilityHandle$16833;

    @Override
    public <native$capabilityResultType$16998> net.minecraftforge.common.util.LazyOptional<native$capabilityResultType$16998> getCapability(net.minecraftforge.common.capabilities.Capability<native$capabilityResultType$16998> native$requestedCapability$16999, net.minecraft.core.Direction native$requestedFace$17000) {
        getCapabilities();
        synchronized (this) {
            if (native$capabilitiesInvalid$16997)
                return net.minecraftforge.common.util.LazyOptional.empty();
            if (native$capabilityActive$16832 && native$requestedCapability$16999 == (net.minecraftforge.common.capabilities.ForgeCapabilities.ITEM_HANDLER)) {
                if (native$capabilityHandle$16833 == null)
                    native$capabilityHandle$16833 = new java.util.HashMap<>();
                net.minecraftforge.common.util.LazyOptional<net.minecraftforge.items.IItemHandler> native$capabilityResult$17002 = native$capabilityHandle$16833.computeIfAbsent(native$requestedFace$17000, native$capabilityFace$16834 -> {
                    net.minecraftforge.items.IItemHandler native$endpoint$226 = (switch(0) {
                        default ->
                            {
                                dev.tc4port.thaumcraft.block.entity.ResearchTableBlockEntity table = dev.tc4port.thaumcraft.block.entity.ResearchTableBlockEntity.this;
                                net.minecraft.core.Direction side = native$capabilityFace$16834;
                                yield (switch(0) {
                                    default ->
                                        {
                                            net.minecraft.world.Container native$operand$12752 = table;
                                            net.minecraftforge.items.IItemHandler native$result$12753 = (new net.minecraftforge.items.wrapper.InvWrapper(native$operand$12752));
                                            yield native$result$12753;
                                        }
                                });
                            }
                    });
                    return native$endpoint$226 == null ? net.minecraftforge.common.util.LazyOptional.empty() : net.minecraftforge.common.util.LazyOptional.of(() -> native$endpoint$226);
                });
                if (native$capabilityResult$17002.isPresent())
                    return native$capabilityResult$17002.cast();
            }
        }
        return super.getCapability(native$requestedCapability$16999, native$requestedFace$17000);
    }

    @Override
    public void invalidateCaps() {
        java.util.List<net.minecraftforge.common.util.LazyOptional<?>> native$expiredCapabilities$17001 = new java.util.ArrayList<>();
        synchronized (this) {
            native$capabilitiesInvalid$16997 = true;
            if (native$capabilityHandle$16833 != null) {
                native$expiredCapabilities$17001.addAll(native$capabilityHandle$16833.values());
                native$capabilityHandle$16833 = null;
            }
        }
        try {
            super.invalidateCaps();
        } finally {
            native$expiredCapabilities$17001.forEach(net.minecraftforge.common.util.LazyOptional::invalidate);
        }
    }

    @Override
    public void reviveCaps() {
        super.reviveCaps();
        synchronized (this) {
            native$capabilitiesInvalid$16997 = false;
        }
    }
}
