package dev.tc4port.thaumcraft.api.flux;

import java.util.Objects;
import java.util.Optional;
import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;

/**
 * Auditable actor or machine identity for a Flux mutation.
 */
public record FluxConsumeContext(ResourceLocation source, BlockPos origin, Optional<ServerPlayer> actor) {

    public FluxConsumeContext {
        Objects.requireNonNull(source, "source");
        origin = Objects.requireNonNull(origin, "origin").immutable();
        actor = Objects.requireNonNull(actor, "actor");
    }

    public static FluxConsumeContext machine(ResourceLocation source, BlockPos origin) {
        return new FluxConsumeContext(source, origin, Optional.empty());
    }

    public static FluxConsumeContext player(ResourceLocation source, ServerPlayer actor) {
        return new FluxConsumeContext(source, actor.blockPosition(), Optional.of(actor));
    }
}
