package dev.tc4port.thaumcraft.api.client;

import dev.tc4port.thaumcraft.api.research.ResearchCategoryKey;
import dev.tc4port.thaumcraft.api.research.ResearchKey;
import java.util.List;
import java.util.Objects;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.ItemStack;

/**
 * A localized, read-only view of research currently visible in the Thaumonomicon.
 */
public record ThaumonomiconEntry(ResearchKey key, ResearchCategoryKey category, Component title, Component categoryTitle, boolean complete, List<RecipeOutput> outputs) {

    public ThaumonomiconEntry {
        Objects.requireNonNull(key, "key");
        Objects.requireNonNull(category, "category");
        title = Objects.requireNonNull(title, "title").copy();
        categoryTitle = Objects.requireNonNull(categoryTitle, "categoryTitle").copy();
        outputs = List.copyOf(outputs);
        if (!complete && !outputs.isEmpty())
            throw new IllegalArgumentException("Unread recipe outputs");
    }

    @Override
    public Component title() {
        return title.copy();
    }

    @Override
    public Component categoryTitle() {
        return categoryTitle.copy();
    }

    /**
     * Page indices are book-definition indices, independent of font and pagination.
     */
    public record RecipeOutput(ItemStack stack, int sourcePage) {

        public RecipeOutput {
            stack = Objects.requireNonNull(stack, "stack").copy();
            if (sourcePage < 0)
                throw new IllegalArgumentException("Negative page index");
        }

        @Override
        public ItemStack stack() {
            return stack.copy();
        }
    }
}
