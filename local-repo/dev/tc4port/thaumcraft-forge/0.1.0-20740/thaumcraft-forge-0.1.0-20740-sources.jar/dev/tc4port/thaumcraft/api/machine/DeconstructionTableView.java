package dev.tc4port.thaumcraft.api.machine;

import dev.tc4port.thaumcraft.api.aspect.AspectId;
import java.util.Optional;

public interface DeconstructionTableView {

    boolean hasItem();

    Optional<AspectId> currentAspect();
}
