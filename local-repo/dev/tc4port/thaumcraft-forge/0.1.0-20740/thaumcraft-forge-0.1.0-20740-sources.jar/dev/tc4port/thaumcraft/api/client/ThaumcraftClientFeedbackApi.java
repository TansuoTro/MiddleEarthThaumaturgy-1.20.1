package dev.tc4port.thaumcraft.api.client;

import dev.tc4port.thaumcraft.api.aspect.AspectId;
import dev.tc4port.thaumcraft.api.research.ResearchKey;
import dev.tc4port.thaumcraft.client.*;
import dev.tc4port.thaumcraft.network.message.NotificationMessage;
import java.util.Objects;
import java.util.Optional;
import net.minecraft.network.chat.Component;

/**
 * Client-local presentation only; no research, warp or aspect state is awarded.
 */
public final class ThaumcraftClientFeedbackApi {

    private ThaumcraftClientFeedbackApi() {
    }

    public static void showScreenEffect(ScreenEffect effect, int ticks) {
        Objects.requireNonNull(effect, "effect");
        if (ticks < 1 || ticks > 72000) {
            throw new IllegalArgumentException("Invalid effect duration");
        }
        WarpMobEffectPostChainManager.request(effect.ordinal(), ticks);
    }

    public static void showWarpVignette() {
        WarpVignetteOverlay.acceptWarpEvent();
    }

    public static void showEldritchMist(boolean prolonged) {
        if (prolonged) {
            EldritchMistEffect.acceptLong();
        } else {
            EldritchMistEffect.acceptShort();
        }
    }

    /**
     * Respects TC's configured notification count and delay.
     */
    public static void showNotification(Component message, Optional<AspectId> aspect, int rgb) {
        PlayerNotificationOverlay.accept(new NotificationMessage(Objects.requireNonNull(message), Objects.requireNonNull(aspect), rgb & 0xFFFFFF, ""));
    }

    /**
     * Draws queued research/aspect notifications above an addon screen, as the built-in research table does.
     */
    public static void renderNotifications(net.minecraft.client.gui.GuiGraphics graphics) {
        PlayerNotificationOverlay.render(Objects.requireNonNull(graphics));
    }

    /**
     * Shows the configured card/toast without changing research progression.
     */
    public static void showResearchCompletion(ResearchKey key) {
        ResearchPopupOverlay.show(Objects.requireNonNull(key));
    }

    public static void showResearchDiscovery() {
        ResearchDiscoveryFeedback.accept();
    }

    /**
     * Amount controls feedback text; visualCount independently bounds pickup sprites.
     */
    public static void showAspectGain(AspectId aspect, int amount, boolean discovered, int visualCount) {
        Objects.requireNonNull(aspect);
        if (amount < 0 || visualCount < 0 || visualCount > 64) {
            throw new IllegalArgumentException("Invalid aspect feedback");
        }
        AspectGainOverlay.accept(new dev.tc4port.thaumcraft.network.message.AspectGain() {

            @Override
            public AspectId aspect() {
                return aspect;
            }

            @Override
            public int amount() {
                return amount;
            }

            @Override
            public boolean newlyDiscovered() {
                return discovered;
            }

            @Override
            public int visualEffectCount() {
                return visualCount;
            }
        });
    }

    public static void playWarpWhispers() {
        var player = net.minecraft.client.Minecraft.getInstance().player;
        if (player != null) {
            player.playSound(net.minecraft.core.registries.BuiltInRegistries.SOUND_EVENT.get(dev.tc4port.thaumcraft.registry.SoundDefinitions.WHISPERS.id()), 0.5F, 1.0F);
        }
    }
}
