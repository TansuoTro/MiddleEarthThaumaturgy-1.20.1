package dev.tc4port.thaumcraft;

import com.mojang.logging.LogUtils;
import org.slf4j.Logger;
import dev.tc4port.thaumcraft.common.*;
import dev.tc4port.thaumcraft.registry.TCRegistries;
import dev.tc4port.thaumcraft.registry.TCItems;
import dev.tc4port.thaumcraft.network.TCPayloads;
import dev.tc4port.thaumcraft.worldgen.TCBiomes;

/**
 * Content bootstrap invoked by the generated native mod entrypoint.
 */
public final class Thaumcraft {

    public static final String MOD_ID = "thaumcraft";

    public static final Logger LOGGER = LogUtils.getLogger();

    private Thaumcraft() {
    }

    public static void initialize(Object bus, Object container) {
        TCNativePolicies.register();
        WandNodeTapping.register();
        Thaumcraft.native$ModLifecyclePlatform$registerConfig(container, "COMMON", TCWorldgenConfig.SPEC, "thaumcraft-worldgen.toml");
        Thaumcraft.native$ModLifecyclePlatform$registerConfig(container, "SERVER", TCServerConfig.SPEC);
        Thaumcraft.native$ModLifecyclePlatform$registerConfig(container, "CLIENT", TCClientConfig.SPEC);
        TCRegistries.register(bus);
        CommonInitialization.register(bus);
        Thaumcraft.native$ModLifecyclePlatform$onCommonSetup(bus, () -> {
            TCBiomes.registerOverworldRegions();
            Thaumcraft.native$DispenserItems$register();
            Thaumcraft.native$NativeDyeing$registerWashable(TCItems.ROBE_CHESTPLATE.get(), TCItems.ROBE_LEGGINGS.get(), TCItems.ROBE_BOOTS.get(), TCItems.VOID_ROBE_HELMET.get(), TCItems.VOID_ROBE_CHESTPLATE.get(), TCItems.VOID_ROBE_LEGGINGS.get());
            TCItems.ALUMENTUM.get().registerDispenser();
        });
        TCPayloads.install(bus);
        LOGGER.info("Initializing Thaumcraft 4R");
    }

    static private void native$DispenserItems$register() {
        net.minecraft.core.registries.BuiltInRegistries.ITEM.forEach(item -> {
            if (item instanceof dev.tc4port.thaumcraft.nativeimpl.ArrowAmmunition arrowItem)
                net.minecraft.world.level.block.DispenserBlock.registerBehavior(item, new net.minecraft.core.dispenser.AbstractProjectileDispenseBehavior() {

                    @Override
                    protected net.minecraft.world.entity.projectile.Projectile getProjectile(net.minecraft.world.level.Level level, net.minecraft.core.Position position, net.minecraft.world.item.ItemStack stack) {
                        var projectile = arrowItem.sharedDispenserProjectile(level, position, stack, net.minecraft.core.Direction.UP);
                        if (projectile instanceof net.minecraft.world.entity.projectile.AbstractArrow arrow)
                            arrow.pickup = net.minecraft.world.entity.projectile.AbstractArrow.Pickup.ALLOWED;
                        return projectile;
                    }
                });
        });
    }

    static private void native$NativeDyeing$registerWashable(net.minecraft.world.item.Item... items) {
        for (net.minecraft.world.item.Item item : items) {
            net.minecraft.core.cauldron.CauldronInteraction.WATER.put(item, net.minecraft.core.cauldron.CauldronInteraction.DYED_ITEM);
        }
    }

    static private void native$ModLifecyclePlatform$registerConfig(java.lang.Object container, java.lang.String scope, net.minecraftforge.common.ForgeConfigSpec definition, java.lang.String filename) {
        var spec = (switch(0) {
            default ->
                {
                    net.minecraftforge.common.ForgeConfigSpec native$operand$16258 = definition;
                    net.minecraftforge.common.ForgeConfigSpec native$result$16259 = (native$operand$16258);
                    yield native$result$16259;
                }
        });
        if (spec.isEmpty())
            return;
        var owner = (net.minecraftforge.fml.ModContainer) container;
        owner.addConfig(new net.minecraftforge.fml.config.ModConfig(net.minecraftforge.fml.config.ModConfig.Type.valueOf(scope), spec, owner, filename));
    }

    static private void native$ModLifecyclePlatform$registerConfig(java.lang.Object container, java.lang.String scope, net.minecraftforge.common.ForgeConfigSpec definition) {
        var spec = (switch(0) {
            default ->
                {
                    net.minecraftforge.common.ForgeConfigSpec native$operand$16260 = definition;
                    net.minecraftforge.common.ForgeConfigSpec native$result$16261 = (native$operand$16260);
                    yield native$result$16261;
                }
        });
        if (spec.isEmpty())
            return;
        var owner = (net.minecraftforge.fml.ModContainer) container;
        owner.addConfig(new net.minecraftforge.fml.config.ModConfig(net.minecraftforge.fml.config.ModConfig.Type.valueOf(scope), spec, owner));
    }

    static private void native$ModLifecyclePlatform$onCommonSetup(java.lang.Object bus, java.lang.Runnable work) {
        ((net.minecraftforge.eventbus.api.IEventBus) bus).addListener((net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent event) -> event.enqueueWork(work));
    }
}
