package dev.tc4port.thaumcraft.api.node;

import java.util.Map;
import java.util.Optional;

/**
 * Read-only, generation-stamped view of the synchronized node catalog.
 */
public interface NodeRegistryView {

    /**
     * Process-local cache stamp changed whenever this view is replaced.
     */
    long generation();

    Map<NodeTypeId, NodeTypeDefinition> types();

    Map<NodeModifierId, NodeModifierDefinition> modifiers();

    NodeGenerationSettings settings();

    default Optional<NodeTypeDefinition> get(NodeTypeId id) {
        return Optional.ofNullable(this.types().get(id));
    }

    default Optional<NodeModifierDefinition> get(NodeModifierId id) {
        return Optional.ofNullable(this.modifiers().get(id));
    }
}
