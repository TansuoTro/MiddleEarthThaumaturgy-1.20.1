package dev.tc4port.thaumcraft.block;

import dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult;
import com.mojang.serialization.MapCodec;
import dev.tc4port.thaumcraft.block.entity.BrainJarBlockEntity;
import dev.tc4port.thaumcraft.registry.TCBlockEntities;
import dev.tc4port.thaumcraft.registry.TCSounds;
import javax.annotation.Nullable;
import net.minecraft.world.phys.HitResult;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.ExperienceOrb;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelReader;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityTicker;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;
import java.lang.Math;
import dev.tc4port.thaumcraft.nativeimpl.ClientExtensionTarget;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.level.pathfinder.PathComputationType;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.Explosion;

/**
 * Brain Jar metadata branch split from TC4's BlockJar.
 */
public final class BrainJarBlock extends net.minecraft.world.level.block.BaseEntityBlock implements dev.tc4port.thaumcraft.nativeimpl.ClientExtensionTarget {

    // Forge calls initializeClient from the native superclass constructor. Do not add a field initializer.
    private java.util.function.Consumer<net.minecraftforge.client.extensions.common.IClientBlockExtensions> platform$clientInstaller;

    public static final MapCodec<BrainJarBlock> CODEC = BrainJarBlock.native$BlockCodecPlatform$simple(BrainJarBlock::new);

    private static final VoxelShape OUTLINE = Block.box(3, 0, 3, 13, 12, 13);

    public BrainJarBlock(BlockBehaviour.Properties properties) {
        this(properties, properties, true);
    }

    protected MapCodec<? extends BrainJarBlock> codec() {
        return CODEC;
    }

    @Nullable
    @Override
    public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        return new BrainJarBlockEntity(pos, state);
    }

    @Nullable
    @Override
    public <T extends BlockEntity> BlockEntityTicker<T> getTicker(Level level, BlockState state, BlockEntityType<T> type) {
        return createTickerHelper(type, TCBlockEntities.BRAIN_JAR.get(), BrainJarBlockEntity::tick);
    }

    @Override
    public RenderShape getRenderShape(BlockState state) {
        /* Static brine/shell share the chunk translucent layer with water. */
        return RenderShape.MODEL;
    }

    @Override
    public VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
        return OUTLINE;
    }

    @Override
    public VoxelShape getCollisionShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
        return Shapes.block();
    }

    @Override
    public float getShadeBrightness(BlockState state, BlockGetter level, BlockPos pos) {
        // BlockJar was non-opaque even though its collision filled a cube.
        return 1.0F;
    }

    protected InteractionResult interactWithoutItem(BlockState state, Level level, BlockPos pos, Player player, BlockHitResult hit) {
        useJar(level, pos);
        return net.minecraft.world.InteractionResult.sidedSuccess(level.isClientSide);
    }

    private static void useJar(Level level, BlockPos pos) {
        if (!(level.getBlockEntity(pos) instanceof BrainJarBlockEntity jar)) {
            return;
        }
        jar.setEatDelay(40);
        if (!level.isClientSide) {
            releaseRandomExperience((ServerLevel) level, pos, jar);
            level.playSound(null, pos, TCSounds.JAR.get(), SoundSource.BLOCKS, 0.2F, 1.0F);
        }
    }

    public static int releaseRandomExperience(ServerLevel level, BlockPos pos, BrainJarBlockEntity jar) {
        int bound = Math.min(jar.experience() + 1, 64);
        int released = level.random.nextInt(Math.max(1, bound));
        if (released > 0) {
            jar.setExperience(jar.experience() - released);
            spawnExperience(level, Vec3.atCenterOf(pos), released);
        }
        return released;
    }

    public static void spawnExperience(ServerLevel level, Vec3 pos, int experience) {
        while (experience > 0) {
            int split = ExperienceOrb.getExperienceValue(experience);
            experience -= split;
            level.addFreshEntity(new ExperienceOrb(level, pos.x(), pos.y(), pos.z(), split));
        }
    }

    @Override
    public void onRemove(BlockState state, Level level, BlockPos pos, BlockState newState, boolean movedByPiston) {
        if (!state.is(newState.getBlock()) && !level.isClientSide && level.getBlockEntity(pos) instanceof BrainJarBlockEntity jar && jar.experience() > 0) {
            /*
             * BlockJar#breakBlock emitted stored XP even in creative and for
             * non-player replacement, at the integer block corner.
             */
            spawnExperience((ServerLevel) level, new Vec3(pos.getX(), pos.getY(), pos.getZ()), jar.experience());
        }
        super.onRemove(state, level, pos, newState, movedByPiston);
    }

    @Override
    public boolean hasAnalogOutputSignal(BlockState state) {
        return true;
    }

    @Override
    public int getAnalogOutputSignal(BlockState state, Level level, BlockPos pos) {
        return level.getBlockEntity(pos) instanceof BrainJarBlockEntity jar ? jar.comparatorOutput() : 0;
    }

    @Override
    public float getEnchantPowerBonus(BlockState state, LevelReader level, BlockPos pos) {
        return 2.0F;
    }

    @Override
    public void animateTick(BlockState state, Level level, BlockPos pos, net.minecraft.util.RandomSource random) {
        if (!(level.getBlockEntity(pos) instanceof BrainJarBlockEntity jar) || jar.experience() < BrainJarBlockEntity.configuredMaximumExperience()) {
            return;
        }
        float green = 0.4F + level.random.nextFloat() * 0.1F;
        float blue = 0.3F + level.random.nextFloat() * 0.2F;
        int color = (128 << 24) | ((int) (green * 255) << 8) | (int) (blue * 255);
        BrainJarBlock.native$ColoredSpell$add(level, color, pos.getX() + 0.3 + random.nextFloat() * 0.4F, pos.getY() + 0.9, pos.getZ() + 0.3 + random.nextFloat() * 0.4F);
    }

    @Override
    public ItemStack getCloneItemStack(BlockState state, HitResult target, net.minecraft.world.level.BlockGetter level, BlockPos pos, Player player) {
        // Stored XP was never copied into the metadata-1 BlockJar item.
        return new ItemStack(this);
    }

    public BlockState beforePlayerDestroy(Level level, BlockPos pos, BlockState state, Player player) {
        /* Creative destruction skips the ordinary playerDestroy loot path. */
        if (player.isCreative() && level instanceof net.minecraft.server.level.ServerLevel serverLevel) {
            net.minecraft.world.level.block.Block.dropResources(state, serverLevel, pos, level.getBlockEntity(pos), player, player.getMainHandItem());
        }
        return (switch(0) {
            default ->
                {
                    net.minecraft.world.level.Level native$bodyOperand$5738 = level;
                    net.minecraft.core.BlockPos native$bodyOperand$5739 = pos;
                    net.minecraft.world.level.block.state.BlockState native$bodyOperand$5740 = state;
                    net.minecraft.world.entity.player.Player native$bodyOperand$5741 = player;
                    net.minecraft.world.level.block.state.BlockState native$bodyResult$5742 = null;
                    native$bodyReturn$5743: {
                        if (true) {
                            super.playerWillDestroy(native$bodyOperand$5738, native$bodyOperand$5739, native$bodyOperand$5740, native$bodyOperand$5741);
                            {
                                native$bodyResult$5742 = native$bodyOperand$5740;
                                break native$bodyReturn$5743;
                            }
                        }
                    }
                    yield native$bodyResult$5742;
                }
        });
    }

    private BrainJarBlock(net.minecraft.world.level.block.state.BlockBehaviour.Properties native$NativeEntityBlock$arg0, BlockBehaviour.Properties properties, boolean native$NativeEntityBlock$captured) {
        super(native$NativeEntityBlock$arg0);
    }

    @Override
    public void initializeClient(java.util.function.Consumer<net.minecraftforge.client.extensions.common.IClientBlockExtensions> installer) {
        platform$clientInstaller = installer;
        super.initializeClient(installer);
    }

    @Override
    public void platform$clientExtension(Object extension) {
        java.util.Objects.requireNonNull(platform$clientInstaller, "Forge initializeClient must run before client extension registration").accept((net.minecraftforge.client.extensions.common.IClientBlockExtensions) extension);
    }

    @Override
    public InteractionResult use(BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
        ItemUseResult result = (switch(0) {
            default ->
                {
                    net.minecraft.world.item.ItemStack native$bodyOperand$4251 = player.getItemInHand(hand);
                    net.minecraft.world.level.block.state.BlockState native$bodyOperand$4252 = state;
                    net.minecraft.world.level.Level native$bodyOperand$4253 = level;
                    net.minecraft.core.BlockPos native$bodyOperand$4254 = pos;
                    net.minecraft.world.entity.player.Player native$bodyOperand$4255 = player;
                    net.minecraft.world.InteractionHand native$bodyOperand$4256 = hand;
                    net.minecraft.world.phys.BlockHitResult native$bodyOperand$4257 = hit;
                    dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult native$bodyResult$4258 = null;
                    native$bodyReturn$4259: {
                        if (true) {
                            {
                                native$bodyResult$4258 = dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
                                break native$bodyReturn$4259;
                            }
                        }
                    }
                    yield native$bodyResult$4258;
                }
        });
        return result == ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION ? (hand == InteractionHand.MAIN_HAND ? (switch(0) {
            default ->
                {
                    net.minecraft.world.level.block.state.BlockState native$bodyOperand$3557 = state;
                    net.minecraft.world.level.Level native$bodyOperand$3558 = level;
                    net.minecraft.core.BlockPos native$bodyOperand$3559 = pos;
                    net.minecraft.world.entity.player.Player native$bodyOperand$3560 = player;
                    net.minecraft.world.phys.BlockHitResult native$bodyOperand$3561 = hit;
                    net.minecraft.world.InteractionResult native$bodyResult$3562 = null;
                    native$bodyReturn$3563: {
                        if (true) {
                            useJar(native$bodyOperand$3558, native$bodyOperand$3559);
                            {
                                native$bodyResult$3562 = net.minecraft.world.InteractionResult.sidedSuccess(native$bodyOperand$3558.isClientSide);
                                break native$bodyReturn$3563;
                            }
                        }
                    }
                    yield native$bodyResult$3562;
                }
        }) : InteractionResult.PASS) : result.result();
    }

    protected ItemUseResult interactWithItem(ItemStack stack, BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
        return dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
    }

    @Override
    public void playerWillDestroy(Level level, BlockPos pos, BlockState state, Player player) {
        {
            net.minecraft.world.level.Level native$bodyOperand$5744 = level;
            net.minecraft.core.BlockPos native$bodyOperand$5745 = pos;
            net.minecraft.world.level.block.state.BlockState native$bodyOperand$5746 = state;
            net.minecraft.world.entity.player.Player native$bodyOperand$5747 = player;
            net.minecraft.world.level.block.state.BlockState native$bodyResult$5749 = null;
            native$bodyReturn$5750: {
                if (true) {
                    /* Creative destruction skips the ordinary playerDestroy loot path. */
                    if (native$bodyOperand$5747.isCreative() && native$bodyOperand$5744 instanceof net.minecraft.server.level.ServerLevel native$bodyBinding$5748) {
                        net.minecraft.world.level.block.Block.dropResources(native$bodyOperand$5746, native$bodyBinding$5748, native$bodyOperand$5745, native$bodyOperand$5744.getBlockEntity(native$bodyOperand$5745), native$bodyOperand$5747, native$bodyOperand$5747.getMainHandItem());
                    }
                    {
                        native$bodyResult$5749 = (switch(0) {
                            default ->
                                {
                                    net.minecraft.world.level.Level native$bodyOperand$8997 = native$bodyOperand$5744;
                                    net.minecraft.core.BlockPos native$bodyOperand$8998 = native$bodyOperand$5745;
                                    net.minecraft.world.level.block.state.BlockState native$bodyOperand$8999 = native$bodyOperand$5746;
                                    net.minecraft.world.entity.player.Player native$bodyOperand$9000 = native$bodyOperand$5747;
                                    net.minecraft.world.level.block.state.BlockState native$bodyResult$9001 = null;
                                    native$bodyReturn$9002: {
                                        if (true) {
                                            super.playerWillDestroy(native$bodyOperand$8997, native$bodyOperand$8998, native$bodyOperand$8999, native$bodyOperand$9000);
                                            {
                                                native$bodyResult$9001 = native$bodyOperand$8999;
                                                break native$bodyReturn$9002;
                                            }
                                        }
                                    }
                                    yield native$bodyResult$9001;
                                }
                        });
                        break native$bodyReturn$5750;
                    }
                }
            }
        }
    }

    protected boolean survivesSharedExplosion() {
        return false;
    }

    public int getExpDrop(net.minecraft.world.level.block.state.BlockState native$callbackInput$1050, net.minecraft.world.level.LevelReader native$callbackInput$1051, net.minecraft.util.RandomSource native$callbackInput$1052, net.minecraft.core.BlockPos native$callbackInput$1053, int native$callbackInput$1054, int native$callbackInput$1055) {
        net.minecraft.world.level.block.state.BlockState state = native$callbackInput$1050;
        net.minecraft.util.RandomSource random = native$callbackInput$1052;
        return 0;
    }

    @Override
    public void onBlockExploded(BlockState state, Level level, BlockPos pos, Explosion explosion) {
        if (!(switch(0) {
            default ->
                {
                    boolean native$bodyResult$5235 = false;
                    native$bodyReturn$5236: {
                        if (true) {
                            {
                                native$bodyResult$5235 = false;
                                break native$bodyReturn$5236;
                            }
                        }
                    }
                    yield native$bodyResult$5235;
                }
        }))
            super.onBlockExploded(state, level, pos, explosion);
    }

    @Override
    public boolean canDropFromExplosion(BlockState state, BlockGetter level, BlockPos pos, Explosion explosion) {
        return !(switch(0) {
            default ->
                {
                    boolean native$bodyResult$4260 = false;
                    native$bodyReturn$4261: {
                        if (true) {
                            {
                                native$bodyResult$4260 = false;
                                break native$bodyReturn$4261;
                            }
                        }
                    }
                    yield native$bodyResult$4260;
                }
        }) && super.canDropFromExplosion(state, level, pos, explosion);
    }

    static private void native$ColoredSpell$add(net.minecraft.world.level.Level level, int color, double x, double y, double z) {
        if (level.isClientSide)
            BrainJarBlock.native$ColoredSpell$create(color, x, y, z);
    }

    static private <B extends net.minecraft.world.level.block.Block> com.mojang.serialization.MapCodec<B> native$BlockCodecPlatform$simple(java.util.function.Function<net.minecraft.world.level.block.state.BlockBehaviour.Properties, B> factory) {
        // Vanilla 1.21's Properties codec is a unit codec. Retain that schema for shared block definitions.
        return com.mojang.serialization.codecs.RecordCodecBuilder.mapCodec(instance -> instance.group(com.mojang.serialization.Codec.unit(net.minecraft.world.level.block.state.BlockBehaviour.Properties::of).fieldOf("properties").forGetter((B block) -> net.minecraft.world.level.block.state.BlockBehaviour.Properties.copy(block))).apply(instance, factory));
    }

    static private net.minecraft.client.particle.Particle native$ColoredSpell$create(int color, double x, double y, double z) {
        net.minecraft.client.particle.Particle p = net.minecraft.client.Minecraft.getInstance().particleEngine.createParticle(net.minecraft.core.particles.ParticleTypes.ENTITY_EFFECT, x, y, z, (color >> 16 & 255) / 255.0, (color >> 8 & 255) / 255.0, (color & 255) / 255.0);
        if (p != null)
            ((dev.tc4port.thaumcraft.nativeimpl.mixin.client.ParticleAlphaAccessor) p).platform$setAlpha((color >>> 24) / 255.0F);
        return p;
    }
}
