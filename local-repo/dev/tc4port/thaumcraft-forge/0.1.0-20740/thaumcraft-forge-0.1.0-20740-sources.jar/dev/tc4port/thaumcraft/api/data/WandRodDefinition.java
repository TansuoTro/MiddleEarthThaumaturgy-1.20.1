package dev.tc4port.thaumcraft.api.data;

import com.mojang.serialization.Codec;
import com.mojang.serialization.DataResult;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import dev.tc4port.thaumcraft.api.wand.WandMaterialId;
import dev.tc4port.thaumcraft.api.wand.WandPartAssemblyMode;
import dev.tc4port.thaumcraft.api.wand.WandPartLimits;
import dev.tc4port.thaumcraft.api.wand.WandRechargeSpec;
import dev.tc4port.thaumcraft.api.research.ResearchRequirement;
import java.util.Objects;
import net.minecraft.resources.ResourceLocation;

/**
 * Synced, data-pack-defined properties shared by equivalent wand rod items.
 * Item identity and the normal/staff distinction deliberately live in tags.
 * Capacity is whole Vis; craft cost is the legacy assembly coefficient.
 */
public record WandRodDefinition(WandMaterialId materialId, int capacity, int craftCost, WandRechargeSpec recharge, ResearchRequirement research, ResourceLocation texture, WandPartAssemblyMode assemblyMode, boolean glowing, boolean runes, int order) {

    private static final Codec<Serialized> SERIALIZED_CODEC = RecordCodecBuilder.create(instance -> instance.group(WandMaterialId.CODEC.fieldOf("material").forGetter(Serialized::materialId), Codec.INT.fieldOf("capacity").forGetter(Serialized::capacity), Codec.INT.fieldOf("craft_cost").forGetter(Serialized::craftCost), WandRodDefinition.native$StrictOptionalFields$of(WandRechargeSpec.CODEC, "recharge_aspect", WandRechargeSpec.none()).forGetter(Serialized::recharge), ResearchRequirement.optionalFieldOf("research").forGetter(Serialized::research), ResourceLocation.CODEC.fieldOf("texture").forGetter(Serialized::texture), WandRodDefinition.native$StrictOptionalFields$of(WandPartAssemblyMode.CODEC, "assembly_mode", WandPartAssemblyMode.NORMAL).forGetter(Serialized::assemblyMode), WandRodDefinition.native$StrictOptionalFields$of(Codec.BOOL, "glowing", false).forGetter(Serialized::glowing), WandRodDefinition.native$StrictOptionalFields$of(Codec.BOOL, "runes", false).forGetter(Serialized::runes), WandRodDefinition.native$StrictOptionalFields$of(Codec.INT, "order", 1000).forGetter(Serialized::order)).apply(instance, Serialized::new));

    public static final Codec<WandRodDefinition> CODEC = SERIALIZED_CODEC.comapFlatMap(WandRodDefinition::decode, WandRodDefinition::serialized);

    public WandRodDefinition {
        materialId = Objects.requireNonNull(materialId, "materialId");
        recharge = Objects.requireNonNull(recharge, "recharge");
        research = Objects.requireNonNull(research, "research");
        texture = Objects.requireNonNull(texture, "texture");
        assemblyMode = Objects.requireNonNull(assemblyMode, "assemblyMode");
        if (texture.toString().length() > 256) {
            throw new IllegalArgumentException("Wand rod texture IDs must not exceed 256 characters");
        }
        if (capacity <= 0 || capacity > Integer.MAX_VALUE / 150 || craftCost < 0 || craftCost > WandPartLimits.MAX_CRAFT_COST) {
            throw new IllegalArgumentException("Invalid wand rod definition " + materialId);
        }
    }

    private static DataResult<WandRodDefinition> decode(Serialized value) {
        try {
            return DataResult.success(new WandRodDefinition(value.materialId(), value.capacity(), value.craftCost(), value.recharge(), value.research(), value.texture(), value.assemblyMode(), value.glowing(), value.runes(), value.order()));
        } catch (RuntimeException exception) {
            return DataResult.error(() -> "Invalid wand rod definition: " + exception.getMessage());
        }
    }

    private Serialized serialized() {
        return new Serialized(this.materialId, this.capacity, this.craftCost, this.recharge, this.research, this.texture, this.assemblyMode, this.glowing, this.runes, this.order);
    }

    private record Serialized(WandMaterialId materialId, int capacity, int craftCost, WandRechargeSpec recharge, ResearchRequirement research, ResourceLocation texture, WandPartAssemblyMode assemblyMode, boolean glowing, boolean runes, int order) {
    }

    /**
     * Compatibility constructor for ordinary, recipe-visible parts.
     */
    public WandRodDefinition(WandMaterialId materialId, int capacity, int craftCost, WandRechargeSpec recharge, ResearchRequirement research, ResourceLocation texture, boolean glowing, boolean runes, int order) {
        this(materialId, capacity, craftCost, recharge, research, texture, WandPartAssemblyMode.NORMAL, glowing, runes, order);
    }

    static private <A> com.mojang.serialization.MapCodec<A> native$StrictOptionalFields$of(com.mojang.serialization.Codec<A> codec, java.lang.String name, A defaultValue) {
        return WandRodDefinition.native$StrictOptionalFields$of(codec, name).xmap(value -> value.orElse(defaultValue), value -> java.util.Objects.equals(value, defaultValue) ? java.util.Optional.empty() : java.util.Optional.of(value));
    }

    static private <A> com.mojang.serialization.MapCodec<java.util.Optional<A>> native$StrictOptionalFields$of(com.mojang.serialization.Codec<A> codec, java.lang.String name) {
        java.util.Objects.requireNonNull(codec, "codec");
        java.util.Objects.requireNonNull(name, "name");
        return new com.mojang.serialization.MapCodec<>() {

            @Override
            public <T> com.mojang.serialization.DataResult<java.util.Optional<A>> decode(com.mojang.serialization.DynamicOps<T> ops, com.mojang.serialization.MapLike<T> input) {
                T value = input.get(name);
                return value == null ? com.mojang.serialization.DataResult.success(java.util.Optional.empty()) : codec.parse(ops, value).map(java.util.Optional::of);
            }

            @Override
            public <T> com.mojang.serialization.RecordBuilder<T> encode(java.util.Optional<A> input, com.mojang.serialization.DynamicOps<T> ops, com.mojang.serialization.RecordBuilder<T> prefix) {
                return input.isPresent() ? prefix.add(name, codec.encodeStart(ops, input.get())) : prefix;
            }

            @Override
            public <T> java.util.stream.Stream<T> keys(com.mojang.serialization.DynamicOps<T> ops) {
                return java.util.stream.Stream.of(ops.createString(name));
            }

            @Override
            public java.lang.String toString() {
                return "StrictOptionalField[" + name + ": " + codec + "]";
            }
        };
    }
}
