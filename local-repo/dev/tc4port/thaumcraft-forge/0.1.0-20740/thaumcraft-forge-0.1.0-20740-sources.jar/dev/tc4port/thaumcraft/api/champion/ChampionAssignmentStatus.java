package dev.tc4port.thaumcraft.api.champion;

/**
 * Outcome of one server-authoritative champion assignment request.
 */
public enum ChampionAssignmentStatus {

    APPLIED, CLIENT_SIDE, ALREADY_CHAMPION, UNKNOWN_DEFINITION, UNSUPPORTED_MOB
}
