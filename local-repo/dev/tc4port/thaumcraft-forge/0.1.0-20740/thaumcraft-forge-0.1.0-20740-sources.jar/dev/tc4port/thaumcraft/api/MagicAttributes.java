package dev.tc4port.thaumcraft.api;

import dev.tc4port.thaumcraft.api.entity.AttributeTypes;
import javax.annotation.Nullable;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.LivingEntity;

/**
 * Stable registry identities for player magic progression. Multipliers default to one.
 */
public final class MagicAttributes {

    public static final ResourceLocation RUNIC_SHIELD_CAPACITY = id("runic_shield_capacity");

    public static final ResourceLocation RUNIC_RECHARGE_RATE = id("runic_recharge_rate");

    public static final ResourceLocation RUNIC_RECHARGE_DELAY_MULTIPLIER = id("runic_recharge_delay_multiplier");

    public static final ResourceLocation FOCUS_DAMAGE_MULTIPLIER = id("focus_damage_multiplier");

    public static final ResourceLocation FOCUS_DAMAGE_BONUS = id("focus_damage_bonus");

    public static final ResourceLocation FOCUS_COOLDOWN_MULTIPLIER = id("focus_cooldown_multiplier");

    public static final ResourceLocation WAND_VIS_COST_MULTIPLIER = id("wand_vis_cost_multiplier");

    private MagicAttributes() {
    }

    /**
     * Non-player callers and contexts without a caster retain the ordinary multiplier.
     */
    public static double multiplier(@Nullable LivingEntity entity, ResourceLocation attribute) {
        if (entity == null)
            return 1.0D;
        var instance = AttributeTypes.resolve(entity, attribute);
        double value = instance == null ? 1.0D : instance.getValue();
        return Double.isFinite(value) ? Math.max(0.0D, value) : 1.0D;
    }

    private static ResourceLocation id(String path) {
        return net.minecraft.resources.ResourceLocation.fromNamespaceAndPath((java.lang.String) ("thaumcraft"), (java.lang.String) (path));
    }

    public static double damageBonus(@Nullable LivingEntity entity) {
        if (entity == null)
            return 0;
        var instance = AttributeTypes.resolve(entity, FOCUS_DAMAGE_BONUS);
        double value = instance == null ? 0 : instance.getValue();
        return Double.isFinite(value) ? value : 0;
    }
}
