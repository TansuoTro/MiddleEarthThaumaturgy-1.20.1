package dev.tc4port.thaumcraft.api.data;

import com.mojang.serialization.Codec;
import com.mojang.serialization.DataResult;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import dev.tc4port.thaumcraft.api.aspect.AspectAmounts;
import dev.tc4port.thaumcraft.api.aspect.AspectId;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;

/**
 * Synced Block Data Map value used by no-item scan targets.
 */
public record BlockAspectDefinition(Mode mode, AspectAmounts aspects) {

    /**
     * Matches the legacy object-aspect per-entry bound.
     */
    public static final int MAX_AMOUNT = 64;

    public enum Mode {

        ADD, REPLACE;

        private static final Codec<Mode> CODEC = Codec.STRING.comapFlatMap(value -> {
            try {
                return DataResult.success(valueOf(value.toUpperCase(Locale.ROOT)));
            } catch (IllegalArgumentException exception) {
                return DataResult.error(() -> "Unknown block aspect mode: " + value);
            }
        }, value -> value.name().toLowerCase(Locale.ROOT));
    }

    private static final Codec<Map<AspectId, Integer>> ASPECTS_CODEC = Codec.unboundedMap(AspectId.CODEC, Codec.INT);

    private static final Codec<Serialized> SERIALIZED_CODEC = RecordCodecBuilder.create(instance -> instance.group(BlockAspectDefinition.native$StrictOptionalFields$of(Mode.CODEC, "mode", Mode.ADD).forGetter(Serialized::mode), ASPECTS_CODEC.fieldOf("aspects").forGetter(Serialized::aspects)).apply(instance, Serialized::new));

    public static final Codec<BlockAspectDefinition> CODEC = SERIALIZED_CODEC.comapFlatMap(BlockAspectDefinition::decode, value -> new Serialized(value.mode, value.aspects.amounts()));

    public BlockAspectDefinition {
        Objects.requireNonNull(mode, "mode");
        Objects.requireNonNull(aspects, "aspects");
        if (aspects.amounts().isEmpty()) {
            throw new IllegalArgumentException("Block aspect definitions must not be empty");
        }
        aspects.amounts().forEach((id, amount) -> {
            if (amount > MAX_AMOUNT) {
                throw new IllegalArgumentException("Block aspect amount exceeds " + MAX_AMOUNT + ": " + id);
            }
        });
    }

    public static BlockAspectDefinition merge(BlockAspectDefinition older, BlockAspectDefinition newer) {
        if (newer.mode == Mode.REPLACE) {
            return newer;
        }
        LinkedHashMap<AspectId, Integer> merged = new LinkedHashMap<>(older.aspects.amounts());
        newer.aspects.amounts().forEach((id, amount) -> merged.merge(id, amount, (left, right) -> (int) Math.min(MAX_AMOUNT, (long) left + right)));
        return new BlockAspectDefinition(Mode.ADD, new AspectAmounts(merged));
    }

    private static DataResult<BlockAspectDefinition> decode(Serialized value) {
        try {
            return DataResult.success(new BlockAspectDefinition(value.mode(), new AspectAmounts(value.aspects())));
        } catch (RuntimeException exception) {
            return DataResult.error(() -> "Invalid block aspect definition: " + exception.getMessage());
        }
    }

    private record Serialized(Mode mode, Map<AspectId, Integer> aspects) {
    }

    static private <A> com.mojang.serialization.MapCodec<A> native$StrictOptionalFields$of(com.mojang.serialization.Codec<A> codec, java.lang.String name, A defaultValue) {
        return BlockAspectDefinition.native$StrictOptionalFields$of(codec, name).xmap(value -> value.orElse(defaultValue), value -> java.util.Objects.equals(value, defaultValue) ? java.util.Optional.empty() : java.util.Optional.of(value));
    }

    static private <A> com.mojang.serialization.MapCodec<java.util.Optional<A>> native$StrictOptionalFields$of(com.mojang.serialization.Codec<A> codec, java.lang.String name) {
        java.util.Objects.requireNonNull(codec, "codec");
        java.util.Objects.requireNonNull(name, "name");
        return new com.mojang.serialization.MapCodec<>() {

            @Override
            public <T> com.mojang.serialization.DataResult<java.util.Optional<A>> decode(com.mojang.serialization.DynamicOps<T> ops, com.mojang.serialization.MapLike<T> input) {
                T value = input.get(name);
                return value == null ? com.mojang.serialization.DataResult.success(java.util.Optional.empty()) : codec.parse(ops, value).map(java.util.Optional::of);
            }

            @Override
            public <T> com.mojang.serialization.RecordBuilder<T> encode(java.util.Optional<A> input, com.mojang.serialization.DynamicOps<T> ops, com.mojang.serialization.RecordBuilder<T> prefix) {
                return input.isPresent() ? prefix.add(name, codec.encodeStart(ops, input.get())) : prefix;
            }

            @Override
            public <T> java.util.stream.Stream<T> keys(com.mojang.serialization.DynamicOps<T> ops) {
                return java.util.stream.Stream.of(ops.createString(name));
            }

            @Override
            public java.lang.String toString() {
                return "StrictOptionalField[" + name + ": " + codec + "]";
            }
        };
    }
}
