package dev.tc4port.thaumcraft.api.client;

import dev.tc4port.thaumcraft.api.research.ResearchKey;

/**
 * Reader state after core knowledge checks and text pagination. Page indices start at zero.
 */
public record ThaumonomiconReading(ResearchKey research, int firstPage, int pageCount) {
}
