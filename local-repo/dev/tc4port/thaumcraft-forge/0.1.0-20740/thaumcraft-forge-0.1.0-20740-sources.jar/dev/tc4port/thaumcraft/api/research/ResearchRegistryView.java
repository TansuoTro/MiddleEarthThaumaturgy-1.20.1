package dev.tc4port.thaumcraft.api.research;

import java.util.Map;
import java.util.Optional;

/**
 * Read-only, generation-stamped view of the active local research catalog.
 */
public interface ResearchRegistryView {

    /**
     * Process-local cache stamp that changes when the effective view rebuilds.
     */
    long generation();

    /**
     * Categories in ascending sort order, then canonical-key order.
     */
    Map<ResearchCategoryKey, ResearchCategorySummary> categories();

    /**
     * Active entries in data-pack presentation order.
     */
    Map<ResearchKey, ResearchEntrySummary> entries();

    default Optional<ResearchEntrySummary> get(ResearchKey key) {
        return Optional.ofNullable(this.entries().get(key));
    }

    default Optional<ResearchCategorySummary> get(ResearchCategoryKey key) {
        return Optional.ofNullable(this.categories().get(key));
    }
}
