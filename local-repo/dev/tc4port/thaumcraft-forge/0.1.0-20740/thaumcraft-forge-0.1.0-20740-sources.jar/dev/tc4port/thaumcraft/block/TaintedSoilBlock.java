package dev.tc4port.thaumcraft.block;

import dev.tc4port.thaumcraft.common.TaintDecayCatalog;
import com.mojang.serialization.MapCodec;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import dev.tc4port.thaumcraft.nativeimpl.ClientExtensionTarget;
import dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.level.pathfinder.PathComputationType;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.level.Explosion;
import net.minecraft.world.level.BlockGetter;

/**
 * Metadata-1 tainted soil. It spreads taint like the crust, but slowly
 * recovers to ordinary dirt after its biome is purified.
 */
public final class TaintedSoilBlock extends net.minecraft.world.level.block.Block implements dev.tc4port.thaumcraft.nativeimpl.ClientExtensionTarget {

    // Forge calls initializeClient from the native superclass constructor. Do not add a field initializer.
    private java.util.function.Consumer<net.minecraftforge.client.extensions.common.IClientBlockExtensions> platform$clientInstaller;

    public static final MapCodec<TaintedSoilBlock> CODEC = TaintedSoilBlock.native$BlockCodecPlatform$simple(TaintedSoilBlock::new);

    public TaintedSoilBlock(BlockBehaviour.Properties properties) {
        this(properties, properties, true);
    }

    protected MapCodec<TaintedSoilBlock> codec() {
        return CODEC;
    }

    @Override
    public void randomTick(BlockState state, ServerLevel level, BlockPos pos, RandomSource random) {
        TaintSpreadLogic.spreadBiome(level, pos, random);
        TaintSpreadLogic.SpreadResult spread = TaintSpreadLogic.tickSolidSpreadTarget(level, pos, random);
        if (!spread.targetTainted()) {
            TaintDecayCatalog.apply(state.getBlock(), TaintDecayCatalog.Trigger.TARGET_NOT_TAINTED, level, pos, random);
        }
    }

    @Override
    public void stepOn(Level level, BlockPos pos, BlockState state, Entity entity) {
        TaintSpreadLogic.applySolidContact(level, entity);
        super.stepOn(level, pos, state, entity);
    }

    private TaintedSoilBlock(net.minecraft.world.level.block.state.BlockBehaviour.Properties native$NativeBlock$arg0, BlockBehaviour.Properties properties, boolean native$NativeBlock$captured) {
        super(native$NativeBlock$arg0);
    }

    @Override
    public void initializeClient(java.util.function.Consumer<net.minecraftforge.client.extensions.common.IClientBlockExtensions> installer) {
        platform$clientInstaller = installer;
        super.initializeClient(installer);
    }

    @Override
    public void platform$clientExtension(Object extension) {
        java.util.Objects.requireNonNull(platform$clientInstaller, "Forge initializeClient must run before client extension registration").accept((net.minecraftforge.client.extensions.common.IClientBlockExtensions) extension);
    }

    @Override
    public InteractionResult use(BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
        ItemUseResult result = (switch(0) {
            default ->
                {
                    net.minecraft.world.item.ItemStack native$bodyOperand$4720 = player.getItemInHand(hand);
                    net.minecraft.world.level.block.state.BlockState native$bodyOperand$4721 = state;
                    net.minecraft.world.level.Level native$bodyOperand$4722 = level;
                    net.minecraft.core.BlockPos native$bodyOperand$4723 = pos;
                    net.minecraft.world.entity.player.Player native$bodyOperand$4724 = player;
                    net.minecraft.world.InteractionHand native$bodyOperand$4725 = hand;
                    net.minecraft.world.phys.BlockHitResult native$bodyOperand$4726 = hit;
                    dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult native$bodyResult$4727 = null;
                    native$bodyReturn$4728: {
                        if (true) {
                            {
                                native$bodyResult$4727 = dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
                                break native$bodyReturn$4728;
                            }
                        }
                    }
                    yield native$bodyResult$4727;
                }
        });
        return result == ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION ? (hand == InteractionHand.MAIN_HAND ? (switch(0) {
            default ->
                {
                    net.minecraft.world.level.block.state.BlockState native$bodyOperand$3861 = state;
                    net.minecraft.world.level.Level native$bodyOperand$3862 = level;
                    net.minecraft.core.BlockPos native$bodyOperand$3863 = pos;
                    net.minecraft.world.entity.player.Player native$bodyOperand$3864 = player;
                    net.minecraft.world.phys.BlockHitResult native$bodyOperand$3865 = hit;
                    net.minecraft.world.InteractionResult native$bodyResult$3866 = null;
                    native$bodyReturn$3867: {
                        if (true) {
                            {
                                native$bodyResult$3866 = super.use(native$bodyOperand$3861, native$bodyOperand$3862, native$bodyOperand$3863, native$bodyOperand$3864, net.minecraft.world.InteractionHand.MAIN_HAND, native$bodyOperand$3865);
                                break native$bodyReturn$3867;
                            }
                        }
                    }
                    yield native$bodyResult$3866;
                }
        }) : InteractionResult.PASS) : result.result();
    }

    protected ItemUseResult interactWithItem(ItemStack stack, BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
        return dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
    }

    protected InteractionResult interactWithoutItem(BlockState state, Level level, BlockPos pos, Player player, BlockHitResult hit) {
        return super.use(state, level, pos, player, net.minecraft.world.InteractionHand.MAIN_HAND, hit);
    }

    @Override
    public void playerWillDestroy(Level level, BlockPos pos, BlockState state, Player player) {
        {
            net.minecraft.world.level.Level native$bodyOperand$6004 = level;
            net.minecraft.core.BlockPos native$bodyOperand$6005 = pos;
            net.minecraft.world.level.block.state.BlockState native$bodyOperand$6006 = state;
            net.minecraft.world.entity.player.Player native$bodyOperand$6007 = player;
            net.minecraft.world.level.block.state.BlockState native$bodyResult$6008 = null;
            native$bodyReturn$6009: {
                if (true) {
                    super.playerWillDestroy(native$bodyOperand$6004, native$bodyOperand$6005, native$bodyOperand$6006, native$bodyOperand$6007);
                    {
                        native$bodyResult$6008 = native$bodyOperand$6006;
                        break native$bodyReturn$6009;
                    }
                }
            }
        }
    }

    public BlockState beforePlayerDestroy(Level level, BlockPos pos, BlockState state, Player player) {
        super.playerWillDestroy(level, pos, state, player);
        return state;
    }

    protected boolean survivesSharedExplosion() {
        return false;
    }

    public int getExpDrop(net.minecraft.world.level.block.state.BlockState native$callbackInput$1145, net.minecraft.world.level.LevelReader native$callbackInput$1146, net.minecraft.util.RandomSource native$callbackInput$1147, net.minecraft.core.BlockPos native$callbackInput$1148, int native$callbackInput$1149, int native$callbackInput$1150) {
        net.minecraft.world.level.block.state.BlockState state = native$callbackInput$1145;
        net.minecraft.util.RandomSource random = native$callbackInput$1147;
        return 0;
    }

    @Override
    public void onBlockExploded(BlockState state, Level level, BlockPos pos, Explosion explosion) {
        if (!(switch(0) {
            default ->
                {
                    boolean native$bodyResult$5317 = false;
                    native$bodyReturn$5318: {
                        if (true) {
                            {
                                native$bodyResult$5317 = false;
                                break native$bodyReturn$5318;
                            }
                        }
                    }
                    yield native$bodyResult$5317;
                }
        }))
            super.onBlockExploded(state, level, pos, explosion);
    }

    @Override
    public boolean canDropFromExplosion(BlockState state, BlockGetter level, BlockPos pos, Explosion explosion) {
        return !(switch(0) {
            default ->
                {
                    boolean native$bodyResult$4729 = false;
                    native$bodyReturn$4730: {
                        if (true) {
                            {
                                native$bodyResult$4729 = false;
                                break native$bodyReturn$4730;
                            }
                        }
                    }
                    yield native$bodyResult$4729;
                }
        }) && super.canDropFromExplosion(state, level, pos, explosion);
    }

    static private <B extends net.minecraft.world.level.block.Block> com.mojang.serialization.MapCodec<B> native$BlockCodecPlatform$simple(java.util.function.Function<net.minecraft.world.level.block.state.BlockBehaviour.Properties, B> factory) {
        // Vanilla 1.21's Properties codec is a unit codec. Retain that schema for shared block definitions.
        return com.mojang.serialization.codecs.RecordCodecBuilder.mapCodec(instance -> instance.group(com.mojang.serialization.Codec.unit(net.minecraft.world.level.block.state.BlockBehaviour.Properties::of).fieldOf("properties").forGetter((B block) -> net.minecraft.world.level.block.state.BlockBehaviour.Properties.copy(block))).apply(instance, factory));
    }
}
