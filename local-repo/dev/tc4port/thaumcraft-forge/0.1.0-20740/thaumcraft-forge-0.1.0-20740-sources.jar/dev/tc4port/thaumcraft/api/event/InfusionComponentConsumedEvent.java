package dev.tc4port.thaumcraft.api.event;

import java.util.Objects;
import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.item.ItemStack;

/**
 * Fired on the native game event bus on the server thread exactly once when a
 * pedestal component's absorption commits, after the recipe's own operation
 * produced its remainder and before that remainder is placed in the pedestal.
 * Not fired for cancelled or restarted absorptions.
 *
 * <p>{@link #setRemainder} replaces what returns to the pedestal; an empty
 * stack leaves it empty. Listeners must not modify the pedestal themselves.</p>
 */
public final class InfusionComponentConsumedEvent extends net.minecraftforge.eventbus.api.Event {

    private final ServerLevel level;

    private final BlockPos matrix;

    private final ResourceLocation recipeId;

    private final int transaction;

    private final BlockPos pedestal;

    private final int componentIndex;

    private final ItemStack consumed;

    private ItemStack remainder;

    public InfusionComponentConsumedEvent(ServerLevel level, BlockPos matrix, ResourceLocation recipeId, int transaction, BlockPos pedestal, int componentIndex, ItemStack consumed, ItemStack remainder) {
        this.level = Objects.requireNonNull(level, "level");
        this.matrix = matrix.immutable();
        this.recipeId = Objects.requireNonNull(recipeId, "recipeId");
        this.transaction = transaction;
        this.pedestal = pedestal.immutable();
        this.componentIndex = componentIndex;
        this.consumed = consumed.copy();
        this.remainder = remainder.copy();
    }

    public ServerLevel level() {
        return this.level;
    }

    public BlockPos matrix() {
        return this.matrix;
    }

    public ResourceLocation recipeId() {
        return this.recipeId;
    }

    /**
     * The absorption transaction id, unique per matrix while it is loaded.
     */
    public int transaction() {
        return this.transaction;
    }

    public BlockPos pedestal() {
        return this.pedestal;
    }

    /**
     * Zero-based index in the recipe's declared components.
     */
    public int componentIndex() {
        return this.componentIndex;
    }

    /**
     * A copy of the stack that was absorbed.
     */
    public ItemStack consumed() {
        return this.consumed.copy();
    }

    /**
     * A copy of what will return to the pedestal.
     */
    public ItemStack remainder() {
        return this.remainder.copy();
    }

    public void setRemainder(ItemStack remainder) {
        this.remainder = Objects.requireNonNull(remainder, "remainder").copy();
    }
}
