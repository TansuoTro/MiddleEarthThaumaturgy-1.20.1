package dev.tc4port.thaumcraft.api.flux;

import dev.tc4port.thaumcraft.util.RuntimeWarnings;
import dev.tc4port.thaumcraft.api.aspect.VisAction;
import dev.tc4port.thaumcraft.api.event.WorldProtection;
import dev.tc4port.thaumcraft.common.TCServerConfig;
import dev.tc4port.thaumcraft.entity.FluxPlacementEntity;
import dev.tc4port.thaumcraft.fluid.BlockBackedFluid;
import dev.tc4port.thaumcraft.registry.TCEntities;
import dev.tc4port.thaumcraft.registry.TCFluids;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.material.Fluid;

/**
 * Deterministic transactions over the port's finite Flux Goo/Gas quanta.
 */
public final class FluxApi {

    public static final int MAXIMUM_RANGE = 32;

    private FluxApi() {
    }

    /**
     * Places newly generated Flux Goo/Gas quanta.
     *
     * <p>When the server setting is enabled, this publishes the native
     * {@code EntityPlaceEvent} using a server-only falling-block entity added
     * and removed before its first tick. Its position after joining determines
     * the actual placement cell, allowing alternate coordinate spaces to
     * project it through their ordinary entity-spawn path. The placement
     * snapshot is captured after the state write so non-player listeners see
     * the Flux state, while a pre-write snapshot restores a cancelled
     * placement. Both modes check fluid admission before writing; with the
     * setting disabled an admitted placement writes the block directly.</p>
     *
     * @return whether the Flux state remains placed
     * Invalid fluid or quanta requests are skipped with a warning once.
     */
    public static boolean place(ServerLevel level, BlockPos position, Fluid fluid, int quanta, int flags) {
        if (level == null || position == null || fluid == null) {
            RuntimeWarnings.warnOnce("flux-place-request", "Ignoring Flux placement request without a level, position or fluid");
            return false;
        }
        BlockBackedFluid fluxFluid = fluxFluid(fluid);
        if (fluxFluid == null || quanta < 1 || quanta > fluxFluid.maximumQuanta()) {
            RuntimeWarnings.warnOnce("flux-place-contents", "Ignoring Flux placement request with unsupported fluid or quanta");
            return false;
        }
        BlockState fluxState = fluxFluid.blockStateForQuanta(quanta);
        if (!level.getServer().isSameThread()) {
            return false;
        }
        if (!TCServerConfig.useZeroTickFluxPlacement()) {
            return WorldProtection.allow(level, position, WorldProtection.Action.FILL_FLUID, null) && level.setBlock(position, fluxState, flags);
        }
        FluxPlacementEntity placementEntity = new FluxPlacementEntity(TCEntities.FLUX_PLACEMENT.get(), level);
        placementEntity.setPos(position.getX() + 0.5D, position.getY(), position.getZ() + 0.5D);
        try {
            if (!level.addFreshEntity(placementEntity)) {
                return false;
            }
            BlockPos actualPosition = placementEntity.blockPosition();
            if (!WorldProtection.allow(level, actualPosition, WorldProtection.Action.FILL_FLUID, placementEntity)) {
                return false;
            }
            BlockState replacedState = level.getBlockState(actualPosition);
            var rollbackSnapshot = net.minecraftforge.common.util.BlockSnapshot.create(level.dimension(), level, actualPosition, flags);
            if (!level.setBlock(actualPosition, fluxState, flags)) {
                return false;
            }
            /*
             * EntityPlaceEvent exposes the snapshot's state for non-player
             * actors. Capture this after setBlock so integrations observe
             * Flux, but retain the pre-write snapshot for cancellation.
             */
            var placementSnapshot = net.minecraftforge.common.util.BlockSnapshot.create(level.dimension(), level, actualPosition, flags);
            if (!FluxApi.native$PlacementEvents$place(placementSnapshot, replacedState, placementEntity).isCanceled()) {
                return true;
            }
            rollbackSnapshot.restore(true, false);
            return false;
        } finally {
            // The actor was added for coordinate projection, but never ticks.
            placementEntity.discard();
        }
    }

    /**
     * Places Flux with normal neighbour and client update flags.
     */
    public static boolean place(ServerLevel level, BlockPos position, Fluid fluid, int quanta) {
        return place(level, position, fluid, quanta, Block.UPDATE_ALL);
    }

    /**
     * Adds quanta to an existing Goo/Gas cell without replacing its kind.
     */
    public static boolean add(ServerLevel level, BlockPos position, int quanta) {
        if (level == null || position == null || quanta <= 0) {
            RuntimeWarnings.warnOnce("flux-add-request", "Ignoring invalid Flux addition request");
            return false;
        }
        if (!level.getServer().isSameThread()) {
            return false;
        }
        BlockState state = level.getBlockState(position);
        BlockBackedFluid fluid = fluxFluid(state.getFluidState().getType());
        if (fluid == null || !WorldProtection.allow(level, position, WorldProtection.Action.FILL_FLUID, null)) {
            return false;
        }
        int current = fluid.quantaIn(state);
        // Deliberate flux generation fills ordinary cells, not the
        // overfull ninth layer used by the legacy spill producers.
        if (quanta > fluid.quantaPerBlock() - current) {
            return false;
        }
        return level.setBlock(position, fluid.blockStateForQuanta(current + quanta), Block.UPDATE_ALL);
    }

    public static int consume(ServerLevel level, BlockPos position, int requestedQuanta, FluxConsumeContext context, VisAction action) {
        return consumeNearby(level, position, 0, requestedQuanta, context, action).consumedQuanta();
    }

    public static FluxConsumeResult consumeNearby(ServerLevel level, BlockPos origin, int range, int requestedQuanta, FluxConsumeContext context, VisAction action) {
        if (level == null || origin == null || action == null || context == null || requestedQuanta <= 0 || range < 0 || range > MAXIMUM_RANGE) {
            RuntimeWarnings.warnOnce("flux-consume-request", "Ignoring invalid Flux consumption request");
            return new FluxConsumeResult(Math.max(0, requestedQuanta), 0, 0);
        }
        if (!level.getServer().isSameThread()) {
            return new FluxConsumeResult(requestedQuanta, 0, 0);
        }
        if (context.actor().isPresent() && context.actor().orElseThrow().serverLevel() != level) {
            return new FluxConsumeResult(requestedQuanta, 0, 0);
        }
        List<BlockPos> positions = loadedPositions(level, origin, range);
        int remaining = requestedQuanta;
        int affected = 0;
        for (BlockPos position : positions) {
            if (remaining == 0) {
                break;
            }
            BlockState state = level.getBlockState(position);
            BlockBackedFluid fluid = fluxFluid(state.getFluidState().getType());
            if (fluid == null) {
                continue;
            }
            int removed = Math.min(remaining, fluid.quantaIn(state));
            if (removed <= 0) {
                continue;
            }
            FluxConsumeEvent event = new FluxConsumeEvent(level, position, state, removed, context, action);
            if (net.minecraftforge.common.MinecraftForge.EVENT_BUS.post(event)) {
                continue;
            }
            if (action == VisAction.EXECUTE) {
                int left = fluid.quantaIn(state) - removed;
                if (!level.setBlock(position, left == 0 ? Blocks.AIR.defaultBlockState() : fluid.blockStateForQuanta(left), Block.UPDATE_ALL)) {
                    continue;
                }
            }
            remaining -= removed;
            affected++;
        }
        return new FluxConsumeResult(requestedQuanta, requestedQuanta - remaining, affected);
    }

    private static List<BlockPos> loadedPositions(ServerLevel level, BlockPos origin, int range) {
        ArrayList<BlockPos> result = new ArrayList<>();
        for (int x = -range; x <= range; x++) {
            for (int y = -range; y <= range; y++) {
                for (int z = -range; z <= range; z++) {
                    BlockPos candidate = origin.offset(x, y, z);
                    if (candidate.distSqr(origin) <= (double) range * range && level.hasChunkAt(candidate)) {
                        result.add(candidate.immutable());
                    }
                }
            }
        }
        result.sort(Comparator.comparingDouble((BlockPos pos) -> pos.distSqr(origin)).thenComparingInt(BlockPos::getY).thenComparingInt(BlockPos::getX).thenComparingInt(BlockPos::getZ));
        return List.copyOf(result);
    }

    private static BlockBackedFluid fluxFluid(Fluid fluid) {
        if (!(fluid instanceof BlockBackedFluid flux)) {
            return null;
        }
        return fluid == TCFluids.FLUX_GOO.get() || fluid == TCFluids.FLUX_GAS.get() ? flux : null;
    }

    static private dev.tc4port.thaumcraft.api.event.HookDecision native$PlacementEvents$place(net.minecraftforge.common.util.BlockSnapshot snapshot, net.minecraft.world.level.block.state.BlockState against, net.minecraft.world.entity.Entity entity) {
        var event = new net.minecraftforge.event.level.BlockEvent.EntityPlaceEvent(snapshot, against, entity);
        net.minecraftforge.common.MinecraftForge.EVENT_BUS.post(event);
        return new dev.tc4port.thaumcraft.api.event.HookDecision(event.isCanceled());
    }
}
