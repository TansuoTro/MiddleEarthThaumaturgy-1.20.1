package dev.tc4port.thaumcraft.block;

import dev.tc4port.thaumcraft.registry.TCSounds;
import dev.tc4port.thaumcraft.nativeimpl.NativeBucketPickup;
import com.mojang.serialization.MapCodec;
import dev.tc4port.thaumcraft.block.entity.MagicFluidBlockEntity;
import net.minecraft.world.level.block.EntityBlock;
import net.minecraft.world.level.block.entity.BlockEntity;
import dev.tc4port.thaumcraft.api.damage.ThaumcraftDamageTypes;
import dev.tc4port.thaumcraft.registry.TCItems;
import dev.tc4port.thaumcraft.registry.TCFluids;
import java.util.Optional;
import net.minecraft.core.BlockPos;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.BucketPickup;

/**
 * Four-quanta finite Liquid Death and its metadata-scaled dissolve damage.
 */
public final class LiquidDeathBlock extends FiniteFluidBlock implements NativeBucketPickup, EntityBlock {

    public static final MapCodec<LiquidDeathBlock> CODEC = LiquidDeathBlock.native$BlockCodecPlatform$simple(LiquidDeathBlock::new);

    public LiquidDeathBlock(BlockBehaviour.Properties properties) {
        super(properties, TCFluids.LIQUID_DEATH::get);
    }

    @Override
    public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        return new MagicFluidBlockEntity(pos, state);
    }

    protected MapCodec<LiquidDeathBlock> codec() {
        return CODEC;
    }

    @Override
    public void entityInside(BlockState state, Level level, BlockPos pos, Entity entity) {
        if (!level.isClientSide && entity instanceof LivingEntity living) {
            living.hurt(ThaumcraftDamageTypes.dissolve(level), state.getValue(LEVEL) + 1.0F);
        }
    }

    @Override
    public void animateTick(BlockState state, Level level, BlockPos pos, RandomSource random) {
        int metadata = Math.min(3, state.getValue(LEVEL));
        dev.tc4port.thaumcraft.client.AdvancedFurnaceBubbleParticle.tickLiquidDeath(level, pos, metadata, random);
        if (random.nextInt(50) == 0) {
            level.playLocalSound(pos, TCSounds.LIQUID_DEATH_BUBBLE.get(), SoundSource.BLOCKS, 0.1F + random.nextFloat() * 0.1F, 0.9F + random.nextFloat() * 0.15F, false);
        }
    }

    public ItemStack pickupBlock(net.minecraft.world.level.LevelAccessor native$callbackInput$1160, net.minecraft.core.BlockPos native$callbackInput$1161, net.minecraft.world.level.block.state.BlockState native$callbackInput$1162) {
        net.minecraft.world.entity.player.Player player = null;
        net.minecraft.world.level.LevelAccessor level = native$callbackInput$1160;
        net.minecraft.core.BlockPos pos = native$callbackInput$1161;
        net.minecraft.world.level.block.state.BlockState state = native$callbackInput$1162;
        if (level.getBlockEntity(pos) instanceof MagicFluidBlockEntity fluid && fluid.volume() < 1000) {
            return ItemStack.EMPTY;
        }
        if (state.getValue(LEVEL) != 3) {
            return ItemStack.EMPTY;
        }
        level.setBlock(pos, Blocks.AIR.defaultBlockState(), 11);
        return new ItemStack(TCItems.LIQUID_DEATH_BUCKET.get());
    }

    @Override
    public Optional<SoundEvent> getPickupSound() {
        return Optional.of(SoundEvents.BUCKET_FILL);
    }

    static private <B extends net.minecraft.world.level.block.Block> com.mojang.serialization.MapCodec<B> native$BlockCodecPlatform$simple(java.util.function.Function<net.minecraft.world.level.block.state.BlockBehaviour.Properties, B> factory) {
        // Vanilla 1.21's Properties codec is a unit codec. Retain that schema for shared block definitions.
        return com.mojang.serialization.codecs.RecordCodecBuilder.mapCodec(instance -> instance.group(com.mojang.serialization.Codec.unit(net.minecraft.world.level.block.state.BlockBehaviour.Properties::of).fieldOf("properties").forGetter((B block) -> net.minecraft.world.level.block.state.BlockBehaviour.Properties.copy(block))).apply(instance, factory));
    }
}
