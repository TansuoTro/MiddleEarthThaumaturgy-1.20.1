package dev.tc4port.thaumcraft.api.entity;

import net.minecraft.world.entity.Mob;
import net.minecraft.world.level.Level;

/**
 * Creates a wild fire bat without assigning focus ownership or a despawn timer.
 */
public final class FireBatApi {

    private FireBatApi() {
    }

    public static Mob create(Level level, boolean explosive, boolean devil) {
        var bat = dev.tc4port.thaumcraft.registry.TCEntities.FIRE_BAT.get().create(level);
        if (bat != null)
            bat.configureWild(explosive, devil);
        return bat;
    }
}
