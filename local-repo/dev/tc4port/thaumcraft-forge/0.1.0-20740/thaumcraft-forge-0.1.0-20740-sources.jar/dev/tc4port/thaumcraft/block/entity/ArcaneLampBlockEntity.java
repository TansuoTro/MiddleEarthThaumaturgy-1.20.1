package dev.tc4port.thaumcraft.block.entity;

import dev.tc4port.thaumcraft.block.ArcaneLampBlock;
import dev.tc4port.thaumcraft.block.GlimmerOfLightBlock;
import dev.tc4port.thaumcraft.block.ManaPodBlock;
import dev.tc4port.thaumcraft.api.aspect.AspectId;
import dev.tc4port.thaumcraft.api.essentia.EssentiaApi;
import dev.tc4port.thaumcraft.api.essentia.EssentiaTransferMode;
import dev.tc4port.thaumcraft.api.essentia.EssentiaTransport;
import dev.tc4port.thaumcraft.network.BlockSparklePayload;
import dev.tc4port.thaumcraft.registry.TCBlockEntities;
import dev.tc4port.thaumcraft.registry.TCBlocks;
import dev.tc4port.thaumcraft.registry.TCTags;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import javax.annotation.Nullable;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.animal.Animal;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.BonemealableBlock;
import net.minecraft.world.level.block.BushBlock;
import net.minecraft.world.level.block.CactusBlock;
import net.minecraft.world.level.block.CocoaBlock;
import net.minecraft.world.level.block.CropBlock;
import net.minecraft.world.level.block.GrassBlock;
import net.minecraft.world.level.block.NetherWartBlock;
import net.minecraft.world.level.block.StemBlock;
import net.minecraft.world.level.block.SugarCaneBlock;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import java.lang.Math;
import dev.tc4port.thaumcraft.nativeimpl.state.ItemFields;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.entity.BlockEntityType;

/**
 * Source-faithful shared implementation of TileArcaneLamp,
 * TileArcaneLampGrowth and TileArcaneLampFertility.
 */
public final class ArcaneLampBlockEntity extends net.minecraft.world.level.block.entity.BlockEntity implements EssentiaTransport, ItemFields.Source {

    private static final int LAMP_RANGE = 15;

    private static final int GROWTH_RANGE = 6;

    private static final int FERTILITY_RANGE = 7;

    private static final int GROWTH_SPARKLE_COLOR = 0x40FF40;

    private static final AspectId HERBA = AspectId.parse("herba");

    private static final AspectId VICTUS = AspectId.parse("victus");

    private boolean reserve;

    private int charges;

    private int count;

    private int drawDelay;

    private final List<BlockPos> growthChecklist = new ArrayList<>();

    private BlockPos lastGrowthTarget = BlockPos.ZERO;

    private BlockState lastGrowthState = net.minecraft.world.level.block.Blocks.AIR.defaultBlockState();

    @Nullable
    private BlockPos pendingGrowthTarget;

    @Nullable
    private Block pendingGrowthBlock;

    public ArcaneLampBlockEntity(BlockPos pos, BlockState state) {
        super(TCBlockEntities.ARCANE_LAMP.get(), pos, state);
        this.charges = this.kind() == ArcaneLampBlock.Kind.GROWTH ? -1 : 0;
    }

    public static void serverTick(Level level, BlockPos pos, BlockState state, ArcaneLampBlockEntity lamp) {
        if (!(level instanceof ServerLevel serverLevel)) {
            return;
        }
        switch(lamp.kind()) {
            case ARCANE ->
                lamp.tickArcane(serverLevel);
            case GROWTH ->
                lamp.tickGrowth(serverLevel);
            case FERTILITY ->
                lamp.tickFertility(serverLevel);
        }
    }

    private ArcaneLampBlock.Kind kind() {
        return this.getBlockState().getBlock() instanceof ArcaneLampBlock lamp ? lamp.kind() : ArcaneLampBlock.Kind.ARCANE;
    }

    public Direction facing() {
        return this.getBlockState().hasProperty(ArcaneLampBlock.FACING) ? this.getBlockState().getValue(ArcaneLampBlock.FACING) : Direction.DOWN;
    }

    public int charges() {
        return this.charges;
    }

    public boolean reserve() {
        return this.reserve;
    }

    private void tickArcane(ServerLevel level) {
        int x = this.worldPosition.getX() + level.random.nextInt(16) - level.random.nextInt(16);
        int y = this.worldPosition.getY() + level.random.nextInt(16) - level.random.nextInt(16);
        int z = this.worldPosition.getZ() + level.random.nextInt(16) - level.random.nextInt(16);
        if (!level.hasChunk(x >> 4, z >> 4))
            return;
        int surface = level.getHeight(net.minecraft.world.level.levelgen.Heightmap.Types.WORLD_SURFACE, x, z);
        y = Math.min(y, surface + 4);
        /*
         * TC4 clamped against y=5 in a 0-based world. Keep the same five
         * block void margin in modern dimensions with negative build height.
         */
        y = Math.max(y, level.getMinBuildHeight() + 5);
        this.placeSecondaryLightAt(level, new BlockPos(x, y, z));
    }

    public boolean placeSecondaryLightAt(ServerLevel level, BlockPos target) {
        if (!level.isLoaded(target))
            return false;
        BlockState targetState = level.getBlockState(target);
        if (!targetState.isAir() || targetState.getBlock() instanceof GlimmerOfLightBlock || level.getRawBrightness(target, 0) >= 9) {
            return false;
        }
        return level.setBlock(target, TCBlocks.GLIMMER_OF_LIGHT_DIM.get().defaultBlockState(), Block.UPDATE_ALL);
    }

    public void removeSecondaryLights(ServerLevel level) {
        BlockPos.MutableBlockPos cursor = new BlockPos.MutableBlockPos();
        for (int x = -LAMP_RANGE; x <= LAMP_RANGE; x++) {
            for (int y = -LAMP_RANGE; y <= LAMP_RANGE; y++) {
                for (int z = -LAMP_RANGE; z <= LAMP_RANGE; z++) {
                    cursor.setWithOffset(this.worldPosition, x, y, z);
                    if (level.isLoaded(cursor) && level.getBlockState(cursor).is(TCBlocks.GLIMMER_OF_LIGHT_DIM.get())) {
                        level.removeBlock(cursor, false);
                    }
                }
            }
        }
    }

    private void tickGrowth(ServerLevel level) {
        this.runPendingGrowth(level);
        if (this.charges <= 0) {
            if (this.reserve) {
                this.charges = 100;
                this.reserve = false;
                this.changedAndSyncChargeState();
            } else if (this.drawEssentia(HERBA)) {
                this.charges = 100;
                this.changedAndSyncChargeState();
            }
        }
        if (!this.reserve && this.drawEssentia(HERBA)) {
            this.reserve = true;
            this.setChanged();
        }
        if (this.charges == 0) {
            this.charges = -1;
            this.changedAndSyncChargeState();
        }
        if (this.charges > 0) {
            this.updatePlant(level);
        }
    }

    private void updatePlant(ServerLevel level) {
        if (level.isLoaded(this.lastGrowthTarget)) {
            BlockState currentLast = level.getBlockState(this.lastGrowthTarget);
            if (currentLast != this.lastGrowthState) {
                this.sendGrowthSparkles(level, this.lastGrowthTarget);
                this.lastGrowthState = currentLast;
            }
        }
        if (this.growthChecklist.isEmpty()) {
            for (int x = -GROWTH_RANGE; x <= GROWTH_RANGE; x++) {
                for (int z = -GROWTH_RANGE; z <= GROWTH_RANGE; z++) {
                    this.growthChecklist.add(this.worldPosition.offset(x, GROWTH_RANGE, z));
                }
            }
            shuffle(this.growthChecklist, level.random);
        }
        BlockPos column = this.growthChecklist.remove(0);
        if (!level.isLoaded(column))
            return;
        BlockPos.MutableBlockPos target = column.mutable();
        while (target.getY() >= this.worldPosition.getY() - GROWTH_RANGE) {
            BlockState state = level.getBlockState(target);
            if (this.isPlant(state) && this.distanceToSqr(target) < GROWTH_RANGE * GROWTH_RANGE && !this.isGrownCrop(level, target, state) && !state.is(TCTags.LAMP_GROWTH_BLACKLIST)) {
                this.lastGrowthTarget = target.immutable();
                this.lastGrowthState = state;
                this.pendingGrowthTarget = target.immutable();
                this.pendingGrowthBlock = state.getBlock();
                return;
            }
            target.move(Direction.DOWN);
        }
    }

    private void runPendingGrowth(ServerLevel level) {
        if (this.pendingGrowthTarget == null || this.pendingGrowthBlock == null) {
            return;
        }
        BlockPos target = this.pendingGrowthTarget;
        Block expected = this.pendingGrowthBlock;
        // Candidates are unpaid and expire on this tick, so an unloaded
        // target never holds up scanning the remaining loaded plants.
        this.pendingGrowthTarget = null;
        this.pendingGrowthBlock = null;
        if (this.charges <= 0 || !level.isLoaded(target))
            return;
        BlockState state = level.getBlockState(target);
        if (state.is(expected) && !this.isGrownCrop(level, target, state) && !state.is(TCTags.LAMP_GROWTH_BLACKLIST)) {
            this.charges--;
            this.setChanged();
            /*
             * 1.7's scheduled update called the same updateTick used by
             * random ticks. BlockState.randomTick is its modern equivalent.
             */
            state.randomTick(level, target, level.random);
        }
    }

    private boolean isPlant(BlockState state) {
        Block block = state.getBlock();
        return !(block instanceof GrassBlock) && (block instanceof BonemealableBlock || block instanceof BushBlock || block instanceof CactusBlock || block instanceof ManaPodBlock || block instanceof SugarCaneBlock);
    }

    private boolean isGrownCrop(ServerLevel level, BlockPos pos, BlockState state) {
        Block block = state.getBlock();
        if (block instanceof BonemealableBlock growable && !(block instanceof StemBlock) && !(switch(0) {
            default ->
                {
                    net.minecraft.world.level.block.BonemealableBlock native$operand$13654 = growable;
                    net.minecraft.world.level.LevelReader native$operand$13655 = level;
                    net.minecraft.core.BlockPos native$operand$13656 = pos;
                    net.minecraft.world.level.block.state.BlockState native$operand$13657 = state;
                    boolean native$result$13658 = (native$operand$13654.isValidBonemealTarget(native$operand$13655, native$operand$13656, native$operand$13657, native$operand$13655.isClientSide()));
                    yield native$result$13658;
                }
        })) {
            return true;
        }
        if (block instanceof CropBlock crop && crop.isMaxAge(state)) {
            return true;
        }
        if (block instanceof NetherWartBlock && state.getValue(NetherWartBlock.AGE) >= 3) {
            return true;
        }
        if (block instanceof CocoaBlock && state.getValue(CocoaBlock.AGE) >= 2) {
            return true;
        }
        if (block instanceof ManaPodBlock && state.getValue(ManaPodBlock.AGE) >= 7) {
            return true;
        }
        return (block instanceof CactusBlock || block instanceof SugarCaneBlock) && level.getBlockState(pos.below()).is(block);
    }

    private double distanceToSqr(BlockPos target) {
        int x = target.getX() - this.worldPosition.getX();
        int y = target.getY() - this.worldPosition.getY();
        int z = target.getZ() - this.worldPosition.getZ();
        return x * x + y * y + z * z;
    }

    private static void shuffle(List<BlockPos> positions, RandomSource random) {
        for (int index = positions.size() - 1; index > 0; index--) {
            Collections.swap(positions, index, random.nextInt(index + 1));
        }
    }

    private void sendGrowthSparkles(ServerLevel level, BlockPos target) {
        BlockSparklePayload payload = new BlockSparklePayload(target, GROWTH_SPARKLE_COLOR, 7);
        Vec3 sourcePoint = Vec3.atLowerCornerOf(target);
        for (ServerPlayer player : level.players()) {
            if (player.distanceToSqr(sourcePoint) <= 32.0 * 32.0) {
                dev.tc4port.thaumcraft.network.TCPayloads.CHANNEL.sendToPlayer(player, payload);
            }
        }
    }

    private void tickFertility(ServerLevel level) {
        if (this.charges < 4 && this.drawEssentia(VICTUS)) {
            this.charges++;
            this.changedAndSyncChargeState();
        }
        if (this.charges > 1 && this.count++ % 300 == 0) {
            this.updateAnimals(level);
        }
    }

    private void updateAnimals(ServerLevel level) {
        AABB range = new AABB(this.worldPosition.getX(), this.worldPosition.getY(), this.worldPosition.getZ(), this.worldPosition.getX() + 1, this.worldPosition.getY() + 1, this.worldPosition.getZ() + 1).inflate(FERTILITY_RANGE);
        List<Animal> animals = level.getEntitiesOfClass(Animal.class, range);
        java.util.Map<Class<?>, List<Animal>> species = new java.util.HashMap<>();
        for (Animal animal : animals) {
            species.computeIfAbsent(animal.getClass(), ignored -> new ArrayList<>()).add(animal);
        }
        for (Animal animal : animals) {
            if (animal.getAge() != 0 || animal.isInLove()) {
                continue;
            }
            List<Animal> sameSpecies = species.get(animal.getClass());
            if (sameSpecies.size() > 7) {
                continue;
            }
            Animal partner = null;
            for (Animal candidate : sameSpecies) {
                if (candidate.getAge() != 0 || candidate.isInLove()) {
                    continue;
                }
                if (partner != null) {
                    this.charges -= 2;
                    candidate.setInLove(null);
                    partner.setInLove(null);
                    /*
                     * TC4 did not send a tile packet here. The charged flag
                     * is a modern block-state/light adaptation and must be
                     * updated so server and client light agree.
                     */
                    this.changedAndSyncChargeState();
                    return;
                }
                partner = candidate;
            }
        }
    }

    private boolean drawEssentia(AspectId wantedAspect) {
        if (++this.drawDelay % 5 != 0 || this.level == null) {
            return false;
        }
        Direction facing = this.facing();
        BlockPos neighborPos = this.worldPosition.relative(facing);
        if (!this.level.isLoaded(neighborPos))
            return false;
        EssentiaTransport transport = EssentiaApi.transport(this.level, neighborPos, facing.getOpposite());
        if (transport == null || !transport.isConnectable(facing.getOpposite()) || !transport.canOutputTo(facing.getOpposite()) || transport.suctionAmount(facing.getOpposite()) >= this.suctionAmount(facing)) {
            return false;
        }
        return EssentiaApi.take(this.level, transport, wantedAspect, 1, facing.getOpposite(), EssentiaTransferMode.EXECUTE) == 1;
    }

    @Override
    public boolean isConnectable(Direction face) {
        return this.kind() != ArcaneLampBlock.Kind.ARCANE && face == this.facing();
    }

    @Override
    public boolean canInputFrom(Direction face) {
        return this.kind() != ArcaneLampBlock.Kind.ARCANE && face == this.facing();
    }

    @Override
    public boolean canOutputTo(Direction face) {
        return false;
    }

    @Nullable
    @Override
    public AspectId suctionType(Direction face) {
        return switch(this.kind()) {
            case GROWTH ->
                HERBA;
            case FERTILITY ->
                VICTUS;
            default ->
                null;
        };
    }

    @Override
    public int suctionAmount(Direction face) {
        if (face != this.facing()) {
            return 0;
        }
        return switch(this.kind()) {
            case GROWTH ->
                this.reserve && this.charges > 0 ? 0 : 128;
            case FERTILITY ->
                128 - this.charges * 10;
            default ->
                0;
        };
    }

    @Override
    public int takeEssentia(AspectId aspect, int amount, Direction face, EssentiaTransferMode mode) {
        return 0;
    }

    @Override
    public int addEssentia(AspectId aspect, int amount, Direction face, EssentiaTransferMode mode) {
        return 0;
    }

    @Nullable
    @Override
    public AspectId essentiaType(Direction face) {
        return null;
    }

    @Override
    public int essentiaAmount(Direction face) {
        return 0;
    }

    @Override
    public int minimumSuction() {
        return 0;
    }

    @Override
    public boolean renderExtendedTube() {
        return false;
    }

    private void changedAndSyncChargeState() {
        this.setChanged();
        if (this.level == null || this.level.isClientSide) {
            return;
        }
        BlockState state = this.getBlockState();
        boolean charged = this.kind() == ArcaneLampBlock.Kind.ARCANE || this.charges > 0;
        if (state.getValue(ArcaneLampBlock.CHARGED) != charged) {
            this.level.setBlock(this.worldPosition, state.setValue(ArcaneLampBlock.CHARGED, charged), Block.UPDATE_CLIENTS);
        } else {
            this.level.sendBlockUpdated(this.worldPosition, state, state, Block.UPDATE_CLIENTS);
        }
    }

    @Override
    public void load(CompoundTag tag) {
        super.load(tag);
        this.reserve = tag.getBoolean("reserve");
        this.charges = tag.getInt("charges");
    }

    @Override
    protected void saveAdditional(CompoundTag tag) {
        super.saveAdditional(tag);
        tag.putInt("orientation", this.facing().get3DDataValue());
        tag.putBoolean("reserve", this.reserve);
        tag.putInt("charges", this.charges);
    }

    @Override
    public CompoundTag getUpdateTag() {
        return this.saveWithoutMetadata();
    }

    @Override
    public Packet<ClientGamePacketListener> getUpdatePacket() {
        return ClientboundBlockEntityDataPacket.create(this);
    }

    protected final HolderLookup.Provider persistenceRegistries() {
        if (level != null)
            return level.registryAccess();
        var server = net.minecraftforge.server.ServerLifecycleHooks.getCurrentServer();
        return server != null ? server.registryAccess() : net.minecraft.core.RegistryAccess.fromRegistryOfRegistries(net.minecraft.core.registries.BuiltInRegistries.REGISTRY);
    }

    protected static net.minecraft.network.chat.Component parseCustomNameSafe(String value, HolderLookup.Provider registries) {
        try {
            return net.minecraft.network.chat.Component.Serializer.fromJson(value);
        } catch (RuntimeException exception) {
            return null;
        }
    }

    protected void readItemFields(ItemFields.Input input) {
    }

    public void copyItemFields(ItemFields.Output output) {
    }

    public void applyComponentsFromItemStack(ItemStack stack) {
        readItemFields(ItemFields.from(stack));
    }

    public void removeComponentsFromTag(CompoundTag tag) {
    }

    @Override
    public void saveToItem(ItemStack stack) {
        CompoundTag tag = saveWithoutMetadata();
        {
            net.minecraft.nbt.CompoundTag native$bodyOperand$6102 = tag;
            native$bodyReturn$6104: {
                if (true) {
                }
            }
        }
        net.minecraft.world.item.BlockItem.setBlockEntityData(stack, getType(), tag);
        copyItemFields(ItemFields.to(stack));
    }

    @Override
    public net.minecraft.world.phys.AABB getRenderBoundingBox() {
        return ArcaneLampBlockEntity.native$ClientBlockEntityBounds$bounds(this);
    }

    @Override()
    public void onDataPacket(net.minecraft.network.Connection connection, net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket packet) {
        handleUpdateTag(packet.getTag());
    }

    @SuppressWarnings({ "rawtypes", "unchecked" })
    static private net.minecraft.world.phys.AABB native$ClientBlockEntityBounds$bounds(net.minecraft.world.level.block.entity.BlockEntity blockEntity) {
        var renderer = net.minecraft.client.Minecraft.getInstance().getBlockEntityRenderDispatcher().getRenderer(blockEntity);
        return renderer instanceof dev.tc4port.thaumcraft.nativeimpl.NativeBlockEntityRenderer shared ? shared.getRenderBoundingBox(blockEntity) : new net.minecraft.world.phys.AABB(blockEntity.getBlockPos());
    }

    private boolean native$capabilitiesInvalid$16884;

    public boolean native$capabilityActive$16765;

    public net.minecraftforge.common.capabilities.Capability<dev.tc4port.thaumcraft.api.essentia.EssentiaTransport> native$capabilityCapture$16764;

    private net.minecraftforge.common.util.LazyOptional<dev.tc4port.thaumcraft.api.essentia.EssentiaTransport> native$capabilityHandle$16766;

    @Override
    public <native$capabilityResultType$16885> net.minecraftforge.common.util.LazyOptional<native$capabilityResultType$16885> getCapability(net.minecraftforge.common.capabilities.Capability<native$capabilityResultType$16885> native$requestedCapability$16886, net.minecraft.core.Direction native$requestedFace$16887) {
        getCapabilities();
        synchronized (this) {
            if (native$capabilitiesInvalid$16884)
                return net.minecraftforge.common.util.LazyOptional.empty();
            if (native$capabilityActive$16765 && native$requestedCapability$16886 == (this.native$capabilityCapture$16764)) {
                if (native$capabilityHandle$16766 == null)
                    native$capabilityHandle$16766 = net.minecraftforge.common.util.LazyOptional.of(() -> this);
                return native$capabilityHandle$16766.cast();
            }
        }
        return super.getCapability(native$requestedCapability$16886, native$requestedFace$16887);
    }

    @Override
    public void invalidateCaps() {
        java.util.List<net.minecraftforge.common.util.LazyOptional<?>> native$expiredCapabilities$16888 = new java.util.ArrayList<>();
        synchronized (this) {
            native$capabilitiesInvalid$16884 = true;
            if (native$capabilityHandle$16766 != null) {
                native$expiredCapabilities$16888.add(native$capabilityHandle$16766);
                native$capabilityHandle$16766 = null;
            }
        }
        try {
            super.invalidateCaps();
        } finally {
            native$expiredCapabilities$16888.forEach(net.minecraftforge.common.util.LazyOptional::invalidate);
        }
    }

    @Override
    public void reviveCaps() {
        super.reviveCaps();
        synchronized (this) {
            native$capabilitiesInvalid$16884 = false;
        }
    }
}
