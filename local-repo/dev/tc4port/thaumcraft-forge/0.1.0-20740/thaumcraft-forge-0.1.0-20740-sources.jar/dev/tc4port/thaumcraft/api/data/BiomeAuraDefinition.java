package dev.tc4port.thaumcraft.api.data;

import com.mojang.serialization.Codec;
import com.mojang.datafixers.util.Either;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import dev.tc4port.thaumcraft.api.aspect.AspectId;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 * One numerical value attached by a native biome selector, without a classification or profile ID.
 */
public record BiomeAuraDefinition(int aura, Optional<AspectId> aspect, float greatwoodChance) {

    public static final Codec<BiomeAuraDefinition> CODEC = RecordCodecBuilder.create(instance -> instance.group(Codec.intRange(1, 1_000_000).fieldOf("aura").forGetter(BiomeAuraDefinition::aura), BiomeAuraDefinition.native$StrictOptionalFields$of(AspectId.CODEC, "aspect").forGetter(BiomeAuraDefinition::aspect), BiomeAuraDefinition.native$StrictOptionalFields$of(Codec.floatRange(0.0F, 1.0F), "greatwood_chance", 0.0F).forGetter(BiomeAuraDefinition::greatwoodChance)).apply(instance, BiomeAuraDefinition::new));

    /**
     * Flat entries are convenient to author; arrays also round-trip merged native values.
     */
    public static final Codec<List<BiomeAuraDefinition>> DATA_MAP_CODEC = Codec.either(CODEC, CODEC.listOf()).xmap(value -> value.map(List::of, List::copyOf), values -> values.size() == 1 ? Either.left(values.get(0)) : Either.right(values));

    /**
     * Native tag entries append unless the data pack uses the native entry or file replace flag.
     */
    public static List<BiomeAuraDefinition> merge(List<BiomeAuraDefinition> older, List<BiomeAuraDefinition> newer) {
        var values = new ArrayList<>(older);
        values.addAll(newer);
        return List.copyOf(values);
    }

    static private <A> com.mojang.serialization.MapCodec<java.util.Optional<A>> native$StrictOptionalFields$of(com.mojang.serialization.Codec<A> codec, java.lang.String name) {
        java.util.Objects.requireNonNull(codec, "codec");
        java.util.Objects.requireNonNull(name, "name");
        return new com.mojang.serialization.MapCodec<>() {

            @Override
            public <T> com.mojang.serialization.DataResult<java.util.Optional<A>> decode(com.mojang.serialization.DynamicOps<T> ops, com.mojang.serialization.MapLike<T> input) {
                T value = input.get(name);
                return value == null ? com.mojang.serialization.DataResult.success(java.util.Optional.empty()) : codec.parse(ops, value).map(java.util.Optional::of);
            }

            @Override
            public <T> com.mojang.serialization.RecordBuilder<T> encode(java.util.Optional<A> input, com.mojang.serialization.DynamicOps<T> ops, com.mojang.serialization.RecordBuilder<T> prefix) {
                return input.isPresent() ? prefix.add(name, codec.encodeStart(ops, input.get())) : prefix;
            }

            @Override
            public <T> java.util.stream.Stream<T> keys(com.mojang.serialization.DynamicOps<T> ops) {
                return java.util.stream.Stream.of(ops.createString(name));
            }

            @Override
            public java.lang.String toString() {
                return "StrictOptionalField[" + name + ": " + codec + "]";
            }
        };
    }

    static private <A> com.mojang.serialization.MapCodec<A> native$StrictOptionalFields$of(com.mojang.serialization.Codec<A> codec, java.lang.String name, A defaultValue) {
        return BiomeAuraDefinition.native$StrictOptionalFields$of(codec, name).xmap(value -> value.orElse(defaultValue), value -> java.util.Objects.equals(value, defaultValue) ? java.util.Optional.empty() : java.util.Optional.of(value));
    }
}
