package dev.tc4port.thaumcraft.api.event;

import dev.tc4port.thaumcraft.api.event.OrderedCallbacks;
import dev.tc4port.thaumcraft.api.event.WorldProtection;
import java.util.function.Predicate;
import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.projectile.AbstractArrow;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;

/**
 * Native interception contracts. Values compose in order; any false permission vetoes.
 */
public final class WorldBehaviorHooks {

    public interface ArrowSource {

        DamageSource apply(AbstractArrow arrow, Entity shooter, DamageSource current);
    }

    public interface TickPermission {

        boolean allow(Level level, BlockPos pos, boolean fluid, boolean random);
    }

    public interface RainLevel {

        float apply(Level level, float partialTick, float current);
    }

    public interface MushroomPlacementPermission {

        boolean allow(BlockGetter level, BlockPos pos, BlockState existing);
    }

    public static final OrderedCallbacks<ArrowSource> ARROW_SOURCE = new OrderedCallbacks<>();

    public static final OrderedCallbacks<TickPermission> TICK = new OrderedCallbacks<>();

    public static final OrderedCallbacks<Predicate<Entity>> STEP = new OrderedCallbacks<>();

    public static final OrderedCallbacks<MushroomPlacementPermission> MUSHROOM_REPLACEMENT = new OrderedCallbacks<>();

    public static final OrderedCallbacks<RainLevel> RAIN = new OrderedCallbacks<>();

    public static final OrderedCallbacks<Predicate<ResourceKey<Level>>> SPIN_MAP = new OrderedCallbacks<>();

    private WorldBehaviorHooks() {
    }

    public static DamageSource arrowSource(AbstractArrow arrow, Entity shooter, DamageSource source) {
        for (ArrowSource callback : ARROW_SOURCE.values()) source = callback.apply(arrow, shooter, source);
        return source;
    }

    public static boolean allowTick(Level level, BlockPos pos, boolean fluid, boolean random) {
        if (!WorldProtection.allow(level, pos, WorldProtection.Action.TICK, null))
            return false;
        for (TickPermission callback : TICK.values()) if (!callback.allow(level, pos, fluid, random))
            return false;
        return true;
    }

    public static boolean allowStep(Entity entity) {
        for (Predicate<Entity> callback : STEP.values()) if (!callback.test(entity))
            return false;
        return true;
    }

    /**
     * Additional veto for mushroom cap and stem placement; vanilla eligibility remains authoritative.
     */
    public static boolean allowMushroomReplacement(BlockGetter level, BlockPos pos, BlockState existing) {
        if (!WorldProtection.allow(level, pos, WorldProtection.Action.GROW, null))
            return false;
        for (MushroomPlacementPermission callback : MUSHROOM_REPLACEMENT.values()) if (!callback.allow(level, pos, existing))
            return false;
        return true;
    }

    public static float rain(Level level, float partialTick, float current) {
        for (RainLevel callback : RAIN.values()) current = callback.apply(level, partialTick, current);
        return current;
    }

    public static boolean spinMap(ResourceKey<Level> dimension) {
        for (Predicate<ResourceKey<Level>> callback : SPIN_MAP.values()) if (callback.test(dimension))
            return true;
        return false;
    }
}
