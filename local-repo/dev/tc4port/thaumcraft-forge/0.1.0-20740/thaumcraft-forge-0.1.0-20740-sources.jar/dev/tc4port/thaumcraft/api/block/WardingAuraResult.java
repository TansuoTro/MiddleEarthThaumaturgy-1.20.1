package dev.tc4port.thaumcraft.api.block;

/**
 * Result of one loaded, server-authoritative warding-aura operation.
 */
public enum WardingAuraResult {

    CREATED,
    ALREADY_PRESENT,
    UPDATED,
    UNCHANGED,
    BLOCKED,
    NOT_AURA,
    OFF_SERVER_THREAD,
    CHUNK_UNLOADED,
    OUT_OF_BOUNDS;

    public boolean successful() {
        return this == CREATED || this == ALREADY_PRESENT || this == UPDATED || this == UNCHANGED;
    }
}
