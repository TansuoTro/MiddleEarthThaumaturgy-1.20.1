package dev.tc4port.thaumcraft.api.client;

/**
 * The three native golem world marker surfaces.
 */
public enum MarkerVisual {

    MARK, HOME, EMPTY
}
