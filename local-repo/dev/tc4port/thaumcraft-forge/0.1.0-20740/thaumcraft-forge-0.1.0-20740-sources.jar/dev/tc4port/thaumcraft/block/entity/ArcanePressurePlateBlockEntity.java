package dev.tc4port.thaumcraft.block.entity;

import dev.tc4port.thaumcraft.registry.TCBlockEntities;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.block.state.BlockState;

/**
 * UUID-based TileOwned state for the Arcane Pressure Plate.
 *
 * <p>The two sets retain ItemKey's iron access and gold administrative access
 * without relying on mutable player names.</p>
 */
public final class ArcanePressurePlateBlockEntity extends AbstractArcaneOwnedBlockEntity {

    public ArcanePressurePlateBlockEntity(BlockPos pos, BlockState state) {
        super(TCBlockEntities.ARCANE_PRESSURE_PLATE.get(), pos, state);
    }
}
