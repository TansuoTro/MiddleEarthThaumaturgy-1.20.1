package dev.tc4port.thaumcraft.api.research;

import dev.tc4port.thaumcraft.api.aspect.AspectAmounts;
import java.util.List;
import java.util.Objects;
import java.util.Set;
import net.minecraft.resources.ResourceLocation;

/**
 * Immutable gameplay summary of an active research entry.
 *
 * <p>Page rendering, legacy item-icon expressions and clue implementation
 * details remain data-pack/internal concerns rather than a Java ABI.</p>
 */
public record ResearchEntrySummary(ResearchKey key, ResearchCategoryKey category, AspectAmounts aspects, int displayColumn, int displayRow, int complexity, Set<ResearchEntryFlag> flags, List<ResearchKey> parents, List<ResearchKey> hiddenParents, List<ResearchKey> siblings, int warp, Set<ResourceLocation> labels) {

    public ResearchEntrySummary {
        key = Objects.requireNonNull(key, "key");
        category = Objects.requireNonNull(category, "category");
        aspects = Objects.requireNonNull(aspects, "aspects");
        if (complexity < 1 || complexity > 3) {
            throw new IllegalArgumentException("Research complexity must be 1..3");
        }
        flags = Set.copyOf(Objects.requireNonNull(flags, "flags"));
        parents = List.copyOf(Objects.requireNonNull(parents, "parents"));
        hiddenParents = List.copyOf(Objects.requireNonNull(hiddenParents, "hiddenParents"));
        siblings = List.copyOf(Objects.requireNonNull(siblings, "siblings"));
        labels = Set.copyOf(Objects.requireNonNull(labels, "labels"));
        if (labels.size() > 64) {
            throw new IllegalArgumentException("Research labels must contain at most 64 values");
        }
        if (warp < 0) {
            throw new IllegalArgumentException("Research warp must be non-negative");
        }
    }

    public boolean hasFlag(ResearchEntryFlag flag) {
        return this.flags.contains(Objects.requireNonNull(flag, "flag"));
    }

    /**
     * Compatibility constructor for integrations compiled against the
     * original summary API.
     */
    public ResearchEntrySummary(ResearchKey key, ResearchCategoryKey category, AspectAmounts aspects, int displayColumn, int displayRow, int complexity, Set<ResearchEntryFlag> flags, List<ResearchKey> parents, List<ResearchKey> hiddenParents, List<ResearchKey> siblings, int warp) {
        this(key, category, aspects, displayColumn, displayRow, complexity, flags, parents, hiddenParents, siblings, warp, Set.of());
    }

    public boolean hasLabel(ResourceLocation label) {
        return this.labels.contains(Objects.requireNonNull(label, "label"));
    }
}
