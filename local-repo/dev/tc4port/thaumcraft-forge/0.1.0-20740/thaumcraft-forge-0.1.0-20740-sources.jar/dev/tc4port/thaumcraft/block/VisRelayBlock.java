package dev.tc4port.thaumcraft.block;

import com.mojang.serialization.MapCodec;
import dev.tc4port.thaumcraft.block.entity.VisRelayBlockEntity;
import dev.tc4port.thaumcraft.registry.TCBlockEntities;
import javax.annotation.Nullable;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityTicker;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.world.level.block.state.properties.DirectionProperty;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.VoxelShape;

/**
 * Six-face shell for BlockMetalDevice metadata 14.
 *
 * <p>The stored facing is the clicked face, exactly like the source tile's
 * {@code orientation}; its support is therefore in the opposite direction.</p>
 */
public final class VisRelayBlock extends AbstractVisRelayBlock implements dev.tc4port.thaumcraft.nativeimpl.ClientExtensionTarget {

    public static final MapCodec<VisRelayBlock> CODEC = VisRelayBlock.native$BlockCodecPlatform$simple(VisRelayBlock::new);

    public static final DirectionProperty FACING = BlockStateProperties.FACING;

    public static final BooleanProperty CONNECTED = BooleanProperty.create("connected");

    public VisRelayBlock(BlockBehaviour.Properties properties) {
        super(properties);
        this.registerDefaultState(this.stateDefinition.any().setValue(FACING, Direction.UP).setValue(CONNECTED, false));
    }

    protected MapCodec<VisRelayBlock> codec() {
        return CODEC;
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(FACING, CONNECTED);
    }

    @Nullable
    @Override
    public BlockState getStateForPlacement(BlockPlaceContext context) {
        return this.defaultBlockState().setValue(FACING, context.getClickedFace());
    }

    @Override
    public VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
        return switch(state.getValue(FACING).getOpposite()) {
            case UP ->
                Block.box(5, 8, 5, 11, 16, 11);
            case DOWN ->
                Block.box(5, 0, 5, 11, 8, 11);
            case EAST ->
                Block.box(8, 5, 5, 16, 11, 11);
            case WEST ->
                Block.box(0, 5, 5, 8, 11, 11);
            case SOUTH ->
                Block.box(5, 5, 8, 11, 11, 16);
            case NORTH ->
                Block.box(5, 5, 0, 11, 11, 8);
        };
    }

    @Override
    public void neighborChanged(BlockState state, Level level, BlockPos pos, Block neighborBlock, BlockPos neighborPos, boolean movedByPiston) {
        super.neighborChanged(state, level, pos, neighborBlock, neighborPos, movedByPiston);
        BlockPos support = pos.relative(state.getValue(FACING).getOpposite());
        /*
         * BlockMetalDevice checked isAirBlock rather than face sturdiness.
         * Transparent and partial non-air supports therefore remain valid.
         */
        if (!level.isClientSide && neighborPos.equals(support) && level.getBlockState(support).isAir()) {
            level.destroyBlock(pos, true);
        }
    }

    @Nullable
    @Override
    public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        return new VisRelayBlockEntity(pos, state);
    }

    @Nullable
    @Override
    public <T extends BlockEntity> BlockEntityTicker<T> getTicker(Level level, BlockState state, BlockEntityType<T> type) {
        return createTickerHelper(type, TCBlockEntities.VIS_RELAY.get(), level.isClientSide ? VisRelayBlockEntity::clientTick : VisRelayBlockEntity::serverTick);
    }

    @Override
    public RenderShape getRenderShape(BlockState state) {
        return RenderShape.MODEL;
    }

    static private <B extends net.minecraft.world.level.block.Block> com.mojang.serialization.MapCodec<B> native$BlockCodecPlatform$simple(java.util.function.Function<net.minecraft.world.level.block.state.BlockBehaviour.Properties, B> factory) {
        // Vanilla 1.21's Properties codec is a unit codec. Retain that schema for shared block definitions.
        return com.mojang.serialization.codecs.RecordCodecBuilder.mapCodec(instance -> instance.group(com.mojang.serialization.Codec.unit(net.minecraft.world.level.block.state.BlockBehaviour.Properties::of).fieldOf("properties").forGetter((B block) -> net.minecraft.world.level.block.state.BlockBehaviour.Properties.copy(block))).apply(instance, factory));
    }
}
