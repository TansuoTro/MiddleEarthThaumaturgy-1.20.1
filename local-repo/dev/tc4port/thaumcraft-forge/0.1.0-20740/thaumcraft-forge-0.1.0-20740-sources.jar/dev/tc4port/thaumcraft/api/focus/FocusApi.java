package dev.tc4port.thaumcraft.api.focus;

import dev.tc4port.thaumcraft.api.aspect.AspectApi;
import dev.tc4port.thaumcraft.api.aspect.VisAction;
import dev.tc4port.thaumcraft.api.aspect.VisChannel;
import dev.tc4port.thaumcraft.common.FocusCarrierState;
import dev.tc4port.thaumcraft.common.FocusSelectionService;
import dev.tc4port.thaumcraft.common.FocusStacks;
import dev.tc4port.thaumcraft.common.FocusUpgradeCatalog;
import dev.tc4port.thaumcraft.data.WandData;
import dev.tc4port.thaumcraft.api.wand.WandCarrierItem;
import dev.tc4port.thaumcraft.state.TCItemState;
import java.nio.charset.StandardCharsets;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.item.ItemStack;

/**
 * Stable entry point for the active server-synchronized focus catalog.
 */
public final class FocusApi {

    public static final int MAX_PROPERTIES = FocusCarrierState.MAX_PROPERTIES;

    public static final int MAX_PROPERTY_VALUE_LENGTH = FocusCarrierState.MAX_PROPERTY_VALUE_LENGTH;

    public static final int MAX_PROPERTY_ENCODED_BYTES = FocusCarrierState.MAX_PROPERTY_ENCODED_BYTES;

    private FocusApi() {
    }

    /**
     * Declares the parameter keys consumed by an addon behavior, before server data loads.
     */
    public static void requireParameters(FocusId focus, Set<String> keys) {
        FocusUpgradeCatalog.requireParameters(focus, keys);
    }

    /**
     * Declares a native safety bound for parameters which one behavior adds together.
     */
    public static void requireParameterSumAtMost(FocusId focus, Set<String> keys, double maximum) {
        FocusUpgradeCatalog.requireParameterSumAtMost(focus, keys, maximum);
    }

    /**
     * Declares named costs that an addon behavior requires in every loaded profile.
     */
    public static void requireActionCosts(FocusId focus, Set<String> keys) {
        FocusUpgradeCatalog.requireActionCosts(focus, keys);
    }

    public static FocusRegistryView registry() {
        return FocusUpgradeCatalog.apiView();
    }

    /**
     * Resolves a gameplay parameter from the active catalog. No Java balance fallback is used.
     */
    public static double parameter(FocusStateView state, String key) {
        return registry().profile(state.focusId()).orElseThrow(() -> new IllegalStateException("Missing focus profile: " + state.focusId())).parameters().value(key, state.upgradeLevels());
    }

    public static double parameter(ItemStack stack, String key) {
        return parameter(installedState(stack).orElseThrow(() -> new IllegalArgumentException("Stack has no installed focus")), key);
    }

    /**
     * Reads installed state from a focus item or a wand holding a focus.
     * This is a read-only data query, not an executable focus callback.
     */
    public static Optional<FocusStateView> installedState(ItemStack stack) {
        return FocusUpgradeCatalog.installedState(stack);
    }

    public static int upgradeLevel(ItemStack stack, FocusUpgradeId upgradeId) {
        return installedState(stack).map(state -> state.level(upgradeId)).orElse(0);
    }

    /**
     * Appends the source-style Vis cost and installed-upgrade lines for any
     * valid built-in or addon focus carrier.
     *
     * <p>This is the shared presentation boundary for addon items. It uses
     * the synchronized catalog and the carrier's {@link FocusStateView}, so
     * callers do not need to duplicate TC's amount formatting, aspect order,
     * colors, cadence label or dormant-upgrade handling.</p>
     */
    public static void appendFocusTooltip(ItemStack stack, List<Component> tooltip) {
        Objects.requireNonNull(stack, "stack");
        Objects.requireNonNull(tooltip, "tooltip");
        FocusStateView state = installedState(stack).orElse(null);
        if (state == null) {
            return;
        }
        FocusProfileDefinition profile = registry().profile(state.focusId()).orElse(null);
        if (profile == null) {
            return;
        }
        var cost = FocusUpgradeCatalog.visCost(profile, state.upgradeLevels());
        if (!cost.isEmpty()) {
            tooltip.add(Component.translatable(profile.displaysPerTickCost(state.upgradeLevels()) ? "item.Focus.cost2" : "item.Focus.cost1"));
            cost.entrySet().stream().filter(entry -> entry.getValue() > 0).sorted(Comparator.comparing((java.util.Map.Entry<dev.tc4port.thaumcraft.api.aspect.VisChannel, java.lang.Integer> entry) -> entry.getKey().aspectId().serialized())).forEach(entry -> appendVisCostLine(tooltip, entry.getKey(), entry.getValue()));
        }
        appendFocusInformation(state, tooltip);
    }

    /**
     * Appends only installed-upgrade lines for a focus carrier or a wand.
     * This is useful when the enclosing UI already presents its own cost.
     */
    public static void appendFocusInformation(ItemStack stack, List<Component> tooltip) {
        Objects.requireNonNull(stack, "stack");
        Objects.requireNonNull(tooltip, "tooltip");
        installedState(stack).ifPresent(state -> appendFocusInformation(state, tooltip));
    }

    /**
     * Player attribute values shown on a held carrier; also available to addon tooltips.
     */
    public static void appendCastingAttributes(ItemStack wand, net.minecraft.world.entity.LivingEntity caster, List<Component> tooltip) {
        if (caster == null || installedState(wand).isEmpty())
            return;
        double bonus = dev.tc4port.thaumcraft.api.MagicAttributes.damageBonus(caster);
        tooltip.add(Component.translatable("thaumcraft.tooltip.focus_damage_bonus", (bonus >= 0 ? "+" : "") + new DecimalFormat("0.##", DecimalFormatSymbols.getInstance(java.util.Locale.ROOT)).format(bonus)).withStyle(ChatFormatting.DARK_PURPLE));
        tooltip.add(Component.translatable("thaumcraft.tooltip.focus_damage_multiplier", formatPercent(dev.tc4port.thaumcraft.api.MagicAttributes.multiplier(caster, dev.tc4port.thaumcraft.api.MagicAttributes.FOCUS_DAMAGE_MULTIPLIER))).withStyle(ChatFormatting.DARK_PURPLE));
        double cooldown = dev.tc4port.thaumcraft.api.MagicAttributes.multiplier(caster, dev.tc4port.thaumcraft.api.MagicAttributes.FOCUS_COOLDOWN_MULTIPLIER);
        if (wand.getItem() instanceof dev.tc4port.thaumcraft.api.wand.CustomWandItem custom) {
            cooldown *= custom.thaumcraftWandSpec().cooldownMultiplier();
        }
        tooltip.add(Component.translatable("thaumcraft.tooltip.focus_cooldown_multiplier", formatPercent(cooldown)).withStyle(ChatFormatting.DARK_PURPLE));
    }

    private static String formatPercent(double value) {
        return new DecimalFormat("0.##", DecimalFormatSymbols.getInstance(java.util.Locale.ROOT)).format(value * 100.0D) + "%";
    }

    public static FocusInstallResult install(ServerPlayer player, InteractionHand hand, ItemStack focus, VisAction action) {
        Objects.requireNonNull(player, "player");
        Objects.requireNonNull(hand, "hand");
        Objects.requireNonNull(focus, "focus");
        Objects.requireNonNull(action, "action");
        if (!player.server.isSameThread()) {
            return FocusInstallResult.DENIED;
        }
        ItemStack wand = player.getItemInHand(hand);
        if (!(wand.getItem() instanceof WandCarrierItem)) {
            return FocusInstallResult.NOT_A_WAND;
        }
        FocusStateView state = FocusStacks.state(focus).orElse(null);
        if (state == null) {
            return FocusInstallResult.NOT_A_FOCUS;
        }
        if (registry().profile(state.focusId()).isEmpty()) {
            return FocusInstallResult.UNKNOWN_PROFILE;
        }
        if (!FocusStacks.validForPlayer(player, state)) {
            return FocusInstallResult.INVALID_STATE;
        }
        WandData data = (switch(0) {
            default ->
                {
                    dev.tc4port.thaumcraft.api.data.ItemStateKey<dev.tc4port.thaumcraft.data.WandData> native$receiver$503 = TCItemState.WAND;
                    net.minecraft.world.item.ItemStack native$argument$504 = wand;
                    dev.tc4port.thaumcraft.data.WandData native$argument$505 = WandData.DEFAULT;
                    java.util.Objects.requireNonNull(native$receiver$503);
                    yield dev.tc4port.thaumcraft.api.item.ItemStatePlatform.getOrDefault(native$argument$504, native$receiver$503, native$argument$505);
                }
        });
        if (data.sceptre()) {
            return FocusInstallResult.DENIED;
        }
        if (data.focus().isPresent() && installedState(wand).isEmpty()) {
            return FocusInstallResult.INVALID_STATE;
        }
        ItemStack installing = focus.copyWithCount(1);
        WandData replacement;
        try {
            replacement = FocusStacks.install(data, installing, state);
        } catch (RuntimeException exception) {
            return FocusInstallResult.INVALID_STATE;
        }
        ItemStack returned = FocusStacks.installedCarrier(data);
        if (action == VisAction.SIMULATE) {
            boolean space = returned.isEmpty() || FocusSelectionService.canStoreReturnedFocus(player, returned) || consumptionFreesInventorySlot(player, focus);
            return space ? FocusInstallResult.WOULD_INSTALL : FocusInstallResult.NO_RETURN_SPACE;
        }
        focus.shrink(1);
        if (!returned.isEmpty() && !FocusSelectionService.storeReturnedFocus(player, returned)) {
            focus.grow(1);
            return FocusInstallResult.NO_RETURN_SPACE;
        }
        {
            dev.tc4port.thaumcraft.api.data.ItemStateKey<dev.tc4port.thaumcraft.data.WandData> native$receiver$840 = TCItemState.WAND;
            net.minecraft.world.item.ItemStack native$argument$841 = wand;
            dev.tc4port.thaumcraft.data.WandData native$argument$842 = replacement;
            java.util.Objects.requireNonNull(native$receiver$840);
            dev.tc4port.thaumcraft.api.item.ItemStatePlatform.set(native$argument$841, native$receiver$840, java.util.Objects.requireNonNull(native$argument$842, "value"));
        }
        return FocusInstallResult.INSTALLED;
    }

    public static FocusPropertyUpdateResult updateInstalledProperties(ServerPlayer player, InteractionHand hand, Map<ResourceLocation, String> replacements, Set<ResourceLocation> removals, VisAction action) {
        Objects.requireNonNull(player, "player");
        Objects.requireNonNull(hand, "hand");
        Objects.requireNonNull(replacements, "replacements");
        Objects.requireNonNull(removals, "removals");
        Objects.requireNonNull(action, "action");
        if (!player.server.isSameThread()) {
            return FocusPropertyUpdateResult.DENIED;
        }
        ItemStack wand = player.getItemInHand(hand);
        if (!(wand.getItem() instanceof WandCarrierItem)) {
            return FocusPropertyUpdateResult.NO_FOCUS;
        }
        WandData data = (switch(0) {
            default ->
                {
                    dev.tc4port.thaumcraft.api.data.ItemStateKey<dev.tc4port.thaumcraft.data.WandData> native$receiver$506 = TCItemState.WAND;
                    net.minecraft.world.item.ItemStack native$argument$507 = wand;
                    dev.tc4port.thaumcraft.data.WandData native$argument$508 = WandData.DEFAULT;
                    java.util.Objects.requireNonNull(native$receiver$506);
                    yield dev.tc4port.thaumcraft.api.item.ItemStatePlatform.getOrDefault(native$argument$507, native$receiver$506, native$argument$508);
                }
        });
        ItemStack carrier = FocusStacks.installedCarrier(data);
        FocusStateView current = installedState(wand).orElse(null);
        if (current == null) {
            return FocusPropertyUpdateResult.NO_FOCUS;
        }
        LinkedHashMap<ResourceLocation, String> properties = new LinkedHashMap<>(current.properties());
        removals.forEach(properties::remove);
        replacements.forEach(properties::put);
        if (!validProperties(properties)) {
            return FocusPropertyUpdateResult.INVALID_PROPERTIES;
        }
        FocusStateView changed = new FocusStateView(current.focusId(), current.upgradeSlots(), properties);
        if (changed.equals(current)) {
            return FocusPropertyUpdateResult.UNCHANGED;
        }
        ItemStack replacement;
        try {
            replacement = FocusStacks.withState(carrier, changed);
        } catch (UnsupportedOperationException exception) {
            return FocusPropertyUpdateResult.READ_ONLY_CARRIER;
        } catch (RuntimeException exception) {
            return FocusPropertyUpdateResult.INVALID_PROPERTIES;
        }
        if (action == VisAction.SIMULATE) {
            return FocusPropertyUpdateResult.WOULD_UPDATE;
        }
        {
            dev.tc4port.thaumcraft.api.data.ItemStateKey<dev.tc4port.thaumcraft.data.WandData> native$receiver$843 = TCItemState.WAND;
            net.minecraft.world.item.ItemStack native$argument$844 = wand;
            dev.tc4port.thaumcraft.data.WandData native$argument$845 = FocusStacks.install(data, replacement);
            java.util.Objects.requireNonNull(native$receiver$843);
            dev.tc4port.thaumcraft.api.item.ItemStatePlatform.set(native$argument$844, native$receiver$843, java.util.Objects.requireNonNull(native$argument$845, "value"));
        }
        return FocusPropertyUpdateResult.UPDATED;
    }

    private static boolean validProperties(Map<ResourceLocation, String> properties) {
        if (properties.size() > MAX_PROPERTIES) {
            return false;
        }
        int bytes = 0;
        for (Map.Entry<ResourceLocation, String> entry : properties.entrySet()) {
            String value = entry.getValue();
            if (value == null || value.length() > MAX_PROPERTY_VALUE_LENGTH) {
                return false;
            }
            bytes += entry.getKey().toString().getBytes(StandardCharsets.UTF_8).length;
            bytes += value.getBytes(StandardCharsets.UTF_8).length;
            if (bytes > MAX_PROPERTY_ENCODED_BYTES) {
                return false;
            }
        }
        return true;
    }

    private static void appendFocusInformation(FocusStateView state, List<Component> tooltip) {
        state.upgradeLevels().forEach((upgrade, level) -> {
            FocusUpgradeDefinition definition = registry().upgrade(upgrade).orElse(null);
            if (definition == null) {
                Component dormant = Component.literal(upgrade.toString()).withStyle(ChatFormatting.DARK_GRAY);
                if (level > 1) {
                    dormant = dormant.copy().append(" ").append(Component.translatable("enchantment.level." + level).withStyle(ChatFormatting.DARK_GRAY));
                }
                tooltip.add(dormant);
                return;
            }
            Component line = Component.translatable(definition.nameKey()).withStyle(ChatFormatting.DARK_PURPLE);
            if (level > 1) {
                line = line.copy().append(" ").append(Component.translatable("enchantment.level." + level).withStyle(ChatFormatting.DARK_PURPLE));
            }
            tooltip.add(line);
        });
    }

    private static void appendVisCostLine(List<Component> tooltip, VisChannel channel, int amount) {
        var aspect = AspectApi.registry().get(channel.aspectId()).orElseThrow(() -> new IllegalStateException("Missing Vis channel aspect " + channel.aspectId()));
        tooltip.add(Component.literal(" ").append(Component.literal(aspect.name()).withStyle(style -> style.withColor(aspect.color()))).append(Component.literal(" x " + formatVis(amount)).withStyle(ChatFormatting.RESET)));
    }

    private static String formatVis(int centivis) {
        DecimalFormat formatter = new DecimalFormat("#####.##", DecimalFormatSymbols.getInstance(java.util.Locale.ROOT));
        return formatter.format(centivis / 100.0F);
    }

    private static boolean consumptionFreesInventorySlot(ServerPlayer player, ItemStack focus) {
        if (focus.getCount() != 1) {
            return false;
        }
        for (ItemStack inventoryStack : player.getInventory().items) {
            if (inventoryStack == focus) {
                return true;
            }
        }
        return false;
    }
}
