package dev.tc4port.thaumcraft.api.client;

public interface NativeFluidClientExtensions extends net.minecraftforge.client.extensions.common.IClientFluidTypeExtensions {

    default boolean renderFluid(net.minecraft.world.level.material.FluidState fluid, net.minecraft.world.level.BlockAndTintGetter level, net.minecraft.core.BlockPos pos, com.mojang.blaze3d.vertex.VertexConsumer vertices, net.minecraft.world.level.block.state.BlockState state) {
        return false;
    }
}
