package dev.tc4port.thaumcraft.block;

import dev.tc4port.thaumcraft.common.MultiblockFormation;
import dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult;
import com.mojang.serialization.MapCodec;
import dev.tc4port.thaumcraft.api.ThaumcraftApiHelper;
import dev.tc4port.thaumcraft.api.aspect.VisAction;
import dev.tc4port.thaumcraft.api.aspect.VisPaymentResult;
import dev.tc4port.thaumcraft.block.entity.AdvancedAlchemyFurnaceBlockEntity;
import dev.tc4port.thaumcraft.common.CompoundBlueprintCatalog;
import dev.tc4port.thaumcraft.common.PlayerKnowledgeService;
import dev.tc4port.thaumcraft.common.WandVis;
import dev.tc4port.thaumcraft.network.BlockSparklePayload;
import dev.tc4port.thaumcraft.registry.TCBlockEntities;
import dev.tc4port.thaumcraft.registry.TCBlocks;
import dev.tc4port.thaumcraft.registry.TCSounds;
import java.util.List;
import javax.annotation.Nullable;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityTicker;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.world.level.block.state.properties.IntegerProperty;
import net.minecraft.world.level.pathfinder.PathComputationType;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.EntityCollisionContext;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;
import java.lang.ThreadLocal;
import dev.tc4port.thaumcraft.nativeimpl.ClientExtensionTarget;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.Explosion;

/**
 * Formed two-layer advanced alchemical furnace (legacy metadata 0..4).
 */
public final class AdvancedAlchemyFurnaceBlock extends net.minecraft.world.level.block.BaseEntityBlock implements dev.tc4port.thaumcraft.nativeimpl.ClientExtensionTarget {

    // Forge calls initializeClient from the native superclass constructor. Do not add a field initializer.
    private java.util.function.Consumer<net.minecraftforge.client.extensions.common.IClientBlockExtensions> platform$clientInstaller;

    public static final MapCodec<AdvancedAlchemyFurnaceBlock> CODEC = AdvancedAlchemyFurnaceBlock.native$BlockCodecPlatform$simple(AdvancedAlchemyFurnaceBlock::new);

    public static final IntegerProperty PART = IntegerProperty.create("part", 0, 4);

    public static final BooleanProperty LIT = BooleanProperty.create("lit");

    public static final IntegerProperty LIGHT = IntegerProperty.create("light", 0, 15);

    public static final int CORE = 0;

    public static final int NOZZLE = 1;

    public static final int TOP_CORNER = 2;

    public static final int TOP_SIDE = 3;

    public static final int BOTTOM_CORNER = 4;

    private static final ThreadLocal<Boolean> RESTORING = ThreadLocal.withInitial(() -> false);

    private static final VoxelShape LOW_CORE = Block.box(0, 0, 0, 16, 11.2, 16);

    public AdvancedAlchemyFurnaceBlock(BlockBehaviour.Properties properties) {
        this(properties, properties, true);
    }

    protected MapCodec<AdvancedAlchemyFurnaceBlock> codec() {
        return CODEC;
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(PART, LIT, LIGHT);
    }

    @Nullable
    @Override
    public BlockState getStateForPlacement(BlockPlaceContext context) {
        Level level = context.getLevel();
        BlockPos core = context.getClickedPos();
        CollisionContext collision = context.getPlayer() == null ? CollisionContext.empty() : CollisionContext.of(context.getPlayer());
        for (int y = 0; y <= 1; y++) {
            for (int x = -1; x <= 1; x++) {
                for (int z = -1; z <= 1; z++) {
                    BlockPos pos = core.offset(x, y, z);
                    if (level.isOutsideBuildHeight(pos) || !level.getWorldBorder().isWithinBounds(pos)) {
                        return null;
                    }
                    // The opening above the core stays empty, as in wand formation.
                    if (y == 1 && x == 0 && z == 0) {
                        if (!level.getBlockState(pos).isAir())
                            return null;
                        continue;
                    }
                    BlockState part = this.defaultBlockState().setValue(PART, partAt(x, y, z));
                    if (!level.getBlockState(pos).canBeReplaced(BlockPlaceContext.at(context, pos, Direction.UP)) || !level.isUnobstructed(part, pos, collision)) {
                        return null;
                    }
                }
            }
        }
        return this.defaultBlockState();
    }

    @Override
    public void setPlacedBy(Level level, BlockPos pos, BlockState state, @Nullable LivingEntity placer, ItemStack stack) {
        super.setPlacedBy(level, pos, state, placer, stack);
        if (!level.isClientSide) {
            // BlockItem has already placed and initialized the core.
            placeStructure(level, pos, false);
        }
    }

    @Nullable
    @Override
    public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        int part = state.getValue(PART);
        return part == CORE || part == NOZZLE ? new AdvancedAlchemyFurnaceBlockEntity(pos, state) : null;
    }

    @Nullable
    @Override
    public <T extends BlockEntity> BlockEntityTicker<T> getTicker(Level level, BlockState state, BlockEntityType<T> type) {
        if (state.getValue(PART) != CORE) {
            return null;
        }
        return level.isClientSide ? null : createTickerHelper(type, TCBlockEntities.ADVANCED_ALCHEMY_FURNACE.get(), AdvancedAlchemyFurnaceBlockEntity::serverTick);
    }

    @Override
    public RenderShape getRenderShape(BlockState state) {
        return RenderShape.MODEL;
    }

    @Override
    public VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
        /*
         * The source selection box was always a full cube. Its shortened
         * core bound existed only in addCollisionBoxesToList for non-living
         * entities.
         */
        return Shapes.block();
    }

    @Override
    public VoxelShape getCollisionShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
        if (state.getValue(PART) != CORE) {
            return Shapes.block();
        }
        return context instanceof EntityCollisionContext entityContext && entityContext.getEntity() instanceof LivingEntity ? Shapes.block() : LOW_CORE;
    }

    @Override
    public void entityInside(BlockState state, Level level, BlockPos pos, Entity entity) {
        if (!level.isClientSide && state.getValue(PART) == CORE && entity instanceof ItemEntity item && level.getBlockEntity(pos) instanceof AdvancedAlchemyFurnaceBlockEntity furnace && furnace.process(item.getItem())) {
            ItemStack remaining = item.getItem().copy();
            remaining.shrink(1);
            level.playSound(null, item.blockPosition(), TCSounds.BUBBLE.get(), SoundSource.BLOCKS, 0.2F, 1.0F + level.random.nextFloat() * 0.4F);
            if (remaining.isEmpty()) {
                item.discard();
            } else {
                item.setItem(remaining);
            }
        }
    }

    @Override
    public void animateTick(BlockState state, Level level, BlockPos pos, net.minecraft.util.RandomSource random) {
        /*
         * Block#randomDisplayTick was the source scheduler. A client BE
         * ticker produced two bubbles every game tick instead of only when
         * this nearby block receives a random display tick.
         */
        if (state.getValue(PART) == CORE && level.getBlockEntity(pos) instanceof AdvancedAlchemyFurnaceBlockEntity furnace) {
            dev.tc4port.thaumcraft.client.AdvancedFurnaceBubbleParticle.tickFurnace(level, pos, furnace);
        }
    }

    public static ItemUseResult tryForm(Level level, BlockPos clicked, Player player, InteractionHand hand, ItemStack wand, Direction face) {
        BlockState clickedState = level.getBlockState(clicked);
        if (!CompoundBlueprintCatalog.isTrigger(CompoundBlueprintCatalog.ADVANCED_ALCHEMICAL_FURNACE, clickedState)) {
            return ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
        }
        boolean primaryTrigger = clickedState.is(TCBlocks.ADVANCED_ALCHEMICAL_CONSTRUCT.get());
        // Other data-provided triggers use the secondary/fall-through path.
        var blueprint = CompoundBlueprintCatalog.require(CompoundBlueprintCatalog.ADVANCED_ALCHEMICAL_FURNACE);
        if (!PlayerKnowledgeService.get(player).hasCompletedResearch(blueprint.research())) {
            /*
             * Metadata three had only event seven and therefore intercepted
             * the focus path. Metadata nine also owned the Thaumatorium
             * trigger, so it must be allowed to continue to that handler.
             */
            return primaryTrigger ? ItemUseResult.FAIL : ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
        }
        for (int x = -1; x <= 1; x++) {
            for (int y = -1; y <= 1; y++) {
                for (int z = -1; z <= 1; z++) {
                    BlockPos core = clicked.offset(x, y, z);
                    if (!fits(level, core)) {
                        continue;
                    }
                    var cost = WandVis.craftingCost(wand, player, blueprint.aspects());
                    if (ThaumcraftApiHelper.consumeExactVisFromWand(wand, player, cost, VisAction.SIMULATE) != VisPaymentResult.AVAILABLE) {
                        return ItemUseResult.FAIL;
                    }
                    if (!level.isClientSide) {
                        if (!MultiblockFormation.convert((ServerLevel) level, player, face, wand, cost, () -> placeStructure(level, core, true), () -> formationEffects((ServerLevel) level, core))) {
                            return ItemUseResult.FAIL;
                        }
                    }
                    player.swing(hand);
                    return ItemUseResult.sidedSuccess(level.isClientSide);
                }
            }
        }
        return primaryTrigger ? ItemUseResult.FAIL : ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
    }

    public static boolean fits(Level level, BlockPos core) {
        return CompoundBlueprintCatalog.matchesFormation(CompoundBlueprintCatalog.ADVANCED_ALCHEMICAL_FURNACE, level, core.offset(-1, 1, -1));
    }

    private static int partAt(int x, int y, int z) {
        if (y == 0 && x == 0 && z == 0)
            return CORE;
        if (y == 0 && (x == 0 ^ z == 0))
            return NOZZLE;
        if (y == 0)
            return BOTTOM_CORNER;
        return x != 0 && z != 0 ? TOP_CORNER : TOP_SIDE;
    }

    private static boolean placeStructure(Level level, BlockPos core, boolean includeCore) {
        for (int y = 0; y <= 1; y++) {
            for (int x = -1; x <= 1; x++) {
                for (int z = -1; z <= 1; z++) {
                    if (y == 1 && x == 0 && z == 0) {
                        continue;
                    }
                    if (!includeCore && y == 0 && x == 0 && z == 0)
                        continue;
                    if (!level.setBlock(core.offset(x, y, z), TCBlocks.ADVANCED_ALCHEMY_FURNACE.get().defaultBlockState().setValue(PART, partAt(x, y, z)), Block.UPDATE_ALL))
                        return false;
                }
            }
        }
        return true;
    }

    private static void formationEffects(ServerLevel level, BlockPos core) {
        level.playSound(null, core, TCSounds.WAND.get(), SoundSource.BLOCKS, 1.0F, 1.0F);
        sendFormationSparkles(level, core);
    }

    private static void sendFormationSparkles(ServerLevel level, BlockPos core) {
        Vec3 center = Vec3.atCenterOf(core);
        List<ServerPlayer> nearbyPlayers = level.players().stream().filter(player -> player.distanceToSqr(center) <= 32.0 * 32.0).toList();
        for (int x = -1; x <= 1; x++) {
            for (int y = 0; y <= 1; y++) {
                for (int z = -1; z <= 1; z++) {
                    BlockSparklePayload payload = new BlockSparklePayload(core.offset(x, y, z), -9999, 7);
                    for (ServerPlayer player : nearbyPlayers) {
                        dev.tc4port.thaumcraft.network.TCPayloads.CHANNEL.sendToPlayer(player, payload);
                    }
                }
            }
        }
    }

    @Override
    public void onRemove(BlockState state, Level level, BlockPos pos, BlockState newState, boolean movedByPiston) {
        if (!state.is(newState.getBlock()) && level instanceof ServerLevel server && !RESTORING.get() && !(switch(0) {
            default ->
                {
                    net.minecraft.world.level.Level native$operand$13628 = level;
                    boolean native$result$13629 = (native$operand$13628.restoringBlockSnapshots);
                    yield native$result$13629;
                }
        })) {
            BlockPos core = state.getValue(PART) == CORE ? pos : findCore(level, pos);
            if (core != null) {
                restoreAfterBreak(server, core, pos);
            }
        }
        super.onRemove(state, level, pos, newState, movedByPiston);
    }

    @Nullable
    private static BlockPos findCore(Level level, BlockPos around) {
        for (int y = -1; y <= 1; y++) {
            for (int x = -1; x <= 1; x++) {
                for (int z = -1; z <= 1; z++) {
                    BlockPos check = around.offset(x, y, z);
                    BlockState state = level.getBlockState(check);
                    if (state.is(TCBlocks.ADVANCED_ALCHEMY_FURNACE.get()) && state.getValue(PART) == CORE) {
                        return check;
                    }
                }
            }
        }
        return null;
    }

    private static void restoreAfterBreak(ServerLevel level, BlockPos core, BlockPos broken) {
        RESTORING.set(true);
        try {
            for (int y = 0; y <= 1; y++) {
                for (int x = -1; x <= 1; x++) {
                    for (int z = -1; z <= 1; z++) {
                        BlockPos check = core.offset(x, y, z);
                        BlockState formed = level.getBlockState(check);
                        if (!formed.is(TCBlocks.ADVANCED_ALCHEMY_FURNACE.get())) {
                            continue;
                        }
                        level.setBlock(check, check.equals(broken) ? Blocks.AIR.defaultBlockState() : restoredState(formed.getValue(PART)), Block.UPDATE_ALL);
                    }
                }
            }
        } finally {
            RESTORING.set(false);
        }
    }

    private static BlockState restoredState(int part) {
        return switch(part) {
            case CORE ->
                TCBlocks.ALCHEMICAL_FURNACE.get().defaultBlockState();
            case TOP_CORNER ->
                TCBlocks.ARCANE_ALEMBIC.get().defaultBlockState();
            case TOP_SIDE ->
                TCBlocks.ALCHEMICAL_CONSTRUCT.get().defaultBlockState();
            default ->
                TCBlocks.ADVANCED_ALCHEMICAL_CONSTRUCT.get().defaultBlockState();
        };
    }

    @Override
    public boolean hasAnalogOutputSignal(BlockState state) {
        return state.getValue(PART) == NOZZLE;
    }

    @Override
    public int getAnalogOutputSignal(BlockState state, Level level, BlockPos pos) {
        if (state.getValue(PART) != NOZZLE || !(level.getBlockEntity(pos) instanceof AdvancedAlchemyFurnaceBlockEntity nozzle)) {
            return 0;
        }
        AdvancedAlchemyFurnaceBlockEntity core = nozzle.core();
        return core == null || core.vis() <= 0 ? 0 : 1;
    }

    @Override
    public boolean isPathfindable(BlockState state, BlockGetter level, BlockPos pos, PathComputationType pathType) {
        // Living entities collide with the core as a full cube, but the
        // pathfinder asks with an empty context and would see a low slab.
        return false;
    }

    private AdvancedAlchemyFurnaceBlock(net.minecraft.world.level.block.state.BlockBehaviour.Properties native$NativeEntityBlock$arg0, BlockBehaviour.Properties properties, boolean native$NativeEntityBlock$captured) {
        super(native$NativeEntityBlock$arg0);
        this.registerDefaultState(this.stateDefinition.any().setValue(PART, CORE).setValue(LIT, false).setValue(LIGHT, 0));
    }

    @Override
    public void initializeClient(java.util.function.Consumer<net.minecraftforge.client.extensions.common.IClientBlockExtensions> installer) {
        platform$clientInstaller = installer;
        super.initializeClient(installer);
    }

    @Override
    public void platform$clientExtension(Object extension) {
        java.util.Objects.requireNonNull(platform$clientInstaller, "Forge initializeClient must run before client extension registration").accept((net.minecraftforge.client.extensions.common.IClientBlockExtensions) extension);
    }

    @Override
    public InteractionResult use(BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
        ItemUseResult result = (switch(0) {
            default ->
                {
                    net.minecraft.world.item.ItemStack native$bodyOperand$4023 = player.getItemInHand(hand);
                    net.minecraft.world.level.block.state.BlockState native$bodyOperand$4024 = state;
                    net.minecraft.world.level.Level native$bodyOperand$4025 = level;
                    net.minecraft.core.BlockPos native$bodyOperand$4026 = pos;
                    net.minecraft.world.entity.player.Player native$bodyOperand$4027 = player;
                    net.minecraft.world.InteractionHand native$bodyOperand$4028 = hand;
                    net.minecraft.world.phys.BlockHitResult native$bodyOperand$4029 = hit;
                    dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult native$bodyResult$4030 = null;
                    native$bodyReturn$4031: {
                        if (true) {
                            {
                                native$bodyResult$4030 = dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
                                break native$bodyReturn$4031;
                            }
                        }
                    }
                    yield native$bodyResult$4030;
                }
        });
        return result == ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION ? (hand == InteractionHand.MAIN_HAND ? (switch(0) {
            default ->
                {
                    net.minecraft.world.level.block.state.BlockState native$bodyOperand$3401 = state;
                    net.minecraft.world.level.Level native$bodyOperand$3402 = level;
                    net.minecraft.core.BlockPos native$bodyOperand$3403 = pos;
                    net.minecraft.world.entity.player.Player native$bodyOperand$3404 = player;
                    net.minecraft.world.phys.BlockHitResult native$bodyOperand$3405 = hit;
                    net.minecraft.world.InteractionResult native$bodyResult$3406 = null;
                    native$bodyReturn$3407: {
                        if (true) {
                            {
                                native$bodyResult$3406 = super.use(native$bodyOperand$3401, native$bodyOperand$3402, native$bodyOperand$3403, native$bodyOperand$3404, net.minecraft.world.InteractionHand.MAIN_HAND, native$bodyOperand$3405);
                                break native$bodyReturn$3407;
                            }
                        }
                    }
                    yield native$bodyResult$3406;
                }
        }) : InteractionResult.PASS) : result.result();
    }

    protected ItemUseResult interactWithItem(ItemStack stack, BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
        return dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
    }

    protected InteractionResult interactWithoutItem(BlockState state, Level level, BlockPos pos, Player player, BlockHitResult hit) {
        return super.use(state, level, pos, player, net.minecraft.world.InteractionHand.MAIN_HAND, hit);
    }

    @Override
    public void playerWillDestroy(Level level, BlockPos pos, BlockState state, Player player) {
        {
            net.minecraft.world.level.Level native$bodyOperand$5602 = level;
            net.minecraft.core.BlockPos native$bodyOperand$5603 = pos;
            net.minecraft.world.level.block.state.BlockState native$bodyOperand$5604 = state;
            net.minecraft.world.entity.player.Player native$bodyOperand$5605 = player;
            net.minecraft.world.level.block.state.BlockState native$bodyResult$5606 = null;
            native$bodyReturn$5607: {
                if (true) {
                    super.playerWillDestroy(native$bodyOperand$5602, native$bodyOperand$5603, native$bodyOperand$5604, native$bodyOperand$5605);
                    {
                        native$bodyResult$5606 = native$bodyOperand$5604;
                        break native$bodyReturn$5607;
                    }
                }
            }
        }
    }

    public BlockState beforePlayerDestroy(Level level, BlockPos pos, BlockState state, Player player) {
        super.playerWillDestroy(level, pos, state, player);
        return state;
    }

    protected boolean survivesSharedExplosion() {
        return false;
    }

    public int getExpDrop(net.minecraft.world.level.block.state.BlockState native$callbackInput$1050, net.minecraft.world.level.LevelReader native$callbackInput$1051, net.minecraft.util.RandomSource native$callbackInput$1052, net.minecraft.core.BlockPos native$callbackInput$1053, int native$callbackInput$1054, int native$callbackInput$1055) {
        net.minecraft.world.level.block.state.BlockState state = native$callbackInput$1050;
        net.minecraft.util.RandomSource random = native$callbackInput$1052;
        return 0;
    }

    @Override
    public void onBlockExploded(BlockState state, Level level, BlockPos pos, Explosion explosion) {
        if (!(switch(0) {
            default ->
                {
                    boolean native$bodyResult$5197 = false;
                    native$bodyReturn$5198: {
                        if (true) {
                            {
                                native$bodyResult$5197 = false;
                                break native$bodyReturn$5198;
                            }
                        }
                    }
                    yield native$bodyResult$5197;
                }
        }))
            super.onBlockExploded(state, level, pos, explosion);
    }

    @Override
    public boolean canDropFromExplosion(BlockState state, BlockGetter level, BlockPos pos, Explosion explosion) {
        return !(switch(0) {
            default ->
                {
                    boolean native$bodyResult$4032 = false;
                    native$bodyReturn$4033: {
                        if (true) {
                            {
                                native$bodyResult$4032 = false;
                                break native$bodyReturn$4033;
                            }
                        }
                    }
                    yield native$bodyResult$4032;
                }
        }) && super.canDropFromExplosion(state, level, pos, explosion);
    }

    static private <B extends net.minecraft.world.level.block.Block> com.mojang.serialization.MapCodec<B> native$BlockCodecPlatform$simple(java.util.function.Function<net.minecraft.world.level.block.state.BlockBehaviour.Properties, B> factory) {
        // Vanilla 1.21's Properties codec is a unit codec. Retain that schema for shared block definitions.
        return com.mojang.serialization.codecs.RecordCodecBuilder.mapCodec(instance -> instance.group(com.mojang.serialization.Codec.unit(net.minecraft.world.level.block.state.BlockBehaviour.Properties::of).fieldOf("properties").forGetter((B block) -> net.minecraft.world.level.block.state.BlockBehaviour.Properties.copy(block))).apply(instance, factory));
    }
}
