package dev.tc4port.thaumcraft.block.entity;

import dev.tc4port.thaumcraft.block.ItemGrateBlock;
import dev.tc4port.thaumcraft.entity.GrateItemEntity;
import dev.tc4port.thaumcraft.registry.TCBlockEntities;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.WorldlyContainer;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.state.BlockState;
import dev.tc4port.thaumcraft.nativeimpl.state.ItemFields;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityType;

/**
 * TileGrate's deliberately stateless, one-slot sided-inventory façade.
 */
public final class ItemGrateBlockEntity extends net.minecraft.world.level.block.entity.BlockEntity implements WorldlyContainer, ItemFields.Source {

    private static final int[] INPUT_SLOT = { 0 };

    private static final int[] NO_SLOTS = {};

    public ItemGrateBlockEntity(BlockPos pos, BlockState state) {
        super(TCBlockEntities.ITEM_GRATE.get(), pos, state);
    }

    public boolean isOpen() {
        return this.getBlockState().getBlock() instanceof ItemGrateBlock && ItemGrateBlock.isOpen(this.getBlockState());
    }

    @Override
    public int getContainerSize() {
        return 1;
    }

    @Override
    public boolean isEmpty() {
        return true;
    }

    @Override
    public ItemStack getItem(int slot) {
        return ItemStack.EMPTY;
    }

    @Override
    public ItemStack removeItem(int slot, int amount) {
        return ItemStack.EMPTY;
    }

    @Override
    public ItemStack removeItemNoUpdate(int slot) {
        return ItemStack.EMPTY;
    }

    @Override
    public void setItem(int slot, ItemStack stack) {
        if (slot != 0 || stack.isEmpty() || this.level == null || this.level.isClientSide || !this.isOpen()) {
            return;
        }
        this.level.addFreshEntity(new GrateItemEntity(this.level, this.worldPosition.getX() + 0.5, this.worldPosition.getY() + 0.6, this.worldPosition.getZ() + 0.5, stack.copy()));
    }

    @Override
    public boolean stillValid(Player player) {
        return false;
    }

    @Override
    public void clearContent() {
    }

    @Override
    public boolean canPlaceItem(int slot, ItemStack stack) {
        return slot == 0 && this.isOpen();
    }

    @Override
    public int[] getSlotsForFace(Direction side) {
        return this.isOpen() && side == Direction.UP ? INPUT_SLOT : NO_SLOTS;
    }

    @Override
    public boolean canPlaceItemThroughFace(int slot, ItemStack stack, Direction side) {
        return slot == 0 && side == Direction.UP && this.isOpen();
    }

    @Override
    public boolean canTakeItemThroughFace(int slot, ItemStack stack, Direction side) {
        return false;
    }

    protected final HolderLookup.Provider persistenceRegistries() {
        if (level != null)
            return level.registryAccess();
        var server = net.minecraftforge.server.ServerLifecycleHooks.getCurrentServer();
        return server != null ? server.registryAccess() : net.minecraft.core.RegistryAccess.fromRegistryOfRegistries(net.minecraft.core.registries.BuiltInRegistries.REGISTRY);
    }

    protected static net.minecraft.network.chat.Component parseCustomNameSafe(String value, HolderLookup.Provider registries) {
        try {
            return net.minecraft.network.chat.Component.Serializer.fromJson(value);
        } catch (RuntimeException exception) {
            return null;
        }
    }

    protected void readItemFields(ItemFields.Input input) {
    }

    public void copyItemFields(ItemFields.Output output) {
    }

    public void applyComponentsFromItemStack(ItemStack stack) {
        readItemFields(ItemFields.from(stack));
    }

    public void removeComponentsFromTag(CompoundTag tag) {
    }

    @Override
    public void saveToItem(ItemStack stack) {
        CompoundTag tag = saveWithoutMetadata();
        {
            net.minecraft.nbt.CompoundTag native$bodyOperand$6176 = tag;
            native$bodyReturn$6178: {
                if (true) {
                }
            }
        }
        net.minecraft.world.item.BlockItem.setBlockEntityData(stack, getType(), tag);
        copyItemFields(ItemFields.to(stack));
    }

    @Override
    public net.minecraft.world.phys.AABB getRenderBoundingBox() {
        return ItemGrateBlockEntity.native$ClientBlockEntityBounds$bounds(this);
    }

    @Override()
    public void onDataPacket(net.minecraft.network.Connection connection, net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket packet) {
        handleUpdateTag(packet.getTag());
    }

    @SuppressWarnings({ "rawtypes", "unchecked" })
    static private net.minecraft.world.phys.AABB native$ClientBlockEntityBounds$bounds(net.minecraft.world.level.block.entity.BlockEntity blockEntity) {
        var renderer = net.minecraft.client.Minecraft.getInstance().getBlockEntityRenderDispatcher().getRenderer(blockEntity);
        return renderer instanceof dev.tc4port.thaumcraft.nativeimpl.NativeBlockEntityRenderer shared ? shared.getRenderBoundingBox(blockEntity) : new net.minecraft.world.phys.AABB(blockEntity.getBlockPos());
    }

    private boolean native$capabilitiesInvalid$17015;

    public boolean native$capabilityActive$16852;

    private java.util.Map<net.minecraft.core.Direction, net.minecraftforge.common.util.LazyOptional<net.minecraftforge.items.IItemHandler>> native$capabilityHandle$16853;

    @Override
    public <native$capabilityResultType$17016> net.minecraftforge.common.util.LazyOptional<native$capabilityResultType$17016> getCapability(net.minecraftforge.common.capabilities.Capability<native$capabilityResultType$17016> native$requestedCapability$17017, net.minecraft.core.Direction native$requestedFace$17018) {
        getCapabilities();
        synchronized (this) {
            if (native$capabilitiesInvalid$17015)
                return net.minecraftforge.common.util.LazyOptional.empty();
            if (native$capabilityActive$16852 && native$requestedCapability$17017 == (net.minecraftforge.common.capabilities.ForgeCapabilities.ITEM_HANDLER)) {
                if (native$capabilityHandle$16853 == null)
                    native$capabilityHandle$16853 = new java.util.HashMap<>();
                net.minecraftforge.common.util.LazyOptional<net.minecraftforge.items.IItemHandler> native$capabilityResult$17020 = native$capabilityHandle$16853.computeIfAbsent(native$requestedFace$17018, native$capabilityFace$16854 -> {
                    net.minecraftforge.items.IItemHandler native$endpoint$301 = (switch(0) {
                        default ->
                            {
                                dev.tc4port.thaumcraft.block.entity.ItemGrateBlockEntity grate = dev.tc4port.thaumcraft.block.entity.ItemGrateBlockEntity.this;
                                net.minecraft.core.Direction side = native$capabilityFace$16854;
                                yield side == net.minecraft.core.Direction.UP ? (switch(0) {
                                    default ->
                                        {
                                            net.minecraft.world.WorldlyContainer native$operand$12743 = grate;
                                            net.minecraft.core.Direction native$operand$12744 = side;
                                            net.minecraftforge.items.IItemHandler native$result$12745 = (new net.minecraftforge.items.wrapper.SidedInvWrapper(native$operand$12743, native$operand$12744));
                                            yield native$result$12745;
                                        }
                                }) : null;
                            }
                    });
                    return native$endpoint$301 == null ? net.minecraftforge.common.util.LazyOptional.empty() : net.minecraftforge.common.util.LazyOptional.of(() -> native$endpoint$301);
                });
                if (native$capabilityResult$17020.isPresent())
                    return native$capabilityResult$17020.cast();
            }
        }
        return super.getCapability(native$requestedCapability$17017, native$requestedFace$17018);
    }

    @Override
    public void invalidateCaps() {
        java.util.List<net.minecraftforge.common.util.LazyOptional<?>> native$expiredCapabilities$17019 = new java.util.ArrayList<>();
        synchronized (this) {
            native$capabilitiesInvalid$17015 = true;
            if (native$capabilityHandle$16853 != null) {
                native$expiredCapabilities$17019.addAll(native$capabilityHandle$16853.values());
                native$capabilityHandle$16853 = null;
            }
        }
        try {
            super.invalidateCaps();
        } finally {
            native$expiredCapabilities$17019.forEach(net.minecraftforge.common.util.LazyOptional::invalidate);
        }
    }

    @Override
    public void reviveCaps() {
        super.reviveCaps();
        synchronized (this) {
            native$capabilitiesInvalid$17015 = false;
        }
    }
}
