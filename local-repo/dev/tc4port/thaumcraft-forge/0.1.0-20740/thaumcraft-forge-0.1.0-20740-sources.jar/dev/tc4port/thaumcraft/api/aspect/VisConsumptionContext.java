package dev.tc4port.thaumcraft.api.aspect;

/**
 * Selects the modifier family applied to a vis payment.
 */
public enum VisConsumptionContext {

    CRAFTING(true), CASTING(false);

    private final boolean crafting;

    VisConsumptionContext(boolean crafting) {
        this.crafting = crafting;
    }

    public boolean crafting() {
        return this.crafting;
    }
}
