package dev.tc4port.thaumcraft.api.client;

import java.util.IdentityHashMap;
import java.util.Map;
import net.minecraft.client.color.item.ItemColor;
import net.minecraft.client.renderer.block.model.BakedQuad;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.ItemLike;

/**
 * Shared item colors use NeoForge's ARGB contract; ordinary Forge colors use RGB.
 */
public final class ItemTintAlpha {

    private static final Map<Item, ItemColor> COLORS = new IdentityHashMap<>();

    private ItemTintAlpha() {
    }

    public static void register(ItemColor color, ItemLike... items) {
        for (ItemLike item : items) COLORS.put(item.asItem(), color);
    }

    public static float alpha(ItemStack stack, BakedQuad quad) {
        if (stack.isEmpty() || !quad.isTinted())
            return 1.0F;
        ItemColor color = COLORS.get(stack.getItem());
        return color == null ? 1.0F : (color.getColor(stack, quad.getTintIndex()) >>> 24) / 255.0F;
    }

    private static final java.util.Set<net.minecraftforge.eventbus.api.IEventBus> BUSES = java.util.Collections.newSetFromMap(new IdentityHashMap<>());

    public static void install(net.minecraftforge.eventbus.api.IEventBus bus) {
        if (BUSES.add(bus))
            bus.addListener(net.minecraftforge.eventbus.api.EventPriority.LOWEST, false, net.minecraftforge.client.event.ModelEvent.ModifyBakingResult.class, ItemTintAlpha::bake);
    }

    private static void bake(net.minecraftforge.client.event.ModelEvent.ModifyBakingResult event) {
        // Bulk replacement may be probed with a null model by lazy model registries.
        // Request only registered item models so their real bake result receives the tint.
        for (Item item : COLORS.keySet()) {
            var id = net.minecraft.core.registries.BuiltInRegistries.ITEM.getKey(item);
            var location = new net.minecraft.client.resources.model.ModelResourceLocation(id, "inventory");
            event.getModels().computeIfPresent(location, (key, model) -> wrap(model, null));
        }
    }

    private static net.minecraft.client.resources.model.BakedModel wrap(net.minecraft.client.resources.model.BakedModel model, ItemStack stack) {
        if (model == null)
            return null;
        while (model instanceof Model tinted) model = tinted.original();
        return new Model(model, stack);
    }

    /**
     * Native item passes supply the stack before quads are submitted to any foil/depth buffer.
     */
    private static final class Model extends net.minecraftforge.client.model.BakedModelWrapper<net.minecraft.client.resources.model.BakedModel> {

        private final ItemStack stack;

        private Model(net.minecraft.client.resources.model.BakedModel model, ItemStack stack) {
            super(model);
            this.stack = stack;
        }

        private net.minecraft.client.resources.model.BakedModel original() {
            return originalModel;
        }

        @Override
        public net.minecraft.client.renderer.block.model.ItemOverrides getOverrides() {
            var overrides = originalModel.getOverrides();
            return new net.minecraft.client.renderer.block.model.ItemOverrides() {

                @Override
                public net.minecraft.client.resources.model.BakedModel resolve(net.minecraft.client.resources.model.BakedModel model, ItemStack item, net.minecraft.client.multiplayer.ClientLevel level, net.minecraft.world.entity.LivingEntity entity, int seed) {
                    return wrap(overrides.resolve(originalModel, item, level, entity, seed), item);
                }

                @Override
                public com.google.common.collect.ImmutableList<net.minecraft.client.renderer.block.model.ItemOverrides.BakedOverride> getOverrides() {
                    return overrides.getOverrides();
                }
            };
        }

        @Override
        public net.minecraft.client.resources.model.BakedModel applyTransform(net.minecraft.world.item.ItemDisplayContext context, com.mojang.blaze3d.vertex.PoseStack pose, boolean leftHand) {
            return wrap(originalModel.applyTransform(context, pose, leftHand), stack);
        }

        @Override
        public java.util.List<net.minecraft.client.resources.model.BakedModel> getRenderPasses(ItemStack item, boolean fabulous) {
            var passes = originalModel.getRenderPasses(item, fabulous);
            if (!COLORS.containsKey(item.getItem()))
                return passes;
            return passes.stream().map(pass -> wrap(pass, item)).toList();
        }

        @Override
        public java.util.List<BakedQuad> getQuads(net.minecraft.world.level.block.state.BlockState state, net.minecraft.core.Direction side, net.minecraft.util.RandomSource random) {
            return (switch(0) {
                default ->
                    {
                        java.util.List<net.minecraft.client.renderer.block.model.BakedQuad> native$bodyOperand$5160 = originalModel.getQuads(state, side, random);
                        java.util.List<net.minecraft.client.renderer.block.model.BakedQuad> native$bodyResult$5169 = null;
                        native$bodyReturn$5170: {
                            if (true) {
                                if (stack == null) {
                                    native$bodyResult$5169 = native$bodyOperand$5160;
                                    break native$bodyReturn$5170;
                                }
                                var native$bodyBinding$5161 = new java.util.ArrayList<net.minecraft.client.renderer.block.model.BakedQuad>(native$bodyOperand$5160.size());
                                for (var native$bodyBinding$5162 : native$bodyOperand$5160) {
                                    float native$bodyBinding$5163 = alpha(stack, native$bodyBinding$5162);
                                    // Hidden layers emit no geometry, including foil and depth.
                                    if (native$bodyBinding$5163 <= 0.0F)
                                        continue;
                                    if (native$bodyBinding$5163 >= 1.0F) {
                                        native$bodyBinding$5161.add(native$bodyBinding$5162);
                                        continue;
                                    }
                                    int[] native$bodyBinding$5164 = native$bodyBinding$5162.getVertices().clone();
                                    int native$bodyBinding$5165 = com.mojang.blaze3d.vertex.DefaultVertexFormat.BLOCK.getIntegerSize();
                                    for (int native$bodyBinding$5166 = 0; native$bodyBinding$5166 < native$bodyBinding$5164.length; native$bodyBinding$5166 += native$bodyBinding$5165) {
                                        int native$bodyBinding$5167 = native$bodyBinding$5164[native$bodyBinding$5166 + 3];
                                        int native$bodyBinding$5168 = (int) (255.0F * (native$bodyBinding$5163 * ((native$bodyBinding$5167 >>> 24) / 255.0F)));
                                        native$bodyBinding$5164[native$bodyBinding$5166 + 3] = (native$bodyBinding$5167 & 0x00FFFFFF) | (native$bodyBinding$5168 << 24);
                                    }
                                    native$bodyBinding$5161.add(new net.minecraft.client.renderer.block.model.BakedQuad(native$bodyBinding$5164, native$bodyBinding$5162.getTintIndex(), native$bodyBinding$5162.getDirection(), native$bodyBinding$5162.getSprite(), native$bodyBinding$5162.isShade(), native$bodyBinding$5162.hasAmbientOcclusion()));
                                }
                                {
                                    native$bodyResult$5169 = native$bodyBinding$5161;
                                    break native$bodyReturn$5170;
                                }
                            }
                        }
                        yield native$bodyResult$5169;
                    }
            });
        }

        @Override
        public java.util.List<BakedQuad> getQuads(net.minecraft.world.level.block.state.BlockState state, net.minecraft.core.Direction side, net.minecraft.util.RandomSource random, net.minecraftforge.client.model.data.ModelData data, net.minecraft.client.renderer.RenderType type) {
            return (switch(0) {
                default ->
                    {
                        java.util.List<net.minecraft.client.renderer.block.model.BakedQuad> native$bodyOperand$5171 = originalModel.getQuads(state, side, random, data, type);
                        java.util.List<net.minecraft.client.renderer.block.model.BakedQuad> native$bodyResult$5180 = null;
                        native$bodyReturn$5181: {
                            if (true) {
                                if (stack == null) {
                                    native$bodyResult$5180 = native$bodyOperand$5171;
                                    break native$bodyReturn$5181;
                                }
                                var native$bodyBinding$5172 = new java.util.ArrayList<net.minecraft.client.renderer.block.model.BakedQuad>(native$bodyOperand$5171.size());
                                for (var native$bodyBinding$5173 : native$bodyOperand$5171) {
                                    float native$bodyBinding$5174 = alpha(stack, native$bodyBinding$5173);
                                    // Hidden layers emit no geometry, including foil and depth.
                                    if (native$bodyBinding$5174 <= 0.0F)
                                        continue;
                                    if (native$bodyBinding$5174 >= 1.0F) {
                                        native$bodyBinding$5172.add(native$bodyBinding$5173);
                                        continue;
                                    }
                                    int[] native$bodyBinding$5175 = native$bodyBinding$5173.getVertices().clone();
                                    int native$bodyBinding$5176 = com.mojang.blaze3d.vertex.DefaultVertexFormat.BLOCK.getIntegerSize();
                                    for (int native$bodyBinding$5177 = 0; native$bodyBinding$5177 < native$bodyBinding$5175.length; native$bodyBinding$5177 += native$bodyBinding$5176) {
                                        int native$bodyBinding$5178 = native$bodyBinding$5175[native$bodyBinding$5177 + 3];
                                        int native$bodyBinding$5179 = (int) (255.0F * (native$bodyBinding$5174 * ((native$bodyBinding$5178 >>> 24) / 255.0F)));
                                        native$bodyBinding$5175[native$bodyBinding$5177 + 3] = (native$bodyBinding$5178 & 0x00FFFFFF) | (native$bodyBinding$5179 << 24);
                                    }
                                    native$bodyBinding$5172.add(new net.minecraft.client.renderer.block.model.BakedQuad(native$bodyBinding$5175, native$bodyBinding$5173.getTintIndex(), native$bodyBinding$5173.getDirection(), native$bodyBinding$5173.getSprite(), native$bodyBinding$5173.isShade(), native$bodyBinding$5173.hasAmbientOcclusion()));
                                }
                                {
                                    native$bodyResult$5180 = native$bodyBinding$5172;
                                    break native$bodyReturn$5181;
                                }
                            }
                        }
                        yield native$bodyResult$5180;
                    }
            });
        }

        private java.util.List<BakedQuad> tint(java.util.List<BakedQuad> quads) {
            if (stack == null)
                return quads;
            var result = new java.util.ArrayList<net.minecraft.client.renderer.block.model.BakedQuad>(quads.size());
            for (var quad : quads) {
                float alpha = alpha(stack, quad);
                // Hidden layers emit no geometry, including foil and depth.
                if (alpha <= 0.0F)
                    continue;
                if (alpha >= 1.0F) {
                    result.add(quad);
                    continue;
                }
                int[] vertices = quad.getVertices().clone();
                int stride = com.mojang.blaze3d.vertex.DefaultVertexFormat.BLOCK.getIntegerSize();
                for (int vertex = 0; vertex < vertices.length; vertex += stride) {
                    int color = vertices[vertex + 3];
                    int opacity = (int) (255.0F * (alpha * ((color >>> 24) / 255.0F)));
                    vertices[vertex + 3] = (color & 0x00FFFFFF) | (opacity << 24);
                }
                result.add(new net.minecraft.client.renderer.block.model.BakedQuad(vertices, quad.getTintIndex(), quad.getDirection(), quad.getSprite(), quad.isShade(), quad.hasAmbientOcclusion()));
            }
            return result;
        }
    }
}
