package dev.tc4port.thaumcraft.api.research;

import java.net.URI;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

/**
 * Data-only client page contributed by a synchronized research definition.
 */
public record ResearchClientPage(Type type, String translationKey, Optional<URI> externalLink, List<ResearchTextFragment> text, ResearchPagePlacement placement) {

    public ResearchClientPage {
        type = Objects.requireNonNull(type, "type");
        translationKey = Objects.requireNonNull(translationKey, "translationKey");
        if (translationKey.isBlank() || translationKey.length() > 256) {
            throw new IllegalArgumentException("Research presentation key must be 1..256 characters");
        }
        externalLink = Objects.requireNonNull(externalLink, "externalLink");
        if ((type == Type.EXTERNAL_LINK) != externalLink.isPresent()) {
            throw new IllegalArgumentException("External-link pages require exactly one URI");
        }
        externalLink.ifPresent(ResearchClientPage::requireHttps);
        text = List.copyOf(text);
        if (text.isEmpty())
            text = List.of(new ResearchTextFragment(translationKey, ResearchTextFragment.Join.NONE));
        Objects.requireNonNull(placement, "placement");
        if (type == Type.EXTERNAL_LINK && placement.mode() == ResearchPagePlacement.Mode.FLOW) {
            throw new IllegalArgumentException("External-link pages cannot use FLOW placement");
        }
        if (text.size() > 1024)
            throw new IllegalArgumentException("Too many research text fragments");
    }

    public ResearchClientPage(Type type, String translationKey, Optional<URI> externalLink) {
        this(type, translationKey, externalLink, List.of(new ResearchTextFragment(translationKey, ResearchTextFragment.Join.NONE)), ResearchPagePlacement.ordered());
    }

    private static void requireHttps(URI uri) {
        if (!"https".equalsIgnoreCase(uri.getScheme()) || uri.getHost() == null || uri.getHost().isBlank() || uri.getUserInfo() != null || uri.toASCIIString().length() > 2048) {
            throw new IllegalArgumentException("Research external links must be bounded HTTPS URIs");
        }
    }

    public enum Type {

        LORE, EXTERNAL_LINK
    }
}
