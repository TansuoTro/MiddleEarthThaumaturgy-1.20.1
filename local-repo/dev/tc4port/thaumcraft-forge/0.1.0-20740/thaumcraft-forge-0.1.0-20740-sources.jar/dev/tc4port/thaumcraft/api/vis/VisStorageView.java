package dev.tc4port.thaumcraft.api.vis;

import dev.tc4port.thaumcraft.api.aspect.VisChannel;
import java.util.Collections;
import java.util.EnumMap;
import java.util.Map;
import java.util.Objects;

/**
 * Immutable snapshot of one addon-owned Vis container.
 */
public record VisStorageView(Map<VisChannel, Integer> currentCentivis, Map<VisChannel, Integer> capacityCentivis, long version) {

    public VisStorageView {
        if (version < 0) {
            throw new IllegalArgumentException("version must be non-negative");
        }
        currentCentivis = checked(currentCentivis, "currentCentivis");
        capacityCentivis = checked(capacityCentivis, "capacityCentivis");
        for (VisChannel channel : VisChannel.values()) {
            if (currentCentivis.getOrDefault(channel, 0) > capacityCentivis.getOrDefault(channel, 0)) {
                throw new IllegalArgumentException("Current Vis exceeds capacity: " + channel);
            }
        }
    }

    private static Map<VisChannel, Integer> checked(Map<VisChannel, Integer> values, String name) {
        Objects.requireNonNull(values, name);
        EnumMap<VisChannel, Integer> result = new EnumMap<>(VisChannel.class);
        values.forEach((channel, amount) -> {
            Objects.requireNonNull(channel, "channel");
            if (amount == null || amount < 0) {
                throw new IllegalArgumentException(name + " must be non-negative");
            }
            result.put(channel, amount);
        });
        return Collections.unmodifiableMap(result);
    }
}
