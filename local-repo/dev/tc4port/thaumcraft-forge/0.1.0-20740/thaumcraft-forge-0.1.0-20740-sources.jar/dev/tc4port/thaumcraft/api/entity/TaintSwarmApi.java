package dev.tc4port.thaumcraft.api.entity;

import dev.tc4port.thaumcraft.entity.TaintSwarmEntity;
import dev.tc4port.thaumcraft.registry.TCEntities;
import java.util.Objects;
import java.util.Optional;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;

/**
 * Controlled factory for the summoned swarm behavior used by addons.
 */
public final class TaintSwarmApi {

    public static final int MIN_ATTACK_DAMAGE = 2;

    /**
     * Native ATTACK_DAMAGE upper bound, shared by both supported targets.
     */
    public static final int MAX_ATTACK_DAMAGE = 2048;

    private TaintSwarmApi() {
    }

    /**
     * Creates, configures and spawns one summoned swarm at the caster's wand
     * origin. The server derives all ownership, position and target state;
     * invalid, unloaded, cross-level and PvP-disallowed requests are pure and
     * return an empty value. The returned entity is exposed only as the
     * vanilla {@link LivingEntity} contract.
     */
    public static Optional<LivingEntity> spawnSummoned(ServerPlayer summoner, LivingEntity target, int attackDamage) {
        return spawnSummoned(summoner, InteractionHand.MAIN_HAND, target, attackDamage);
    }

    /**
     * Hand-aware form that launches from Thaumcraft's shared wand-tip origin.
     */
    public static Optional<LivingEntity> spawnSummoned(ServerPlayer summoner, InteractionHand hand, LivingEntity target, int attackDamage) {
        Objects.requireNonNull(summoner, "summoner");
        Objects.requireNonNull(hand, "hand");
        Objects.requireNonNull(target, "target");
        if (!summoner.server.isSameThread() || attackDamage < MIN_ATTACK_DAMAGE || attackDamage > MAX_ATTACK_DAMAGE || !summoner.isAlive() || !target.isAlive() || target == summoner || target.level() != summoner.level() || !target.isAttackable() || target instanceof Player playerTarget && (playerTarget.isCreative() || playerTarget.isSpectator() || !summoner.canHarmPlayer(playerTarget))) {
            return Optional.empty();
        }
        ServerLevel level = summoner.serverLevel();
        Vec3 position = dev.tc4port.thaumcraft.common.WandCastOrigin.focusTip(summoner, hand);
        BlockPos spawnPos = BlockPos.containing(position);
        if (!level.hasChunkAt(spawnPos) || !level.hasChunkAt(target.blockPosition()) || level.isOutsideBuildHeight(spawnPos) || !level.getWorldBorder().isWithinBounds(spawnPos)) {
            return Optional.empty();
        }
        TaintSwarmEntity swarm = TCEntities.TAINT_SWARM.get().create(level);
        if (swarm == null) {
            return Optional.empty();
        }
        swarm.moveTo(position.x, position.y, position.z, summoner.getYRot(), summoner.getXRot());
        swarm.setDamageBonus(attackDamage - MIN_ATTACK_DAMAGE);
        swarm.setTarget(target);
        swarm.setSummoned(true);
        swarm.setFocusDamageModifiers(dev.tc4port.thaumcraft.api.focus.FocusDamageModifiers.capture(summoner));
        if (!level.addFreshEntity(swarm)) {
            return Optional.empty();
        }
        return Optional.of(swarm);
    }
}
