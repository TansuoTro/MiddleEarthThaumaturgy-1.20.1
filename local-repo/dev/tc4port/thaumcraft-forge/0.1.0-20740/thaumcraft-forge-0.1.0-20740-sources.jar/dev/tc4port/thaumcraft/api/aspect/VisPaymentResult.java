package dev.tc4port.thaumcraft.api.aspect;

/**
 * Separates affordability prediction from an authoritative mutation.
 */
public record VisPaymentResult(boolean affordable, boolean consumed) {

    public static final VisPaymentResult UNAVAILABLE = new VisPaymentResult(false, false);

    public static final VisPaymentResult AVAILABLE = new VisPaymentResult(true, false);

    public static final VisPaymentResult CONSUMED = new VisPaymentResult(true, true);

    public VisPaymentResult {
        if (consumed && !affordable) {
            throw new IllegalArgumentException("Consumed vis must also have been affordable");
        }
    }
}
