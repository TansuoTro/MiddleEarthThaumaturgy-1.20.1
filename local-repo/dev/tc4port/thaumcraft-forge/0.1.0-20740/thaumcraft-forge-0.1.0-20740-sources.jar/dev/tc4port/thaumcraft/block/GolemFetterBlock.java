package dev.tc4port.thaumcraft.block;

import com.mojang.serialization.MapCodec;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.RandomSource;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import dev.tc4port.thaumcraft.nativeimpl.ClientExtensionTarget;
import dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.level.pathfinder.PathComputationType;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.level.Explosion;
import net.minecraft.world.level.BlockGetter;

/**
 * Immobilises a golem standing on it while its powered state is set.
 *
 * <p>BlockCosmeticSolid encoded the two halves of this switch as metadata
 * nine and ten, which this port first mapped to a block identity each. The
 * switch is one block state, so it is modelled as one: a powered property
 * updated the way the vanilla redstone lamp updates its own, with the
 * off-delay that keeps a one-tick pulse from flickering the block.</p>
 *
 * <p>This property is the authority on whether a golem is held. It is what
 * the block looks like, what the save keeps, and what the golem reads, so an
 * update-suppressed fetter behaves exactly as it appears; suppression is a
 * redstone technique, not a state worth second-guessing from the live
 * signal. The scheduled switch off persists with the chunk, so a pending
 * one lands after a reload rather than being lost.</p>
 */
public final class GolemFetterBlock extends net.minecraft.world.level.block.Block implements dev.tc4port.thaumcraft.nativeimpl.ClientExtensionTarget {

    // Forge calls initializeClient from the native superclass constructor. Do not add a field initializer.
    private java.util.function.Consumer<net.minecraftforge.client.extensions.common.IClientBlockExtensions> platform$clientInstaller;

    public static final BooleanProperty POWERED = BlockStateProperties.POWERED;

    private static final int OFF_DELAY_TICKS = 4;

    private static final MapCodec<GolemFetterBlock> CODEC = GolemFetterBlock.native$BlockCodecPlatform$simple(GolemFetterBlock::new);

    public GolemFetterBlock(BlockBehaviour.Properties properties) {
        this(properties, properties, true);
    }

    protected MapCodec<GolemFetterBlock> codec() {
        return CODEC;
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(POWERED);
    }

    @Override
    public BlockState getStateForPlacement(BlockPlaceContext context) {
        return this.defaultBlockState().setValue(POWERED, context.getLevel().hasChunksAt(context.getClickedPos().offset(-2, 0, -2), context.getClickedPos().offset(2, 0, 2)) && context.getLevel().hasNeighborSignal(context.getClickedPos()));
    }

    @Override
    public void neighborChanged(BlockState state, Level level, BlockPos pos, Block neighborBlock, BlockPos neighborPos, boolean movedByPiston) {
        super.neighborChanged(state, level, pos, neighborBlock, neighborPos, movedByPiston);
        if (level.isClientSide || !level.hasChunksAt(pos.offset(-2, 0, -2), pos.offset(2, 0, 2))) {
            return;
        }
        boolean powered = state.getValue(POWERED);
        if (powered == level.hasNeighborSignal(pos)) {
            return;
        }
        if (powered) {
            level.scheduleTick(pos, this, OFF_DELAY_TICKS);
        } else {
            level.setBlock(pos, state.setValue(POWERED, true), Block.UPDATE_CLIENTS);
        }
    }

    @Override
    public void tick(BlockState state, ServerLevel level, BlockPos pos, RandomSource random) {
        if (!level.hasChunksAt(pos.offset(-2, 0, -2), pos.offset(2, 0, 2))) {
            level.scheduleTick(pos, this, OFF_DELAY_TICKS);
            return;
        }
        if (state.getValue(POWERED) && !level.hasNeighborSignal(pos)) {
            level.setBlock(pos, state.setValue(POWERED, false), Block.UPDATE_CLIENTS);
        }
    }

    private GolemFetterBlock(net.minecraft.world.level.block.state.BlockBehaviour.Properties native$NativeBlock$arg0, BlockBehaviour.Properties properties, boolean native$NativeBlock$captured) {
        super(native$NativeBlock$arg0);
        this.registerDefaultState(this.stateDefinition.any().setValue(POWERED, false));
    }

    @Override
    public void initializeClient(java.util.function.Consumer<net.minecraftforge.client.extensions.common.IClientBlockExtensions> installer) {
        platform$clientInstaller = installer;
        super.initializeClient(installer);
    }

    @Override
    public void platform$clientExtension(Object extension) {
        java.util.Objects.requireNonNull(platform$clientInstaller, "Forge initializeClient must run before client extension registration").accept((net.minecraftforge.client.extensions.common.IClientBlockExtensions) extension);
    }

    @Override
    public InteractionResult use(BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
        ItemUseResult result = (switch(0) {
            default ->
                {
                    net.minecraft.world.item.ItemStack native$bodyOperand$4474 = player.getItemInHand(hand);
                    net.minecraft.world.level.block.state.BlockState native$bodyOperand$4475 = state;
                    net.minecraft.world.level.Level native$bodyOperand$4476 = level;
                    net.minecraft.core.BlockPos native$bodyOperand$4477 = pos;
                    net.minecraft.world.entity.player.Player native$bodyOperand$4478 = player;
                    net.minecraft.world.InteractionHand native$bodyOperand$4479 = hand;
                    net.minecraft.world.phys.BlockHitResult native$bodyOperand$4480 = hit;
                    dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult native$bodyResult$4481 = null;
                    native$bodyReturn$4482: {
                        if (true) {
                            {
                                native$bodyResult$4481 = dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
                                break native$bodyReturn$4482;
                            }
                        }
                    }
                    yield native$bodyResult$4481;
                }
        });
        return result == ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION ? (hand == InteractionHand.MAIN_HAND ? (switch(0) {
            default ->
                {
                    net.minecraft.world.level.block.state.BlockState native$bodyOperand$3698 = state;
                    net.minecraft.world.level.Level native$bodyOperand$3699 = level;
                    net.minecraft.core.BlockPos native$bodyOperand$3700 = pos;
                    net.minecraft.world.entity.player.Player native$bodyOperand$3701 = player;
                    net.minecraft.world.phys.BlockHitResult native$bodyOperand$3702 = hit;
                    net.minecraft.world.InteractionResult native$bodyResult$3703 = null;
                    native$bodyReturn$3704: {
                        if (true) {
                            {
                                native$bodyResult$3703 = super.use(native$bodyOperand$3698, native$bodyOperand$3699, native$bodyOperand$3700, native$bodyOperand$3701, net.minecraft.world.InteractionHand.MAIN_HAND, native$bodyOperand$3702);
                                break native$bodyReturn$3704;
                            }
                        }
                    }
                    yield native$bodyResult$3703;
                }
        }) : InteractionResult.PASS) : result.result();
    }

    protected ItemUseResult interactWithItem(ItemStack stack, BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
        return dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
    }

    protected InteractionResult interactWithoutItem(BlockState state, Level level, BlockPos pos, Player player, BlockHitResult hit) {
        return super.use(state, level, pos, player, net.minecraft.world.InteractionHand.MAIN_HAND, hit);
    }

    @Override
    public void playerWillDestroy(Level level, BlockPos pos, BlockState state, Player player) {
        {
            net.minecraft.world.level.Level native$bodyOperand$5859 = level;
            net.minecraft.core.BlockPos native$bodyOperand$5860 = pos;
            net.minecraft.world.level.block.state.BlockState native$bodyOperand$5861 = state;
            net.minecraft.world.entity.player.Player native$bodyOperand$5862 = player;
            net.minecraft.world.level.block.state.BlockState native$bodyResult$5863 = null;
            native$bodyReturn$5864: {
                if (true) {
                    super.playerWillDestroy(native$bodyOperand$5859, native$bodyOperand$5860, native$bodyOperand$5861, native$bodyOperand$5862);
                    {
                        native$bodyResult$5863 = native$bodyOperand$5861;
                        break native$bodyReturn$5864;
                    }
                }
            }
        }
    }

    public BlockState beforePlayerDestroy(Level level, BlockPos pos, BlockState state, Player player) {
        super.playerWillDestroy(level, pos, state, player);
        return state;
    }

    protected boolean survivesSharedExplosion() {
        return false;
    }

    public int getExpDrop(net.minecraft.world.level.block.state.BlockState native$callbackInput$1145, net.minecraft.world.level.LevelReader native$callbackInput$1146, net.minecraft.util.RandomSource native$callbackInput$1147, net.minecraft.core.BlockPos native$callbackInput$1148, int native$callbackInput$1149, int native$callbackInput$1150) {
        net.minecraft.world.level.block.state.BlockState state = native$callbackInput$1145;
        net.minecraft.util.RandomSource random = native$callbackInput$1147;
        return 0;
    }

    @Override
    public void onBlockExploded(BlockState state, Level level, BlockPos pos, Explosion explosion) {
        if (!(switch(0) {
            default ->
                {
                    boolean native$bodyResult$5273 = false;
                    native$bodyReturn$5274: {
                        if (true) {
                            {
                                native$bodyResult$5273 = false;
                                break native$bodyReturn$5274;
                            }
                        }
                    }
                    yield native$bodyResult$5273;
                }
        }))
            super.onBlockExploded(state, level, pos, explosion);
    }

    @Override
    public boolean canDropFromExplosion(BlockState state, BlockGetter level, BlockPos pos, Explosion explosion) {
        return !(switch(0) {
            default ->
                {
                    boolean native$bodyResult$4483 = false;
                    native$bodyReturn$4484: {
                        if (true) {
                            {
                                native$bodyResult$4483 = false;
                                break native$bodyReturn$4484;
                            }
                        }
                    }
                    yield native$bodyResult$4483;
                }
        }) && super.canDropFromExplosion(state, level, pos, explosion);
    }

    static private <B extends net.minecraft.world.level.block.Block> com.mojang.serialization.MapCodec<B> native$BlockCodecPlatform$simple(java.util.function.Function<net.minecraft.world.level.block.state.BlockBehaviour.Properties, B> factory) {
        // Vanilla 1.21's Properties codec is a unit codec. Retain that schema for shared block definitions.
        return com.mojang.serialization.codecs.RecordCodecBuilder.mapCodec(instance -> instance.group(com.mojang.serialization.Codec.unit(net.minecraft.world.level.block.state.BlockBehaviour.Properties::of).fieldOf("properties").forGetter((B block) -> net.minecraft.world.level.block.state.BlockBehaviour.Properties.copy(block))).apply(instance, factory));
    }
}
