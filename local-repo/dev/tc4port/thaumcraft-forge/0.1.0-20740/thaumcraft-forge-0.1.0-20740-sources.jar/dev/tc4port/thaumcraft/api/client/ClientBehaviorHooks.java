package dev.tc4port.thaumcraft.api.client;

import dev.tc4port.thaumcraft.api.player.FlightAccess;
import dev.tc4port.thaumcraft.api.event.OrderedCallbacks;
import java.util.function.BiConsumer;
import java.util.function.BiPredicate;
import java.util.function.Predicate;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.HumanoidArm;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.biome.Biome;

/**
 * Value folds and notifications run in priority order; render permissions combine with AND.
 */
public final class ClientBehaviorHooks {

    public interface BiomeColor {

        int apply(Biome biome, boolean foliage, double x, double z, int current);
    }

    public interface HandLayer {

        boolean allow(LivingEntity entity, ItemStack stack, ItemDisplayContext display, HumanoidArm arm);
    }

    public static final OrderedCallbacks<Predicate<AbstractClientPlayer>> CAPE = new OrderedCallbacks<>();

    public static final OrderedCallbacks<BiomeColor> BIOME_COLOR = new OrderedCallbacks<>();

    public static final OrderedCallbacks<BiConsumer<HumanoidModel<?>, LivingEntity>> HUMANOID_POSE = new OrderedCallbacks<>();

    public static final OrderedCallbacks<HandLayer> HAND_LAYER = new OrderedCallbacks<>();

    public static final OrderedCallbacks<BiPredicate<Player, InteractionHand>> EQUIP_RESET = new OrderedCallbacks<>();

    /**
     * Opt-ins retain active flight through landing and the double-jump toggle; they never start flight.
     */
    public static final OrderedCallbacks<Predicate<Player>> CONTINUOUS_FLIGHT = new OrderedCallbacks<>();

    public static final OrderedCallbacks<Runnable> BEFORE_DRAW = new OrderedCallbacks<>();

    private ClientBehaviorHooks() {
    }

    public static boolean allowCape(AbstractClientPlayer player) {
        for (Predicate<AbstractClientPlayer> callback : CAPE.values()) if (!callback.test(player))
            return false;
        return true;
    }

    public static int biomeColor(Biome biome, boolean foliage, double x, double z, int color) {
        for (BiomeColor callback : BIOME_COLOR.values()) color = callback.apply(biome, foliage, x, z, color);
        return color;
    }

    public static void pose(HumanoidModel<?> model, LivingEntity entity) {
        for (BiConsumer<HumanoidModel<?>, LivingEntity> callback : HUMANOID_POSE.values()) callback.accept(model, entity);
    }

    public static boolean allowHand(LivingEntity entity, ItemStack stack, ItemDisplayContext display, HumanoidArm arm) {
        for (HandLayer callback : HAND_LAYER.values()) if (!callback.allow(entity, stack, display, arm))
            return false;
        return true;
    }

    public static boolean allowEquipReset(Player player, InteractionHand hand) {
        for (BiPredicate<Player, InteractionHand> callback : EQUIP_RESET.values()) if (!callback.test(player, hand))
            return false;
        return true;
    }

    public static boolean continuousFlight(Player player) {
        // Abilities, attributes and equipment arrive separately. An old opt-in and
        // flight permission must not undo a newer server instruction to stop flying.
        if (!player.getAbilities().flying || !FlightAccess.mayFly(player))
            return false;
        for (Predicate<Player> callback : CONTINUOUS_FLIGHT.values()) if (callback.test(player))
            return true;
        return false;
    }

    public static void beforeDraw() {
        for (Runnable callback : BEFORE_DRAW.values()) callback.run();
    }
}
