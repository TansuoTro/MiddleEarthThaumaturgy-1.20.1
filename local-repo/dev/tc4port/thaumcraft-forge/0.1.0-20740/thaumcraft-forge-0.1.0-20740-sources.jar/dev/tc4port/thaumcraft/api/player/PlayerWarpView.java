package dev.tc4port.thaumcraft.api.player;

/**
 * Immutable projection of the synchronized TC4 player-Warp attachment.
 */
public record PlayerWarpView(int permanent, int sticky, int temporary) {

    public PlayerWarpView {
        if (permanent < 0 || sticky < 0 || temporary < 0) {
            throw new IllegalArgumentException("Warp values cannot be negative");
        }
    }

    /**
     * Returns the lossless sum of all three non-negative Warp pools.
     */
    public long total() {
        return (long) permanent + sticky + temporary;
    }
}
