package dev.tc4port.thaumcraft.api.aspect;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Objects;

/**
 * Immutable validated quantities keyed by public aspect identity.
 */
public record AspectAmounts(Map<AspectId, Integer> amounts) {

    public static final AspectAmounts EMPTY = new AspectAmounts(Map.of());

    public AspectAmounts {
        Objects.requireNonNull(amounts, "amounts");
        LinkedHashMap<AspectId, Integer> checked = new LinkedHashMap<>();
        amounts.forEach((id, amount) -> {
            Objects.requireNonNull(id, "aspect id");
            Objects.requireNonNull(amount, "aspect amount");
            if (amount < 0) {
                throw new IllegalArgumentException("Aspect amounts must be non-negative: " + id);
            }
            if (amount > 0) {
                checked.merge(id, amount, Math::addExact);
            }
        });
        amounts = Collections.unmodifiableMap(checked);
    }

    public static AspectAmounts of(AspectId id, int amount) {
        return new AspectAmounts(Map.of(id, amount));
    }

    public int amount(AspectId id) {
        return this.amounts.getOrDefault(Objects.requireNonNull(id, "id"), 0);
    }
}
