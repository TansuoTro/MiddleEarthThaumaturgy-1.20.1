package dev.tc4port.thaumcraft.api.client;

import dev.tc4port.thaumcraft.Thaumcraft;
import dev.tc4port.thaumcraft.client.EssentiaTrailParticle;
import dev.tc4port.thaumcraft.client.ChampionGenericParticle;
import dev.tc4port.thaumcraft.client.FollowingFallingWispParticle;
import dev.tc4port.thaumcraft.client.InfusionSparkleEffects;
import dev.tc4port.thaumcraft.client.PaletteWispParticle;
import dev.tc4port.thaumcraft.client.RunedStoneRuneParticleAccess;
import dev.tc4port.thaumcraft.client.SmokeSpiralParticleAccess;
import dev.tc4port.thaumcraft.client.SparkleParticle;
import dev.tc4port.thaumcraft.client.WispBurstParticle;
import dev.tc4port.thaumcraft.client.WispMoteParticle;
import dev.tc4port.thaumcraft.client.WispLightningEffect;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.core.BlockPos;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.entity.Entity;

/**
 * Stable client-only access to reusable Thaumcraft visual primitives.
 * Invalid requests are skipped and warned once per validation reason.
 * Requests for a world other than the client's current world are ignored.
 */
public final class ThaumcraftClientEffectsApi {

    public static final double MAX_TRAIL_DISTANCE = 256.0;

    public static final double MAX_EFFECT_DISTANCE = 256.0;

    public static final double MAX_EFFECT_SPEED = 16.0;

    public static final float MAX_WISP_SIZE = 1024.0F;

    /**
     * Includes TC4 addon effects such as Thaumic Tinkerer's scale-20
     * necromancy trail while still bounding malformed client input.
     */
    public static final float MAX_TRAIL_SCALE = 64.0F;

    private static final Set<String> WARNED_INVALID_REQUESTS = ConcurrentHashMap.newKeySet();

    private ThaumcraftClientEffectsApi() {
    }

    public static void spawnEssentiaTrail(ClientLevel level, Vec3 source, Vec3 target, int phase, int color, float scale) {
        if (!currentLevel(level) || !finite(source) || !finite(target)) {
            reject("Essentia trail level and finite positions are required");
            return;
        }
        if (!Float.isFinite(scale) || scale <= 0.0F || scale > MAX_TRAIL_SCALE) {
            reject("Essentia trail scale must be positive, finite, and no " + "greater than " + MAX_TRAIL_SCALE);
            return;
        }
        if (source.distanceToSqr(target) > MAX_TRAIL_DISTANCE * MAX_TRAIL_DISTANCE) {
            reject("Essentia trail distance must be no greater than " + MAX_TRAIL_DISTANCE);
            return;
        }
        EssentiaTrailParticle.spawn(level, source, target, phase, color & 0xFFFFFF, scale);
    }

    public static void spawnSparkle(ClientLevel level, Vec3 position, Vec3 target, float size, int colorType, int multiplier, float gravity, boolean noClip) {
        if (!validateEffect(level, position, target, size, colorType) || !validateGravity(gravity) || !validateDistance(position, target))
            return;
        if (multiplier < 1 || multiplier > 400) {
            reject("Sparkle multiplier must be 1..400");
            return;
        }
        SparkleParticle.spawnType(level, position.x, position.y, position.z, target.x, target.y, target.z, size, colorType, multiplier, gravity, noClip);
    }

    public static void spawnDestinationWisp(ClientLevel level, Vec3 position, Vec3 target, float size, int colorType, boolean shrink, float gravity) {
        if (!validateEffect(level, position, target, size, colorType) || !validateGravity(gravity) || !validateDistance(position, target))
            return;
        PaletteWispParticle.spawnDestination(level, position.x, position.y, position.z, target.x, target.y, target.z, size, colorType, shrink, gravity);
    }

    /**
     * ClientProxy sparkle route, including TC4's particle-quality gate.
     */
    public static void spawnQualitySparkle(ClientLevel level, Vec3 position, float size, int colorType, float gravity) {
        /*
         * ClientProxy.sparkle accepted every int. FXSparkle's 0..7 palette
         * switch deliberately fell back to solid red for all other values;
         * legacy addons relied on that behavior despite often passing what
         * looked like a packed RGB value.
         */
        if (!validateEffect(level, position, position, size, 0) || !validateGravity(gravity))
            return;
        SparkleParticle.spawnProxy(level, position.x, position.y, position.z, size, colorType, gravity);
    }

    public static void spawnMovingSparkle(ClientLevel level, Vec3 position, Vec3 velocity, float size, int colorType, int multiplier, float gravity, boolean noClip) {
        if (!validateEffect(level, position, velocity, size, colorType) || !validateGravity(gravity) || !validateSpeed(velocity))
            return;
        if (multiplier < 1 || multiplier > 400) {
            reject("Sparkle multiplier must be 1..400");
            return;
        }
        SparkleParticle.spawnMovingType(level, position.x, position.y, position.z, velocity.x, velocity.y, velocity.z, size, colorType, multiplier, gravity, noClip);
    }

    /**
     * Full fixed-color FXSparkle contract for addon subclasses which changed
     * animation, lifetime or motion flags after construction. Camera fading
     * changes only submitted size/opacity; it never moves or kills the particle.
     */
    public static void spawnCustomSparkle(ClientLevel level, Vec3 position, float size, float red, float green, float blue, int frameInterval, int lifetime, int firstFrame, float gravity, boolean noClip, boolean normalBlend, boolean shrink, boolean slowdown, ParticleCameraFade cameraFade) {
        if (cameraFade == null) {
            reject("Custom sparkle camera fade must not be null");
            return;
        }
        if (!validateEffect(level, position, position, size, 0) || !validateGravity(gravity))
            return;
        if (!finiteColor(red) || !finiteColor(green) || !finiteColor(blue) || frameInterval < 1 || frameInterval > 400 || lifetime < 1 || lifetime > 12_000 || firstFrame < 0 || firstFrame > 3) {
            reject("Invalid custom sparkle parameters");
            return;
        }
        SparkleParticle.spawnCustom(level, position.x, position.y, position.z, size, red, green, blue, frameInterval, lifetime, firstFrame, gravity, noClip, normalBlend, shrink, slowdown, cameraFade);
    }

    /**
     * Direct custom-color ClientProxy.wispFX construction path.
     */
    public static void spawnWispMote(ClientLevel level, Vec3 position, float size, float red, float green, float blue, boolean shrink, float gravity) {
        if (!validateGravity(gravity))
            return;
        if (!currentLevel(level) || !finite(position) || !Float.isFinite(size) || size <= 0.0F || size > MAX_WISP_SIZE || !finiteColor(red) || !finiteColor(green) || !finiteColor(blue)) {
            reject("Invalid wisp mote parameters");
            return;
        }
        WispMoteParticle.spawn(level, position.x, position.y, position.z, size, red, green, blue, shrink, gravity);
    }

    /**
     * Exact ClientProxy.blockSparkle quality and color-jitter route.
     */
    public static void spawnBlockSparkle(ClientLevel level, BlockPos position, int color, int baseCount) {
        if (!currentLevel(level) || position == null || baseCount < 0 || baseCount > 400) {
            reject("Block sparkle requires a level, position and base count of 0..400");
            return;
        }
        InfusionSparkleEffects.blockSparkle(level, position, color, baseCount);
    }

    /**
     * TC4's all/decreased/minimal base*2/base/zero count contract.
     */
    public static int qualityScaledParticleCount(int baseCount) {
        if (baseCount < 0 || baseCount > 400) {
            reject("Particle base count must be 0..400");
            return 0;
        }
        return InfusionSparkleEffects.particleCount(baseCount);
    }

    /**
     * ClientProxy.blockRunes logical coordinates; the proxy adds 0.5 to all
     * three axes before constructing the wall-oriented particle.
     */
    public static void spawnBlockRune(ClientLevel level, Vec3 logicalPosition, float red, float green, float blue, int duration, float gravity) {
        if (!validateEffect(level, logicalPosition, logicalPosition, 0.3F, 0) || !validateGravity(gravity))
            return;
        if (!finiteColor(red) || !finiteColor(green) || !finiteColor(blue) || duration < 1 || duration > 400) {
            reject("Invalid block rune parameters");
            return;
        }
        RunedStoneRuneParticleAccess.spawn(level, logicalPosition.add(0.5, 0.5, 0.5), red, green, blue, duration, gravity);
    }

    public static void spawnMovingWisp(ClientLevel level, Vec3 position, Vec3 velocity, float size, int colorType, boolean shrink, float gravity, boolean noClip) {
        if (!currentLevel(level) || !finite(position) || !finite(velocity) || !Float.isFinite(size) || size < 0.0F || size > 64.0F || colorType < 0 || colorType > 7) {
            reject("Invalid moving wisp parameters");
            return;
        }
        if (!validateGravity(gravity) || !validateSpeed(velocity))
            return;
        PaletteWispParticle.spawnMoving(level, position.x, position.y, position.z, velocity.x, velocity.y, velocity.z, size, colorType, shrink, gravity, noClip);
    }

    public static void spawnFollowingFallingWisp(ClientLevel level, Vec3 position, Entity target) {
        if (!currentLevel(level) || target == null || !finite(position) || target.level() != level || !finite(target.position()) || target.position().distanceToSqr(position) > MAX_EFFECT_DISTANCE * MAX_EFFECT_DISTANCE) {
            reject("Following wisp position must be finite and target must be in level");
            return;
        }
        FollowingFallingWispParticle.spawn(level, position, target);
    }

    public static void spawnBurst(ClientLevel level, Vec3 position, float size) {
        if (!validateEffect(level, position, position, size, 0))
            return;
        WispBurstParticle.spawn(level, position.x, position.y, position.z, size);
    }

    /**
     * Direct source-colored FXSmokeSpiral construction for legacy addons.
     */
    public static void spawnSmokeSpiral(ClientLevel level, Vec3 position, float radius, float startingAngle, double minimumY, int color) {
        if (!validateEffect(level, position, position, radius, 0))
            return;
        if (!Float.isFinite(startingAngle) || !Double.isFinite(minimumY) || Math.abs(minimumY) > 30_000_000.0 || color < 0 || color > 0xFFFFFF) {
            reject("Invalid smoke spiral parameters");
            return;
        }
        SmokeSpiralParticleAccess.spawn(level, position, radius, startingAngle, minimumY, color);
    }

    public static void spawnFocusLightning(ClientLevel level, Vec3 start, Vec3 end) {
        if (!validateEffect(level, start, end, 1.0F, 0) || !validateDistance(start, end))
            return;
        WispLightningEffect.spawnFocusBolt(level, start, end);
    }

    /**
     * Source speed-4, type-2 lightning used by legacy shockwave effects.
     */
    public static void spawnShockLightning(ClientLevel level, Vec3 start, Vec3 end) {
        if (!validateEffect(level, start, end, 1.0F, 0) || !validateDistance(start, end))
            return;
        WispLightningEffect.spawnShockBolt(level, start, end);
    }

    /**
     * Source duration-10, multiplier-4 node lightning used by addon tools.
     */
    public static void spawnNodeLightning(ClientLevel level, Vec3 start, Vec3 end) {
        if (!validateEffect(level, start, end, 1.0F, 0) || !validateDistance(start, end))
            return;
        WispLightningEffect.spawnNodeBolt(level, start, end);
    }

    public static void spawnGenericParticle(ClientLevel level, Vec3 position, Vec3 velocity, float red, float green, float blue, float alpha, boolean loop, int startParticle, int numberOfParticles, int particleIncrement, int maximumAge, int delay, float scale) {
        if (!validateEffect(level, position, velocity, scale, 0) || !validateSpeed(velocity))
            return;
        if (startParticle < 0 || startParticle > 255 || numberOfParticles < 1 || numberOfParticles > 256 || startParticle + numberOfParticles > 256 || particleIncrement < 1 || particleIncrement > 256 || maximumAge < 1 || maximumAge > 12_000 || delay < 0 || delay > 12_000 || !finiteColor(red) || !finiteColor(green) || !finiteColor(blue) || !finiteColor(alpha)) {
            reject("Invalid generic particle parameters");
            return;
        }
        ChampionGenericParticle.spawn(level, position.x, position.y, position.z, velocity.x, velocity.y, velocity.z, red, green, blue, alpha, loop, startParticle, numberOfParticles, particleIncrement, maximumAge, delay, scale);
    }

    /**
     * Client lookup. Server emitters can use ThaumcraftParticle.type() without client classes.
     */
    public static net.minecraft.core.particles.SimpleParticleType particleType(ThaumcraftParticle particle) {
        java.util.Objects.requireNonNull(particle, "particle");
        return particle.type();
    }

    /**
     * Native provider dispatch; arguments are NOT universally velocity. See CLIENT_EFFECTS_API.md.
     */
    public static void spawnParticle(ClientLevel level, ThaumcraftParticle particle, Vec3 position, Vec3 arguments) {
        if (!currentLevel(level) || !finite(position) || !finite(arguments)) {
            reject("Particle level and finite provider arguments are required");
            return;
        }
        if (!validProviderArguments(particle, position, arguments)) {
            reject("Invalid provider arguments; use the matching named particle method");
            return;
        }
        level.addParticle(particleType(particle), position.x, position.y, position.z, arguments.x, arguments.y, arguments.z);
    }

    public static void spawnBeam(ClientLevel level, Vec3 start, Vec3 end, BeamSettings settings) {
        java.util.Objects.requireNonNull(settings, "settings");
        if (validAttraction(level, start, end)) {
            dev.tc4port.thaumcraft.client.CoordinateBeamEffect.spawn(level, start, end, null, settings);
        }
    }

    /**
     * Entity beam follows eye height minus half entity height.
     */
    public static void spawnBeam(ClientLevel level, Vec3 start, Entity target, BeamSettings settings) {
        if (target == null || target.level() != level) {
            return;
        }
        Vec3 end = target.position().add(0, target.getEyeHeight() - target.getBbHeight() / 2.0, 0);
        if (validAttraction(level, start, end)) {
            dev.tc4port.thaumcraft.client.CoordinateBeamEffect.spawn(level, start, end, target, java.util.Objects.requireNonNull(settings, "settings"));
        }
    }

    public static void spawnLightning(ClientLevel level, Vec3 start, Vec3 end, LightningSettings settings) {
        java.util.Objects.requireNonNull(settings, "settings");
        if (validAttraction(level, start, end)) {
            WispLightningEffect.spawnCustom(level, start, end, settings);
        }
    }

    public static void spawnArc(ClientLevel level, Vec3 start, Vec3 end, EffectColor color, float height) {
        java.util.Objects.requireNonNull(color, "color");
        if (validAttraction(level, start, end) && Float.isFinite(height) && Math.abs(height) <= MAX_EFFECT_DISTANCE) {
            dev.tc4port.thaumcraft.client.EldritchArcEffect.spawn(level, start, end, color.red(), color.green(), color.blue(), height);
        }
    }

    public static void spawnSonicWave(net.minecraft.world.entity.LivingEntity source, int baseAge) {
        if (source != null && source.level() instanceof ClientLevel level && currentLevel(level) && baseAge >= 1 && baseAge <= 1200) {
            dev.tc4port.thaumcraft.client.EldritchSonicEffect.spawn(source, baseAge);
        }
    }

    /**
     * Entity-bound hemispherical shield, orientation in degrees.
     */
    public static void spawnShieldRunes(Entity source, float yaw, float pitch) {
        if (source != null && source.level() instanceof ClientLevel level && currentLevel(level) && Float.isFinite(yaw) && Float.isFinite(pitch)) {
            dev.tc4port.thaumcraft.client.ShieldRunesEffect.spawn(level, source, yaw, pitch);
        }
    }

    public static void spawnWardHit(net.minecraft.world.phys.BlockHitResult hit) {
        dev.tc4port.thaumcraft.client.WardHitParticle.spawn(java.util.Objects.requireNonNull(hit));
    }

    public static void spawnInfusionItem(ClientLevel level, Vec3 source, Vec3 target, net.minecraft.world.item.ItemStack stack) {
        if (validAttraction(level, source, target) && stack != null && !stack.isEmpty()) {
            dev.tc4port.thaumcraft.client.AttractionParticleEffects.item(level, source, target, stack.copy());
        }
    }

    public static void spawnInfusionBlock(ClientLevel level, Vec3 source, Vec3 target, net.minecraft.world.level.block.state.BlockState state, BlockPos sourcePos, net.minecraft.core.Direction face) {
        if (validAttraction(level, source, target) && state != null && !state.isAir()) {
            dev.tc4port.thaumcraft.client.AttractionParticleEffects.block(level, source, target, state, java.util.Objects.requireNonNull(sourcePos), java.util.Objects.requireNonNull(face), false);
        }
    }

    public static void spawnHungryNodeFragment(ClientLevel level, Vec3 source, Vec3 target, net.minecraft.world.level.block.state.BlockState state, BlockPos sourcePos, net.minecraft.core.Direction face) {
        if (validAttraction(level, source, target) && state != null && !state.isAir()) {
            dev.tc4port.thaumcraft.client.AttractionParticleEffects.block(level, source, target, state, java.util.Objects.requireNonNull(sourcePos), java.util.Objects.requireNonNull(face), true);
        }
    }

    /**
     * Supplier returns a current world-space endpoint on each client tick.
     */
    public static void spawnBoreFragment(ClientLevel level, Vec3 source, Vec3 lifetimeTarget, java.util.function.Supplier<Vec3> target, net.minecraft.world.level.block.state.BlockState state, BlockPos sourcePos, net.minecraft.core.Direction face) {
        if (validAttraction(level, source, lifetimeTarget) && state != null && !state.isAir()) {
            dev.tc4port.thaumcraft.client.AttractionParticleEffects.bore(level, source, lifetimeTarget, java.util.Objects.requireNonNull(target), state, java.util.Objects.requireNonNull(sourcePos), java.util.Objects.requireNonNull(face));
        }
    }

    public static void spawnVisSparkle(ClientLevel level, Vec3 source, Vec3 target, int rgb) {
        if (validAttraction(level, source, target)) {
            dev.tc4port.thaumcraft.client.VisSparkleParticle.spawn(level, source, target, rgb & 0xFFFFFF);
        }
    }

    public static void spawnVent(ClientLevel level, Vec3 position, Vec3 heading, int rgb, float scale) {
        if (validateEffect(level, position, heading, scale, 0) && validateSpeed(heading)) {
            dev.tc4port.thaumcraft.client.TubeVentParticle.spawnDirected(level, position.x, position.y, position.z, heading.x, heading.y, heading.z, rgb & 0xFFFFFF, scale);
        }
    }

    public static void spawnBubble(ClientLevel level, Vec3 position, int age, int rgb, double riseSpeed) {
        if (currentLevel(level) && finite(position) && age >= -4 && age <= 1200 && Double.isFinite(riseSpeed) && Math.abs(riseSpeed) <= MAX_EFFECT_SPEED) {
            dev.tc4port.thaumcraft.client.CrucibleBubbleParticle.spawn(level, position.x, position.y, position.z, age, rgb & 0xFFFFFF, riseSpeed);
        }
    }

    public static void spawnFroth(ClientLevel level, Vec3 position, boolean down) {
        if (currentLevel(level) && finite(position)) {
            dev.tc4port.thaumcraft.client.CrucibleBubbleParticle.spawnFroth(level, position.x, position.y, position.z, down);
        }
    }

    public static void spawnDroplet(ClientLevel level, Vec3 position, EffectColor color) {
        java.util.Objects.requireNonNull(color, "color");
        if (currentLevel(level) && finite(position)) {
            dev.tc4port.thaumcraft.client.TaintDropletParticle.spawn(level, position.x, position.y, position.z, color.red(), color.green(), color.blue());
        }
    }

    /**
     * Native Particle handle permits remove(); no TC implementation type escapes.
     */
    public static net.minecraft.client.particle.Particle spawnSwarm(ClientLevel level, Entity target, float speed, float turnSpeed, float gravity) {
        if (!currentLevel(level) || target == null || target.level() != level || !Float.isFinite(speed) || speed < 0 || speed > MAX_EFFECT_SPEED || !Float.isFinite(turnSpeed) || turnSpeed < 0 || turnSpeed > 360 || !validateGravity(gravity)) {
            return null;
        }
        return dev.tc4port.thaumcraft.client.TaintSwarmParticle.spawn(level, target, speed, turnSpeed, gravity);
    }

    public static void spawnTargetedWisp(ClientLevel level, Vec3 position, Entity target, int colorType, boolean shrink, float gravity) {
        if (validateEffect(level, position, Vec3.ZERO, 1, colorType) && target != null && target.level() == level && validateGravity(gravity)) {
            PaletteWispParticle.spawnTargeted(level, position.x, position.y, position.z, target, colorType, shrink, gravity);
        }
    }

    public static void spawnInfusedStoneHit(ClientLevel level, net.minecraft.world.level.block.state.BlockState state, net.minecraft.world.phys.BlockHitResult hit, int rgb) {
        if (currentLevel(level) && state != null && hit != null && !state.getShape(level, hit.getBlockPos()).isEmpty()) {
            dev.tc4port.thaumcraft.client.InfusedStoneTerrainParticle.spawnHit(state, level, hit, net.minecraft.client.Minecraft.getInstance().particleEngine, rgb & 0xFFFFFF);
        }
    }

    public static void spawnInfusedStoneBreak(ClientLevel level, net.minecraft.world.level.block.state.BlockState state, BlockPos pos, int rgb) {
        if (currentLevel(level) && state != null && pos != null) {
            dev.tc4port.thaumcraft.client.InfusedStoneTerrainParticle.spawnDestroy(state, level, pos, net.minecraft.client.Minecraft.getInstance().particleEngine, rgb & 0xFFFFFF);
        }
    }

    public static void spawnSpark(ClientLevel level, Vec3 position, float size, EffectColor color, float alpha) {
        java.util.Objects.requireNonNull(color);
        if (validateEffect(level, position, Vec3.ZERO, size, 0) && finiteColor(alpha)) {
            dev.tc4port.thaumcraft.client.ChampionSparkParticle.spawn(level, position.x, position.y, position.z, size, color.red(), color.green(), color.blue(), alpha);
        }
    }

    public static void spawnSlimyBubble(ClientLevel level, Vec3 position, float size, EffectColor color) {
        java.util.Objects.requireNonNull(color);
        if (validateEffect(level, position, Vec3.ZERO, size, 0)) {
            dev.tc4port.thaumcraft.client.AdvancedFurnaceBubbleParticle.spawn(level, position, size, color);
        }
    }

    /**
     * TC's special color-only Nitor pass, not an ordinary engine-particle material override.
     */
    public static void spawnNitorWisp(ClientLevel level, Vec3 source, Vec3 target, float size, int colorType, boolean shrink, float gravity) {
        if (validateEffect(level, source, Vec3.ZERO, size, colorType) && finite(target) && validateDistance(source, target) && validateGravity(gravity)) {
            PaletteWispParticle.spawnNitorDestination(level, source.x, source.y, source.z, target.x, target.y, target.z, size, colorType, shrink, gravity);
        }
    }

    /**
     * Bore (0), infusion (1), XP infusion (2), with a live supplier endpoint.
     */
    public static void spawnAttractedSparkle(ClientLevel level, Vec3 source, Vec3 lifetimeTarget, java.util.function.Supplier<Vec3> target, int mode) {
        if (validAttraction(level, source, lifetimeTarget) && mode >= 0 && mode <= 2) {
            net.minecraft.client.Minecraft.getInstance().particleEngine.add(new dev.tc4port.thaumcraft.client.BoreSparkleParticle(level, source.x, source.y, source.z, lifetimeTarget, java.util.Objects.requireNonNull(target), mode));
        }
    }

    private static boolean validProviderArguments(ThaumcraftParticle particle, Vec3 position, Vec3 args) {
        return switch(java.util.Objects.requireNonNull(particle)) {
            case WISP_MOTE, SPARKLE, DARK_SPARKLE, ALUMENTUM_MOTE, SCAN_RUNE, INFUSION_RUNE, NODE_JAR_FORMATION, FOCAL_MANIPULATOR_SPARKLE, CRUCIBLE_BUBBLE, ELDRITCH_ARC_SPARKLE, ELDRITCH_LOCK_SPARK ->
                unit(args.x) && unit(args.y) && unit(args.z);
            // Its provider needs an entity; use spawnSwarm.
            case TAINT_SWARM ->
                false;
            case BORE_SPARKLE, INFUSION_SPARKLE, INFUSION_XP_SPARKLE ->
                validateDistance(position, args);
            case DESTINATION_WISP_MAGENTA, DESTINATION_WISP_BLUE, DESTINATION_WISP_GREEN, DESTINATION_WISP_DARK ->
                args.lengthSqr() <= MAX_EFFECT_DISTANCE * MAX_EFFECT_DISTANCE;
            case ELDRITCH_WISP, TARGETED_ELDRITCH_WISP ->
                args.x >= 0 && args.x <= Integer.MAX_VALUE && args.x == Math.floor(args.x);
            case WISP_BURST ->
                args.x > 0 && args.x <= MAX_WISP_SIZE;
            case PALETTE_WISP ->
                args.x >= 0 && args.x <= 7 && args.x == Math.floor(args.x) && args.y > 0 && args.y <= MAX_WISP_SIZE && Math.abs(args.z) <= MAX_EFFECT_SPEED;
            case SHOCK_SPARK_0, SHOCK_SPARK_1, SHOCK_SPARK_2 ->
                unit(args.x) && args.y > 0 && args.y <= 64 && unit(args.z);
            case RUNED_STONE_RUNE ->
                args.x >= 1 && args.x < 1201 && unit(args.y) && unit(args.z);
            case SMOKE_SPIRAL, WARDEN_SMOKE_SPIRAL ->
                args.x > 0 && args.x <= 64;
            default ->
                validateSpeed(args);
        };
    }

    private static boolean unit(double value) {
        return value >= 0 && value <= 1;
    }

    private static boolean validAttraction(ClientLevel level, Vec3 source, Vec3 target) {
        return currentLevel(level) && finite(source) && finite(target) && validateDistance(source, target);
    }

    private static boolean currentLevel(ClientLevel level) {
        return level != null && level == Minecraft.getInstance().level;
    }

    private static boolean validateEffect(ClientLevel level, Vec3 position, Vec3 vector, float size, int colorType) {
        if (!currentLevel(level) || !finite(position) || !finite(vector) || !Float.isFinite(size) || size <= 0.0F || size > 64.0F || colorType < 0 || colorType > 7) {
            return reject("Invalid Thaumcraft effect parameters");
        }
        return true;
    }

    private static boolean finiteColor(float value) {
        return Float.isFinite(value) && value >= 0.0F && value <= 1.0F;
    }

    private static boolean validateGravity(float gravity) {
        if (!Float.isFinite(gravity) || Math.abs(gravity) > 16.0F) {
            return reject("Invalid Thaumcraft effect gravity");
        }
        return true;
    }

    private static boolean validateDistance(Vec3 start, Vec3 end) {
        if (start.distanceToSqr(end) > MAX_EFFECT_DISTANCE * MAX_EFFECT_DISTANCE) {
            return reject("Thaumcraft effect is too long");
        }
        return true;
    }

    private static boolean validateSpeed(Vec3 velocity) {
        if (velocity.lengthSqr() > MAX_EFFECT_SPEED * MAX_EFFECT_SPEED) {
            return reject("Thaumcraft effect is too fast");
        }
        return true;
    }

    private static boolean finite(Vec3 value) {
        return value != null && Double.isFinite(value.x) && Double.isFinite(value.y) && Double.isFinite(value.z);
    }

    private static boolean reject(String reason) {
        if (WARNED_INVALID_REQUESTS.add(reason)) {
            Thaumcraft.LOGGER.warn("Ignoring invalid client effect request: {}", reason);
        }
        return false;
    }
}
