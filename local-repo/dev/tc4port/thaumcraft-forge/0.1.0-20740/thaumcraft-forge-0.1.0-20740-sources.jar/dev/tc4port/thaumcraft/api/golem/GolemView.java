package dev.tc4port.thaumcraft.api.golem;

import java.util.List;
import java.util.Optional;
import net.minecraft.core.GlobalPos;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.phys.Vec3;

/**
 * Immutable read-only projection; marker payloads are stable descriptions.
 */
public record GolemView(String decorations, Optional<ResourceLocation> coreId, Optional<GlobalPos> home, List<GolemMarkerView> markers, ResourceLocation type, Vec3 position, float health, float maximumHealth, GolemActivityView activity) {

    public GolemView {
        java.util.Objects.requireNonNull(decorations, "decorations");
        java.util.Objects.requireNonNull(coreId, "coreId");
        java.util.Objects.requireNonNull(home, "home");
        java.util.Objects.requireNonNull(type, "type");
        java.util.Objects.requireNonNull(position, "position");
        java.util.Objects.requireNonNull(activity, "activity");
        markers = List.copyOf(markers);
        if (health < 0 || maximumHealth < 0 || health > maximumHealth || !Float.isFinite(health) || !Float.isFinite(maximumHealth)) {
            throw new IllegalArgumentException("Invalid golem health");
        }
    }
}
