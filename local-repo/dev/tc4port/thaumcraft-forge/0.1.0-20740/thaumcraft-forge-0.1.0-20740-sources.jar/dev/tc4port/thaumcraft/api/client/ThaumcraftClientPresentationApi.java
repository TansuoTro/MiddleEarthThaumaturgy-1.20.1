package dev.tc4port.thaumcraft.api.client;

import dev.tc4port.thaumcraft.api.Registration;
import dev.tc4port.thaumcraft.client.ActionPresentationClient;
import java.util.Objects;
import net.minecraft.resources.ResourceLocation;

/**
 * Stable client-only registration surface for predicted action feedback.
 */
public final class ThaumcraftClientPresentationApi {

    private ThaumcraftClientPresentationApi() {
    }

    /**
     * Registers exactly one handler for a presentation identity. Focus actions
     * normally use their {@code FocusActionSpec.actionId()} as that identity.
     */
    public static Registration register(ResourceLocation presentationId, ActionPresentationHandler handler) {
        return Registration.of(ActionPresentationClient.register(Objects.requireNonNull(presentationId, "presentationId"), Objects.requireNonNull(handler, "handler")));
    }
}
