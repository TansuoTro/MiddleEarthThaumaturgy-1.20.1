package dev.tc4port.thaumcraft.block;

import com.mojang.serialization.MapCodec;
import dev.tc4port.thaumcraft.block.entity.InfusionPillarBlockEntity;
import dev.tc4port.thaumcraft.registry.TCBlocks;
import javax.annotation.Nullable;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.core.BlockPos;
import net.minecraft.util.StringRepresentable;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.LevelEvent;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.EnumProperty;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;
import dev.tc4port.thaumcraft.nativeimpl.ClientExtensionTarget;
import dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.level.pathfinder.PathComputationType;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.Explosion;

/**
 * Formed lower half of an infusion pillar. TC4 stored four corner
 * orientations as metadata 2..5 on this tile.
 */
public final class InfusionPillarBlock extends net.minecraft.world.level.block.BaseEntityBlock implements dev.tc4port.thaumcraft.nativeimpl.ClientExtensionTarget {

    // Forge calls initializeClient from the native superclass constructor. Do not add a field initializer.
    private java.util.function.Consumer<net.minecraftforge.client.extensions.common.IClientBlockExtensions> platform$clientInstaller;

    public enum Orientation implements StringRepresentable {

        NORTH_WEST("north_west"), NORTH_EAST("north_east"), SOUTH_WEST("south_west"), SOUTH_EAST("south_east");

        private final String serializedName;

        Orientation(String serializedName) {
            this.serializedName = serializedName;
        }

        @Override
        public String getSerializedName() {
            return this.serializedName;
        }
    }

    public static final MapCodec<InfusionPillarBlock> CODEC = InfusionPillarBlock.native$BlockCodecPlatform$simple(InfusionPillarBlock::new);

    public static final EnumProperty<Orientation> ORIENTATION = EnumProperty.create("orientation", Orientation.class);

    private static final VoxelShape SHAPE = Block.box(0, 0, 0, 16, 8, 16);

    private static final VoxelShape COLLISION_SHAPE = Block.box(0, 0, 0, 16, 16, 16);

    public InfusionPillarBlock(BlockBehaviour.Properties properties) {
        this(properties, properties, true);
    }

    protected MapCodec<InfusionPillarBlock> codec() {
        return CODEC;
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(ORIENTATION);
    }

    @Nullable
    @Override
    public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        return new InfusionPillarBlockEntity(pos, state);
    }

    @Override
    public RenderShape getRenderShape(BlockState state) {
        return RenderShape.MODEL;
    }

    @Override
    public VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
        return SHAPE;
    }

    @Override
    public VoxelShape getCollisionShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
        /*
         * BlockStoneDevice metadata 3 used this half-height outline, but
         * addCollisionBoxesToList deliberately reset the bounds to a full
         * cube. Keep the two contracts separate on the modern engine too.
         */
        return COLLISION_SHAPE;
    }

    @Override
    public VoxelShape getBlockSupportShape(BlockState state, BlockGetter level, BlockPos pos) {
        return Shapes.empty();
    }

    @Override
    public void neighborChanged(BlockState state, Level level, BlockPos pos, Block neighborBlock, BlockPos neighborPos, boolean movedByPiston) {
        super.neighborChanged(state, level, pos, neighborBlock, neighborPos, movedByPiston);
        if (!level.isClientSide && !level.getBlockState(pos.above()).is(TCBlocks.INFUSION_PILLAR_TOP.get())) {
            level.destroyBlock(pos, true);
        }
    }

    @Override
    public boolean triggerEvent(BlockState state, Level level, BlockPos pos, int id, int parameter) {
        if (id == 1) {
            if (level.isClientSide) {
                dev.tc4port.thaumcraft.client.InfusionSparkleEffects.blockSparkle(level, pos, 11960575, 2);
                level.levelEvent(LevelEvent.PARTICLES_DESTROY_BLOCK, pos, Block.getId(Blocks.STONE_BRICKS.defaultBlockState()));
            }
            return true;
        }
        return super.triggerEvent(state, level, pos, id, parameter);
    }

    @Override
    public ItemStack getCloneItemStack(BlockState state, HitResult target, net.minecraft.world.level.BlockGetter level, BlockPos pos, Player player) {
        // Formed lower metadata 3 dropped the arcane-stone-brick base.
        return new ItemStack(TCBlocks.ARCANE_STONE_BRICKS.get());
    }

    private InfusionPillarBlock(net.minecraft.world.level.block.state.BlockBehaviour.Properties native$NativeEntityBlock$arg0, BlockBehaviour.Properties properties, boolean native$NativeEntityBlock$captured) {
        super(native$NativeEntityBlock$arg0);
        this.registerDefaultState(this.stateDefinition.any().setValue(ORIENTATION, Orientation.NORTH_WEST));
    }

    @Override
    public void initializeClient(java.util.function.Consumer<net.minecraftforge.client.extensions.common.IClientBlockExtensions> installer) {
        platform$clientInstaller = installer;
        super.initializeClient(installer);
    }

    @Override
    public void platform$clientExtension(Object extension) {
        java.util.Objects.requireNonNull(platform$clientInstaller, "Forge initializeClient must run before client extension registration").accept((net.minecraftforge.client.extensions.common.IClientBlockExtensions) extension);
    }

    @Override
    public InteractionResult use(BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
        ItemUseResult result = (switch(0) {
            default ->
                {
                    net.minecraft.world.item.ItemStack native$bodyOperand$4518 = player.getItemInHand(hand);
                    net.minecraft.world.level.block.state.BlockState native$bodyOperand$4519 = state;
                    net.minecraft.world.level.Level native$bodyOperand$4520 = level;
                    net.minecraft.core.BlockPos native$bodyOperand$4521 = pos;
                    net.minecraft.world.entity.player.Player native$bodyOperand$4522 = player;
                    net.minecraft.world.InteractionHand native$bodyOperand$4523 = hand;
                    net.minecraft.world.phys.BlockHitResult native$bodyOperand$4524 = hit;
                    dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult native$bodyResult$4525 = null;
                    native$bodyReturn$4526: {
                        if (true) {
                            {
                                native$bodyResult$4525 = dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
                                break native$bodyReturn$4526;
                            }
                        }
                    }
                    yield native$bodyResult$4525;
                }
        });
        return result == ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION ? (hand == InteractionHand.MAIN_HAND ? (switch(0) {
            default ->
                {
                    net.minecraft.world.level.block.state.BlockState native$bodyOperand$3728 = state;
                    net.minecraft.world.level.Level native$bodyOperand$3729 = level;
                    net.minecraft.core.BlockPos native$bodyOperand$3730 = pos;
                    net.minecraft.world.entity.player.Player native$bodyOperand$3731 = player;
                    net.minecraft.world.phys.BlockHitResult native$bodyOperand$3732 = hit;
                    net.minecraft.world.InteractionResult native$bodyResult$3733 = null;
                    native$bodyReturn$3734: {
                        if (true) {
                            {
                                native$bodyResult$3733 = super.use(native$bodyOperand$3728, native$bodyOperand$3729, native$bodyOperand$3730, native$bodyOperand$3731, net.minecraft.world.InteractionHand.MAIN_HAND, native$bodyOperand$3732);
                                break native$bodyReturn$3734;
                            }
                        }
                    }
                    yield native$bodyResult$3733;
                }
        }) : InteractionResult.PASS) : result.result();
    }

    protected ItemUseResult interactWithItem(ItemStack stack, BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
        return dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
    }

    protected InteractionResult interactWithoutItem(BlockState state, Level level, BlockPos pos, Player player, BlockHitResult hit) {
        return super.use(state, level, pos, player, net.minecraft.world.InteractionHand.MAIN_HAND, hit);
    }

    @Override
    public void playerWillDestroy(Level level, BlockPos pos, BlockState state, Player player) {
        {
            net.minecraft.world.level.Level native$bodyOperand$5883 = level;
            net.minecraft.core.BlockPos native$bodyOperand$5884 = pos;
            net.minecraft.world.level.block.state.BlockState native$bodyOperand$5885 = state;
            net.minecraft.world.entity.player.Player native$bodyOperand$5886 = player;
            net.minecraft.world.level.block.state.BlockState native$bodyResult$5887 = null;
            native$bodyReturn$5888: {
                if (true) {
                    super.playerWillDestroy(native$bodyOperand$5883, native$bodyOperand$5884, native$bodyOperand$5885, native$bodyOperand$5886);
                    {
                        native$bodyResult$5887 = native$bodyOperand$5885;
                        break native$bodyReturn$5888;
                    }
                }
            }
        }
    }

    public BlockState beforePlayerDestroy(Level level, BlockPos pos, BlockState state, Player player) {
        super.playerWillDestroy(level, pos, state, player);
        return state;
    }

    protected boolean survivesSharedExplosion() {
        return false;
    }

    public int getExpDrop(net.minecraft.world.level.block.state.BlockState native$callbackInput$1050, net.minecraft.world.level.LevelReader native$callbackInput$1051, net.minecraft.util.RandomSource native$callbackInput$1052, net.minecraft.core.BlockPos native$callbackInput$1053, int native$callbackInput$1054, int native$callbackInput$1055) {
        net.minecraft.world.level.block.state.BlockState state = native$callbackInput$1050;
        net.minecraft.util.RandomSource random = native$callbackInput$1052;
        return 0;
    }

    @Override
    public void onBlockExploded(BlockState state, Level level, BlockPos pos, Explosion explosion) {
        if (!(switch(0) {
            default ->
                {
                    boolean native$bodyResult$5281 = false;
                    native$bodyReturn$5282: {
                        if (true) {
                            {
                                native$bodyResult$5281 = false;
                                break native$bodyReturn$5282;
                            }
                        }
                    }
                    yield native$bodyResult$5281;
                }
        }))
            super.onBlockExploded(state, level, pos, explosion);
    }

    @Override
    public boolean canDropFromExplosion(BlockState state, BlockGetter level, BlockPos pos, Explosion explosion) {
        return !(switch(0) {
            default ->
                {
                    boolean native$bodyResult$4527 = false;
                    native$bodyReturn$4528: {
                        if (true) {
                            {
                                native$bodyResult$4527 = false;
                                break native$bodyReturn$4528;
                            }
                        }
                    }
                    yield native$bodyResult$4527;
                }
        }) && super.canDropFromExplosion(state, level, pos, explosion);
    }

    static private <B extends net.minecraft.world.level.block.Block> com.mojang.serialization.MapCodec<B> native$BlockCodecPlatform$simple(java.util.function.Function<net.minecraft.world.level.block.state.BlockBehaviour.Properties, B> factory) {
        // Vanilla 1.21's Properties codec is a unit codec. Retain that schema for shared block definitions.
        return com.mojang.serialization.codecs.RecordCodecBuilder.mapCodec(instance -> instance.group(com.mojang.serialization.Codec.unit(net.minecraft.world.level.block.state.BlockBehaviour.Properties::of).fieldOf("properties").forGetter((B block) -> net.minecraft.world.level.block.state.BlockBehaviour.Properties.copy(block))).apply(instance, factory));
    }
}
