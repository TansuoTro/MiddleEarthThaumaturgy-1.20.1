package dev.tc4port.thaumcraft.block.entity;

import dev.tc4port.thaumcraft.registry.TCSounds;
import dev.tc4port.thaumcraft.common.TCGameplayParameters;
import dev.tc4port.thaumcraft.aspect.AspectCatalog;
import dev.tc4port.thaumcraft.block.EssentiaTubeBlock;
import dev.tc4port.thaumcraft.api.machine.ArcaneBellowsApi;
import dev.tc4port.thaumcraft.api.aspect.AspectId;
import dev.tc4port.thaumcraft.api.aspect.AspectAmounts;
import dev.tc4port.thaumcraft.api.essentia.EssentiaApi;
import dev.tc4port.thaumcraft.api.essentia.EssentiaMultiStoreView;
import dev.tc4port.thaumcraft.api.essentia.EssentiaTransferMode;
import dev.tc4port.thaumcraft.api.essentia.EssentiaTransport;
import dev.tc4port.thaumcraft.network.EssentiaVentPayload;
import dev.tc4port.thaumcraft.registry.TCBlockEntities;
import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import javax.annotation.Nullable;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket;
import net.minecraft.sounds.SoundSource;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import java.lang.Math;
import java.lang.System;
import dev.tc4port.thaumcraft.nativeimpl.state.ItemFields;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.entity.BlockEntityType;

/**
 * Suction propagation and one-unit transfer state shared by all TC4 tubes.
 */
public final class EssentiaTubeBlockEntity extends net.minecraft.world.level.block.entity.BlockEntity implements EssentiaTransport, EssentiaMultiStoreView, ItemFields.Source {

    public static final int BUFFER_CAPACITY = 8;

    private final boolean[] openSides = { true, true, true, true, true, true };

    private final byte[] chokedSides = new byte[6];

    private final LinkedHashMap<AspectId, Integer> buffer = new LinkedHashMap<>();

    private AspectId essentiaType;

    private int essentiaAmount;

    private AspectId suctionType;

    private int suction;

    private AspectId filter;

    private boolean flowAllowed = true;

    private boolean wasPowered;

    private int venting;

    private int ventColor = 0xAAAAAA;

    private float clientRotation;

    private TubeModelState clientModelState;

    private record TubeModelState(long connections, int fittings, AspectId filter, long aspects) {
    }

    private int lastCapacity;

    private int count;

    private int bellows = -1;

    private boolean initializedCount;

    public int capacity() {
        return dev.tc4port.thaumcraft.api.essentia.EssentiaStorageApi.capacity(dev.tc4port.thaumcraft.api.essentia.EssentiaStorageApi.ESSENTIA_BUFFER, 8, this.level != null && this.level.isClientSide);
    }

    public EssentiaTubeBlockEntity(BlockPos pos, BlockState state) {
        super(TCBlockEntities.ESSENTIA_TUBE.get(), pos, state);
    }

    public static void serverTick(Level level, BlockPos pos, BlockState state, EssentiaTubeBlockEntity tube) {
        if (!tube.initializedCount) {
            tube.count = level.random.nextInt(10);
            tube.initializedCount = true;
        }
        if (tube.lastCapacity != tube.capacity()) {
            tube.lastCapacity = tube.capacity();
            tube.changedAndSync();
        }
        tube.count++;
        EssentiaTubeBlock.Kind kind = tube.kind();
        if (kind == EssentiaTubeBlock.Kind.VALVE && tube.count % TCGameplayParameters.ALCHEMY_ESSENTIA_TUBES_WORK_INTERVAL.intValue() == 0 && level.hasChunksAt(pos.offset(-2, 0, -2), pos.offset(2, 0, 2))) {
            boolean powered = level.hasNeighborSignal(pos);
            if (powered != tube.wasPowered) {
                tube.wasPowered = powered;
                tube.setFlowAllowed(!powered);
            }
        }
        if (kind == EssentiaTubeBlock.Kind.BUFFER) {
            if (tube.bellows < 0 || tube.count % 20 == 0) {
                tube.recountBellows();
            }
            if (tube.count % TCGameplayParameters.ALCHEMY_ESSENTIA_TUBES_WORK_INTERVAL.intValue() == 0 && tube.totalBuffer() < tube.capacity()) {
                tube.fillBuffer();
            }
        } else {
            if (tube.venting > 0) {
                tube.venting--;
            }
            if (tube.venting <= 0 && tube.count % 2 == 0) {
                tube.calculateSuction();
                tube.checkVenting();
                if (tube.essentiaAmount == 0) {
                    tube.essentiaType = null;
                }
            }
            if (tube.venting <= 0 && tube.count % TCGameplayParameters.ALCHEMY_ESSENTIA_TUBES_WORK_INTERVAL.intValue() == 0 && tube.suction > 0) {
                tube.equalizeWithNeighbours();
            }
        }
        if (tube.count % 20 == 0 && state.getBlock() instanceof EssentiaTubeBlock block) {
            block.refreshConnections(level, pos);
        }
    }

    public static void clientTick(Level level, BlockPos pos, BlockState state, EssentiaTubeBlockEntity tube) {
        int fittings = 0;
        for (Direction direction : Direction.values()) {
            int index = direction.get3DDataValue();
            fittings |= (tube.open(direction) ? tube.choke(direction) : 0) << (index * 2);
        }
        TubeModelState appearance = new TubeModelState(tube.modelConnections(), fittings, tube.filter(), AspectCatalog.generation());
        if (!appearance.equals(tube.clientModelState)) {
            tube.clientModelState = appearance;
            level.sendBlockUpdated(pos, state, state, Block.UPDATE_CLIENTS);
        }
        if (tube.kind() == EssentiaTubeBlock.Kind.VALVE) {
            if (!tube.flowAllowed && tube.clientRotation < 360.0F) {
                tube.clientRotation = Math.min(360.0F, tube.clientRotation + 20.0F);
            } else if (tube.flowAllowed && tube.clientRotation > 0.0F) {
                tube.clientRotation = Math.max(0.0F, tube.clientRotation - 20.0F);
            }
        }
        if (tube.venting > 0) {
            tube.venting--;
            if (tube.venting > 0) {
                dev.tc4port.thaumcraft.client.TubeVentParticle.spawn(level, pos, tube, tube.ventColor);
            }
        }
    }

    /**
     * Three bits per face: connected, extended, and non-conduit endpoint.
     */
    public long modelConnections() {
        if (this.level == null)
            return 0;
        long result = 0;
        for (Direction direction : Direction.values()) {
            if (!this.isConnectable(direction))
                continue;
            BlockPos neighborPos = this.worldPosition.relative(direction);
            if (!this.level.isLoaded(neighborPos))
                continue;
            BlockEntity neighbor = this.level.getBlockEntity(neighborPos);
            int flags = 0;
            EssentiaTransport transport = EssentiaApi.transport(this.level, neighborPos, direction.getOpposite());
            if (transport != null && transport.isConnectable(direction.getOpposite())) {
                flags = 1 | (transport.renderExtendedTube() ? 2 : 0) | (!(neighbor instanceof EssentiaTubeBlockEntity tube) || tube.kind() == EssentiaTubeBlock.Kind.BUFFER ? 4 : 0);
            } else if (this.kind() == EssentiaTubeBlock.Kind.BUFFER && ArcaneBellowsApi.blowsToward(this.level, this.worldPosition.relative(direction), this.worldPosition)) {
                flags = 5;
            }
            result |= (long) flags << (direction.get3DDataValue() * 3);
        }
        return result;
    }

    public EssentiaTubeBlock.Kind kind() {
        return this.getBlockState().getBlock() instanceof EssentiaTubeBlock block ? block.kind() : EssentiaTubeBlock.Kind.NORMAL;
    }

    public boolean open(Direction side) {
        return this.openSides[side.get3DDataValue()];
    }

    public byte choke(Direction side) {
        return this.chokedSides[side.get3DDataValue()];
    }

    public void initializeOpenSidesFromNeighbors() {
        if (this.level == null || this.level.isClientSide) {
            return;
        }
        for (Direction side : Direction.values()) {
            BlockPos neighborPos = this.worldPosition.relative(side);
            if (!this.level.isLoaded(neighborPos))
                continue;
            BlockEntity neighbor = this.level.getBlockEntity(neighborPos);
            this.openSides[side.get3DDataValue()] = !(neighbor instanceof EssentiaTubeBlockEntity tube) || tube.open(side.getOpposite());
        }
        this.changedAndSync();
        this.refreshConnections();
    }

    public void toggleOpen(Direction side) {
        int index = side.get3DDataValue();
        BlockPos neighborPos = this.worldPosition.relative(side);
        BlockEntity neighbor = this.level == null || !this.level.isLoaded(neighborPos) ? null : this.level.getBlockEntity(neighborPos);
        // Toggle the pair's connection so either end can reopen mismatched
        // endpoints in one use.
        boolean connected = this.openSides[index] && (!(neighbor instanceof EssentiaTubeBlockEntity tube) || tube.open(side.getOpposite()));
        this.openSides[index] = !connected;
        if (neighbor instanceof EssentiaTubeBlockEntity tube) {
            tube.openSides[side.getOpposite().get3DDataValue()] = this.openSides[index];
            tube.changedAndSync();
            if (tube.getBlockState().getBlock() instanceof EssentiaTubeBlock block) {
                block.refreshConnections(this.level, tube.getBlockPos());
            }
        }
        this.changedAndSync();
        this.refreshConnections();
    }

    public void cycleChoke(Direction side) {
        int index = side.get3DDataValue();
        this.chokedSides[index]++;
        if (this.chokedSides[index] > 2) {
            this.chokedSides[index] = 0;
        }
        this.changedAndSync();
    }

    public void setFacing(Direction facing) {
        if (this.level != null) {
            this.level.setBlock(this.worldPosition, this.getBlockState().setValue(EssentiaTubeBlock.FACING, facing), Block.UPDATE_ALL);
            this.refreshConnections();
        }
    }

    public Direction facing() {
        return this.getBlockState().getValue(EssentiaTubeBlock.FACING);
    }

    public float clientRotation() {
        return this.clientRotation;
    }

    public void cycleDirectionalFacing() {
        Direction[] directions = Direction.values();
        int start = this.facing().get3DDataValue();
        for (int offset = 1; offset < 20; offset++) {
            Direction candidate = directions[(start + offset) % directions.length];
            Direction sourceSide = candidate.getOpposite();
            if (this.hasRawTransport(sourceSide) && this.isConnectable(sourceSide)) {
                this.setFacing(candidate);
                return;
            }
        }
    }

    public void cycleValveFacing() {
        Direction[] directions = Direction.values();
        int start = this.facing().get3DDataValue();
        for (int offset = 1; offset < 20; offset++) {
            Direction candidate = directions[(start + offset) % directions.length];
            if (!this.hasRawTransport(candidate)) {
                this.setFacing(candidate);
                return;
            }
        }
    }

    private boolean hasRawTransport(Direction direction) {
        BlockPos neighborPos = this.worldPosition.relative(direction);
        return this.level != null && this.level.isLoaded(neighborPos) && EssentiaApi.transport(this.level, neighborPos, direction.getOpposite()) != null;
    }

    @Nullable
    public AspectId filter() {
        return this.filter;
    }

    public boolean setFilter(AspectId aspect) {
        if (!validAspect(aspect)) {
            return false;
        }
        this.filter = aspect;
        this.changedAndSync();
        return true;
    }

    public boolean clearFilter() {
        if (this.filter == null) {
            return false;
        }
        this.filter = null;
        this.changedAndSync();
        return true;
    }

    public boolean flowAllowed() {
        return this.flowAllowed;
    }

    public void setFlowAllowed(boolean allowed) {
        if (this.flowAllowed == allowed) {
            return;
        }
        this.flowAllowed = allowed;
        if (!allowed) {
            this.suction = 0;
            this.suctionType = null;
        }
        if (this.level != null && !this.level.isClientSide) {
            this.level.playSound(null, this.worldPosition, dev.tc4port.thaumcraft.registry.TCSounds.SQUEEK.get(), SoundSource.BLOCKS, 0.7F, 0.9F + this.level.random.nextFloat() * 0.2F);
        }
        this.changedAndSync();
    }

    public Map<AspectId, Integer> bufferedAspects() {
        return Collections.unmodifiableMap(new LinkedHashMap<>(this.buffer));
    }

    @Override
    public AspectAmounts visibleAspects() {
        return this.kind() == EssentiaTubeBlock.Kind.BUFFER ? new AspectAmounts(this.buffer) : AspectAmounts.EMPTY;
    }

    @Override
    public java.util.Set<AspectId> visibleAspectFilters() {
        return this.kind() != EssentiaTubeBlock.Kind.FILTER || this.filter == null ? java.util.Set.of() : java.util.Set.of(this.filter);
    }

    public int comparatorOutput() {
        int total = this.kind() == EssentiaTubeBlock.Kind.BUFFER ? this.totalBuffer() : this.essentiaAmount;
        int capacity = this.kind() == EssentiaTubeBlock.Kind.BUFFER ? capacity() : 1;
        int filled = Math.min(total, capacity);
        return (int) ((long) filled * 14 / capacity) + (total > 0 ? 1 : 0);
    }

    private void calculateSuction() {
        this.suction = 0;
        this.suctionType = null;
        boolean directional = this.kind() == EssentiaTubeBlock.Kind.DIRECTIONAL;
        boolean restricted = this.kind() == EssentiaTubeBlock.Kind.RESTRICTED;
        AspectId activeFilter = this.kind() == EssentiaTubeBlock.Kind.FILTER ? this.filter : null;
        for (Direction direction : Direction.values()) {
            if (directional && this.facing() != direction.getOpposite()) {
                continue;
            }
            if (!this.isConnectable(direction)) {
                continue;
            }
            EssentiaTransport neighbor = this.transportAt(direction);
            if (neighbor == null) {
                continue;
            }
            Direction neighborFace = direction.getOpposite();
            AspectId neighborSuction = neighbor.suctionType(neighborFace);
            boolean allowed = (activeFilter == null || neighborSuction == null || activeFilter.equals(neighborSuction)) && (activeFilter != null || this.essentiaAmount(direction) <= 0 || neighborSuction == null || Objects.equals(this.essentiaType(direction), neighborSuction)) && (activeFilter == null || this.essentiaAmount(direction) <= 0 || this.essentiaType(direction) == null || neighborSuction == null || Objects.equals(this.essentiaType(direction), neighborSuction));
            if (!allowed) {
                continue;
            }
            int neighborAmount = neighbor.suctionAmount(neighborFace);
            if (neighborAmount > 0 && neighborAmount > this.suction + 1) {
                AspectId type = neighborSuction == null ? activeFilter == null ? null : activeFilter : neighborSuction;
                this.setSuction(type, restricted ? neighborAmount / TCGameplayParameters.ALCHEMY_ESSENTIA_TUBES_RESTRICTED_SUCTION_DIVISOR.intValue() : neighborAmount - 1);
            }
        }
    }

    private void checkVenting() {
        for (Direction direction : Direction.values()) {
            if (!this.isConnectable(direction)) {
                continue;
            }
            EssentiaTransport neighbor = this.transportAt(direction);
            if (neighbor == null) {
                continue;
            }
            Direction neighborFace = direction.getOpposite();
            int neighborSuction = neighbor.suctionAmount(neighborFace);
            if (this.suction > 0 && (neighborSuction == this.suction || neighborSuction == this.suction - 1) && !Objects.equals(this.suctionType, neighbor.suctionType(neighborFace))) {
                this.venting = TCGameplayParameters.ALCHEMY_ESSENTIA_TUBES_CONFLICT_VENT_TICKS.intValue();
                this.sendVentEffect();
                this.changedAndSync();
                return;
            }
        }
    }

    private void equalizeWithNeighbours() {
        if (this.essentiaAmount > 0) {
            return;
        }
        boolean directional = this.kind() == EssentiaTubeBlock.Kind.DIRECTIONAL;
        for (Direction direction : Direction.values()) {
            if (directional && this.facing() == direction.getOpposite()) {
                continue;
            }
            if (!this.isConnectable(direction)) {
                continue;
            }
            EssentiaTransport neighbor = this.transportAt(direction);
            if (neighbor == null) {
                continue;
            }
            Direction neighborFace = direction.getOpposite();
            AspectId neighborType = neighbor.essentiaType(neighborFace);
            if (!neighbor.canOutputTo(neighborFace) || !(this.suctionType == null || Objects.equals(this.suctionType, neighborType) || neighborType == null) || this.suction <= neighbor.suctionAmount(neighborFace) || this.suction < neighbor.minimumSuction()) {
                continue;
            }
            AspectId aspect = this.suctionType == null ? null : this.suctionType;
            if (aspect == null) {
                aspect = neighborType;
                if (aspect == null) {
                    aspect = neighbor.extractableAspect(neighborFace);
                }
            }
            if (aspect == null || !AspectCatalog.contains(aspect)) {
                continue;
            }
            int taken = EssentiaApi.take(this.level, neighbor, aspect, 1, neighborFace, EssentiaTransferMode.EXECUTE);
            if (taken > 0) {
                this.addEssentia(aspect, taken, direction, EssentiaTransferMode.EXECUTE);
                if (this.level != null && this.level.random.nextInt(100) == 0) {
                    this.level.blockEvent(this.worldPosition, this.getBlockState().getBlock(), 0, 0);
                }
                return;
            }
        }
    }

    private void fillBuffer() {
        for (Direction direction : Direction.values()) {
            if (!this.isConnectable(direction)) {
                continue;
            }
            EssentiaTransport neighbor = this.transportAt(direction);
            if (neighbor == null) {
                continue;
            }
            Direction neighborFace = direction.getOpposite();
            if (neighbor.essentiaAmount(neighborFace) > 0 && neighbor.suctionAmount(neighborFace) < this.suctionAmount(direction) && this.suctionAmount(direction) >= neighbor.minimumSuction()) {
                AspectId type = neighbor.essentiaType(neighborFace);
                if (type != null) {
                    this.addEssentia(type, EssentiaApi.take(this.level, neighbor, type, 1, neighborFace, EssentiaTransferMode.EXECUTE), direction, EssentiaTransferMode.EXECUTE);
                }
                return;
            }
        }
    }

    private void recountBellows() {
        if (this.level == null) {
            return;
        }
        int found = 0;
        for (Direction direction : Direction.values()) {
            BlockPos bellowsPos = this.worldPosition.relative(direction);
            if (ArcaneBellowsApi.blowsToward(this.level, bellowsPos, this.worldPosition)) {
                found++;
            }
        }
        this.bellows = found;
    }

    @Nullable
    private EssentiaTransport transportAt(Direction direction) {
        BlockPos neighborPos = this.worldPosition.relative(direction);
        if (this.level == null || !this.level.isLoaded(neighborPos)) {
            return null;
        }
        EssentiaTransport transport = EssentiaApi.transport(this.level, neighborPos, direction.getOpposite());
        if (transport == null)
            return null;
        EssentiaTransport view = transport.transferView();
        return view.isConnectable(direction.getOpposite()) ? view : null;
    }

    /**
     * Physical ports remain present when their wand-controlled connection is closed.
     */
    public boolean hasConnectionPort(Direction face) {
        return this.kind() != EssentiaTubeBlock.Kind.VALVE || face != this.facing();
    }

    @Override
    public boolean isConnectable(Direction face) {
        return this.open(face) && this.hasConnectionPort(face);
    }

    @Override
    public boolean canInputFrom(Direction face) {
        return this.isConnectable(face);
    }

    @Override
    public boolean canOutputTo(Direction face) {
        return this.isConnectable(face);
    }

    public void setSuction(@Nullable AspectId aspect, int amount) {
        if (this.kind() == EssentiaTubeBlock.Kind.VALVE && !this.flowAllowed) {
            return;
        }
        if (aspect == null) {
            // Empty jars advertise untyped suction. Null is a wildcard, not
            // an unknown aspect identity, and must retain its strength.
            this.suctionType = null;
            this.suction = Math.max(0, amount);
        } else if (validAspect(aspect)) {
            this.suctionType = aspect;
            this.suction = Math.max(0, amount);
        } else {
            this.suctionType = null;
            this.suction = 0;
        }
    }

    @Nullable
    @Override
    public AspectId suctionType(Direction face) {
        return this.kind() == EssentiaTubeBlock.Kind.BUFFER || !AspectCatalog.contains(this.suctionType) ? null : this.suctionType;
    }

    @Override
    public int suctionAmount(Direction face) {
        if (this.kind() != EssentiaTubeBlock.Kind.BUFFER) {
            return this.suctionType == null || AspectCatalog.contains(this.suctionType) ? this.suction : 0;
        }
        byte choke = this.choke(face);
        if (choke == 2) {
            return 0;
        }
        return this.bellows > 0 && choke != 1 ? this.bellows * 32 : 1;
    }

    @Override
    public int takeEssentia(AspectId aspect, int amount, Direction face, EssentiaTransferMode mode) {
        if (!this.canOutputTo(face) || !validAspect(aspect) || amount <= 0) {
            return 0;
        }
        if (this.kind() == EssentiaTubeBlock.Kind.BUFFER) {
            int requesterSuction = 0;
            EssentiaTransport requester = this.transportAt(face);
            if (requester != null) {
                requesterSuction = requester.suctionAmount(face.getOpposite());
            }
            for (Direction direction : Direction.values()) {
                if (direction == face || !this.canOutputTo(direction)) {
                    continue;
                }
                EssentiaTransport neighbor = this.transportAt(direction);
                if (neighbor == null) {
                    continue;
                }
                Direction neighborFace = direction.getOpposite();
                int competing = neighbor.suctionAmount(neighborFace);
                AspectId type = neighbor.suctionType(neighborFace);
                if ((type == null || aspect.equals(type)) && requesterSuction < competing && this.suctionAmount(direction) < competing) {
                    return 0;
                }
            }
            int present = this.buffer.getOrDefault(aspect, 0);
            int removed = Math.min(amount, present);
            if (removed > 0 && mode.executes()) {
                int remaining = present - removed;
                if (remaining == 0) {
                    this.buffer.remove(aspect);
                } else {
                    this.buffer.put(aspect, remaining);
                }
                this.changedAndSync();
            }
            return removed;
        }
        if (!aspect.equals(this.essentiaType) || this.essentiaAmount <= 0) {
            return 0;
        }
        int removed = Math.min(amount, this.essentiaAmount);
        if (mode.executes()) {
            this.essentiaAmount -= removed;
            if (this.essentiaAmount == 0) {
                this.essentiaType = null;
            }
            this.changedAndSync();
        }
        return removed;
    }

    @Override
    public int addEssentia(AspectId aspect, int amount, Direction face, EssentiaTransferMode mode) {
        if (!this.canInputFrom(face) || !validAspect(aspect) || amount <= 0) {
            return 0;
        }
        if (this.kind() == EssentiaTubeBlock.Kind.BUFFER) {
            // TC4's tube buffer intentionally accepts one-unit pushes only.
            if (amount != 1 || this.totalBuffer() >= capacity()) {
                return 0;
            }
            if (mode.executes()) {
                this.buffer.merge(aspect, 1, Integer::sum);
                this.changedAndSync();
            }
            return 1;
        }
        if (this.essentiaAmount != 0) {
            return 0;
        }
        if (mode.executes()) {
            this.essentiaType = aspect;
            this.essentiaAmount = 1;
            this.changedAndSync();
        }
        return 1;
    }

    @Nullable
    @Override
    public AspectId essentiaType(Direction face) {
        if (this.kind() != EssentiaTubeBlock.Kind.BUFFER) {
            return AspectCatalog.contains(this.essentiaType) ? this.essentiaType : null;
        }
        if (this.buffer.isEmpty() || this.level == null) {
            return null;
        }
        List<AspectId> active = this.buffer.keySet().stream().filter(AspectCatalog::contains).toList();
        if (active.isEmpty()) {
            return null;
        }
        int selected = this.level.random.nextInt(active.size());
        return active.stream().skip(selected).findFirst().orElse(null);
    }

    @Nullable
    @Override
    public AspectId extractableAspect(Direction face) {
        if (this.kind() != EssentiaTubeBlock.Kind.BUFFER) {
            return EssentiaTransport.super.extractableAspect(face);
        }
        return this.buffer.entrySet().stream().filter(entry -> entry.getValue() > 0).map(Map.Entry::getKey).filter(AspectCatalog::contains).findFirst().orElse(null);
    }

    @Override
    public int availableEssentia(AspectId aspect, Direction face) {
        if (this.kind() != EssentiaTubeBlock.Kind.BUFFER) {
            return EssentiaTransport.super.availableEssentia(aspect, face);
        }
        if (!AspectCatalog.contains(aspect)) {
            return 0;
        }
        return Math.max(0, this.buffer.getOrDefault(aspect, 0));
    }

    @Override
    public int essentiaAmount(Direction face) {
        if (this.kind() == EssentiaTubeBlock.Kind.BUFFER) {
            return (int) Math.min(Integer.MAX_VALUE, this.buffer.entrySet().stream().filter(entry -> AspectCatalog.contains(entry.getKey())).mapToLong(Map.Entry::getValue).sum());
        }
        return AspectCatalog.contains(this.essentiaType) ? this.essentiaAmount : 0;
    }

    @Override
    public int minimumSuction() {
        return 0;
    }

    @Override
    public boolean renderExtendedTube() {
        return false;
    }

    private int totalBuffer() {
        return (int) Math.min(Integer.MAX_VALUE, this.buffer.values().stream().mapToLong(Integer::longValue).sum());
    }

    private void refreshConnections() {
        if (this.level != null && this.getBlockState().getBlock() instanceof EssentiaTubeBlock block) {
            block.refreshConnections(this.level, this.worldPosition);
        }
    }

    private void changedAndSync() {
        this.setChanged();
        BlockEntitySync.sendToClientAndUpdateComparator(this);
    }

    private void sendVentEffect() {
        if (!(this.level instanceof ServerLevel serverLevel)) {
            return;
        }
        EssentiaVentPayload payload = EssentiaVentPayload.of(this.worldPosition, this.suctionType);
        Vec3 center = Vec3.atCenterOf(this.worldPosition);
        for (ServerPlayer player : serverLevel.players()) {
            if (player.distanceToSqr(center) <= 32.0 * 32.0) {
                dev.tc4port.thaumcraft.network.TCPayloads.CHANNEL.sendToPlayer(player, payload);
            }
        }
    }

    public void clientVent(@Nullable AspectId aspect) {
        if (this.level == null || !this.level.isClientSide) {
            return;
        }
        if (this.venting <= 0) {
            this.level.playLocalSound(this.worldPosition.getX() + 0.5, this.worldPosition.getY() + 0.5, this.worldPosition.getZ() + 0.5, TCSounds.TUBE_VENT.get(), SoundSource.BLOCKS, 0.1F, 1.0F + this.level.random.nextFloat() * 0.1F, false);
        }
        this.venting = 50;
        var definition = aspect == null ? null : AspectCatalog.get(aspect);
        this.ventColor = definition == null ? 0xAAAAAA : definition.color();
    }

    @Override
    public boolean triggerEvent(int id, int parameter) {
        if (id == 0) {
            if (this.level != null && this.level.isClientSide) {
                this.level.playLocalSound(this.worldPosition.getX() + 0.5, this.worldPosition.getY() + 0.5, this.worldPosition.getZ() + 0.5, TCSounds.TUBE_FLOW.get(), SoundSource.BLOCKS, 1.0F, 1.3F + this.level.random.nextFloat() * 0.2F, false);
            }
            return true;
        }
        return super.triggerEvent(id, parameter);
    }

    private static boolean validAspect(@Nullable AspectId aspect) {
        return aspect != null && AspectCatalog.contains(aspect);
    }

    @Nullable
    private static AspectId parsePersistedAspect(@Nullable String value) {
        try {
            return value == null || value.isBlank() ? null : AspectId.parse(value);
        } catch (RuntimeException ignored) {
            return null;
        }
    }

    @Override
    public void load(CompoundTag tag) {
        super.load(tag);
        String storedType = tag.contains("type") ? tag.getString("type") : null;
        this.essentiaType = parsePersistedAspect(storedType);
        this.essentiaAmount = Math.max(0, Math.min(1, tag.getInt("amount")));
        String storedSuction = tag.contains("stype") ? tag.getString("stype") : null;
        this.suctionType = parsePersistedAspect(storedSuction);
        this.suction = Math.max(0, tag.getInt("samount"));
        String storedFilter = tag.contains("AspectFilter") ? tag.getString("AspectFilter") : null;
        this.filter = parsePersistedAspect(storedFilter);
        this.flowAllowed = !tag.contains("flow") || tag.getBoolean("flow");
        this.wasPowered = tag.getBoolean("hadpower");
        byte[] open = tag.getByteArray("open");
        if (open.length == 6) {
            for (int index = 0; index < 6; index++) {
                this.openSides[index] = open[index] == 1;
            }
        }
        byte[] choke = tag.getByteArray("choke");
        if (choke.length == 6) {
            System.arraycopy(choke, 0, this.chokedSides, 0, 6);
        }
        AspectNbtList.loadInto(tag, this.buffer);
    }

    @Override
    protected void saveAdditional(CompoundTag tag) {
        super.saveAdditional(tag);
        if (this.essentiaType != null) {
            tag.putString("type", this.essentiaType.serialized());
        }
        tag.putInt("amount", this.essentiaAmount);
        if (this.suctionType != null) {
            tag.putString("stype", this.suctionType.serialized());
        }
        tag.putInt("samount", this.suction);
        if (this.filter != null) {
            tag.putString("AspectFilter", this.filter.serialized());
        }
        tag.putBoolean("flow", this.flowAllowed);
        tag.putBoolean("hadpower", this.wasPowered);
        byte[] open = new byte[6];
        for (int index = 0; index < 6; index++) {
            open[index] = (byte) (this.openSides[index] ? 1 : 0);
        }
        tag.putByteArray("open", open);
        tag.putByteArray("choke", Arrays.copyOf(this.chokedSides, 6));
        if (this.kind() == EssentiaTubeBlock.Kind.BUFFER) {
            AspectNbtList.saveFrom(tag, this.buffer);
        }
    }

    @Override
    public CompoundTag getUpdateTag() {
        return this.saveWithoutMetadata();
    }

    @Override
    public Packet<ClientGamePacketListener> getUpdatePacket() {
        return ClientboundBlockEntityDataPacket.create(this);
    }

    protected final HolderLookup.Provider persistenceRegistries() {
        if (level != null)
            return level.registryAccess();
        var server = net.minecraftforge.server.ServerLifecycleHooks.getCurrentServer();
        return server != null ? server.registryAccess() : net.minecraft.core.RegistryAccess.fromRegistryOfRegistries(net.minecraft.core.registries.BuiltInRegistries.REGISTRY);
    }

    protected static net.minecraft.network.chat.Component parseCustomNameSafe(String value, HolderLookup.Provider registries) {
        try {
            return net.minecraft.network.chat.Component.Serializer.fromJson(value);
        } catch (RuntimeException exception) {
            return null;
        }
    }

    protected void readItemFields(ItemFields.Input input) {
    }

    public void copyItemFields(ItemFields.Output output) {
    }

    public void applyComponentsFromItemStack(ItemStack stack) {
        readItemFields(ItemFields.from(stack));
    }

    public void removeComponentsFromTag(CompoundTag tag) {
    }

    @Override
    public void saveToItem(ItemStack stack) {
        CompoundTag tag = saveWithoutMetadata();
        {
            net.minecraft.nbt.CompoundTag native$bodyOperand$6150 = tag;
            native$bodyReturn$6152: {
                if (true) {
                }
            }
        }
        net.minecraft.world.item.BlockItem.setBlockEntityData(stack, getType(), tag);
        copyItemFields(ItemFields.to(stack));
    }

    @Override
    public net.minecraft.world.phys.AABB getRenderBoundingBox() {
        return EssentiaTubeBlockEntity.native$ClientBlockEntityBounds$bounds(this);
    }

    @Override()
    public void onDataPacket(net.minecraft.network.Connection connection, net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket packet) {
        handleUpdateTag(packet.getTag());
    }

    @SuppressWarnings({ "rawtypes", "unchecked" })
    static private net.minecraft.world.phys.AABB native$ClientBlockEntityBounds$bounds(net.minecraft.world.level.block.entity.BlockEntity blockEntity) {
        var renderer = net.minecraft.client.Minecraft.getInstance().getBlockEntityRenderDispatcher().getRenderer(blockEntity);
        return renderer instanceof dev.tc4port.thaumcraft.nativeimpl.NativeBlockEntityRenderer shared ? shared.getRenderBoundingBox(blockEntity) : new net.minecraft.world.phys.AABB(blockEntity.getBlockPos());
    }

    private boolean native$capabilitiesInvalid$16899;

    public boolean native$capabilityActive$16765;

    public net.minecraftforge.common.capabilities.Capability<dev.tc4port.thaumcraft.api.essentia.EssentiaTransport> native$capabilityCapture$16764;

    private net.minecraftforge.common.util.LazyOptional<dev.tc4port.thaumcraft.api.essentia.EssentiaTransport> native$capabilityHandle$16766;

    @Override
    public <native$capabilityResultType$16900> net.minecraftforge.common.util.LazyOptional<native$capabilityResultType$16900> getCapability(net.minecraftforge.common.capabilities.Capability<native$capabilityResultType$16900> native$requestedCapability$16901, net.minecraft.core.Direction native$requestedFace$16902) {
        getCapabilities();
        synchronized (this) {
            if (native$capabilitiesInvalid$16899)
                return net.minecraftforge.common.util.LazyOptional.empty();
            if (native$capabilityActive$16765 && native$requestedCapability$16901 == (this.native$capabilityCapture$16764)) {
                if (native$capabilityHandle$16766 == null)
                    native$capabilityHandle$16766 = net.minecraftforge.common.util.LazyOptional.of(() -> this);
                return native$capabilityHandle$16766.cast();
            }
        }
        return super.getCapability(native$requestedCapability$16901, native$requestedFace$16902);
    }

    @Override
    public void invalidateCaps() {
        java.util.List<net.minecraftforge.common.util.LazyOptional<?>> native$expiredCapabilities$16903 = new java.util.ArrayList<>();
        synchronized (this) {
            native$capabilitiesInvalid$16899 = true;
            if (native$capabilityHandle$16766 != null) {
                native$expiredCapabilities$16903.add(native$capabilityHandle$16766);
                native$capabilityHandle$16766 = null;
            }
        }
        try {
            super.invalidateCaps();
        } finally {
            native$expiredCapabilities$16903.forEach(net.minecraftforge.common.util.LazyOptional::invalidate);
        }
    }

    @Override
    public void reviveCaps() {
        super.reviveCaps();
        synchronized (this) {
            native$capabilitiesInvalid$16899 = false;
        }
    }
}
