package dev.tc4port.thaumcraft.aspect;

import dev.tc4port.thaumcraft.nativeimpl.util.SyncPayloadBudget;
import dev.tc4port.thaumcraft.api.aspect.AspectDefinition;
import dev.tc4port.thaumcraft.api.aspect.AspectId;
import dev.tc4port.thaumcraft.api.aspect.AspectRegistryView;
import dev.tc4port.thaumcraft.api.aspect.VisChannel;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import dev.tc4port.thaumcraft.util.StableWeightedSelector;
import java.util.Set;

/**
 * Validated immutable aspect graph installed as one atomic unit.
 */
public final class AspectRegistrySnapshot implements AspectRegistryView {

    public static final int MAX_DEFINITIONS = 4096;

    public static final int MAX_COMPONENT_DEPTH = 128;

    public static final int MAX_PRIMAL_EXPANSION = 4096;

    private static final List<VisChannel> FIXED_VIS_CHANNELS = List.of(VisChannel.values());

    private final long generation;

    private final Map<AspectId, AspectDefinition> definitions;

    private final Set<AspectId> primals;

    private final Set<AspectId> compounds;

    private final List<VisChannel> visChannels;

    private final Map<AspectId, Integer> naturalPrimalWeights;

    private final Map<AspectId, Integer> naturalCompoundWeights;

    private final Map<ComponentPair, AspectId> combinations;

    private AspectRegistrySnapshot(long generation, Map<AspectId, AspectDefinition> definitions, Set<AspectId> primals, Set<AspectId> compounds, List<VisChannel> visChannels, Map<AspectId, Integer> naturalPrimalWeights, Map<AspectId, Integer> naturalCompoundWeights, Map<ComponentPair, AspectId> combinations) {
        this.generation = generation;
        this.definitions = definitions;
        this.primals = primals;
        this.compounds = compounds;
        this.visChannels = visChannels;
        this.naturalPrimalWeights = naturalPrimalWeights;
        this.naturalCompoundWeights = naturalCompoundWeights;
        this.combinations = combinations;
    }

    public static AspectRegistrySnapshot create(long generation, Collection<AspectDefinition> input) {
        if (generation < 0L) {
            throw new IllegalArgumentException("Aspect registry generation must not be negative");
        }
        if (input == null || input.isEmpty() || input.size() > MAX_DEFINITIONS) {
            throw new IllegalArgumentException("An aspect registry must contain 1.." + MAX_DEFINITIONS + " definitions");
        }
        ArrayList<AspectDefinition> ordered = new ArrayList<>(input);
        LinkedHashMap<AspectId, AspectDefinition> definitions = new LinkedHashMap<>();
        for (AspectDefinition definition : ordered) {
            AspectDefinition replaced = definitions.put(definition.id(), definition);
            if (replaced != null) {
                throw new IllegalArgumentException("Duplicate aspect definition: " + definition.id());
            }
        }
        validateComponents(definitions);
        validateAcyclic(definitions);
        validateConsumerComplexity(definitions);
        ArrayList<AspectId> primals = new ArrayList<>();
        ArrayList<AspectId> compounds = new ArrayList<>();
        LinkedHashMap<AspectId, Integer> naturalPrimalWeights = new LinkedHashMap<>();
        LinkedHashMap<AspectId, Integer> naturalCompoundWeights = new LinkedHashMap<>();
        AspectDefinition[] channels = new AspectDefinition[6];
        LinkedHashMap<ComponentPair, AspectId> combinations = new LinkedHashMap<>();
        for (AspectDefinition definition : definitions.values()) {
            List<AspectId> category = definition.primal() ? primals : compounds;
            category.add(definition.id());
            if (definition.naturalGenerationWeight() > 0) {
                Map<AspectId, Integer> natural = definition.primal() ? naturalPrimalWeights : naturalCompoundWeights;
                natural.put(definition.id(), definition.naturalGenerationWeight());
            }
            if (definition.isVisChannel()) {
                int slot = definition.visChannel().orElseThrow().index();
                if (channels[slot] != null) {
                    throw new IllegalArgumentException("Duplicate vis channel " + slot + ": " + channels[slot].id() + " and " + definition.id());
                }
                channels[slot] = definition;
            }
            if (!definition.primal()) {
                ComponentPair pair = ComponentPair.of(definition.components().get(0), definition.components().get(1));
                AspectId previous = combinations.put(pair, definition.id());
                if (previous != null) {
                    throw new IllegalArgumentException("Ambiguous aspect combination " + pair.first + " + " + pair.second + ": " + previous + " and " + definition.id());
                }
            }
        }
        ArrayList<VisChannel> visChannels = new ArrayList<>(6);
        for (int slot = 0; slot < channels.length; slot++) {
            if (channels[slot] == null) {
                throw new IllegalArgumentException("Missing vis channel " + slot);
            }
            VisChannel expected = VisChannel.values()[slot];
            if (!channels[slot].id().equals(expected.aspectId())) {
                throw new IllegalArgumentException("Vis channel " + expected + " must be owned by " + expected.aspectId() + "; found " + channels[slot].id());
            }
            visChannels.add(channels[slot].visChannel().orElseThrow());
        }
        if (!visChannels.equals(FIXED_VIS_CHANNELS)) {
            throw new IllegalArgumentException("The six fixed vis channels and their slots are a saved " + "gameplay contract; found " + visChannels);
        }
        if (naturalPrimalWeights.isEmpty() || naturalCompoundWeights.isEmpty()) {
            throw new IllegalArgumentException("Natural aspect pools must contain at least one primal " + "and one compound definition");
        }
        AspectRegistrySnapshot result = new AspectRegistrySnapshot(generation, Collections.unmodifiableMap(definitions), Collections.unmodifiableSet(new LinkedHashSet<>(primals)), Collections.unmodifiableSet(new LinkedHashSet<>(compounds)), List.copyOf(visChannels), Collections.unmodifiableMap(naturalPrimalWeights), Collections.unmodifiableMap(naturalCompoundWeights), Collections.unmodifiableMap(combinations));
        SyncPayloadBudget.requireWithin(result.encodedSizeUpperBound(), "Aspect registry");
        return result;
    }

    private static void validateComponents(Map<AspectId, AspectDefinition> definitions) {
        for (AspectDefinition definition : definitions.values()) {
            for (AspectId component : definition.components()) {
                if (!definitions.containsKey(component)) {
                    throw new IllegalArgumentException("Aspect " + definition.id() + " references missing component " + component);
                }
                if (definition.id().equals(component)) {
                    throw new IllegalArgumentException("Aspect " + definition.id() + " cannot contain itself");
                }
            }
        }
    }

    private static void validateAcyclic(Map<AspectId, AspectDefinition> definitions) {
        HashSet<AspectId> complete = new HashSet<>();
        HashSet<AspectId> visiting = new HashSet<>();
        ArrayList<AspectId> path = new ArrayList<>();
        ArrayList<Integer> nextComponents = new ArrayList<>();
        for (AspectId root : definitions.keySet()) {
            if (complete.contains(root)) {
                continue;
            }
            path.add(root);
            nextComponents.add(0);
            visiting.add(root);
            while (!path.isEmpty()) {
                int last = path.size() - 1;
                AspectId current = path.get(last);
                List<AspectId> components = definitions.get(current).components();
                int next = nextComponents.get(last);
                if (next < components.size()) {
                    AspectId component = components.get(next);
                    nextComponents.set(last, next + 1);
                    if (complete.contains(component)) {
                        continue;
                    }
                    if (!visiting.add(component)) {
                        ArrayList<AspectId> cycle = new ArrayList<>(path);
                        cycle.add(component);
                        throw new IllegalArgumentException("Cyclic aspect graph: " + cycle);
                    }
                    path.add(component);
                    nextComponents.add(0);
                    continue;
                }
                path.remove(path.size() - 1);
                nextComponents.remove(nextComponents.size() - 1);
                visiting.remove(current);
                complete.add(current);
            }
        }
    }

    private static void validateConsumerComplexity(Map<AspectId, AspectDefinition> definitions) {
        LinkedHashMap<AspectId, Integer> depths = new LinkedHashMap<>();
        LinkedHashMap<AspectId, Integer> expansions = new LinkedHashMap<>();
        for (AspectId root : definitions.keySet()) {
            ArrayList<AspectId> path = new ArrayList<>();
            path.add(root);
            while (!path.isEmpty()) {
                AspectId current = path.get(path.size() - 1);
                if (depths.containsKey(current)) {
                    path.remove(path.size() - 1);
                    continue;
                }
                AspectDefinition definition = definitions.get(current);
                if (definition.primal()) {
                    depths.put(current, 0);
                    expansions.put(current, 1);
                    path.remove(path.size() - 1);
                    continue;
                }
                AspectId unresolved = definition.components().stream().filter(component -> !depths.containsKey(component)).findFirst().orElse(null);
                if (unresolved != null) {
                    path.add(unresolved);
                    continue;
                }
                int depth = 1 + Math.max(depths.get(definition.components().get(0)), depths.get(definition.components().get(1)));
                long expansion = (long) expansions.get(definition.components().get(0)) + expansions.get(definition.components().get(1));
                if (depth > MAX_COMPONENT_DEPTH || expansion > MAX_PRIMAL_EXPANSION) {
                    throw new IllegalArgumentException("Aspect " + current + " exceeds the consumer " + "graph budget of depth " + MAX_COMPONENT_DEPTH + " and " + MAX_PRIMAL_EXPANSION + " expanded primal units");
                }
                depths.put(current, depth);
                expansions.put(current, (int) expansion);
                path.remove(path.size() - 1);
            }
        }
    }

    @Override
    public long generation() {
        return this.generation;
    }

    public long encodedSizeUpperBound() {
        long bytes = 15L;
        for (AspectDefinition definition : this.definitions.values()) {
            bytes += 24L;
            bytes += SyncPayloadBudget.resourceLocation(definition.id().value(), "Aspect ID");
            for (AspectId component : definition.components()) {
                bytes += SyncPayloadBudget.resourceLocation(component.value(), "Aspect component ID");
            }
            bytes += SyncPayloadBudget.resourceLocation(definition.texture(), "Aspect texture");
        }
        return bytes;
    }

    @Override
    public Map<AspectId, AspectDefinition> definitions() {
        return this.definitions;
    }

    @Override
    public Optional<AspectDefinition> get(AspectId id) {
        return Optional.ofNullable(this.definitions.get(id));
    }

    @Override
    public Set<AspectId> primals() {
        return this.primals;
    }

    @Override
    public Set<AspectId> compounds() {
        return this.compounds;
    }

    @Override
    public List<VisChannel> visChannels() {
        return this.visChannels;
    }

    @Override
    public Map<AspectId, Integer> naturalPrimalWeights() {
        return this.naturalPrimalWeights;
    }

    @Override
    public Map<AspectId, Integer> naturalCompoundWeights() {
        return this.naturalCompoundWeights;
    }

    /**
     * Weighted rendezvous selection. One caller-supplied entropy value is
     * mixed independently with each identity, so declaration, pack and map
     * iteration order cannot change the winner.
     */
    @Override
    public AspectId selectNaturalPrimal(long entropy) {
        return selectWeighted(this.naturalPrimalWeights, entropy);
    }

    @Override
    public AspectId selectNaturalCompound(long entropy) {
        return selectWeighted(this.naturalCompoundWeights, entropy);
    }

    public AspectId selectKnown(Collection<AspectId> candidates, long entropy) {
        List<AspectId> known = candidates.stream().filter(this.definitions::containsKey).distinct().toList();
        return known.isEmpty() ? null : StableWeightedSelector.select(known, AspectId::serialized, ignored -> 1, entropy);
    }

    private static AspectId selectWeighted(Map<AspectId, Integer> weights, long entropy) {
        return StableWeightedSelector.select(weights.entrySet(), entry -> entry.getKey().serialized(), Map.Entry::getValue, entropy).getKey();
    }

    @Override
    public Optional<AspectId> combination(AspectId first, AspectId second) {
        return Optional.ofNullable(this.combinations.get(ComponentPair.of(first, second)));
    }

    private record ComponentPair(AspectId first, AspectId second) {

        private static ComponentPair of(AspectId first, AspectId second) {
            return first.compareTo(second) <= 0 ? new ComponentPair(first, second) : new ComponentPair(second, first);
        }
    }
}
