package dev.tc4port.thaumcraft.api.machine;

import java.util.List;
import net.minecraft.world.item.ItemStack;

/**
 * An addon-owned transformation of one Arcane Bore harvest.
 */
@FunctionalInterface
public interface ArcaneBoreDropModifier {

    /**
     * Called once on the server thread after successful native player mining
     * and its loot/harvest events, before machine output. The mutable list
     * contains fresh item drops from the operation (including tool-triggered
     * secondary breaks), possibly empty; pre-existing loose items are collected
     * separately. The context describes the primary target. Callbacks may add,
     * replace or remove stacks.
     * Do not retain the list, mutate the world or spawn the drops yourself.
     */
    void modifyDrops(ArcaneBoreDropContext context, List<ItemStack> drops);
}
