package dev.tc4port.thaumcraft.block;

import dev.tc4port.thaumcraft.common.TCGameplayParameters;
import com.mojang.serialization.MapCodec;
import dev.tc4port.thaumcraft.block.entity.MagicFluidBlockEntity;
import dev.tc4port.thaumcraft.entity.ThaumicSlimeEntity;
import dev.tc4port.thaumcraft.registry.TCEffects;
import dev.tc4port.thaumcraft.registry.TCFluids;
import net.minecraft.core.BlockPos;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.EntityBlock;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;

/**
 * Volume-conserving Flux Goo plus TC4's slime, taint and exposure rules.
 */
public final class FluxGooBlock extends FiniteFluidBlock implements EntityBlock {

    public static final MapCodec<FluxGooBlock> CODEC = FluxGooBlock.native$BlockCodecPlatform$simple(FluxGooBlock::new);

    public FluxGooBlock(BlockBehaviour.Properties properties) {
        // viscosity 6000 / 200, density 8, default eight quanta
        super(properties, TCFluids.FLUX_GOO::get);
    }

    protected MapCodec<FluxGooBlock> codec() {
        return CODEC;
    }

    @Override
    public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        return new MagicFluidBlockEntity(pos, state);
    }

    @Override
    public void entityInside(BlockState state, Level level, BlockPos pos, Entity entity) {
        int metadata = state.getValue(LEVEL);
        if (entity instanceof ThaumicSlimeEntity slime) {
            if (!level.isClientSide && slime.mass() < metadata && level.random.nextBoolean()) {
                slime.setMass(slime.mass() + 1);
                if (metadata > 1) {
                    level.setBlock(pos, state.setValue(LEVEL, metadata - 1), 3);
                } else {
                    this.clear(level, pos);
                }
            }
            return;
        }
        float drag = 1.0F - this.filledPercentage(state);
        Vec3 motion = entity.getDeltaMovement();
        entity.setDeltaMovement(motion.x * drag, motion.y, motion.z * drag);
        if (!level.isClientSide && entity instanceof LivingEntity living) {
            living.addEffect((switch(0) {
                default ->
                    {
                        net.minecraft.core.Holder<net.minecraft.world.effect.MobEffect> native$operand$13293 = ((net.minecraft.core.Holder<net.minecraft.world.effect.MobEffect>) (net.minecraft.core.Holder<?>) (TCEffects.VIS_EXHAUST).getHolder().orElseThrow());
                        int native$operand$13294 = TCGameplayParameters.EFFECTS_TAINT_CONTACT_GOO_DURATION.intValue();
                        int native$operand$13295 = metadata / TCGameplayParameters.EFFECTS_TAINT_CONTACT_METADATA_AMPLIFIER_DIVISOR.intValue();
                        boolean native$operand$13296 = true;
                        boolean native$operand$13297 = true;
                        net.minecraft.world.effect.MobEffectInstance native$result$13298 = (new net.minecraft.world.effect.MobEffectInstance(native$operand$13293.value(), native$operand$13294, FluxGooBlock.native$MobEffectPlatform$safeAmplifier(native$operand$13293, native$operand$13295), native$operand$13296, native$operand$13297));
                        yield native$result$13298;
                    }
            }));
        }
    }

    @Override
    public void animateTick(BlockState state, Level level, BlockPos pos, RandomSource random) {
        int metadata = state.getValue(LEVEL);
        dev.tc4port.thaumcraft.client.CrucibleBubbleParticle.tickFluxGoo(level, pos, metadata, random);
    }

    /**
     * Native shift-based effects need a smaller ceiling than the stored amplifier byte.
     */
    static private int native$MobEffectPlatform$safeAmplifier(net.minecraft.core.Holder<net.minecraft.world.effect.MobEffect> effect, int amplifier) {
        net.minecraft.world.effect.MobEffect type = effect.value();
        int maximum = type == net.minecraft.world.effect.MobEffects.HEAL || type == net.minecraft.world.effect.MobEffects.HARM ? 16 : type == net.minecraft.world.effect.MobEffects.REGENERATION || type == net.minecraft.world.effect.MobEffects.POISON || type == net.minecraft.world.effect.MobEffects.WITHER ? 31 : 127;
        return java.lang.Math.max(0, java.lang.Math.min(maximum, amplifier));
    }

    static private <B extends net.minecraft.world.level.block.Block> com.mojang.serialization.MapCodec<B> native$BlockCodecPlatform$simple(java.util.function.Function<net.minecraft.world.level.block.state.BlockBehaviour.Properties, B> factory) {
        // Vanilla 1.21's Properties codec is a unit codec. Retain that schema for shared block definitions.
        return com.mojang.serialization.codecs.RecordCodecBuilder.mapCodec(instance -> instance.group(com.mojang.serialization.Codec.unit(net.minecraft.world.level.block.state.BlockBehaviour.Properties::of).fieldOf("properties").forGetter((B block) -> net.minecraft.world.level.block.state.BlockBehaviour.Properties.copy(block))).apply(instance, factory));
    }
}
