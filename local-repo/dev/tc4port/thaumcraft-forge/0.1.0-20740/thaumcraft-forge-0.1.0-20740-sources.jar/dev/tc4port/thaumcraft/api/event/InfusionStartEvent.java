package dev.tc4port.thaumcraft.api.event;

import dev.tc4port.thaumcraft.api.ThaumcraftApi;
import dev.tc4port.thaumcraft.api.aspect.AspectAmounts;
import dev.tc4port.thaumcraft.api.aspect.AspectApi;
import java.util.Objects;
import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;

/**
 * Fired on the native game event bus on the server thread when an infusion
 * matrix has selected a recipe and computed its quote, before the craft starts.
 *
 * <p>The quote already includes recipe data and recipe transformations.
 * Listeners may adjust it for this craft; the matrix then derives the starting
 * instability as {@code symmetry + recipeInstability}, so stability effects
 * change {@link #setSymmetry} or {@link #setRecipeInstability} rather than a
 * final value. The adjusted quote is what the altar shows and charges, and it
 * persists with the craft. Cancel with {@code setCanceled(true)} to refuse the
 * start; the matrix is then left unchanged.</p>
 */
@net.minecraftforge.eventbus.api.Cancelable()
public final class InfusionStartEvent extends net.minecraftforge.eventbus.api.Event {

    private final ServerLevel level;

    private final BlockPos matrix;

    private final Player player;

    private final ResourceLocation recipeId;

    private final boolean enchantment;

    private final ItemStack central;

    private final int pedestalSymmetry;

    private final float stabilizerSymmetry;

    private AspectAmounts aspects;

    private int recipeInstability;

    private int experienceLevels;

    private int symmetry;

    private int essentiaPerPulse;

    private int absorptionPulses;

    public InfusionStartEvent(ServerLevel level, BlockPos matrix, Player player, ResourceLocation recipeId, boolean enchantment, ItemStack central, int pedestalSymmetry, float stabilizerSymmetry, int symmetry, AspectAmounts aspects, int recipeInstability, int experienceLevels, int essentiaPerPulse, int absorptionPulses) {
        this.level = Objects.requireNonNull(level, "level");
        this.matrix = matrix.immutable();
        this.player = Objects.requireNonNull(player, "player");
        this.recipeId = Objects.requireNonNull(recipeId, "recipeId");
        this.enchantment = enchantment;
        this.central = central.copy();
        this.pedestalSymmetry = pedestalSymmetry;
        this.stabilizerSymmetry = stabilizerSymmetry;
        this.symmetry = symmetry;
        this.aspects = Objects.requireNonNull(aspects, "aspects");
        this.recipeInstability = recipeInstability;
        this.experienceLevels = experienceLevels;
        this.essentiaPerPulse = essentiaPerPulse;
        this.absorptionPulses = absorptionPulses;
    }

    public ServerLevel level() {
        return this.level;
    }

    /**
     * The matrix block position.
     */
    public BlockPos matrix() {
        return this.matrix;
    }

    public Player player() {
        return this.player;
    }

    public ResourceLocation recipeId() {
        return this.recipeId;
    }

    /**
     * Whether the selected recipe is an infusion enchantment.
     */
    public boolean enchantment() {
        return this.enchantment;
    }

    /**
     * A copy of the central item.
     */
    public ItemStack central() {
        return this.central.copy();
    }

    /**
     * Pedestal part of the scanned symmetry; positive is less stable.
     */
    public int pedestalSymmetry() {
        return this.pedestalSymmetry;
    }

    /**
     * Stabilizer part of the scanned symmetry before truncation; negative is more stable.
     */
    public float stabilizerSymmetry() {
        return this.stabilizerSymmetry;
    }

    /**
     * Symmetry used for this craft; initially {@code (int)(pedestal + stabilizer)}.
     * The change is kept for the craft and shown with the live scanned symmetry.
     */
    public int symmetry() {
        return this.symmetry;
    }

    public void setSymmetry(int symmetry) {
        this.symmetry = symmetry;
    }

    public AspectAmounts aspects() {
        return this.aspects;
    }

    /**
     * Replaces the essentia requirement; every aspect must be registered.
     */
    public void setAspects(AspectAmounts aspects) {
        Objects.requireNonNull(aspects, "aspects");
        aspects.amounts().keySet().forEach(aspect -> {
            if (AspectApi.registry().get(aspect).isEmpty()) {
                throw new IllegalArgumentException("Unknown aspect " + aspect);
            }
        });
        this.aspects = aspects;
    }

    public int recipeInstability() {
        return this.recipeInstability;
    }

    public void setRecipeInstability(int recipeInstability) {
        if (recipeInstability < 0 || recipeInstability > ThaumcraftApi.MAX_INFUSION_INSTABILITY) {
            throw new IllegalArgumentException("Recipe instability must be 0.." + ThaumcraftApi.MAX_INFUSION_INSTABILITY);
        }
        this.recipeInstability = recipeInstability;
    }

    /**
     * Whole player levels drained from nearby players before essentia. Only
     * enchantment recipes start with a cost, but a listener may add one to any recipe.
     */
    public int experienceLevels() {
        return this.experienceLevels;
    }

    public void setExperienceLevels(int experienceLevels) {
        if (experienceLevels < 0)
            throw new IllegalArgumentException("Experience levels must be non-negative");
        this.experienceLevels = experienceLevels;
    }

    /**
     * Essentia units drawn per work pulse for this craft; defaults to the machine parameter.
     */
    public int essentiaPerPulse() {
        return this.essentiaPerPulse;
    }

    public void setEssentiaPerPulse(int essentiaPerPulse) {
        if (essentiaPerPulse < 1)
            throw new IllegalArgumentException("Essentia per pulse must be positive");
        this.essentiaPerPulse = essentiaPerPulse;
    }

    /**
     * Work pulses each component absorption takes for this craft; defaults to the machine parameter.
     */
    public int absorptionPulses() {
        return this.absorptionPulses;
    }

    public void setAbsorptionPulses(int absorptionPulses) {
        if (absorptionPulses < 1 || absorptionPulses > 1000) {
            throw new IllegalArgumentException("Absorption pulses must be 1..1000");
        }
        this.absorptionPulses = absorptionPulses;
    }
}
