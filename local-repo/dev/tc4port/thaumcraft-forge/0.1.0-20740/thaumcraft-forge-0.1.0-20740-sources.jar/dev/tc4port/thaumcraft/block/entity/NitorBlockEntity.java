package dev.tc4port.thaumcraft.block.entity;

import dev.tc4port.thaumcraft.client.PaletteWispParticle;
import dev.tc4port.thaumcraft.registry.Nitors;
import java.util.function.IntUnaryOperator;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import dev.tc4port.thaumcraft.nativeimpl.state.ItemFields;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityType;

public final class NitorBlockEntity extends net.minecraft.world.level.block.entity.BlockEntity implements ItemFields.Source {

    private static IntUnaryOperator particleCount = base -> 0;

    public NitorBlockEntity(BlockPos pos, BlockState state) {
        super(Nitors.type(), pos, state);
    }

    public static void setParticleCountResolver(IntUnaryOperator resolver) {
        particleCount = resolver;
    }

    public static void clientTick(Level level, BlockPos pos, BlockState state, NitorBlockEntity nitor) {
        if (level.random.nextInt(9 - particleCount.applyAsInt(2)) == 0) {
            PaletteWispParticle.spawnNitorDestination(level, pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5, pos.getX() + 0.3 + level.random.nextFloat() * 0.4F, pos.getY() + 0.5, pos.getZ() + 0.3 + level.random.nextFloat() * 0.4F, 0.5F, 4, true, -0.025F);
        }
        if (level.random.nextInt(15 - particleCount.applyAsInt(4)) == 0) {
            PaletteWispParticle.spawnNitorDestination(level, pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5, pos.getX() + 0.4 + level.random.nextFloat() * 0.2F, pos.getY() + 0.5, pos.getZ() + 0.4 + level.random.nextFloat() * 0.2F, 0.25F, 1, true, -0.02F);
        }
    }

    protected final HolderLookup.Provider persistenceRegistries() {
        if (level != null)
            return level.registryAccess();
        var server = net.minecraftforge.server.ServerLifecycleHooks.getCurrentServer();
        return server != null ? server.registryAccess() : net.minecraft.core.RegistryAccess.fromRegistryOfRegistries(net.minecraft.core.registries.BuiltInRegistries.REGISTRY);
    }

    protected static net.minecraft.network.chat.Component parseCustomNameSafe(String value, HolderLookup.Provider registries) {
        try {
            return net.minecraft.network.chat.Component.Serializer.fromJson(value);
        } catch (RuntimeException exception) {
            return null;
        }
    }

    protected void readItemFields(ItemFields.Input input) {
    }

    public void copyItemFields(ItemFields.Output output) {
    }

    public void applyComponentsFromItemStack(ItemStack stack) {
        readItemFields(ItemFields.from(stack));
    }

    public void removeComponentsFromTag(CompoundTag tag) {
    }

    @Override
    public void saveToItem(ItemStack stack) {
        CompoundTag tag = saveWithoutMetadata();
        {
            net.minecraft.nbt.CompoundTag native$bodyOperand$6196 = tag;
            native$bodyReturn$6198: {
                if (true) {
                }
            }
        }
        net.minecraft.world.item.BlockItem.setBlockEntityData(stack, getType(), tag);
        copyItemFields(ItemFields.to(stack));
    }

    @Override
    public net.minecraft.world.phys.AABB getRenderBoundingBox() {
        return NitorBlockEntity.native$ClientBlockEntityBounds$bounds(this);
    }

    @Override()
    public void onDataPacket(net.minecraft.network.Connection connection, net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket packet) {
        handleUpdateTag(packet.getTag());
    }

    @SuppressWarnings({ "rawtypes", "unchecked" })
    static private net.minecraft.world.phys.AABB native$ClientBlockEntityBounds$bounds(net.minecraft.world.level.block.entity.BlockEntity blockEntity) {
        var renderer = net.minecraft.client.Minecraft.getInstance().getBlockEntityRenderDispatcher().getRenderer(blockEntity);
        return renderer instanceof dev.tc4port.thaumcraft.nativeimpl.NativeBlockEntityRenderer shared ? shared.getRenderBoundingBox(blockEntity) : new net.minecraft.world.phys.AABB(blockEntity.getBlockPos());
    }
}
