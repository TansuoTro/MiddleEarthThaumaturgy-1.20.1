package dev.tc4port.thaumcraft.api.client;

import dev.tc4port.thaumcraft.api.client.ArmorWalkingAnimation;
import net.minecraftforge.client.extensions.common.IClientItemExtensions;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.Model;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;

public interface NativeItemClientExtensions extends IClientItemExtensions {

    default int armorLayerTint(ItemStack stack, LivingEntity entity, boolean dyeable, int index, int fallbackColor) {
        return dyeable ? fallbackColor : 0xFFFFFFFF;
    }

    default int getDefaultDyeColor(ItemStack stack) {
        return stack.getItem() instanceof net.minecraft.world.item.DyeableLeatherItem dyeable ? 0xFF000000 | dyeable.getColor(stack) : 0xFFFFFFFF;
    }

    /**
     * Updates owned armor details after the native body pose has been copied.
     */
    default void animateArmor(LivingEntity entity, ItemStack stack, EquipmentSlot slot, Model model, float limbSwing, float limbSwingAmount) {
    }

    @Override
    default Model getGenericArmorModel(LivingEntity entity, ItemStack stack, EquipmentSlot slot, HumanoidModel<?> original) {
        Model model = IClientItemExtensions.super.getGenericArmorModel(entity, stack, slot, original);
        animateArmor(entity, stack, slot, model, ArmorWalkingAnimation.swing(entity, original), ArmorWalkingAnimation.amount(entity, original));
        return model;
    }
}
