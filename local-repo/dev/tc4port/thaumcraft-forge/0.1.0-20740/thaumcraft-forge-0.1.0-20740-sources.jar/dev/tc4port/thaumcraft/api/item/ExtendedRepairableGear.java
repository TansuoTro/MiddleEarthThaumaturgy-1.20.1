package dev.tc4port.thaumcraft.api.item;

import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;

/**
 * Repairable item that can veto an individual Thaumcraft repair attempt.
 */
public interface ExtendedRepairableGear extends RepairableGear {

    /**
     * Runs on the logical server before vis availability is tested or
     * consumed by the player loop or Arcane Bore. {@code repairLevel} is one
     * or two. The bore supplies its server-side fake player. Returning
     * {@code false} leaves the item and accumulated vis unchanged.
     */
    boolean beforeThaumcraftRepair(ItemStack stack, ServerPlayer player, int repairLevel);
}
