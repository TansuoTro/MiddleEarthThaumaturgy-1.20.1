package dev.tc4port.thaumcraft.api.loot;

/**
 * Loot-bag pool targeted by a runtime entry.
 */
public enum LootBagTier {

    COMMON, UNCOMMON, RARE
}
