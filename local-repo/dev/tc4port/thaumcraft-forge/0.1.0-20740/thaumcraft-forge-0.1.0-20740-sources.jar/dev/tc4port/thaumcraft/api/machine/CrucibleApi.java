package dev.tc4port.thaumcraft.api.machine;

import dev.tc4port.thaumcraft.api.aspect.AspectAmounts;
import dev.tc4port.thaumcraft.api.aspect.AspectApi;
import dev.tc4port.thaumcraft.api.aspect.AspectId;
import dev.tc4port.thaumcraft.block.entity.CrucibleBlockEntity;
import dev.tc4port.thaumcraft.util.RuntimeWarnings;
import java.util.Objects;
import java.util.Optional;
import javax.annotation.Nullable;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

/**
 * Loaded-only access to single steps of TC's own crucible implementation.
 *
 * <p>Each call runs exactly one existing step with its original values. A
 * step called on its own does not satisfy the preconditions its normal call
 * chain checks first (boiling, water, timers); arranging those is the
 * caller's responsibility. Mutating calls run only on the owning server
 * thread and return {@code false} for an unloaded or non-crucible target.
 */
public final class CrucibleApi {

    private CrucibleApi() {
    }

    /**
     * Removes up to {@code amount} of one aspect, dropping the entry when it
     * reaches zero. Like the core step this neither checks that enough is
     * present nor saves or synchronizes; call {@link #changedAndSync} after
     * finishing a group of changes.
     *
     * @return false for an invalid request or unavailable crucible
     */
    public static boolean removeAspect(Level level, BlockPos pos, AspectId aspect, int amount) {
        if (aspect == null || amount <= 0 || AspectApi.registry().get(aspect).isEmpty()) {
            RuntimeWarnings.warnOnce("crucible-remove-aspect", "Ignoring invalid crucible aspect removal request");
            return false;
        }
        CrucibleBlockEntity crucible = serverCrucible(level, pos);
        if (crucible == null) {
            return false;
        }
        crucible.removeAspect(aspect, amount);
        return true;
    }

    /**
     * Saves the crucible and sends the core's client and comparator updates.
     */
    public static boolean changedAndSync(Level level, BlockPos pos) {
        CrucibleBlockEntity crucible = serverCrucible(level, pos);
        if (crucible == null) {
            return false;
        }
        crucible.changedAndSync();
        return true;
    }

    /**
     * Runs one core decomposition: drains its water cost, breaks one random
     * aspect into a component or spills flux for a primal, then synchronizes.
     * It does not check heat or reset the crucible's decomposition timer.
     */
    public static boolean decomposeOneAspect(Level level, BlockPos pos) {
        CrucibleBlockEntity crucible = serverCrucible(level, pos);
        if (crucible == null || crucible.aspects().isEmpty()) {
            return false;
        }
        crucible.decomposeOneAspect((ServerLevel) level);
        return true;
    }

    /**
     * Selects the recipe the core would craft from this catalyst against the
     * crucible's current contents, using the core ordering, aspect check and
     * the owner's research. Water and boiling are not checked. Read-only.
     */
    public static Optional<CrucibleRecipeMatch> findRecipe(Level level, BlockPos pos, ItemStack catalyst, @Nullable Entity owner) {
        Objects.requireNonNull(catalyst, "catalyst");
        CrucibleBlockEntity crucible = loadedCrucible(level, pos);
        if (crucible == null || catalyst.isEmpty()) {
            return Optional.empty();
        }
        var recipes = crucible.orderedRecipes();
        var selected = crucible.findRecipe(recipes, catalyst, owner);
        return recipes.stream().filter(holder -> java.util.Objects.requireNonNull(holder) == selected).findFirst().map(holder -> new CrucibleRecipeMatch(holder.getId(), java.util.Objects.requireNonNull(holder).getResultItem(level.registryAccess()), new AspectAmounts(java.util.Objects.requireNonNull(holder).aspects())));
    }

    /**
     * Ejects items from the crucible exactly as crafted output is ejected.
     * The given stack is consumed (left empty).
     */
    public static boolean ejectItem(Level level, BlockPos pos, ItemStack items) {
        Objects.requireNonNull(items, "items");
        CrucibleBlockEntity crucible = serverCrucible(level, pos);
        if (crucible == null || items.isEmpty()) {
            return false;
        }
        crucible.ejectItem(items);
        return true;
    }

    /**
     * Whether the core treats the block at {@code heatPos} as a crucible heat
     * source. A crucible checks the block directly below itself.
     */
    public static boolean isHeatSource(Level level, BlockPos heatPos) {
        Objects.requireNonNull(level, "level");
        Objects.requireNonNull(heatPos, "heatPos");
        return level.hasChunkAt(heatPos) && CrucibleBlockEntity.hasHeatSource(level, heatPos);
    }

    @Nullable
    private static CrucibleBlockEntity loadedCrucible(Level level, BlockPos pos) {
        Objects.requireNonNull(level, "level");
        Objects.requireNonNull(pos, "pos");
        if ((level instanceof ServerLevel serverLevel && !serverLevel.getServer().isSameThread()) || !level.hasChunkAt(pos) || !(level.getBlockEntity(pos) instanceof CrucibleBlockEntity crucible)) {
            return null;
        }
        return crucible;
    }

    @Nullable
    private static CrucibleBlockEntity serverCrucible(Level level, BlockPos pos) {
        Objects.requireNonNull(level, "level");
        Objects.requireNonNull(pos, "pos");
        if (!(level instanceof ServerLevel)) {
            return null;
        }
        return loadedCrucible(level, pos);
    }
}
