package dev.tc4port.thaumcraft.block;

import dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult;
import com.mojang.serialization.MapCodec;
import dev.tc4port.thaumcraft.block.entity.EssentiaReservoirBlockEntity;
import dev.tc4port.thaumcraft.api.flux.FluxApi;
import dev.tc4port.thaumcraft.common.WandInteractionTarget;
import dev.tc4port.thaumcraft.api.wand.WandCarrierItem;
import dev.tc4port.thaumcraft.registry.TCBlockEntities;
import dev.tc4port.thaumcraft.registry.TCFluids;
import javax.annotation.Nullable;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityTicker;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.DirectionProperty;
import net.minecraft.world.phys.BlockHitResult;
import dev.tc4port.thaumcraft.nativeimpl.ClientExtensionTarget;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.level.pathfinder.PathComputationType;
import net.minecraft.world.phys.HitResult;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.Explosion;
import net.minecraft.world.level.BlockGetter;

/**
 * BlockEssentiaReservoir shell, comparator and destructive spill behavior.
 */
public final class EssentiaReservoirBlock extends net.minecraft.world.level.block.BaseEntityBlock implements WandInteractionTarget, dev.tc4port.thaumcraft.nativeimpl.ClientExtensionTarget {

    // Forge calls initializeClient from the native superclass constructor. Do not add a field initializer.
    private java.util.function.Consumer<net.minecraftforge.client.extensions.common.IClientBlockExtensions> platform$clientInstaller;

    public static final MapCodec<EssentiaReservoirBlock> CODEC = EssentiaReservoirBlock.native$BlockCodecPlatform$simple(EssentiaReservoirBlock::new);

    public static final DirectionProperty FACING = BlockStateProperties.FACING;

    public EssentiaReservoirBlock(BlockBehaviour.Properties properties) {
        this(properties, properties, true);
    }

    protected MapCodec<EssentiaReservoirBlock> codec() {
        return CODEC;
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(FACING);
    }

    @Nullable
    @Override
    public BlockState getStateForPlacement(BlockPlaceContext context) {
        return this.defaultBlockState().setValue(FACING, context.getClickedFace().getOpposite());
    }

    @Nullable
    @Override
    public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        return new EssentiaReservoirBlockEntity(pos, state);
    }

    @Nullable
    @Override
    public <T extends BlockEntity> BlockEntityTicker<T> getTicker(Level level, BlockState state, BlockEntityType<T> type) {
        return createTickerHelper(type, TCBlockEntities.ESSENTIA_RESERVOIR.get(), level.isClientSide ? EssentiaReservoirBlockEntity::clientTick : EssentiaReservoirBlockEntity::serverTick);
    }

    @Override
    public RenderShape getRenderShape(BlockState state) {
        return RenderShape.MODEL;
    }

    protected ItemUseResult interactWithItem(ItemStack stack, BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
        if (!(stack.getItem() instanceof dev.tc4port.thaumcraft.api.wand.WandCarrierItem)) {
            return dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
        }
        net.minecraft.core.Direction facing = player.isShiftKeyDown() ? hit.getDirection() : hit.getDirection().getOpposite();
        if (!level.isClientSide) {
            level.setBlock(pos, state.setValue(dev.tc4port.thaumcraft.block.EssentiaReservoirBlock.FACING, facing), net.minecraft.world.level.block.Block.UPDATE_ALL);
        }
        player.swing(hand);
        return dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.sidedSuccess(level.isClientSide);
    }

    @Override
    public boolean hasAnalogOutputSignal(BlockState state) {
        return true;
    }

    @Override
    public int getAnalogOutputSignal(BlockState state, Level level, BlockPos pos) {
        return level.getBlockEntity(pos) instanceof EssentiaReservoirBlockEntity reservoir ? reservoir.comparatorOutput() : 0;
    }

    @Override
    public void onRemove(BlockState state, Level level, BlockPos pos, BlockState newState, boolean movedByPiston) {
        if (!state.is(newState.getBlock()) && level instanceof ServerLevel serverLevel && level.getBlockEntity(pos) instanceof EssentiaReservoirBlockEntity reservoir) {
            spill(serverLevel, pos, reservoir.totalAmount());
        }
        super.onRemove(state, level, pos, newState, movedByPiston);
    }

    private static void spill(ServerLevel level, BlockPos pos, int totalAmount) {
        int spillSize = totalAmount / 16;
        if (spillSize <= 0) {
            return;
        }
        level.explode(null, pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5, 1.0F, Level.ExplosionInteraction.NONE);
        int placed = 0;
        for (int attempt = 0; attempt < 50; attempt++) {
            BlockPos target = pos.offset(level.random.nextInt(5) - level.random.nextInt(5), level.random.nextInt(5) - level.random.nextInt(5), level.random.nextInt(5) - level.random.nextInt(5));
            if (!level.getBlockState(target).isAir()) {
                continue;
            }
            FluxApi.place(level, target, target.getY() < pos.getY() ? TCFluids.FLUX_GOO.get() : TCFluids.FLUX_GAS.get(), 9, Block.UPDATE_ALL);
            // The original q++ >= sz condition places sz + 1 blocks.
            if (placed++ >= spillSize) {
                break;
            }
        }
    }

    private EssentiaReservoirBlock(net.minecraft.world.level.block.state.BlockBehaviour.Properties native$NativeEntityBlock$arg0, BlockBehaviour.Properties properties, boolean native$NativeEntityBlock$captured) {
        super(native$NativeEntityBlock$arg0);
        this.registerDefaultState(this.stateDefinition.any().setValue(FACING, Direction.DOWN));
    }

    @Override
    public void initializeClient(java.util.function.Consumer<net.minecraftforge.client.extensions.common.IClientBlockExtensions> installer) {
        platform$clientInstaller = installer;
        super.initializeClient(installer);
    }

    @Override
    public void platform$clientExtension(Object extension) {
        java.util.Objects.requireNonNull(platform$clientInstaller, "Forge initializeClient must run before client extension registration").accept((net.minecraftforge.client.extensions.common.IClientBlockExtensions) extension);
    }

    @Override
    public InteractionResult use(BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
        ItemUseResult result = (switch(0) {
            default ->
                {
                    net.minecraft.world.item.ItemStack native$bodyOperand$4411 = player.getItemInHand(hand);
                    net.minecraft.world.level.block.state.BlockState native$bodyOperand$4412 = state;
                    net.minecraft.world.level.Level native$bodyOperand$4413 = level;
                    net.minecraft.core.BlockPos native$bodyOperand$4414 = pos;
                    net.minecraft.world.entity.player.Player native$bodyOperand$4415 = player;
                    net.minecraft.world.InteractionHand native$bodyOperand$4416 = hand;
                    net.minecraft.world.phys.BlockHitResult native$bodyOperand$4417 = hit;
                    dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult native$bodyResult$4419 = null;
                    native$bodyReturn$4420: {
                        if (true) {
                            if (!(native$bodyOperand$4411.getItem() instanceof dev.tc4port.thaumcraft.api.wand.WandCarrierItem)) {
                                {
                                    native$bodyResult$4419 = dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
                                    break native$bodyReturn$4420;
                                }
                            }
                            net.minecraft.core.Direction native$bodyBinding$4418 = native$bodyOperand$4415.isShiftKeyDown() ? native$bodyOperand$4417.getDirection() : native$bodyOperand$4417.getDirection().getOpposite();
                            if (!native$bodyOperand$4413.isClientSide) {
                                native$bodyOperand$4413.setBlock(native$bodyOperand$4414, native$bodyOperand$4412.setValue(dev.tc4port.thaumcraft.block.EssentiaReservoirBlock.FACING, native$bodyBinding$4418), net.minecraft.world.level.block.Block.UPDATE_ALL);
                            }
                            native$bodyOperand$4415.swing(native$bodyOperand$4416);
                            {
                                native$bodyResult$4419 = dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.sidedSuccess(native$bodyOperand$4413.isClientSide);
                                break native$bodyReturn$4420;
                            }
                        }
                    }
                    yield native$bodyResult$4419;
                }
        });
        return result == ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION ? (hand == InteractionHand.MAIN_HAND ? (switch(0) {
            default ->
                {
                    net.minecraft.world.level.block.state.BlockState native$bodyOperand$3659 = state;
                    net.minecraft.world.level.Level native$bodyOperand$3660 = level;
                    net.minecraft.core.BlockPos native$bodyOperand$3661 = pos;
                    net.minecraft.world.entity.player.Player native$bodyOperand$3662 = player;
                    net.minecraft.world.phys.BlockHitResult native$bodyOperand$3663 = hit;
                    net.minecraft.world.InteractionResult native$bodyResult$3664 = null;
                    native$bodyReturn$3665: {
                        if (true) {
                            {
                                native$bodyResult$3664 = super.use(native$bodyOperand$3659, native$bodyOperand$3660, native$bodyOperand$3661, native$bodyOperand$3662, net.minecraft.world.InteractionHand.MAIN_HAND, native$bodyOperand$3663);
                                break native$bodyReturn$3665;
                            }
                        }
                    }
                    yield native$bodyResult$3664;
                }
        }) : InteractionResult.PASS) : result.result();
    }

    protected InteractionResult interactWithoutItem(BlockState state, Level level, BlockPos pos, Player player, BlockHitResult hit) {
        return super.use(state, level, pos, player, net.minecraft.world.InteractionHand.MAIN_HAND, hit);
    }

    @Override
    public void playerWillDestroy(Level level, BlockPos pos, BlockState state, Player player) {
        {
            net.minecraft.world.level.Level native$bodyOperand$5829 = level;
            net.minecraft.core.BlockPos native$bodyOperand$5830 = pos;
            net.minecraft.world.level.block.state.BlockState native$bodyOperand$5831 = state;
            net.minecraft.world.entity.player.Player native$bodyOperand$5832 = player;
            net.minecraft.world.level.block.state.BlockState native$bodyResult$5833 = null;
            native$bodyReturn$5834: {
                if (true) {
                    super.playerWillDestroy(native$bodyOperand$5829, native$bodyOperand$5830, native$bodyOperand$5831, native$bodyOperand$5832);
                    {
                        native$bodyResult$5833 = native$bodyOperand$5831;
                        break native$bodyReturn$5834;
                    }
                }
            }
        }
    }

    public BlockState beforePlayerDestroy(Level level, BlockPos pos, BlockState state, Player player) {
        super.playerWillDestroy(level, pos, state, player);
        return state;
    }

    protected boolean survivesSharedExplosion() {
        return false;
    }

    public int getExpDrop(net.minecraft.world.level.block.state.BlockState native$callbackInput$1050, net.minecraft.world.level.LevelReader native$callbackInput$1051, net.minecraft.util.RandomSource native$callbackInput$1052, net.minecraft.core.BlockPos native$callbackInput$1053, int native$callbackInput$1054, int native$callbackInput$1055) {
        net.minecraft.world.level.block.state.BlockState state = native$callbackInput$1050;
        net.minecraft.util.RandomSource random = native$callbackInput$1052;
        return 0;
    }

    @Override
    public void onBlockExploded(BlockState state, Level level, BlockPos pos, Explosion explosion) {
        if (!(switch(0) {
            default ->
                {
                    boolean native$bodyResult$5263 = false;
                    native$bodyReturn$5264: {
                        if (true) {
                            {
                                native$bodyResult$5263 = false;
                                break native$bodyReturn$5264;
                            }
                        }
                    }
                    yield native$bodyResult$5263;
                }
        }))
            super.onBlockExploded(state, level, pos, explosion);
    }

    @Override
    public boolean canDropFromExplosion(BlockState state, BlockGetter level, BlockPos pos, Explosion explosion) {
        return !(switch(0) {
            default ->
                {
                    boolean native$bodyResult$4421 = false;
                    native$bodyReturn$4422: {
                        if (true) {
                            {
                                native$bodyResult$4421 = false;
                                break native$bodyReturn$4422;
                            }
                        }
                    }
                    yield native$bodyResult$4421;
                }
        }) && super.canDropFromExplosion(state, level, pos, explosion);
    }

    static private <B extends net.minecraft.world.level.block.Block> com.mojang.serialization.MapCodec<B> native$BlockCodecPlatform$simple(java.util.function.Function<net.minecraft.world.level.block.state.BlockBehaviour.Properties, B> factory) {
        // Vanilla 1.21's Properties codec is a unit codec. Retain that schema for shared block definitions.
        return com.mojang.serialization.codecs.RecordCodecBuilder.mapCodec(instance -> instance.group(com.mojang.serialization.Codec.unit(net.minecraft.world.level.block.state.BlockBehaviour.Properties::of).fieldOf("properties").forGetter((B block) -> net.minecraft.world.level.block.state.BlockBehaviour.Properties.copy(block))).apply(instance, factory));
    }
}
