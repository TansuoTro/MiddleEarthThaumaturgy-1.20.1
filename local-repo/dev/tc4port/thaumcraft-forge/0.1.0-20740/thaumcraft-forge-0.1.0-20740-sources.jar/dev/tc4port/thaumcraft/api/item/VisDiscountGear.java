package dev.tc4port.thaumcraft.api.item;

import dev.tc4port.thaumcraft.api.aspect.VisChannel;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;

/**
 * Dynamic owner-item hook for integer-percent wand Vis discounts.
 *
 * <p>Static discounts should use the synchronized equipment-ability Data Map.
 * The callback is read-only, may run on either physical side and must return a
 * non-negative percentage; negative results are treated as zero.</p>
 */
@FunctionalInterface
public interface VisDiscountGear {

    int thaumcraftVisDiscount(ItemStack stack, Player wearer, VisChannel channel);
}
