package dev.tc4port.thaumcraft.api.event;

import java.util.Objects;
import java.util.Optional;
import javax.annotation.Nullable;
import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.item.ItemStack;

/**
 * Fired on the native game event bus on the server thread once a craft has
 * ended and the matrix has cleared its craft state. A listener may start the
 * next craft with {@code InfusionMatrixBlockEntity.startCrafting}, which
 * re-checks structure, research and materials.
 */
public final class InfusionEndEvent extends net.minecraftforge.eventbus.api.Event {

    public enum Outcome {

        /**
         * The result was placed on the central pedestal.
         */
        COMPLETED,
        /**
         * The craft failed: changed recipe, central item or components.
         */
        FAILED,
        /**
         * The craft stopped without a result, for example its recipe was removed.
         */
        STOPPED
    }

    private final ServerLevel level;

    private final BlockPos matrix;

    private final Outcome outcome;

    @Nullable
    private final ResourceLocation recipeId;

    @Nullable
    private final String playerName;

    private final ItemStack output;

    public InfusionEndEvent(ServerLevel level, BlockPos matrix, Outcome outcome, @Nullable ResourceLocation recipeId, @Nullable String playerName, ItemStack output) {
        this.level = Objects.requireNonNull(level, "level");
        this.matrix = matrix.immutable();
        this.outcome = Objects.requireNonNull(outcome, "outcome");
        this.recipeId = recipeId;
        this.playerName = playerName;
        this.output = output.copy();
    }

    public ServerLevel level() {
        return this.level;
    }

    public BlockPos matrix() {
        return this.matrix;
    }

    public Outcome outcome() {
        return this.outcome;
    }

    public Optional<ResourceLocation> recipeId() {
        return Optional.ofNullable(this.recipeId);
    }

    /**
     * The name of the player who started the craft.
     */
    public Optional<String> playerName() {
        return Optional.ofNullable(this.playerName);
    }

    /**
     * A copy of the result for {@link Outcome#COMPLETED}; empty otherwise.
     */
    public ItemStack output() {
        return this.output.copy();
    }
}
