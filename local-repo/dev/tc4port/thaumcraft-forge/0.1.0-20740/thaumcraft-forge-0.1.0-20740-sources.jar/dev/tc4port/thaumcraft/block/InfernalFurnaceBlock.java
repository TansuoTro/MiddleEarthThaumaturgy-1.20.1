package dev.tc4port.thaumcraft.block;

import dev.tc4port.thaumcraft.common.MultiblockFormation;
import dev.tc4port.thaumcraft.nativeimpl.EffectTypes;
import com.mojang.serialization.MapCodec;
import dev.tc4port.thaumcraft.api.ThaumcraftApiHelper;
import dev.tc4port.thaumcraft.api.aspect.VisAction;
import dev.tc4port.thaumcraft.api.aspect.VisPaymentResult;
import dev.tc4port.thaumcraft.block.entity.InfernalFurnaceBlockEntity;
import dev.tc4port.thaumcraft.block.entity.InfernalFurnaceNozzleBlockEntity;
import dev.tc4port.thaumcraft.common.CompoundBlueprintCatalog;
import dev.tc4port.thaumcraft.common.PlayerKnowledgeService;
import dev.tc4port.thaumcraft.common.InfernalFurnaceTextures;
import dev.tc4port.thaumcraft.common.WandVis;
import dev.tc4port.thaumcraft.api.wand.WandCarrierItem;
import dev.tc4port.thaumcraft.network.BlockSparklePayload;
import dev.tc4port.thaumcraft.registry.TCBlockEntities;
import dev.tc4port.thaumcraft.registry.TCBlocks;
import dev.tc4port.thaumcraft.registry.TCSounds;
import java.util.ArrayList;
import java.util.List;
import javax.annotation.Nullable;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.monster.Blaze;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityTicker;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.IntegerProperty;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.pathfinder.PathComputationType;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;
import java.lang.ThreadLocal;
import dev.tc4port.thaumcraft.nativeimpl.ClientExtensionTarget;
import dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.level.Explosion;

/**
 * Metadata 0..10 of TC4's formed 3x3x3 Infernal Furnace.
 */
public final class InfernalFurnaceBlock extends net.minecraft.world.level.block.BaseEntityBlock implements dev.tc4port.thaumcraft.nativeimpl.ClientExtensionTarget {

    // Forge calls initializeClient from the native superclass constructor. Do not add a field initializer.
    private java.util.function.Consumer<net.minecraftforge.client.extensions.common.IClientBlockExtensions> platform$clientInstaller;

    public static final MapCodec<InfernalFurnaceBlock> CODEC = InfernalFurnaceBlock.native$BlockCodecPlatform$simple(InfernalFurnaceBlock::new);

    public static final IntegerProperty PART = IntegerProperty.create("part", 0, 10);

    public static final int CORE_PART = 0;

    // The iron-bar demon mouth ejects items; the obsidian intakes are separate parts.
    public static final int OUTLET_PART = 10;

    private static final VoxelShape CORE_SHAPE = Block.box(0.0, 0.0, 0.0, 16.0, 4.0, 16.0);

    private static final VoxelShape WEST_NOZZLE_SHAPE = Block.box(0.0, 0.0, 0.0, 8.0, 16.0, 16.0);

    private static final VoxelShape EAST_NOZZLE_SHAPE = Block.box(8.0, 0.0, 0.0, 16.0, 16.0, 16.0);

    private static final VoxelShape NORTH_NOZZLE_SHAPE = Block.box(0.0, 0.0, 0.0, 16.0, 16.0, 8.0);

    private static final VoxelShape SOUTH_NOZZLE_SHAPE = Block.box(0.0, 0.0, 8.0, 16.0, 16.0, 16.0);

    private static final ThreadLocal<Boolean> RESTORING = ThreadLocal.withInitial(() -> false);

    public InfernalFurnaceBlock(BlockBehaviour.Properties properties) {
        this(properties, properties, true);
    }

    protected MapCodec<InfernalFurnaceBlock> codec() {
        return CODEC;
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(PART);
    }

    @Nullable
    @Override
    public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        int part = state.getValue(PART);
        if (part == CORE_PART) {
            return new InfernalFurnaceBlockEntity(pos, state);
        }
        if (isIntakePart(part)) {
            return new InfernalFurnaceNozzleBlockEntity(pos, state);
        }
        return null;
    }

    @Nullable
    @Override
    public <T extends BlockEntity> BlockEntityTicker<T> getTicker(Level level, BlockState state, BlockEntityType<T> type) {
        if (level.isClientSide) {
            return null;
        }
        if (state.getValue(PART) == CORE_PART) {
            return createTickerHelper(type, TCBlockEntities.INFERNAL_FURNACE.get(), InfernalFurnaceBlockEntity::serverTick);
        }
        if (isIntakePart(state.getValue(PART))) {
            return createTickerHelper(type, TCBlockEntities.INFERNAL_FURNACE_NOZZLE.get(), InfernalFurnaceNozzleBlockEntity::serverTick);
        }
        return null;
    }

    private static boolean isIntakePart(int part) {
        // Original metadata: four side centers and the bottom center.
        // Repeated parts in the upper/lower rim stay inactive without an adjacent core.
        return part == 2 || part == 4 || part == 5 || part == 6 || part == 8;
    }

    @Override
    public RenderShape getRenderShape(BlockState state) {
        return RenderShape.MODEL;
    }

    @Override
    public VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
        return state.getValue(PART) == CORE_PART ? CORE_SHAPE : Shapes.block();
    }

    @Override
    public VoxelShape getCollisionShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
        int part = state.getValue(PART);
        if (part == CORE_PART) {
            return CORE_SHAPE;
        }
        if (part != OUTLET_PART) {
            return Shapes.block();
        }
        return switch(InfernalFurnaceTextures.nozzleCoreDirection(level, pos, this)) {
            case WEST ->
                WEST_NOZZLE_SHAPE;
            case EAST ->
                EAST_NOZZLE_SHAPE;
            case NORTH ->
                NORTH_NOZZLE_SHAPE;
            case SOUTH ->
                SOUTH_NOZZLE_SHAPE;
            default ->
                SOUTH_NOZZLE_SHAPE;
        };
    }

    @Override
    public VoxelShape getBlockSupportShape(BlockState state, BlockGetter level, BlockPos pos) {
        return state.getValue(PART) == CORE_PART ? Shapes.empty() : Shapes.block();
    }

    @Override
    public void animateTick(BlockState state, Level level, BlockPos pos, RandomSource random) {
        if (state.getValue(PART) != CORE_PART || !level.getBlockState(pos.above()).isAir()) {
            return;
        }
        for (int particle = 0; particle < 3; particle++) {
            level.addParticle(ParticleTypes.LARGE_SMOKE, pos.getX() + random.nextFloat(), pos.getY() + 1.0F + random.nextFloat() * 0.5F, pos.getZ() + random.nextFloat(), 0.0, 0.0, 0.0);
        }
    }

    @Override
    public void entityInside(BlockState state, Level level, BlockPos pos, Entity entity) {
        if (state.getValue(PART) != CORE_PART) {
            return;
        }
        if (entity.getX() < pos.getX() + 0.3) {
            entity.setDeltaMovement(entity.getDeltaMovement().add(0.0001, 0.0, 0.0));
        }
        if (entity.getX() > pos.getX() + 0.7) {
            entity.setDeltaMovement(entity.getDeltaMovement().add(-0.0001, 0.0, 0.0));
        }
        if (entity.getZ() < pos.getZ() + 0.3) {
            entity.setDeltaMovement(entity.getDeltaMovement().add(0.0, 0.0, 0.0001));
        }
        if (entity.getZ() > pos.getZ() + 0.7) {
            entity.setDeltaMovement(entity.getDeltaMovement().add(0.0, 0.0, -0.0001));
        }
        if (entity instanceof ItemEntity item) {
            item.setDeltaMovement(item.getDeltaMovement().x, 0.025, item.getDeltaMovement().z);
            if (!level.isClientSide && item.onGround() && level.getBlockEntity(pos) instanceof InfernalFurnaceBlockEntity furnace && furnace.addDroppedStack(item.getItem())) {
                item.discard();
            }
        } else if (entity instanceof LivingEntity living && !living.fireImmune()) {
            living.hurt(level.damageSources().lava(), 3.0F);
            InfernalFurnaceBlock.native$EntityActions$ignite(living, 10.0F);
        }
    }

    /**
     * Handles the old wand trigger from the three identities actually
     * registered by ConfigRecipes: obsidian, nether brick and iron bars.
     * The central lava is a blueprint member but was never a trigger target.
     */
    public static InteractionResult tryForm(UseOnContext context) {
        Player player = context.getPlayer();
        if (player == null || !(context.getItemInHand().getItem() instanceof WandCarrierItem)) {
            return InteractionResult.PASS;
        }
        BlockPos clicked = context.getClickedPos();
        Level level = context.getLevel();
        BlockState clickedState = level.getBlockState(clicked);
        if (!CompoundBlueprintCatalog.isTrigger(CompoundBlueprintCatalog.INFERNAL_FURNACE, clickedState)) {
            return InteractionResult.PASS;
        }
        var blueprint = CompoundBlueprintCatalog.require(CompoundBlueprintCatalog.INFERNAL_FURNACE);
        if (!PlayerKnowledgeService.get(player).hasCompletedResearch(blueprint.research())) {
            return InteractionResult.FAIL;
        }
        for (int x = -2; x <= 0; x++) {
            for (int y = -2; y <= 0; y++) {
                for (int z = -2; z <= 0; z++) {
                    BlockPos anchor = clicked.offset(x, y, z);
                    if (!fits(level, anchor)) {
                        continue;
                    }
                    ItemStack wand = context.getItemInHand();
                    var cost = WandVis.craftingCost(wand, player, blueprint.aspects());
                    if (ThaumcraftApiHelper.consumeExactVisFromWand(wand, player, cost, VisAction.SIMULATE) != VisPaymentResult.AVAILABLE) {
                        return InteractionResult.FAIL;
                    }
                    if (!level.isClientSide) {
                        List<BlockPos> changed = new ArrayList<>(26);
                        if (!MultiblockFormation.convert((ServerLevel) level, player, context.getClickedFace(), wand, cost, () -> formBlocks((ServerLevel) level, anchor, changed), () -> formationEffects((ServerLevel) level, anchor, changed))) {
                            return InteractionResult.FAIL;
                        }
                    }
                    player.swing(context.getHand());
                    return InteractionResult.sidedSuccess(level.isClientSide);
                }
            }
        }
        return InteractionResult.FAIL;
    }

    public static boolean fits(Level level, BlockPos anchor) {
        return CompoundBlueprintCatalog.matchesFormation(CompoundBlueprintCatalog.INFERNAL_FURNACE, level, anchor.offset(0, 2, 0));
    }

    public static void form(ServerLevel level, BlockPos anchor) {
        List<BlockPos> changed = new ArrayList<>(26);
        if (formBlocks(level, anchor, changed))
            formationEffects(level, anchor, changed);
    }

    private static boolean formBlocks(ServerLevel level, BlockPos anchor, List<BlockPos> changed) {
        for (int y = 0; y < 3; y++) {
            int step = 1;
            for (int z = 0; z < 3; z++) {
                for (int x = 0; x < 3; x++) {
                    BlockPos pos = anchor.offset(x, y, z);
                    BlockState old = level.getBlockState(pos);
                    int part = step;
                    if (old.is(Blocks.LAVA)) {
                        part = CORE_PART;
                    } else if (old.is(Blocks.IRON_BARS)) {
                        part = OUTLET_PART;
                    }
                    if (!old.isAir()) {
                        if (!level.setBlock(pos, TCBlocks.INFERNAL_FURNACE.get().defaultBlockState().setValue(PART, part), Block.UPDATE_ALL))
                            return false;
                        changed.add(pos.immutable());
                    }
                    step++;
                }
            }
        }
        return true;
    }

    private static void formationEffects(ServerLevel level, BlockPos anchor, List<BlockPos> changed) {
        level.playSound(null, anchor, TCSounds.WAND.get(), SoundSource.BLOCKS, 1.0F, 1.0F);
        Vec3 center = Vec3.atCenterOf(anchor.offset(1, 1, 1));
        List<ServerPlayer> observers = level.players().stream().filter(player -> player.distanceToSqr(center) <= 32.0 * 32.0).toList();
        for (BlockPos pos : changed) {
            BlockSparklePayload payload = new BlockSparklePayload(pos, 16_736_256, 5);
            for (ServerPlayer observer : observers) {
                dev.tc4port.thaumcraft.network.TCPayloads.CHANNEL.sendToPlayer(observer, payload);
            }
        }
    }

    @Override
    public void onRemove(BlockState state, Level level, BlockPos pos, BlockState newState, boolean movedByPiston) {
        if (!state.is(newState.getBlock()) && level instanceof ServerLevel server && !RESTORING.get() && !(switch(0) {
            default ->
                {
                    net.minecraft.world.level.Level native$operand$13637 = level;
                    boolean native$result$13638 = (native$operand$13637.restoringBlockSnapshots);
                    yield native$result$13638;
                }
        })) {
            BlockPos core = state.getValue(PART) == CORE_PART ? pos : findCore(level, pos);
            if (core != null) {
                restoreAfterBreak(server, core, pos, state.getValue(PART));
            }
        }
        super.onRemove(state, level, pos, newState, movedByPiston);
    }

    @Nullable
    private static BlockPos findCore(Level level, BlockPos around) {
        for (int y = -1; y <= 1; y++) {
            for (int x = -1; x <= 1; x++) {
                for (int z = -1; z <= 1; z++) {
                    BlockPos check = around.offset(x, y, z);
                    BlockState state = level.getBlockState(check);
                    if (state.is(TCBlocks.INFERNAL_FURNACE.get()) && state.getValue(PART) == CORE_PART) {
                        return check;
                    }
                }
            }
        }
        return null;
    }

    private static void restoreAfterBreak(ServerLevel level, BlockPos core, BlockPos broken, int brokenPart) {
        RESTORING.set(true);
        try {
            BlockPos anchor = core.offset(-1, -1, -1);
            for (int y = 0; y < 3; y++) {
                for (int x = 0; x < 3; x++) {
                    for (int z = 0; z < 3; z++) {
                        BlockPos pos = anchor.offset(x, y, z);
                        BlockState formed = level.getBlockState(pos);
                        if (!formed.is(TCBlocks.INFERNAL_FURNACE.get())) {
                            continue;
                        }
                        int part = formed.getValue(PART);
                        level.setBlock(pos, pos.equals(broken) ? Blocks.AIR.defaultBlockState() : restoredState(part), Block.UPDATE_ALL);
                    }
                }
            }
            if (brokenPart == CORE_PART) {
                spawnBlaze(level, core);
            }
        } finally {
            RESTORING.set(false);
        }
    }

    private static BlockState restoredState(int part) {
        if (part == CORE_PART) {
            return Blocks.AIR.defaultBlockState();
        }
        if (part == OUTLET_PART) {
            return Blocks.IRON_BARS.defaultBlockState();
        }
        return part % 2 != 0 && part != 5 ? Blocks.NETHER_BRICKS.defaultBlockState() : Blocks.OBSIDIAN.defaultBlockState();
    }

    private static void spawnBlaze(ServerLevel level, BlockPos core) {
        Blaze blaze = EntityType.BLAZE.create(level);
        if (blaze == null) {
            return;
        }
        blaze.moveTo(core.getX() + 0.5, core.getY() + 1.0, core.getZ() + 0.5, 0.0F, 0.0F);
        blaze.addEffect((switch(0) {
            default ->
                {
                    net.minecraft.core.Holder<net.minecraft.world.effect.MobEffect> native$operand$14104 = EffectTypes.REGENERATION;
                    int native$operand$14105 = 6000;
                    int native$operand$14106 = 2;
                    net.minecraft.world.effect.MobEffectInstance native$result$14107 = (new net.minecraft.world.effect.MobEffectInstance(native$operand$14104.value(), native$operand$14105, InfernalFurnaceBlock.native$MobEffectPlatform$safeAmplifier(native$operand$14104, native$operand$14106)));
                    yield native$result$14107;
                }
        }));
        blaze.addEffect((switch(0) {
            default ->
                {
                    net.minecraft.core.Holder<net.minecraft.world.effect.MobEffect> native$operand$14108 = EffectTypes.DAMAGE_RESISTANCE;
                    int native$operand$14109 = 12000;
                    int native$operand$14110 = 0;
                    net.minecraft.world.effect.MobEffectInstance native$result$14111 = (new net.minecraft.world.effect.MobEffectInstance(native$operand$14108.value(), native$operand$14109, InfernalFurnaceBlock.native$MobEffectPlatform$safeAmplifier(native$operand$14108, native$operand$14110)));
                    yield native$result$14111;
                }
        }));
        level.addFreshEntity(blaze);
    }

    @Override
    public boolean isPathfindable(BlockState state, BlockGetter level, BlockPos pos, PathComputationType pathType) {
        // The nozzle is a full-height half wall; no part is walk-through.
        return false;
    }

    private InfernalFurnaceBlock(net.minecraft.world.level.block.state.BlockBehaviour.Properties native$NativeEntityBlock$arg0, BlockBehaviour.Properties properties, boolean native$NativeEntityBlock$captured) {
        super(native$NativeEntityBlock$arg0);
        this.registerDefaultState(this.stateDefinition.any().setValue(PART, 1));
    }

    @Override
    public void initializeClient(java.util.function.Consumer<net.minecraftforge.client.extensions.common.IClientBlockExtensions> installer) {
        platform$clientInstaller = installer;
        super.initializeClient(installer);
    }

    @Override
    public void platform$clientExtension(Object extension) {
        java.util.Objects.requireNonNull(platform$clientInstaller, "Forge initializeClient must run before client extension registration").accept((net.minecraftforge.client.extensions.common.IClientBlockExtensions) extension);
    }

    @Override
    public InteractionResult use(BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
        ItemUseResult result = (switch(0) {
            default ->
                {
                    net.minecraft.world.item.ItemStack native$bodyOperand$4507 = player.getItemInHand(hand);
                    net.minecraft.world.level.block.state.BlockState native$bodyOperand$4508 = state;
                    net.minecraft.world.level.Level native$bodyOperand$4509 = level;
                    net.minecraft.core.BlockPos native$bodyOperand$4510 = pos;
                    net.minecraft.world.entity.player.Player native$bodyOperand$4511 = player;
                    net.minecraft.world.InteractionHand native$bodyOperand$4512 = hand;
                    net.minecraft.world.phys.BlockHitResult native$bodyOperand$4513 = hit;
                    dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult native$bodyResult$4514 = null;
                    native$bodyReturn$4515: {
                        if (true) {
                            {
                                native$bodyResult$4514 = dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
                                break native$bodyReturn$4515;
                            }
                        }
                    }
                    yield native$bodyResult$4514;
                }
        });
        return result == ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION ? (hand == InteractionHand.MAIN_HAND ? (switch(0) {
            default ->
                {
                    net.minecraft.world.level.block.state.BlockState native$bodyOperand$3721 = state;
                    net.minecraft.world.level.Level native$bodyOperand$3722 = level;
                    net.minecraft.core.BlockPos native$bodyOperand$3723 = pos;
                    net.minecraft.world.entity.player.Player native$bodyOperand$3724 = player;
                    net.minecraft.world.phys.BlockHitResult native$bodyOperand$3725 = hit;
                    net.minecraft.world.InteractionResult native$bodyResult$3726 = null;
                    native$bodyReturn$3727: {
                        if (true) {
                            {
                                native$bodyResult$3726 = super.use(native$bodyOperand$3721, native$bodyOperand$3722, native$bodyOperand$3723, native$bodyOperand$3724, net.minecraft.world.InteractionHand.MAIN_HAND, native$bodyOperand$3725);
                                break native$bodyReturn$3727;
                            }
                        }
                    }
                    yield native$bodyResult$3726;
                }
        }) : InteractionResult.PASS) : result.result();
    }

    protected ItemUseResult interactWithItem(ItemStack stack, BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
        return dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
    }

    protected InteractionResult interactWithoutItem(BlockState state, Level level, BlockPos pos, Player player, BlockHitResult hit) {
        return super.use(state, level, pos, player, net.minecraft.world.InteractionHand.MAIN_HAND, hit);
    }

    @Override
    public void playerWillDestroy(Level level, BlockPos pos, BlockState state, Player player) {
        {
            net.minecraft.world.level.Level native$bodyOperand$5877 = level;
            net.minecraft.core.BlockPos native$bodyOperand$5878 = pos;
            net.minecraft.world.level.block.state.BlockState native$bodyOperand$5879 = state;
            net.minecraft.world.entity.player.Player native$bodyOperand$5880 = player;
            net.minecraft.world.level.block.state.BlockState native$bodyResult$5881 = null;
            native$bodyReturn$5882: {
                if (true) {
                    super.playerWillDestroy(native$bodyOperand$5877, native$bodyOperand$5878, native$bodyOperand$5879, native$bodyOperand$5880);
                    {
                        native$bodyResult$5881 = native$bodyOperand$5879;
                        break native$bodyReturn$5882;
                    }
                }
            }
        }
    }

    public BlockState beforePlayerDestroy(Level level, BlockPos pos, BlockState state, Player player) {
        super.playerWillDestroy(level, pos, state, player);
        return state;
    }

    protected boolean survivesSharedExplosion() {
        return false;
    }

    public int getExpDrop(net.minecraft.world.level.block.state.BlockState native$callbackInput$1050, net.minecraft.world.level.LevelReader native$callbackInput$1051, net.minecraft.util.RandomSource native$callbackInput$1052, net.minecraft.core.BlockPos native$callbackInput$1053, int native$callbackInput$1054, int native$callbackInput$1055) {
        net.minecraft.world.level.block.state.BlockState state = native$callbackInput$1050;
        net.minecraft.util.RandomSource random = native$callbackInput$1052;
        return 0;
    }

    @Override
    public void onBlockExploded(BlockState state, Level level, BlockPos pos, Explosion explosion) {
        if (!(switch(0) {
            default ->
                {
                    boolean native$bodyResult$5279 = false;
                    native$bodyReturn$5280: {
                        if (true) {
                            {
                                native$bodyResult$5279 = false;
                                break native$bodyReturn$5280;
                            }
                        }
                    }
                    yield native$bodyResult$5279;
                }
        }))
            super.onBlockExploded(state, level, pos, explosion);
    }

    @Override
    public boolean canDropFromExplosion(BlockState state, BlockGetter level, BlockPos pos, Explosion explosion) {
        return !(switch(0) {
            default ->
                {
                    boolean native$bodyResult$4516 = false;
                    native$bodyReturn$4517: {
                        if (true) {
                            {
                                native$bodyResult$4516 = false;
                                break native$bodyReturn$4517;
                            }
                        }
                    }
                    yield native$bodyResult$4516;
                }
        }) && super.canDropFromExplosion(state, level, pos, explosion);
    }

    /**
     * Native shift-based effects need a smaller ceiling than the stored amplifier byte.
     */
    static private int native$MobEffectPlatform$safeAmplifier(net.minecraft.core.Holder<net.minecraft.world.effect.MobEffect> effect, int amplifier) {
        net.minecraft.world.effect.MobEffect type = effect.value();
        int maximum = type == net.minecraft.world.effect.MobEffects.HEAL || type == net.minecraft.world.effect.MobEffects.HARM ? 16 : type == net.minecraft.world.effect.MobEffects.REGENERATION || type == net.minecraft.world.effect.MobEffects.POISON || type == net.minecraft.world.effect.MobEffects.WITHER ? 31 : 127;
        return java.lang.Math.max(0, java.lang.Math.min(maximum, amplifier));
    }

    static private void native$EntityActions$ignite(net.minecraft.world.entity.Entity entity, float seconds) {
        int ticks = net.minecraft.util.Mth.floor(seconds * 20.0F);
        if (entity instanceof net.minecraft.world.entity.LivingEntity living)
            ticks = net.minecraft.world.item.enchantment.ProtectionEnchantment.getFireAfterDampener(living, ticks);
        if (entity.getRemainingFireTicks() < ticks)
            entity.setRemainingFireTicks(ticks);
    }

    static private <B extends net.minecraft.world.level.block.Block> com.mojang.serialization.MapCodec<B> native$BlockCodecPlatform$simple(java.util.function.Function<net.minecraft.world.level.block.state.BlockBehaviour.Properties, B> factory) {
        // Vanilla 1.21's Properties codec is a unit codec. Retain that schema for shared block definitions.
        return com.mojang.serialization.codecs.RecordCodecBuilder.mapCodec(instance -> instance.group(com.mojang.serialization.Codec.unit(net.minecraft.world.level.block.state.BlockBehaviour.Properties::of).fieldOf("properties").forGetter((B block) -> net.minecraft.world.level.block.state.BlockBehaviour.Properties.copy(block))).apply(instance, factory));
    }
}
