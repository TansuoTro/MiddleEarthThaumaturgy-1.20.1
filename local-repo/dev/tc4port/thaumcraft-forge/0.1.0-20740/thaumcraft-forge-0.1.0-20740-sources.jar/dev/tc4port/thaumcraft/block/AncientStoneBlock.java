package dev.tc4port.thaumcraft.block;

import java.util.List;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import dev.tc4port.thaumcraft.nativeimpl.ClientExtensionTarget;
import net.minecraft.world.item.TooltipFlag;

/**
 * The two visually identical TC4 ancient-stone metadata values share one
 * modern registry identity. Structure stone keeps its creature-spawn
 * suppression as block state and only exposes that state on an item when an
 * exact-state recovery path, such as Silk Touch or pick-block, requests it.
 */
public final class AncientStoneBlock extends net.minecraft.world.level.block.Block implements dev.tc4port.thaumcraft.nativeimpl.ClientExtensionTarget {

    // Forge calls initializeClient from the native superclass constructor. Do not add a field initializer.
    private java.util.function.Consumer<net.minecraftforge.client.extensions.common.IClientBlockExtensions> platform$clientInstaller;

    public static final BooleanProperty SPAWN_INHIBITING = BooleanProperty.create("spawn_inhibiting");

    public static final String SPAWN_INHIBITING_TOOLTIP = "tooltip.thaumcraft.ancient_stone.spawn_inhibiting";

    public AncientStoneBlock(BlockBehaviour.Properties properties) {
        this(properties.isValidSpawn((state, level, pos, type) -> !state.getValue(SPAWN_INHIBITING)), properties, true);
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(SPAWN_INHIBITING);
    }

    protected void appendBlockTooltip(ItemStack stack, List<Component> tooltip) {
        if (isSpawnInhibiting(stack)) {
            tooltip.add(net.minecraft.network.chat.Component.translatable(dev.tc4port.thaumcraft.block.AncientStoneBlock.SPAWN_INHIBITING_TOOLTIP).withStyle(net.minecraft.ChatFormatting.LIGHT_PURPLE, net.minecraft.ChatFormatting.ITALIC));
        }
    }

    public ItemStack getCloneItemStack(net.minecraft.world.level.block.state.BlockState native$callbackInput$1131, net.minecraft.world.phys.HitResult native$callbackInput$1132, net.minecraft.world.level.BlockGetter native$callbackInput$1133, net.minecraft.core.BlockPos native$callbackInput$1134, net.minecraft.world.entity.player.Player native$callbackInput$1135) {
        net.minecraft.world.level.block.state.BlockState state = native$callbackInput$1131;
        net.minecraft.world.item.ItemStack stack = super.getCloneItemStack(native$callbackInput$1131, native$callbackInput$1132, native$callbackInput$1133, native$callbackInput$1134, native$callbackInput$1135);
        if (state.getValue(SPAWN_INHIBITING)) {
            AncientStoneBlock.native$BlockItemStatePlatform$set(stack, SPAWN_INHIBITING, true);
        }
        return stack;
    }

    public static boolean isSpawnInhibiting(ItemStack stack) {
        Boolean value = AncientStoneBlock.native$BlockItemStatePlatform$get(stack, SPAWN_INHIBITING);
        return Boolean.TRUE.equals(value);
    }

    private AncientStoneBlock(net.minecraft.world.level.block.state.BlockBehaviour.Properties native$TooltipBlockPlatform$arg0, BlockBehaviour.Properties properties, boolean native$TooltipBlockPlatform$captured) {
        super(native$TooltipBlockPlatform$arg0);
        this.registerDefaultState(this.defaultBlockState().setValue(SPAWN_INHIBITING, false));
    }

    @Override
    public void initializeClient(java.util.function.Consumer<net.minecraftforge.client.extensions.common.IClientBlockExtensions> installer) {
        platform$clientInstaller = installer;
        super.initializeClient(installer);
    }

    @Override
    public void platform$clientExtension(Object extension) {
        java.util.Objects.requireNonNull(platform$clientInstaller, "Forge initializeClient must run before client extension registration").accept((net.minecraftforge.client.extensions.common.IClientBlockExtensions) extension);
    }

    @Override
    public void appendHoverText(ItemStack stack, net.minecraft.world.level.BlockGetter context, List<Component> tooltip, TooltipFlag flag) {
        super.appendHoverText(stack, context, tooltip, flag);
        {
            net.minecraft.world.item.ItemStack native$bodyOperand$5626 = stack;
            java.util.List<net.minecraft.network.chat.Component> native$bodyOperand$5627 = tooltip;
            native$bodyReturn$5629: {
                if (true) {
                    if (isSpawnInhibiting(native$bodyOperand$5626)) {
                        native$bodyOperand$5627.add(net.minecraft.network.chat.Component.translatable(dev.tc4port.thaumcraft.block.AncientStoneBlock.SPAWN_INHIBITING_TOOLTIP).withStyle(net.minecraft.ChatFormatting.LIGHT_PURPLE, net.minecraft.ChatFormatting.ITALIC));
                    }
                }
            }
        }
    }

    static private void native$BlockItemStatePlatform$set(net.minecraft.world.item.ItemStack stack, net.minecraft.world.level.block.state.properties.BooleanProperty property, boolean value) {
        var state = new net.minecraft.nbt.CompoundTag();
        state.putString(property.getName(), property.getName(value));
        stack.getOrCreateTag().put("BlockStateTag", state);
    }

    static private java.lang.Boolean native$BlockItemStatePlatform$get(net.minecraft.world.item.ItemStack stack, net.minecraft.world.level.block.state.properties.BooleanProperty property) {
        var state = stack.getTagElement("BlockStateTag");
        return state == null ? null : property.getValue(state.getString(property.getName())).orElse(null);
    }
}
