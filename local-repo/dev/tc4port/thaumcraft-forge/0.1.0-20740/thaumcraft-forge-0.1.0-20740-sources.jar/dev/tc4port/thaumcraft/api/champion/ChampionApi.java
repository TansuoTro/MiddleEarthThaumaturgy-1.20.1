package dev.tc4port.thaumcraft.api.champion;

import dev.tc4port.thaumcraft.common.ChampionModifierCatalog;
import dev.tc4port.thaumcraft.common.ChampionSystem;
import java.util.Objects;
import java.util.Optional;
import net.minecraft.world.entity.Mob;

/**
 * Stable entry point for champion inspection and authoritative assignment.
 */
public final class ChampionApi {

    private ChampionApi() {
    }

    public static ChampionRegistryView registry() {
        return ChampionModifierCatalog.apiView();
    }

    /**
     * Returns the stable identity synchronized on this mob, when present.
     */
    public static Optional<ChampionId> current(Mob mob) {
        Objects.requireNonNull(mob, "mob");
        return ChampionSystem.championId(mob);
    }

    /**
     * Assigns a definition on the logical server. Creepers may substitute the
     * catalog's configured creeper identity; the result reports that actual
     * identity rather than echoing the request. The despawn policy does not
     * control champion-data serialization and never clears existing vanilla
     * persistence.
     */
    public static ChampionAssignmentResult assign(Mob mob, ChampionId requested, ChampionDespawnPolicy despawnPolicy) {
        Objects.requireNonNull(mob, "mob");
        Objects.requireNonNull(requested, "requested");
        Objects.requireNonNull(despawnPolicy, "despawnPolicy");
        return ChampionSystem.assign(mob, requested, despawnPolicy == ChampionDespawnPolicy.PREVENT_DESPAWN);
    }

    /**
     * Selects from the synchronized catalog's ordered random pool.
     */
    public static ChampionAssignmentResult assignRandom(Mob mob, ChampionDespawnPolicy despawnPolicy) {
        Objects.requireNonNull(mob, "mob");
        Objects.requireNonNull(despawnPolicy, "despawnPolicy");
        return ChampionSystem.assignRandom(mob, despawnPolicy == ChampionDespawnPolicy.PREVENT_DESPAWN);
    }
}
