package dev.tc4port.thaumcraft.api.data;

import com.mojang.serialization.Codec;
import com.mojang.serialization.DataResult;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import dev.tc4port.thaumcraft.api.aspect.VisChannel;
import dev.tc4port.thaumcraft.api.wand.WandMaterialId;
import dev.tc4port.thaumcraft.api.wand.WandPartAssemblyMode;
import dev.tc4port.thaumcraft.api.wand.WandPartLimits;
import dev.tc4port.thaumcraft.api.research.ResearchRequirement;
import java.util.Objects;
import java.util.Set;
import net.minecraft.resources.ResourceLocation;

/**
 * Synced, data-pack-defined properties shared by equivalent wand cap items.
 */
public record WandCapDefinition(WandMaterialId materialId, float baseCostModifier, Set<VisChannel> specialCostModifierAspects, float specialCostModifier, ResourceLocation texture, int craftCost, ResearchRequirement research, WandPartAssemblyMode assemblyMode, int order) {

    private static final Codec<Serialized> SERIALIZED_CODEC = RecordCodecBuilder.create(instance -> instance.group(WandMaterialId.CODEC.fieldOf("material").forGetter(Serialized::materialId), Codec.FLOAT.fieldOf("base_cost_modifier").forGetter(Serialized::baseCostModifier), WandCapDefinition.native$StrictOptionalFields$of(VisChannel.CODEC.listOf().<Set<VisChannel>>xmap(Set::copyOf, aspects -> aspects.stream().sorted(java.util.Comparator.comparingInt(VisChannel::index)).toList()), "special_cost_modifier_aspects", Set.of()).forGetter(Serialized::specialCostModifierAspects), Codec.FLOAT.fieldOf("special_cost_modifier").forGetter(Serialized::specialCostModifier), ResourceLocation.CODEC.fieldOf("texture").forGetter(Serialized::texture), Codec.INT.fieldOf("craft_cost").forGetter(Serialized::craftCost), ResearchRequirement.optionalFieldOf("research").forGetter(Serialized::research), WandCapDefinition.native$StrictOptionalFields$of(WandPartAssemblyMode.CODEC, "assembly_mode", WandPartAssemblyMode.NORMAL).forGetter(Serialized::assemblyMode), WandCapDefinition.native$StrictOptionalFields$of(Codec.INT, "order", 1000).forGetter(Serialized::order)).apply(instance, Serialized::new));

    public static final Codec<WandCapDefinition> CODEC = SERIALIZED_CODEC.comapFlatMap(WandCapDefinition::decode, WandCapDefinition::serialized);

    public WandCapDefinition {
        materialId = Objects.requireNonNull(materialId, "materialId");
        specialCostModifierAspects = Set.copyOf(specialCostModifierAspects);
        texture = Objects.requireNonNull(texture, "texture");
        if (texture.toString().length() > 256) {
            throw new IllegalArgumentException("Wand cap texture IDs must not exceed 256 characters");
        }
        research = Objects.requireNonNull(research, "research");
        assemblyMode = Objects.requireNonNull(assemblyMode, "assemblyMode");
        if (!Float.isFinite(baseCostModifier) || baseCostModifier <= 0.0F || !Float.isFinite(specialCostModifier) || specialCostModifier <= 0.0F || craftCost < 0) {
            throw new IllegalArgumentException("Invalid wand cap definition " + materialId);
        }
        if (craftCost > WandPartLimits.MAX_CRAFT_COST) {
            throw new IllegalArgumentException("Invalid wand cap definition " + materialId);
        }
    }

    private static DataResult<WandCapDefinition> decode(Serialized value) {
        try {
            return DataResult.success(new WandCapDefinition(value.materialId(), value.baseCostModifier(), value.specialCostModifierAspects(), value.specialCostModifier(), value.texture(), value.craftCost(), value.research(), value.assemblyMode(), value.order()));
        } catch (RuntimeException exception) {
            return DataResult.error(() -> "Invalid wand cap definition: " + exception.getMessage());
        }
    }

    private Serialized serialized() {
        return new Serialized(this.materialId, this.baseCostModifier, this.specialCostModifierAspects, this.specialCostModifier, this.texture, this.craftCost, this.research, this.assemblyMode, this.order);
    }

    private record Serialized(WandMaterialId materialId, float baseCostModifier, Set<VisChannel> specialCostModifierAspects, float specialCostModifier, ResourceLocation texture, int craftCost, ResearchRequirement research, WandPartAssemblyMode assemblyMode, int order) {
    }

    /**
     * Compatibility constructor for ordinary, recipe-visible parts.
     */
    public WandCapDefinition(WandMaterialId materialId, float baseCostModifier, Set<VisChannel> specialCostModifierAspects, float specialCostModifier, ResourceLocation texture, int craftCost, ResearchRequirement research, int order) {
        this(materialId, baseCostModifier, specialCostModifierAspects, specialCostModifier, texture, craftCost, research, WandPartAssemblyMode.NORMAL, order);
    }

    static private <A> com.mojang.serialization.MapCodec<java.util.Optional<A>> native$StrictOptionalFields$of(com.mojang.serialization.Codec<A> codec, java.lang.String name) {
        java.util.Objects.requireNonNull(codec, "codec");
        java.util.Objects.requireNonNull(name, "name");
        return new com.mojang.serialization.MapCodec<>() {

            @Override
            public <T> com.mojang.serialization.DataResult<java.util.Optional<A>> decode(com.mojang.serialization.DynamicOps<T> ops, com.mojang.serialization.MapLike<T> input) {
                T value = input.get(name);
                return value == null ? com.mojang.serialization.DataResult.success(java.util.Optional.empty()) : codec.parse(ops, value).map(java.util.Optional::of);
            }

            @Override
            public <T> com.mojang.serialization.RecordBuilder<T> encode(java.util.Optional<A> input, com.mojang.serialization.DynamicOps<T> ops, com.mojang.serialization.RecordBuilder<T> prefix) {
                return input.isPresent() ? prefix.add(name, codec.encodeStart(ops, input.get())) : prefix;
            }

            @Override
            public <T> java.util.stream.Stream<T> keys(com.mojang.serialization.DynamicOps<T> ops) {
                return java.util.stream.Stream.of(ops.createString(name));
            }

            @Override
            public java.lang.String toString() {
                return "StrictOptionalField[" + name + ": " + codec + "]";
            }
        };
    }

    static private <A> com.mojang.serialization.MapCodec<A> native$StrictOptionalFields$of(com.mojang.serialization.Codec<A> codec, java.lang.String name, A defaultValue) {
        return WandCapDefinition.native$StrictOptionalFields$of(codec, name).xmap(value -> value.orElse(defaultValue), value -> java.util.Objects.equals(value, defaultValue) ? java.util.Optional.empty() : java.util.Optional.of(value));
    }
}
