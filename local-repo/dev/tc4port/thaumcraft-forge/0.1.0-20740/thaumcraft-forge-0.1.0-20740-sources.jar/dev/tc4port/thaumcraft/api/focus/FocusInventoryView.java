package dev.tc4port.thaumcraft.api.focus;

import dev.tc4port.thaumcraft.api.aspect.VisAction;
import java.util.List;
import net.minecraft.world.item.ItemStack;

/**
 * Transactional view owned by an item that can store complete foci.
 */
public interface FocusInventoryView {

    /**
     * Defensive, client-safe snapshot of the complete storage in stable slot
     * order. Unrelated item stacks are permitted for mixed inventories; TC
     * compares them during a transaction and requires them to remain intact.
     */
    List<ItemStack> snapshot();

    /**
     * Inserts one count-one focus without permitting nested sources.
     */
    boolean insert(ItemStack focus, VisAction action);

    /**
     * Returns a defensive copy; EXECUTE also removes the selected slot.
     */
    ItemStack extract(int slot, VisAction action);

    /**
     * Owner-defined state version, changed after every successful mutation.
     */
    long version();
}
