package dev.tc4port.thaumcraft.api.client;

import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.crafting.Ingredient;

/**
 * Client-only, frame-local access to a research recipe page. Do not retain it.
 */
public interface ResearchRecipeRenderContext {

    GuiGraphics graphics();

    Font font();

    /**
     * Page origin in the book's logical GUI coordinates.
     */
    int x();

    int y();

    /**
     * Result of the current live recipe, resolved with the level's registries.
     */
    ItemStack output();

    /**
     * Draw a 16-pixel item and retain book tooltips and optional research links.
     */
    void item(ItemStack stack, int offsetX, int offsetY, boolean linkRecipe);

    /**
     * Draw alternatives using the book's ingredient cycle and research links.
     */
    void ingredient(Ingredient ingredient, int offsetX, int offsetY);

    /**
     * Coordinates are relative to the page origin, like item and ingredient.
     */
    boolean isHovered(int offsetX, int offsetY, int width, int height);
}
