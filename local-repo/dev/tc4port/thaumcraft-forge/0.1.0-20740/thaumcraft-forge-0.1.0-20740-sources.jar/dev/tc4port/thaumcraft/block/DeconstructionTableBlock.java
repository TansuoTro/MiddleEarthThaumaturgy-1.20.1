package dev.tc4port.thaumcraft.block;

import com.mojang.serialization.MapCodec;
import dev.tc4port.thaumcraft.block.entity.DeconstructionTableBlockEntity;
import dev.tc4port.thaumcraft.registry.TCBlockEntities;
import javax.annotation.Nullable;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.Containers;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityTicker;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.shapes.VoxelShape;
import dev.tc4port.thaumcraft.nativeimpl.ClientExtensionTarget;
import dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.level.pathfinder.PathComputationType;
import net.minecraft.world.phys.HitResult;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.Explosion;

/**
 * The metadata-14 table identity, split out so it can own its one-slot
 * deconstruction state machine and menu.
 */
public final class DeconstructionTableBlock extends net.minecraft.world.level.block.BaseEntityBlock implements dev.tc4port.thaumcraft.nativeimpl.ClientExtensionTarget {

    // Forge calls initializeClient from the native superclass constructor. Do not add a field initializer.
    private java.util.function.Consumer<net.minecraftforge.client.extensions.common.IClientBlockExtensions> platform$clientInstaller;

    public static final MapCodec<DeconstructionTableBlock> CODEC = DeconstructionTableBlock.native$BlockCodecPlatform$simple(DeconstructionTableBlock::new);

    public DeconstructionTableBlock(BlockBehaviour.Properties properties) {
        this(properties, properties, true);
    }

    protected MapCodec<DeconstructionTableBlock> codec() {
        return CODEC;
    }

    @Nullable
    @Override
    public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        return new DeconstructionTableBlockEntity(pos, state);
    }

    @Override
    public VoxelShape getBlockSupportShape(BlockState state, BlockGetter level, BlockPos pos) {
        return TableBlock.TOP_SUPPORT;
    }

    @Nullable
    @Override
    public <T extends BlockEntity> BlockEntityTicker<T> getTicker(Level level, BlockState state, BlockEntityType<T> type) {
        return level.isClientSide ? null : createTickerHelper(type, TCBlockEntities.DECONSTRUCTION_TABLE.get(), DeconstructionTableBlockEntity::serverTick);
    }

    protected InteractionResult interactWithoutItem(BlockState state, Level level, BlockPos pos, Player player, BlockHitResult hit) {
        if (player.isShiftKeyDown()) {
            return net.minecraft.world.InteractionResult.PASS;
        }
        if (level.isClientSide) {
            return net.minecraft.world.InteractionResult.SUCCESS;
        }
        if (player instanceof net.minecraft.server.level.ServerPlayer serverPlayer && level.getBlockEntity(pos) instanceof dev.tc4port.thaumcraft.block.entity.DeconstructionTableBlockEntity table) {
            net.minecraftforge.network.NetworkHooks.openScreen((net.minecraft.server.level.ServerPlayer) (serverPlayer), (net.minecraft.world.MenuProvider) (table), (java.util.function.Consumer<net.minecraft.network.FriendlyByteBuf>) (buffer -> buffer.writeBlockPos(pos)));
        }
        return net.minecraft.world.InteractionResult.CONSUME;
    }

    @Override
    public void onRemove(BlockState state, Level level, BlockPos pos, BlockState newState, boolean movedByPiston) {
        if (!state.is(newState.getBlock()) && level.getBlockEntity(pos) instanceof DeconstructionTableBlockEntity table) {
            Containers.dropContents(level, pos, table);
        }
        super.onRemove(state, level, pos, newState, movedByPiston);
    }

    @Override
    public RenderShape getRenderShape(BlockState state) {
        return RenderShape.MODEL;
    }

    private DeconstructionTableBlock(net.minecraft.world.level.block.state.BlockBehaviour.Properties native$NativeEntityBlock$arg0, BlockBehaviour.Properties properties, boolean native$NativeEntityBlock$captured) {
        super(native$NativeEntityBlock$arg0);
    }

    @Override
    public void initializeClient(java.util.function.Consumer<net.minecraftforge.client.extensions.common.IClientBlockExtensions> installer) {
        platform$clientInstaller = installer;
        super.initializeClient(installer);
    }

    @Override
    public void platform$clientExtension(Object extension) {
        java.util.Objects.requireNonNull(platform$clientInstaller, "Forge initializeClient must run before client extension registration").accept((net.minecraftforge.client.extensions.common.IClientBlockExtensions) extension);
    }

    @Override
    public InteractionResult use(BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
        ItemUseResult result = (switch(0) {
            default ->
                {
                    net.minecraft.world.item.ItemStack native$bodyOperand$4310 = player.getItemInHand(hand);
                    net.minecraft.world.level.block.state.BlockState native$bodyOperand$4311 = state;
                    net.minecraft.world.level.Level native$bodyOperand$4312 = level;
                    net.minecraft.core.BlockPos native$bodyOperand$4313 = pos;
                    net.minecraft.world.entity.player.Player native$bodyOperand$4314 = player;
                    net.minecraft.world.InteractionHand native$bodyOperand$4315 = hand;
                    net.minecraft.world.phys.BlockHitResult native$bodyOperand$4316 = hit;
                    dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult native$bodyResult$4317 = null;
                    native$bodyReturn$4318: {
                        if (true) {
                            {
                                native$bodyResult$4317 = dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
                                break native$bodyReturn$4318;
                            }
                        }
                    }
                    yield native$bodyResult$4317;
                }
        });
        return result == ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION ? (hand == InteractionHand.MAIN_HAND ? (switch(0) {
            default ->
                {
                    net.minecraft.world.level.block.state.BlockState native$bodyOperand$3593 = state;
                    net.minecraft.world.level.Level native$bodyOperand$3594 = level;
                    net.minecraft.core.BlockPos native$bodyOperand$3595 = pos;
                    net.minecraft.world.entity.player.Player native$bodyOperand$3596 = player;
                    net.minecraft.world.phys.BlockHitResult native$bodyOperand$3597 = hit;
                    net.minecraft.world.InteractionResult native$bodyResult$3601 = null;
                    native$bodyReturn$3602: {
                        if (true) {
                            if (native$bodyOperand$3596.isShiftKeyDown()) {
                                {
                                    native$bodyResult$3601 = net.minecraft.world.InteractionResult.PASS;
                                    break native$bodyReturn$3602;
                                }
                            }
                            if (native$bodyOperand$3594.isClientSide) {
                                {
                                    native$bodyResult$3601 = net.minecraft.world.InteractionResult.SUCCESS;
                                    break native$bodyReturn$3602;
                                }
                            }
                            if (native$bodyOperand$3596 instanceof net.minecraft.server.level.ServerPlayer native$bodyBinding$3598 && native$bodyOperand$3594.getBlockEntity(native$bodyOperand$3595) instanceof dev.tc4port.thaumcraft.block.entity.DeconstructionTableBlockEntity native$bodyBinding$3599) {
                                net.minecraftforge.network.NetworkHooks.openScreen((net.minecraft.server.level.ServerPlayer) (native$bodyBinding$3598), (net.minecraft.world.MenuProvider) (native$bodyBinding$3599), (java.util.function.Consumer<net.minecraft.network.FriendlyByteBuf>) (native$bodyBinding$3600 -> native$bodyBinding$3600.writeBlockPos(native$bodyOperand$3595)));
                            }
                            {
                                native$bodyResult$3601 = net.minecraft.world.InteractionResult.CONSUME;
                                break native$bodyReturn$3602;
                            }
                        }
                    }
                    yield native$bodyResult$3601;
                }
        }) : InteractionResult.PASS) : result.result();
    }

    protected ItemUseResult interactWithItem(ItemStack stack, BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
        return dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
    }

    @Override
    public void playerWillDestroy(Level level, BlockPos pos, BlockState state, Player player) {
        {
            net.minecraft.world.level.Level native$bodyOperand$5775 = level;
            net.minecraft.core.BlockPos native$bodyOperand$5776 = pos;
            net.minecraft.world.level.block.state.BlockState native$bodyOperand$5777 = state;
            net.minecraft.world.entity.player.Player native$bodyOperand$5778 = player;
            net.minecraft.world.level.block.state.BlockState native$bodyResult$5779 = null;
            native$bodyReturn$5780: {
                if (true) {
                    super.playerWillDestroy(native$bodyOperand$5775, native$bodyOperand$5776, native$bodyOperand$5777, native$bodyOperand$5778);
                    {
                        native$bodyResult$5779 = native$bodyOperand$5777;
                        break native$bodyReturn$5780;
                    }
                }
            }
        }
    }

    public BlockState beforePlayerDestroy(Level level, BlockPos pos, BlockState state, Player player) {
        super.playerWillDestroy(level, pos, state, player);
        return state;
    }

    protected boolean survivesSharedExplosion() {
        return false;
    }

    public int getExpDrop(net.minecraft.world.level.block.state.BlockState native$callbackInput$1050, net.minecraft.world.level.LevelReader native$callbackInput$1051, net.minecraft.util.RandomSource native$callbackInput$1052, net.minecraft.core.BlockPos native$callbackInput$1053, int native$callbackInput$1054, int native$callbackInput$1055) {
        net.minecraft.world.level.block.state.BlockState state = native$callbackInput$1050;
        net.minecraft.util.RandomSource random = native$callbackInput$1052;
        return 0;
    }

    @Override
    public void onBlockExploded(BlockState state, Level level, BlockPos pos, Explosion explosion) {
        if (!(switch(0) {
            default ->
                {
                    boolean native$bodyResult$5245 = false;
                    native$bodyReturn$5246: {
                        if (true) {
                            {
                                native$bodyResult$5245 = false;
                                break native$bodyReturn$5246;
                            }
                        }
                    }
                    yield native$bodyResult$5245;
                }
        }))
            super.onBlockExploded(state, level, pos, explosion);
    }

    @Override
    public boolean canDropFromExplosion(BlockState state, BlockGetter level, BlockPos pos, Explosion explosion) {
        return !(switch(0) {
            default ->
                {
                    boolean native$bodyResult$4319 = false;
                    native$bodyReturn$4320: {
                        if (true) {
                            {
                                native$bodyResult$4319 = false;
                                break native$bodyReturn$4320;
                            }
                        }
                    }
                    yield native$bodyResult$4319;
                }
        }) && super.canDropFromExplosion(state, level, pos, explosion);
    }

    static private <B extends net.minecraft.world.level.block.Block> com.mojang.serialization.MapCodec<B> native$BlockCodecPlatform$simple(java.util.function.Function<net.minecraft.world.level.block.state.BlockBehaviour.Properties, B> factory) {
        // Vanilla 1.21's Properties codec is a unit codec. Retain that schema for shared block definitions.
        return com.mojang.serialization.codecs.RecordCodecBuilder.mapCodec(instance -> instance.group(com.mojang.serialization.Codec.unit(net.minecraft.world.level.block.state.BlockBehaviour.Properties::of).fieldOf("properties").forGetter((B block) -> net.minecraft.world.level.block.state.BlockBehaviour.Properties.copy(block))).apply(instance, factory));
    }
}
