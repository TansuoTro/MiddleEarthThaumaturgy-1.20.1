package dev.tc4port.thaumcraft.block;

import com.mojang.serialization.MapCodec;
import dev.tc4port.thaumcraft.client.PaletteWispParticle;
import dev.tc4port.thaumcraft.registry.TCBlocks;
import net.minecraft.core.BlockPos;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;
import dev.tc4port.thaumcraft.nativeimpl.ClientExtensionTarget;
import dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.level.pathfinder.PathComputationType;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.level.Explosion;

/**
 * Invisible, air-like BlockAiry metadata 2/3 identities.
 *
 * <p>Both legacy variants emitted light level 15, were replaceable, counted
 * as air, had neither collision nor a selection box, rendered nothing and
 * dropped nothing. Metadata 3 is the secondary light placed by Arcane Lamps
 * and Arcane Bores.</p>
 */
public final class GlimmerOfLightBlock extends net.minecraft.world.level.block.Block implements dev.tc4port.thaumcraft.nativeimpl.ClientExtensionTarget {

    // Forge calls initializeClient from the native superclass constructor. Do not add a field initializer.
    private java.util.function.Consumer<net.minecraftforge.client.extensions.common.IClientBlockExtensions> platform$clientInstaller;

    public static final MapCodec<GlimmerOfLightBlock> CODEC = GlimmerOfLightBlock.native$BlockCodecPlatform$simple(GlimmerOfLightBlock::new);

    public GlimmerOfLightBlock(BlockBehaviour.Properties properties) {
        this(properties, properties, true);
    }

    protected MapCodec<GlimmerOfLightBlock> codec() {
        return CODEC;
    }

    @Override
    public RenderShape getRenderShape(BlockState state) {
        return RenderShape.INVISIBLE;
    }

    @Override
    public VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
        return Shapes.empty();
    }

    @Override
    public VoxelShape getCollisionShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
        return Shapes.empty();
    }

    @Override
    public VoxelShape getOcclusionShape(BlockState state, BlockGetter level, BlockPos pos) {
        return Shapes.empty();
    }

    @Override
    public void animateTick(BlockState state, Level level, BlockPos pos, RandomSource random) {
        /*
         * Only BlockAiry metadata two had this one-in-five-hundred roaming
         * ember. Metadata three is the lamp/bore secondary light and stayed
         * visually silent despite sharing every block property.
         */
        if (this != TCBlocks.GLIMMER_OF_LIGHT.get() || random.nextInt(500) != 0) {
            return;
        }
        int startX = pos.getX() + random.nextInt(3) - random.nextInt(3);
        int startY = pos.getY() + random.nextInt(3) - random.nextInt(3);
        int startZ = pos.getZ() + random.nextInt(3) - random.nextInt(3);
        int targetX = startX + random.nextInt(3) - random.nextInt(3);
        int targetY = startY + random.nextInt(3) - random.nextInt(3);
        int targetZ = startZ + random.nextInt(3) - random.nextInt(3);
        PaletteWispParticle.spawnDestination(level, startX, startY, startZ, targetX, targetY, targetZ, 0.1F + random.nextFloat() * 0.1F, 7, false, random.nextBoolean() ? -0.033F : 0.033F);
    }

    private GlimmerOfLightBlock(net.minecraft.world.level.block.state.BlockBehaviour.Properties native$NativeBlock$arg0, BlockBehaviour.Properties properties, boolean native$NativeBlock$captured) {
        super(native$NativeBlock$arg0);
    }

    @Override
    public void initializeClient(java.util.function.Consumer<net.minecraftforge.client.extensions.common.IClientBlockExtensions> installer) {
        platform$clientInstaller = installer;
        super.initializeClient(installer);
    }

    @Override
    public void platform$clientExtension(Object extension) {
        java.util.Objects.requireNonNull(platform$clientInstaller, "Forge initializeClient must run before client extension registration").accept((net.minecraftforge.client.extensions.common.IClientBlockExtensions) extension);
    }

    @Override
    public InteractionResult use(BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
        ItemUseResult result = (switch(0) {
            default ->
                {
                    net.minecraft.world.item.ItemStack native$bodyOperand$4463 = player.getItemInHand(hand);
                    net.minecraft.world.level.block.state.BlockState native$bodyOperand$4464 = state;
                    net.minecraft.world.level.Level native$bodyOperand$4465 = level;
                    net.minecraft.core.BlockPos native$bodyOperand$4466 = pos;
                    net.minecraft.world.entity.player.Player native$bodyOperand$4467 = player;
                    net.minecraft.world.InteractionHand native$bodyOperand$4468 = hand;
                    net.minecraft.world.phys.BlockHitResult native$bodyOperand$4469 = hit;
                    dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult native$bodyResult$4470 = null;
                    native$bodyReturn$4471: {
                        if (true) {
                            {
                                native$bodyResult$4470 = dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
                                break native$bodyReturn$4471;
                            }
                        }
                    }
                    yield native$bodyResult$4470;
                }
        });
        return result == ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION ? (hand == InteractionHand.MAIN_HAND ? (switch(0) {
            default ->
                {
                    net.minecraft.world.level.block.state.BlockState native$bodyOperand$3691 = state;
                    net.minecraft.world.level.Level native$bodyOperand$3692 = level;
                    net.minecraft.core.BlockPos native$bodyOperand$3693 = pos;
                    net.minecraft.world.entity.player.Player native$bodyOperand$3694 = player;
                    net.minecraft.world.phys.BlockHitResult native$bodyOperand$3695 = hit;
                    net.minecraft.world.InteractionResult native$bodyResult$3696 = null;
                    native$bodyReturn$3697: {
                        if (true) {
                            {
                                native$bodyResult$3696 = super.use(native$bodyOperand$3691, native$bodyOperand$3692, native$bodyOperand$3693, native$bodyOperand$3694, net.minecraft.world.InteractionHand.MAIN_HAND, native$bodyOperand$3695);
                                break native$bodyReturn$3697;
                            }
                        }
                    }
                    yield native$bodyResult$3696;
                }
        }) : InteractionResult.PASS) : result.result();
    }

    protected ItemUseResult interactWithItem(ItemStack stack, BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
        return dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
    }

    protected InteractionResult interactWithoutItem(BlockState state, Level level, BlockPos pos, Player player, BlockHitResult hit) {
        return super.use(state, level, pos, player, net.minecraft.world.InteractionHand.MAIN_HAND, hit);
    }

    @Override
    public void playerWillDestroy(Level level, BlockPos pos, BlockState state, Player player) {
        {
            net.minecraft.world.level.Level native$bodyOperand$5853 = level;
            net.minecraft.core.BlockPos native$bodyOperand$5854 = pos;
            net.minecraft.world.level.block.state.BlockState native$bodyOperand$5855 = state;
            net.minecraft.world.entity.player.Player native$bodyOperand$5856 = player;
            net.minecraft.world.level.block.state.BlockState native$bodyResult$5857 = null;
            native$bodyReturn$5858: {
                if (true) {
                    super.playerWillDestroy(native$bodyOperand$5853, native$bodyOperand$5854, native$bodyOperand$5855, native$bodyOperand$5856);
                    {
                        native$bodyResult$5857 = native$bodyOperand$5855;
                        break native$bodyReturn$5858;
                    }
                }
            }
        }
    }

    public BlockState beforePlayerDestroy(Level level, BlockPos pos, BlockState state, Player player) {
        super.playerWillDestroy(level, pos, state, player);
        return state;
    }

    protected boolean survivesSharedExplosion() {
        return false;
    }

    public int getExpDrop(net.minecraft.world.level.block.state.BlockState native$callbackInput$1145, net.minecraft.world.level.LevelReader native$callbackInput$1146, net.minecraft.util.RandomSource native$callbackInput$1147, net.minecraft.core.BlockPos native$callbackInput$1148, int native$callbackInput$1149, int native$callbackInput$1150) {
        net.minecraft.world.level.block.state.BlockState state = native$callbackInput$1145;
        net.minecraft.util.RandomSource random = native$callbackInput$1147;
        return 0;
    }

    @Override
    public void onBlockExploded(BlockState state, Level level, BlockPos pos, Explosion explosion) {
        if (!(switch(0) {
            default ->
                {
                    boolean native$bodyResult$5271 = false;
                    native$bodyReturn$5272: {
                        if (true) {
                            {
                                native$bodyResult$5271 = false;
                                break native$bodyReturn$5272;
                            }
                        }
                    }
                    yield native$bodyResult$5271;
                }
        }))
            super.onBlockExploded(state, level, pos, explosion);
    }

    @Override
    public boolean canDropFromExplosion(BlockState state, BlockGetter level, BlockPos pos, Explosion explosion) {
        return !(switch(0) {
            default ->
                {
                    boolean native$bodyResult$4472 = false;
                    native$bodyReturn$4473: {
                        if (true) {
                            {
                                native$bodyResult$4472 = false;
                                break native$bodyReturn$4473;
                            }
                        }
                    }
                    yield native$bodyResult$4472;
                }
        }) && super.canDropFromExplosion(state, level, pos, explosion);
    }

    static private <B extends net.minecraft.world.level.block.Block> com.mojang.serialization.MapCodec<B> native$BlockCodecPlatform$simple(java.util.function.Function<net.minecraft.world.level.block.state.BlockBehaviour.Properties, B> factory) {
        // Vanilla 1.21's Properties codec is a unit codec. Retain that schema for shared block definitions.
        return com.mojang.serialization.codecs.RecordCodecBuilder.mapCodec(instance -> instance.group(com.mojang.serialization.Codec.unit(net.minecraft.world.level.block.state.BlockBehaviour.Properties::of).fieldOf("properties").forGetter((B block) -> net.minecraft.world.level.block.state.BlockBehaviour.Properties.copy(block))).apply(instance, factory));
    }
}
