package dev.tc4port.thaumcraft.block.entity;

import dev.tc4port.thaumcraft.registry.TCSounds;
import dev.tc4port.thaumcraft.block.ArcaneBellowsBlock;
import dev.tc4port.thaumcraft.registry.TCBlockEntities;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.FurnaceBlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import dev.tc4port.thaumcraft.nativeimpl.state.ItemFields;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityType;

/**
 * Bellows pulse state and the original regular-furnace acceleration hook.
 */
public final class ArcaneBellowsBlockEntity extends net.minecraft.world.level.block.entity.BlockEntity implements ItemFields.Source {

    private static final String VANILLA_FURNACE_KEY = "onVanillaFurnace";

    private int serverDelay;

    private boolean onVanillaFurnace;

    private boolean expanding;

    private boolean firstClientTick = true;

    private float inflation = 1.0F;

    public ArcaneBellowsBlockEntity(BlockPos pos, BlockState state) {
        super(TCBlockEntities.ARCANE_BELLOWS.get(), pos, state);
    }

    public static void serverTick(Level level, BlockPos pos, BlockState state, ArcaneBellowsBlockEntity bellows) {
        if (!bellows.onVanillaFurnace || !level.hasChunksAt(pos.offset(-2, 0, -2), pos.offset(2, 0, 2)) || level.hasNeighborSignal(pos) || ++bellows.serverDelay < 2) {
            return;
        }
        bellows.serverDelay = 0;
        Direction facing = state.getValue(ArcaneBellowsBlock.FACING);
        /*
         * TileBellows deliberately omitted orientation.offsetY in this one
         * vanilla-furnace lookup.  Vertical bellows can still serve TC
         * machines through getBellows, but never accelerate a furnace.
         */
        BlockPos targetPos = pos.offset(facing.getStepX(), 0, facing.getStepZ());
        if (!level.isLoaded(targetPos) || !(level.getBlockEntity(targetPos) instanceof FurnaceBlockEntity furnace)) {
            return;
        }
        if ((switch(0) {
            default ->
                {
                    net.minecraft.world.level.block.entity.AbstractFurnaceBlockEntity native$operand$13639 = furnace;
                    int native$result$13640 = (((dev.tc4port.thaumcraft.nativeimpl.mixin.FurnaceAccessor) native$operand$13639).platform$progress());
                    yield native$result$13640;
                }
        }) > 0 && (switch(0) {
            default ->
                {
                    net.minecraft.world.level.block.entity.AbstractFurnaceBlockEntity native$operand$13641 = furnace;
                    int native$result$13642 = (((dev.tc4port.thaumcraft.nativeimpl.mixin.FurnaceAccessor) native$operand$13641).platform$progress());
                    yield native$result$13642;
                }
        }) < 199) {
            {
                net.minecraft.world.level.block.entity.AbstractFurnaceBlockEntity native$operand$13643 = furnace;
                int native$operand$13644 = (switch(0) {
                    default ->
                        {
                            net.minecraft.world.level.block.entity.AbstractFurnaceBlockEntity native$operand$13104 = furnace;
                            int native$result$13105 = (((dev.tc4port.thaumcraft.nativeimpl.mixin.FurnaceAccessor) native$operand$13104).platform$progress());
                            yield native$result$13105;
                        }
                }) + 1;
                ((dev.tc4port.thaumcraft.nativeimpl.mixin.FurnaceAccessor) native$operand$13643).platform$progress(native$operand$13644);
            }
            furnace.setChanged();
        }
    }

    public static void clientTick(Level level, BlockPos pos, BlockState state, ArcaneBellowsBlockEntity bellows) {
        if (level.hasNeighborSignal(pos)) {
            return;
        }
        if (bellows.firstClientTick) {
            bellows.inflation = 0.35F + level.random.nextFloat() * 0.55F;
            bellows.firstClientTick = false;
        }
        if (!bellows.expanding) {
            bellows.inflation -= 0.075F;
            if (bellows.inflation <= 0.35F) {
                bellows.inflation = 0.35F;
                bellows.expanding = true;
            }
            return;
        }
        bellows.inflation += 0.025F;
        if (bellows.inflation >= 1.0F) {
            bellows.inflation = 1.0F;
            bellows.expanding = false;
            level.playLocalSound(pos, TCSounds.BELLOWS_BLOW.get(), SoundSource.BLOCKS, 0.01F, 0.5F + (level.random.nextFloat() - level.random.nextFloat()) * 0.2F, false);
        }
    }

    public float inflation() {
        return this.inflation;
    }

    public void setOnVanillaFurnace(boolean onVanillaFurnace) {
        this.onVanillaFurnace = onVanillaFurnace;
        this.setChanged();
    }

    public boolean onVanillaFurnace() {
        return this.onVanillaFurnace;
    }

    @Override
    protected void saveAdditional(CompoundTag tag) {
        super.saveAdditional(tag);
        tag.putBoolean(VANILLA_FURNACE_KEY, this.onVanillaFurnace);
    }

    @Override
    public void load(CompoundTag tag) {
        super.load(tag);
        this.onVanillaFurnace = tag.getBoolean(VANILLA_FURNACE_KEY);
    }

    protected final HolderLookup.Provider persistenceRegistries() {
        if (level != null)
            return level.registryAccess();
        var server = net.minecraftforge.server.ServerLifecycleHooks.getCurrentServer();
        return server != null ? server.registryAccess() : net.minecraft.core.RegistryAccess.fromRegistryOfRegistries(net.minecraft.core.registries.BuiltInRegistries.REGISTRY);
    }

    protected static net.minecraft.network.chat.Component parseCustomNameSafe(String value, HolderLookup.Provider registries) {
        try {
            return net.minecraft.network.chat.Component.Serializer.fromJson(value);
        } catch (RuntimeException exception) {
            return null;
        }
    }

    protected void readItemFields(ItemFields.Input input) {
    }

    public void copyItemFields(ItemFields.Output output) {
    }

    public void applyComponentsFromItemStack(ItemStack stack) {
        readItemFields(ItemFields.from(stack));
    }

    public void removeComponentsFromTag(CompoundTag tag) {
    }

    @Override
    public void saveToItem(ItemStack stack) {
        CompoundTag tag = saveWithoutMetadata();
        {
            net.minecraft.nbt.CompoundTag native$bodyOperand$6093 = tag;
            native$bodyReturn$6095: {
                if (true) {
                }
            }
        }
        net.minecraft.world.item.BlockItem.setBlockEntityData(stack, getType(), tag);
        copyItemFields(ItemFields.to(stack));
    }

    @Override
    public net.minecraft.world.phys.AABB getRenderBoundingBox() {
        return ArcaneBellowsBlockEntity.native$ClientBlockEntityBounds$bounds(this);
    }

    @Override()
    public void onDataPacket(net.minecraft.network.Connection connection, net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket packet) {
        handleUpdateTag(packet.getTag());
    }

    @SuppressWarnings({ "rawtypes", "unchecked" })
    static private net.minecraft.world.phys.AABB native$ClientBlockEntityBounds$bounds(net.minecraft.world.level.block.entity.BlockEntity blockEntity) {
        var renderer = net.minecraft.client.Minecraft.getInstance().getBlockEntityRenderDispatcher().getRenderer(blockEntity);
        return renderer instanceof dev.tc4port.thaumcraft.nativeimpl.NativeBlockEntityRenderer shared ? shared.getRenderBoundingBox(blockEntity) : new net.minecraft.world.phys.AABB(blockEntity.getBlockPos());
    }
}
