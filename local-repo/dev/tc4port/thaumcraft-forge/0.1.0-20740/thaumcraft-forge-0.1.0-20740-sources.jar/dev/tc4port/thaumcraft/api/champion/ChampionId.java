package dev.tc4port.thaumcraft.api.champion;

import com.mojang.serialization.Codec;
import com.mojang.serialization.DataResult;
import java.util.Objects;
import net.minecraft.resources.ResourceLocation;

/**
 * Stable namespaced identity of one champion modifier definition.
 */
public record ChampionId(ResourceLocation value) {

    public static final Codec<ChampionId> CODEC = Codec.STRING.comapFlatMap(value -> {
        try {
            return DataResult.success(parse(value));
        } catch (IllegalArgumentException exception) {
            return DataResult.error(exception::getMessage);
        }
    }, ChampionId::toString);

    public ChampionId {
        Objects.requireNonNull(value, "value");
        if (value.toString().length() > 256) {
            throw new IllegalArgumentException("Champion ID is too long");
        }
    }

    public static ChampionId of(ResourceLocation value) {
        return new ChampionId(value);
    }

    public static ChampionId parse(String value) {
        if (value == null || value.isBlank()) {
            throw new IllegalArgumentException("Champion ID must not be blank");
        }
        ResourceLocation parsed = value.indexOf(':') < 0 ? null : ResourceLocation.tryParse(value);
        if (parsed == null) {
            throw new IllegalArgumentException("Invalid champion ID " + value);
        }
        return new ChampionId(parsed);
    }

    @Override
    public String toString() {
        return this.value.toString();
    }
}
