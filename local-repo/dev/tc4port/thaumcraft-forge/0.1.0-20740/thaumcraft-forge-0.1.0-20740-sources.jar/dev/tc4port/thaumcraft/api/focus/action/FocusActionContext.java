package dev.tc4port.thaumcraft.api.focus.action;

import dev.tc4port.thaumcraft.api.aspect.VisAction;
import dev.tc4port.thaumcraft.api.aspect.VisConsumptionContext;
import dev.tc4port.thaumcraft.api.aspect.VisCost;
import dev.tc4port.thaumcraft.api.aspect.VisPaymentResult;
import dev.tc4port.thaumcraft.api.focus.FocusStateView;
import dev.tc4port.thaumcraft.api.focus.FocusUpgradeId;
import java.util.Map;
import javax.annotation.Nullable;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

public interface FocusActionContext {

    ServerPlayer player();

    InteractionHand hand();

    ItemStack wand();

    FocusStateView installedFocus();

    Map<FocusUpgradeId, Integer> installedUpgrades();

    default double parameter(String key) {
        return dev.tc4port.thaumcraft.api.focus.FocusApi.registry().profile(installedFocus().focusId()).orElseThrow().parameters().value(key, installedUpgrades());
    }

    /**
     * Parameters and damage modifiers captured together for this cast's projectiles or summons.
     */
    default dev.tc4port.thaumcraft.api.focus.FocusParameterValues resolvedParameters() {
        return dev.tc4port.thaumcraft.api.focus.FocusParameterValues.resolve(installedFocus().focusId(), installedUpgrades(), player());
    }

    default VisCost configuredCost() {
        return dev.tc4port.thaumcraft.api.focus.FocusApi.registry().profile(installedFocus().focusId()).orElseThrow().fixedCost(installedUpgrades()).orElseThrow(() -> new IllegalStateException("Focus action needs a fixed cost"));
    }

    default VisCost configuredCost(String action) {
        VisCost cost = dev.tc4port.thaumcraft.api.focus.FocusApi.registry().profile(installedFocus().focusId()).orElseThrow().actionCosts().get(action);
        if (cost == null)
            throw new IllegalArgumentException("Missing focus action cost: " + action);
        return cost;
    }

    FocusActivation activation();

    HitResult authoritativeHit();

    int useTicks();

    /**
     * Stable world-space position of the installed focus at the wand tip.
     *
     * <p>Use this for server-authored projectile and effect origins. Client
     * beam renderers should resolve the latest actually rendered tip through
     * {@code ThaumcraftClientRenderApi.resolveFocusCastOrigin}. Thaumcraft's
     * context overrides the compatibility default with its selected-hand
     * wand-tip calculation.</p>
     */
    default Vec3 castOrigin() {
        Vec3 look = player().getLookAngle();
        return player().getEyePosition().add(look.scale(0.5D));
    }

    /**
     * The pre-debit authorization token during EXECUTE. Registrations without
     * an authorizer, and SIMULATE calls, receive an allowed empty token.
     */
    default FocusAuthorization authorization() {
        return FocusAuthorization.allow();
    }

    /**
     * Adds one bounded audiovisual event to this focus transaction.
     *
     * <p>Thaumcraft validates but does not publish calls made during
     * {@link VisAction#SIMULATE}. Calls made during EXECUTE are buffered until
     * every action and Vis replay succeeds, so a later failure cannot leak a
     * false success effect. {@link
     * dev.tc4port.thaumcraft.api.presentation.ActionPresentationAudience#PREDICTED}
     * confirms only to observers because the casting client already received
     * the action's normal predicted callback. Use {@code CONFIRMED_ALL} for
     * server-owned secondary targets that could not be predicted safely.
     * Explicit events are delivered after a successful transaction even when
     * the action metadata does not request an automatic confirmation.</p>
     */
    void present(Vec3 origin, Vec3 target, @Nullable Entity targetEntity, double detail, int value, dev.tc4port.thaumcraft.api.presentation.ActionPresentationAudience audience);

    VisPaymentResult pay(VisCost cost, VisAction action);

    void setCooldown(int ticks);
}
