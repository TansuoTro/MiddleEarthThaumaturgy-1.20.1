package dev.tc4port.thaumcraft.api.golem;

import dev.tc4port.thaumcraft.entity.GolemMarker;
import dev.tc4port.thaumcraft.entity.ThaumcraftGolemEntity;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.GlobalPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Entity;

/**
 * Bounded server-authoritative writes for TC-owned golem home state.
 */
public final class GolemControlApi {

    public static final int MAX_MARKERS = 64;

    private GolemControlApi() {
    }

    public static GolemControlResult setHome(ServerLevel level, Entity entity, GlobalPos home, Direction homeSide) {
        Objects.requireNonNull(level, "level");
        Objects.requireNonNull(entity, "entity");
        Objects.requireNonNull(home, "home");
        Objects.requireNonNull(homeSide, "homeSide");
        GolemControlResult preflight = preflight(level, entity);
        if (preflight != null) {
            return preflight;
        }
        BlockPos homePosition = home.pos().immutable();
        if (!home.dimension().equals(level.dimension()) || !level.isInWorldBounds(homePosition) || !level.hasChunkAt(homePosition)) {
            return GolemControlResult.INVALID_TARGET;
        }
        ThaumcraftGolemEntity golem = (ThaumcraftGolemEntity) entity;
        if (golem.hasRestriction() && golem.getRestrictCenter().equals(homePosition) && golem.getHomeFace() == homeSide) {
            return GolemControlResult.UNCHANGED;
        }
        golem.setControlledHome(homePosition, homeSide);
        return GolemControlResult.UPDATED;
    }

    public static GolemControlResult replaceMarkers(ServerLevel level, Entity entity, List<GolemMarkerView> markers) {
        Objects.requireNonNull(level, "level");
        Objects.requireNonNull(entity, "entity");
        Objects.requireNonNull(markers, "markers");
        GolemControlResult preflight = preflight(level, entity);
        if (preflight != null) {
            return preflight;
        }
        if (markers.size() > MAX_MARKERS) {
            return GolemControlResult.INVALID_TARGET;
        }
        ArrayList<GolemMarker> checked = new ArrayList<>(markers.size());
        for (GolemMarkerView marker : markers) {
            BlockPos markerPosition = marker == null ? null : marker.position().pos().immutable();
            if (marker == null || !marker.position().dimension().equals(level.dimension()) || !level.isInWorldBounds(markerPosition) || !level.hasChunkAt(markerPosition)) {
                return GolemControlResult.INVALID_TARGET;
            }
            GolemMarker converted = new GolemMarker(markerPosition, level.dimension(), marker.side(), (byte) marker.color());
            if (checked.stream().anyMatch(existing -> existing.pos().equals(converted.pos()) && existing.side() == converted.side())) {
                return GolemControlResult.INVALID_TARGET;
            }
            checked.add(converted);
        }
        ThaumcraftGolemEntity golem = (ThaumcraftGolemEntity) entity;
        if (golem.markerSnapshot().equals(checked)) {
            return GolemControlResult.UNCHANGED;
        }
        golem.setMarkers(List.copyOf(checked));
        return GolemControlResult.UPDATED;
    }

    private static GolemControlResult preflight(ServerLevel level, Entity entity) {
        if (!level.getServer().isSameThread()) {
            return GolemControlResult.OFF_SERVER_THREAD;
        }
        if (!(entity instanceof ThaumcraftGolemEntity)) {
            return GolemControlResult.NOT_A_GOLEM;
        }
        if (entity.level() != level) {
            return GolemControlResult.WRONG_LEVEL;
        }
        if (!entity.isAlive() || entity.isRemoved()) {
            return GolemControlResult.INVALID_TARGET;
        }
        return null;
    }
}
