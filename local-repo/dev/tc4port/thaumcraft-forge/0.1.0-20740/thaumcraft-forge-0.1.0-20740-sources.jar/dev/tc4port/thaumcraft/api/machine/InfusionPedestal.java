package dev.tc4port.thaumcraft.api.machine;

import net.minecraft.world.item.ItemStack;

/**
 * A pedestal's held stack and explicit server-side removal operation.
 */
public interface InfusionPedestal {

    ItemStack item();

    /**
     * Replaces the native container slot; core pedestals expose slot zero.
     */
    void setItem(int slot, ItemStack stack);

    void clearContent();
}
