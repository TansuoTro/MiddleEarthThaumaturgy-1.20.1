package dev.tc4port.thaumcraft.api.inventory;

/**
 * A slot whose displayed item is a template and should use native fake-item rendering.
 */
public interface FakeSlot {

    boolean isFake();
}
