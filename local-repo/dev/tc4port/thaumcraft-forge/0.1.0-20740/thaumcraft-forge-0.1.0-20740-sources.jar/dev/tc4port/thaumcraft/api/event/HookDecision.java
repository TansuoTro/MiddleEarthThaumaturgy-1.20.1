package dev.tc4port.thaumcraft.api.event;

public record HookDecision(boolean isCanceled) {
}
