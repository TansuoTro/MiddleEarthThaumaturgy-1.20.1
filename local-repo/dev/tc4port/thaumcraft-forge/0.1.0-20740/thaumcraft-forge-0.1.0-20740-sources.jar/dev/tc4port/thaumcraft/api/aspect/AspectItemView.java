package dev.tc4port.thaumcraft.api.aspect;

import net.minecraft.world.item.ItemStack;

/**
 * Item-owned, read-only persisted aspect data used by scanning and recipes.
 *
 * <p>The item implementation owns its storage format and invariants. This
 * avoids treating unrelated internal data components (for example centivis
 * storage) as whole-aspect contents. Stored unknown IDs may be returned so
 * they survive a removed data pack; gameplay callers use
 * {@link AspectApi#getItemAspects} to obtain only active definitions.</p>
 */
@FunctionalInterface
public interface AspectItemView {

    AspectAmounts storedAspectData(ItemStack stack);
}
