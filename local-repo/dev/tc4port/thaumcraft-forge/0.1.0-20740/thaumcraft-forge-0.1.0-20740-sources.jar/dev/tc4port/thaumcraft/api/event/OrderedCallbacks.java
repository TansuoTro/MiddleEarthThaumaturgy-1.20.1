package dev.tc4port.thaumcraft.api.event;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Objects;

/**
 * Lower priority runs first; equal priorities sort by caller ID. Registration precedes use.
 */
public final class OrderedCallbacks<T> {

    private record Entry<T>(int priority, String id, T callback) {
    }

    private final List<Entry<T>> entries = new ArrayList<>();

    private volatile List<T> callbacks = List.of();

    public synchronized void register(int priority, String id, T callback) {
        Objects.requireNonNull(id);
        Objects.requireNonNull(callback);
        if (entries.stream().anyMatch(entry -> entry.id().equals(id)))
            throw new IllegalArgumentException("Duplicate callback ID: " + id);
        entries.add(new Entry<>(priority, id, callback));
        entries.sort(Comparator.<Entry<T>>comparingInt(Entry::priority).thenComparing(Entry::id));
        callbacks = entries.stream().map(Entry::callback).toList();
    }

    public List<T> values() {
        return callbacks;
    }
}
