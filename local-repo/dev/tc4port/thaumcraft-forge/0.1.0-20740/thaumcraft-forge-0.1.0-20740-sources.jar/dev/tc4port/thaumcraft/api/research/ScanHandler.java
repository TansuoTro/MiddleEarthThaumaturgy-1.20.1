package dev.tc4port.thaumcraft.api.research;

import java.util.Optional;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;

/**
 * Supplies an addon-owned phenomenon when built-in scan probes find none.
 */
@FunctionalInterface
public interface ScanHandler {

    Optional<ScanPhenomenon> scan(ServerPlayer player, ItemStack scanner);
}
