package dev.tc4port.thaumcraft.api.machine;

import java.util.Objects;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.state.BlockState;

/**
 * One server-side harvest, with the effective tool after focus upgrades.
 */
public record ArcaneBoreDropContext(ServerLevel level, BlockPos borePos, BlockPos targetPos, BlockState state, ItemStack tool, int fortune, boolean silkTouch) {

    public ArcaneBoreDropContext {
        Objects.requireNonNull(level, "level");
        borePos = Objects.requireNonNull(borePos, "borePos").immutable();
        targetPos = Objects.requireNonNull(targetPos, "targetPos").immutable();
        Objects.requireNonNull(state, "state");
        tool = Objects.requireNonNull(tool, "tool").copy();
    }

    /**
     * A detached copy: modifying it cannot change the installed tool or other callbacks.
     */
    @Override
    public ItemStack tool() {
        return tool.copy();
    }
}
