package dev.tc4port.thaumcraft.block;

import com.mojang.serialization.MapCodec;
import dev.tc4port.thaumcraft.nativeimpl.EffectTypes;
import dev.tc4port.thaumcraft.client.WispMoteParticle;
import net.minecraft.core.BlockPos;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;

public final class VishroomBlock extends TCPlantBlock {

    public VishroomBlock(BlockBehaviour.Properties properties) {
        super(properties);
    }

    @Override
    public void entityInside(BlockState state, Level level, BlockPos pos, Entity entity) {
        if (entity instanceof LivingEntity living) {
            living.addEffect((switch(0) {
                default ->
                    {
                        net.minecraft.core.Holder<net.minecraft.world.effect.MobEffect> native$operand$13319 = EffectTypes.CONFUSION;
                        int native$operand$13320 = 200;
                        int native$operand$13321 = 0;
                        net.minecraft.world.effect.MobEffectInstance native$result$13322 = (new net.minecraft.world.effect.MobEffectInstance(native$operand$13319.value(), native$operand$13320, VishroomBlock.native$MobEffectPlatform$safeAmplifier(native$operand$13319, native$operand$13321)));
                        yield native$result$13322;
                    }
            }));
        }
        super.entityInside(state, level, pos, entity);
    }

    @Override
    public void animateTick(BlockState state, Level level, BlockPos pos, RandomSource random) {
        if (random.nextInt(3) == 0) {
            WispMoteParticle.spawn(level, pos.getX() + 0.5 + (random.nextFloat() - random.nextFloat()) * 0.4, pos.getY() + 0.3, pos.getZ() + 0.5 + (random.nextFloat() - random.nextFloat()) * 0.4, 0.1F, 0.5F, 0.3F, 0.8F, true, 0.015F);
        }
    }

    public static final MapCodec<VishroomBlock> CODEC = VishroomBlock.native$BlockCodecPlatform$simple(VishroomBlock::new);

    protected MapCodec<? extends VishroomBlock> codec() {
        return CODEC;
    }

    /**
     * Native shift-based effects need a smaller ceiling than the stored amplifier byte.
     */
    static private int native$MobEffectPlatform$safeAmplifier(net.minecraft.core.Holder<net.minecraft.world.effect.MobEffect> effect, int amplifier) {
        net.minecraft.world.effect.MobEffect type = effect.value();
        int maximum = type == net.minecraft.world.effect.MobEffects.HEAL || type == net.minecraft.world.effect.MobEffects.HARM ? 16 : type == net.minecraft.world.effect.MobEffects.REGENERATION || type == net.minecraft.world.effect.MobEffects.POISON || type == net.minecraft.world.effect.MobEffects.WITHER ? 31 : 127;
        return java.lang.Math.max(0, java.lang.Math.min(maximum, amplifier));
    }

    static private <B extends net.minecraft.world.level.block.Block> com.mojang.serialization.MapCodec<B> native$BlockCodecPlatform$simple(java.util.function.Function<net.minecraft.world.level.block.state.BlockBehaviour.Properties, B> factory) {
        // Vanilla 1.21's Properties codec is a unit codec. Retain that schema for shared block definitions.
        return com.mojang.serialization.codecs.RecordCodecBuilder.mapCodec(instance -> instance.group(com.mojang.serialization.Codec.unit(net.minecraft.world.level.block.state.BlockBehaviour.Properties::of).fieldOf("properties").forGetter((B block) -> net.minecraft.world.level.block.state.BlockBehaviour.Properties.copy(block))).apply(instance, factory));
    }
}
