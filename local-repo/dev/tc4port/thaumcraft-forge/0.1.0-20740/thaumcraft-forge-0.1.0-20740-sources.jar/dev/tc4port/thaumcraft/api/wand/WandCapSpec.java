package dev.tc4port.thaumcraft.api.wand;

import dev.tc4port.thaumcraft.api.aspect.VisChannel;
import dev.tc4port.thaumcraft.api.research.ResearchRequirement;
import java.util.Objects;
import java.util.Set;
import net.minecraft.resources.ResourceLocation;

/**
 * Programmatically installed, declarative wand-cap definition.
 */
public record WandCapSpec(ResourceLocation itemId, WandMaterialId materialId, float baseCostModifier, Set<VisChannel> specialCostModifierAspects, float specialCostModifier, ResourceLocation texture, int craftCost, ResearchRequirement research, WandPartAssemblyMode assemblyMode, int order) {

    public WandCapSpec {
        itemId = Objects.requireNonNull(itemId, "itemId");
        materialId = Objects.requireNonNull(materialId, "materialId");
        specialCostModifierAspects = Set.copyOf(specialCostModifierAspects);
        texture = Objects.requireNonNull(texture, "texture");
        research = Objects.requireNonNull(research, "research");
        assemblyMode = Objects.requireNonNull(assemblyMode, "assemblyMode");
        if (texture.toString().length() > 256) {
            throw new IllegalArgumentException("Wand cap texture ID must not exceed 256 characters");
        }
        if (!Float.isFinite(baseCostModifier) || baseCostModifier <= 0.0F || !Float.isFinite(specialCostModifier) || specialCostModifier <= 0.0F || craftCost < 0 || craftCost > WandPartApi.MAX_CRAFT_COST) {
            throw new IllegalArgumentException("Wand caps require positive modifiers and craft cost " + "from 0 to " + WandPartApi.MAX_CRAFT_COST);
        }
    }

    /**
     * Compatibility constructor for ordinary, recipe-visible parts.
     */
    public WandCapSpec(ResourceLocation itemId, WandMaterialId materialId, float baseCostModifier, Set<VisChannel> specialCostModifierAspects, float specialCostModifier, ResourceLocation texture, int craftCost, ResearchRequirement research, int order) {
        this(itemId, materialId, baseCostModifier, specialCostModifierAspects, specialCostModifier, texture, craftCost, research, WandPartAssemblyMode.NORMAL, order);
    }
}
