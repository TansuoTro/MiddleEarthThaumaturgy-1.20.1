package dev.tc4port.thaumcraft.block.entity;

import dev.tc4port.thaumcraft.nativeimpl.EffectTypes;
import dev.tc4port.thaumcraft.api.entity.EldritchMob;
import dev.tc4port.thaumcraft.registry.TCBlockEntities;
import dev.tc4port.thaumcraft.registry.TCParticles;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import dev.tc4port.thaumcraft.nativeimpl.state.ItemFields;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityType;

/**
 * Server aura from {@code TileEldritchObelisk}.
 */
public final class EldritchObeliskBlockEntity extends net.minecraft.world.level.block.entity.BlockEntity implements ItemFields.Source {

    public EldritchObeliskBlockEntity(BlockPos pos, BlockState state) {
        super(TCBlockEntities.ELDRITCH_OBELISK.get(), pos, state);
    }

    public static void serverTick(Level level, BlockPos pos, BlockState state, EldritchObeliskBlockEntity obelisk) {
        /*
         * TC4 declared a counter but never incremented it. The bytecode
         * therefore evaluates counter % 20 == 0 every tick, while the
         * regeneration guard naturally limits reapplication.
         */
        Vec3 center = new Vec3(pos.getX() + 0.5, pos.getY(), pos.getZ() + 0.5);
        AABB range = new AABB(center, center).inflate(6.0);
        for (LivingEntity entity : level.getEntitiesOfClass(LivingEntity.class, range)) {
            if (entity instanceof EldritchMob && !(switch(0) {
                default ->
                    {
                        net.minecraft.world.entity.LivingEntity native$operand$13106 = entity;
                        net.minecraft.core.Holder<net.minecraft.world.effect.MobEffect> native$operand$13107 = EffectTypes.REGENERATION;
                        boolean native$result$13108 = (native$operand$13106.hasEffect(native$operand$13107.value()));
                        yield native$result$13108;
                    }
            })) {
                entity.addEffect((switch(0) {
                    default ->
                        {
                            net.minecraft.core.Holder<net.minecraft.world.effect.MobEffect> native$operand$12966 = EffectTypes.DAMAGE_BOOST;
                            int native$operand$12967 = 40;
                            int native$operand$12968 = 0;
                            boolean native$operand$12969 = true;
                            boolean native$operand$12970 = true;
                            net.minecraft.world.effect.MobEffectInstance native$result$12971 = (new net.minecraft.world.effect.MobEffectInstance(native$operand$12966.value(), native$operand$12967, EldritchObeliskBlockEntity.native$MobEffectPlatform$safeAmplifier(native$operand$12966, native$operand$12968), native$operand$12969, native$operand$12970));
                            yield native$result$12971;
                        }
                }));
                entity.addEffect((switch(0) {
                    default ->
                        {
                            net.minecraft.core.Holder<net.minecraft.world.effect.MobEffect> native$operand$12972 = EffectTypes.REGENERATION;
                            int native$operand$12973 = 40;
                            int native$operand$12974 = 0;
                            boolean native$operand$12975 = true;
                            boolean native$operand$12976 = true;
                            net.minecraft.world.effect.MobEffectInstance native$result$12977 = (new net.minecraft.world.effect.MobEffectInstance(native$operand$12972.value(), native$operand$12973, EldritchObeliskBlockEntity.native$MobEffectPlatform$safeAmplifier(native$operand$12972, native$operand$12974), native$operand$12975, native$operand$12976));
                            yield native$result$12977;
                        }
                }));
                /*
                 * The original Guardian is UNDEAD. Both 1.7 and 1.21 reject
                 * this regeneration instance for it, so the guard stays
                 * false and Strength is refreshed every tick. Calling both
                 * additions is nevertheless part of the exact source path
                 * and supports any future non-undead IEldritchMob.
                 */
            }
        }
    }

    public static void clientTick(Level level, BlockPos pos, BlockState state, EldritchObeliskBlockEntity obelisk) {
        Vec3 center = new Vec3(pos.getX() + 0.5, pos.getY(), pos.getZ() + 0.5);
        AABB range = new AABB(center, center).inflate(6.0);
        for (LivingEntity entity : level.getEntitiesOfClass(LivingEntity.class, range)) {
            if (!(entity instanceof EldritchMob)) {
                continue;
            }
            level.addParticle(TCParticles.TARGETED_ELDRITCH_WISP.get(), pos.getX() + 0.5, pos.getY() + 1.0 + level.random.nextFloat() * 3.0F, pos.getZ() + 0.5, entity.getId(), 0.0, 0.0);
        }
    }

    protected final HolderLookup.Provider persistenceRegistries() {
        if (level != null)
            return level.registryAccess();
        var server = net.minecraftforge.server.ServerLifecycleHooks.getCurrentServer();
        return server != null ? server.registryAccess() : net.minecraft.core.RegistryAccess.fromRegistryOfRegistries(net.minecraft.core.registries.BuiltInRegistries.REGISTRY);
    }

    protected static net.minecraft.network.chat.Component parseCustomNameSafe(String value, HolderLookup.Provider registries) {
        try {
            return net.minecraft.network.chat.Component.Serializer.fromJson(value);
        } catch (RuntimeException exception) {
            return null;
        }
    }

    protected void readItemFields(ItemFields.Input input) {
    }

    public void copyItemFields(ItemFields.Output output) {
    }

    public void applyComponentsFromItemStack(ItemStack stack) {
        readItemFields(ItemFields.from(stack));
    }

    public void removeComponentsFromTag(CompoundTag tag) {
    }

    @Override
    public void saveToItem(ItemStack stack) {
        CompoundTag tag = saveWithoutMetadata();
        {
            net.minecraft.nbt.CompoundTag native$bodyOperand$6138 = tag;
            native$bodyReturn$6140: {
                if (true) {
                }
            }
        }
        net.minecraft.world.item.BlockItem.setBlockEntityData(stack, getType(), tag);
        copyItemFields(ItemFields.to(stack));
    }

    @Override
    public net.minecraft.world.phys.AABB getRenderBoundingBox() {
        return EldritchObeliskBlockEntity.native$ClientBlockEntityBounds$bounds(this);
    }

    @Override()
    public void onDataPacket(net.minecraft.network.Connection connection, net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket packet) {
        handleUpdateTag(packet.getTag());
    }

    /**
     * Native shift-based effects need a smaller ceiling than the stored amplifier byte.
     */
    static private int native$MobEffectPlatform$safeAmplifier(net.minecraft.core.Holder<net.minecraft.world.effect.MobEffect> effect, int amplifier) {
        net.minecraft.world.effect.MobEffect type = effect.value();
        int maximum = type == net.minecraft.world.effect.MobEffects.HEAL || type == net.minecraft.world.effect.MobEffects.HARM ? 16 : type == net.minecraft.world.effect.MobEffects.REGENERATION || type == net.minecraft.world.effect.MobEffects.POISON || type == net.minecraft.world.effect.MobEffects.WITHER ? 31 : 127;
        return java.lang.Math.max(0, java.lang.Math.min(maximum, amplifier));
    }

    @SuppressWarnings({ "rawtypes", "unchecked" })
    static private net.minecraft.world.phys.AABB native$ClientBlockEntityBounds$bounds(net.minecraft.world.level.block.entity.BlockEntity blockEntity) {
        var renderer = net.minecraft.client.Minecraft.getInstance().getBlockEntityRenderDispatcher().getRenderer(blockEntity);
        return renderer instanceof dev.tc4port.thaumcraft.nativeimpl.NativeBlockEntityRenderer shared ? shared.getRenderBoundingBox(blockEntity) : new net.minecraft.world.phys.AABB(blockEntity.getBlockPos());
    }
}
