package dev.tc4port.thaumcraft.api.focus;

import dev.tc4port.thaumcraft.api.aspect.VisCost;
import dev.tc4port.thaumcraft.api.research.ResearchRequirement;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;

/**
 * Immutable, server-synchronized profile for one built-in focus behavior.
 *
 * <p>A profile controls presentation, Vis cost and the five focal-manipulator
 * choice ranks. It does not define executable casting behavior.</p>
 */
public record FocusProfileDefinition(FocusId focusId, int color, boolean displaysPerTickCost, CostMode costMode, Optional<VisCost> baseCost, List<CostOverride> costOverrides, List<List<FocusUpgradeId>> ranks, Map<FocusUpgradeId, Requirement> requirements, FocusClientPresentation clientPresentation, FocusParameters parameters, Map<String, VisCost> actionCosts) {

    public static final int RANK_COUNT = 5;

    public FocusProfileDefinition {
        Objects.requireNonNull(focusId, "focusId");
        if (color < 0 || color > 0xFFFFFF) {
            throw new IllegalArgumentException("Focus color must be a 24-bit RGB value");
        }
        costMode = Objects.requireNonNull(costMode, "costMode");
        baseCost = Objects.requireNonNull(baseCost, "baseCost");
        if (costMode == CostMode.PRIMAL_RANDOM && baseCost.isPresent()) {
            throw new IllegalArgumentException("A primal-random profile must not define a fixed cost");
        }
        Objects.requireNonNull(costOverrides, "costOverrides");
        costOverrides = List.copyOf(costOverrides);
        if (costOverrides.stream().anyMatch(Objects::isNull)) {
            throw new IllegalArgumentException("Focus cost overrides cannot contain null");
        }
        if (costMode == CostMode.PRIMAL_RANDOM && !costOverrides.isEmpty()) {
            throw new IllegalArgumentException("A primal-random profile cannot define cost overrides");
        }
        Objects.requireNonNull(ranks, "ranks");
        if (ranks.size() != RANK_COUNT) {
            throw new IllegalArgumentException("A focus profile must define exactly five ranks");
        }
        ranks = ranks.stream().map(rank -> {
            Objects.requireNonNull(rank, "rank");
            LinkedHashSet<FocusUpgradeId> unique = new LinkedHashSet<>(rank);
            if (unique.size() != rank.size() || unique.contains(null)) {
                throw new IllegalArgumentException("A focus rank cannot contain null or duplicate IDs");
            }
            return List.copyOf(unique);
        }).toList();
        Objects.requireNonNull(requirements, "requirements");
        LinkedHashMap<FocusUpgradeId, Requirement> checked = new LinkedHashMap<>();
        requirements.forEach((upgrade, requirement) -> checked.put(Objects.requireNonNull(upgrade, "requirement upgrade"), Objects.requireNonNull(requirement, "requirement")));
        requirements = Collections.unmodifiableMap(checked);
        parameters = Objects.requireNonNull(parameters, "parameters");
        actionCosts = Collections.unmodifiableMap(new LinkedHashMap<>(actionCosts));
        if (actionCosts.size() > FocusParameters.MAX_ENTRIES || actionCosts.entrySet().stream().anyMatch(entry -> entry.getKey() == null || !entry.getKey().matches("[a-z][a-z0-9_]{0,63}") || entry.getValue() == null)) {
            throw new IllegalArgumentException("Invalid named focus costs");
        }
        clientPresentation = Objects.requireNonNull(clientPresentation, "clientPresentation");
    }

    /**
     * Closed built-in cost algorithms understood by the synchronized client.
     */
    public enum CostMode {

        FIXED, PRIMAL_RANDOM
    }

    /**
     * Returns the first cost override whose complete required-upgrade set is
     * installed. Declaration order is authoritative, so more-specific
     * combinations should be declared before their single-upgrade fallback.
     */
    public Optional<CostOverride> matchingCostOverride(Map<FocusUpgradeId, Integer> upgrades) {
        Objects.requireNonNull(upgrades, "upgrades");
        return costOverrides.stream().filter(override -> override.matches(upgrades)).findFirst();
    }

    /**
     * Resolves a fixed profile's upgrade-sensitive cost.
     */
    public Optional<VisCost> fixedCost(Map<FocusUpgradeId, Integer> upgrades) {
        if (costMode != CostMode.FIXED) {
            return Optional.empty();
        }
        return matchingCostOverride(upgrades).map(CostOverride::cost).or(() -> baseCost);
    }

    /**
     * Resolves the synchronized cost-label cadence for installed upgrades.
     */
    public boolean displaysPerTickCost(Map<FocusUpgradeId, Integer> upgrades) {
        return matchingCostOverride(upgrades).flatMap(CostOverride::perTickDisplayOverride).orElse(displaysPerTickCost);
    }

    /**
     * First matching override wins in declaration order.
     */
    public record CostOverride(Set<FocusUpgradeId> requiredUpgrades, VisCost cost, Optional<Boolean> perTickDisplayOverride) {

        public CostOverride {
            Objects.requireNonNull(requiredUpgrades, "requiredUpgrades");
            LinkedHashSet<FocusUpgradeId> checked = new LinkedHashSet<>();
            requiredUpgrades.forEach(upgrade -> checked.add(Objects.requireNonNull(upgrade, "requiredUpgrades entry")));
            if (checked.isEmpty()) {
                throw new IllegalArgumentException("A focus cost override must require an upgrade");
            }
            requiredUpgrades = Collections.unmodifiableSet(checked);
            Objects.requireNonNull(cost, "cost");
            perTickDisplayOverride = Objects.requireNonNull(perTickDisplayOverride, "perTickDisplayOverride");
        }

        /**
         * Existing single-upgrade declaration remains source/binary usable.
         */
        public CostOverride(FocusUpgradeId upgradeId, VisCost cost) {
            this(Set.of(upgradeId), cost, Optional.empty());
        }

        /**
         * Combination-cost declaration inheriting the profile cadence.
         */
        public CostOverride(Set<FocusUpgradeId> requiredUpgrades, VisCost cost) {
            this(requiredUpgrades, cost, Optional.empty());
        }

        /**
         * Combination-cost declaration with an explicit cadence override.
         */
        public CostOverride(Set<FocusUpgradeId> requiredUpgrades, VisCost cost, boolean displaysPerTickCost) {
            this(requiredUpgrades, cost, Optional.of(displaysPerTickCost));
        }

        /**
         * Compatibility accessor for existing single-upgrade consumers.
         */
        public FocusUpgradeId upgradeId() {
            return requiredUpgrades.iterator().next();
        }

        public boolean matches(Map<FocusUpgradeId, Integer> upgrades) {
            Objects.requireNonNull(upgrades, "upgrades");
            return requiredUpgrades.stream().allMatch(upgrade -> upgrades.getOrDefault(upgrade, 0) > 0);
        }
    }

    /**
     * Optional prerequisites for one upgrade in this profile.
     */
    public record Requirement(Set<FocusUpgradeId> requireAny, Set<FocusUpgradeId> requireAll, Set<FocusUpgradeId> rejectIfAll, ResearchRequirement research) {

        public Requirement {
            requireAny = immutableIds(requireAny, "requireAny");
            requireAll = immutableIds(requireAll, "requireAll");
            rejectIfAll = immutableIds(rejectIfAll, "rejectIfAll");
            research = Objects.requireNonNull(research, "research");
        }

        private static Set<FocusUpgradeId> immutableIds(Set<FocusUpgradeId> values, String field) {
            Objects.requireNonNull(values, field);
            LinkedHashSet<FocusUpgradeId> checked = new LinkedHashSet<>();
            values.forEach(value -> checked.add(Objects.requireNonNull(value, field + " entry")));
            return Collections.unmodifiableSet(checked);
        }
    }
}
