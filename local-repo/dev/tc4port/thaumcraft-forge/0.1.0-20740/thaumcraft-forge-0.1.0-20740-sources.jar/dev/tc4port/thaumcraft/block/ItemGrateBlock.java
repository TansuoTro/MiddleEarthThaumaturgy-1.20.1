package dev.tc4port.thaumcraft.block;

import com.mojang.serialization.MapCodec;
import dev.tc4port.thaumcraft.block.entity.ItemGrateBlockEntity;
import dev.tc4port.thaumcraft.registry.TCBlocks;
import javax.annotation.Nullable;
import net.minecraft.world.level.pathfinder.PathComputationType;
import net.minecraft.world.phys.HitResult;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.EntityCollisionContext;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;
import dev.tc4port.thaumcraft.nativeimpl.ClientExtensionTarget;
import dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.Explosion;

/**
 * BlockMetalDevice metadata five/six as one modern open-state block.
 *
 * <p>The old metadata distinction is stored entirely in {@link #OPEN}; there
 * is one block id and one obtainable item.</p>
 */
public final class ItemGrateBlock extends net.minecraft.world.level.block.BaseEntityBlock implements dev.tc4port.thaumcraft.nativeimpl.ClientExtensionTarget {

    // Forge calls initializeClient from the native superclass constructor. Do not add a field initializer.
    private java.util.function.Consumer<net.minecraftforge.client.extensions.common.IClientBlockExtensions> platform$clientInstaller;

    public static final BooleanProperty OPEN = BlockStateProperties.OPEN;

    private static final VoxelShape TOP = Block.box(0.0, 13.0, 0.0, 16.0, 16.0, 16.0);

    private static final MapCodec<ItemGrateBlock> CODEC = ItemGrateBlock.native$BlockCodecPlatform$simple(ItemGrateBlock::new);

    public ItemGrateBlock(BlockBehaviour.Properties properties) {
        this(properties, properties, true);
    }

    protected MapCodec<ItemGrateBlock> codec() {
        return CODEC;
    }

    public static boolean isOpen(BlockState state) {
        return state.hasProperty(OPEN) && state.getValue(OPEN);
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(OPEN);
    }

    @Nullable
    @Override
    public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        return new ItemGrateBlockEntity(pos, state);
    }

    @Override
    public RenderShape getRenderShape(BlockState state) {
        return RenderShape.MODEL;
    }

    @Override
    public VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
        return TOP;
    }

    @Override
    public VoxelShape getCollisionShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
        if (isOpen(state) && context instanceof EntityCollisionContext entityContext && entityContext.getEntity() instanceof ItemEntity) {
            return Shapes.empty();
        }
        return TOP;
    }

    protected InteractionResult interactWithoutItem(BlockState state, Level level, BlockPos pos, Player player, BlockHitResult hit) {
        if (!level.isClientSide) {
            this.setOpen((net.minecraft.server.level.ServerLevel) level, pos, !isOpen(state));
        }
        return net.minecraft.world.InteractionResult.sidedSuccess(level.isClientSide);
    }

    @Override
    public void neighborChanged(BlockState state, Level level, BlockPos pos, Block neighborBlock, BlockPos neighborPos, boolean movedByPiston) {
        super.neighborChanged(state, level, pos, neighborBlock, neighborPos, movedByPiston);
        if (level instanceof ServerLevel serverLevel && level.hasChunksAt(pos.offset(-2, 0, -2), pos.offset(2, 0, 2))) {
            boolean powered = level.hasNeighborSignal(pos);
            if (powered || neighborBlock.defaultBlockState().isSignalSource()) {
                boolean shouldOpen = !powered;
                if (shouldOpen != isOpen(state)) {
                    this.setOpen(serverLevel, pos, shouldOpen);
                }
            }
        }
    }

    private void setOpen(ServerLevel level, BlockPos pos, boolean open) {
        BlockState replacement = TCBlocks.ITEM_GRATE.get().defaultBlockState().setValue(OPEN, open);
        level.setBlock(pos, replacement, Block.UPDATE_CLIENTS);
        level.playSound(null, pos, open ? SoundEvents.WOODEN_TRAPDOOR_OPEN : SoundEvents.WOODEN_TRAPDOOR_CLOSE, SoundSource.BLOCKS, 1.0F, level.random.nextFloat() * 0.1F + 0.9F);
    }

    @Override
    public ItemStack getCloneItemStack(BlockState state, HitResult target, net.minecraft.world.level.BlockGetter level, BlockPos pos, Player player) {
        return new ItemStack(TCBlocks.ITEM_GRATE.get());
    }

    @Override
    public boolean isPathfindable(BlockState state, BlockGetter level, BlockPos pos, PathComputationType pathType) {
        // Only the top plate collides. Reporting the cell as open made
        // walkers path into the plate instead of across it.
        return false;
    }

    private ItemGrateBlock(net.minecraft.world.level.block.state.BlockBehaviour.Properties native$NativeEntityBlock$arg0, BlockBehaviour.Properties properties, boolean native$NativeEntityBlock$captured) {
        super(native$NativeEntityBlock$arg0);
        this.registerDefaultState(this.stateDefinition.any().setValue(OPEN, true));
    }

    @Override
    public void initializeClient(java.util.function.Consumer<net.minecraftforge.client.extensions.common.IClientBlockExtensions> installer) {
        platform$clientInstaller = installer;
        super.initializeClient(installer);
    }

    @Override
    public void platform$clientExtension(Object extension) {
        java.util.Objects.requireNonNull(platform$clientInstaller, "Forge initializeClient must run before client extension registration").accept((net.minecraftforge.client.extensions.common.IClientBlockExtensions) extension);
    }

    @Override
    public InteractionResult use(BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
        ItemUseResult result = (switch(0) {
            default ->
                {
                    net.minecraft.world.item.ItemStack native$bodyOperand$4540 = player.getItemInHand(hand);
                    net.minecraft.world.level.block.state.BlockState native$bodyOperand$4541 = state;
                    net.minecraft.world.level.Level native$bodyOperand$4542 = level;
                    net.minecraft.core.BlockPos native$bodyOperand$4543 = pos;
                    net.minecraft.world.entity.player.Player native$bodyOperand$4544 = player;
                    net.minecraft.world.InteractionHand native$bodyOperand$4545 = hand;
                    net.minecraft.world.phys.BlockHitResult native$bodyOperand$4546 = hit;
                    dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult native$bodyResult$4547 = null;
                    native$bodyReturn$4548: {
                        if (true) {
                            {
                                native$bodyResult$4547 = dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
                                break native$bodyReturn$4548;
                            }
                        }
                    }
                    yield native$bodyResult$4547;
                }
        });
        return result == ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION ? (hand == InteractionHand.MAIN_HAND ? (switch(0) {
            default ->
                {
                    net.minecraft.world.level.block.state.BlockState native$bodyOperand$3742 = state;
                    net.minecraft.world.level.Level native$bodyOperand$3743 = level;
                    net.minecraft.core.BlockPos native$bodyOperand$3744 = pos;
                    net.minecraft.world.entity.player.Player native$bodyOperand$3745 = player;
                    net.minecraft.world.phys.BlockHitResult native$bodyOperand$3746 = hit;
                    net.minecraft.world.InteractionResult native$bodyResult$3747 = null;
                    native$bodyReturn$3748: {
                        if (true) {
                            if (!native$bodyOperand$3743.isClientSide) {
                                this.setOpen((net.minecraft.server.level.ServerLevel) native$bodyOperand$3743, native$bodyOperand$3744, !isOpen(native$bodyOperand$3742));
                            }
                            {
                                native$bodyResult$3747 = net.minecraft.world.InteractionResult.sidedSuccess(native$bodyOperand$3743.isClientSide);
                                break native$bodyReturn$3748;
                            }
                        }
                    }
                    yield native$bodyResult$3747;
                }
        }) : InteractionResult.PASS) : result.result();
    }

    protected ItemUseResult interactWithItem(ItemStack stack, BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
        return dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
    }

    @Override
    public void playerWillDestroy(Level level, BlockPos pos, BlockState state, Player player) {
        {
            net.minecraft.world.level.Level native$bodyOperand$5895 = level;
            net.minecraft.core.BlockPos native$bodyOperand$5896 = pos;
            net.minecraft.world.level.block.state.BlockState native$bodyOperand$5897 = state;
            net.minecraft.world.entity.player.Player native$bodyOperand$5898 = player;
            net.minecraft.world.level.block.state.BlockState native$bodyResult$5899 = null;
            native$bodyReturn$5900: {
                if (true) {
                    super.playerWillDestroy(native$bodyOperand$5895, native$bodyOperand$5896, native$bodyOperand$5897, native$bodyOperand$5898);
                    {
                        native$bodyResult$5899 = native$bodyOperand$5897;
                        break native$bodyReturn$5900;
                    }
                }
            }
        }
    }

    public BlockState beforePlayerDestroy(Level level, BlockPos pos, BlockState state, Player player) {
        super.playerWillDestroy(level, pos, state, player);
        return state;
    }

    protected boolean survivesSharedExplosion() {
        return false;
    }

    public int getExpDrop(net.minecraft.world.level.block.state.BlockState native$callbackInput$1050, net.minecraft.world.level.LevelReader native$callbackInput$1051, net.minecraft.util.RandomSource native$callbackInput$1052, net.minecraft.core.BlockPos native$callbackInput$1053, int native$callbackInput$1054, int native$callbackInput$1055) {
        net.minecraft.world.level.block.state.BlockState state = native$callbackInput$1050;
        net.minecraft.util.RandomSource random = native$callbackInput$1052;
        return 0;
    }

    @Override
    public void onBlockExploded(BlockState state, Level level, BlockPos pos, Explosion explosion) {
        if (!(switch(0) {
            default ->
                {
                    boolean native$bodyResult$5285 = false;
                    native$bodyReturn$5286: {
                        if (true) {
                            {
                                native$bodyResult$5285 = false;
                                break native$bodyReturn$5286;
                            }
                        }
                    }
                    yield native$bodyResult$5285;
                }
        }))
            super.onBlockExploded(state, level, pos, explosion);
    }

    @Override
    public boolean canDropFromExplosion(BlockState state, BlockGetter level, BlockPos pos, Explosion explosion) {
        return !(switch(0) {
            default ->
                {
                    boolean native$bodyResult$4549 = false;
                    native$bodyReturn$4550: {
                        if (true) {
                            {
                                native$bodyResult$4549 = false;
                                break native$bodyReturn$4550;
                            }
                        }
                    }
                    yield native$bodyResult$4549;
                }
        }) && super.canDropFromExplosion(state, level, pos, explosion);
    }

    static private <B extends net.minecraft.world.level.block.Block> com.mojang.serialization.MapCodec<B> native$BlockCodecPlatform$simple(java.util.function.Function<net.minecraft.world.level.block.state.BlockBehaviour.Properties, B> factory) {
        // Vanilla 1.21's Properties codec is a unit codec. Retain that schema for shared block definitions.
        return com.mojang.serialization.codecs.RecordCodecBuilder.mapCodec(instance -> instance.group(com.mojang.serialization.Codec.unit(net.minecraft.world.level.block.state.BlockBehaviour.Properties::of).fieldOf("properties").forGetter((B block) -> net.minecraft.world.level.block.state.BlockBehaviour.Properties.copy(block))).apply(instance, factory));
    }
}
