package dev.tc4port.thaumcraft.api.golem;

import dev.tc4port.thaumcraft.api.Registration;
import dev.tc4port.thaumcraft.common.GolemSpatialService;

/**
 * Registration boundary for alternate golem coordinate spaces.
 */
public final class GolemSpatialAdapters {

    private GolemSpatialAdapters() {
    }

    /**
     * Registers one adapter during mod construction. Duplicate ids are
     * rejected so load order cannot silently replace another addon's rules.
     */
    public static Registration register(GolemSpatialAdapter adapter) {
        return GolemSpatialService.register(adapter);
    }
}
