package dev.tc4port.thaumcraft.block;

import dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult;
import com.mojang.serialization.MapCodec;
import dev.tc4port.thaumcraft.api.wand.WandCarrierItem;
import net.minecraft.core.BlockPos;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;
import dev.tc4port.thaumcraft.nativeimpl.ClientExtensionTarget;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.pathfinder.PathComputationType;
import net.minecraft.world.phys.HitResult;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.Explosion;
import net.minecraft.world.level.BlockGetter;

/**
 * BlockMetalDevice metadata three and its wand multiblock trigger.
 */
public final class AdvancedAlchemicalConstructBlock extends net.minecraft.world.level.block.Block implements dev.tc4port.thaumcraft.nativeimpl.ClientExtensionTarget {

    // Forge calls initializeClient from the native superclass constructor. Do not add a field initializer.
    private java.util.function.Consumer<net.minecraftforge.client.extensions.common.IClientBlockExtensions> platform$clientInstaller;

    public static final MapCodec<AdvancedAlchemicalConstructBlock> CODEC = AdvancedAlchemicalConstructBlock.native$BlockCodecPlatform$simple(AdvancedAlchemicalConstructBlock::new);

    public AdvancedAlchemicalConstructBlock(BlockBehaviour.Properties properties) {
        this(properties, properties, true);
    }

    protected MapCodec<AdvancedAlchemicalConstructBlock> codec() {
        return CODEC;
    }

    protected ItemUseResult interactWithItem(ItemStack stack, BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
        return stack.getItem() instanceof dev.tc4port.thaumcraft.api.wand.WandCarrierItem ? dev.tc4port.thaumcraft.block.AdvancedAlchemyFurnaceBlock.tryForm(level, pos, player, hand, stack, hit.getDirection()) : dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
    }

    private AdvancedAlchemicalConstructBlock(net.minecraft.world.level.block.state.BlockBehaviour.Properties native$NativeBlock$arg0, BlockBehaviour.Properties properties, boolean native$NativeBlock$captured) {
        super(native$NativeBlock$arg0);
    }

    @Override
    public void initializeClient(java.util.function.Consumer<net.minecraftforge.client.extensions.common.IClientBlockExtensions> installer) {
        platform$clientInstaller = installer;
        super.initializeClient(installer);
    }

    @Override
    public void platform$clientExtension(Object extension) {
        java.util.Objects.requireNonNull(platform$clientInstaller, "Forge initializeClient must run before client extension registration").accept((net.minecraftforge.client.extensions.common.IClientBlockExtensions) extension);
    }

    @Override
    public InteractionResult use(BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
        ItemUseResult result = (switch(0) {
            default ->
                {
                    net.minecraft.world.item.ItemStack native$bodyOperand$4012 = player.getItemInHand(hand);
                    net.minecraft.world.level.block.state.BlockState native$bodyOperand$4013 = state;
                    net.minecraft.world.level.Level native$bodyOperand$4014 = level;
                    net.minecraft.core.BlockPos native$bodyOperand$4015 = pos;
                    net.minecraft.world.entity.player.Player native$bodyOperand$4016 = player;
                    net.minecraft.world.InteractionHand native$bodyOperand$4017 = hand;
                    net.minecraft.world.phys.BlockHitResult native$bodyOperand$4018 = hit;
                    dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult native$bodyResult$4019 = null;
                    native$bodyReturn$4020: {
                        if (true) {
                            {
                                native$bodyResult$4019 = native$bodyOperand$4012.getItem() instanceof dev.tc4port.thaumcraft.api.wand.WandCarrierItem ? dev.tc4port.thaumcraft.block.AdvancedAlchemyFurnaceBlock.tryForm(native$bodyOperand$4014, native$bodyOperand$4015, native$bodyOperand$4016, native$bodyOperand$4017, native$bodyOperand$4012, native$bodyOperand$4018.getDirection()) : dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
                                break native$bodyReturn$4020;
                            }
                        }
                    }
                    yield native$bodyResult$4019;
                }
        });
        return result == ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION ? (hand == InteractionHand.MAIN_HAND ? (switch(0) {
            default ->
                {
                    net.minecraft.world.level.block.state.BlockState native$bodyOperand$3394 = state;
                    net.minecraft.world.level.Level native$bodyOperand$3395 = level;
                    net.minecraft.core.BlockPos native$bodyOperand$3396 = pos;
                    net.minecraft.world.entity.player.Player native$bodyOperand$3397 = player;
                    net.minecraft.world.phys.BlockHitResult native$bodyOperand$3398 = hit;
                    net.minecraft.world.InteractionResult native$bodyResult$3399 = null;
                    native$bodyReturn$3400: {
                        if (true) {
                            {
                                native$bodyResult$3399 = super.use(native$bodyOperand$3394, native$bodyOperand$3395, native$bodyOperand$3396, native$bodyOperand$3397, net.minecraft.world.InteractionHand.MAIN_HAND, native$bodyOperand$3398);
                                break native$bodyReturn$3400;
                            }
                        }
                    }
                    yield native$bodyResult$3399;
                }
        }) : InteractionResult.PASS) : result.result();
    }

    protected InteractionResult interactWithoutItem(BlockState state, Level level, BlockPos pos, Player player, BlockHitResult hit) {
        return super.use(state, level, pos, player, net.minecraft.world.InteractionHand.MAIN_HAND, hit);
    }

    @Override
    public void playerWillDestroy(Level level, BlockPos pos, BlockState state, Player player) {
        {
            net.minecraft.world.level.Level native$bodyOperand$5596 = level;
            net.minecraft.core.BlockPos native$bodyOperand$5597 = pos;
            net.minecraft.world.level.block.state.BlockState native$bodyOperand$5598 = state;
            net.minecraft.world.entity.player.Player native$bodyOperand$5599 = player;
            net.minecraft.world.level.block.state.BlockState native$bodyResult$5600 = null;
            native$bodyReturn$5601: {
                if (true) {
                    super.playerWillDestroy(native$bodyOperand$5596, native$bodyOperand$5597, native$bodyOperand$5598, native$bodyOperand$5599);
                    {
                        native$bodyResult$5600 = native$bodyOperand$5598;
                        break native$bodyReturn$5601;
                    }
                }
            }
        }
    }

    public BlockState beforePlayerDestroy(Level level, BlockPos pos, BlockState state, Player player) {
        super.playerWillDestroy(level, pos, state, player);
        return state;
    }

    protected boolean survivesSharedExplosion() {
        return false;
    }

    public int getExpDrop(net.minecraft.world.level.block.state.BlockState native$callbackInput$1145, net.minecraft.world.level.LevelReader native$callbackInput$1146, net.minecraft.util.RandomSource native$callbackInput$1147, net.minecraft.core.BlockPos native$callbackInput$1148, int native$callbackInput$1149, int native$callbackInput$1150) {
        net.minecraft.world.level.block.state.BlockState state = native$callbackInput$1145;
        net.minecraft.util.RandomSource random = native$callbackInput$1147;
        return 0;
    }

    @Override
    public void onBlockExploded(BlockState state, Level level, BlockPos pos, Explosion explosion) {
        if (!(switch(0) {
            default ->
                {
                    boolean native$bodyResult$5195 = false;
                    native$bodyReturn$5196: {
                        if (true) {
                            {
                                native$bodyResult$5195 = false;
                                break native$bodyReturn$5196;
                            }
                        }
                    }
                    yield native$bodyResult$5195;
                }
        }))
            super.onBlockExploded(state, level, pos, explosion);
    }

    @Override
    public boolean canDropFromExplosion(BlockState state, BlockGetter level, BlockPos pos, Explosion explosion) {
        return !(switch(0) {
            default ->
                {
                    boolean native$bodyResult$4021 = false;
                    native$bodyReturn$4022: {
                        if (true) {
                            {
                                native$bodyResult$4021 = false;
                                break native$bodyReturn$4022;
                            }
                        }
                    }
                    yield native$bodyResult$4021;
                }
        }) && super.canDropFromExplosion(state, level, pos, explosion);
    }

    static private <B extends net.minecraft.world.level.block.Block> com.mojang.serialization.MapCodec<B> native$BlockCodecPlatform$simple(java.util.function.Function<net.minecraft.world.level.block.state.BlockBehaviour.Properties, B> factory) {
        // Vanilla 1.21's Properties codec is a unit codec. Retain that schema for shared block definitions.
        return com.mojang.serialization.codecs.RecordCodecBuilder.mapCodec(instance -> instance.group(com.mojang.serialization.Codec.unit(net.minecraft.world.level.block.state.BlockBehaviour.Properties::of).fieldOf("properties").forGetter((B block) -> net.minecraft.world.level.block.state.BlockBehaviour.Properties.copy(block))).apply(instance, factory));
    }
}
