package dev.tc4port.thaumcraft.api.champion;

/**
 * Gameplay dispatch category of a champion modifier.
 */
public enum ChampionCategory {

    PASSIVE, OFFENSIVE, DEFENSIVE
}
