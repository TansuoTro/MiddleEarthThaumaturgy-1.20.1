package dev.tc4port.thaumcraft.block;

import com.mojang.serialization.MapCodec;
import dev.tc4port.thaumcraft.block.entity.ArcaneWorktableBlockEntity;
import javax.annotation.Nullable;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.Containers;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.shapes.VoxelShape;
import dev.tc4port.thaumcraft.nativeimpl.ClientExtensionTarget;
import dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.level.pathfinder.PathComputationType;
import net.minecraft.world.phys.HitResult;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.Explosion;

public final class ArcaneWorktableBlock extends net.minecraft.world.level.block.BaseEntityBlock implements dev.tc4port.thaumcraft.nativeimpl.ClientExtensionTarget {

    // Forge calls initializeClient from the native superclass constructor. Do not add a field initializer.
    private java.util.function.Consumer<net.minecraftforge.client.extensions.common.IClientBlockExtensions> platform$clientInstaller;

    public static final MapCodec<ArcaneWorktableBlock> CODEC = ArcaneWorktableBlock.native$BlockCodecPlatform$simple(ArcaneWorktableBlock::new);

    public ArcaneWorktableBlock(BlockBehaviour.Properties properties) {
        this(properties, properties, true);
    }

    protected MapCodec<ArcaneWorktableBlock> codec() {
        return CODEC;
    }

    @Nullable
    @Override
    public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        return new ArcaneWorktableBlockEntity(pos, state);
    }

    @Override
    public RenderShape getRenderShape(BlockState state) {
        return RenderShape.MODEL;
    }

    @Override
    public VoxelShape getBlockSupportShape(BlockState state, BlockGetter level, BlockPos pos) {
        return TableBlock.TOP_SUPPORT;
    }

    protected InteractionResult interactWithoutItem(BlockState state, Level level, BlockPos pos, Player player, BlockHitResult hitResult) {
        if (player.isShiftKeyDown()) {
            return net.minecraft.world.InteractionResult.PASS;
        }
        if (level.isClientSide) {
            return net.minecraft.world.InteractionResult.SUCCESS;
        }
        if (player instanceof net.minecraft.server.level.ServerPlayer serverPlayer && level.getBlockEntity(pos) instanceof dev.tc4port.thaumcraft.block.entity.ArcaneWorktableBlockEntity worktable) {
            net.minecraftforge.network.NetworkHooks.openScreen((net.minecraft.server.level.ServerPlayer) (serverPlayer), (net.minecraft.world.MenuProvider) (worktable), (java.util.function.Consumer<net.minecraft.network.FriendlyByteBuf>) (buffer -> buffer.writeBlockPos(pos)));
        }
        return net.minecraft.world.InteractionResult.CONSUME;
    }

    @Override
    public void onRemove(BlockState state, Level level, BlockPos pos, BlockState newState, boolean isMoving) {
        if (!state.is(newState.getBlock()) && level.getBlockEntity(pos) instanceof ArcaneWorktableBlockEntity worktable) {
            /*
             * Slot 9 is a derived preview. InventoryUtils.dropItems skipped
             * it explicitly, otherwise breaking the table duplicates the
             * current recipe output.
             */
            worktable.removeItemNoUpdate(ArcaneWorktableBlockEntity.RESULT_SLOT);
            Containers.dropContents(level, pos, worktable);
        }
        super.onRemove(state, level, pos, newState, isMoving);
    }

    private ArcaneWorktableBlock(net.minecraft.world.level.block.state.BlockBehaviour.Properties native$NativeEntityBlock$arg0, BlockBehaviour.Properties properties, boolean native$NativeEntityBlock$captured) {
        super(native$NativeEntityBlock$arg0);
    }

    @Override
    public void initializeClient(java.util.function.Consumer<net.minecraftforge.client.extensions.common.IClientBlockExtensions> installer) {
        platform$clientInstaller = installer;
        super.initializeClient(installer);
    }

    @Override
    public void platform$clientExtension(Object extension) {
        java.util.Objects.requireNonNull(platform$clientInstaller, "Forge initializeClient must run before client extension registration").accept((net.minecraftforge.client.extensions.common.IClientBlockExtensions) extension);
    }

    @Override
    public InteractionResult use(BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
        ItemUseResult result = (switch(0) {
            default ->
                {
                    net.minecraft.world.item.ItemStack native$bodyOperand$4207 = player.getItemInHand(hand);
                    net.minecraft.world.level.block.state.BlockState native$bodyOperand$4208 = state;
                    net.minecraft.world.level.Level native$bodyOperand$4209 = level;
                    net.minecraft.core.BlockPos native$bodyOperand$4210 = pos;
                    net.minecraft.world.entity.player.Player native$bodyOperand$4211 = player;
                    net.minecraft.world.InteractionHand native$bodyOperand$4212 = hand;
                    net.minecraft.world.phys.BlockHitResult native$bodyOperand$4213 = hit;
                    dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult native$bodyResult$4214 = null;
                    native$bodyReturn$4215: {
                        if (true) {
                            {
                                native$bodyResult$4214 = dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
                                break native$bodyReturn$4215;
                            }
                        }
                    }
                    yield native$bodyResult$4214;
                }
        });
        return result == ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION ? (hand == InteractionHand.MAIN_HAND ? (switch(0) {
            default ->
                {
                    net.minecraft.world.level.block.state.BlockState native$bodyOperand$3526 = state;
                    net.minecraft.world.level.Level native$bodyOperand$3527 = level;
                    net.minecraft.core.BlockPos native$bodyOperand$3528 = pos;
                    net.minecraft.world.entity.player.Player native$bodyOperand$3529 = player;
                    net.minecraft.world.phys.BlockHitResult native$bodyOperand$3530 = hit;
                    net.minecraft.world.InteractionResult native$bodyResult$3534 = null;
                    native$bodyReturn$3535: {
                        if (true) {
                            if (native$bodyOperand$3529.isShiftKeyDown()) {
                                {
                                    native$bodyResult$3534 = net.minecraft.world.InteractionResult.PASS;
                                    break native$bodyReturn$3535;
                                }
                            }
                            if (native$bodyOperand$3527.isClientSide) {
                                {
                                    native$bodyResult$3534 = net.minecraft.world.InteractionResult.SUCCESS;
                                    break native$bodyReturn$3535;
                                }
                            }
                            if (native$bodyOperand$3529 instanceof net.minecraft.server.level.ServerPlayer native$bodyBinding$3531 && native$bodyOperand$3527.getBlockEntity(native$bodyOperand$3528) instanceof dev.tc4port.thaumcraft.block.entity.ArcaneWorktableBlockEntity native$bodyBinding$3532) {
                                net.minecraftforge.network.NetworkHooks.openScreen((net.minecraft.server.level.ServerPlayer) (native$bodyBinding$3531), (net.minecraft.world.MenuProvider) (native$bodyBinding$3532), (java.util.function.Consumer<net.minecraft.network.FriendlyByteBuf>) (native$bodyBinding$3533 -> native$bodyBinding$3533.writeBlockPos(native$bodyOperand$3528)));
                            }
                            {
                                native$bodyResult$3534 = net.minecraft.world.InteractionResult.CONSUME;
                                break native$bodyReturn$3535;
                            }
                        }
                    }
                    yield native$bodyResult$3534;
                }
        }) : InteractionResult.PASS) : result.result();
    }

    protected ItemUseResult interactWithItem(ItemStack stack, BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
        return dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
    }

    @Override
    public void playerWillDestroy(Level level, BlockPos pos, BlockState state, Player player) {
        {
            net.minecraft.world.level.Level native$bodyOperand$5696 = level;
            net.minecraft.core.BlockPos native$bodyOperand$5697 = pos;
            net.minecraft.world.level.block.state.BlockState native$bodyOperand$5698 = state;
            net.minecraft.world.entity.player.Player native$bodyOperand$5699 = player;
            net.minecraft.world.level.block.state.BlockState native$bodyResult$5700 = null;
            native$bodyReturn$5701: {
                if (true) {
                    super.playerWillDestroy(native$bodyOperand$5696, native$bodyOperand$5697, native$bodyOperand$5698, native$bodyOperand$5699);
                    {
                        native$bodyResult$5700 = native$bodyOperand$5698;
                        break native$bodyReturn$5701;
                    }
                }
            }
        }
    }

    public BlockState beforePlayerDestroy(Level level, BlockPos pos, BlockState state, Player player) {
        super.playerWillDestroy(level, pos, state, player);
        return state;
    }

    protected boolean survivesSharedExplosion() {
        return false;
    }

    public int getExpDrop(net.minecraft.world.level.block.state.BlockState native$callbackInput$1050, net.minecraft.world.level.LevelReader native$callbackInput$1051, net.minecraft.util.RandomSource native$callbackInput$1052, net.minecraft.core.BlockPos native$callbackInput$1053, int native$callbackInput$1054, int native$callbackInput$1055) {
        net.minecraft.world.level.block.state.BlockState state = native$callbackInput$1050;
        net.minecraft.util.RandomSource random = native$callbackInput$1052;
        return 0;
    }

    @Override
    public void onBlockExploded(BlockState state, Level level, BlockPos pos, Explosion explosion) {
        if (!(switch(0) {
            default ->
                {
                    boolean native$bodyResult$5227 = false;
                    native$bodyReturn$5228: {
                        if (true) {
                            {
                                native$bodyResult$5227 = false;
                                break native$bodyReturn$5228;
                            }
                        }
                    }
                    yield native$bodyResult$5227;
                }
        }))
            super.onBlockExploded(state, level, pos, explosion);
    }

    @Override
    public boolean canDropFromExplosion(BlockState state, BlockGetter level, BlockPos pos, Explosion explosion) {
        return !(switch(0) {
            default ->
                {
                    boolean native$bodyResult$4216 = false;
                    native$bodyReturn$4217: {
                        if (true) {
                            {
                                native$bodyResult$4216 = false;
                                break native$bodyReturn$4217;
                            }
                        }
                    }
                    yield native$bodyResult$4216;
                }
        }) && super.canDropFromExplosion(state, level, pos, explosion);
    }

    static private <B extends net.minecraft.world.level.block.Block> com.mojang.serialization.MapCodec<B> native$BlockCodecPlatform$simple(java.util.function.Function<net.minecraft.world.level.block.state.BlockBehaviour.Properties, B> factory) {
        // Vanilla 1.21's Properties codec is a unit codec. Retain that schema for shared block definitions.
        return com.mojang.serialization.codecs.RecordCodecBuilder.mapCodec(instance -> instance.group(com.mojang.serialization.Codec.unit(net.minecraft.world.level.block.state.BlockBehaviour.Properties::of).fieldOf("properties").forGetter((B block) -> net.minecraft.world.level.block.state.BlockBehaviour.Properties.copy(block))).apply(instance, factory));
    }
}
