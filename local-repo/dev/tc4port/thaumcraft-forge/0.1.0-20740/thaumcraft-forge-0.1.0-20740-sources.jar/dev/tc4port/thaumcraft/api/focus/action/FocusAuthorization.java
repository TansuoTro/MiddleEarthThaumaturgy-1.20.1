package dev.tc4port.thaumcraft.api.focus.action;

import java.util.Objects;
import java.util.Optional;
import net.minecraft.world.phys.Vec3;

/**
 * Immutable result of a pre-debit focus authorization. An optional target is
 * bounded to vanilla world coordinates before it can reach execution.
 */
public record FocusAuthorization(boolean authorized, Optional<Vec3> target) {

    private static final double MAX_COORDINATE = 30_000_000.0D;

    private static final FocusAuthorization ALLOWED = new FocusAuthorization(true, Optional.empty());

    private static final FocusAuthorization DENIED = new FocusAuthorization(false, Optional.empty());

    public FocusAuthorization {
        target = Objects.requireNonNull(target, "target");
        if (!authorized && target.isPresent()) {
            throw new IllegalArgumentException("A denied authorization cannot carry a target");
        }
        target.ifPresent(value -> {
            if (!Double.isFinite(value.x) || !Double.isFinite(value.y) || !Double.isFinite(value.z) || Math.abs(value.x) > MAX_COORDINATE || Math.abs(value.y) > MAX_COORDINATE || Math.abs(value.z) > MAX_COORDINATE) {
                throw new IllegalArgumentException("Authorization target is outside supported bounds");
            }
        });
    }

    public static FocusAuthorization allow() {
        return ALLOWED;
    }

    public static FocusAuthorization allow(Vec3 target) {
        return new FocusAuthorization(true, Optional.of(Objects.requireNonNull(target, "target")));
    }

    public static FocusAuthorization deny() {
        return DENIED;
    }
}
