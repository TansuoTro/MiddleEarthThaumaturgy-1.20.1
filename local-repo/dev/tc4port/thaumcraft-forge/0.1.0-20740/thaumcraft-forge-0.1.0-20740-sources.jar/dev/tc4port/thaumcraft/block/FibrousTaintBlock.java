package dev.tc4port.thaumcraft.block;

import com.mojang.serialization.MapCodec;
import dev.tc4port.thaumcraft.common.TaintDecayCatalog;
import dev.tc4port.thaumcraft.registry.TCTags;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.block.MultifaceBlock;
import net.minecraft.world.level.block.MultifaceSpreader;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.item.context.BlockPlaceContext;

/**
 * Metadata-0 fibrous taint. TC4's custom renderer drew one paper-thin quad on
 * every adjacent non-taint solid face; MultifaceBlock supplies the equivalent
 * modern shape/state semantics for floors, ceilings, walls and corners.
 */
public final class FibrousTaintBlock extends MultifaceBlock {

    public static final MapCodec<FibrousTaintBlock> CODEC = FibrousTaintBlock.native$BlockCodecPlatform$simple(FibrousTaintBlock::new);

    private final MultifaceSpreader spreader = new MultifaceSpreader(this);

    public FibrousTaintBlock(BlockBehaviour.Properties properties) {
        super(properties);
    }

    protected MapCodec<FibrousTaintBlock> codec() {
        return CODEC;
    }

    @Override
    public MultifaceSpreader getSpreader() {
        return this.spreader;
    }

    /**
     * TC4's canPlaceBlockAt required Config.biomeTaintID. Keep that check at
     * the actual player-placement entry point so an invalid placement is
     * rejected immediately instead of appearing until the next random tick.
     */
    @Override
    public BlockState getStateForPlacement(BlockPlaceContext context) {
        if (!TaintSpreadLogic.isTaintedAt(context.getLevel(), context.getClickedPos())) {
            return null;
        }
        return super.getStateForPlacement(context);
    }

    /**
     * Builds the state used by world generation and taint spreading. A single
     * fibre block may render on several faces simultaneously, just as the
     * original TESR-free custom block renderer did.
     */
    public BlockState stateForPlacement(BlockGetter level, BlockPos pos) {
        BlockState state = this.defaultBlockState();
        for (Direction direction : Direction.values()) {
            if (this.isValidStateForPlacement(level, state, pos, direction)) {
                BlockState withFace = this.getStateForPlacement(state, level, pos, direction);
                if (withFace != null) {
                    state = withFace;
                }
            }
        }
        return state;
    }

    public boolean hasFaces(BlockState state) {
        return hasAnyFace(state);
    }

    @Override
    public boolean isValidStateForPlacement(BlockGetter level, BlockState state, BlockPos pos, Direction direction) {
        BlockPos supportPos = pos.relative(direction);
        if (level.getBlockState(supportPos).is(TCTags.TAINT)) {
            return false;
        }
        return super.isValidStateForPlacement(level, state, pos, direction);
    }

    @Override
    public void onPlace(BlockState state, Level level, BlockPos pos, BlockState oldState, boolean movedByPiston) {
        super.onPlace(state, level, pos, oldState, movedByPiston);
        BlockState attached = this.stateForPlacement(level, pos);
        if (attached != state && hasAnyFace(attached)) {
            level.setBlock(pos, attached, 2);
        }
    }

    @Override
    public BlockState updateShape(BlockState state, Direction direction, BlockState neighborState, LevelAccessor level, BlockPos pos, BlockPos neighborPos) {
        BlockState updated = super.updateShape(state, direction, neighborState, level, pos, neighborPos);
        if (updated.isAir()) {
            return updated;
        }
        /*
         * The vanilla multiface update only removes invalid faces. TC4 also
         * immediately became visible on a newly-added adjacent solid face.
         */
        return this.stateForPlacement(level, pos);
    }

    @Override
    public void entityInside(BlockState state, Level level, BlockPos pos, Entity entity) {
        TaintSpreadLogic.applyFibrousContact(level, entity);
        super.entityInside(state, level, pos, entity);
    }

    @Override
    public void randomTick(BlockState state, ServerLevel level, BlockPos pos, RandomSource random) {
        /*
         * Also repairs states loaded from early development worlds, before
         * fibrous taint acquired MultifaceBlock's six attachment properties.
         */
        if (!hasAnyFace(state)) {
            BlockState attached = this.stateForPlacement(level, pos);
            if (!hasAnyFace(attached)) {
                level.removeBlock(pos, false);
                return;
            }
            level.setBlock(pos, attached, 2);
        }
        TaintSpreadLogic.spreadBiome(level, pos, random);
        if (!TaintSpreadLogic.isTaintedAt(level, pos)) {
            TaintDecayCatalog.apply(state.getBlock(), TaintDecayCatalog.Trigger.OUTSIDE_TAINTED_BIOME, level, pos, random);
            return;
        }
        if (TaintSpreadLogic.isOnlyAdjacentToTaint(level, pos)) {
            TaintDecayCatalog.apply(state.getBlock(), TaintDecayCatalog.Trigger.ISOLATED, level, pos, random);
            return;
        }
        TaintSpreadLogic.tickFibreSpreadTarget(level, pos, random);
    }

    static private <B extends net.minecraft.world.level.block.Block> com.mojang.serialization.MapCodec<B> native$BlockCodecPlatform$simple(java.util.function.Function<net.minecraft.world.level.block.state.BlockBehaviour.Properties, B> factory) {
        // Vanilla 1.21's Properties codec is a unit codec. Retain that schema for shared block definitions.
        return com.mojang.serialization.codecs.RecordCodecBuilder.mapCodec(instance -> instance.group(com.mojang.serialization.Codec.unit(net.minecraft.world.level.block.state.BlockBehaviour.Properties::of).fieldOf("properties").forGetter((B block) -> net.minecraft.world.level.block.state.BlockBehaviour.Properties.copy(block))).apply(instance, factory));
    }
}
