package dev.tc4port.thaumcraft.block.entity;

import dev.tc4port.thaumcraft.registry.TCBlockEntities;
import net.minecraft.core.BlockPos;
import net.minecraft.util.Mth;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.ChestBlockEntity;
import net.minecraft.world.level.block.state.BlockState;

/**
 * Vanilla chest persistence/menu/open-count machinery plus TC4's short bite
 * lid event when a touching item is accepted.
 */
public final class HungryChestBlockEntity extends ChestBlockEntity {

    private float previousBite;

    private float bite;

    public HungryChestBlockEntity(BlockPos pos, BlockState state) {
        super(TCBlockEntities.HUNGRY_CHEST.get(), pos, state);
    }

    public static void clientTick(Level level, BlockPos pos, BlockState state, HungryChestBlockEntity chest) {
        ChestBlockEntity.lidAnimateTick(level, pos, state, chest);
        chest.previousBite = chest.bite;
        chest.bite = Math.max(0.0F, chest.bite - 0.1F);
    }

    @Override
    public boolean triggerEvent(int id, int value) {
        if (id == 2) {
            this.previousBite = this.bite;
            this.bite = Math.max(this.bite, value / 10.0F);
            return true;
        }
        return super.triggerEvent(id, value);
    }

    @Override
    public float getOpenNess(float partialTick) {
        return Math.max(super.getOpenNess(partialTick), Mth.lerp(partialTick, this.previousBite, this.bite));
    }

    private boolean native$capabilitiesInvalid$16985;

    public boolean native$capabilityActive$16824;

    private java.util.Map<net.minecraft.core.Direction, net.minecraftforge.common.util.LazyOptional<net.minecraftforge.items.IItemHandler>> native$capabilityHandle$16825;

    @Override
    public <native$capabilityResultType$16986> net.minecraftforge.common.util.LazyOptional<native$capabilityResultType$16986> getCapability(net.minecraftforge.common.capabilities.Capability<native$capabilityResultType$16986> native$requestedCapability$16987, net.minecraft.core.Direction native$requestedFace$16988) {
        getCapabilities();
        synchronized (this) {
            if (native$capabilitiesInvalid$16985)
                return net.minecraftforge.common.util.LazyOptional.empty();
            if (native$capabilityActive$16824 && native$requestedCapability$16987 == (net.minecraftforge.common.capabilities.ForgeCapabilities.ITEM_HANDLER)) {
                if (native$capabilityHandle$16825 == null)
                    native$capabilityHandle$16825 = new java.util.HashMap<>();
                net.minecraftforge.common.util.LazyOptional<net.minecraftforge.items.IItemHandler> native$capabilityResult$16990 = native$capabilityHandle$16825.computeIfAbsent(native$requestedFace$16988, native$capabilityFace$16826 -> {
                    net.minecraftforge.items.IItemHandler native$endpoint$196 = (switch(0) {
                        default ->
                            {
                                dev.tc4port.thaumcraft.block.entity.HungryChestBlockEntity chest = dev.tc4port.thaumcraft.block.entity.HungryChestBlockEntity.this;
                                net.minecraft.core.Direction side = native$capabilityFace$16826;
                                yield (switch(0) {
                                    default ->
                                        {
                                            net.minecraft.world.Container native$operand$12748 = chest;
                                            net.minecraftforge.items.IItemHandler native$result$12749 = (new net.minecraftforge.items.wrapper.InvWrapper(native$operand$12748));
                                            yield native$result$12749;
                                        }
                                });
                            }
                    });
                    return native$endpoint$196 == null ? net.minecraftforge.common.util.LazyOptional.empty() : net.minecraftforge.common.util.LazyOptional.of(() -> native$endpoint$196);
                });
                if (native$capabilityResult$16990.isPresent())
                    return native$capabilityResult$16990.cast();
            }
        }
        return super.getCapability(native$requestedCapability$16987, native$requestedFace$16988);
    }

    @Override
    public void invalidateCaps() {
        java.util.List<net.minecraftforge.common.util.LazyOptional<?>> native$expiredCapabilities$16989 = new java.util.ArrayList<>();
        synchronized (this) {
            native$capabilitiesInvalid$16985 = true;
            if (native$capabilityHandle$16825 != null) {
                native$expiredCapabilities$16989.addAll(native$capabilityHandle$16825.values());
                native$capabilityHandle$16825 = null;
            }
        }
        try {
            super.invalidateCaps();
        } finally {
            native$expiredCapabilities$16989.forEach(net.minecraftforge.common.util.LazyOptional::invalidate);
        }
    }

    @Override
    public void reviveCaps() {
        super.reviveCaps();
        synchronized (this) {
            native$capabilitiesInvalid$16985 = false;
        }
    }
}
