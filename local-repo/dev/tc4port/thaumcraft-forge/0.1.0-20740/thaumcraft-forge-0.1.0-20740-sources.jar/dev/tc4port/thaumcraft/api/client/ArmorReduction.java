package dev.tc4port.thaumcraft.api.client;

import net.minecraft.world.damagesource.DamageSource;

/**
 * Native armor-phase reduction in damage points, before resistance and enchantments.
 */
@FunctionalInterface
public interface ArmorReduction {

    float apply(DamageSource source, float incoming, float previousReduction);
}
