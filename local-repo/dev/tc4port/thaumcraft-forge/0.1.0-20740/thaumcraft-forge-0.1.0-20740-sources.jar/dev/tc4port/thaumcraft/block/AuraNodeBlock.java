package dev.tc4port.thaumcraft.block;

import com.mojang.serialization.MapCodec;
import dev.tc4port.thaumcraft.block.entity.AuraNodeBlockEntity;
import dev.tc4port.thaumcraft.block.entity.NodeStabilizerBlockEntity;
import dev.tc4port.thaumcraft.block.entity.NodeTransducerBlockEntity;
import dev.tc4port.thaumcraft.api.node.AuraNodeState;
import dev.tc4port.thaumcraft.api.flux.FluxApi;
import dev.tc4port.thaumcraft.registry.TCBlockEntities;
import dev.tc4port.thaumcraft.registry.TCBlocks;
import dev.tc4port.thaumcraft.registry.TCFluids;
import dev.tc4port.thaumcraft.worldgen.AuraNodeFactory;
import java.util.Optional;
import java.util.UUID;
import javax.annotation.Nullable;
import net.minecraft.world.phys.HitResult;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityTicker;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.VoxelShape;
import dev.tc4port.thaumcraft.nativeimpl.ClientExtensionTarget;
import dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.level.pathfinder.PathComputationType;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.Explosion;
import net.minecraft.world.level.BlockGetter;

/**
 * The logical anchor for an aura node.
 *
 * <p>TC4 rendered nodes entirely through their tile entity. Keeping the block
 * invisible preserves that split and allows the renderer to be replaced with
 * a modern block-entity renderer without giving the node a collision cube.</p>
 */
public final class AuraNodeBlock extends net.minecraft.world.level.block.BaseEntityBlock implements dev.tc4port.thaumcraft.nativeimpl.ClientExtensionTarget {

    // Forge calls initializeClient from the native superclass constructor. Do not add a field initializer.
    private java.util.function.Consumer<net.minecraftforge.client.extensions.common.IClientBlockExtensions> platform$clientInstaller;

    public static final MapCodec<AuraNodeBlock> CODEC = AuraNodeBlock.native$BlockCodecPlatform$simple(AuraNodeBlock::new);

    private static final VoxelShape TARGET_SHAPE = Block.box(4.8, 4.8, 4.8, 11.2, 11.2, 11.2);

    public AuraNodeBlock(BlockBehaviour.Properties properties) {
        this(properties, properties, true);
    }

    protected MapCodec<AuraNodeBlock> codec() {
        return CODEC;
    }

    @Nullable
    @Override
    public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        return new AuraNodeBlockEntity(pos, state);
    }

    /**
     * TC4 exposed metadata 0 of BlockAiry in its creative tab. Placing that
     * stack immediately called createRandomNodeAt instead of leaving an empty,
     * visually inert TileNode behind.
     */
    @Override
    public void setPlacedBy(Level level, BlockPos pos, BlockState state, @Nullable LivingEntity placer, ItemStack stack) {
        super.setPlacedBy(level, pos, state, placer, stack);
        if (placer instanceof Player && state.is(TCBlocks.AURA_NODE.get()) && level instanceof ServerLevel serverLevel && level.getBlockEntity(pos) instanceof AuraNodeBlockEntity node) {
            AuraNodeState generated = AuraNodeFactory.create(serverLevel, pos, serverLevel.getRandom(), false, false, false);
            /*
             * TC4's raw node block regenerated its contents whenever a player
             * placed it. Its coordinate id made replacing a node at the same
             * location inherit the old scan record. In the modern port the
             * scan identity is deliberately instance-based so a newly placed
             * phenomenon must be observed again, including at a reused block
             * position. World-generated nodes keep their stable generation id.
             */
            node.setNodeState(generated.withInstanceId(Optional.of(UUID.randomUUID())));
        }
    }

    @Override
    public ItemStack getCloneItemStack(BlockState state, HitResult target, net.minecraft.world.level.BlockGetter level, BlockPos pos, Player player) {
        /* BlockAiry#getItem returned air for metadata zero and five. */
        return ItemStack.EMPTY;
    }

    @Override
    public RenderShape getRenderShape(BlockState state) {
        return RenderShape.INVISIBLE;
    }

    /**
     * BlockAiry used a 0.3-0.7 internal target box while returning an empty
     * selected bounding box. Modern Minecraft uses the same shape for
     * targeting and the outline, so the outline alone is cancelled by
     * AuraNodeClientEvents while this smaller ray target remains usable.
     */
    @Override
    public VoxelShape getShape(BlockState state, net.minecraft.world.level.BlockGetter level, BlockPos pos, CollisionContext context) {
        return TARGET_SHAPE;
    }

    /**
     * Metadata 5 in BlockAiry owned the energized assembly's safety check.
     * Keeping that check on the node is important: if the transducer itself is
     * removed, its block entity no longer exists to detect the broken machine.
     */
    @Override
    public void neighborChanged(BlockState state, Level level, BlockPos pos, Block neighborBlock, BlockPos neighborPos, boolean movedByPiston) {
        super.neighborChanged(state, level, pos, neighborBlock, neighborPos, movedByPiston);
        checkStructure(level, pos);
    }

    /**
     * Propagate changes across the node to the assembly's controller.
     */
    public static void checkStructure(Level level, BlockPos nodePos) {
        if (!(level instanceof ServerLevel) || !level.isLoaded(nodePos)) {
            return;
        }
        checkEnergizedStructure(level, nodePos);
        if (level.getBlockEntity(nodePos.above()) instanceof NodeTransducerBlockEntity transducer) {
            transducer.checkStatus();
        }
    }

    public static void checkEnergizedStructure(Level level, BlockPos nodePos) {
        if (!(level instanceof ServerLevel serverLevel) || !level.isLoaded(nodePos)) {
            return;
        }
        if (!level.hasChunksAt(nodePos.offset(-2, 0, -2), nodePos.offset(2, 0, 2))) {
            if (level.getBlockEntity(nodePos) instanceof AuraNodeBlockEntity node) {
                node.deferEnergizedStructureCheck();
            }
            return;
        }
        if (level.getBlockState(nodePos).is(TCBlocks.ENERGIZED_AURA_NODE.get()) && !hasValidEnergizedStructure(level, nodePos)) {
            explodeEnergizedNode(serverLevel, nodePos);
        }
    }

    public static boolean hasValidEnergizedStructure(Level level, BlockPos nodePos) {
        BlockPos stabilizerPos = nodePos.below();
        return level.hasChunksAt(stabilizerPos.offset(-2, 0, -2), stabilizerPos.offset(2, 0, 2)) && !level.hasNeighborSignal(stabilizerPos) && level.getBlockEntity(stabilizerPos) instanceof NodeStabilizerBlockEntity && level.getBlockEntity(nodePos.above()) instanceof NodeTransducerBlockEntity;
    }

    public static void explodeEnergizedNode(ServerLevel level, BlockPos nodePos) {
        /*
         * Neighbor callbacks can re-enter through removeBlock. Guard on the
         * energized state so one structural failure creates exactly one blast.
         */
        if (!level.isLoaded(nodePos) || !level.getBlockState(nodePos).is(TCBlocks.ENERGIZED_AURA_NODE.get())) {
            return;
        }
        level.removeBlock(nodePos, false);
        // Native explosions trace blocks even with interaction NONE.
        // A missing blast neighborhood must not be loaded by this effect.
        if (level.hasChunksAt(nodePos.offset(-8, 0, -8), nodePos.offset(8, 0, 8))) {
            level.explode(null, nodePos.getX() + 0.5, nodePos.getY() + 0.5, nodePos.getZ() + 0.5, 3.0F, false, Level.ExplosionInteraction.NONE);
        }
        for (int attempt = 0; attempt < 50; attempt++) {
            BlockPos target = nodePos.offset(level.random.nextInt(8) - level.random.nextInt(8), level.random.nextInt(8) - level.random.nextInt(8), level.random.nextInt(8) - level.random.nextInt(8));
            if (level.hasChunksAt(target.offset(-1, 0, -1), target.offset(1, 0, 1)) && level.getBlockState(target).isAir()) {
                FluxApi.place(level, target, target.getY() < nodePos.getY() ? TCFluids.FLUX_GOO.get() : TCFluids.FLUX_GAS.get(), 9, 3);
            }
        }
    }

    public BlockState beforePlayerDestroy(Level level, BlockPos pos, BlockState state, Player player) {
        // Creative destruction skips native block loot; preserve node harvest rewards
        // by evaluating the same table here only for that skipped branch.
        if (player.isCreative() && level instanceof net.minecraft.server.level.ServerLevel) {
            net.minecraft.world.level.block.Block.dropResources(state, level, pos, level.getBlockEntity(pos), player, player.getMainHandItem());
        }
        return (switch(0) {
            default ->
                {
                    net.minecraft.world.level.Level native$bodyOperand$5702 = level;
                    net.minecraft.core.BlockPos native$bodyOperand$5703 = pos;
                    net.minecraft.world.level.block.state.BlockState native$bodyOperand$5704 = state;
                    net.minecraft.world.entity.player.Player native$bodyOperand$5705 = player;
                    net.minecraft.world.level.block.state.BlockState native$bodyResult$5706 = null;
                    native$bodyReturn$5707: {
                        if (true) {
                            super.playerWillDestroy(native$bodyOperand$5702, native$bodyOperand$5703, native$bodyOperand$5704, native$bodyOperand$5705);
                            {
                                native$bodyResult$5706 = native$bodyOperand$5704;
                                break native$bodyReturn$5707;
                            }
                        }
                    }
                    yield native$bodyResult$5706;
                }
        });
    }

    @Nullable
    @Override
    public <T extends BlockEntity> BlockEntityTicker<T> getTicker(Level level, BlockState state, BlockEntityType<T> type) {
        return createTickerHelper(type, TCBlockEntities.AURA_NODE.get(), level.isClientSide ? AuraNodeBlockEntity::clientTick : AuraNodeBlockEntity::serverTick);
    }

    @Override
    public java.util.List<net.minecraft.world.item.ItemStack> getDrops(BlockState state, net.minecraft.world.level.storage.loot.LootParams.Builder params) {
        params.withParameter(net.minecraft.world.level.storage.loot.parameters.LootContextParams.BLOCK_STATE, state);
        dev.tc4port.thaumcraft.loot.NodeLoot.prepare(params);
        return super.getDrops(state, params);
    }

    private AuraNodeBlock(net.minecraft.world.level.block.state.BlockBehaviour.Properties native$NativeEntityBlock$arg0, BlockBehaviour.Properties properties, boolean native$NativeEntityBlock$captured) {
        super(native$NativeEntityBlock$arg0);
    }

    @Override
    public void initializeClient(java.util.function.Consumer<net.minecraftforge.client.extensions.common.IClientBlockExtensions> installer) {
        platform$clientInstaller = installer;
        super.initializeClient(installer);
    }

    @Override
    public void platform$clientExtension(Object extension) {
        java.util.Objects.requireNonNull(platform$clientInstaller, "Forge initializeClient must run before client extension registration").accept((net.minecraftforge.client.extensions.common.IClientBlockExtensions) extension);
    }

    @Override
    public InteractionResult use(BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
        ItemUseResult result = (switch(0) {
            default ->
                {
                    net.minecraft.world.item.ItemStack native$bodyOperand$4218 = player.getItemInHand(hand);
                    net.minecraft.world.level.block.state.BlockState native$bodyOperand$4219 = state;
                    net.minecraft.world.level.Level native$bodyOperand$4220 = level;
                    net.minecraft.core.BlockPos native$bodyOperand$4221 = pos;
                    net.minecraft.world.entity.player.Player native$bodyOperand$4222 = player;
                    net.minecraft.world.InteractionHand native$bodyOperand$4223 = hand;
                    net.minecraft.world.phys.BlockHitResult native$bodyOperand$4224 = hit;
                    dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult native$bodyResult$4225 = null;
                    native$bodyReturn$4226: {
                        if (true) {
                            {
                                native$bodyResult$4225 = dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
                                break native$bodyReturn$4226;
                            }
                        }
                    }
                    yield native$bodyResult$4225;
                }
        });
        return result == ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION ? (hand == InteractionHand.MAIN_HAND ? (switch(0) {
            default ->
                {
                    net.minecraft.world.level.block.state.BlockState native$bodyOperand$3536 = state;
                    net.minecraft.world.level.Level native$bodyOperand$3537 = level;
                    net.minecraft.core.BlockPos native$bodyOperand$3538 = pos;
                    net.minecraft.world.entity.player.Player native$bodyOperand$3539 = player;
                    net.minecraft.world.phys.BlockHitResult native$bodyOperand$3540 = hit;
                    net.minecraft.world.InteractionResult native$bodyResult$3541 = null;
                    native$bodyReturn$3542: {
                        if (true) {
                            {
                                native$bodyResult$3541 = super.use(native$bodyOperand$3536, native$bodyOperand$3537, native$bodyOperand$3538, native$bodyOperand$3539, net.minecraft.world.InteractionHand.MAIN_HAND, native$bodyOperand$3540);
                                break native$bodyReturn$3542;
                            }
                        }
                    }
                    yield native$bodyResult$3541;
                }
        }) : InteractionResult.PASS) : result.result();
    }

    protected ItemUseResult interactWithItem(ItemStack stack, BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
        return dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
    }

    protected InteractionResult interactWithoutItem(BlockState state, Level level, BlockPos pos, Player player, BlockHitResult hit) {
        return super.use(state, level, pos, player, net.minecraft.world.InteractionHand.MAIN_HAND, hit);
    }

    @Override
    public void playerWillDestroy(Level level, BlockPos pos, BlockState state, Player player) {
        {
            net.minecraft.world.level.Level native$bodyOperand$5708 = level;
            net.minecraft.core.BlockPos native$bodyOperand$5709 = pos;
            net.minecraft.world.level.block.state.BlockState native$bodyOperand$5710 = state;
            net.minecraft.world.entity.player.Player native$bodyOperand$5711 = player;
            net.minecraft.world.level.block.state.BlockState native$bodyResult$5712 = null;
            native$bodyReturn$5713: {
                if (true) {
                    // Creative destruction skips native block loot; preserve node harvest rewards
                    // by evaluating the same table here only for that skipped branch.
                    if (native$bodyOperand$5711.isCreative() && native$bodyOperand$5708 instanceof net.minecraft.server.level.ServerLevel) {
                        net.minecraft.world.level.block.Block.dropResources(native$bodyOperand$5710, native$bodyOperand$5708, native$bodyOperand$5709, native$bodyOperand$5708.getBlockEntity(native$bodyOperand$5709), native$bodyOperand$5711, native$bodyOperand$5711.getMainHandItem());
                    }
                    {
                        native$bodyResult$5712 = (switch(0) {
                            default ->
                                {
                                    net.minecraft.world.level.Level native$bodyOperand$8979 = native$bodyOperand$5708;
                                    net.minecraft.core.BlockPos native$bodyOperand$8980 = native$bodyOperand$5709;
                                    net.minecraft.world.level.block.state.BlockState native$bodyOperand$8981 = native$bodyOperand$5710;
                                    net.minecraft.world.entity.player.Player native$bodyOperand$8982 = native$bodyOperand$5711;
                                    net.minecraft.world.level.block.state.BlockState native$bodyResult$8983 = null;
                                    native$bodyReturn$8984: {
                                        if (true) {
                                            super.playerWillDestroy(native$bodyOperand$8979, native$bodyOperand$8980, native$bodyOperand$8981, native$bodyOperand$8982);
                                            {
                                                native$bodyResult$8983 = native$bodyOperand$8981;
                                                break native$bodyReturn$8984;
                                            }
                                        }
                                    }
                                    yield native$bodyResult$8983;
                                }
                        });
                        break native$bodyReturn$5713;
                    }
                }
            }
        }
    }

    protected boolean survivesSharedExplosion() {
        return false;
    }

    public int getExpDrop(net.minecraft.world.level.block.state.BlockState native$callbackInput$1050, net.minecraft.world.level.LevelReader native$callbackInput$1051, net.minecraft.util.RandomSource native$callbackInput$1052, net.minecraft.core.BlockPos native$callbackInput$1053, int native$callbackInput$1054, int native$callbackInput$1055) {
        net.minecraft.world.level.block.state.BlockState state = native$callbackInput$1050;
        net.minecraft.util.RandomSource random = native$callbackInput$1052;
        return 0;
    }

    @Override
    public void onBlockExploded(BlockState state, Level level, BlockPos pos, Explosion explosion) {
        if (!(switch(0) {
            default ->
                {
                    boolean native$bodyResult$5229 = false;
                    native$bodyReturn$5230: {
                        if (true) {
                            {
                                native$bodyResult$5229 = false;
                                break native$bodyReturn$5230;
                            }
                        }
                    }
                    yield native$bodyResult$5229;
                }
        }))
            super.onBlockExploded(state, level, pos, explosion);
    }

    @Override
    public boolean canDropFromExplosion(BlockState state, BlockGetter level, BlockPos pos, Explosion explosion) {
        return !(switch(0) {
            default ->
                {
                    boolean native$bodyResult$4227 = false;
                    native$bodyReturn$4228: {
                        if (true) {
                            {
                                native$bodyResult$4227 = false;
                                break native$bodyReturn$4228;
                            }
                        }
                    }
                    yield native$bodyResult$4227;
                }
        }) && super.canDropFromExplosion(state, level, pos, explosion);
    }

    static private <B extends net.minecraft.world.level.block.Block> com.mojang.serialization.MapCodec<B> native$BlockCodecPlatform$simple(java.util.function.Function<net.minecraft.world.level.block.state.BlockBehaviour.Properties, B> factory) {
        // Vanilla 1.21's Properties codec is a unit codec. Retain that schema for shared block definitions.
        return com.mojang.serialization.codecs.RecordCodecBuilder.mapCodec(instance -> instance.group(com.mojang.serialization.Codec.unit(net.minecraft.world.level.block.state.BlockBehaviour.Properties::of).fieldOf("properties").forGetter((B block) -> net.minecraft.world.level.block.state.BlockBehaviour.Properties.copy(block))).apply(instance, factory));
    }
}
