package dev.tc4port.thaumcraft.block.entity;

import dev.tc4port.thaumcraft.registry.TCBlockEntities;
import javax.annotation.Nullable;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.HolderLookup;
import net.minecraft.core.NonNullList;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket;
import net.minecraft.world.ContainerHelper;
import net.minecraft.world.WorldlyContainer;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.state.BlockState;
import dev.tc4port.thaumcraft.nativeimpl.state.ItemFields;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityType;

/**
 * TC4's single-slot arcane pedestal.
 */
public final class ArcanePedestalBlockEntity extends net.minecraft.world.level.block.entity.BlockEntity implements WorldlyContainer, dev.tc4port.thaumcraft.api.machine.InfusionPedestal, ItemFields.Source {

    private static final int[] SLOT = { 0 };

    private NonNullList<ItemStack> items = NonNullList.withSize(1, ItemStack.EMPTY);

    @Nullable
    private Component customName;

    private long contentRevision;

    private int sparkleTicks;

    private int sparkleColor;

    public ArcanePedestalBlockEntity(BlockPos pos, BlockState state) {
        super(TCBlockEntities.ARCANE_PEDESTAL.get(), pos, state);
    }

    public ItemStack item() {
        return this.items.iterator().next();
    }

    /**
     * Monotonic, runtime-only identity for the stack occupying the pedestal.
     * Infusion uses it to distinguish an uninterrupted ingredient from an
     * item that was removed and immediately replaced with an identical copy.
     */
    public long contentRevision() {
        return this.contentRevision;
    }

    /**
     * Infusion output may exceed the normal pedestal stack limit, matching
     * TilePedestal#setInventorySlotContentsFromInfusion.
     */
    public void setFromInfusion(ItemStack stack) {
        this.items.set(0, stack.copy());
        this.contentChangedAndSync();
    }

    public int sparkleColor() {
        return this.sparkleColor;
    }

    public void clientTick() {
        if (this.sparkleTicks > 0) {
            this.sparkleTicks--;
        }
    }

    @Override
    public int getContainerSize() {
        return 1;
    }

    @Override
    public boolean isEmpty() {
        return this.item().isEmpty();
    }

    @Override
    public ItemStack getItem(int slot) {
        return slot == 0 ? this.item() : ItemStack.EMPTY;
    }

    @Override
    public ItemStack removeItem(int slot, int amount) {
        if (slot != 0) {
            return ItemStack.EMPTY;
        }
        ItemStack removed = ContainerHelper.removeItem(this.items, slot, amount);
        if (!removed.isEmpty()) {
            this.contentChangedAndSync();
        }
        return removed;
    }

    @Override
    public ItemStack removeItemNoUpdate(int slot) {
        if (slot != 0) {
            return ItemStack.EMPTY;
        }
        ItemStack removed = ContainerHelper.takeItem(this.items, slot);
        if (!removed.isEmpty()) {
            this.contentRevision++;
            this.setChanged();
        }
        return removed;
    }

    @Override
    public void setItem(int slot, ItemStack stack) {
        if (slot != 0) {
            return;
        }
        this.items.set(0, stack.isEmpty() ? ItemStack.EMPTY : stack.copyWithCount(1));
        this.contentChangedAndSync();
    }

    @Override
    public boolean stillValid(Player player) {
        return this.level != null && this.level.getBlockEntity(this.worldPosition) == this && player.distanceToSqr(this.worldPosition.getX() + 0.5, this.worldPosition.getY() + 0.5, this.worldPosition.getZ() + 0.5) <= 64.0;
    }

    @Override
    public void clearContent() {
        this.items.clear();
        this.contentChangedAndSync();
    }

    @Override
    public int getMaxStackSize() {
        return 1;
    }

    @Override
    public int[] getSlotsForFace(Direction side) {
        return SLOT;
    }

    @Override
    public boolean canPlaceItemThroughFace(int index, ItemStack stack, @Nullable Direction direction) {
        return index == 0 && this.item().isEmpty();
    }

    @Override
    public boolean canTakeItemThroughFace(int index, ItemStack stack, Direction direction) {
        return index == 0;
    }

    public Component displayName() {
        return this.customName == null ? Component.translatable("container.pedestal") : this.customName;
    }

    public void setCustomName(@Nullable Component name) {
        this.customName = name;
        this.changedAndSync();
    }

    @Override
    public void load(CompoundTag tag) {
        HolderLookup.Provider registries = persistenceRegistries();
        super.load(tag);
        this.items = NonNullList.withSize(1, ItemStack.EMPTY);
        {
            net.minecraft.nbt.CompoundTag native$operand$14327 = tag;
            net.minecraft.core.NonNullList<net.minecraft.world.item.ItemStack> native$operand$14328 = this.items;
            net.minecraft.core.HolderLookup.Provider native$operand$14329 = registries;
            net.minecraft.world.ContainerHelper.loadAllItems(native$operand$14327, native$operand$14328);
        }
        if (tag.contains("CustomName")) {
            this.customName = parseCustomNameSafe(tag.getString("CustomName"), registries);
        }
    }

    @Override
    protected void saveAdditional(CompoundTag tag) {
        HolderLookup.Provider registries = persistenceRegistries();
        super.saveAdditional(tag);
        {
            net.minecraft.nbt.CompoundTag native$operand$14330 = tag;
            net.minecraft.core.NonNullList<net.minecraft.world.item.ItemStack> native$operand$14331 = this.items;
            net.minecraft.core.HolderLookup.Provider native$operand$14332 = registries;
            net.minecraft.nbt.CompoundTag native$result$14333 = (net.minecraft.world.ContainerHelper.saveAllItems(native$operand$14330, native$operand$14331));
        }
        if (this.customName != null) {
            tag.putString("CustomName", (switch(0) {
                default ->
                    {
                        net.minecraft.network.chat.Component native$operand$13323 = this.customName;
                        net.minecraft.core.HolderLookup.Provider native$operand$13324 = registries;
                        java.lang.String native$result$13325 = (net.minecraft.network.chat.Component.Serializer.toJson(native$operand$13323));
                        yield native$result$13325;
                    }
            }));
        }
    }

    @Override
    public CompoundTag getUpdateTag() {
        return this.saveWithoutMetadata();
    }

    @Nullable
    @Override
    public Packet<ClientGamePacketListener> getUpdatePacket() {
        return ClientboundBlockEntityDataPacket.create(this);
    }

    @Override
    public boolean triggerEvent(int id, int type) {
        if (id == 11 || id == 12) {
            this.sparkleTicks = id == 11 ? 5 : 10;
            this.sparkleColor = id == 11 ? 0xC000C0 : 0xFFFFFF;
            return true;
        }
        return super.triggerEvent(id, type);
    }

    private void changedAndSync() {
        this.setChanged();
        BlockEntitySync.sendToClientAndUpdateComparator(this);
    }

    private void contentChangedAndSync() {
        this.contentRevision++;
        this.changedAndSync();
    }

    protected final HolderLookup.Provider persistenceRegistries() {
        if (level != null)
            return level.registryAccess();
        var server = net.minecraftforge.server.ServerLifecycleHooks.getCurrentServer();
        return server != null ? server.registryAccess() : net.minecraft.core.RegistryAccess.fromRegistryOfRegistries(net.minecraft.core.registries.BuiltInRegistries.REGISTRY);
    }

    protected static net.minecraft.network.chat.Component parseCustomNameSafe(String value, HolderLookup.Provider registries) {
        try {
            return net.minecraft.network.chat.Component.Serializer.fromJson(value);
        } catch (RuntimeException exception) {
            return null;
        }
    }

    protected void readItemFields(ItemFields.Input input) {
    }

    public void copyItemFields(ItemFields.Output output) {
    }

    public void applyComponentsFromItemStack(ItemStack stack) {
        readItemFields(ItemFields.from(stack));
    }

    public void removeComponentsFromTag(CompoundTag tag) {
    }

    @Override
    public void saveToItem(ItemStack stack) {
        CompoundTag tag = saveWithoutMetadata();
        {
            net.minecraft.nbt.CompoundTag native$bodyOperand$6108 = tag;
            native$bodyReturn$6110: {
                if (true) {
                }
            }
        }
        net.minecraft.world.item.BlockItem.setBlockEntityData(stack, getType(), tag);
        copyItemFields(ItemFields.to(stack));
    }

    @Override
    public net.minecraft.world.phys.AABB getRenderBoundingBox() {
        return ArcanePedestalBlockEntity.native$ClientBlockEntityBounds$bounds(this);
    }

    @Override()
    public void onDataPacket(net.minecraft.network.Connection connection, net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket packet) {
        handleUpdateTag(packet.getTag());
    }

    @SuppressWarnings({ "rawtypes", "unchecked" })
    static private net.minecraft.world.phys.AABB native$ClientBlockEntityBounds$bounds(net.minecraft.world.level.block.entity.BlockEntity blockEntity) {
        var renderer = net.minecraft.client.Minecraft.getInstance().getBlockEntityRenderDispatcher().getRenderer(blockEntity);
        return renderer instanceof dev.tc4port.thaumcraft.nativeimpl.NativeBlockEntityRenderer shared ? shared.getRenderBoundingBox(blockEntity) : new net.minecraft.world.phys.AABB(blockEntity.getBlockPos());
    }

    private boolean native$capabilitiesInvalid$16967;

    public boolean native$capabilityActive$16812;

    private java.util.Map<net.minecraft.core.Direction, net.minecraftforge.common.util.LazyOptional<net.minecraftforge.items.IItemHandler>> native$capabilityHandle$16813;

    @Override
    public <native$capabilityResultType$16968> net.minecraftforge.common.util.LazyOptional<native$capabilityResultType$16968> getCapability(net.minecraftforge.common.capabilities.Capability<native$capabilityResultType$16968> native$requestedCapability$16969, net.minecraft.core.Direction native$requestedFace$16970) {
        getCapabilities();
        synchronized (this) {
            if (native$capabilitiesInvalid$16967)
                return net.minecraftforge.common.util.LazyOptional.empty();
            if (native$capabilityActive$16812 && native$requestedCapability$16969 == (net.minecraftforge.common.capabilities.ForgeCapabilities.ITEM_HANDLER)) {
                if (native$capabilityHandle$16813 == null)
                    native$capabilityHandle$16813 = new java.util.HashMap<>();
                net.minecraftforge.common.util.LazyOptional<net.minecraftforge.items.IItemHandler> native$capabilityResult$16972 = native$capabilityHandle$16813.computeIfAbsent(native$requestedFace$16970, native$capabilityFace$16814 -> {
                    net.minecraftforge.items.IItemHandler native$endpoint$151 = (switch(0) {
                        default ->
                            {
                                net.minecraft.world.WorldlyContainer native$operand$12764 = dev.tc4port.thaumcraft.block.entity.ArcanePedestalBlockEntity.this;
                                net.minecraft.core.Direction native$operand$12765 = native$capabilityFace$16814;
                                net.minecraftforge.items.IItemHandler native$result$12766 = (new net.minecraftforge.items.wrapper.SidedInvWrapper(native$operand$12764, native$operand$12765));
                                yield native$result$12766;
                            }
                    });
                    return native$endpoint$151 == null ? net.minecraftforge.common.util.LazyOptional.empty() : net.minecraftforge.common.util.LazyOptional.of(() -> native$endpoint$151);
                });
                if (native$capabilityResult$16972.isPresent())
                    return native$capabilityResult$16972.cast();
            }
        }
        return super.getCapability(native$requestedCapability$16969, native$requestedFace$16970);
    }

    @Override
    public void invalidateCaps() {
        java.util.List<net.minecraftforge.common.util.LazyOptional<?>> native$expiredCapabilities$16971 = new java.util.ArrayList<>();
        synchronized (this) {
            native$capabilitiesInvalid$16967 = true;
            if (native$capabilityHandle$16813 != null) {
                native$expiredCapabilities$16971.addAll(native$capabilityHandle$16813.values());
                native$capabilityHandle$16813 = null;
            }
        }
        try {
            super.invalidateCaps();
        } finally {
            native$expiredCapabilities$16971.forEach(net.minecraftforge.common.util.LazyOptional::invalidate);
        }
    }

    @Override
    public void reviveCaps() {
        super.reviveCaps();
        synchronized (this) {
            native$capabilitiesInvalid$16967 = false;
        }
    }
}
