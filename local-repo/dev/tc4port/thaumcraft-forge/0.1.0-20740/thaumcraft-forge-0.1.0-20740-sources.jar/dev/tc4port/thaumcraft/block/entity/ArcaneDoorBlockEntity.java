package dev.tc4port.thaumcraft.block.entity;

import dev.tc4port.thaumcraft.registry.TCBlockEntities;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.block.DoorBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.DoubleBlockHalf;

/**
 * One synchronized half of an Arcane Door's TileOwned permissions.
 */
public final class ArcaneDoorBlockEntity extends AbstractArcaneOwnedBlockEntity {

    public ArcaneDoorBlockEntity(BlockPos pos, BlockState state) {
        super(TCBlockEntities.ARCANE_DOOR.get(), pos, state);
    }

    public BlockPos lowerPos() {
        return this.getBlockState().hasProperty(DoorBlock.HALF) && this.getBlockState().getValue(DoorBlock.HALF) == DoubleBlockHalf.UPPER ? this.worldPosition.below() : this.worldPosition;
    }

    public boolean grantBothHalves(Player player, boolean gold) {
        if (this.level == null) {
            return false;
        }
        BlockPos lowerPos = this.lowerPos();
        ArcaneDoorBlockEntity lower = this.level.getBlockEntity(lowerPos) instanceof ArcaneDoorBlockEntity found ? found : this;
        if (!lower.grant(player, gold)) {
            return false;
        }
        if (this.level.getBlockEntity(lowerPos.above()) instanceof ArcaneDoorBlockEntity upper && upper != lower) {
            upper.copyPermissionsFrom(lower);
        }
        if (this != lower) {
            this.copyPermissionsFrom(lower);
        }
        return true;
    }
}
