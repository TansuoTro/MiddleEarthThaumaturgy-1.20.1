package dev.tc4port.thaumcraft.api.wand.behavior;

import dev.tc4port.thaumcraft.api.aspect.VisAction;
import dev.tc4port.thaumcraft.api.aspect.VisCost;
import dev.tc4port.thaumcraft.api.wand.VisTransferResult;
import dev.tc4port.thaumcraft.api.wand.WandView;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.item.ItemStack;

public interface WandServerContext {

    ServerPlayer player();

    InteractionHand hand();

    ItemStack wand();

    WandView view();

    VisTransferResult extract(VisCost cost, VisAction action);

    VisTransferResult insert(VisCost cost, VisAction action);
}
