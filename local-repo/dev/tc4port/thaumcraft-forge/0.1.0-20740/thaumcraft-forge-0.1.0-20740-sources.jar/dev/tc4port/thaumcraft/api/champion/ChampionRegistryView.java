package dev.tc4port.thaumcraft.api.champion;

import java.util.List;
import java.util.Map;
import java.util.Optional;

/**
 * Read-only, generation-stamped view of the synchronized champion catalog.
 */
public interface ChampionRegistryView {

    /**
     * Process-local cache stamp that changes whenever this view is replaced.
     */
    long generation();

    /**
     * Definitions in deterministic presentation order.
     */
    Map<ChampionId, ChampionDefinition> definitions();

    /**
     * Global assignment rules; bosses intentionally skip base modifiers.
     */
    ChampionSettings settings();

    /**
     * Stable identities eligible for the built-in random assignment path.
     */
    List<ChampionId> randomPool();

    default Optional<ChampionDefinition> get(ChampionId id) {
        return Optional.ofNullable(this.definitions().get(id));
    }
}
