package dev.tc4port.thaumcraft.api.recipe;

import dev.tc4port.thaumcraft.api.event.PlatformIdentity;
import java.util.Objects;
import java.util.function.Supplier;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.crafting.Recipe;

/**
 * Recipe identities live on the generated native recipe, never in a global side table.
 */
public final class NativeRecipeIds {

    private NativeRecipeIds() {
    }

    /**
     * Implemented by owned native recipes; external recipes retain their native identity.
     */
    public interface Owned {

        ResourceLocation native$recipeId();

        void native$assignRecipeId(ResourceLocation id);
    }

    public static void bind(Recipe<?> recipe, ResourceLocation id) {
        Objects.requireNonNull(recipe, "recipe");
        Objects.requireNonNull(id, "id");
        if (recipe instanceof Owned owned)
            owned.native$assignRecipeId(id);
        else if (!id.equals(recipe.getId()))
            throw new IllegalArgumentException("Recipe identity differs from its native registered id");
    }

    public static ResourceLocation id(Recipe<?> recipe) {
        return Objects.requireNonNull(((Owned) recipe).native$recipeId(), "Recipe has not been assigned an ID");
    }

    public static ResourceLocation idOr(Recipe<?> recipe, ResourceLocation constructorId) {
        var id = ((Owned) recipe).native$recipeId();
        return id == null ? constructorId : id;
    }

    public static ResourceLocation constructionId() {
        // Native superclasses require an ID even for standalone previews. Their
        // generated override publishes the assigned ID after deserialization.
        return net.minecraft.resources.ResourceLocation.fromNamespaceAndPath((java.lang.String) (PlatformIdentity.NAMESPACE), (java.lang.String) ("runtime/" + java.util.UUID.randomUUID()));
    }

    public static <T extends Recipe<?>> T construct(ResourceLocation id, Supplier<T> factory) {
        Objects.requireNonNull(id, "id");
        T recipe = factory.get();
        bind(recipe, id);
        return recipe;
    }
}
