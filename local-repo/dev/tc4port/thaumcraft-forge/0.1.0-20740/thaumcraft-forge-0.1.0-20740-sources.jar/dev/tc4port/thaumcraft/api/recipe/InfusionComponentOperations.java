package dev.tc4port.thaumcraft.api.recipe;

import net.minecraft.core.HolderLookup;
import net.minecraft.world.item.ItemStack;

/**
 * Post-use peripheral item operations owned by an infusion recipe.
 *
 * <p>Indices correspond to the recipe's resolved ingredient list. Callers
 * perform ingredient matching before invoking an operation. Results are
 * defensive copies and do not mutate the input or the world; the consuming
 * machine owns committing them to the source pedestal.</p>
 */
public interface InfusionComponentOperations {

    /**
     * Tests operation eligibility, including runic bounds and registered transformations.
     */
    boolean supportsComponentInput(int index, ItemStack input);

    /**
     * Returns the configured post-use stack, including native container defaults.
     */
    ItemStack componentRemainder(int index, ItemStack input, HolderLookup.Provider registries);
}
