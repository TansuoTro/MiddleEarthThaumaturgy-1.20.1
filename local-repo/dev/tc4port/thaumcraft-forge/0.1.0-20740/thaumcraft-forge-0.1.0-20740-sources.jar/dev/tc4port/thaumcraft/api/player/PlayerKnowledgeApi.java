package dev.tc4port.thaumcraft.api.player;

import dev.tc4port.thaumcraft.api.aspect.AspectApi;
import dev.tc4port.thaumcraft.api.research.ResearchApi;
import dev.tc4port.thaumcraft.data.PlayerKnowledgeData;
import dev.tc4port.thaumcraft.state.TCObjectState;
import java.util.Objects;
import java.util.Optional;
import java.util.UUID;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.entity.player.Player;

/**
 * Read-only access to the research and aspect knowledge players may share.
 */
public final class PlayerKnowledgeApi {

    private PlayerKnowledgeApi() {
    }

    /**
     * Starts knowledge afresh: scans, research, aspect pools and all Warp are
     * cleared, initial primal pools restored, and current auto-unlocks applied.
     * The native owner synchronization publishes the complete new snapshot.
     */
    public static void reset(net.minecraft.server.level.ServerPlayer player) {
        TCObjectState.PLAYER_KNOWLEDGE.set(player, PlayerKnowledgeData.initial(player.getRandom()));
        dev.tc4port.thaumcraft.research.ResearchCatalog.applyAutoUnlocks(player);
    }

    /**
     * Returns the live synchronized view for a player entity. Client callers
     * may only treat their local player's view as authoritative.
     */
    public static PlayerKnowledgeView view(Player player) {
        Objects.requireNonNull(player, "player");
        return project(TCObjectState.PLAYER_KNOWLEDGE.get(player));
    }

    /**
     * Loads the current live view when the player is online, otherwise their
     * last saved server-side view. The read is available only on the owning
     * server thread and returns empty for a missing or uninitialized player
     * record. It never logs the player in, changes the saved record, or
     * exposes scan and Warp data.
     */
    public static Optional<PlayerKnowledgeView> savedView(MinecraftServer server, UUID playerId) {
        Objects.requireNonNull(server, "server");
        Objects.requireNonNull(playerId, "playerId");
        PlayerKnowledgeData knowledge = TCObjectState.PLAYER_KNOWLEDGE.savedPlayer(server, playerId);
        if (knowledge == null || !knowledge.initialized()) {
            return Optional.empty();
        }
        return Optional.of(project(knowledge));
    }

    private static PlayerKnowledgeView project(PlayerKnowledgeData knowledge) {
        var research = ResearchApi.registry().entries().keySet().stream().filter(knowledge::hasCompletedResearch).toList();
        var aspects = AspectApi.registry().definitions().keySet().stream().filter(knowledge::knowsAspect).toList();
        return new PlayerKnowledgeView(research, aspects);
    }
}
