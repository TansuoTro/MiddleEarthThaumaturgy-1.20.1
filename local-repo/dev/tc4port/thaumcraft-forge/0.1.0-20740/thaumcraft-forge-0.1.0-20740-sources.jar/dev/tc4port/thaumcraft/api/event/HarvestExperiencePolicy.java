package dev.tc4port.thaumcraft.api.event;

/**
 * Combines native harvest XP with equipment-provided Fortune without rerolling the harvest.
 */
public interface HarvestExperiencePolicy {

    int equippedFortuneExperience(int harvestedExperience, int equippedFortune);
}
