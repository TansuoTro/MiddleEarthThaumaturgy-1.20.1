package dev.tc4port.thaumcraft.api.essentia;

import java.util.Objects;
import javax.annotation.Nullable;
import net.minecraft.core.Direction;

/**
 * A bounded legacy-order volume or forward-prism source search.
 */
public record EssentiaSearch(int range, @Nullable Direction direction) {

    public static final int MAX_RANGE = 32;

    public EssentiaSearch {
        if (range < 1 || range > MAX_RANGE) {
            throw new IllegalArgumentException("Essentia search range must be 1.." + MAX_RANGE);
        }
    }

    public static EssentiaSearch nearby(int range) {
        return new EssentiaSearch(range, null);
    }

    public static EssentiaSearch ahead(Direction direction, int range) {
        return new EssentiaSearch(range, Objects.requireNonNull(direction, "direction"));
    }

    public boolean directional() {
        return this.direction != null;
    }
}
