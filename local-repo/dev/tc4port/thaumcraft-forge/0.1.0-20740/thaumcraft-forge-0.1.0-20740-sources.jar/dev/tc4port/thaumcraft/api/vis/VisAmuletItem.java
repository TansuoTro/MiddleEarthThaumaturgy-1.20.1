package dev.tc4port.thaumcraft.api.vis;

import dev.tc4port.thaumcraft.api.item.ItemStatePlatform;
import dev.tc4port.thaumcraft.data.AspectStackData;
import dev.tc4port.thaumcraft.aspect.AspectCatalog;
import dev.tc4port.thaumcraft.api.aspect.AspectId;
import dev.tc4port.thaumcraft.api.aspect.VisChannel;
import dev.tc4port.thaumcraft.state.TCObjectState;
import dev.tc4port.thaumcraft.state.TCItemState;
import java.text.DecimalFormat;
import java.util.List;
import java.util.LinkedHashMap;
import java.util.Map;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import java.lang.Math;
import dev.tc4port.thaumcraft.nativeimpl.ClientExtensionTarget;
import dev.tc4port.thaumcraft.api.item.OwnedItemStack;
import net.minecraft.world.item.Item;

/**
 * Public native Vis amulet base. Subclasses share the core primal storage,
 * worn wand/relay transfers, pedestal recharge and inventory payment paths.
 * Amounts and capacity are centivis; override canEquip for addon equipment rules.
 * Storage operations are final so recharge and payment retain the same ledger.
 */
public class VisAmuletItem extends net.minecraft.world.item.Item implements dev.tc4port.thaumcraft.api.item.OwnedItemStack {

    // Forge calls initializeClient from the native superclass constructor. Do not add a field initializer.
    private java.util.function.Consumer<net.minecraftforge.client.extensions.common.IClientItemExtensions> platform$clientInstaller;

    private final int maximumVis;

    private final String descriptionId;

    public VisAmuletItem(Properties properties, int maximumVis, String descriptionId) {
        this(ItemStatePlatform.withDefault(properties.stacksTo(1), TCItemState.ASPECTS, AspectStackData.EMPTY), properties, maximumVis, descriptionId, true);
    }

    @Override
    public String getDescriptionId() {
        return this.descriptionId;
    }

    public final int maximumVis() {
        var definition = dev.tc4port.thaumcraft.registry.TCRegistryDataMaps.VIS_AMULETS.get(this.builtInRegistryHolder());
        return definition == null ? maximumVis : definition.capacityCentivis();
    }

    public final int vis(ItemStack stack, VisChannel aspect) {
        return (switch(0) {
            default ->
                {
                    dev.tc4port.thaumcraft.api.data.ItemStateKey<dev.tc4port.thaumcraft.data.AspectStackData> native$receiver$804 = TCItemState.ASPECTS;
                    net.minecraft.world.item.ItemStack native$argument$805 = stack;
                    dev.tc4port.thaumcraft.data.AspectStackData native$argument$806 = AspectStackData.EMPTY;
                    java.util.Objects.requireNonNull(native$receiver$804);
                    yield dev.tc4port.thaumcraft.api.item.ItemStatePlatform.getOrDefault(native$argument$805, native$receiver$804, native$argument$806);
                }
        }).amount(aspect.aspectId());
    }

    /**
     * Stores raw centivis, matching TC4's {@code addRealVis}. The returned
     * value is the amount accepted, rather than the legacy leftover value,
     * which makes transfers transactional.
     */
    public final int add(ItemStack stack, VisChannel aspect, int centivis) {
        if (centivis <= 0) {
            return 0;
        }
        AspectStackData storage = (switch(0) {
            default ->
                {
                    dev.tc4port.thaumcraft.api.data.ItemStateKey<dev.tc4port.thaumcraft.data.AspectStackData> native$receiver$511 = TCItemState.ASPECTS;
                    net.minecraft.world.item.ItemStack native$argument$512 = stack;
                    dev.tc4port.thaumcraft.data.AspectStackData native$argument$513 = AspectStackData.EMPTY;
                    java.util.Objects.requireNonNull(native$receiver$511);
                    yield dev.tc4port.thaumcraft.api.item.ItemStatePlatform.getOrDefault(native$argument$512, native$receiver$511, native$argument$513);
                }
        });
        AspectId aspectId = aspect.aspectId();
        int before = storage.amount(aspectId);
        int room = Math.max(0, maximumVis() - before);
        int after = before + Math.min(room, centivis);
        if (after == before) {
            return 0;
        }
        Map<AspectId, Integer> changed = new LinkedHashMap<>(storage.aspects());
        changed.put(aspectId, after);
        {
            dev.tc4port.thaumcraft.api.data.ItemStateKey<dev.tc4port.thaumcraft.data.AspectStackData> native$receiver$855 = TCItemState.ASPECTS;
            net.minecraft.world.item.ItemStack native$argument$856 = stack;
            dev.tc4port.thaumcraft.data.AspectStackData native$argument$857 = new AspectStackData(changed);
            java.util.Objects.requireNonNull(native$receiver$855);
            dev.tc4port.thaumcraft.api.item.ItemStatePlatform.set(native$argument$856, native$receiver$855, java.util.Objects.requireNonNull(native$argument$857, "value"));
        }
        return after - before;
    }

    public final boolean contains(ItemStack stack, Map<VisChannel, Integer> cost) {
        if (cost == null || cost.isEmpty() || cost.entrySet().stream().anyMatch(entry -> entry.getValue() == null || entry.getValue() < 0 || entry.getKey() == null)) {
            return false;
        }
        AspectStackData storage = (switch(0) {
            default ->
                {
                    dev.tc4port.thaumcraft.api.data.ItemStateKey<dev.tc4port.thaumcraft.data.AspectStackData> native$receiver$514 = TCItemState.ASPECTS;
                    net.minecraft.world.item.ItemStack native$argument$515 = stack;
                    dev.tc4port.thaumcraft.data.AspectStackData native$argument$516 = AspectStackData.EMPTY;
                    java.util.Objects.requireNonNull(native$receiver$514);
                    yield dev.tc4port.thaumcraft.api.item.ItemStatePlatform.getOrDefault(native$argument$515, native$receiver$514, native$argument$516);
                }
        });
        return cost.entrySet().stream().allMatch(entry -> storage.amount(entry.getKey().aspectId()) >= entry.getValue());
    }

    public final boolean consume(ItemStack stack, Map<VisChannel, Integer> cost) {
        if (!contains(stack, cost)) {
            return false;
        }
        Map<AspectId, Integer> remaining = new LinkedHashMap<>((switch(0) {
            default ->
                {
                    dev.tc4port.thaumcraft.api.data.ItemStateKey<dev.tc4port.thaumcraft.data.AspectStackData> native$receiver$397 = TCItemState.ASPECTS;
                    net.minecraft.world.item.ItemStack native$argument$398 = stack;
                    dev.tc4port.thaumcraft.data.AspectStackData native$argument$399 = AspectStackData.EMPTY;
                    java.util.Objects.requireNonNull(native$receiver$397);
                    yield dev.tc4port.thaumcraft.api.item.ItemStatePlatform.getOrDefault(native$argument$398, native$receiver$397, native$argument$399);
                }
        }).aspects());
        cost.forEach((aspect, amount) -> {
            AspectId id = aspect.aspectId();
            remaining.put(id, remaining.getOrDefault(id, 0) - amount);
        });
        {
            dev.tc4port.thaumcraft.api.data.ItemStateKey<dev.tc4port.thaumcraft.data.AspectStackData> native$receiver$858 = TCItemState.ASPECTS;
            net.minecraft.world.item.ItemStack native$argument$859 = stack;
            dev.tc4port.thaumcraft.data.AspectStackData native$argument$860 = new AspectStackData(remaining);
            java.util.Objects.requireNonNull(native$receiver$858);
            dev.tc4port.thaumcraft.api.item.ItemStatePlatform.set(native$argument$859, native$receiver$858, java.util.Objects.requireNonNull(native$argument$860, "value"));
        }
        return true;
    }

    public boolean canEquip(LivingEntity wearer) {
        var definition = dev.tc4port.thaumcraft.registry.TCRegistryDataMaps.VIS_AMULETS.get(this.builtInRegistryHolder());
        String research = definition == null ? (this.maximumVis == 25_000 ? "VISAMULET" : null) : definition.requiredResearch().orElse(null);
        return research == null || wearer instanceof Player player && TCObjectState.PLAYER_KNOWLEDGE.get(player).hasCompletedResearch(dev.tc4port.thaumcraft.api.research.ResearchKey.parse(research));
    }

    protected void appendSharedHoverText(ItemStack stack, List<Component> tooltip, TooltipFlag flag) {
        var definition = dev.tc4port.thaumcraft.registry.TCRegistryDataMaps.VIS_AMULETS.get(this.builtInRegistryHolder());
        String text = definition == null ? (this.maximumVis == 2_500 ? "item.ItemAmuletVis.text" : null) : definition.description().orElse(null);
        if (text != null)
            tooltip.add(Component.translatable(text).withStyle(ChatFormatting.AQUA));
        tooltip.add(Component.translatable("item.capacity.text").append(" " + this.maximumVis() / 100).withStyle(ChatFormatting.GOLD));
        AspectStackData stored = (switch(0) {
            default ->
                {
                    dev.tc4port.thaumcraft.api.data.ItemStateKey<dev.tc4port.thaumcraft.data.AspectStackData> native$receiver$517 = TCItemState.ASPECTS;
                    net.minecraft.world.item.ItemStack native$argument$518 = stack;
                    dev.tc4port.thaumcraft.data.AspectStackData native$argument$519 = AspectStackData.EMPTY;
                    java.util.Objects.requireNonNull(native$receiver$517);
                    yield dev.tc4port.thaumcraft.api.item.ItemStatePlatform.getOrDefault(native$argument$518, native$receiver$517, native$argument$519);
                }
        });
        DecimalFormat formatter = new DecimalFormat("#######.##");
        for (AspectId aspect : AspectCatalog.visChannels()) {
            if (!stored.aspects().containsKey(aspect)) {
                continue;
            }
            tooltip.add(Component.literal(" ").append(Component.literal(AspectCatalog.get(aspect).name()).withStyle(style -> style.withColor(AspectCatalog.get(aspect).color()))).append(" x " + formatter.format(stored.amount(aspect) / 100.0F)));
        }
    }

    private VisAmuletItem(net.minecraft.world.item.Item.Properties native$TooltipItem$arg0, Properties properties, int maximumVis, String descriptionId, boolean native$TooltipItem$captured) {
        super(native$TooltipItem$arg0);
        ItemStatePlatform.bindDefaults(this, properties);
        if (maximumVis <= 0) {
            throw new IllegalArgumentException("Vis amulet capacity must be positive");
        }
        this.maximumVis = maximumVis;
        this.descriptionId = descriptionId;
    }

    @Override
    public void initializeClient(java.util.function.Consumer<net.minecraftforge.client.extensions.common.IClientItemExtensions> installer) {
        platform$clientInstaller = installer;
        super.initializeClient(installer);
    }

    public void platform$clientExtension(Object extension) {
        java.util.Objects.requireNonNull(platform$clientInstaller, "Forge initializeClient must run before client extension registration").accept((net.minecraftforge.client.extensions.common.IClientItemExtensions) extension);
    }

    @Override
    public final void appendHoverText(ItemStack stack, net.minecraft.world.level.Level context, List<Component> tooltip, TooltipFlag flag) {
        appendSharedHoverText(stack, tooltip, flag);
        super.appendHoverText(stack, context, tooltip, flag);
    }
}
