package dev.tc4port.thaumcraft.api.aspect;

import java.util.Collections;
import java.util.EnumMap;
import java.util.Map;
import java.util.Objects;

/**
 * Immutable whole-vis recipe cost over the six fixed vis channels.
 *
 * <p>This type deliberately cannot represent partial vis. Runtime payment
 * APIs use {@link VisCost}, whose unit is centivis.</p>
 */
public record WholeVisCost(Map<VisChannel, Integer> amounts) {

    public WholeVisCost {
        Objects.requireNonNull(amounts, "amounts");
        if (amounts.isEmpty()) {
            throw new IllegalArgumentException("A whole-vis cost must not be empty");
        }
        EnumMap<VisChannel, Integer> checked = new EnumMap<>(VisChannel.class);
        amounts.forEach((channel, amount) -> {
            Objects.requireNonNull(channel, "channel");
            Objects.requireNonNull(amount, "amount");
            if (amount <= 0 || amount > Integer.MAX_VALUE / 100) {
                throw new IllegalArgumentException("A whole-vis cost must be positive and fit in " + "centivis: " + channel);
            }
            checked.put(channel, amount);
        });
        amounts = Collections.unmodifiableMap(checked);
    }

    public static WholeVisCost of(VisChannel channel, int amount) {
        return new WholeVisCost(Map.of(channel, amount));
    }

    /**
     * Converts this recipe cost to the centivis payment unit.
     */
    public VisCost toCentivis() {
        return VisCost.ofWholeVis(this.amounts);
    }
}
