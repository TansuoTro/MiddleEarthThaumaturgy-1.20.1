package dev.tc4port.thaumcraft.block;

import com.mojang.serialization.MapCodec;
import dev.tc4port.thaumcraft.block.entity.ArcaneBellowsBlockEntity;
import dev.tc4port.thaumcraft.registry.TCBlockEntities;
import javax.annotation.Nullable;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityTicker;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.DirectionProperty;
import net.minecraft.world.level.pathfinder.PathComputationType;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.VoxelShape;
import net.minecraft.world.phys.BlockHitResult;
import dev.tc4port.thaumcraft.nativeimpl.ClientExtensionTarget;
import dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.phys.HitResult;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.Explosion;

/**
 * TC4's metadata-zero wooden device.  The facing points from the bellows into
 * the block it is blowing at, matching {@code BlockWoodenDeviceItem}.
 */
public final class ArcaneBellowsBlock extends net.minecraft.world.level.block.BaseEntityBlock implements dev.tc4port.thaumcraft.nativeimpl.ClientExtensionTarget {

    // Forge calls initializeClient from the native superclass constructor. Do not add a field initializer.
    private java.util.function.Consumer<net.minecraftforge.client.extensions.common.IClientBlockExtensions> platform$clientInstaller;

    public static final MapCodec<ArcaneBellowsBlock> CODEC = ArcaneBellowsBlock.native$BlockCodecPlatform$simple(ArcaneBellowsBlock::new);

    public static final DirectionProperty FACING = BlockStateProperties.FACING;

    private static final VoxelShape SHAPE = Block.box(1.6, 0.0, 1.6, 14.4, 16.0, 14.4);

    public ArcaneBellowsBlock(BlockBehaviour.Properties properties) {
        this(properties, properties, true);
    }

    protected MapCodec<ArcaneBellowsBlock> codec() {
        return CODEC;
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(FACING);
    }

    @Nullable
    @Override
    public BlockState getStateForPlacement(BlockPlaceContext context) {
        return this.defaultBlockState().setValue(FACING, context.getClickedFace().getOpposite());
    }

    @Override
    public void setPlacedBy(Level level, BlockPos pos, BlockState state, @Nullable LivingEntity placer, ItemStack stack) {
        super.setPlacedBy(level, pos, state, placer, stack);
        if (level.getBlockEntity(pos) instanceof ArcaneBellowsBlockEntity bellows) {
            bellows.setOnVanillaFurnace(level.getBlockState(pos.relative(state.getValue(FACING))).is(Blocks.FURNACE));
        }
    }

    protected InteractionResult interactWithoutItem(BlockState state, Level level, BlockPos pos, Player player, BlockHitResult hitResult) {
        /* Metadata zero consumed activation even though it had no GUI. */
        return net.minecraft.world.InteractionResult.sidedSuccess(level.isClientSide);
    }

    @Override
    public int getLightBlock(BlockState state, BlockGetter level, BlockPos pos) {
        return 0;
    }

    @Override
    public VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
        return SHAPE;
    }

    @Nullable
    @Override
    public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        return new ArcaneBellowsBlockEntity(pos, state);
    }

    @Nullable
    @Override
    public <T extends BlockEntity> BlockEntityTicker<T> getTicker(Level level, BlockState state, BlockEntityType<T> type) {
        return createTickerHelper(type, TCBlockEntities.ARCANE_BELLOWS.get(), level.isClientSide ? ArcaneBellowsBlockEntity::clientTick : ArcaneBellowsBlockEntity::serverTick);
    }

    @Override
    public RenderShape getRenderShape(BlockState state) {
        return RenderShape.ENTITYBLOCK_ANIMATED;
    }

    /**
     * Returns whether a bellows at {@code bellowsPos} points exactly at the
     * requested target and is not disabled by redstone.
     */
    public static boolean blowsToward(Level level, BlockPos bellowsPos, BlockPos targetPos) {
        if (!level.hasChunksAt(bellowsPos.offset(-2, 0, -2), bellowsPos.offset(2, 0, 2)))
            return false;
        BlockState state = level.getBlockState(bellowsPos);
        return state.getBlock() instanceof ArcaneBellowsBlock && bellowsPos.relative(state.getValue(FACING)).equals(targetPos) && !level.hasNeighborSignal(bellowsPos);
    }

    @Override
    public boolean isPathfindable(BlockState state, BlockGetter level, BlockPos pos, PathComputationType pathType) {
        // The bellows fills nearly the whole cell at full height.
        return false;
    }

    private ArcaneBellowsBlock(net.minecraft.world.level.block.state.BlockBehaviour.Properties native$NativeEntityBlock$arg0, BlockBehaviour.Properties properties, boolean native$NativeEntityBlock$captured) {
        super(native$NativeEntityBlock$arg0);
        this.registerDefaultState(this.stateDefinition.any().setValue(FACING, Direction.NORTH));
    }

    @Override
    public void initializeClient(java.util.function.Consumer<net.minecraftforge.client.extensions.common.IClientBlockExtensions> installer) {
        platform$clientInstaller = installer;
        super.initializeClient(installer);
    }

    @Override
    public void platform$clientExtension(Object extension) {
        java.util.Objects.requireNonNull(platform$clientInstaller, "Forge initializeClient must run before client extension registration").accept((net.minecraftforge.client.extensions.common.IClientBlockExtensions) extension);
    }

    @Override
    public InteractionResult use(BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
        ItemUseResult result = (switch(0) {
            default ->
                {
                    net.minecraft.world.item.ItemStack native$bodyOperand$4088 = player.getItemInHand(hand);
                    net.minecraft.world.level.block.state.BlockState native$bodyOperand$4089 = state;
                    net.minecraft.world.level.Level native$bodyOperand$4090 = level;
                    net.minecraft.core.BlockPos native$bodyOperand$4091 = pos;
                    net.minecraft.world.entity.player.Player native$bodyOperand$4092 = player;
                    net.minecraft.world.InteractionHand native$bodyOperand$4093 = hand;
                    net.minecraft.world.phys.BlockHitResult native$bodyOperand$4094 = hit;
                    dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult native$bodyResult$4095 = null;
                    native$bodyReturn$4096: {
                        if (true) {
                            {
                                native$bodyResult$4095 = dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
                                break native$bodyReturn$4096;
                            }
                        }
                    }
                    yield native$bodyResult$4095;
                }
        });
        return result == ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION ? (hand == InteractionHand.MAIN_HAND ? (switch(0) {
            default ->
                {
                    net.minecraft.world.level.block.state.BlockState native$bodyOperand$3443 = state;
                    net.minecraft.world.level.Level native$bodyOperand$3444 = level;
                    net.minecraft.core.BlockPos native$bodyOperand$3445 = pos;
                    net.minecraft.world.entity.player.Player native$bodyOperand$3446 = player;
                    net.minecraft.world.phys.BlockHitResult native$bodyOperand$3447 = hit;
                    net.minecraft.world.InteractionResult native$bodyResult$3448 = null;
                    native$bodyReturn$3449: {
                        if (true) {
                            {
                                native$bodyResult$3448 = net.minecraft.world.InteractionResult.sidedSuccess(native$bodyOperand$3444.isClientSide);
                                break native$bodyReturn$3449;
                            }
                        }
                    }
                    yield native$bodyResult$3448;
                }
        }) : InteractionResult.PASS) : result.result();
    }

    protected ItemUseResult interactWithItem(ItemStack stack, BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
        return dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
    }

    @Override
    public void playerWillDestroy(Level level, BlockPos pos, BlockState state, Player player) {
        {
            net.minecraft.world.level.Level native$bodyOperand$5636 = level;
            net.minecraft.core.BlockPos native$bodyOperand$5637 = pos;
            net.minecraft.world.level.block.state.BlockState native$bodyOperand$5638 = state;
            net.minecraft.world.entity.player.Player native$bodyOperand$5639 = player;
            net.minecraft.world.level.block.state.BlockState native$bodyResult$5640 = null;
            native$bodyReturn$5641: {
                if (true) {
                    super.playerWillDestroy(native$bodyOperand$5636, native$bodyOperand$5637, native$bodyOperand$5638, native$bodyOperand$5639);
                    {
                        native$bodyResult$5640 = native$bodyOperand$5638;
                        break native$bodyReturn$5641;
                    }
                }
            }
        }
    }

    public BlockState beforePlayerDestroy(Level level, BlockPos pos, BlockState state, Player player) {
        super.playerWillDestroy(level, pos, state, player);
        return state;
    }

    protected boolean survivesSharedExplosion() {
        return false;
    }

    public int getExpDrop(net.minecraft.world.level.block.state.BlockState native$callbackInput$1050, net.minecraft.world.level.LevelReader native$callbackInput$1051, net.minecraft.util.RandomSource native$callbackInput$1052, net.minecraft.core.BlockPos native$callbackInput$1053, int native$callbackInput$1054, int native$callbackInput$1055) {
        net.minecraft.world.level.block.state.BlockState state = native$callbackInput$1050;
        net.minecraft.util.RandomSource random = native$callbackInput$1052;
        return 0;
    }

    @Override
    public void onBlockExploded(BlockState state, Level level, BlockPos pos, Explosion explosion) {
        if (!(switch(0) {
            default ->
                {
                    boolean native$bodyResult$5207 = false;
                    native$bodyReturn$5208: {
                        if (true) {
                            {
                                native$bodyResult$5207 = false;
                                break native$bodyReturn$5208;
                            }
                        }
                    }
                    yield native$bodyResult$5207;
                }
        }))
            super.onBlockExploded(state, level, pos, explosion);
    }

    @Override
    public boolean canDropFromExplosion(BlockState state, BlockGetter level, BlockPos pos, Explosion explosion) {
        return !(switch(0) {
            default ->
                {
                    boolean native$bodyResult$4097 = false;
                    native$bodyReturn$4098: {
                        if (true) {
                            {
                                native$bodyResult$4097 = false;
                                break native$bodyReturn$4098;
                            }
                        }
                    }
                    yield native$bodyResult$4097;
                }
        }) && super.canDropFromExplosion(state, level, pos, explosion);
    }

    static private <B extends net.minecraft.world.level.block.Block> com.mojang.serialization.MapCodec<B> native$BlockCodecPlatform$simple(java.util.function.Function<net.minecraft.world.level.block.state.BlockBehaviour.Properties, B> factory) {
        // Vanilla 1.21's Properties codec is a unit codec. Retain that schema for shared block definitions.
        return com.mojang.serialization.codecs.RecordCodecBuilder.mapCodec(instance -> instance.group(com.mojang.serialization.Codec.unit(net.minecraft.world.level.block.state.BlockBehaviour.Properties::of).fieldOf("properties").forGetter((B block) -> net.minecraft.world.level.block.state.BlockBehaviour.Properties.copy(block))).apply(instance, factory));
    }
}
