package dev.tc4port.thaumcraft.api.player;

import java.util.*;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Player;

/**
 * Forge's single abilities flag needs shared source ownership for cooperating consumers.
 */
public final class FlightAccess {

    private static final Map<Player, Lease> PLAYERS = new WeakHashMap<>();

    private FlightAccess() {
    }

    private static final class Lease {

        final boolean previous;

        final Set<ResourceLocation> owners = new HashSet<>();

        Lease(boolean previous) {
            this.previous = previous;
        }
    }

    public static synchronized void grant(Player player, ResourceLocation id) {
        Lease lease = PLAYERS.computeIfAbsent(player, p -> new Lease(p.getAbilities().mayfly));
        lease.owners.add(id);
        boolean changed = !player.getAbilities().mayfly;
        player.getAbilities().mayfly = true;
        if (changed && player instanceof ServerPlayer server)
            server.onUpdateAbilities();
    }

    public static synchronized boolean revoke(Player player, ResourceLocation id) {
        Lease lease = PLAYERS.get(player);
        if (lease == null || !lease.owners.remove(id))
            return false;
        if (lease.owners.isEmpty()) {
            PLAYERS.remove(player);
            boolean value = lease.previous || player.isCreative() || player.isSpectator();
            boolean changed = value != player.getAbilities().mayfly;
            player.getAbilities().mayfly = value;
            if (changed && player instanceof ServerPlayer server)
                server.onUpdateAbilities();
        }
        return true;
    }

    public static synchronized boolean owns(Player player, ResourceLocation id) {
        Lease lease = PLAYERS.get(player);
        return lease != null && lease.owners.contains(id);
    }

    public static boolean mayFly(Player player) {
        return player.getAbilities().mayfly;
    }
}
