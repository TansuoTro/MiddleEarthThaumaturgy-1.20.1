package dev.tc4port.thaumcraft.api.item;

import dev.tc4port.thaumcraft.api.event.Damage;
import dev.tc4port.thaumcraft.api.event.PlatformIdentity;
import com.mojang.serialization.Codec;
import com.mojang.serialization.DataResult;
import dev.tc4port.thaumcraft.api.data.ItemStateKey;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.NbtOps;
import net.minecraft.nbt.NumericTag;
import net.minecraft.nbt.Tag;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Item;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.StringTag;
import java.util.Map;
import java.util.Set;
import java.util.LinkedHashSet;
import java.util.Objects;
import net.minecraft.world.item.Items;
import net.minecraft.core.Registry;
import net.minecraft.resources.ResourceKey;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.IForgeRegistry;
import net.minecraftforge.registries.RegistryBuilder;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.function.Supplier;

/**
 * Forge-native ItemStack NBT storage for the shared current field schemas.
 */
public final class ItemStatePlatform {

    private static String root(ItemStateKey<?> key) {
        return key.id().getNamespace() + ":item_state";
    }

    private static final ResourceKey<Registry<ItemStateKey<?>>> FIELD_REGISTRY_KEY = ResourceKey.createRegistryKey(new ResourceLocation(PlatformIdentity.NAMESPACE, "item_state_fields"));

    private static final DeferredRegister<ItemStateKey<?>> FIELD_REGISTRY = DeferredRegister.create(FIELD_REGISTRY_KEY, PlatformIdentity.NAMESPACE);

    // Field IDs are stored as resource locations in NBT/JSON, never numeric registry IDs.
    private static final Supplier<IForgeRegistry<ItemStateKey<?>>> FIELDS = FIELD_REGISTRY.makeRegistry(() -> new RegistryBuilder<ItemStateKey<?>>().disableOverrides().disableSaving().disableSync());

    private static final AtomicBoolean REGISTRY_ATTACHED = new AtomicBoolean();

    public static java.util.List<ItemStateKey<?>> keys() {
        var registry = FIELDS.get();
        return registry == null ? java.util.List.of() : java.util.List.copyOf(registry.getValues());
    }

    public static ItemStateKey<?> find(ResourceLocation id) {
        var registry = FIELDS.get();
        return registry == null ? null : registry.getValue(id);
    }

    private static final String REMOVED_DEFAULTS = "removed_defaults";

    private static final Map<Item.Properties, Map<ResourceLocation, Object>> PROPERTY_DEFAULTS = new java.util.WeakHashMap<>();

    private static final Map<Item, Map<ResourceLocation, Object>> ITEM_DEFAULTS = new java.util.concurrent.ConcurrentHashMap<>();

    // ItemStack.CODEC in 1.20.1 omits ForgeCaps. Native save/of preserves the full carrier.
    public static final Codec<ItemStack> OPTIONAL_STACK_CODEC = CompoundTag.CODEC.flatXmap(ItemStatePlatform::decodeStack, stack -> DataResult.success(stack.isEmpty() ? new CompoundTag() : stack.save(new CompoundTag())));

    private ItemStatePlatform() {
    }

    public static synchronized <T> Item.Properties withDefault(Item.Properties properties, ItemStateKey<T> key, T value) {
        Objects.requireNonNull(properties);
        Objects.requireNonNull(value);
        PROPERTY_DEFAULTS.computeIfAbsent(properties, ignored -> new java.util.LinkedHashMap<>()).put(key.id(), value);
        return properties;
    }

    public static synchronized void bindDefaults(Item item, Item.Properties properties) {
        Objects.requireNonNull(item);
        Objects.requireNonNull(properties);
        Map<ResourceLocation, Object> defaults = Map.copyOf(PROPERTY_DEFAULTS.getOrDefault(properties, Map.of()));
        if (ITEM_DEFAULTS.putIfAbsent(item, defaults) != null)
            throw new IllegalStateException("Item default state already bound");
    }

    @SuppressWarnings("unchecked")
    private static <T> T defaultValue(ItemStack stack, ItemStateKey<T> key) {
        return stack.isEmpty() ? null : (T) ITEM_DEFAULTS.getOrDefault(stack.getItem(), Map.of()).get(key.id());
    }

    public static boolean hasStackChanges(ItemStack stack) {
        // Native constructors can populate prototype data such as Damage=0 on tools.
        // Compare against that same native prototype instead of rejecting every non-null tag.
        return !java.util.Objects.equals(stack.getTag(), new ItemStack(stack.getItem()).getTag());
    }

    private static CompoundTag fields(ItemStack stack, ItemStateKey<?> key) {
        CompoundTag tag = stack.getTag();
        if (tag == null || !tag.contains(root(key)))
            return null;
        if (!tag.contains(root(key), Tag.TAG_COMPOUND)) {
            throw new IllegalArgumentException("Item state must be a compound");
        }
        return tag.getCompound(root(key));
    }

    private static Set<String> removedDefaults(CompoundTag fields) {
        if (fields == null || !fields.contains(REMOVED_DEFAULTS))
            return Set.of();
        var removed = new LinkedHashSet<String>();
        if (!(fields.get(REMOVED_DEFAULTS) instanceof ListTag list) || !list.isEmpty() && list.getElementType() != Tag.TAG_STRING) {
            throw new IllegalArgumentException("Removed item defaults must be a string list");
        }
        for (Tag entry : list) {
            String id = entry.getAsString();
            if (ResourceLocation.tryParse(id) == null || !removed.add(id) || fields.contains(id)) {
                throw new IllegalArgumentException("Invalid or conflicting removed item default: " + id);
            }
        }
        return removed;
    }

    private static void writeRemovedDefaults(CompoundTag fields, Set<String> removed) {
        if (removed.isEmpty())
            fields.remove(REMOVED_DEFAULTS);
        else {
            var list = new ListTag();
            removed.stream().sorted().forEach(id -> list.add(StringTag.valueOf(id)));
            fields.put(REMOVED_DEFAULTS, list);
        }
    }

    private static CompoundTag writableFields(ItemStack stack, CompoundTag fields, ItemStateKey<?> key) {
        if (fields != null)
            return fields;
        fields = new CompoundTag();
        stack.getOrCreateTag().put(root(key), fields);
        return fields;
    }

    private static void clean(ItemStack stack, CompoundTag fields, ItemStateKey<?> key) {
        if (fields != null && fields.isEmpty())
            stack.removeTagKey(root(key));
    }

    public static <T> T get(ItemStack stack, ItemStateKey<T> key) {
        CompoundTag fields = fields(stack, key);
        if (removedDefaults(fields).contains(key.id().toString()))
            return null;
        if (fields == null || !fields.contains(key.id().toString()))
            return defaultValue(stack, key);
        return require(key.codec().parse(NbtOps.INSTANCE, fields.get(key.id().toString())), key.id());
    }

    public static <T> T getOrDefault(ItemStack stack, ItemStateKey<T> key, T fallback) {
        T value = get(stack, key);
        return value == null ? fallback : value;
    }

    public static boolean has(ItemStack stack, ItemStateKey<?> key) {
        CompoundTag fields = fields(stack, key);
        return !removedDefaults(fields).contains(key.id().toString()) && (fields != null && fields.contains(key.id().toString()) || defaultValue(stack, key) != null);
    }

    public static <T> T set(ItemStack stack, ItemStateKey<T> key, T value) {
        if (stack.isEmpty())
            throw new IllegalArgumentException("Cannot store item state on an empty stack");
        // Encode completely before changing the owner, so failure is atomic.
        Tag encoded = require(key.codec().encodeStart(NbtOps.INSTANCE, value), key.id());
        T previous = get(stack, key);
        // Native PatchedDataComponentMap.set returns the prototype for a previously removed default.
        if (previous == null)
            previous = defaultValue(stack, key);
        CompoundTag fields = fields(stack, key);
        Set<String> removed = new LinkedHashSet<>(removedDefaults(fields));
        removed.remove(key.id().toString());
        if (Objects.equals(defaultValue(stack, key), value)) {
            if (fields == null)
                return previous;
            fields.remove(key.id().toString());
        } else {
            fields = writableFields(stack, fields, key);
            fields.put(key.id().toString(), encoded);
        }
        writeRemovedDefaults(fields, removed);
        clean(stack, fields, key);
        return previous;
    }

    public static <T> T remove(ItemStack stack, ItemStateKey<T> key) {
        T previous = get(stack, key);
        CompoundTag fields = fields(stack, key);
        Set<String> removed = new LinkedHashSet<>(removedDefaults(fields));
        if (defaultValue(stack, key) != null) {
            fields = writableFields(stack, fields, key);
            removed.add(key.id().toString());
        } else
            removed.remove(key.id().toString());
        if (fields != null) {
            fields.remove(key.id().toString());
            writeRemovedDefaults(fields, removed);
            clean(stack, fields, key);
        }
        return previous;
    }

    public static Object contentsForHash(ItemStack stack) {
        return stack.getTag();
    }

    private static <T> T require(DataResult<T> result, ResourceLocation key) {
        return result.result().orElseThrow(() -> new IllegalArgumentException("Invalid item state " + key + ": " + result.error().map(error -> error.message()).orElse("No decoded value")));
    }

    private static DataResult<ItemStack> decodeStack(CompoundTag tag) {
        if (tag.isEmpty())
            return DataResult.success(ItemStack.EMPTY);
        ResourceLocation id = tag.contains("id", Tag.TAG_STRING) ? ResourceLocation.tryParse(tag.getString("id")) : null;
        if (id == null || !BuiltInRegistries.ITEM.containsKey(id) || BuiltInRegistries.ITEM.get(id) == Items.AIR) {
            return DataResult.error(() -> "Invalid stored item identity");
        }
        if (!(tag.get("Count") instanceof NumericTag count) || count.getAsInt() < 1 || count.getAsInt() > Byte.MAX_VALUE) {
            return DataResult.error(() -> "Invalid stored item count");
        }
        for (String field : new String[] { "tag", "ForgeCaps" }) {
            if (tag.contains(field) && !tag.contains(field, Tag.TAG_COMPOUND)) {
                return DataResult.error(() -> "Invalid stored item " + field);
            }
        }
        ItemStack result = ItemStack.of(tag.copy());
        return result.isEmpty() ? DataResult.error(() -> "Stored item could not be loaded") : DataResult.success(result);
    }

    /**
     * Queue declarations during mod construction; Forge owns publication and freezing.
     */
    public static void register(Object bus, java.util.List<? extends ItemStateKey<?>> fields) {
        IEventBus eventBus = (IEventBus) Objects.requireNonNull(bus, "bus");
        if (FIELDS.get() != null)
            throw new IllegalStateException("Item fields must be queued before NewRegistryEvent completes");
        var batch = java.util.List.copyOf(fields);
        var registers = new java.util.LinkedHashMap<String, DeferredRegister<ItemStateKey<?>>>();
        for (var field : batch) {
            var register = registers.computeIfAbsent(field.id().getNamespace(), namespace -> DeferredRegister.create(FIELD_REGISTRY_KEY, namespace));
            register.register(field.id().getPath(), () -> field);
        }
        // Only the empty registry creator is shared. Each call owns its native
        // pending entries, including when several mods explicitly share this API.
        if (REGISTRY_ATTACHED.compareAndSet(false, true))
            FIELD_REGISTRY.register(eventBus);
        registers.values().forEach(register -> register.register(eventBus));
    }
}
