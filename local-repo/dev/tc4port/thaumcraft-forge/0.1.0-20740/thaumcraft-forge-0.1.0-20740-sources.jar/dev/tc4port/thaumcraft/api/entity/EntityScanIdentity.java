package dev.tc4port.thaumcraft.api.entity;

/**
 * Case-sensitive entity identity used as the base of the persisted scan hash
 * and by hidden-research entity triggers.
 *
 * <p>This is deliberately not a {@code ResourceLocation}: the fixed values
 * reproduce the historical hash preimages exactly. Identity equality is
 * global: two rules using the same spelling intentionally share a clue
 * identity and scan-hash base. Literal, dynamic, runtime and root suffixes can
 * still produce different final scan keys. New addon-owned identities should
 * therefore use a stable namespace-style spelling such as
 * {@code example:entity_variant}.</p>
 */
public record EntityScanIdentity(String serialized) {

    public static final int MAX_CHARACTERS = 256;

    public EntityScanIdentity {
        if (serialized == null || serialized.isBlank() || serialized.length() > MAX_CHARACTERS) {
            throw new IllegalArgumentException("Invalid entity scan identity: " + serialized);
        }
    }

    @Override
    public String toString() {
        return this.serialized;
    }
}
