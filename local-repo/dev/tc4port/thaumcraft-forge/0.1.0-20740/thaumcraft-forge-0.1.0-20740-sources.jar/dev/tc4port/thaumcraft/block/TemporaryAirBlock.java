package dev.tc4port.thaumcraft.block;

import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.structure.BoundingBox;
import net.minecraft.world.ticks.LevelChunkTicks;
import java.lang.Math;
import dev.tc4port.thaumcraft.nativeimpl.ClientExtensionTarget;
import dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.level.pathfinder.PathComputationType;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.level.Explosion;
import net.minecraft.world.level.BlockGetter;

/**
 * Air-like spell fields with random expiry and a sampled scheduled fallback.
 */
public abstract class TemporaryAirBlock extends net.minecraft.world.level.block.Block implements dev.tc4port.thaumcraft.nativeimpl.ClientExtensionTarget {

    // Forge calls initializeClient from the native superclass constructor. Do not add a field initializer.
    private java.util.function.Consumer<net.minecraftforge.client.extensions.common.IClientBlockExtensions> platform$clientInstaller;

    // Three selections from a 4096-cell section per tick: the default random
    // tick lifetime, sampled once for a fallback independent of section counts.
    private static final double LOG_SURVIVAL_PER_TICK = 3.0 * Math.log1p(-1.0 / 4096.0);

    protected TemporaryAirBlock(BlockBehaviour.Properties properties) {
        this(properties, properties, true);
    }

    static int sampleLifetimeTicks(RandomSource random) {
        return 1 + (int) (Math.log1p(-random.nextDouble()) / LOG_SURVIVAL_PER_TICK);
    }

    @Override
    public void onPlace(BlockState state, Level level, BlockPos pos, BlockState oldState, boolean movedByPiston) {
        super.onPlace(state, level, pos, oldState, movedByPiston);
        if (!oldState.is(this) && level instanceof ServerLevel server) {
            server.scheduleTick(pos, this, sampleLifetimeTicks(server.random));
        }
    }

    /**
     * A spell can shorten an existing field's life, but cannot renew it.
     */
    public final void expireWithin(ServerLevel level, BlockPos pos, int maximumDelayTicks) {
        if (!level.getBlockState(pos).is(this) || level.getBlockTicks().willTickThisTick(pos, this)) {
            return;
        }
        int delay = Math.max(1, maximumDelayTicks);
        long deadline = level.getGameTime() + delay;
        LevelChunkTicks<Block> ticks = (LevelChunkTicks<Block>) level.getChunkAt(pos).getBlockTicks();
        boolean expiresSooner = ticks.getAll().anyMatch(tick -> tick.type() == this && tick.pos().equals(pos) && tick.triggerTick() <= deadline);
        if (expiresSooner) {
            return;
        }
        // Native scheduling deduplicates by position and block, even when a
        // new deadline is earlier. Cancel this occupied cell before replacing
        // its expiry; neighbouring cells and fluid ticks are untouched.
        level.getBlockTicks().clearArea(new BoundingBox(pos));
        level.scheduleTick(pos, this, delay);
    }

    @Override
    public void onRemove(BlockState state, Level level, BlockPos pos, BlockState newState, boolean movedByPiston) {
        if (!newState.is(this) && level instanceof ServerLevel server) {
            dev.tc4port.thaumcraft.common.FocusFieldDamage.forget(server, pos);
        }
        if (!newState.is(this) && level instanceof ServerLevel server && (server.getBlockTicks().hasScheduledTick(pos, this) || server.getBlockTicks().willTickThisTick(pos, this))) {
            // A later field at the same position must not inherit this
            // instance's deadline, including ticks already collected to run.
            server.getBlockTicks().clearArea(new BoundingBox(pos));
        }
        super.onRemove(state, level, pos, newState, movedByPiston);
    }

    @Override
    public final void tick(BlockState state, ServerLevel level, BlockPos pos, RandomSource random) {
        level.removeBlock(pos, false);
    }

    @Override
    public final void randomTick(BlockState state, ServerLevel level, BlockPos pos, RandomSource random) {
        level.removeBlock(pos, false);
    }

    private TemporaryAirBlock(net.minecraft.world.level.block.state.BlockBehaviour.Properties native$NativeBlock$arg0, BlockBehaviour.Properties properties, boolean native$NativeBlock$captured) {
        super(native$NativeBlock$arg0);
    }

    @Override
    public void initializeClient(java.util.function.Consumer<net.minecraftforge.client.extensions.common.IClientBlockExtensions> installer) {
        platform$clientInstaller = installer;
        super.initializeClient(installer);
    }

    @Override
    public void platform$clientExtension(Object extension) {
        java.util.Objects.requireNonNull(platform$clientInstaller, "Forge initializeClient must run before client extension registration").accept((net.minecraftforge.client.extensions.common.IClientBlockExtensions) extension);
    }

    @Override
    public InteractionResult use(BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
        ItemUseResult result = interactWithItem(player.getItemInHand(hand), state, level, pos, player, hand, hit);
        return result == ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION ? (hand == InteractionHand.MAIN_HAND ? interactWithoutItem(state, level, pos, player, hit) : InteractionResult.PASS) : result.result();
    }

    protected ItemUseResult interactWithItem(ItemStack stack, BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
        return ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
    }

    protected InteractionResult interactWithoutItem(BlockState state, Level level, BlockPos pos, Player player, BlockHitResult hit) {
        return super.use(state, level, pos, player, InteractionHand.MAIN_HAND, hit);
    }

    @Override
    public void playerWillDestroy(Level level, BlockPos pos, BlockState state, Player player) {
        beforePlayerDestroy(level, pos, state, player);
    }

    public BlockState beforePlayerDestroy(Level level, BlockPos pos, BlockState state, Player player) {
        super.playerWillDestroy(level, pos, state, player);
        return state;
    }

    protected boolean survivesSharedExplosion() {
        return false;
    }

    public int getExpDrop(net.minecraft.world.level.block.state.BlockState native$callbackInput$1145, net.minecraft.world.level.LevelReader native$callbackInput$1146, net.minecraft.util.RandomSource native$callbackInput$1147, net.minecraft.core.BlockPos native$callbackInput$1148, int native$callbackInput$1149, int native$callbackInput$1150) {
        net.minecraft.world.level.block.state.BlockState state = native$callbackInput$1145;
        net.minecraft.util.RandomSource random = native$callbackInput$1147;
        return 0;
    }

    @Override
    public void onBlockExploded(BlockState state, Level level, BlockPos pos, Explosion explosion) {
        if (!survivesSharedExplosion())
            super.onBlockExploded(state, level, pos, explosion);
    }

    @Override
    public boolean canDropFromExplosion(BlockState state, BlockGetter level, BlockPos pos, Explosion explosion) {
        return !survivesSharedExplosion() && super.canDropFromExplosion(state, level, pos, explosion);
    }
}
