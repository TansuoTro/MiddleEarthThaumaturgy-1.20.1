package dev.tc4port.thaumcraft.api.machine;

import dev.tc4port.thaumcraft.block.ArcaneBellowsBlock;
import java.util.Objects;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.level.Level;

/**
 * Stable observation of loaded, correctly oriented TC arcane bellows.
 */
public final class ArcaneBellowsApi {

    private ArcaneBellowsApi() {
    }

    public static boolean blowsToward(Level level, BlockPos bellowsPos, BlockPos targetPos) {
        Objects.requireNonNull(level, "level");
        Objects.requireNonNull(bellowsPos, "bellowsPos");
        Objects.requireNonNull(targetPos, "targetPos");
        return level.hasChunkAt(bellowsPos) && ArcaneBellowsBlock.blowsToward(level, bellowsPos, targetPos);
    }

    public static int countAdjacentBlowingToward(Level level, BlockPos targetPos) {
        Objects.requireNonNull(level, "level");
        Objects.requireNonNull(targetPos, "targetPos");
        int count = 0;
        for (Direction direction : Direction.values()) {
            if (blowsToward(level, targetPos.relative(direction), targetPos)) {
                count++;
            }
        }
        return count;
    }
}
