package dev.tc4port.thaumcraft.api.recipe;

import dev.tc4port.thaumcraft.registry.TCRecipes;
import java.util.List;
import java.util.Optional;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.Level;

/**
 * Current native arcane recipes; lookups always observe the level's latest recipe reload.
 */
public final class ArcaneCraftingApi {

    private ArcaneCraftingApi() {
    }

    /**
     * Native type for addon-owned arcane serializers; worktable gates still apply.
     */
    public static net.minecraft.world.item.crafting.RecipeType<ArcaneCraftingRecipe> recipeType() {
        return TCRecipes.ARCANE.get();
    }

    public static List<ArcaneCraftingRecipe> recipes(Level level) {
        return ArcaneCraftingApi.native$RecipeAccess$all(level.getRecipeManager(), TCRecipes.ARCANE.get());
    }

    public static Optional<ArcaneCraftingRecipe> byId(Level level, ResourceLocation id) {
        return recipes(level).stream().filter(recipe -> recipe.getId().equals(id)).findFirst();
    }

    @SuppressWarnings({ "unchecked", "rawtypes" })
    static private <T extends net.minecraft.world.item.crafting.Recipe<?>> java.util.List<T> native$RecipeAccess$all(net.minecraft.world.item.crafting.RecipeManager manager, net.minecraft.world.item.crafting.RecipeType<T> type) {
        java.util.List<T> values = manager.getAllRecipesFor((net.minecraft.world.item.crafting.RecipeType) type);
        return values.stream().map(ArcaneCraftingApi::native$RecipeAccess$entry).toList();
    }

    static private <T extends net.minecraft.world.item.crafting.Recipe<?>> T native$RecipeAccess$entry(T recipe) {
        return ArcaneCraftingApi.native$RecipeAccess$identified(recipe.getId(), recipe);
    }

    static private <T extends net.minecraft.world.item.crafting.Recipe<?>> T native$RecipeAccess$identified(net.minecraft.resources.ResourceLocation id, T recipe) {
        dev.tc4port.thaumcraft.api.recipe.NativeRecipeIds.bind(recipe, id);
        return recipe;
    }
}
