package dev.tc4port.thaumcraft.api.research;

/**
 * Stable read-only flags that affect research-tree visibility and behavior.
 */
public enum ResearchEntryFlag {

    SPECIAL,
    STUB,
    LOST,
    CONCEALED,
    HIDDEN,
    VIRTUAL,
    AUTO_UNLOCK,
    ROUND,
    SECONDARY
}
