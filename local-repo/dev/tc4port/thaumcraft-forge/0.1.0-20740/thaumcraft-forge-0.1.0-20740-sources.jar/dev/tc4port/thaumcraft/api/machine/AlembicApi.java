package dev.tc4port.thaumcraft.api.machine;

import dev.tc4port.thaumcraft.util.RuntimeWarnings;
import dev.tc4port.thaumcraft.api.aspect.AspectId;
import dev.tc4port.thaumcraft.api.essentia.EssentiaTransferMode;
import dev.tc4port.thaumcraft.block.entity.ArcaneAlembicBlockEntity;
import java.util.Objects;
import java.util.Optional;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.Level;

/**
 * Stable loaded-only access to TC's direct furnace-to-alembic contract.
 */
public final class AlembicApi {

    private AlembicApi() {
    }

    /**
     * Reads a snapshot without loading a chunk, retaining over-capacity contents.
     * Empty means the target is unloaded or is not a TC arcane alembic.
     */
    public static Optional<AlembicSnapshot> snapshot(Level level, BlockPos target) {
        Objects.requireNonNull(level, "level");
        Objects.requireNonNull(target, "target");
        if ((level instanceof ServerLevel serverLevel && !serverLevel.getServer().isSameThread()) || !level.hasChunkAt(target) || !(level.getBlockEntity(target) instanceof ArcaneAlembicBlockEntity alembic)) {
            return Optional.empty();
        }
        return Optional.of(new AlembicSnapshot(alembic.aspect(), alembic.aspectFilter(), alembic.amount(), alembic.capacity()));
    }

    /**
     * Inserts into a loaded TC arcane alembic through the same checked storage
     * mutation used by the core alchemical furnace.
     *
     * @return the amount accepted, between zero and {@code amount}
     */
    public static int insertLoaded(Level level, BlockPos target, AspectId aspect, int amount, EssentiaTransferMode mode) {
        if (level == null || target == null || aspect == null || mode == null || amount <= 0 || dev.tc4port.thaumcraft.api.aspect.AspectApi.registry().get(aspect).isEmpty()) {
            RuntimeWarnings.warnOnce("alembic-insert", "Ignoring invalid alembic insertion request");
            return 0;
        }
        if (mode.executes() && (level.isClientSide || level.getServer() == null || !level.getServer().isSameThread())) {
            return 0;
        }
        if ((level instanceof ServerLevel serverLevel && !serverLevel.getServer().isSameThread()) || !level.hasChunkAt(target) || !(level.getBlockEntity(target) instanceof ArcaneAlembicBlockEntity alembic) || !alembic.canAccept(aspect, 0)) {
            return 0;
        }
        int accepted = Math.min(amount, alembic.capacity() - alembic.amount());
        if (accepted <= 0 || !mode.executes()) {
            return Math.max(0, accepted);
        }
        int remainder = alembic.add(aspect, accepted);
        return accepted - remainder;
    }
}
