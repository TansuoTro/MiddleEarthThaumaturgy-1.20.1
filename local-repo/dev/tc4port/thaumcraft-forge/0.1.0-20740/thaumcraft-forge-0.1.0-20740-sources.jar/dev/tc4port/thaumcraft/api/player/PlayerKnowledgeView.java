package dev.tc4port.thaumcraft.api.player;

import dev.tc4port.thaumcraft.api.aspect.AspectId;
import dev.tc4port.thaumcraft.api.research.ResearchKey;
import java.util.List;
import java.util.Objects;

/**
 * Immutable, catalog-filtered projection of shareable player knowledge.
 */
public record PlayerKnowledgeView(List<ResearchKey> completedResearch, List<AspectId> discoveredAspects) {

    public PlayerKnowledgeView {
        completedResearch = List.copyOf(Objects.requireNonNull(completedResearch, "completedResearch"));
        discoveredAspects = List.copyOf(Objects.requireNonNull(discoveredAspects, "discoveredAspects"));
    }
}
