package dev.tc4port.thaumcraft.api.essentia;

import dev.tc4port.thaumcraft.api.aspect.AspectContainerView;
import dev.tc4port.thaumcraft.api.aspect.AspectId;

/**
 * Jar inspection separates its label from the actually stored quantity.
 */
public interface EssentiaJarView extends AspectContainerView {

    int capacity();

    @javax.annotation.Nullable
    AspectId filter();
}
