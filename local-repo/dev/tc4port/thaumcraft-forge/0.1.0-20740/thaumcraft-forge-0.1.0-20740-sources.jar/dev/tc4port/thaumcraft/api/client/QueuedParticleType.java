package dev.tc4port.thaumcraft.api.client;

/**
 * A native particle queue whose vertex submission is owned by an explicit world render pass.
 */
public interface QueuedParticleType extends net.minecraft.client.particle.ParticleRenderType {
}
