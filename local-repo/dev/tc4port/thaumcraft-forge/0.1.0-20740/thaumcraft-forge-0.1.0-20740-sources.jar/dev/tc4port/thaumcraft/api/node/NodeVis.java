package dev.tc4port.thaumcraft.api.node;

import com.mojang.serialization.Codec;
import com.mojang.serialization.DataResult;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import dev.tc4port.thaumcraft.api.aspect.AspectAmounts;
import dev.tc4port.thaumcraft.api.aspect.AspectId;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

/**
 * Ordered whole-Vis node storage. Unlike the general sparse
 * {@link AspectAmounts} value, zero entries are retained because exhausted
 * node aspects participate in TC4's delayed erosion lifecycle.
 */
public record NodeVis(Map<AspectId, Integer> amounts) {

    public static final int MAX_ASPECTS = 256;

    public static final NodeVis EMPTY = new NodeVis(Map.of());

    private static final Codec<Entry> ENTRY_CODEC = RecordCodecBuilder.create(instance -> instance.group(AspectId.CODEC.fieldOf("id").forGetter(Entry::id), Codec.INT.fieldOf("amount").forGetter(Entry::amount)).apply(instance, Entry::new));

    private static final Codec<List<Entry>> ORDERED_CODEC = ENTRY_CODEC.listOf();

    public static final Codec<NodeVis> CODEC = ORDERED_CODEC.comapFlatMap(NodeVis::decodeOrdered, NodeVis::encode);

    public NodeVis {
        Objects.requireNonNull(amounts, "amounts");
        if (amounts.size() > MAX_ASPECTS) {
            throw new IllegalArgumentException("Node Vis has more than " + MAX_ASPECTS + " aspects");
        }
        LinkedHashMap<AspectId, Integer> checked = new LinkedHashMap<>();
        int total = 0;
        for (Map.Entry<AspectId, Integer> entry : amounts.entrySet()) {
            AspectId id = Objects.requireNonNull(entry.getKey(), "aspect id");
            int amount = Objects.requireNonNull(entry.getValue(), "aspect amount");
            if (amount < 0) {
                throw new IllegalArgumentException("Node Vis must be non-negative: " + id);
            }
            Integer previous = checked.putIfAbsent(id, amount);
            if (previous != null) {
                throw new IllegalArgumentException("Duplicate node aspect " + id);
            }
            total = Math.addExact(total, amount);
        }
        amounts = Collections.unmodifiableMap(checked);
    }

    public int amount(AspectId id) {
        return this.amounts.getOrDefault(Objects.requireNonNull(id, "id"), 0);
    }

    public AspectAmounts positiveAmounts() {
        return new AspectAmounts(this.amounts);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof NodeVis nodeVis) || this.amounts.size() != nodeVis.amounts.size()) {
            return false;
        }
        return List.copyOf(this.amounts.entrySet()).equals(List.copyOf(nodeVis.amounts.entrySet()));
    }

    @Override
    public int hashCode() {
        int hash = 1;
        for (Map.Entry<AspectId, Integer> entry : this.amounts.entrySet()) {
            hash = 31 * hash + entry.hashCode();
        }
        return hash;
    }

    private static DataResult<NodeVis> decodeOrdered(List<Entry> values) {
        try {
            if (values.size() > MAX_ASPECTS) {
                return DataResult.error(() -> "Node Vis has more than " + MAX_ASPECTS + " aspects");
            }
            LinkedHashMap<AspectId, Integer> ordered = new LinkedHashMap<>();
            for (Entry entry : values) {
                if (ordered.putIfAbsent(entry.id(), entry.amount()) != null) {
                    return DataResult.error(() -> "Duplicate node aspect " + entry.id());
                }
            }
            return DataResult.success(new NodeVis(ordered));
        } catch (RuntimeException exception) {
            return DataResult.error(() -> "Invalid node Vis: " + exception.getMessage());
        }
    }

    private static List<Entry> encode(NodeVis values) {
        ArrayList<Entry> ordered = new ArrayList<>(values.amounts.size());
        values.amounts.forEach((id, amount) -> ordered.add(new Entry(id, amount)));
        return List.copyOf(ordered);
    }

    private record Entry(AspectId id, int amount) {
    }
}
