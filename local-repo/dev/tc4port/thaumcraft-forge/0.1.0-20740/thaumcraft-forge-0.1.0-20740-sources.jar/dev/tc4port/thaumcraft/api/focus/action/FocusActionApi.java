package dev.tc4port.thaumcraft.api.focus.action;

import dev.tc4port.thaumcraft.api.Registration;
import dev.tc4port.thaumcraft.common.FocusActionRegistry;
import java.util.Objects;

public final class FocusActionApi {

    private FocusActionApi() {
    }

    public static Registration register(FocusActionSpec definition, FocusActionHandler handler) {
        return Registration.of(FocusActionRegistry.register(Objects.requireNonNull(definition, "definition"), Objects.requireNonNull(handler, "handler")));
    }

    /**
     * Registers an action with a once-per-dispatch authorization phase that
     * runs after successful simulation and before the shared Vis debit.
     */
    public static Registration register(FocusActionSpec definition, FocusActionHandler handler, FocusActionAuthorizer authorizer) {
        return Registration.of(FocusActionRegistry.register(Objects.requireNonNull(definition, "definition"), Objects.requireNonNull(handler, "handler"), Objects.requireNonNull(authorizer, "authorizer")));
    }

    public static FocusActionRegistryView registry() {
        return FocusActionRegistry.view();
    }
}
