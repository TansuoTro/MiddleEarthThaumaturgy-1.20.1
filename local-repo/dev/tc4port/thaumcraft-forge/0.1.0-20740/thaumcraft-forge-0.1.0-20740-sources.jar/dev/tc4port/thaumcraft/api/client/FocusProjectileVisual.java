package dev.tc4port.thaumcraft.api.client;

/**
 * Native projectile appearances, independent of TC projectile gameplay.
 */
public enum FocusProjectileVisual {

    EMBER, FIREBALL, FROST, SHOCK_ORB, PRIMAL
}
