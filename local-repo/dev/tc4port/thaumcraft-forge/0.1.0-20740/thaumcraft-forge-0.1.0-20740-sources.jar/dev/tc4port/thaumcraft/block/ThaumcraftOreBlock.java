package dev.tc4port.thaumcraft.block;

import dev.tc4port.thaumcraft.nativeimpl.ExperienceBlock;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import org.jetbrains.annotations.Nullable;

/**
 * Exact modern counterpart of TC4's metadata-driven {@code BlockCustomOre}.
 *
 * <p>Infused shards and amber retain the old non-vanilla fortune formulae.
 * Native block loot tables own all item drops; this class retains the
 * ore-specific experience rules.</p>
 */
public final class ThaumcraftOreBlock extends ExperienceBlock implements dev.tc4port.thaumcraft.api.event.HarvestExperiencePolicy, dev.tc4port.thaumcraft.nativeimpl.ClientExtensionTarget {

    public enum DropKind {

        CINNABAR, INFUSED_SHARD, AMBER
    }

    private final DropKind dropKind;

    public ThaumcraftOreBlock(DropKind dropKind, BlockBehaviour.Properties properties) {
        super(properties);
        this.dropKind = dropKind;
    }

    public int getExpDrop(BlockState state, LevelAccessor level, BlockPos pos, @Nullable BlockEntity blockEntity, @Nullable Entity breaker, ItemStack tool) {
        if (this.dropKind == DropKind.CINNABAR) {
            return 0;
        }
        return experience(level.getRandom(), ExperienceBlock.silkTouch(level, tool));
    }

    @Override
    protected int experience(net.minecraft.util.RandomSource random, int silkTouch) {
        if (this.dropKind == dev.tc4port.thaumcraft.block.ThaumcraftOreBlock.DropKind.CINNABAR || silkTouch > 0)
            return 0;
        return this.dropKind == dev.tc4port.thaumcraft.block.ThaumcraftOreBlock.DropKind.AMBER ? 1 + random.nextInt(4) : random.nextInt(4);
    }

    @Override
    public int equippedFortuneExperience(int harvestedExperience, int equippedFortune) {
        return harvestedExperience <= 0 ? harvestedExperience : harvestedExperience + equippedFortune;
    }
}
