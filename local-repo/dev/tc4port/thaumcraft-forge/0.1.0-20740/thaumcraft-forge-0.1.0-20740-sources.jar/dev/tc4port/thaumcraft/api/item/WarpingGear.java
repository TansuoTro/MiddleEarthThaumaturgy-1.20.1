package dev.tc4port.thaumcraft.api.item;

import java.util.Optional;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;

/**
 * Dynamic owner-item hook for warp contributed from the main hand or while
 * equipped.
 *
 * <p>Static values should use the synchronized equipped-warp Data Map. The
 * callback is read-only, may run on either physical side and must return a
 * non-negative amount; negative results are treated as zero. The wearer is
 * empty in display contexts without a player.</p>
 */
@FunctionalInterface
public interface WarpingGear {

    int thaumcraftWarp(ItemStack stack, Optional<Player> wearer);
}
