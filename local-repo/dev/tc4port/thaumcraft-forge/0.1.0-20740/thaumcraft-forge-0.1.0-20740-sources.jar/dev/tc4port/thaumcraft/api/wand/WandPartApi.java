package dev.tc4port.thaumcraft.api.wand;

import dev.tc4port.thaumcraft.api.Registration;
import dev.tc4port.thaumcraft.common.WandPartIndex;
import java.util.List;
import java.util.Optional;
import net.minecraft.world.item.ItemStack;

/**
 * Programmatic wand-part definitions. Synced data maps remain preferred.
 */
public final class WandPartApi {

    /**
     * Largest per-part assembly coefficient. Two maximum-cost parts still
     * produce a sceptre cost that fits the whole-Vis and centivis contracts.
     */
    public static final int MAX_CRAFT_COST = WandPartLimits.MAX_CRAFT_COST;

    private WandPartApi() {
    }

    public static Registration registerRod(WandRodSpec spec) {
        return Registration.of(WandPartIndex.registerRod(spec));
    }

    public static Registration registerCap(WandCapSpec spec) {
        return Registration.of(WandPartIndex.registerCap(spec));
    }

    public static Optional<WandRodSpec> rod(ItemStack stack) {
        return Optional.ofNullable(WandPartIndex.rod(stack));
    }

    public static Optional<WandCapSpec> cap(ItemStack stack) {
        return Optional.ofNullable(WandPartIndex.cap(stack));
    }

    public static Optional<WandRodSpec> rod(WandMaterialId materialId) {
        return Optional.ofNullable(WandPartIndex.rod(materialId));
    }

    public static Optional<WandCapSpec> cap(WandMaterialId materialId) {
        return Optional.ofNullable(WandPartIndex.cap(materialId));
    }

    public static List<WandRodSpec> rods() {
        return WandPartIndex.rods();
    }

    public static List<WandCapSpec> caps() {
        return WandPartIndex.caps();
    }

    public static int maximumCentivis(WandMaterialId rod, boolean sceptre) {
        return WandPartIndex.maxVis(rod, sceptre);
    }
}
