package dev.tc4port.thaumcraft.api.client;

import com.mojang.blaze3d.vertex.PoseStack;
import dev.tc4port.thaumcraft.api.node.AuraNodeState;
import dev.tc4port.thaumcraft.client.*;
import java.util.Objects;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.world.phys.Vec3;

/**
 * Direct model/ribbon drawing in the caller's render context.
 *
 * <p>The caller owns the final pose (including any camera-facing rotation),
 * buffer lifetime, ordering and draw stage. These methods neither capture
 * positions nor enqueue work in TC's world queues, and never flush the supplied
 * buffers (the explicitly immediate mirror field is the exception). Local geometry and animation are applied under the supplied pose;
 * it is restored on return. Billboard sheets lie in local XY, facing +Z.
 * TC's own renderers retain their independent capture and deferred rendering.
 *
 * <p>Particle/effect spawning remains in {@link ThaumcraftClientEffectsApi}.
 */
public final class ThaumcraftClientVisualsApi {

    private ThaumcraftClientVisualsApi() {
    }

    /**
     * Origin is the projectile centre. Seed controls stable mesh/ray variation, not orientation.
     */
    public static void renderFocusProjectile(PoseStack pose, MultiBufferSource buffers, FocusProjectileVisual kind, int age, int seed, int lifetime, float damage, float partialTick, int packedLight) {
        context(pose, buffers);
        Objects.requireNonNull(kind);
        unit(partialTick);
        if (age < 0 || lifetime < 1 || lifetime > 12000 || !Float.isFinite(damage) || damage < 0 || damage > 640) {
            throw new IllegalArgumentException("Invalid projectile visual parameters");
        }
        FocusProjectileRenderer.renderVisual(kind, age, seed, lifetime, damage, partialTick, pose, buffers, packedLight);
    }

    public static void renderItemHalo(PoseStack pose, MultiBufferSource buffers, int age, float growth) {
        context(pose, buffers);
        unit(growth);
        SpecialItemRenderer.renderRays(age, growth, net.minecraft.client.Minecraft.getInstance().options.graphicsMode().get() == net.minecraft.client.GraphicsStatus.FAST ? 5 : 10, pose, buffers);
    }

    /**
     * Local origin is the matrix's block corner, preserving its half-block offset.
     */
    public static void renderInfusionHalo(PoseStack pose, MultiBufferSource buffers, int craftCount) {
        context(pose, buffers);
        if (craftCount < 0) {
            throw new IllegalArgumentException("Negative craft count");
        }
        InfusionMatrixRenderer.renderHalo(pose, buffers, craftCount);
    }

    /**
     * Origin is the bubble centre. No camera-facing rotation is added.
     */
    public static void renderNodeBubble(PoseStack pose, MultiBufferSource buffers, int count, int lockStrength, double animation) {
        context(pose, buffers);
        if (count < 0 || count > 37 || lockStrength < 0 || lockStrength > 2 || !Double.isFinite(animation)) {
            throw new IllegalArgumentException("Invalid node bubble");
        }
        NodeMachineRenderHelper.renderBubble(pose, buffers, count, lockStrength, animation);
    }

    /**
     * Origin is the aura centre.
     */
    public static void renderBloomAura(PoseStack pose, MultiBufferSource buffers, float scale, int frame) {
        context(pose, buffers);
        scale(scale);
        EtherealBloomRenderer.renderAura(pose, buffers, scale, frame);
    }

    /**
     * Origin is the portal centre, not a block corner.
     */
    public static void renderEldritchPortal(PoseStack pose, MultiBufferSource buffers, int openingTicks, float partialTick) {
        context(pose, buffers);
        unit(partialTick);
        if (openingTicks < 0) {
            throw new IllegalArgumentException("Negative opening age");
        }
        EldritchPortalRenderer.renderSurface(openingTicks, partialTick, pose, buffers);
    }

    /**
     * Origin is the portal centre, not entity feet.
     */
    public static void renderCultistPortal(PoseStack pose, MultiBufferSource buffers, int age, int hurtTicks, int pulseTicks, float healthFraction, float partialTick) {
        context(pose, buffers);
        unit(healthFraction);
        unit(partialTick);
        if (age < 0 || hurtTicks < 0 || pulseTicks < 0) {
            throw new IllegalArgumentException("Negative portal clocks");
        }
        CultistPortalRenderer.renderSurface(age, hurtTicks, pulseTicks, healthFraction, partialTick, pose, buffers);
    }

    /**
     * Endpoint is local to the supplied eye-emitter pose.
     */
    public static void renderWatcherBeam(PoseStack pose, MultiBufferSource buffers, Vec3 direction, float charge, float animation, int age) {
        context(pose, buffers);
        vector(direction);
        unit(charge);
        distance(Vec3.ZERO, direction);
        if (!Float.isFinite(animation) || age < 0) {
            throw new IllegalArgumentException("Invalid watcher animation");
        }
        WatcherRenderer.renderBeam(pose, buffers, direction, charge, animation, age);
    }

    /**
     * Beam body only; draw an independently oriented endpoint with renderBoreImpact.
     */
    public static void renderBoreBeam(PoseStack pose, MultiBufferSource buffers, Vec3 start, Vec3 end, int rgb, boolean reverse, double animation) {
        context(pose, buffers);
        vector(start);
        vector(end);
        distance(start, end);
        clock(animation);
        ArcaneBoreRenderer.renderAddonBeam(pose, buffers, start, end, rgb & 0xFFFFFF, reverse, animation);
    }

    /**
     * Origin is the impact centre; the supplied pose determines the sheet's orientation.
     */
    public static void renderBoreImpact(PoseStack pose, MultiBufferSource buffers, int rgb, double animation) {
        context(pose, buffers);
        clock(animation);
        ArcaneBoreRenderer.emitImpact(pose, buffers, rgb & 0xFFFFFF, animation);
    }

    /**
     * General coordinate beam. Endpoints and wave/rotation clocks are caller-local; clocks are ticks.
     */
    public static void renderBeam(PoseStack pose, MultiBufferSource buffers, Vec3 start, Vec3 end, BeamSettings settings, int age, float partialTick, double animation) {
        context(pose, buffers);
        vector(start);
        vector(end);
        distance(start, end);
        Objects.requireNonNull(settings);
        unit(partialTick);
        clock(animation);
        if (age < 0) {
            throw new IllegalArgumentException("Negative beam age");
        }
        CoordinateBeamEffect.renderLocal(pose.last(), buffers, start, end, settings, age, partialTick, animation, animation);
    }

    /**
     * Beam body only; its endpoint flare has a separate, caller-oriented draw call.
     */
    public static void renderPowerBeam(PoseStack pose, MultiBufferSource buffers, Vec3 start, Vec3 end, EffectColor color, float opacity, float scroll) {
        context(pose, buffers);
        vector(start);
        vector(end);
        unit(opacity);
        Objects.requireNonNull(color);
        distance(start, end);
        if (!Float.isFinite(scroll)) {
            throw new IllegalArgumentException("Invalid beam scroll");
        }
        VisRelayRenderer.renderPowerBeam(pose, buffers, start, end, color, opacity, scroll);
    }

    public static void renderPowerFlare(PoseStack pose, MultiBufferSource buffers, EffectColor color, float opacity, int frame) {
        context(pose, buffers);
        Objects.requireNonNull(color);
        unit(opacity);
        VisRelayRenderer.renderPowerFlare(pose, buffers, color, opacity, frame);
    }

    /**
     * Endpoints and procedural phase remain local; the pose transforms the completed ribbon.
     */
    public static void renderRitualRibbon(PoseStack pose, MultiBufferSource buffers, Vec3 source, Vec3 target, double age, double animation) {
        context(pose, buffers);
        vector(source);
        vector(target);
        distance(source, target);
        clock(animation);
        if (!Double.isFinite(age) || age < 0) {
            throw new IllegalArgumentException("Invalid ribbon age");
        }
        CultistRitualLinkEffect.renderLocal(pose.last(), source, target, age, animation, buffers);
    }

    public static void renderBoreVortex(PoseStack pose, MultiBufferSource buffers, float y, float scale, float spin, float tilt, float alpha) {
        context(pose, buffers);
        scale(scale);
        unit(alpha);
        if (!Float.isFinite(y) || !Float.isFinite(spin) || !Float.isFinite(tilt)) {
            throw new IllegalArgumentException("Invalid vortex pose");
        }
        ArcaneBoreRenderer.renderVortex(pose, buffers, y, scale, spin, tilt, alpha);
    }

    /**
     * Projection-dependent mirror field; unlike buffered geometry this makes its two
     * immediate draw calls. Uses the supplied block-corner pose and face, never a
     * billboard rotation or TC capture queue. Call only in a live world render context.
     */
    public static void renderMirrorField(net.minecraft.core.BlockPos pos, net.minecraft.core.Direction face, float partialTick, PoseStack pose) {
        unit(partialTick);
        LinkedMirrorFieldRenderer.render(Objects.requireNonNull(pos), Objects.requireNonNull(face), partialTick, Objects.requireNonNull(pose));
    }

    /**
     * Origin is the marker face centre.
     */
    public static void renderMarker(PoseStack pose, MultiBufferSource buffers, MarkerVisual kind, int rgb) {
        context(pose, buffers);
        Objects.requireNonNull(kind);
        GolemMarkerRenderer.renderMarker(pose, buffers, kind.ordinal(), rgb & 0xFFFFFF);
    }

    /**
     * Block-corner frame and local source; -1 pulses, 0..15 selects TC's marker palette.
     */
    public static void renderMarkerLink(PoseStack pose, MultiBufferSource buffers, Vec3 source, net.minecraft.core.Direction face, int color, double animation) {
        context(pose, buffers);
        vector(source);
        Objects.requireNonNull(face);
        distance(source, Vec3.ZERO);
        clock(animation);
        if (color < -1 || color > 15) {
            throw new IllegalArgumentException("Invalid marker link color");
        }
        GolemMarkerRenderer.renderPosedLink(pose.last(), buffers, Vec3.ZERO, source, net.minecraft.core.BlockPos.ZERO, face, (byte) color, animation);
    }

    /**
     * One node in local XY at the pose origin, using current vis and normal depth-tested
     * node materials. No camera, block-centre offset, distance fade or equipment gating.
     * Caller supplies opacity and animation in ticks; modifier pulse/type animation remain TC-owned.
     * World-node layer transforms do not apply to this caller-local drawing operation.
     */
    public static void renderNode(AuraNodeState state, PoseStack pose, MultiBufferSource buffers, double animation, float opacity) {
        context(pose, buffers);
        Objects.requireNonNull(state);
        clock(animation);
        unit(opacity);
        AuraNodeRenderer.renderOrientedNode(state, pose, buffers, animation, opacity);
    }

    /**
     * Three perpendicular item-node planes, with caller-owned pose and animation in ticks.
     */
    public static void renderInventoryNode(AuraNodeState state, PoseStack pose, MultiBufferSource buffers, long animation) {
        context(pose, buffers);
        Objects.requireNonNull(state);
        // The item texture advances every 40 ms (25 Hz); the modifier/aspect pulse uses ticks.
        // 128 ticks span five complete 32-frame cycles; reduce first to avoid overflow.
        long frameTime = Math.floorMod(animation, 128L) * 5L / 4L;
        AuraNodeRenderer.renderInventoryNode(state, pose, buffers, frameTime, animation);
    }

    private static void context(PoseStack pose, MultiBufferSource buffers) {
        Objects.requireNonNull(pose);
        Objects.requireNonNull(buffers);
    }

    private static void clock(double value) {
        if (!Double.isFinite(value)) {
            throw new IllegalArgumentException("Expected finite clock");
        }
    }

    private static void distance(Vec3 start, Vec3 end) {
        if (start.distanceToSqr(end) > 256 * 256) {
            throw new IllegalArgumentException("Visual path exceeds 256 blocks");
        }
    }

    private static void unit(float value) {
        if (!Float.isFinite(value) || value < 0 || value > 1) {
            throw new IllegalArgumentException("Expected [0, 1]");
        }
    }

    private static void scale(float value) {
        if (!Float.isFinite(value) || value <= 0 || value > 64) {
            throw new IllegalArgumentException("Invalid visual size");
        }
    }

    private static void vector(Vec3 vector) {
        Objects.requireNonNull(vector);
        if (!Double.isFinite(vector.x) || !Double.isFinite(vector.y) || !Double.isFinite(vector.z)) {
            throw new IllegalArgumentException("Expected finite local vector");
        }
    }
}
