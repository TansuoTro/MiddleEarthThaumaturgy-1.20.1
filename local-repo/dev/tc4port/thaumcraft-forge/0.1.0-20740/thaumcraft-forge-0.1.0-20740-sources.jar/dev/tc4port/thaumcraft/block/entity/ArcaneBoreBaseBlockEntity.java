package dev.tc4port.thaumcraft.block.entity;

import dev.tc4port.thaumcraft.block.ArcaneBoreBaseBlock;
import dev.tc4port.thaumcraft.api.aspect.AspectId;
import dev.tc4port.thaumcraft.api.essentia.EssentiaApi;
import dev.tc4port.thaumcraft.api.essentia.EssentiaTransferMode;
import dev.tc4port.thaumcraft.api.essentia.EssentiaTransport;
import dev.tc4port.thaumcraft.registry.TCBlockEntities;
import javax.annotation.Nullable;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import dev.tc4port.thaumcraft.nativeimpl.state.ItemFields;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.entity.BlockEntityType;

/**
 * The bore base is an instantaneous Perditio consumer. It stores no essentia:
 * one unit is pulled only when the attached bore needs a new speed charge.
 */
public final class ArcaneBoreBaseBlockEntity extends net.minecraft.world.level.block.entity.BlockEntity implements EssentiaTransport, ItemFields.Source {

    public ArcaneBoreBaseBlockEntity(BlockPos pos, BlockState state) {
        super(TCBlockEntities.ARCANE_BORE_BASE.get(), pos, state);
    }

    public Direction outputDirection() {
        return this.getBlockState().getValue(ArcaneBoreBaseBlock.FACING);
    }

    /**
     * Exact TileArcaneBoreBase loop, including its unusual early failure when
     * the first connectable neighbour cannot output toward the base.
     */
    public boolean drawEssentia() {
        if (this.level == null) {
            return false;
        }
        for (Direction facing : Direction.values()) {
            BlockPos neighborPos = this.worldPosition.relative(facing);
            if (!this.level.isLoaded(neighborPos))
                continue;
            EssentiaTransport transport = EssentiaApi.transport(this.level, neighborPos, facing.getOpposite());
            if (transport == null || !transport.isConnectable(facing.getOpposite())) {
                continue;
            }
            Direction neighborFace = facing.getOpposite();
            if (!transport.canOutputTo(neighborFace)) {
                return false;
            }
            if (transport.suctionAmount(neighborFace) < this.suctionAmount(facing) && EssentiaApi.take(this.level, transport, AspectId.parse("perditio"), 1, neighborFace, EssentiaTransferMode.EXECUTE) == 1) {
                return true;
            }
        }
        return false;
    }

    @Override
    public boolean isConnectable(Direction face) {
        return true;
    }

    @Override
    public boolean canInputFrom(Direction face) {
        return true;
    }

    @Override
    public boolean canOutputTo(Direction face) {
        return false;
    }

    @Nullable
    @Override
    public AspectId suctionType(Direction face) {
        return AspectId.parse("perditio");
    }

    @Override
    public int suctionAmount(Direction face) {
        return face == this.outputDirection() ? 0 : 128;
    }

    @Override
    public int takeEssentia(AspectId aspect, int amount, Direction face, EssentiaTransferMode mode) {
        return 0;
    }

    @Override
    public int addEssentia(AspectId aspect, int amount, Direction face, EssentiaTransferMode mode) {
        return 0;
    }

    @Nullable
    @Override
    public AspectId essentiaType(Direction face) {
        return null;
    }

    @Override
    public int essentiaAmount(Direction face) {
        return 0;
    }

    @Override
    public int minimumSuction() {
        return 0;
    }

    @Override
    public boolean renderExtendedTube() {
        return true;
    }

    protected final HolderLookup.Provider persistenceRegistries() {
        if (level != null)
            return level.registryAccess();
        var server = net.minecraftforge.server.ServerLifecycleHooks.getCurrentServer();
        return server != null ? server.registryAccess() : net.minecraft.core.RegistryAccess.fromRegistryOfRegistries(net.minecraft.core.registries.BuiltInRegistries.REGISTRY);
    }

    protected static net.minecraft.network.chat.Component parseCustomNameSafe(String value, HolderLookup.Provider registries) {
        try {
            return net.minecraft.network.chat.Component.Serializer.fromJson(value);
        } catch (RuntimeException exception) {
            return null;
        }
    }

    protected void readItemFields(ItemFields.Input input) {
    }

    public void copyItemFields(ItemFields.Output output) {
    }

    public void applyComponentsFromItemStack(ItemStack stack) {
        readItemFields(ItemFields.from(stack));
    }

    public void removeComponentsFromTag(CompoundTag tag) {
    }

    @Override
    public void saveToItem(ItemStack stack) {
        CompoundTag tag = saveWithoutMetadata();
        {
            net.minecraft.nbt.CompoundTag native$bodyOperand$6096 = tag;
            native$bodyReturn$6098: {
                if (true) {
                }
            }
        }
        net.minecraft.world.item.BlockItem.setBlockEntityData(stack, getType(), tag);
        copyItemFields(ItemFields.to(stack));
    }

    @Override
    public net.minecraft.world.phys.AABB getRenderBoundingBox() {
        return ArcaneBoreBaseBlockEntity.native$ClientBlockEntityBounds$bounds(this);
    }

    @Override()
    public void onDataPacket(net.minecraft.network.Connection connection, net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket packet) {
        handleUpdateTag(packet.getTag());
    }

    @SuppressWarnings({ "rawtypes", "unchecked" })
    static private net.minecraft.world.phys.AABB native$ClientBlockEntityBounds$bounds(net.minecraft.world.level.block.entity.BlockEntity blockEntity) {
        var renderer = net.minecraft.client.Minecraft.getInstance().getBlockEntityRenderDispatcher().getRenderer(blockEntity);
        return renderer instanceof dev.tc4port.thaumcraft.nativeimpl.NativeBlockEntityRenderer shared ? shared.getRenderBoundingBox(blockEntity) : new net.minecraft.world.phys.AABB(blockEntity.getBlockPos());
    }

    private boolean native$capabilitiesInvalid$16879;

    public boolean native$capabilityActive$16765;

    public net.minecraftforge.common.capabilities.Capability<dev.tc4port.thaumcraft.api.essentia.EssentiaTransport> native$capabilityCapture$16764;

    private net.minecraftforge.common.util.LazyOptional<dev.tc4port.thaumcraft.api.essentia.EssentiaTransport> native$capabilityHandle$16766;

    @Override
    public <native$capabilityResultType$16880> net.minecraftforge.common.util.LazyOptional<native$capabilityResultType$16880> getCapability(net.minecraftforge.common.capabilities.Capability<native$capabilityResultType$16880> native$requestedCapability$16881, net.minecraft.core.Direction native$requestedFace$16882) {
        getCapabilities();
        synchronized (this) {
            if (native$capabilitiesInvalid$16879)
                return net.minecraftforge.common.util.LazyOptional.empty();
            if (native$capabilityActive$16765 && native$requestedCapability$16881 == (this.native$capabilityCapture$16764)) {
                if (native$capabilityHandle$16766 == null)
                    native$capabilityHandle$16766 = net.minecraftforge.common.util.LazyOptional.of(() -> this);
                return native$capabilityHandle$16766.cast();
            }
        }
        return super.getCapability(native$requestedCapability$16881, native$requestedFace$16882);
    }

    @Override
    public void invalidateCaps() {
        java.util.List<net.minecraftforge.common.util.LazyOptional<?>> native$expiredCapabilities$16883 = new java.util.ArrayList<>();
        synchronized (this) {
            native$capabilitiesInvalid$16879 = true;
            if (native$capabilityHandle$16766 != null) {
                native$expiredCapabilities$16883.add(native$capabilityHandle$16766);
                native$capabilityHandle$16766 = null;
            }
        }
        try {
            super.invalidateCaps();
        } finally {
            native$expiredCapabilities$16883.forEach(net.minecraftforge.common.util.LazyOptional::invalidate);
        }
    }

    @Override
    public void reviveCaps() {
        super.reviveCaps();
        synchronized (this) {
            native$capabilitiesInvalid$16879 = false;
        }
    }
}
