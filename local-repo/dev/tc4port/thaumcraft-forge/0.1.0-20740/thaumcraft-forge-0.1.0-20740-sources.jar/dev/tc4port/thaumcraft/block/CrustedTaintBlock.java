package dev.tc4port.thaumcraft.block;

import com.mojang.serialization.MapCodec;
import dev.tc4port.thaumcraft.common.TCServerConfig;
import dev.tc4port.thaumcraft.common.TaintDecayCatalog;
import dev.tc4port.thaumcraft.entity.FallingTaintEntity;
import dev.tc4port.thaumcraft.entity.TaintSporeSwarmerEntity;
import dev.tc4port.thaumcraft.registry.TCBlocks;
import dev.tc4port.thaumcraft.registry.TCEntities;
import dev.tc4port.thaumcraft.registry.TCSounds;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.tags.BlockTags;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import dev.tc4port.thaumcraft.nativeimpl.ClientExtensionTarget;
import dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.level.pathfinder.PathComputationType;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.level.Explosion;
import net.minecraft.world.level.BlockGetter;

/**
 * Metadata-0 crusted taint, including its delayed vertical/sideways slumping
 * and rare swarmer conversion.
 */
public final class CrustedTaintBlock extends net.minecraft.world.level.block.Block implements dev.tc4port.thaumcraft.nativeimpl.ClientExtensionTarget {

    // Forge calls initializeClient from the native superclass constructor. Do not add a field initializer.
    private java.util.function.Consumer<net.minecraftforge.client.extensions.common.IClientBlockExtensions> platform$clientInstaller;

    public static final MapCodec<CrustedTaintBlock> CODEC = CrustedTaintBlock.native$BlockCodecPlatform$simple(CrustedTaintBlock::new);

    public CrustedTaintBlock(BlockBehaviour.Properties properties) {
        this(properties, properties, true);
    }

    protected MapCodec<CrustedTaintBlock> codec() {
        return CODEC;
    }

    @Override
    public void animateTick(BlockState state, Level level, BlockPos pos, RandomSource random) {
        /*
         * BlockTaint metadata zero used the callback RNG only for the
         * one-in-ten gate, then sampled both horizontal coordinates from
         * World.rand. Keep that split: moving all three draws onto the
         * callback RNG changes the neighbouring display-effect sequence.
         */
        if (level.isEmptyBlock(pos.below()) && random.nextInt(10) == 0) {
            dev.tc4port.thaumcraft.client.TaintDropletParticle.spawn(level, pos.getX() + 0.1F + level.random.nextFloat() * 0.8F, pos.getY(), pos.getZ() + 0.1F + level.random.nextFloat() * 0.8F, 0.3F, 0.1F, 0.8F);
        }
    }

    @Override
    public void randomTick(BlockState state, ServerLevel level, BlockPos pos, RandomSource random) {
        TaintSpreadLogic.spreadBiome(level, pos, random);
        if (this.tryToFall(level, state, pos, pos)) {
            return;
        }
        if (level.getBlockState(pos.above()).isAir()) {
            Direction direction = legacyHorizontalDirection(random.nextInt(4));
            boolean canSlide = true;
            for (int depth = 0; depth < 4; depth++) {
                if (!level.getBlockState(pos.relative(direction).below(depth)).isAir() || !level.getBlockState(pos.below(depth)).is(this)) {
                    canSlide = false;
                    break;
                }
            }
            if (canSlide && this.tryToFall(level, state, pos, pos.relative(direction))) {
                return;
            }
        }
        TaintSpreadLogic.SpreadResult spread = TaintSpreadLogic.tickSolidSpreadTarget(level, pos, random);
        if (!spread.targetTainted()) {
            TaintDecayCatalog.apply(state.getBlock(), TaintDecayCatalog.Trigger.TARGET_NOT_TAINTED, level, pos, random);
            return;
        }
        if (level.getBlockState(pos.above()).isAir() && TCServerConfig.spawnTaintSpore() && random.nextInt(200) == 0 && level.getEntitiesOfClass(TaintSporeSwarmerEntity.class, new AABB(pos).inflate(16.0)).isEmpty()) {
            this.spawnSwarmer(level, pos, random);
            return;
        }
        if (this.isCompletelyEnclosed(level, pos)) {
            TaintDecayCatalog.apply(state.getBlock(), TaintDecayCatalog.Trigger.ENCLOSED, level, pos, random);
        }
    }

    /**
     * ForgeDirection ordinals 2..5 were north, south, west, east.
     */
    public static Direction legacyHorizontalDirection(int index) {
        return switch(index) {
            case 0 ->
                Direction.NORTH;
            case 1 ->
                Direction.SOUTH;
            case 2 ->
                Direction.WEST;
            case 3 ->
                Direction.EAST;
            default ->
                throw new IllegalArgumentException("Legacy horizontal index must be 0..3: " + index);
        };
    }

    private void spawnSwarmer(ServerLevel level, BlockPos pos, RandomSource random) {
        TaintSporeSwarmerEntity swarmer = TCEntities.TAINT_SPORE_SWARMER.get().create(level);
        if (swarmer == null) {
            return;
        }
        level.removeBlock(pos, false);
        swarmer.moveTo(pos.getX() + 0.5, pos.getY(), pos.getZ() + 0.5, 0.0F, 0.0F);
        level.addFreshEntity(swarmer);
        swarmer.playSound(TCSounds.ROOTS.get(), 0.1F, 0.9F + random.nextFloat() * 0.2F);
    }

    private boolean tryToFall(ServerLevel level, BlockState state, BlockPos source, BlockPos destination) {
        if (destination.getY() < level.getMinBuildHeight() || !canFallBelow(level, destination.below())) {
            return false;
        }
        level.addFreshEntity(new FallingTaintEntity(level, destination, state, source));
        return true;
    }

    public static boolean canFallBelow(Level level, BlockPos pos) {
        for (BlockPos nearby : BlockPos.betweenClosed(pos.offset(-1, -1, -1), pos.offset(1, 1, 1))) {
            if (level.getBlockState(nearby).is(BlockTags.LOGS)) {
                return false;
            }
        }
        BlockState below = level.getBlockState(pos);
        if (below.is(TCBlocks.byId("flux_goo").get())) {
            /*
             * Flux Goo levels are still represented by one modern block.
             * Treating it as the old stable (quanta >= 4) case prevents a
             * crust column from tunnelling through an existing goo pool.
             */
            return below.getValue(FiniteFluidBlock.LEVEL) < 4;
        }
        return below.isAir() || below.is(BlockTags.FIRE) || isTaintFibre(below) || below.canBeReplaced() || !below.getFluidState().isEmpty();
    }

    public static boolean isTaintFibre(BlockState state) {
        return state.is(TCBlocks.FIBROUS_TAINT.get()) || state.is(TCBlocks.TAINTED_GRASS.get()) || state.is(TCBlocks.TAINTED_PLANT.get()) || state.is(TCBlocks.SPORE_STALK.get()) || state.is(TCBlocks.MATURE_SPORE_STALK.get());
    }

    private boolean isCompletelyEnclosed(ServerLevel level, BlockPos pos) {
        if (!level.getBlockState(pos.above()).is(this)) {
            return false;
        }
        for (Direction direction : Direction.Plane.HORIZONTAL) {
            if (!level.getBlockState(pos.relative(direction)).is(this)) {
                return false;
            }
        }
        return true;
    }

    @Override
    public void stepOn(Level level, BlockPos pos, BlockState state, Entity entity) {
        TaintSpreadLogic.applySolidContact(level, entity);
        super.stepOn(level, pos, state, entity);
    }

    private CrustedTaintBlock(net.minecraft.world.level.block.state.BlockBehaviour.Properties native$NativeBlock$arg0, BlockBehaviour.Properties properties, boolean native$NativeBlock$captured) {
        super(native$NativeBlock$arg0);
    }

    @Override
    public void initializeClient(java.util.function.Consumer<net.minecraftforge.client.extensions.common.IClientBlockExtensions> installer) {
        platform$clientInstaller = installer;
        super.initializeClient(installer);
    }

    @Override
    public void platform$clientExtension(Object extension) {
        java.util.Objects.requireNonNull(platform$clientInstaller, "Forge initializeClient must run before client extension registration").accept((net.minecraftforge.client.extensions.common.IClientBlockExtensions) extension);
    }

    @Override
    public InteractionResult use(BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
        ItemUseResult result = (switch(0) {
            default ->
                {
                    net.minecraft.world.item.ItemStack native$bodyOperand$4288 = player.getItemInHand(hand);
                    net.minecraft.world.level.block.state.BlockState native$bodyOperand$4289 = state;
                    net.minecraft.world.level.Level native$bodyOperand$4290 = level;
                    net.minecraft.core.BlockPos native$bodyOperand$4291 = pos;
                    net.minecraft.world.entity.player.Player native$bodyOperand$4292 = player;
                    net.minecraft.world.InteractionHand native$bodyOperand$4293 = hand;
                    net.minecraft.world.phys.BlockHitResult native$bodyOperand$4294 = hit;
                    dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult native$bodyResult$4295 = null;
                    native$bodyReturn$4296: {
                        if (true) {
                            {
                                native$bodyResult$4295 = dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
                                break native$bodyReturn$4296;
                            }
                        }
                    }
                    yield native$bodyResult$4295;
                }
        });
        return result == ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION ? (hand == InteractionHand.MAIN_HAND ? (switch(0) {
            default ->
                {
                    net.minecraft.world.level.block.state.BlockState native$bodyOperand$3579 = state;
                    net.minecraft.world.level.Level native$bodyOperand$3580 = level;
                    net.minecraft.core.BlockPos native$bodyOperand$3581 = pos;
                    net.minecraft.world.entity.player.Player native$bodyOperand$3582 = player;
                    net.minecraft.world.phys.BlockHitResult native$bodyOperand$3583 = hit;
                    net.minecraft.world.InteractionResult native$bodyResult$3584 = null;
                    native$bodyReturn$3585: {
                        if (true) {
                            {
                                native$bodyResult$3584 = super.use(native$bodyOperand$3579, native$bodyOperand$3580, native$bodyOperand$3581, native$bodyOperand$3582, net.minecraft.world.InteractionHand.MAIN_HAND, native$bodyOperand$3583);
                                break native$bodyReturn$3585;
                            }
                        }
                    }
                    yield native$bodyResult$3584;
                }
        }) : InteractionResult.PASS) : result.result();
    }

    protected ItemUseResult interactWithItem(ItemStack stack, BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
        return dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
    }

    protected InteractionResult interactWithoutItem(BlockState state, Level level, BlockPos pos, Player player, BlockHitResult hit) {
        return super.use(state, level, pos, player, net.minecraft.world.InteractionHand.MAIN_HAND, hit);
    }

    @Override
    public void playerWillDestroy(Level level, BlockPos pos, BlockState state, Player player) {
        {
            net.minecraft.world.level.Level native$bodyOperand$5763 = level;
            net.minecraft.core.BlockPos native$bodyOperand$5764 = pos;
            net.minecraft.world.level.block.state.BlockState native$bodyOperand$5765 = state;
            net.minecraft.world.entity.player.Player native$bodyOperand$5766 = player;
            net.minecraft.world.level.block.state.BlockState native$bodyResult$5767 = null;
            native$bodyReturn$5768: {
                if (true) {
                    super.playerWillDestroy(native$bodyOperand$5763, native$bodyOperand$5764, native$bodyOperand$5765, native$bodyOperand$5766);
                    {
                        native$bodyResult$5767 = native$bodyOperand$5765;
                        break native$bodyReturn$5768;
                    }
                }
            }
        }
    }

    public BlockState beforePlayerDestroy(Level level, BlockPos pos, BlockState state, Player player) {
        super.playerWillDestroy(level, pos, state, player);
        return state;
    }

    protected boolean survivesSharedExplosion() {
        return false;
    }

    public int getExpDrop(net.minecraft.world.level.block.state.BlockState native$callbackInput$1145, net.minecraft.world.level.LevelReader native$callbackInput$1146, net.minecraft.util.RandomSource native$callbackInput$1147, net.minecraft.core.BlockPos native$callbackInput$1148, int native$callbackInput$1149, int native$callbackInput$1150) {
        net.minecraft.world.level.block.state.BlockState state = native$callbackInput$1145;
        net.minecraft.util.RandomSource random = native$callbackInput$1147;
        return 0;
    }

    @Override
    public void onBlockExploded(BlockState state, Level level, BlockPos pos, Explosion explosion) {
        if (!(switch(0) {
            default ->
                {
                    boolean native$bodyResult$5241 = false;
                    native$bodyReturn$5242: {
                        if (true) {
                            {
                                native$bodyResult$5241 = false;
                                break native$bodyReturn$5242;
                            }
                        }
                    }
                    yield native$bodyResult$5241;
                }
        }))
            super.onBlockExploded(state, level, pos, explosion);
    }

    @Override
    public boolean canDropFromExplosion(BlockState state, BlockGetter level, BlockPos pos, Explosion explosion) {
        return !(switch(0) {
            default ->
                {
                    boolean native$bodyResult$4297 = false;
                    native$bodyReturn$4298: {
                        if (true) {
                            {
                                native$bodyResult$4297 = false;
                                break native$bodyReturn$4298;
                            }
                        }
                    }
                    yield native$bodyResult$4297;
                }
        }) && super.canDropFromExplosion(state, level, pos, explosion);
    }

    static private <B extends net.minecraft.world.level.block.Block> com.mojang.serialization.MapCodec<B> native$BlockCodecPlatform$simple(java.util.function.Function<net.minecraft.world.level.block.state.BlockBehaviour.Properties, B> factory) {
        // Vanilla 1.21's Properties codec is a unit codec. Retain that schema for shared block definitions.
        return com.mojang.serialization.codecs.RecordCodecBuilder.mapCodec(instance -> instance.group(com.mojang.serialization.Codec.unit(net.minecraft.world.level.block.state.BlockBehaviour.Properties::of).fieldOf("properties").forGetter((B block) -> net.minecraft.world.level.block.state.BlockBehaviour.Properties.copy(block))).apply(instance, factory));
    }
}
