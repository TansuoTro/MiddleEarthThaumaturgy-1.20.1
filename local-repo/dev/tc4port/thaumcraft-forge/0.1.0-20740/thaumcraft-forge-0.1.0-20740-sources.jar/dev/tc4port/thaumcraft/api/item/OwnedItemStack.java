package dev.tc4port.thaumcraft.api.item;

import dev.tc4port.thaumcraft.api.item.ItemProperties;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.common.extensions.IForgeItem;

/**
 * Saved stack extensions supplied by owned items through Forge's native callbacks.
 */
public interface OwnedItemStack extends IForgeItem {

    @Override
    default int getMaxDamage(ItemStack stack) {
        return OwnedItemStack.native$ItemDurability$maximumOverride(stack).orElse(IForgeItem.super.getMaxDamage(stack));
    }

    @Override
    default boolean isDamageable(ItemStack stack) {
        // Both native ItemStack constructors invoke this before normalizing damage.
        // initCapabilities is lazy and cannot initialize data needed immediately.
        ItemProperties.initialize(stack);
        return IForgeItem.super.isDamageable(stack);
    }

    static private java.util.OptionalInt native$ItemDurability$maximumOverride(net.minecraft.world.item.ItemStack stack) {
        var tag = stack.getTag();
        int value = tag == null ? 0 : tag.getInt("minecraft:max_damage");
        return value > 0 ? java.util.OptionalInt.of(value) : java.util.OptionalInt.empty();
    }
}
