package dev.tc4port.thaumcraft.api.client;

/**
 * World-node layer parameters before drawing: radius in blocks, rotation in radians, RGB color and opacity.
 */
public record AuraNodeLayer(float radius, float rotation, int color, float opacity) {

    public AuraNodeLayer {
        if (!Float.isFinite(radius) || radius < 0 || !Float.isFinite(rotation) || !Float.isFinite(opacity))
            throw new IllegalArgumentException("Node layer parameters must be finite, with non-negative radius");
    }
}
