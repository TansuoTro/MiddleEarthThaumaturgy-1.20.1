package dev.tc4port.thaumcraft.api.focus;

import dev.tc4port.thaumcraft.api.aspect.AspectAmounts;
import java.util.Objects;
import java.util.List;
import net.minecraft.resources.ResourceLocation;

/**
 * Immutable presentation and crafting metadata for one focus upgrade.
 *
 * <p>The aspect amounts are positive coefficients. The focal manipulator
 * multiplies them by its rank-dependent centivis factor before reducing them
 * to primals.</p>
 */
public record FocusUpgradeDefinition(FocusUpgradeId id, ResourceLocation icon, String nameKey, String descriptionKey, AspectAmounts aspects, int maxLevel, List<Integer> rankVis, List<Integer> rankXp) {

    public FocusUpgradeDefinition {
        if (maxLevel < 1 || maxLevel > FocusProfileDefinition.RANK_COUNT) {
            throw new IllegalArgumentException("Upgrade max_level must be 1 through 5");
        }
        rankVis = List.copyOf(rankVis);
        rankXp = List.copyOf(rankXp);
        if (rankVis.size() != 5 || rankXp.size() != 5 || rankVis.stream().anyMatch(value -> value < 1 || value > 1_000_000) || rankXp.stream().anyMatch(value -> value < 0 || value > 1_000_000)) {
            throw new IllegalArgumentException("Upgrade rank_vis/rank_xp require five bounded amounts");
        }
        Objects.requireNonNull(id, "id");
        Objects.requireNonNull(icon, "icon");
        nameKey = requireText(nameKey, "nameKey");
        descriptionKey = requireText(descriptionKey, "descriptionKey");
        aspects = Objects.requireNonNull(aspects, "aspects");
        if (aspects.amounts().isEmpty()) {
            throw new IllegalArgumentException("A focus upgrade must have at least one aspect");
        }
    }

    private static String requireText(String value, String field) {
        Objects.requireNonNull(value, field);
        if (value.isBlank() || value.length() > 256) {
            throw new IllegalArgumentException(field + " must contain 1 through 256 characters");
        }
        return value;
    }
}
