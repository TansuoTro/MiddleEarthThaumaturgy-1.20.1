package dev.tc4port.thaumcraft.api.research;

import java.util.Objects;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.crafting.Ingredient;

/**
 * Presentation of a single-input workstation conversion. The book obtains
 * the output from the live recipe with the current level's registries.
 * An empty catalyst means no catalyst is required; alternatives are cycled.
 */
public record ResearchRecipeDisplay(Component title, Ingredient input, ItemStack workstation, Ingredient catalyst, Component cost) {

    public ResearchRecipeDisplay {
        title = Objects.requireNonNull(title, "title").copy();
        input = Objects.requireNonNull(input, "input");
        workstation = Objects.requireNonNull(workstation, "workstation").copy();
        catalyst = Objects.requireNonNull(catalyst, "catalyst");
        cost = Objects.requireNonNull(cost, "cost").copy();
    }

    @Override
    public Component title() {
        return title.copy();
    }

    @Override
    public ItemStack workstation() {
        return workstation.copy();
    }

    @Override
    public Component cost() {
        return cost.copy();
    }
}
