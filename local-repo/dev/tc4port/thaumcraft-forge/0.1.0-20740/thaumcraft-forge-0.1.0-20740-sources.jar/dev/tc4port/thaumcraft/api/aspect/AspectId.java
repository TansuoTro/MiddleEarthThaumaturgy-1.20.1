package dev.tc4port.thaumcraft.api.aspect;

import com.mojang.serialization.Codec;
import com.mojang.serialization.DataResult;
import java.util.Objects;
import net.minecraft.resources.ResourceLocation;

/**
 * The single stable identity type used by the public aspect API.
 */
public record AspectId(ResourceLocation value) implements Comparable<AspectId> {

    public static final Codec<AspectId> CODEC = Codec.STRING.comapFlatMap(AspectId::decode, AspectId::toString);

    public AspectId {
        value = Objects.requireNonNull(value, "value");
        if (value.toString().length() > 256) {
            throw new IllegalArgumentException("Aspect ID is longer than 256 characters: " + value);
        }
    }

    public static AspectId of(ResourceLocation value) {
        return new AspectId(value);
    }

    /**
     * Parses the current compact built-in spelling or a namespaced resource
     * ID. Public code should retain {@link AspectId} rather than round-tripping
     * strings.
     */
    public static AspectId parse(String value) {
        Objects.requireNonNull(value, "value");
        ResourceLocation parsed = value.indexOf(':') < 0 ? ResourceLocation.tryBuild("thaumcraft", value) : ResourceLocation.tryParse(value);
        if (parsed == null) {
            throw new IllegalArgumentException("Invalid aspect ID: " + value);
        }
        return new AspectId(parsed);
    }

    private static DataResult<AspectId> decode(String value) {
        try {
            return DataResult.success(parse(value));
        } catch (RuntimeException exception) {
            return DataResult.error(() -> "Invalid aspect ID '" + value + "': " + exception.getMessage());
        }
    }

    /**
     * Compact spelling used by current internal storage and data bridges.
     */
    public String serialized() {
        return this.value.getNamespace().equals("thaumcraft") ? this.value.getPath() : this.value.toString();
    }

    @Override
    public int compareTo(AspectId other) {
        return this.value.compareTo(other.value);
    }

    @Override
    public String toString() {
        return this.value.toString();
    }
}
