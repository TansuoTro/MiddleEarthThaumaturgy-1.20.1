package dev.tc4port.thaumcraft.api.gameplay;

import dev.tc4port.thaumcraft.common.GameplayEventCatalog;
import net.minecraft.resources.ResourceLocation;

/**
 * Submit an ordered behavior at a caller-owned gameplay entrypoint on the server thread.
 * A true result means the group passed its initial requirements and was accepted, not that
 * every action succeeded. Native command/function callers may resume before the group runs.
 * Callback failures stop the group's remaining steps; native commands handle their own errors.
 * Scheduled functions and asynchronous work are not awaited.
 */
public final class GameplayEventApi {

    private GameplayEventApi() {
    }

    public static boolean consumed(net.minecraft.world.entity.LivingEntity actor, net.minecraft.world.item.ItemStack originalItem, ResourceLocation behaviorId) {
        return itemUsed(actor, originalItem, behaviorId, java.util.Map.of());
    }

    public static boolean itemUsed(net.minecraft.world.entity.LivingEntity actor, net.minecraft.world.item.ItemStack usedItem, ResourceLocation behaviorId, java.util.Map<String, Double> values) {
        if (!(actor.level() instanceof net.minecraft.server.level.ServerLevel))
            return false;
        return dispatch(behaviorId, dev.tc4port.thaumcraft.common.GameplayContexts.of(actor, usedItem, values));
    }

    public static boolean dispatch(ResourceLocation behaviorId, GameplayContext context) {
        return GameplayEventCatalog.execute(behaviorId, context);
    }

    /**
     * Whether the current successful reload contains this enabled behavior.
     */
    public static boolean contains(ResourceLocation behaviorId) {
        return GameplayEventCatalog.contains(behaviorId);
    }

    /**
     * Execute an owner-provided action group without a named behavior resource.
     */
    public static boolean dispatch(GameplayAction actions, GameplayContext context) {
        return GameplayEventCatalog.execute(ResourceLocation.parse("thaumcraft:inline"), actions, context);
    }
}
