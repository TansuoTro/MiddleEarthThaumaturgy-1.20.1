package dev.tc4port.thaumcraft.api.client;

/**
 * Visual-only post chains; requesting these never grants gameplay mob effects.
 */
public enum ScreenEffect {

    DEATH_GAZE, BLURRED_VISION, UNNATURAL_HUNGER, SUN_SCORNED
}
