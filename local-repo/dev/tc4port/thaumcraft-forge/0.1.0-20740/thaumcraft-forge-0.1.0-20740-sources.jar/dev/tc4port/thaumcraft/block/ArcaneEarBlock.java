package dev.tc4port.thaumcraft.block;

import com.mojang.serialization.MapCodec;
import dev.tc4port.thaumcraft.block.entity.ArcaneEarBlockEntity;
import dev.tc4port.thaumcraft.registry.TCBlockEntities;
import javax.annotation.Nullable;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.NoteBlock;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityTicker;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.world.level.block.state.properties.NoteBlockInstrument;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;
import dev.tc4port.thaumcraft.nativeimpl.ClientExtensionTarget;
import dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.level.pathfinder.PathComputationType;
import net.minecraft.world.phys.HitResult;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.Explosion;

/**
 * Metadata one of TC4's BlockWoodenDevice.
 *
 * <p>The old renderer built the ear from ten cuboids while the tile listened
 * for a matching note/instrument within sixty-four blocks. Geometry now lives
 * in the baked model, but note playback remains a block event so the sound and
 * note particle are emitted exactly once on observing clients.</p>
 */
public final class ArcaneEarBlock extends net.minecraft.world.level.block.BaseEntityBlock implements dev.tc4port.thaumcraft.nativeimpl.ClientExtensionTarget {

    // Forge calls initializeClient from the native superclass constructor. Do not add a field initializer.
    private java.util.function.Consumer<net.minecraftforge.client.extensions.common.IClientBlockExtensions> platform$clientInstaller;

    public static final MapCodec<ArcaneEarBlock> CODEC = ArcaneEarBlock.native$BlockCodecPlatform$simple(ArcaneEarBlock::new);

    public static final BooleanProperty ACTIVE = BooleanProperty.create("active");

    public ArcaneEarBlock(BlockBehaviour.Properties properties) {
        this(properties, properties, true);
    }

    protected MapCodec<ArcaneEarBlock> codec() {
        return CODEC;
    }

    @Override
    public RenderShape getRenderShape(BlockState state) {
        return RenderShape.MODEL;
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(ACTIVE);
    }

    @Nullable
    @Override
    public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        return new ArcaneEarBlockEntity(pos, state);
    }

    @Nullable
    @Override
    public <T extends BlockEntity> BlockEntityTicker<T> getTicker(Level level, BlockState state, BlockEntityType<T> type) {
        return level.isClientSide ? null : createTickerHelper(type, TCBlockEntities.ARCANE_EAR.get(), ArcaneEarBlockEntity::serverTick);
    }

    @Override
    public void onPlace(BlockState state, Level level, BlockPos pos, BlockState oldState, boolean movedByPiston) {
        super.onPlace(state, level, pos, oldState, movedByPiston);
        if (!oldState.is(state.getBlock()) && level.getBlockEntity(pos) instanceof ArcaneEarBlockEntity ear) {
            ear.updateTone();
        }
    }

    @Override
    public void neighborChanged(BlockState state, Level level, BlockPos pos, Block neighborBlock, BlockPos neighborPos, boolean movedByPiston) {
        super.neighborChanged(state, level, pos, neighborBlock, neighborPos, movedByPiston);
        if (level.getBlockEntity(pos) instanceof ArcaneEarBlockEntity ear) {
            ear.updateTone();
        }
    }

    protected InteractionResult interactWithoutItem(BlockState state, Level level, BlockPos pos, Player player, BlockHitResult hitResult) {
        if (!level.isClientSide && level.getBlockEntity(pos) instanceof dev.tc4port.thaumcraft.block.entity.ArcaneEarBlockEntity ear) {
            ear.changePitch();
            ear.playTunedNote(true);
        }
        return net.minecraft.world.InteractionResult.sidedSuccess(level.isClientSide);
    }

    @Override
    public boolean triggerEvent(BlockState state, Level level, BlockPos pos, int instrument, int note) {
        if (instrument < -1 || instrument > NoteBlockInstrument.PLING.ordinal() || note < 0 || note > 24) {
            return super.triggerEvent(state, level, pos, instrument, note);
        }
        float pitch = NoteBlock.getPitchFromNote(note);
        if (instrument >= 0) {
            level.playSeededSound(null, pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5, instrument(instrument).getSoundEvent(), SoundSource.RECORDS, 3.0F, pitch, level.random.nextLong());
        }
        level.addParticle(ParticleTypes.NOTE, pos.getX() + 0.5, pos.getY() + 1.2, pos.getZ() + 0.5, note / 24.0, 0.0, 0.0);
        return true;
    }

    @Override
    public boolean isSignalSource(BlockState state) {
        return true;
    }

    @Override
    public int getSignal(BlockState state, BlockGetter level, BlockPos pos, Direction direction) {
        return state.getValue(ACTIVE) ? 15 : 0;
    }

    @Override
    public int getDirectSignal(BlockState state, BlockGetter level, BlockPos pos, Direction direction) {
        return state.getValue(ACTIVE) ? 15 : 0;
    }

    @Override
    public VoxelShape getBlockSupportShape(BlockState state, BlockGetter level, BlockPos pos) {
        return Shapes.empty();
    }

    @Override
    public int getLightBlock(BlockState state, BlockGetter level, BlockPos pos) {
        return 0;
    }

    public static int instrumentId(NoteBlockInstrument instrument) {
        return instrument.isTunable() ? instrument.ordinal() : -1;
    }

    public static NoteBlockInstrument instrument(int id) {
        return id >= 0 && id <= NoteBlockInstrument.PLING.ordinal() ? NoteBlockInstrument.values()[id] : NoteBlockInstrument.HARP;
    }

    private ArcaneEarBlock(net.minecraft.world.level.block.state.BlockBehaviour.Properties native$NativeEntityBlock$arg0, BlockBehaviour.Properties properties, boolean native$NativeEntityBlock$captured) {
        super(native$NativeEntityBlock$arg0);
        this.registerDefaultState(this.stateDefinition.any().setValue(ACTIVE, false));
    }

    @Override
    public void initializeClient(java.util.function.Consumer<net.minecraftforge.client.extensions.common.IClientBlockExtensions> installer) {
        platform$clientInstaller = installer;
        super.initializeClient(installer);
    }

    @Override
    public void platform$clientExtension(Object extension) {
        java.util.Objects.requireNonNull(platform$clientInstaller, "Forge initializeClient must run before client extension registration").accept((net.minecraftforge.client.extensions.common.IClientBlockExtensions) extension);
    }

    @Override
    public InteractionResult use(BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
        ItemUseResult result = (switch(0) {
            default ->
                {
                    net.minecraft.world.item.ItemStack native$bodyOperand$4134 = player.getItemInHand(hand);
                    net.minecraft.world.level.block.state.BlockState native$bodyOperand$4135 = state;
                    net.minecraft.world.level.Level native$bodyOperand$4136 = level;
                    net.minecraft.core.BlockPos native$bodyOperand$4137 = pos;
                    net.minecraft.world.entity.player.Player native$bodyOperand$4138 = player;
                    net.minecraft.world.InteractionHand native$bodyOperand$4139 = hand;
                    net.minecraft.world.phys.BlockHitResult native$bodyOperand$4140 = hit;
                    dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult native$bodyResult$4141 = null;
                    native$bodyReturn$4142: {
                        if (true) {
                            {
                                native$bodyResult$4141 = dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
                                break native$bodyReturn$4142;
                            }
                        }
                    }
                    yield native$bodyResult$4141;
                }
        });
        return result == ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION ? (hand == InteractionHand.MAIN_HAND ? (switch(0) {
            default ->
                {
                    net.minecraft.world.level.block.state.BlockState native$bodyOperand$3476 = state;
                    net.minecraft.world.level.Level native$bodyOperand$3477 = level;
                    net.minecraft.core.BlockPos native$bodyOperand$3478 = pos;
                    net.minecraft.world.entity.player.Player native$bodyOperand$3479 = player;
                    net.minecraft.world.phys.BlockHitResult native$bodyOperand$3480 = hit;
                    net.minecraft.world.InteractionResult native$bodyResult$3482 = null;
                    native$bodyReturn$3483: {
                        if (true) {
                            if (!native$bodyOperand$3477.isClientSide && native$bodyOperand$3477.getBlockEntity(native$bodyOperand$3478) instanceof dev.tc4port.thaumcraft.block.entity.ArcaneEarBlockEntity native$bodyBinding$3481) {
                                native$bodyBinding$3481.changePitch();
                                native$bodyBinding$3481.playTunedNote(true);
                            }
                            {
                                native$bodyResult$3482 = net.minecraft.world.InteractionResult.sidedSuccess(native$bodyOperand$3477.isClientSide);
                                break native$bodyReturn$3483;
                            }
                        }
                    }
                    yield native$bodyResult$3482;
                }
        }) : InteractionResult.PASS) : result.result();
    }

    protected ItemUseResult interactWithItem(ItemStack stack, BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
        return dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
    }

    @Override
    public void playerWillDestroy(Level level, BlockPos pos, BlockState state, Player player) {
        {
            net.minecraft.world.level.Level native$bodyOperand$5660 = level;
            net.minecraft.core.BlockPos native$bodyOperand$5661 = pos;
            net.minecraft.world.level.block.state.BlockState native$bodyOperand$5662 = state;
            net.minecraft.world.entity.player.Player native$bodyOperand$5663 = player;
            net.minecraft.world.level.block.state.BlockState native$bodyResult$5664 = null;
            native$bodyReturn$5665: {
                if (true) {
                    super.playerWillDestroy(native$bodyOperand$5660, native$bodyOperand$5661, native$bodyOperand$5662, native$bodyOperand$5663);
                    {
                        native$bodyResult$5664 = native$bodyOperand$5662;
                        break native$bodyReturn$5665;
                    }
                }
            }
        }
    }

    public BlockState beforePlayerDestroy(Level level, BlockPos pos, BlockState state, Player player) {
        super.playerWillDestroy(level, pos, state, player);
        return state;
    }

    protected boolean survivesSharedExplosion() {
        return false;
    }

    public int getExpDrop(net.minecraft.world.level.block.state.BlockState native$callbackInput$1050, net.minecraft.world.level.LevelReader native$callbackInput$1051, net.minecraft.util.RandomSource native$callbackInput$1052, net.minecraft.core.BlockPos native$callbackInput$1053, int native$callbackInput$1054, int native$callbackInput$1055) {
        net.minecraft.world.level.block.state.BlockState state = native$callbackInput$1050;
        net.minecraft.util.RandomSource random = native$callbackInput$1052;
        return 0;
    }

    @Override
    public void onBlockExploded(BlockState state, Level level, BlockPos pos, Explosion explosion) {
        if (!(switch(0) {
            default ->
                {
                    boolean native$bodyResult$5215 = false;
                    native$bodyReturn$5216: {
                        if (true) {
                            {
                                native$bodyResult$5215 = false;
                                break native$bodyReturn$5216;
                            }
                        }
                    }
                    yield native$bodyResult$5215;
                }
        }))
            super.onBlockExploded(state, level, pos, explosion);
    }

    @Override
    public boolean canDropFromExplosion(BlockState state, BlockGetter level, BlockPos pos, Explosion explosion) {
        return !(switch(0) {
            default ->
                {
                    boolean native$bodyResult$4143 = false;
                    native$bodyReturn$4144: {
                        if (true) {
                            {
                                native$bodyResult$4143 = false;
                                break native$bodyReturn$4144;
                            }
                        }
                    }
                    yield native$bodyResult$4143;
                }
        }) && super.canDropFromExplosion(state, level, pos, explosion);
    }

    static private <B extends net.minecraft.world.level.block.Block> com.mojang.serialization.MapCodec<B> native$BlockCodecPlatform$simple(java.util.function.Function<net.minecraft.world.level.block.state.BlockBehaviour.Properties, B> factory) {
        // Vanilla 1.21's Properties codec is a unit codec. Retain that schema for shared block definitions.
        return com.mojang.serialization.codecs.RecordCodecBuilder.mapCodec(instance -> instance.group(com.mojang.serialization.Codec.unit(net.minecraft.world.level.block.state.BlockBehaviour.Properties::of).fieldOf("properties").forGetter((B block) -> net.minecraft.world.level.block.state.BlockBehaviour.Properties.copy(block))).apply(instance, factory));
    }
}
