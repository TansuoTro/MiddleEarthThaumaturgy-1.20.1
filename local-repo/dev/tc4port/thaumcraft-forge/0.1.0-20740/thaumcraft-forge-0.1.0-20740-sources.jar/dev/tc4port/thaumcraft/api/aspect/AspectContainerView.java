package dev.tc4port.thaumcraft.api.aspect;

import java.util.Set;
import java.util.List;

/**
 * Read-only aspect contents exposed to goggles and other inspectors.
 *
 * <p>Stored quantities and display-only filters are intentionally separate:
 * a filter identity is not a negative or phantom amount. Implementations
 * must return immutable snapshots and must not mutate while queried.</p>
 */
public interface AspectContainerView {

    AspectAmounts visibleAspects();

    /**
     * Ordered identities to display. The list may include an identity whose
     * sparse amount is zero.
     */
    default List<AspectId> visibleAspectOrder() {
        return List.copyOf(this.visibleAspects().amounts().keySet());
    }

    default Set<AspectId> visibleAspectFilters() {
        return Set.of();
    }
}
