package dev.tc4port.thaumcraft.block;

import net.minecraft.core.BlockPos;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;
import dev.tc4port.thaumcraft.nativeimpl.ClientExtensionTarget;
import dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.level.pathfinder.PathComputationType;
import net.minecraft.world.phys.HitResult;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.Explosion;

/**
 * Non-tile variants of TC4's metadata-driven {@code BlockEldritch}.
 *
 * <p>The original block deliberately only yielded itself for metadata four,
 * yielded one knowledge fragment for metadata five, and yielded nothing for
 * the doorway and locking-mechanism variants.</p>
 */
public final class EldritchStoneBlock extends net.minecraft.world.level.block.Block implements dev.tc4port.thaumcraft.nativeimpl.ClientExtensionTarget {

    // Forge calls initializeClient from the native superclass constructor. Do not add a field initializer.
    private java.util.function.Consumer<net.minecraftforge.client.extensions.common.IClientBlockExtensions> platform$clientInstaller;

    public enum Kind {

        GLOWING_CRUSTED_STONE, GLYPHED_STONE, ANCIENT_DOORWAY, ANCIENT_LOCKING_MECHANISM
    }

    private final Kind kind;

    public EldritchStoneBlock(Kind kind, BlockBehaviour.Properties properties) {
        this(kind == Kind.ANCIENT_DOORWAY || kind == Kind.ANCIENT_LOCKING_MECHANISM ? properties.noLootTable() : properties, kind, properties, true);
    }

    public Kind kind() {
        return this.kind;
    }

    @Override
    public VoxelShape getOcclusionShape(BlockState state, BlockGetter level, BlockPos pos) {
        // The inset mesh leaves parts of adjacent block faces visible.
        return this.kind == Kind.GLOWING_CRUSTED_STONE ? Shapes.empty() : super.getOcclusionShape(state, level, pos);
    }

    public int getExpDrop(net.minecraft.world.level.block.state.BlockState native$callbackInput$1151, net.minecraft.world.level.LevelReader native$callbackInput$1152, net.minecraft.util.RandomSource native$callbackInput$1153, net.minecraft.core.BlockPos native$callbackInput$1154, int native$callbackInput$1155, int native$callbackInput$1156) {
        net.minecraft.world.level.block.state.BlockState state = native$callbackInput$1151;
        net.minecraft.util.RandomSource random = native$callbackInput$1153;
        return this.kind == Kind.GLYPHED_STONE ? 1 + random.nextInt(4) : 0;
    }

    private EldritchStoneBlock(net.minecraft.world.level.block.state.BlockBehaviour.Properties native$NativeBlock$arg0, Kind kind, BlockBehaviour.Properties properties, boolean native$NativeBlock$captured) {
        super(native$NativeBlock$arg0);
        this.kind = kind;
    }

    @Override
    public void initializeClient(java.util.function.Consumer<net.minecraftforge.client.extensions.common.IClientBlockExtensions> installer) {
        platform$clientInstaller = installer;
        super.initializeClient(installer);
    }

    @Override
    public void platform$clientExtension(Object extension) {
        java.util.Objects.requireNonNull(platform$clientInstaller, "Forge initializeClient must run before client extension registration").accept((net.minecraftforge.client.extensions.common.IClientBlockExtensions) extension);
    }

    @Override
    public InteractionResult use(BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
        ItemUseResult result = (switch(0) {
            default ->
                {
                    net.minecraft.world.item.ItemStack native$bodyOperand$4377 = player.getItemInHand(hand);
                    net.minecraft.world.level.block.state.BlockState native$bodyOperand$4378 = state;
                    net.minecraft.world.level.Level native$bodyOperand$4379 = level;
                    net.minecraft.core.BlockPos native$bodyOperand$4380 = pos;
                    net.minecraft.world.entity.player.Player native$bodyOperand$4381 = player;
                    net.minecraft.world.InteractionHand native$bodyOperand$4382 = hand;
                    net.minecraft.world.phys.BlockHitResult native$bodyOperand$4383 = hit;
                    dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult native$bodyResult$4384 = null;
                    native$bodyReturn$4385: {
                        if (true) {
                            {
                                native$bodyResult$4384 = dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
                                break native$bodyReturn$4385;
                            }
                        }
                    }
                    yield native$bodyResult$4384;
                }
        });
        return result == ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION ? (hand == InteractionHand.MAIN_HAND ? (switch(0) {
            default ->
                {
                    net.minecraft.world.level.block.state.BlockState native$bodyOperand$3638 = state;
                    net.minecraft.world.level.Level native$bodyOperand$3639 = level;
                    net.minecraft.core.BlockPos native$bodyOperand$3640 = pos;
                    net.minecraft.world.entity.player.Player native$bodyOperand$3641 = player;
                    net.minecraft.world.phys.BlockHitResult native$bodyOperand$3642 = hit;
                    net.minecraft.world.InteractionResult native$bodyResult$3643 = null;
                    native$bodyReturn$3644: {
                        if (true) {
                            {
                                native$bodyResult$3643 = super.use(native$bodyOperand$3638, native$bodyOperand$3639, native$bodyOperand$3640, native$bodyOperand$3641, net.minecraft.world.InteractionHand.MAIN_HAND, native$bodyOperand$3642);
                                break native$bodyReturn$3644;
                            }
                        }
                    }
                    yield native$bodyResult$3643;
                }
        }) : InteractionResult.PASS) : result.result();
    }

    protected ItemUseResult interactWithItem(ItemStack stack, BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
        return dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
    }

    protected InteractionResult interactWithoutItem(BlockState state, Level level, BlockPos pos, Player player, BlockHitResult hit) {
        return super.use(state, level, pos, player, net.minecraft.world.InteractionHand.MAIN_HAND, hit);
    }

    @Override
    public void playerWillDestroy(Level level, BlockPos pos, BlockState state, Player player) {
        {
            net.minecraft.world.level.Level native$bodyOperand$5811 = level;
            net.minecraft.core.BlockPos native$bodyOperand$5812 = pos;
            net.minecraft.world.level.block.state.BlockState native$bodyOperand$5813 = state;
            net.minecraft.world.entity.player.Player native$bodyOperand$5814 = player;
            net.minecraft.world.level.block.state.BlockState native$bodyResult$5815 = null;
            native$bodyReturn$5816: {
                if (true) {
                    super.playerWillDestroy(native$bodyOperand$5811, native$bodyOperand$5812, native$bodyOperand$5813, native$bodyOperand$5814);
                    {
                        native$bodyResult$5815 = native$bodyOperand$5813;
                        break native$bodyReturn$5816;
                    }
                }
            }
        }
    }

    public BlockState beforePlayerDestroy(Level level, BlockPos pos, BlockState state, Player player) {
        super.playerWillDestroy(level, pos, state, player);
        return state;
    }

    protected boolean survivesSharedExplosion() {
        return false;
    }

    @Override
    public void onBlockExploded(BlockState state, Level level, BlockPos pos, Explosion explosion) {
        if (!(switch(0) {
            default ->
                {
                    boolean native$bodyResult$5257 = false;
                    native$bodyReturn$5258: {
                        if (true) {
                            {
                                native$bodyResult$5257 = false;
                                break native$bodyReturn$5258;
                            }
                        }
                    }
                    yield native$bodyResult$5257;
                }
        }))
            super.onBlockExploded(state, level, pos, explosion);
    }

    @Override
    public boolean canDropFromExplosion(BlockState state, BlockGetter level, BlockPos pos, Explosion explosion) {
        return !(switch(0) {
            default ->
                {
                    boolean native$bodyResult$4386 = false;
                    native$bodyReturn$4387: {
                        if (true) {
                            {
                                native$bodyResult$4386 = false;
                                break native$bodyReturn$4387;
                            }
                        }
                    }
                    yield native$bodyResult$4386;
                }
        }) && super.canDropFromExplosion(state, level, pos, explosion);
    }
}
