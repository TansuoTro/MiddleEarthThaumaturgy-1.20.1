package dev.tc4port.thaumcraft.api.client;

import dev.tc4port.thaumcraft.api.aspect.AspectId;
import javax.annotation.Nullable;

/**
 * Optional recipe-viewer hover contract for replacement research-table screens. Coordinates and bounds are in GUI screen units, after any screen-local scaling.
 */
public interface ResearchAspectScreen {

    record AspectHit(AspectId aspect, int x, int y, int width, int height) {

        public AspectHit(AspectId aspect, int x, int y) {
            this(aspect, x, y, 16, 16);
        }

        public AspectHit {
            java.util.Objects.requireNonNull(aspect, "aspect");
            if (width <= 0 || height <= 0)
                throw new IllegalArgumentException("Aspect hit bounds must be positive");
        }
    }

    @Nullable
    AspectHit aspectUnderMouse(double mouseX, double mouseY);
}
