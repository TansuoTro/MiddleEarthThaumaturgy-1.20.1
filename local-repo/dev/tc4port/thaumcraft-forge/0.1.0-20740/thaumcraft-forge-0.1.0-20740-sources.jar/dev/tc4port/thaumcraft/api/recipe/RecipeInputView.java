package dev.tc4port.thaumcraft.api.recipe;

import net.minecraft.world.item.ItemStack;

/**
 * Read-only recipe snapshot with the input interface required by this Minecraft version.
 */
public interface RecipeInputView extends net.minecraft.world.Container {

    int size();

    ItemStack getItem(int slot);

    default int getContainerSize() {
        return size();
    }

    default boolean isEmpty() {
        for (int slot = 0; slot < size(); slot++) if (!getItem(slot).isEmpty())
            return false;
        return true;
    }

    default ItemStack removeItem(int slot, int count) {
        throw new UnsupportedOperationException("Recipe inputs are read-only");
    }

    default ItemStack removeItemNoUpdate(int slot) {
        throw new UnsupportedOperationException("Recipe inputs are read-only");
    }

    default void setItem(int slot, ItemStack stack) {
        throw new UnsupportedOperationException("Recipe inputs are read-only");
    }

    default void clearContent() {
        throw new UnsupportedOperationException("Recipe inputs are read-only");
    }

    default void setChanged() {
    }

    default boolean stillValid(net.minecraft.world.entity.player.Player player) {
        return false;
    }
}
