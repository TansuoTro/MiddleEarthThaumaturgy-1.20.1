package dev.tc4port.thaumcraft.api.client;

import java.util.*;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.LivingEntity;

/**
 * Composable native clothing passes. Each participant declares which professions it owns.
 */
public final class ClothingLayerHooks {

    public interface Interceptor {

        <T extends LivingEntity> void render(int pass, EntityModel<T> model, ResourceLocation texture, PoseStack poses, MultiBufferSource buffers, int light, T entity, int color, Runnable next);
    }

    private static final List<Interceptor> INTERCEPTORS = new ArrayList<>();

    private ClothingLayerHooks() {
    }

    public static void register(Interceptor interceptor) {
        INTERCEPTORS.add(interceptor);
    }

    public static <T extends LivingEntity> void render(int pass, EntityModel<T> model, ResourceLocation texture, PoseStack poses, MultiBufferSource buffers, int light, T entity, int color, Runnable original) {
        render(0, pass, model, texture, poses, buffers, light, entity, color, original);
    }

    private static <T extends LivingEntity> void render(int index, int pass, EntityModel<T> model, ResourceLocation texture, PoseStack poses, MultiBufferSource buffers, int light, T entity, int color, Runnable original) {
        if (index == INTERCEPTORS.size())
            original.run();
        else
            INTERCEPTORS.get(index).render(pass, model, texture, poses, buffers, light, entity, color, () -> render(index + 1, pass, model, texture, poses, buffers, light, entity, color, original));
    }
}
