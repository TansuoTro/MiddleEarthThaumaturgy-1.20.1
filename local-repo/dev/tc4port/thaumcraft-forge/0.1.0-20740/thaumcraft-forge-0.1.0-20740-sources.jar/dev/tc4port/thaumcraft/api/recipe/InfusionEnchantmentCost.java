package dev.tc4port.thaumcraft.api.recipe;

import dev.tc4port.thaumcraft.api.aspect.AspectAmounts;

/**
 * Resolved cost for one operation. Experience is whole player levels, not XP points.
 */
public record InfusionEnchantmentCost(AspectAmounts aspects, int instability, int experienceLevels) {

    public InfusionEnchantmentCost {
        java.util.Objects.requireNonNull(aspects, "aspects");
        if (instability < 0 || experienceLevels < 0) {
            throw new IllegalArgumentException("Infusion costs must be non-negative");
        }
    }
}
