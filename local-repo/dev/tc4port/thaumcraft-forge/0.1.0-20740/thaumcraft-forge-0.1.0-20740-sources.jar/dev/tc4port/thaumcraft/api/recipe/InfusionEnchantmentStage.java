package dev.tc4port.thaumcraft.api.recipe;

import com.mojang.serialization.Codec;
import com.mojang.serialization.DataResult;
import java.util.Map;

/**
 * One explicit transition. Undeclared input levels cannot use the recipe.
 */
public record InfusionEnchantmentStage(int from, int to) {

    public static final Codec<InfusionEnchantmentStage> CODEC = Codec.unboundedMap(Codec.STRING, Codec.INT).comapFlatMap(values -> {
        if (!values.keySet().equals(java.util.Set.of("from", "to"))) {
            return DataResult.error(() -> "An enchantment stage requires from and to");
        }
        try {
            return DataResult.success(new InfusionEnchantmentStage(values.get("from"), values.get("to")));
        } catch (IllegalArgumentException exception) {
            return DataResult.error(exception::getMessage);
        }
    }, stage -> Map.of("from", stage.from(), "to", stage.to()));

    public InfusionEnchantmentStage {
        if (from < 0 || to <= from || to > 255) {
            throw new IllegalArgumentException("Enchantment stages require 0 <= from < to <= 255");
        }
    }
}
