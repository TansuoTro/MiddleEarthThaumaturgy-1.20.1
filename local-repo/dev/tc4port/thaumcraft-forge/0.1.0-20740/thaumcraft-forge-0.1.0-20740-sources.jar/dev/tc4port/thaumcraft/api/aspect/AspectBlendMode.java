package dev.tc4port.thaumcraft.api.aspect;

/**
 * Render blend contract carried by a data-pack aspect definition.
 */
public enum AspectBlendMode {

    ADDITIVE, NORMAL
}
