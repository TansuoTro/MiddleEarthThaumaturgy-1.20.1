package dev.tc4port.thaumcraft.api.essentia;

/**
 * Public native capability identities shared by core machines and addons.
 */
public final class EssentiaCapabilities {

    private EssentiaCapabilities() {
    }

    /**
     * Directional transport, including jars and pipes. The query face belongs to
     * the endpoint. A null face discovers the endpoint without granting access;
     * transfers must still use a concrete face and obey its connection rules.
     * Implementing EssentiaTransport on a block entity automatically provides this
     * capability. Other implementations can register a native provider for it.
     */
    public static final net.minecraftforge.common.capabilities.Capability<EssentiaTransport> TRANSPORT = (switch(0) {
        default ->
            {
                java.util.Objects.requireNonNull(net.minecraft.resources.ResourceLocation.fromNamespaceAndPath((java.lang.String) ("thaumcraft"), (java.lang.String) ("essentia_transport")));
                yield java.util.Objects.requireNonNull(net.minecraftforge.common.capabilities.CapabilityManager.get(new net.minecraftforge.common.capabilities.CapabilityToken<dev.tc4port.thaumcraft.api.essentia.EssentiaTransport>() {
                }));
            }
    });

    /**
     * Remote extraction, independent of directional transport. Query with a null
     * face. Presence permits source requests; simulation determines whether the
     * source can satisfy a particular aspect and amount without mutation.
     * Implementing EssentiaSource on a block entity automatically provides this
     * capability. Other implementations can register a native provider for it.
     */
    public static final net.minecraftforge.common.capabilities.Capability<EssentiaSource> SOURCE = (switch(0) {
        default ->
            {
                java.util.Objects.requireNonNull(net.minecraft.resources.ResourceLocation.fromNamespaceAndPath((java.lang.String) ("thaumcraft"), (java.lang.String) ("essentia_source")));
                yield java.util.Objects.requireNonNull(net.minecraftforge.common.capabilities.CapabilityManager.get(new net.minecraftforge.common.capabilities.CapabilityToken<dev.tc4port.thaumcraft.api.essentia.EssentiaSource>() {
                }));
            }
    });
}
