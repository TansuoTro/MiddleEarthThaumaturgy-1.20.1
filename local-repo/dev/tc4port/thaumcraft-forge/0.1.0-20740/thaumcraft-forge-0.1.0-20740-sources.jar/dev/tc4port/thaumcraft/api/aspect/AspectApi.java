package dev.tc4port.thaumcraft.api.aspect;

import dev.tc4port.thaumcraft.aspect.AspectRegistryManager;
import java.util.LinkedHashMap;
import java.util.Objects;
import net.minecraft.world.item.ItemStack;

/**
 * Stable entry point for querying the active server-synchronized aspect set.
 */
public final class AspectApi {

    private AspectApi() {
    }

    public static AspectRegistryView registry() {
        return AspectRegistryManager.current();
    }

    /**
     * Current definitions; callers should not retain them across a reload.
     */
    public static java.util.Map<AspectId, AspectDefinition> definitions() {
        return registry().definitions();
    }

    public static java.util.Set<AspectId> primals() {
        return registry().primals();
    }

    /**
     * Returns null when the active registry has no such aspect.
     */
    @javax.annotation.Nullable
    public static AspectDefinition get(AspectId id) {
        return registry().get(id).orElse(null);
    }

    public static boolean contains(AspectId id) {
        return registry().get(id).isPresent();
    }

    public static java.util.Optional<AspectId> combination(AspectId first, AspectId second) {
        return registry().combination(first, second);
    }

    public static net.minecraft.network.chat.MutableComponent tooltipName(AspectId id) {
        return dev.tc4port.thaumcraft.aspect.AspectCatalog.tooltipName(id);
    }

    public static net.minecraft.network.chat.MutableComponent tooltipDescription(AspectId id) {
        return dev.tc4port.thaumcraft.aspect.AspectCatalog.tooltipDescription(id);
    }

    public static net.minecraft.network.chat.MutableComponent tooltipEntry(AspectId id, String suffix) {
        return dev.tc4port.thaumcraft.aspect.AspectCatalog.tooltipEntry(id, suffix);
    }

    /**
     * Read-only machine contents; absence means the block has no aspect inspection contract.
     */
    public static java.util.Optional<AspectAmounts> getBlockAspects(net.minecraft.world.level.block.entity.BlockEntity block) {
        Objects.requireNonNull(block, "block");
        if (block instanceof AspectContainerView view)
            return java.util.Optional.of(view.visibleAspects());
        if (block instanceof dev.tc4port.thaumcraft.block.entity.AlchemyFurnaceBlockEntity furnace)
            return java.util.Optional.of(new AspectAmounts(furnace.aspects()));
        return java.util.Optional.empty();
    }

    /**
     * Reads item-owned whole-aspect contents through the supported SPI.
     */
    public static AspectAmounts getItemAspects(ItemStack stack) {
        Objects.requireNonNull(stack, "stack");
        if (!(stack.getItem() instanceof AspectItemView view)) {
            return AspectAmounts.EMPTY;
        }
        AspectAmounts stored = Objects.requireNonNull(view.storedAspectData(stack), "AspectItemView returned null");
        AspectRegistryView registry = registry();
        LinkedHashMap<AspectId, Integer> active = new LinkedHashMap<>();
        stored.amounts().forEach((id, amount) -> {
            if (registry.get(id).isPresent()) {
                active.put(id, amount);
            }
        });
        return new AspectAmounts(active);
    }
}
