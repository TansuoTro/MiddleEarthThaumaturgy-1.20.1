package dev.tc4port.thaumcraft.api.node;

import java.util.Objects;

/**
 * Read-only metadata for one of the six built-in node behaviors.
 */
public record NodeTypeDefinition(NodeTypeId id, NodeAspectProfile initialAspectProfile, int generationWeight, boolean shiny, boolean darkRender, int renderLayer, boolean fixedRotation, boolean volatileOutput, float coreScale, java.util.Map<String, Double> parameters) {

    public NodeTypeDefinition {
        id = Objects.requireNonNull(id, "id");
        initialAspectProfile = Objects.requireNonNull(initialAspectProfile, "initialAspectProfile");
        if (generationWeight < 0 || renderLayer < 0 || renderLayer >= 32 || !Float.isFinite(coreScale) || coreScale <= 0.0F || coreScale > 1_000.0F) {
            throw new IllegalArgumentException("Invalid node type definition " + id);
        }
        parameters.forEach((name, value) -> {
            double minimum = 0, maximum = 1000000;
            boolean integer = false;
            switch(name) {
                case "hungry_range" ->
                    {
                        minimum = .001;
                        maximum = 32;
                    }
                case "hungry_damage_distance_squared" ->
                    maximum = 1024;
                case "hungry_damage", "hungry_horizontal_pull", "hungry_vertical_pull" ->
                    {
                    }
                case "neighbor_offset_choices" ->
                    {
                        minimum = 1;
                        maximum = 17;
                        integer = true;
                    }
                case "shiny_growth_divisor" ->
                    minimum = .001;
                case "pale_recovery_denominator", "target_erosion_denominator", "aspect_removal_denominator", "modifier_decay_denominator", "fading_decay_denominator", "aspect_decay_interval" ->
                    {
                        minimum = 1;
                        integer = true;
                    }
                default ->
                    throw new IllegalArgumentException("Unknown node behavior parameter " + name);
            }
            if (value == null || !Double.isFinite(value) || value < minimum || value > maximum || integer && Math.rint(value) != value)
                throw new IllegalArgumentException("Invalid node parameter " + name);
        });
        parameters = java.util.Map.copyOf(parameters);
    }

    public double number(String name, double fallback) {
        return parameters.getOrDefault(name, fallback);
    }

    public int integer(String name, int fallback) {
        return parameters.getOrDefault(name, (double) fallback).intValue();
    }
}
