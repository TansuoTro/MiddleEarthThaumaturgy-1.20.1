package dev.tc4port.thaumcraft.block;

import com.mojang.serialization.MapCodec;
import dev.tc4port.thaumcraft.client.SparkleParticle;
import net.minecraft.world.level.block.LeavesBlock;
import java.util.Objects;
import java.util.function.BooleanSupplier;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;

/**
 * TC4 magical leaves with native loot tables and source decay distance.
 *
 * <p>Modern distance propagation replaces the source's 32-cube scratch
 * array. Disconnected, non-persistent leaves evaluate their native loot
 * table before removal; the same table owns player harvesting.</p>
 */
public final class MagicalLeavesBlock extends LeavesBlock {

    /**
     * The source breadth-first search accepted supports at distance 0..4.
     */
    public static final int LEGACY_SUPPORT_DISTANCE = 4;

    private static volatile BooleanSupplier fancyGraphics = () -> true;

    public enum Kind {

        GREATWOOD, SILVERWOOD
    }

    private final Kind kind;

    public MagicalLeavesBlock(Kind kind, BlockBehaviour.Properties properties) {
        super(properties);
        this.kind = kind;
    }

    @Override
    public void randomTick(BlockState state, ServerLevel level, BlockPos pos, RandomSource random) {
        if (!this.decaying(state)) {
            return;
        }
        Block.dropResources(state, level, pos);
        level.removeBlock(pos, false);
    }

    @Override
    public boolean isRandomlyTicking(BlockState state) {
        return this.decaying(state);
    }

    @Override
    protected boolean decaying(BlockState state) {
        return !state.getValue(PERSISTENT) && state.getValue(DISTANCE) > LEGACY_SUPPORT_DISTANCE;
    }

    /**
     * Installs the client graphics-mode lookup without linking this common
     * block class to client-only Minecraft classes on a dedicated server.
     */
    public static void setFancyGraphicsSupplier(BooleanSupplier supplier) {
        fancyGraphics = Objects.requireNonNull(supplier);
    }

    public static boolean usesFancyGraphics() {
        return fancyGraphics.getAsBoolean();
    }

    public static boolean hidesSharedFace(boolean fancy, BlockState adjacentState) {
        return !fancy && adjacentState.getBlock() instanceof MagicalLeavesBlock;
    }

    @Override
    public boolean skipRendering(BlockState state, BlockState adjacentState, Direction direction) {
        /*
         * BlockMagicalLeaves was one metadata block, so fast mode hid the
         * shared face even when Greatwood touched Silverwood. Fancy mode
         * rendered every leaf-to-leaf interior face.
         */
        return hidesSharedFace(usesFancyGraphics(), adjacentState) || super.skipRendering(state, adjacentState, direction);
    }

    @Override
    public int getFlammability(BlockState state, BlockGetter level, BlockPos pos, Direction face) {
        return 60;
    }

    @Override
    public int getFireSpreadSpeed(BlockState state, BlockGetter level, BlockPos pos, Direction face) {
        return 30;
    }

    @Override
    public void animateTick(BlockState state, Level level, BlockPos pos, RandomSource random) {
        super.animateTick(state, level, pos, random);
        if (this.kind != Kind.SILVERWOOD || random.nextInt(500) != 0) {
            return;
        }
        SparkleParticle.spawnProxy(level, pos.getX() + 0.5F + level.random.nextFloat() - level.random.nextFloat(), pos.getY() + 0.5F + level.random.nextFloat() - level.random.nextFloat(), pos.getZ() + 0.5F + level.random.nextFloat() - level.random.nextFloat(), 2.0F, 7, 0.0F);
    }

    public static final MapCodec<MagicalLeavesBlock> GREATWOOD_CODEC = MagicalLeavesBlock.native$BlockCodecPlatform$simple(properties -> new MagicalLeavesBlock(Kind.GREATWOOD, properties));

    public static final MapCodec<MagicalLeavesBlock> SILVERWOOD_CODEC = MagicalLeavesBlock.native$BlockCodecPlatform$simple(properties -> new MagicalLeavesBlock(Kind.SILVERWOOD, properties));

    public MapCodec<MagicalLeavesBlock> codec() {
        return kind == Kind.GREATWOOD ? GREATWOOD_CODEC : SILVERWOOD_CODEC;
    }

    static private <B extends net.minecraft.world.level.block.Block> com.mojang.serialization.MapCodec<B> native$BlockCodecPlatform$simple(java.util.function.Function<net.minecraft.world.level.block.state.BlockBehaviour.Properties, B> factory) {
        // Vanilla 1.21's Properties codec is a unit codec. Retain that schema for shared block definitions.
        return com.mojang.serialization.codecs.RecordCodecBuilder.mapCodec(instance -> instance.group(com.mojang.serialization.Codec.unit(net.minecraft.world.level.block.state.BlockBehaviour.Properties::of).fieldOf("properties").forGetter((B block) -> net.minecraft.world.level.block.state.BlockBehaviour.Properties.copy(block))).apply(instance, factory));
    }
}
