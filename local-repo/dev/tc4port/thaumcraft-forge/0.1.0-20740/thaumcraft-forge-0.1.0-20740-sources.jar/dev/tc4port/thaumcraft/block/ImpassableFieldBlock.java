package dev.tc4port.thaumcraft.block;

import com.mojang.serialization.MapCodec;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.pathfinder.PathComputationType;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;
import dev.tc4port.thaumcraft.nativeimpl.ClientExtensionTarget;
import dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.Explosion;

/**
 * BlockAiry metadata twelve, the invisible solid membrane around a sealed
 * Outer Lands boss-room lock.
 *
 * <p>The source deliberately returned no selection or ordinary rendered
 * shape, was not replaceable and supplied a full cube only to collision.
 * Keeping it separate from the genuinely intangible Airy identities avoids
 * turning the five-by-five lock field into an open doorway.</p>
 */
public final class ImpassableFieldBlock extends net.minecraft.world.level.block.Block implements dev.tc4port.thaumcraft.nativeimpl.ClientExtensionTarget {

    // Forge calls initializeClient from the native superclass constructor. Do not add a field initializer.
    private java.util.function.Consumer<net.minecraftforge.client.extensions.common.IClientBlockExtensions> platform$clientInstaller;

    public static final MapCodec<ImpassableFieldBlock> CODEC = ImpassableFieldBlock.native$BlockCodecPlatform$simple(ImpassableFieldBlock::new);

    public ImpassableFieldBlock(BlockBehaviour.Properties properties) {
        this(properties, properties, true);
    }

    protected MapCodec<ImpassableFieldBlock> codec() {
        return CODEC;
    }

    @Override
    public RenderShape getRenderShape(BlockState state) {
        return RenderShape.INVISIBLE;
    }

    @Override
    public VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
        return Shapes.empty();
    }

    @Override
    public VoxelShape getCollisionShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
        return Shapes.block();
    }

    @Override
    public VoxelShape getOcclusionShape(BlockState state, BlockGetter level, BlockPos pos) {
        return Shapes.empty();
    }

    @Override
    public VoxelShape getBlockSupportShape(BlockState state, BlockGetter level, BlockPos pos) {
        return Shapes.empty();
    }

    @Override
    public boolean isPathfindable(BlockState state, net.minecraft.world.level.BlockGetter level, BlockPos pos, PathComputationType type) {
        /* BlockAiry#isPassable returned true even for metadata twelve. */
        return true;
    }

    @Override
    public boolean canEntityDestroy(BlockState state, BlockGetter level, BlockPos pos, Entity entity) {
        return false;
    }

    private ImpassableFieldBlock(net.minecraft.world.level.block.state.BlockBehaviour.Properties native$NativeBlock$arg0, BlockBehaviour.Properties properties, boolean native$NativeBlock$captured) {
        super(native$NativeBlock$arg0);
    }

    @Override
    public void initializeClient(java.util.function.Consumer<net.minecraftforge.client.extensions.common.IClientBlockExtensions> installer) {
        platform$clientInstaller = installer;
        super.initializeClient(installer);
    }

    @Override
    public void platform$clientExtension(Object extension) {
        java.util.Objects.requireNonNull(platform$clientInstaller, "Forge initializeClient must run before client extension registration").accept((net.minecraftforge.client.extensions.common.IClientBlockExtensions) extension);
    }

    @Override
    public InteractionResult use(BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
        ItemUseResult result = (switch(0) {
            default ->
                {
                    net.minecraft.world.item.ItemStack native$bodyOperand$4496 = player.getItemInHand(hand);
                    net.minecraft.world.level.block.state.BlockState native$bodyOperand$4497 = state;
                    net.minecraft.world.level.Level native$bodyOperand$4498 = level;
                    net.minecraft.core.BlockPos native$bodyOperand$4499 = pos;
                    net.minecraft.world.entity.player.Player native$bodyOperand$4500 = player;
                    net.minecraft.world.InteractionHand native$bodyOperand$4501 = hand;
                    net.minecraft.world.phys.BlockHitResult native$bodyOperand$4502 = hit;
                    dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult native$bodyResult$4503 = null;
                    native$bodyReturn$4504: {
                        if (true) {
                            {
                                native$bodyResult$4503 = dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
                                break native$bodyReturn$4504;
                            }
                        }
                    }
                    yield native$bodyResult$4503;
                }
        });
        return result == ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION ? (hand == InteractionHand.MAIN_HAND ? (switch(0) {
            default ->
                {
                    net.minecraft.world.level.block.state.BlockState native$bodyOperand$3714 = state;
                    net.minecraft.world.level.Level native$bodyOperand$3715 = level;
                    net.minecraft.core.BlockPos native$bodyOperand$3716 = pos;
                    net.minecraft.world.entity.player.Player native$bodyOperand$3717 = player;
                    net.minecraft.world.phys.BlockHitResult native$bodyOperand$3718 = hit;
                    net.minecraft.world.InteractionResult native$bodyResult$3719 = null;
                    native$bodyReturn$3720: {
                        if (true) {
                            {
                                native$bodyResult$3719 = super.use(native$bodyOperand$3714, native$bodyOperand$3715, native$bodyOperand$3716, native$bodyOperand$3717, net.minecraft.world.InteractionHand.MAIN_HAND, native$bodyOperand$3718);
                                break native$bodyReturn$3720;
                            }
                        }
                    }
                    yield native$bodyResult$3719;
                }
        }) : InteractionResult.PASS) : result.result();
    }

    protected ItemUseResult interactWithItem(ItemStack stack, BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
        return dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
    }

    protected InteractionResult interactWithoutItem(BlockState state, Level level, BlockPos pos, Player player, BlockHitResult hit) {
        return super.use(state, level, pos, player, net.minecraft.world.InteractionHand.MAIN_HAND, hit);
    }

    @Override
    public void playerWillDestroy(Level level, BlockPos pos, BlockState state, Player player) {
        {
            net.minecraft.world.level.Level native$bodyOperand$5871 = level;
            net.minecraft.core.BlockPos native$bodyOperand$5872 = pos;
            net.minecraft.world.level.block.state.BlockState native$bodyOperand$5873 = state;
            net.minecraft.world.entity.player.Player native$bodyOperand$5874 = player;
            net.minecraft.world.level.block.state.BlockState native$bodyResult$5875 = null;
            native$bodyReturn$5876: {
                if (true) {
                    super.playerWillDestroy(native$bodyOperand$5871, native$bodyOperand$5872, native$bodyOperand$5873, native$bodyOperand$5874);
                    {
                        native$bodyResult$5875 = native$bodyOperand$5873;
                        break native$bodyReturn$5876;
                    }
                }
            }
        }
    }

    public BlockState beforePlayerDestroy(Level level, BlockPos pos, BlockState state, Player player) {
        super.playerWillDestroy(level, pos, state, player);
        return state;
    }

    protected boolean survivesSharedExplosion() {
        return false;
    }

    public int getExpDrop(net.minecraft.world.level.block.state.BlockState native$callbackInput$1145, net.minecraft.world.level.LevelReader native$callbackInput$1146, net.minecraft.util.RandomSource native$callbackInput$1147, net.minecraft.core.BlockPos native$callbackInput$1148, int native$callbackInput$1149, int native$callbackInput$1150) {
        net.minecraft.world.level.block.state.BlockState state = native$callbackInput$1145;
        net.minecraft.util.RandomSource random = native$callbackInput$1147;
        return 0;
    }

    @Override
    public void onBlockExploded(BlockState state, Level level, BlockPos pos, Explosion explosion) {
        if (!(switch(0) {
            default ->
                {
                    boolean native$bodyResult$5277 = false;
                    native$bodyReturn$5278: {
                        if (true) {
                            {
                                native$bodyResult$5277 = false;
                                break native$bodyReturn$5278;
                            }
                        }
                    }
                    yield native$bodyResult$5277;
                }
        }))
            super.onBlockExploded(state, level, pos, explosion);
    }

    @Override
    public boolean canDropFromExplosion(BlockState state, BlockGetter level, BlockPos pos, Explosion explosion) {
        return !(switch(0) {
            default ->
                {
                    boolean native$bodyResult$4505 = false;
                    native$bodyReturn$4506: {
                        if (true) {
                            {
                                native$bodyResult$4505 = false;
                                break native$bodyReturn$4506;
                            }
                        }
                    }
                    yield native$bodyResult$4505;
                }
        }) && super.canDropFromExplosion(state, level, pos, explosion);
    }

    static private <B extends net.minecraft.world.level.block.Block> com.mojang.serialization.MapCodec<B> native$BlockCodecPlatform$simple(java.util.function.Function<net.minecraft.world.level.block.state.BlockBehaviour.Properties, B> factory) {
        // Vanilla 1.21's Properties codec is a unit codec. Retain that schema for shared block definitions.
        return com.mojang.serialization.codecs.RecordCodecBuilder.mapCodec(instance -> instance.group(com.mojang.serialization.Codec.unit(net.minecraft.world.level.block.state.BlockBehaviour.Properties::of).fieldOf("properties").forGetter((B block) -> net.minecraft.world.level.block.state.BlockBehaviour.Properties.copy(block))).apply(instance, factory));
    }
}
