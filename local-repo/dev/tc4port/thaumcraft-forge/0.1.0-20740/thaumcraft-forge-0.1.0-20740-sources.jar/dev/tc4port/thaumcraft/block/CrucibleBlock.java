package dev.tc4port.thaumcraft.block;

import dev.tc4port.thaumcraft.registry.TCSounds;
import dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult;
import com.mojang.serialization.MapCodec;
import dev.tc4port.thaumcraft.block.entity.CrucibleBlockEntity;
import dev.tc4port.thaumcraft.common.CompoundBlueprintCatalog;
import dev.tc4port.thaumcraft.common.WandInteractionTarget;
import dev.tc4port.thaumcraft.entity.SpecialItemEntity;
import dev.tc4port.thaumcraft.api.wand.WandCarrierItem;
import dev.tc4port.thaumcraft.registry.TCBlockEntities;
import javax.annotation.Nullable;
import net.minecraft.core.BlockPos;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityTicker;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.material.Fluids;
import net.minecraft.world.level.pathfinder.PathComputationType;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;
import dev.tc4port.thaumcraft.nativeimpl.ClientExtensionTarget;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.level.Explosion;

/**
 * TC4 crucible shell, interaction and collision behavior.
 */
public final class CrucibleBlock extends net.minecraft.world.level.block.BaseEntityBlock implements WandInteractionTarget, dev.tc4port.thaumcraft.nativeimpl.ClientExtensionTarget {

    // Forge calls initializeClient from the native superclass constructor. Do not add a field initializer.
    private java.util.function.Consumer<net.minecraftforge.client.extensions.common.IClientBlockExtensions> platform$clientInstaller;

    public static final MapCodec<CrucibleBlock> CODEC = CrucibleBlock.native$BlockCodecPlatform$simple(CrucibleBlock::new);

    private static final VoxelShape INSIDE = Block.box(2.0, 5.0, 2.0, 14.0, 16.0, 14.0);

    private static final VoxelShape SHAPE = Shapes.or(Block.box(0.0, 0.0, 0.0, 16.0, 5.0, 16.0), Block.box(0.0, 0.0, 0.0, 2.0, 13.6, 16.0), Block.box(14.0, 0.0, 0.0, 16.0, 13.6, 16.0), Block.box(2.0, 0.0, 0.0, 14.0, 13.6, 2.0), Block.box(2.0, 0.0, 14.0, 14.0, 13.6, 16.0));

    public CrucibleBlock(BlockBehaviour.Properties properties) {
        this(properties, properties, true);
    }

    protected MapCodec<CrucibleBlock> codec() {
        return CODEC;
    }

    @Override
    public float getShadeBrightness(BlockState state, BlockGetter level, BlockPos pos) {
        // Use the user-selected cauldron ambient brightness.
        return 0.2F;
    }

    @Nullable
    @Override
    public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        return new CrucibleBlockEntity(pos, state);
    }

    @Nullable
    @Override
    public <T extends BlockEntity> BlockEntityTicker<T> getTicker(Level level, BlockState state, BlockEntityType<T> type) {
        return createTickerHelper(type, TCBlockEntities.CRUCIBLE.get(), level.isClientSide ? CrucibleBlockEntity::clientTick : CrucibleBlockEntity::serverTick);
    }

    @Override
    public RenderShape getRenderShape(BlockState state) {
        return RenderShape.MODEL;
    }

    /**
     * TC4 wand trigger one: any vanilla cauldron water level is discarded and
     * the block becomes an empty crucible. The trigger has no research or vis
     * cost in the original registration.
     */
    public static net.minecraft.world.InteractionResult tryCreate(UseOnContext context) {
        if (!(context.getItemInHand().getItem() instanceof WandCarrierItem)) {
            return net.minecraft.world.InteractionResult.PASS;
        }
        Level level = context.getLevel();
        BlockPos pos = context.getClickedPos();
        BlockState state = level.getBlockState(pos);
        if (!CompoundBlueprintCatalog.isTrigger(CompoundBlueprintCatalog.CRUCIBLE, state)) {
            return net.minecraft.world.InteractionResult.PASS;
        }
        Block output = CompoundBlueprintCatalog.outputBlock(CompoundBlueprintCatalog.CRUCIBLE);
        if (output == null) {
            return net.minecraft.world.InteractionResult.PASS;
        }
        if (!level.isClientSide) {
            level.setBlock(pos, output.defaultBlockState(), Block.UPDATE_ALL);
            level.updateNeighborsAt(pos, output);
            level.blockEvent(pos, dev.tc4port.thaumcraft.registry.TCBlocks.CRUCIBLE.get(), 1, 1);
            level.playSound(null, pos, TCSounds.WAND.get(), SoundSource.BLOCKS, 1.0F, 1.0F);
        }
        if (context.getPlayer() != null) {
            context.getPlayer().swing(context.getHand());
        }
        return net.minecraft.world.InteractionResult.sidedSuccess(level.isClientSide);
    }

    @Override
    public VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
        // BlockMetalDevice metadata zero kept a full-cube selection box.
        return Shapes.block();
    }

    @Override
    public VoxelShape getCollisionShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
        return SHAPE;
    }

    @Override
    public VoxelShape getInteractionShape(BlockState state, BlockGetter level, BlockPos pos) {
        return Shapes.block();
    }

    protected ItemUseResult interactWithItem(ItemStack stack, BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hitResult) {
        if (!(level.getBlockEntity(pos) instanceof dev.tc4port.thaumcraft.block.entity.CrucibleBlockEntity crucible)) {
            return dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
        }
        if (stack.is(net.minecraft.world.item.Items.WATER_BUCKET)) {
            net.minecraftforge.fluids.FluidStack water = new net.minecraftforge.fluids.FluidStack(net.minecraft.world.level.material.Fluids.WATER, 1_000);
            int accepted = crucible.tank().fill(water, net.minecraftforge.fluids.capability.IFluidHandler.FluidAction.SIMULATE);
            if (!level.isClientSide && accepted > 0) {
                crucible.tank().fill(water, net.minecraftforge.fluids.capability.IFluidHandler.FluidAction.EXECUTE);
                /*
                 * BlockMetalDevice decremented the filled container
                 * directly, including in creative, then returned the empty
                 * container through the inventory.
                 */
                stack.shrink(1);
                net.minecraft.world.item.ItemStack empty = new net.minecraft.world.item.ItemStack(net.minecraft.world.item.Items.BUCKET);
                if (!player.addItem(empty)) {
                    player.drop(empty, false);
                }
                level.playSound(null, pos, dev.tc4port.thaumcraft.registry.TCSounds.CRUCIBLE_FILL.get(), net.minecraft.sounds.SoundSource.BLOCKS, 0.33F, 1.0F + (level.random.nextFloat() - level.random.nextFloat()) * 0.3F);
            }
            return dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.sidedSuccess(level.isClientSide);
        }
        if (stack.getItem() instanceof dev.tc4port.thaumcraft.api.wand.WandCarrierItem) {
            if (player.isShiftKeyDown() && !level.isClientSide) {
                crucible.spillRemnants();
            }
            /*
             * TileCrucible#onWandRightClick(World, stack, player) returned
             * the wand for both crouching and ordinary clicks. Crouching
             * additionally spilled the contents; an ordinary click was
             * still consumed before the installed focus could run. The
             * modern standing ward action runs earlier in WandItem; this
             * fallback retains machine use for other foci and secondary use.
             * Client success lets the native interaction swing the hand;
             * the server only consumes the action, without a second swing.
             */
            return dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.sidedSuccess(level.isClientSide);
        }
        return dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
    }

    @Override
    public void entityInside(BlockState state, Level level, BlockPos pos, Entity entity) {
        if (level.isClientSide || !(level.getBlockEntity(pos) instanceof CrucibleBlockEntity crucible) || !crucible.boiling() || !INSIDE.bounds().intersects(entity.getBoundingBox().move(-pos.getX(), -pos.getY(), -pos.getZ()))) {
            return;
        }
        if (entity instanceof ItemEntity itemEntity) {
            /*
             * BlockMetalDevice permanently excluded EntitySpecialItem. It was
             * not a short pickup-style grace period: crucible results must
             * never become catalysts again even if they remain over the pot.
             */
            if (!(itemEntity instanceof SpecialItemEntity)) {
                crucible.attemptSmelt(itemEntity);
            }
            return;
        }
        if (entity instanceof LivingEntity living && entity.tickCount % 10 == 0) {
            living.hurt(level.damageSources().inFire(), 1.0F);
            level.playSound(null, pos, TCSounds.CRUCIBLE_SCALD.get(), SoundSource.BLOCKS, 0.4F, 2.0F + level.random.nextFloat() * 0.4F);
        }
    }

    @Override
    public void neighborChanged(BlockState state, Level level, BlockPos pos, Block neighborBlock, BlockPos neighborPos, boolean movedByPiston) {
        super.neighborChanged(state, level, pos, neighborBlock, neighborPos, movedByPiston);
        if (level.getBlockEntity(pos) instanceof CrucibleBlockEntity crucible) {
            crucible.recountBellows();
        }
    }

    @Override
    public void onRemove(BlockState state, Level level, BlockPos pos, BlockState newState, boolean isMoving) {
        if (!state.is(newState.getBlock()) && level.getBlockEntity(pos) instanceof CrucibleBlockEntity crucible) {
            crucible.spillRemnants();
        }
        super.onRemove(state, level, pos, newState, isMoving);
    }

    @Override
    public boolean hasAnalogOutputSignal(BlockState state) {
        return true;
    }

    @Override
    public int getAnalogOutputSignal(BlockState state, Level level, BlockPos pos) {
        if (!(level.getBlockEntity(pos) instanceof CrucibleBlockEntity crucible)) {
            return 0;
        }
        int amount = crucible.totalAspects();
        return amount <= 0 ? 0 : Mth.floor(amount / 100.0F * 14.0F) + 1;
    }

    @Override
    public void animateTick(BlockState state, Level level, BlockPos pos, RandomSource random) {
        if (!(level.getBlockEntity(pos) instanceof CrucibleBlockEntity crucible) || crucible.water() <= 0) {
            return;
        }
        if (crucible.boiling() && random.nextInt(10) == 0) {
            level.playLocalSound(pos, TCSounds.CRUCIBLE_BOIL.get(), SoundSource.BLOCKS, 0.1F + random.nextFloat() * 0.1F, 1.2F + random.nextFloat() * 0.2F, false);
        }
    }

    @Override
    public boolean isPathfindable(BlockState state, BlockGetter level, BlockPos pos, PathComputationType pathType) {
        // Same as vanilla cauldrons: walk over the rim, not through it.
        return false;
    }

    private CrucibleBlock(net.minecraft.world.level.block.state.BlockBehaviour.Properties native$NativeEntityBlock$arg0, BlockBehaviour.Properties properties, boolean native$NativeEntityBlock$captured) {
        super(native$NativeEntityBlock$arg0);
    }

    @Override
    public void initializeClient(java.util.function.Consumer<net.minecraftforge.client.extensions.common.IClientBlockExtensions> installer) {
        platform$clientInstaller = installer;
        super.initializeClient(installer);
    }

    @Override
    public void platform$clientExtension(Object extension) {
        java.util.Objects.requireNonNull(platform$clientInstaller, "Forge initializeClient must run before client extension registration").accept((net.minecraftforge.client.extensions.common.IClientBlockExtensions) extension);
    }

    @Override
    public InteractionResult use(BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
        ItemUseResult result = (switch(0) {
            default ->
                {
                    net.minecraft.world.item.ItemStack native$bodyOperand$4273 = player.getItemInHand(hand);
                    net.minecraft.world.level.block.state.BlockState native$bodyOperand$4274 = state;
                    net.minecraft.world.level.Level native$bodyOperand$4275 = level;
                    net.minecraft.core.BlockPos native$bodyOperand$4276 = pos;
                    net.minecraft.world.entity.player.Player native$bodyOperand$4277 = player;
                    net.minecraft.world.InteractionHand native$bodyOperand$4278 = hand;
                    net.minecraft.world.phys.BlockHitResult native$bodyOperand$4279 = hit;
                    dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult native$bodyResult$4284 = null;
                    native$bodyReturn$4285: {
                        if (true) {
                            if (!(native$bodyOperand$4275.getBlockEntity(native$bodyOperand$4276) instanceof dev.tc4port.thaumcraft.block.entity.CrucibleBlockEntity native$bodyBinding$4280)) {
                                {
                                    native$bodyResult$4284 = dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
                                    break native$bodyReturn$4285;
                                }
                            }
                            if (native$bodyOperand$4273.is(net.minecraft.world.item.Items.WATER_BUCKET)) {
                                net.minecraftforge.fluids.FluidStack native$bodyBinding$4281 = new net.minecraftforge.fluids.FluidStack(net.minecraft.world.level.material.Fluids.WATER, 1_000);
                                int native$bodyBinding$4282 = native$bodyBinding$4280.tank().fill(native$bodyBinding$4281, net.minecraftforge.fluids.capability.IFluidHandler.FluidAction.SIMULATE);
                                if (!native$bodyOperand$4275.isClientSide && native$bodyBinding$4282 > 0) {
                                    native$bodyBinding$4280.tank().fill(native$bodyBinding$4281, net.minecraftforge.fluids.capability.IFluidHandler.FluidAction.EXECUTE);
                                    /*
                 * BlockMetalDevice decremented the filled container
                 * directly, including in creative, then returned the empty
                 * container through the inventory.
                 */
                                    native$bodyOperand$4273.shrink(1);
                                    net.minecraft.world.item.ItemStack native$bodyBinding$4283 = new net.minecraft.world.item.ItemStack(net.minecraft.world.item.Items.BUCKET);
                                    if (!native$bodyOperand$4277.addItem(native$bodyBinding$4283)) {
                                        native$bodyOperand$4277.drop(native$bodyBinding$4283, false);
                                    }
                                    native$bodyOperand$4275.playSound(null, native$bodyOperand$4276, dev.tc4port.thaumcraft.registry.TCSounds.CRUCIBLE_FILL.get(), net.minecraft.sounds.SoundSource.BLOCKS, 0.33F, 1.0F + (native$bodyOperand$4275.random.nextFloat() - native$bodyOperand$4275.random.nextFloat()) * 0.3F);
                                }
                                {
                                    native$bodyResult$4284 = dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.sidedSuccess(native$bodyOperand$4275.isClientSide);
                                    break native$bodyReturn$4285;
                                }
                            }
                            if (native$bodyOperand$4273.getItem() instanceof dev.tc4port.thaumcraft.api.wand.WandCarrierItem) {
                                if (native$bodyOperand$4277.isShiftKeyDown() && !native$bodyOperand$4275.isClientSide) {
                                    native$bodyBinding$4280.spillRemnants();
                                }
                                {
                                    native$bodyResult$4284 = dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.sidedSuccess(native$bodyOperand$4275.isClientSide);
                                    break native$bodyReturn$4285;
                                }
                            }
                            {
                                native$bodyResult$4284 = dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
                                break native$bodyReturn$4285;
                            }
                        }
                    }
                    yield native$bodyResult$4284;
                }
        });
        return result == ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION ? (hand == InteractionHand.MAIN_HAND ? (switch(0) {
            default ->
                {
                    net.minecraft.world.level.block.state.BlockState native$bodyOperand$3572 = state;
                    net.minecraft.world.level.Level native$bodyOperand$3573 = level;
                    net.minecraft.core.BlockPos native$bodyOperand$3574 = pos;
                    net.minecraft.world.entity.player.Player native$bodyOperand$3575 = player;
                    net.minecraft.world.phys.BlockHitResult native$bodyOperand$3576 = hit;
                    net.minecraft.world.InteractionResult native$bodyResult$3577 = null;
                    native$bodyReturn$3578: {
                        if (true) {
                            {
                                native$bodyResult$3577 = super.use(native$bodyOperand$3572, native$bodyOperand$3573, native$bodyOperand$3574, native$bodyOperand$3575, net.minecraft.world.InteractionHand.MAIN_HAND, native$bodyOperand$3576);
                                break native$bodyReturn$3578;
                            }
                        }
                    }
                    yield native$bodyResult$3577;
                }
        }) : InteractionResult.PASS) : result.result();
    }

    protected InteractionResult interactWithoutItem(BlockState state, Level level, BlockPos pos, Player player, BlockHitResult hit) {
        return super.use(state, level, pos, player, net.minecraft.world.InteractionHand.MAIN_HAND, hit);
    }

    @Override
    public void playerWillDestroy(Level level, BlockPos pos, BlockState state, Player player) {
        {
            net.minecraft.world.level.Level native$bodyOperand$5757 = level;
            net.minecraft.core.BlockPos native$bodyOperand$5758 = pos;
            net.minecraft.world.level.block.state.BlockState native$bodyOperand$5759 = state;
            net.minecraft.world.entity.player.Player native$bodyOperand$5760 = player;
            net.minecraft.world.level.block.state.BlockState native$bodyResult$5761 = null;
            native$bodyReturn$5762: {
                if (true) {
                    super.playerWillDestroy(native$bodyOperand$5757, native$bodyOperand$5758, native$bodyOperand$5759, native$bodyOperand$5760);
                    {
                        native$bodyResult$5761 = native$bodyOperand$5759;
                        break native$bodyReturn$5762;
                    }
                }
            }
        }
    }

    public BlockState beforePlayerDestroy(Level level, BlockPos pos, BlockState state, Player player) {
        super.playerWillDestroy(level, pos, state, player);
        return state;
    }

    protected boolean survivesSharedExplosion() {
        return false;
    }

    public int getExpDrop(net.minecraft.world.level.block.state.BlockState native$callbackInput$1050, net.minecraft.world.level.LevelReader native$callbackInput$1051, net.minecraft.util.RandomSource native$callbackInput$1052, net.minecraft.core.BlockPos native$callbackInput$1053, int native$callbackInput$1054, int native$callbackInput$1055) {
        net.minecraft.world.level.block.state.BlockState state = native$callbackInput$1050;
        net.minecraft.util.RandomSource random = native$callbackInput$1052;
        return 0;
    }

    @Override
    public void onBlockExploded(BlockState state, Level level, BlockPos pos, Explosion explosion) {
        if (!(switch(0) {
            default ->
                {
                    boolean native$bodyResult$5239 = false;
                    native$bodyReturn$5240: {
                        if (true) {
                            {
                                native$bodyResult$5239 = false;
                                break native$bodyReturn$5240;
                            }
                        }
                    }
                    yield native$bodyResult$5239;
                }
        }))
            super.onBlockExploded(state, level, pos, explosion);
    }

    @Override
    public boolean canDropFromExplosion(BlockState state, BlockGetter level, BlockPos pos, Explosion explosion) {
        return !(switch(0) {
            default ->
                {
                    boolean native$bodyResult$4286 = false;
                    native$bodyReturn$4287: {
                        if (true) {
                            {
                                native$bodyResult$4286 = false;
                                break native$bodyReturn$4287;
                            }
                        }
                    }
                    yield native$bodyResult$4286;
                }
        }) && super.canDropFromExplosion(state, level, pos, explosion);
    }

    static private <B extends net.minecraft.world.level.block.Block> com.mojang.serialization.MapCodec<B> native$BlockCodecPlatform$simple(java.util.function.Function<net.minecraft.world.level.block.state.BlockBehaviour.Properties, B> factory) {
        // Vanilla 1.21's Properties codec is a unit codec. Retain that schema for shared block definitions.
        return com.mojang.serialization.codecs.RecordCodecBuilder.mapCodec(instance -> instance.group(com.mojang.serialization.Codec.unit(net.minecraft.world.level.block.state.BlockBehaviour.Properties::of).fieldOf("properties").forGetter((B block) -> net.minecraft.world.level.block.state.BlockBehaviour.Properties.copy(block))).apply(instance, factory));
    }
}
