package dev.tc4port.thaumcraft.api.focus.action;

@FunctionalInterface
public interface FocusActionAuthorizer {

    /**
     * Runs once on the server thread after all pure simulations and before
     * any Vis debit. This phase may query or post a permission event, but must
     * not mutate the world, player, or supplied wand copy.
     */
    FocusAuthorization authorize(FocusAuthorizationContext context);
}
