package dev.tc4port.thaumcraft.block.entity;

import dev.tc4port.thaumcraft.block.ArcaneEarBlock;
import dev.tc4port.thaumcraft.common.ArcaneEarSystem;
import dev.tc4port.thaumcraft.registry.TCBlockEntities;
import net.minecraft.core.BlockPos;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import java.lang.Byte;
import java.lang.Math;
import dev.tc4port.thaumcraft.nativeimpl.state.ItemFields;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityType;

/**
 * Pitch, support instrument and ten-tick redstone pulse for the Arcane Ear.
 */
public final class ArcaneEarBlockEntity extends net.minecraft.world.level.block.entity.BlockEntity implements dev.tc4port.thaumcraft.api.machine.ArcaneEarView, ItemFields.Source {

    // Nominal defaults; runtime behavior reads configured accessors.
    public static final int PULSE_TICKS = 10;

    public static int configuredPulseTicks() {
        return dev.tc4port.thaumcraft.common.TCGameplayParameters.MACHINES_ARCANE_EAR_PULSE_TICKS.intValue();
    }

    private static final String NOTE_KEY = "note";

    private static final String TONE_KEY = "tone";

    private byte note;

    private byte tone;

    private int redstoneSignal;

    public ArcaneEarBlockEntity(BlockPos pos, BlockState state) {
        super(TCBlockEntities.ARCANE_EAR.get(), pos, state);
    }

    public static void serverTick(Level level, BlockPos pos, BlockState state, ArcaneEarBlockEntity ear) {
        if (ear.redstoneSignal <= 0) {
            return;
        }
        ear.redstoneSignal--;
        if (ear.redstoneSignal == 0) {
            ear.setActive(false);
        }
    }

    public int note() {
        return Byte.toUnsignedInt(this.note);
    }

    public int tone() {
        return Byte.toUnsignedInt(this.tone);
    }

    public int redstoneSignal() {
        return this.redstoneSignal;
    }

    public void updateTone() {
        if (this.level == null) {
            return;
        }
        this.tone = (byte) Math.max(0, ArcaneEarBlock.instrumentId(this.level.getBlockState(this.worldPosition.below()).instrument()));
        this.setChanged();
        ArcaneEarSystem.track(this);
    }

    public void changePitch() {
        this.setControlledNote((this.note() + 1) % 25);
    }

    /**
     * Internal owner hook used by the bounded public control service.
     */
    public void setControlledNote(int note) {
        if (note < 0 || note > 24) {
            throw new IllegalArgumentException("note must be 0..24");
        }
        this.note = (byte) note;
        this.setChanged();
        if (this.level != null && !this.level.isClientSide) {
            BlockState state = this.getBlockState();
            this.level.sendBlockUpdated(this.worldPosition, state, state, Block.UPDATE_CLIENTS);
        }
    }

    public boolean matches(int instrument, int candidateNote) {
        return instrument == this.tone() && candidateNote == this.note();
    }

    public void hearNote() {
        this.playTunedNote(false);
        this.redstoneSignal = configuredPulseTicks();
        this.setActive(true);
    }

    public void playTunedNote(boolean sound) {
        if (this.level == null || !this.level.getBlockState(this.worldPosition.above()).isAir()) {
            return;
        }
        int instrument = sound ? ArcaneEarBlock.instrumentId(this.level.getBlockState(this.worldPosition.below()).instrument()) : -1;
        this.level.blockEvent(this.worldPosition, this.getBlockState().getBlock(), Math.max(-1, instrument), this.note());
    }

    private void setActive(boolean active) {
        if (this.level == null) {
            return;
        }
        BlockState state = this.getBlockState();
        if (state.getValue(ArcaneEarBlock.ACTIVE) != active) {
            this.level.setBlock(this.worldPosition, state.setValue(ArcaneEarBlock.ACTIVE, active), Block.UPDATE_CLIENTS);
        }
        this.level.updateNeighborsAt(this.worldPosition, state.getBlock());
        this.level.updateNeighborsAt(this.worldPosition.below(), state.getBlock());
        this.setChanged();
    }

    @Override
    public void onLoad() {
        super.onLoad();
        ArcaneEarSystem.track(this);
    }

    @Override
    public void setRemoved() {
        ArcaneEarSystem.untrack(this);
        super.setRemoved();
    }

    @Override
    public void load(CompoundTag tag) {
        super.load(tag);
        this.note = (byte) dev.tc4port.thaumcraft.util.PortMath.clamp(tag.getByte(NOTE_KEY), 0, 24);
        this.tone = (byte) dev.tc4port.thaumcraft.util.PortMath.clamp(tag.getByte(TONE_KEY), 0, net.minecraft.world.level.block.state.properties.NoteBlockInstrument.PLING.ordinal());
        this.redstoneSignal = 0;
    }

    @Override
    protected void saveAdditional(CompoundTag tag) {
        super.saveAdditional(tag);
        tag.putByte(NOTE_KEY, this.note);
        tag.putByte(TONE_KEY, this.tone);
    }

    @Override
    public CompoundTag getUpdateTag() {
        return this.saveWithoutMetadata();
    }

    @Override
    public Packet<ClientGamePacketListener> getUpdatePacket() {
        return ClientboundBlockEntityDataPacket.create(this);
    }

    protected final HolderLookup.Provider persistenceRegistries() {
        if (level != null)
            return level.registryAccess();
        var server = net.minecraftforge.server.ServerLifecycleHooks.getCurrentServer();
        return server != null ? server.registryAccess() : net.minecraft.core.RegistryAccess.fromRegistryOfRegistries(net.minecraft.core.registries.BuiltInRegistries.REGISTRY);
    }

    protected static net.minecraft.network.chat.Component parseCustomNameSafe(String value, HolderLookup.Provider registries) {
        try {
            return net.minecraft.network.chat.Component.Serializer.fromJson(value);
        } catch (RuntimeException exception) {
            return null;
        }
    }

    protected void readItemFields(ItemFields.Input input) {
    }

    public void copyItemFields(ItemFields.Output output) {
    }

    public void applyComponentsFromItemStack(ItemStack stack) {
        readItemFields(ItemFields.from(stack));
    }

    public void removeComponentsFromTag(CompoundTag tag) {
    }

    @Override
    public void saveToItem(ItemStack stack) {
        CompoundTag tag = saveWithoutMetadata();
        {
            net.minecraft.nbt.CompoundTag native$bodyOperand$6099 = tag;
            native$bodyReturn$6101: {
                if (true) {
                }
            }
        }
        net.minecraft.world.item.BlockItem.setBlockEntityData(stack, getType(), tag);
        copyItemFields(ItemFields.to(stack));
    }

    @Override
    public net.minecraft.world.phys.AABB getRenderBoundingBox() {
        return ArcaneEarBlockEntity.native$ClientBlockEntityBounds$bounds(this);
    }

    @Override()
    public void onDataPacket(net.minecraft.network.Connection connection, net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket packet) {
        handleUpdateTag(packet.getTag());
    }

    @SuppressWarnings({ "rawtypes", "unchecked" })
    static private net.minecraft.world.phys.AABB native$ClientBlockEntityBounds$bounds(net.minecraft.world.level.block.entity.BlockEntity blockEntity) {
        var renderer = net.minecraft.client.Minecraft.getInstance().getBlockEntityRenderDispatcher().getRenderer(blockEntity);
        return renderer instanceof dev.tc4port.thaumcraft.nativeimpl.NativeBlockEntityRenderer shared ? shared.getRenderBoundingBox(blockEntity) : new net.minecraft.world.phys.AABB(blockEntity.getBlockPos());
    }
}
