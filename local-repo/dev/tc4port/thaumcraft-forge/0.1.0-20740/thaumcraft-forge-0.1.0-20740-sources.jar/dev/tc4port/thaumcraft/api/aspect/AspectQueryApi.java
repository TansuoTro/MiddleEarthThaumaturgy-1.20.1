package dev.tc4port.thaumcraft.api.aspect;

import dev.tc4port.thaumcraft.common.BlockAspectCatalog;
import dev.tc4port.thaumcraft.common.EntityAspectCatalog;
import dev.tc4port.thaumcraft.common.ObjectAspectResolver;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Objects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.state.BlockState;

/**
 * Unified read-only queries for effective object and entity aspects.
 */
public final class AspectQueryApi {

    /**
     * Per-unit aspects plus the number of units destroyed together.
     */
    public record Consumption(AspectAmounts perUnit, int units) {

        public Consumption {
            Objects.requireNonNull(perUnit, "perUnit");
            if (units < 0) {
                throw new IllegalArgumentException("Consumption units must be non-negative");
            }
        }
    }

    private AspectQueryApi() {
    }

    /**
     * Effective aspects of one logical item, independent of stack count.
     */
    public static AspectAmounts item(ItemStack stack) {
        Objects.requireNonNull(stack, "stack");
        if (stack.isEmpty()) {
            return AspectAmounts.EMPTY;
        }
        return new AspectAmounts(ObjectAspectResolver.resolve(stack.copyWithCount(1)));
    }

    /**
     * Effective aspects of every item in the supplied stack.
     */
    public static AspectAmounts stack(ItemStack stack) {
        Objects.requireNonNull(stack, "stack");
        if (stack.isEmpty()) {
            return AspectAmounts.EMPTY;
        }
        int count = stack.getCount();
        LinkedHashMap<AspectId, Integer> scaled = new LinkedHashMap<>();
        item(stack).amounts().forEach((aspect, amount) -> scaled.put(aspect, (int) Math.min(Integer.MAX_VALUE, (long) amount * count)));
        return new AspectAmounts(scaled);
    }

    /**
     * One placed block's item aspects plus its block-state-only aspects.
     */
    public static AspectAmounts placedBlock(ItemStack stack, BlockState state) {
        Objects.requireNonNull(stack, "stack");
        Objects.requireNonNull(state, "state");
        ItemStack single = stack.isEmpty() ? ItemStack.EMPTY : stack.copyWithCount(1);
        return new AspectAmounts(ObjectAspectResolver.resolvePlacedBlock(single, state));
    }

    /**
     * Effective scan aspects contributed by a block state alone.
     */
    public static AspectAmounts block(BlockState state) {
        Objects.requireNonNull(state, "state");
        Map<AspectId, Integer> resolved = BlockAspectCatalog.resolve(state);
        return resolved == null ? AspectAmounts.EMPTY : new AspectAmounts(resolved);
    }

    /**
     * Effective entity-catalog aspects, without object-scan dispatch.
     */
    public static AspectAmounts entity(Entity entity) {
        Objects.requireNonNull(entity, "entity");
        return new AspectAmounts(EntityAspectCatalog.resolve(entity));
    }

    /**
     * Effective thaumometer aspects. Object-scanned item entities identify
     * one logical item and therefore ignore their carried stack count.
     */
    public static AspectAmounts scanTarget(Entity entity) {
        Objects.requireNonNull(entity, "entity");
        if (entity instanceof ItemEntity itemEntity && EntityAspectCatalog.scansAsObject(entity)) {
            return item(itemEntity.getItem());
        }
        return entity(entity);
    }

    /**
     * Query units for an entity that will be destroyed in one operation.
     */
    public static Consumption consumption(Entity entity) {
        Objects.requireNonNull(entity, "entity");
        if (entity instanceof ItemEntity itemEntity && EntityAspectCatalog.scansAsObject(entity)) {
            return new Consumption(item(itemEntity.getItem()), itemEntity.getItem().getCount());
        }
        return new Consumption(entity(entity), 1);
    }
}
