package dev.tc4port.thaumcraft.api.gameplay;

import com.mojang.datafixers.util.Either;
import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.Map;

/**
 * A finite number or base + context coefficients, with explicit output bounds.
 */
public record GameplayNumber(double base, Map<String, Double> per, double min, double max) {

    private static final Codec<GameplayNumber> EXPRESSION = RecordCodecBuilder.create(instance -> instance.group(Codec.DOUBLE.fieldOf("base").forGetter(GameplayNumber::base), GameplayNumber.native$CodecValues$optionalField(Codec.unboundedMap(Codec.STRING, Codec.DOUBLE), "per", Map.of()).forGetter(GameplayNumber::per), GameplayNumber.native$CodecValues$optionalField(Codec.DOUBLE, "min", -1_000_000_000D).forGetter(GameplayNumber::min), GameplayNumber.native$CodecValues$optionalField(Codec.DOUBLE, "max", 1_000_000_000D).forGetter(GameplayNumber::max)).apply(instance, GameplayNumber::new));

    public static final Codec<GameplayNumber> CODEC = Codec.either(Codec.DOUBLE, EXPRESSION).xmap(value -> value.map(GameplayNumber::constant, v -> v), Either::right);

    public GameplayNumber {
        per = Map.copyOf(per);
        if (!Double.isFinite(base) || !Double.isFinite(min) || !Double.isFinite(max) || min > max || Math.abs(min) > 1_000_000_000 || Math.abs(max) > 1_000_000_000 || per.size() > 32 || per.values().stream().anyMatch(value -> !Double.isFinite(value))) {
            throw new IllegalArgumentException("Invalid gameplay number");
        }
    }

    public static Codec<GameplayNumber> boundedCodec(double min, double max) {
        return CODEC.flatXmap(value -> value.min() < min || value.max() > max ? com.mojang.serialization.DataResult.error(() -> "Number bounds must fit [" + min + ", " + max + "]") : com.mojang.serialization.DataResult.success(value), com.mojang.serialization.DataResult::success);
    }

    public static GameplayNumber constant(double value) {
        return new GameplayNumber(value, Map.of(), value, value);
    }

    public double value(GameplayContext context) {
        double result = base;
        for (var entry : per.entrySet()) result += entry.getValue() * context.value(entry.getKey());
        if (!Double.isFinite(result)) {
            java.math.BigDecimal exact = java.math.BigDecimal.valueOf(base);
            for (var entry : per.entrySet()) exact = exact.add(java.math.BigDecimal.valueOf(entry.getValue()).multiply(java.math.BigDecimal.valueOf(context.value(entry.getKey()))));
            return exact.max(java.math.BigDecimal.valueOf(min)).min(java.math.BigDecimal.valueOf(max)).doubleValue();
        }
        return Math.max(min, Math.min(max, result));
    }

    public static java.util.Set<String> requiredValues(GameplayNumber... numbers) {
        var result = new java.util.HashSet<String>();
        for (var number : numbers) result.addAll(number.per().keySet());
        return java.util.Set.copyOf(result);
    }

    public int integer(GameplayContext context) {
        return (int) value(context);
    }

    static private <A> com.mojang.serialization.MapCodec<A> native$CodecValues$optionalField(com.mojang.serialization.Codec<A> codec, java.lang.String name, A fallback) {
        return GameplayNumber.native$CodecValues$optionalField(codec, name).xmap(value -> value.orElse(fallback), value -> java.util.Objects.equals(value, fallback) ? java.util.Optional.empty() : java.util.Optional.of(value));
    }

    /**
     * Missing values are optional; present but invalid values must still fail.
     */
    static private <A> com.mojang.serialization.MapCodec<java.util.Optional<A>> native$CodecValues$optionalField(com.mojang.serialization.Codec<A> codec, java.lang.String name) {
        return new com.mojang.serialization.MapCodec<>() {

            @Override
            public <T> com.mojang.serialization.DataResult<java.util.Optional<A>> decode(com.mojang.serialization.DynamicOps<T> ops, com.mojang.serialization.MapLike<T> input) {
                T value = input.get(name);
                return value == null ? com.mojang.serialization.DataResult.success(java.util.Optional.empty()) : codec.parse(ops, value).map(java.util.Optional::of);
            }

            @Override
            public <T> com.mojang.serialization.RecordBuilder<T> encode(java.util.Optional<A> value, com.mojang.serialization.DynamicOps<T> ops, com.mojang.serialization.RecordBuilder<T> prefix) {
                return value.map(element -> prefix.add(name, codec.encodeStart(ops, element))).orElse(prefix);
            }

            @Override
            public <T> java.util.stream.Stream<T> keys(com.mojang.serialization.DynamicOps<T> ops) {
                return java.util.stream.Stream.of(ops.createString(name));
            }
        };
    }
}
