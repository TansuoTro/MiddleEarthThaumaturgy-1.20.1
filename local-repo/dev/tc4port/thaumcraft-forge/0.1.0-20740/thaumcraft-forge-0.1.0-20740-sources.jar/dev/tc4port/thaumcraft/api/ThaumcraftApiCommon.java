package dev.tc4port.thaumcraft.api;

import dev.tc4port.thaumcraft.common.CraftingWarpSystem;
import dev.tc4port.thaumcraft.common.BlockAspectCatalog;
import dev.tc4port.thaumcraft.common.EntityAspectCatalog;
import dev.tc4port.thaumcraft.common.InfusionCentralTransformationRegistry;
import dev.tc4port.thaumcraft.common.LootBagLoot;
import dev.tc4port.thaumcraft.common.ObjectAspectCatalog;
import dev.tc4port.thaumcraft.common.PortableHoleBlacklist;
import dev.tc4port.thaumcraft.common.ScanExtensionRegistry;
import dev.tc4port.thaumcraft.api.loot.LootBagTier;
import dev.tc4port.thaumcraft.api.entity.EntityNbtCondition;
import dev.tc4port.thaumcraft.api.entity.EntityScanIdentity;
import dev.tc4port.thaumcraft.api.recipe.InfusionCentralTransformation;
import dev.tc4port.thaumcraft.api.aspect.AspectAmounts;
import dev.tc4port.thaumcraft.data.AspectStackData;
import dev.tc4port.thaumcraft.api.research.ScanHandler;
import dev.tc4port.thaumcraft.item.TCTiers;
import dev.tc4port.thaumcraft.registry.TCEnchantments;
import java.util.List;
import java.util.Map;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.tags.TagKey;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Tier;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.level.block.Block;

/**
 * Supported 1.21 counterpart of TC4's aggregate public API.
 *
 * <p>Numeric metadata and ore-dictionary identities become stacks and tags;
 * numeric enchantment ids become registry keys; data-pack recipes remain
 * authoritative. Runtime extensions below are wired into the same gameplay
 * catalogs used by scanning, crafting warp, the infernal furnace, portable
 * holes and loot bags rather than being passive compatibility collections.</p>
 */
public abstract class ThaumcraftApiCommon {

    /**
     * Largest supported infusion instability. At this value every legacy
     * 0..499 altar roll already selects an instability event.
     */
    public static final int MAX_INFUSION_INSTABILITY = 499;

    /**
     * Maximum peripheral ingredients in one infusion recipe. The matrix can
     * discover one pedestal in each of the 17 by 17 columns around its center.
     */
    public static final int MAX_INFUSION_COMPONENTS = 288;

    public static final Tier TOOL_MATERIAL_THAUMIUM = TCTiers.THAUMIUM;

    public static final Tier TOOL_MATERIAL_VOID = TCTiers.VOID;

    public static final Tier TOOL_MATERIAL_ELEMENTAL = TCTiers.ELEMENTAL;

    public static final ResourceKey<Enchantment> ENCHANTMENT_HASTE = TCEnchantments.HASTE;

    public static final ResourceKey<Enchantment> ENCHANTMENT_REPAIR = TCEnchantments.REPAIR;

    /**
     * Stable modern wand-part extension surface. Addons attach their items
     * to one category tag and provide a value in the corresponding synced
     * data map; no Java callback is required.
     */
    /**
     * Synced item abilities used by revealing, vis-discount, runic-shield,
     * hover-fuel and fall-reduction systems.
     */
    /**
     * Synced item-to-source-color mapping used by Vis Relay tuning.
     */
    protected ThaumcraftApiCommon() {
    }

    /**
     * Registers a scan extension handler with a removable lifetime.
     */
    public static Registration registerScanHandler(ScanHandler handler) {
        if (handler == null) {
            throw new IllegalArgumentException("Scan handler is null");
        }
        return registration(ScanExtensionRegistry.register(handler));
    }

    /**
     * Registers a named entity-aspect rule. More NBT conditions make a rule
     * more specific; equal-specificity rules use lexicographic rule ID order.
     * The scan identity is the exact hash base and entity-clue identity
     * contributed by this rule.
     */
    public static Registration registerEntityAspects(ResourceLocation ruleId, EntityType<?> type, EntityScanIdentity scanIdentity, AspectAmounts aspects, EntityNbtCondition... conditions) {
        return registration(EntityAspectCatalog.registerRuntime(ruleId, type, scanIdentity, aspects.amounts(), conditions));
    }

    /**
     * Registers an addon ItemEntity type whose thaumometer identity and
     * aspects come from its carried ItemStack. The registration conflicts
     * with entity-aspect and typed scan-hash rules for the same entity type.
     */
    public static <T extends ItemEntity> Registration registerObjectScannedEntityType(EntityType<T> type) {
        return registration(EntityAspectCatalog.registerObjectScanType(type));
    }

    /**
     * Returns whether the stack has an object-aspect definition, even empty.
     */
    public static boolean hasObjectAspectDefinition(ItemStack stack) {
        return ObjectAspectCatalog.hasRegistration(stack);
    }

    /**
     * Registers aspects for one current item identity.
     */
    public static Registration registerObjectAspects(Item item, AspectAmounts aspects) {
        return registerObjectAspects(item, aspects, ObjectAspectPhase.AFTER_INFERENCE);
    }

    /**
     * Registers a replacement at the selected catalog-construction phase.
     */
    public static Registration registerObjectAspects(Item item, AspectAmounts aspects, ObjectAspectPhase phase) {
        return registration(ObjectAspectCatalog.registerRuntime(item, aspects.amounts(), java.util.Objects.requireNonNull(phase, "phase")));
    }

    /**
     * Adds to the current effective item aspects, including after reloads.
     */
    public static Registration registerAdditionalObjectAspects(Item item, AspectAmounts aspects) {
        return registerAdditionalObjectAspects(item, aspects, ObjectAspectPhase.AFTER_INFERENCE);
    }

    /**
     * Adds aspects at the selected catalog-construction phase.
     */
    public static Registration registerAdditionalObjectAspects(Item item, AspectAmounts aspects, ObjectAspectPhase phase) {
        return registration(ObjectAspectCatalog.registerRuntimeAddition(item, java.util.Objects.requireNonNull(aspects, "aspects").amounts(), java.util.Objects.requireNonNull(phase, "phase")));
    }

    /**
     * Cache generation for item-aspect reloads and live registrations.
     */
    public static long objectAspectGeneration() {
        return ObjectAspectCatalog.generation();
    }

    /**
     * Adds aspects after the effective Block Data Map and runtime tag
     * overlays. Multiple live registrations add; closing restores the exact
     * preceding sum.
     */
    public static Registration registerBlockAspects(Block block, AspectAmounts aspects) {
        return registration(BlockAspectCatalog.register(block, aspects));
    }

    /**
     * Adds aspects to matching blocks before exact runtime block overlays.
     */
    public static Registration registerBlockAspects(TagKey<Block> tag, AspectAmounts aspects) {
        return registration(BlockAspectCatalog.register(tag, aspects));
    }

    /**
     * Cache generation for live block-aspect registrations.
     */
    public static long blockAspectGeneration() {
        return BlockAspectCatalog.generation();
    }

    /**
     * Registers aspects for every item in a Minecraft item tag.
     */
    public static Registration registerObjectAspects(TagKey<Item> tag, AspectAmounts aspects) {
        return registerObjectAspects(tag, aspects, ObjectAspectPhase.AFTER_INFERENCE);
    }

    /**
     * Registers a replacement for every matching item at the selected phase.
     */
    public static Registration registerObjectAspects(TagKey<Item> tag, AspectAmounts aspects, ObjectAspectPhase phase) {
        return registration(ObjectAspectCatalog.registerRuntime(tag, aspects.amounts(), java.util.Objects.requireNonNull(phase, "phase")));
    }

    /**
     * Adds aspects for every matching item at the selected phase.
     */
    public static Registration registerAdditionalObjectAspects(TagKey<Item> tag, AspectAmounts aspects) {
        return registerAdditionalObjectAspects(tag, aspects, ObjectAspectPhase.AFTER_INFERENCE);
    }

    /**
     * Adds aspects for every matching item at the selected phase.
     */
    public static Registration registerAdditionalObjectAspects(TagKey<Item> tag, AspectAmounts aspects, ObjectAspectPhase phase) {
        return registration(ObjectAspectCatalog.registerRuntimeAddition(tag, java.util.Objects.requireNonNull(aspects, "aspects").amounts(), java.util.Objects.requireNonNull(phase, "phase")));
    }

    /**
     * Registers one stable scan identity without changing object aspects.
     */
    public static Registration registerObjectScanGroup(ResourceLocation groupId, List<Item> members) {
        return registration(ObjectAspectCatalog.registerRuntimeScanGroup(groupId, members));
    }

    /**
     * Registers crafting warp for one current item identity.
     */
    public static Registration registerItemWarp(Item output, int amount) {
        return registration(CraftingWarpSystem.register(output, amount));
    }

    public static int getWarp(ItemStack stack) {
        return CraftingWarpSystem.warpFor(stack);
    }

    /**
     * Includes data tags, server configuration and runtime registrations.
     */
    public static boolean isPortableHoleBlacklisted(net.minecraft.world.level.block.state.BlockState state) {
        return PortableHoleBlacklist.contains(java.util.Objects.requireNonNull(state, "state"));
    }

    /**
     * Whether the active server configuration permits mirror gameplay.
     */
    public static boolean areMirrorsEnabled() {
        return dev.tc4port.thaumcraft.common.TCServerConfig.allowMirrors();
    }

    public static Registration registerPortableHoleBlacklist(Block... blocks) {
        return registration(PortableHoleBlacklist.register(blocks));
    }

    /**
     * Registers one stable-id loot-bag entry and returns its lifetime handle.
     * Native loot tables are preferred for static entries. Changes take effect
     * on the next server data-pack reload, including closing the handle.
     */
    public static Registration registerLootBagItem(ResourceLocation id, ItemStack item, int weight, LootBagTier... tiers) {
        return registration(LootBagLoot.register(id, item, weight, lootBagTiers(tiers)));
    }

    /**
     * Registers one deterministic addon-owned central-stack transformation.
     * The returned lifetime must outlive every recipe referring to the id.
     */
    public static Registration registerInfusionCentralTransformation(ResourceLocation id, InfusionCentralTransformation transformation) {
        return Registration.of(InfusionCentralTransformationRegistry.register(id, transformation));
    }

    /**
     * Registers one addon-owned peripheral component operation, selected by a
     * recipe's {@code component_transformation} operation id. The returned
     * lifetime must outlive every recipe referring to the id.
     */
    public static Registration registerInfusionComponentTransformation(ResourceLocation id, dev.tc4port.thaumcraft.api.recipe.InfusionComponentTransformation transformation) {
        return Registration.of(dev.tc4port.thaumcraft.common.InfusionComponentTransformationRegistry.register(id, transformation));
    }

    /**
     * Registers one deterministic addon-owned infusion enchantment cost hook,
     * selected by a recipe's {@code cost_transformation} id. The returned
     * lifetime must outlive every recipe referring to the id.
     */
    public static Registration registerInfusionEnchantmentCostTransformation(ResourceLocation id, dev.tc4port.thaumcraft.api.recipe.InfusionEnchantmentCostTransformation transformation) {
        return Registration.of(dev.tc4port.thaumcraft.common.InfusionEnchantmentCostTransformationRegistry.register(id, transformation));
    }

    private static LootBagLoot.Tier[] lootBagTiers(LootBagTier... tiers) {
        if (tiers == null || tiers.length == 0) {
            return new LootBagLoot.Tier[] { LootBagLoot.Tier.COMMON };
        }
        LootBagLoot.Tier[] mapped = new LootBagLoot.Tier[tiers.length];
        for (int index = 0; index < tiers.length; index++) {
            mapped[index] = switch(java.util.Objects.requireNonNull(tiers[index], "loot bag tier")) {
                case COMMON ->
                    LootBagLoot.Tier.COMMON;
                case UNCOMMON ->
                    LootBagLoot.Tier.UNCOMMON;
                case RARE ->
                    LootBagLoot.Tier.RARE;
            };
        }
        return mapped;
    }

    private static AspectStackData stackData(AspectAmounts amounts) {
        if (amounts == null) {
            throw new IllegalArgumentException("Aspect amounts are null");
        }
        return new AspectStackData(amounts.amounts());
    }

    private static Registration registration(Runnable remover) {
        return Registration.of(remover);
    }
}
