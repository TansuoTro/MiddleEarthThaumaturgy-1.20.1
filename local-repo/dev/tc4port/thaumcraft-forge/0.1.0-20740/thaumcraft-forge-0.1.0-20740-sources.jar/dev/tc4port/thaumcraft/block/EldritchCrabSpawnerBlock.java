package dev.tc4port.thaumcraft.block;

import com.mojang.serialization.MapCodec;
import dev.tc4port.thaumcraft.block.entity.EldritchCrabSpawnerBlockEntity;
import dev.tc4port.thaumcraft.registry.TCBlockEntities;
import javax.annotation.Nullable;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityTicker;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import dev.tc4port.thaumcraft.nativeimpl.ClientExtensionTarget;
import dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.level.pathfinder.PathComputationType;
import net.minecraft.world.phys.HitResult;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.Explosion;
import net.minecraft.world.level.BlockGetter;

/**
 * The otherwise full-cube BlockEldritch metadata-9 crab vent.
 */
public final class EldritchCrabSpawnerBlock extends net.minecraft.world.level.block.BaseEntityBlock implements dev.tc4port.thaumcraft.nativeimpl.ClientExtensionTarget {

    // Forge calls initializeClient from the native superclass constructor. Do not add a field initializer.
    private java.util.function.Consumer<net.minecraftforge.client.extensions.common.IClientBlockExtensions> platform$clientInstaller;

    public static final MapCodec<EldritchCrabSpawnerBlock> CODEC = EldritchCrabSpawnerBlock.native$BlockCodecPlatform$simple(EldritchCrabSpawnerBlock::new);

    public EldritchCrabSpawnerBlock(BlockBehaviour.Properties properties) {
        this(properties, properties, true);
    }

    protected MapCodec<EldritchCrabSpawnerBlock> codec() {
        return CODEC;
    }

    @Nullable
    @Override
    public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        return new EldritchCrabSpawnerBlockEntity(pos, state);
    }

    @Nullable
    @Override
    public <T extends BlockEntity> BlockEntityTicker<T> getTicker(Level level, BlockState state, BlockEntityType<T> type) {
        return level.isClientSide ? createTickerHelper(type, TCBlockEntities.ELDRITCH_CRAB_SPAWNER.get(), EldritchCrabSpawnerBlockEntity::clientTick) : createTickerHelper(type, TCBlockEntities.ELDRITCH_CRAB_SPAWNER.get(), EldritchCrabSpawnerBlockEntity::serverTick);
    }

    @Override
    public RenderShape getRenderShape(BlockState state) {
        return RenderShape.MODEL;
    }

    @Override
    public boolean triggerEvent(BlockState state, Level level, BlockPos pos, int id, int parameter) {
        if (level.getBlockEntity(pos) instanceof EldritchCrabSpawnerBlockEntity spawner && spawner.triggerEvent(id, parameter)) {
            return true;
        }
        return super.triggerEvent(state, level, pos, id, parameter);
    }

    public int getExpDrop(net.minecraft.world.level.block.state.BlockState native$callbackInput$1056, net.minecraft.world.level.LevelReader native$callbackInput$1057, net.minecraft.util.RandomSource native$callbackInput$1058, net.minecraft.core.BlockPos native$callbackInput$1059, int native$callbackInput$1060, int native$callbackInput$1061) {
        net.minecraft.world.level.block.state.BlockState state = native$callbackInput$1056;
        net.minecraft.util.RandomSource random = native$callbackInput$1058;
        return 6 + random.nextInt(5);
    }

    private EldritchCrabSpawnerBlock(net.minecraft.world.level.block.state.BlockBehaviour.Properties native$NativeEntityBlock$arg0, BlockBehaviour.Properties properties, boolean native$NativeEntityBlock$captured) {
        super(native$NativeEntityBlock$arg0);
    }

    @Override
    public void initializeClient(java.util.function.Consumer<net.minecraftforge.client.extensions.common.IClientBlockExtensions> installer) {
        platform$clientInstaller = installer;
        super.initializeClient(installer);
    }

    @Override
    public void platform$clientExtension(Object extension) {
        java.util.Objects.requireNonNull(platform$clientInstaller, "Forge initializeClient must run before client extension registration").accept((net.minecraftforge.client.extensions.common.IClientBlockExtensions) extension);
    }

    @Override
    public InteractionResult use(BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
        ItemUseResult result = (switch(0) {
            default ->
                {
                    net.minecraft.world.item.ItemStack native$bodyOperand$4321 = player.getItemInHand(hand);
                    net.minecraft.world.level.block.state.BlockState native$bodyOperand$4322 = state;
                    net.minecraft.world.level.Level native$bodyOperand$4323 = level;
                    net.minecraft.core.BlockPos native$bodyOperand$4324 = pos;
                    net.minecraft.world.entity.player.Player native$bodyOperand$4325 = player;
                    net.minecraft.world.InteractionHand native$bodyOperand$4326 = hand;
                    net.minecraft.world.phys.BlockHitResult native$bodyOperand$4327 = hit;
                    dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult native$bodyResult$4328 = null;
                    native$bodyReturn$4329: {
                        if (true) {
                            {
                                native$bodyResult$4328 = dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
                                break native$bodyReturn$4329;
                            }
                        }
                    }
                    yield native$bodyResult$4328;
                }
        });
        return result == ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION ? (hand == InteractionHand.MAIN_HAND ? (switch(0) {
            default ->
                {
                    net.minecraft.world.level.block.state.BlockState native$bodyOperand$3603 = state;
                    net.minecraft.world.level.Level native$bodyOperand$3604 = level;
                    net.minecraft.core.BlockPos native$bodyOperand$3605 = pos;
                    net.minecraft.world.entity.player.Player native$bodyOperand$3606 = player;
                    net.minecraft.world.phys.BlockHitResult native$bodyOperand$3607 = hit;
                    net.minecraft.world.InteractionResult native$bodyResult$3608 = null;
                    native$bodyReturn$3609: {
                        if (true) {
                            {
                                native$bodyResult$3608 = super.use(native$bodyOperand$3603, native$bodyOperand$3604, native$bodyOperand$3605, native$bodyOperand$3606, net.minecraft.world.InteractionHand.MAIN_HAND, native$bodyOperand$3607);
                                break native$bodyReturn$3609;
                            }
                        }
                    }
                    yield native$bodyResult$3608;
                }
        }) : InteractionResult.PASS) : result.result();
    }

    protected ItemUseResult interactWithItem(ItemStack stack, BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
        return dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
    }

    protected InteractionResult interactWithoutItem(BlockState state, Level level, BlockPos pos, Player player, BlockHitResult hit) {
        return super.use(state, level, pos, player, net.minecraft.world.InteractionHand.MAIN_HAND, hit);
    }

    @Override
    public void playerWillDestroy(Level level, BlockPos pos, BlockState state, Player player) {
        {
            net.minecraft.world.level.Level native$bodyOperand$5781 = level;
            net.minecraft.core.BlockPos native$bodyOperand$5782 = pos;
            net.minecraft.world.level.block.state.BlockState native$bodyOperand$5783 = state;
            net.minecraft.world.entity.player.Player native$bodyOperand$5784 = player;
            net.minecraft.world.level.block.state.BlockState native$bodyResult$5785 = null;
            native$bodyReturn$5786: {
                if (true) {
                    super.playerWillDestroy(native$bodyOperand$5781, native$bodyOperand$5782, native$bodyOperand$5783, native$bodyOperand$5784);
                    {
                        native$bodyResult$5785 = native$bodyOperand$5783;
                        break native$bodyReturn$5786;
                    }
                }
            }
        }
    }

    public BlockState beforePlayerDestroy(Level level, BlockPos pos, BlockState state, Player player) {
        super.playerWillDestroy(level, pos, state, player);
        return state;
    }

    protected boolean survivesSharedExplosion() {
        return false;
    }

    @Override
    public void onBlockExploded(BlockState state, Level level, BlockPos pos, Explosion explosion) {
        if (!(switch(0) {
            default ->
                {
                    boolean native$bodyResult$5247 = false;
                    native$bodyReturn$5248: {
                        if (true) {
                            {
                                native$bodyResult$5247 = false;
                                break native$bodyReturn$5248;
                            }
                        }
                    }
                    yield native$bodyResult$5247;
                }
        }))
            super.onBlockExploded(state, level, pos, explosion);
    }

    @Override
    public boolean canDropFromExplosion(BlockState state, BlockGetter level, BlockPos pos, Explosion explosion) {
        return !(switch(0) {
            default ->
                {
                    boolean native$bodyResult$4330 = false;
                    native$bodyReturn$4331: {
                        if (true) {
                            {
                                native$bodyResult$4330 = false;
                                break native$bodyReturn$4331;
                            }
                        }
                    }
                    yield native$bodyResult$4330;
                }
        }) && super.canDropFromExplosion(state, level, pos, explosion);
    }

    static private <B extends net.minecraft.world.level.block.Block> com.mojang.serialization.MapCodec<B> native$BlockCodecPlatform$simple(java.util.function.Function<net.minecraft.world.level.block.state.BlockBehaviour.Properties, B> factory) {
        // Vanilla 1.21's Properties codec is a unit codec. Retain that schema for shared block definitions.
        return com.mojang.serialization.codecs.RecordCodecBuilder.mapCodec(instance -> instance.group(com.mojang.serialization.Codec.unit(net.minecraft.world.level.block.state.BlockBehaviour.Properties::of).fieldOf("properties").forGetter((B block) -> net.minecraft.world.level.block.state.BlockBehaviour.Properties.copy(block))).apply(instance, factory));
    }
}
