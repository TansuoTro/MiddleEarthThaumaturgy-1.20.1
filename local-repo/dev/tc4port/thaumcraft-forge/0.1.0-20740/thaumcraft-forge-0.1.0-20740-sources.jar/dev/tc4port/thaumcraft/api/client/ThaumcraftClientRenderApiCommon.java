package dev.tc4port.thaumcraft.api.client;

import dev.tc4port.thaumcraft.api.client.WorldRenderContext;
import com.mojang.blaze3d.vertex.PoseStack;
import dev.tc4port.thaumcraft.client.ContinuousFocusOrigin;
import dev.tc4port.thaumcraft.client.ExcavationBeamEffect;
import dev.tc4port.thaumcraft.api.client.HeldItemRenderContext;
import dev.tc4port.thaumcraft.client.TCWorldOverlayRenderState;
import dev.tc4port.thaumcraft.client.GogglesAspectView;
import dev.tc4port.thaumcraft.client.GogglesClientEvents;
import dev.tc4port.thaumcraft.client.TCClientRenderTypes;
import dev.tc4port.thaumcraft.client.WandItemRenderer;
import java.util.Objects;
import javax.annotation.Nullable;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.Vec3;
import org.joml.Matrix4f;

/**
 * Stable client-only access to reusable Thaumcraft rendering primitives.
 */
public class ThaumcraftClientRenderApiCommon {

    private static final ResourceLocation PARTICLE_ATLAS = ResourceLocation.tryParse("minecraft:textures/atlas/particles.png");

    protected ThaumcraftClientRenderApiCommon() {
    }

    /**
     * Selected sequence texture and frame content bounds, excluding sampling padding.
     */
    public record EffectFrame(ResourceLocation texture, float u0, float u1, float v0, float v1) {
    }

    public static EffectFrame effectFrame(EffectSequence sequence, int frame) {
        return effectFrame(sequence, frame, 0, 1, 0, 1);
    }

    /**
     * Crops and mirrors use fractions within one frame on its guarded sequence sheet.
     */
    public static EffectFrame effectFrame(EffectSequence sequence, int frame, float u0, float u1, float v0, float v1) {
        Objects.requireNonNull(sequence);
        if (!Float.isFinite(u0) || !Float.isFinite(u1) || !Float.isFinite(v0) || !Float.isFinite(v1)) {
            throw new IllegalArgumentException("Expected finite frame coordinates");
        }
        return new EffectFrame(sequence.texture(frame), sequence.u(frame, u0), sequence.u(frame, u1), sequence.v(frame, v0), sequence.v(frame, v1));
    }

    /**
     * Available after client provider registration; the set is rebound by Minecraft on reload.
     */
    public static net.minecraft.client.particle.SpriteSet particleSprites(ThaumcraftParticle particle) {
        return dev.tc4port.thaumcraft.client.ParticleSprites.get(Objects.requireNonNull(particle));
    }

    /**
     * Content bounds of a current TC SpriteSet sprite in Minecraft's stitched particle atlas.
     */
    public static EffectFrame particleFrame(net.minecraft.client.renderer.texture.TextureAtlasSprite sprite) {
        return particleFrame(sprite, 0, 1, 0, 1);
    }

    /**
     * Crops or mirrors within one TC particle frame while excluding its two-pixel padding.
     */
    public static EffectFrame particleFrame(net.minecraft.client.renderer.texture.TextureAtlasSprite sprite, float u0, float u1, float v0, float v1) {
        Objects.requireNonNull(sprite);
        if (!Float.isFinite(u0) || !Float.isFinite(u1) || !Float.isFinite(v0) || !Float.isFinite(v1)) {
            throw new IllegalArgumentException("Expected finite frame coordinates");
        }
        return new EffectFrame(PARTICLE_ATLAS, dev.tc4port.thaumcraft.client.ParticleSprites.u(sprite, u0), dev.tc4port.thaumcraft.client.ParticleSprites.u(sprite, u1), dev.tc4port.thaumcraft.client.ParticleSprites.v(sprite, v0), dev.tc4port.thaumcraft.client.ParticleSprites.v(sprite, v1));
    }

    /**
     * The user's configured placement of Thaumcraft's focus dial.
     */
    public static boolean isFocusDialAtBottom() {
        return dev.tc4port.thaumcraft.common.TCClientConfig.dialBottom();
    }

    /**
     * Draws one 16x16 aspect icon with the core's existing blend behavior.
     */
    public static void drawAspect(net.minecraft.client.gui.GuiGraphics graphics, dev.tc4port.thaumcraft.api.aspect.AspectId aspect, int x, int y, float alpha) {
        dev.tc4port.thaumcraft.client.AspectGuiRender.blit(graphics, aspect, x, y, alpha);
    }

    /**
     * Linear-filtered, additive, full-bright billboard with no depth write.
     */
    public static RenderType legacyLinearAdditiveBillboard(ResourceLocation texture) {
        return TCClientRenderTypes.additiveTranslucentEmissiveBlurred(Objects.requireNonNull(texture, "texture"));
    }

    /**
     * Linear-filtered, ordinary-alpha, full-bright billboard; depth-tested only.
     */
    public static RenderType legacyLinearTranslucentBillboard(ResourceLocation texture) {
        return TCClientRenderTypes.normalTranslucentEmissiveDepthTestBlurred(Objects.requireNonNull(texture, "texture"));
    }

    /**
     * Linear-filtered ordinary-alpha billboard retaining source depth writes.
     */
    public static RenderType legacyLinearTranslucentDepthWriteBillboard(ResourceLocation texture) {
        return TCClientRenderTypes.normalTranslucentBillboardDepthWriteBlurred(Objects.requireNonNull(texture, "texture"));
    }

    /**
     * Creates the complete eldritch-orb renderer for an addon projectile.
     * Spikes share the core's pre-translucent pass; the animated, depth-writing
     * core is a ParticleEngine particle. Position, age and lifetime follow the entity.
     */
    public static <T extends net.minecraft.world.entity.Entity> net.minecraft.client.renderer.entity.EntityRenderer<T> createEldritchOrbRenderer(net.minecraft.client.renderer.entity.EntityRendererProvider.Context context) {
        return new dev.tc4port.thaumcraft.client.EldritchOrbRenderer<>(context);
    }

    /**
     * TC4's triangle-mode, additive, color-only eldritch-orb ray pass.
     */
    public static RenderType eldritchOrbRays() {
        return TCClientRenderTypes.eldritchOrbRays();
    }

    /**
     * The goggles aspect-icon layer: ordinary-alpha, full-bright billboard
     * drawn without depth testing, so it shows through blocks.
     */
    public static RenderType gogglesAspectBillboard(ResourceLocation texture) {
        return TCClientRenderTypes.normalTranslucentEmissiveNoDepthBillboard(Objects.requireNonNull(texture, "texture"));
    }

    /**
     * Draws one goggles aspect icon and its amount exactly as the core
     * overlay does, centred on the current pose as a unit quad. The caller
     * supplies the overlay transform (position, camera-facing yaw, the
     * 180-degree Z flip and scale). A negative amount hides the number;
     * {@code known = false} draws the unknown-aspect glyph. When
     * {@code buffers} is a {@code BufferSource}, the icon layer and both
     * amount passes are flushed immediately to keep the digits above the icon.
     */
    public static void renderGogglesAspect(PoseStack poseStack, MultiBufferSource buffers, dev.tc4port.thaumcraft.api.aspect.AspectId aspect, int amount, boolean known) {
        GogglesClientEvents.renderAspect(Objects.requireNonNull(poseStack, "poseStack"), Objects.requireNonNull(buffers, "buffers"), new GogglesAspectView.Entry(Objects.requireNonNull(aspect, "aspect"), amount), known);
    }

    /**
     * Draws only the goggles amount text (shadow then foreground) in the
     * core position relative to a unit aspect icon on the current pose.
     * Flushes the last batch after each pass when given a {@code BufferSource}.
     */
    public static void renderGogglesAmount(PoseStack poseStack, MultiBufferSource buffers, String amount) {
        GogglesClientEvents.renderAmount(Objects.requireNonNull(poseStack, "poseStack"), Objects.requireNonNull(buffers, "buffers"), Objects.requireNonNull(amount, "amount"));
    }

    /**
     * Returns the entity whose held-item renderer is currently invoking a
     * custom item renderer, or {@code null} outside that nested render.
     *
     * <p>NeoForge's {@code BlockEntityWithoutLevelRenderer} callback omits
     * the holder even though source renderers commonly selected crouching,
     * species or equipment transforms from it. TC4 already captures that
     * value for its own wands; this projection lets addons consume the same
     * scoped context without importing the implementation-owned holder
     * stack.</p>
     */
    @Nullable
    public static LivingEntity currentHeldItemEntity() {
        return HeldItemRenderContext.currentEntity();
    }

    /**
     * Restores the world model-view and projection matrices while an addon
     * submits geometry from NeoForge's {@code AFTER_LEVEL} stage.
     *
     * <p>NeoForge fires that stage after {@code LevelRenderer} has returned,
     * with a fresh identity pose stack and without guaranteeing that the live
     * RenderSystem model-view stack still contains the world matrices. The
     * returned scope reinstates the matrices carried by the event, configures
     * the requested scene-depth behavior, disables depth writes for the
     * overlay, and restores all affected state when closed.</p>
     *
     * @param event the current {@code AFTER_LEVEL} event
     * @param depthTested whether ordinary scene-depth occlusion is retained
     * @return a scope that must surround both vertex submission and flushing
     */
    public static WorldRenderScope beginAfterLevelWorldRender(WorldRenderContext event, boolean depthTested) {
        Objects.requireNonNull(event, "event");
        if (event.getStage() != WorldRenderContext.Stage.AFTER_LEVEL) {
            throw new IllegalArgumentException("Late world rendering requires the AFTER_LEVEL stage");
        }
        return beginAfterLevelWorldRender(event.getModelViewMatrix(), event.getProjectionMatrix(), depthTested);
    }

    /**
     * Matrix-only entry for an addon rendering from its native AFTER_LEVEL callback.
     * The caller supplies the world model-view and projection snapshots captured
     * at that callback boundary. No new event or delayed matrix snapshot is made.
     * The returned scope must surround both vertex submission and flushing.
     */
    public static WorldRenderScope beginAfterLevelWorldRender(Matrix4f modelViewMatrix, Matrix4f projectionMatrix, boolean depthTested) {
        Objects.requireNonNull(modelViewMatrix, "modelViewMatrix");
        Objects.requireNonNull(projectionMatrix, "projectionMatrix");
        TCWorldOverlayRenderState state = TCWorldOverlayRenderState.beginForAddon(modelViewMatrix, projectionMatrix, depthTested);
        return state::close;
    }

    /**
     * A non-throwing render-state scope suitable for try-with-resources.
     */
    @FunctionalInterface
    public interface WorldRenderScope extends AutoCloseable {

        @Override
        void close();
    }

    /**
     * Renders a wand using TC4's framed/dropped-entity transform relative to
     * the caller's current pose. The helper owns its inner pose push/pop;
     * callers remain responsible for placement and animation transforms.
     */
    public static void renderLegacyFramedWand(ItemStack stack, PoseStack poseStack, MultiBufferSource buffers, int packedLight, int packedOverlay) {
        requireRenderableWand(stack, poseStack, buffers);
        RendererHolder.WAND.renderLegacyFramedEntity(stack, poseStack, buffers, packedLight, packedOverlay);
    }

    /**
     * Renders a wand with TC4's direct {@code ItemRenderType.ENTITY}
     * transform relative to the caller's current pose. Unlike
     * {@link #renderLegacyFramedWand}, this does not apply Forge's additional
     * dropped-item half scale. Use it when a legacy renderer called TC4's
     * wand renderer directly, such as Thaumic Tinkerer's Osmotic Enchanter.
     */
    public static void renderLegacyDirectEntityWand(ItemStack stack, PoseStack poseStack, MultiBufferSource buffers, int packedLight, int packedOverlay) {
        requireRenderableWand(stack, poseStack, buffers);
        RendererHolder.WAND.renderLegacyDirectEntity(stack, poseStack, buffers, packedLight, packedOverlay);
    }

    /**
     * Renders only the focus installed in a public wand carrier. The caller
     * supplies the complete carrier transform and may select the legacy staff
     * focus proportions; TC resolves the live focus profile, layers, color,
     * ornament and animation without exposing renderer internals.
     */
    public static void renderInstalledFocus(ItemStack stack, boolean staffScale, PoseStack poseStack, int animationTick, int packedLight, int packedOverlay) {
        Objects.requireNonNull(stack, "stack");
        Objects.requireNonNull(poseStack, "poseStack");
        if (stack.isEmpty()) {
            throw new IllegalArgumentException("A non-empty focus carrier stack is required");
        }
        RendererHolder.WAND.renderInstalledFocusOnly(stack, staffScale, poseStack, animationTick, packedLight, packedOverlay);
    }

    /**
     * Resolves the visible focus tip used by TC4's continuous bolts and beams.
     * The latest rendered hand position is preferred, with the same stable
     * body-space fallback used by server-authored projectiles.
     */
    public static Vec3 resolveFocusCastOrigin(LivingEntity wielder, InteractionHand hand) {
        return ContinuousFocusOrigin.resolve(Objects.requireNonNull(wielder, "wielder"), Objects.requireNonNull(hand, "hand"));
    }

    /**
     * Creates or refreshes one of TC4's legacy continuous wand beams.
     *
     * <p>The beam is keyed by addon effect id, source entity and hand, starts
     * at {@link #resolveFocusCastOrigin}, and keeps TC4's eight-tick lifetime,
     * four-tick refresh window, additive texture animation and impact sprite.
     * Call once for every client-authorized update while the beam is active.</p>
     */
    public static void showFocusBeam(ResourceLocation effectId, LivingEntity source, InteractionHand hand, Vec3 target, int rgb, float endScale, int impactTicks) {
        Objects.requireNonNull(effectId, "effectId");
        Objects.requireNonNull(source, "source");
        Objects.requireNonNull(hand, "hand");
        Objects.requireNonNull(target, "target");
        if (rgb < 0 || rgb > 0xFFFFFF || !Float.isFinite(endScale) || endScale < 0.0F || endScale > 4.0F || impactTicks < 0 || impactTicks > 5) {
            throw new IllegalArgumentException("Invalid focus beam settings");
        }
        ExcavationBeamEffect.showAddonBeam(effectId, source, hand, target, rgb, endScale, impactTicks);
    }

    /**
     * Full native texture/flow selection, with the same keyed refresh lifecycle.
     */
    public static void showFocusBeam(ResourceLocation effectId, LivingEntity source, InteractionHand hand, Vec3 target, int rgb, float endScale, int impactTicks, BeamTexture texture, boolean reverse) {
        Objects.requireNonNull(effectId, "effectId");
        Objects.requireNonNull(source, "source");
        Objects.requireNonNull(hand, "hand");
        Objects.requireNonNull(target, "target");
        Objects.requireNonNull(texture, "texture");
        if (rgb < 0 || rgb > 0xFFFFFF || !Float.isFinite(endScale) || endScale < 0 || endScale > 4 || impactTicks < 0 || impactTicks > 5 || !Double.isFinite(target.x) || !Double.isFinite(target.y) || !Double.isFinite(target.z)) {
            throw new IllegalArgumentException("Invalid focus beam settings");
        }
        ExcavationBeamEffect.showAddonBeam(effectId, source, hand, target, rgb, endScale, impactTicks, texture, reverse);
    }

    private static void requireRenderableWand(ItemStack stack, PoseStack poseStack, MultiBufferSource buffers) {
        Objects.requireNonNull(stack, "stack");
        Objects.requireNonNull(poseStack, "poseStack");
        Objects.requireNonNull(buffers, "buffers");
        if (stack.isEmpty()) {
            throw new IllegalArgumentException("A non-empty wand stack is required");
        }
    }

    private static final class RendererHolder {

        private static final WandItemRenderer WAND = new WandItemRenderer();

        private RendererHolder() {
        }
    }
}
