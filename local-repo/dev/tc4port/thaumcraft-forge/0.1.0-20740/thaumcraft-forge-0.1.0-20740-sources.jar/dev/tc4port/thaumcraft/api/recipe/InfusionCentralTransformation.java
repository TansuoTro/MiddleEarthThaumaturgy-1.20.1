package dev.tc4port.thaumcraft.api.recipe;

import dev.tc4port.thaumcraft.api.aspect.AspectAmounts;
import net.minecraft.core.HolderLookup;
import net.minecraft.world.item.ItemStack;

/**
 * Stable-id addon transformation for central or peripheral infusion inputs.
 *
 * <p>Matching, costs and previews must be deterministic and side-effect free;
 * the completion hook may produce a random result. Every input
 * is a defensive copy. The registration must remain active for as long as a
 * recipe referring to its id may be selected or completed.</p>
 */
public interface InfusionCentralTransformation {

    /**
     * Applies addon-specific eligibility beyond the recipe ingredients.
     */
    default boolean matches(ItemStack centralInput) {
        return true;
    }

    /**
     * Returns a non-empty transformed copy. Cost hooks apply only to the central input.
     */
    ItemStack transform(ItemStack centralInput, HolderLookup.Provider registries);

    /**
     * Produces the central result exactly once on successful server completion.
     * Random outcomes and new persistent identities belong here. Preview and
     * matching continue to use the deterministic {@link #transform} operation.
     * The input is a defensive copy; do not mutate the world or retain arguments.
     */
    default ItemStack transformOnCompletion(ItemStack centralInput, net.minecraft.server.level.ServerLevel level) {
        return transform(centralInput, level.registryAccess());
    }

    /**
     * Complete, finite central-input examples for unfocused viewers. Called only with a
     * live world after recipes/data are available; never retain the world or its registries.
     * Use current recipes when examples must be craftable. Empty means no display examples.
     * This is presentation only; focused queries still use the actual item and matching rules.
     */
    default java.util.List<ItemStack> previewInputs(net.minecraft.world.level.Level level, java.util.List<ItemStack> ingredientExamples) {
        return ingredientExamples;
    }

    /**
     * Computes the current bounded instability from the data-defined base.
     */
    default int instability(ItemStack centralInput, int baseInstability) {
        return baseInstability;
    }

    /**
     * Computes the current bounded aspect cost from the data-defined base.
     */
    default AspectAmounts aspects(ItemStack centralInput, AspectAmounts baseAspects) {
        return baseAspects;
    }
}
