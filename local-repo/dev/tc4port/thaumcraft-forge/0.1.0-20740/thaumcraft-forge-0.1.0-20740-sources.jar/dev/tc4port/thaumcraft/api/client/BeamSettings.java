package dev.tc4port.thaumcraft.api.client;

import java.util.Objects;

/**
 * Coordinate beam parameters in world blocks and client ticks.
 */
public record BeamSettings(BeamTexture texture, EffectColor color, int lifetime, float width, float endScale, boolean reverse, boolean pulse, int rotationSpeed, boolean additive) {

    public BeamSettings {
        Objects.requireNonNull(texture, "texture");
        Objects.requireNonNull(color, "color");
        if (lifetime < 1 || lifetime > 1200 || !Float.isFinite(width) || width <= 0 || width > 64 || !Float.isFinite(endScale) || endScale < 0 || endScale > 64 || rotationSpeed < 1 || rotationSpeed > 360) {
            throw new IllegalArgumentException("Invalid beam settings");
        }
    }
}
