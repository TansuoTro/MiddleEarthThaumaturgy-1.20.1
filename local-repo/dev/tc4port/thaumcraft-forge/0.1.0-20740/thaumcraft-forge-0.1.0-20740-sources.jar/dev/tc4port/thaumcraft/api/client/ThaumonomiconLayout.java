package dev.tc4port.thaumcraft.api.client;

/**
 * Current panel bounds in native GUI coordinates, excluding category tabs and widget overlays.
 */
public record ThaumonomiconLayout(int left, int top, int width, int height, boolean reading) {
}
