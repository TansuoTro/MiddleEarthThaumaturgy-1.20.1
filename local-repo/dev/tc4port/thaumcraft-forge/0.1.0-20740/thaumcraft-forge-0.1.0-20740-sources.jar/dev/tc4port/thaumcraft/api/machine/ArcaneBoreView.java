package dev.tc4port.thaumcraft.api.machine;

public interface ArcaneBoreView {

    boolean hasPickaxe();

    boolean hasFocus();

    boolean isPickaxeBroken();

    boolean isWorking();

    int radius();

    int speed();

    boolean hasNativeClusters();

    int fortune();

    boolean hasSilkTouch();
}
