package dev.tc4port.thaumcraft.block;

import dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult;
import com.mojang.serialization.MapCodec;
import dev.tc4port.thaumcraft.block.entity.EssentiaTubeBlockEntity;
import dev.tc4port.thaumcraft.api.aspect.AspectId;
import dev.tc4port.thaumcraft.api.essentia.EssentiaTransport;
import dev.tc4port.thaumcraft.api.essentia.EssentiaApi;
import dev.tc4port.thaumcraft.common.WandInteractionTarget;
import dev.tc4port.thaumcraft.api.wand.WandCarrierItem;
import dev.tc4port.thaumcraft.state.TCItemState;
import dev.tc4port.thaumcraft.registry.TCItems;
import dev.tc4port.thaumcraft.registry.TCSounds;
import java.util.EnumMap;
import java.util.Map;
import javax.annotation.Nullable;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityTicker;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.world.level.block.state.properties.DirectionProperty;
import net.minecraft.world.level.pathfinder.PathComputationType;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;
import dev.tc4port.thaumcraft.nativeimpl.ClientExtensionTarget;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.phys.HitResult;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.Explosion;

/**
 * Shared shell for TC4's six tube metadata variants and the eight-unit
 * buffer. Connections are real block states so chunk meshes and collision
 * update without a legacy custom world renderer.
 */
public final class EssentiaTubeBlock extends net.minecraft.world.level.block.BaseEntityBlock implements WandInteractionTarget, dev.tc4port.thaumcraft.nativeimpl.ClientExtensionTarget {

    // Forge calls initializeClient from the native superclass constructor. Do not add a field initializer.
    private java.util.function.Consumer<net.minecraftforge.client.extensions.common.IClientBlockExtensions> platform$clientInstaller;

    /**
     * Exact CodeChicken sub-hit identity: null arm means the core cuboid.
     */
    public record TraceTarget(@Nullable Direction arm) {
    }

    public enum Kind {

        NORMAL,
        VALVE,
        FILTER,
        BUFFER,
        RESTRICTED,
        DIRECTIONAL
    }

    public static final MapCodec<EssentiaTubeBlock> CODEC = EssentiaTubeBlock.native$BlockCodecPlatform$simple(properties -> new EssentiaTubeBlock(Kind.NORMAL, properties));

    public static final DirectionProperty FACING = BlockStateProperties.FACING;

    public static final BooleanProperty DOWN = BooleanProperty.create("down");

    public static final BooleanProperty UP = BooleanProperty.create("up");

    public static final BooleanProperty NORTH = BooleanProperty.create("north");

    public static final BooleanProperty SOUTH = BooleanProperty.create("south");

    public static final BooleanProperty WEST = BooleanProperty.create("west");

    public static final BooleanProperty EAST = BooleanProperty.create("east");

    private static final Map<Direction, BooleanProperty> CONNECTIONS = new EnumMap<>(Direction.class);

    private static final VoxelShape CORE = Block.box(5.5, 5.5, 5.5, 10.5, 10.5, 10.5);

    private static final VoxelShape BUFFER_CORE = Block.box(4, 4, 4, 12, 12, 12);

    private static final Map<Direction, VoxelShape> ARMS = new EnumMap<>(Direction.class);

    private static final double HIT_EPSILON = 1.0E-5;

    static {
        CONNECTIONS.put(Direction.DOWN, DOWN);
        CONNECTIONS.put(Direction.UP, UP);
        CONNECTIONS.put(Direction.NORTH, NORTH);
        CONNECTIONS.put(Direction.SOUTH, SOUTH);
        CONNECTIONS.put(Direction.WEST, WEST);
        CONNECTIONS.put(Direction.EAST, EAST);
        ARMS.put(Direction.DOWN, Block.box(6.72, 0, 6.72, 9.28, 8, 9.28));
        ARMS.put(Direction.UP, Block.box(6.72, 8, 6.72, 9.28, 16, 9.28));
        ARMS.put(Direction.NORTH, Block.box(6.72, 6.72, 0, 9.28, 9.28, 8));
        ARMS.put(Direction.SOUTH, Block.box(6.72, 6.72, 8, 9.28, 9.28, 16));
        ARMS.put(Direction.WEST, Block.box(0, 6.72, 6.72, 8, 9.28, 9.28));
        ARMS.put(Direction.EAST, Block.box(8, 6.72, 6.72, 16, 9.28, 9.28));
    }

    private final Kind kind;

    public EssentiaTubeBlock(Kind kind, BlockBehaviour.Properties properties) {
        this(properties, kind, properties, true);
    }

    public Kind kind() {
        return this.kind;
    }

    protected MapCodec<? extends EssentiaTubeBlock> codec() {
        return CODEC;
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(FACING, DOWN, UP, NORTH, SOUTH, WEST, EAST);
    }

    @Nullable
    @Override
    public BlockState getStateForPlacement(BlockPlaceContext context) {
        return this.stateWithConnections(context.getLevel(), context.getClickedPos(), this.defaultBlockState().setValue(FACING, context.getClickedFace()));
    }

    @Override
    public void setPlacedBy(Level level, BlockPos pos, BlockState state, @Nullable LivingEntity placer, ItemStack stack) {
        super.setPlacedBy(level, pos, state, placer, stack);
        if (level.getBlockEntity(pos) instanceof EssentiaTubeBlockEntity tube) {
            tube.initializeOpenSidesFromNeighbors();
        }
    }

    @Override
    public BlockState updateShape(BlockState state, Direction direction, BlockState neighborState, LevelAccessor level, BlockPos pos, BlockPos neighborPos) {
        return this.stateWithConnections(level, pos, state);
    }

    public BlockState stateWithConnections(BlockGetter level, BlockPos pos, BlockState state) {
        BlockEntity own = level.getBlockEntity(pos);
        for (Direction direction : Direction.values()) {
            boolean ownOpen = !(own instanceof EssentiaTransport transport) || transport.isConnectable(direction);
            BlockPos neighborPos = pos.relative(direction);
            EssentiaTransport neighbor = EssentiaApi.transport(level, neighborPos, direction.getOpposite());
            boolean connected = ownOpen && neighbor != null && neighbor.isConnectable(direction.getOpposite());
            state = state.setValue(CONNECTIONS.get(direction), connected);
        }
        return state;
    }

    public void refreshConnections(Level level, BlockPos pos) {
        if (!level.isLoaded(pos))
            return;
        BlockState state = level.getBlockState(pos);
        BlockState updated = this.stateWithConnections(level, pos, state);
        if (updated != state) {
            // Connection properties do not need vanilla shape propagation into absent chunks.
            level.setBlock(pos, updated, Block.UPDATE_CLIENTS | Block.UPDATE_KNOWN_SHAPE);
        }
    }

    @Nullable
    @Override
    public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        return new EssentiaTubeBlockEntity(pos, state);
    }

    @Nullable
    @Override
    public <T extends BlockEntity> BlockEntityTicker<T> getTicker(Level level, BlockState state, BlockEntityType<T> type) {
        return createTickerHelper(type, dev.tc4port.thaumcraft.registry.TCBlockEntities.ESSENTIA_TUBE.get(), level.isClientSide ? EssentiaTubeBlockEntity::clientTick : EssentiaTubeBlockEntity::serverTick);
    }

    @Override
    public RenderShape getRenderShape(BlockState state) {
        return RenderShape.MODEL;
    }

    @Override
    public VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
        VoxelShape shape = this.kind == Kind.BUFFER ? BUFFER_CORE : CORE;
        for (Direction direction : Direction.values()) {
            if (this.hasSelectableArm(level, pos, direction)) {
                shape = Shapes.or(shape, ARMS.get(direction));
            }
        }
        return shape;
    }

    @Override
    public VoxelShape getCollisionShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
        return this.legacyBounds(level, pos, 6, 10, 6, 10, 6, 10);
    }

    private VoxelShape legacyBounds(BlockGetter level, BlockPos pos, double minX, double maxX, double minY, double maxY, double minZ, double maxZ) {
        for (Direction direction : Direction.values()) {
            BlockPos neighborPos = pos.relative(direction);
            if (level instanceof net.minecraft.world.level.LevelReader reader && !reader.hasChunk(neighborPos.getX() >> 4, neighborPos.getZ() >> 4)) {
                continue;
            }
            EssentiaTransport transport = EssentiaApi.transport(level, neighborPos, direction.getOpposite());
            if (transport == null || !transport.isConnectable(direction.getOpposite())) {
                continue;
            }
            switch(direction) {
                case DOWN ->
                    minY = 0;
                case UP ->
                    maxY = 16;
                case NORTH ->
                    minZ = 0;
                case SOUTH ->
                    maxZ = 16;
                case WEST ->
                    minX = 0;
                case EAST ->
                    maxX = 16;
            }
        }
        return Block.box(minX, minY, minZ, maxX, maxY, maxZ);
    }

    protected ItemUseResult interactWithItem(ItemStack stack, BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
        if (!(level.getBlockEntity(pos) instanceof dev.tc4port.thaumcraft.block.entity.EssentiaTubeBlockEntity tube)) {
            return dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
        }
        if (this.kind == dev.tc4port.thaumcraft.block.EssentiaTubeBlock.Kind.VALVE && (stack.is(dev.tc4port.thaumcraft.registry.TCItems.byId("resonator").get()) || isTubeFamilyItem(stack))) {
            /*
             * BlockTube returned false for the resonator and its combined
             * metadata BlockItem, allowing those items to inspect/place
             * instead of toggling the valve's default activation.
             */
            return dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.SKIP_DEFAULT_BLOCK_INTERACTION;
        }
        if (this.kind == dev.tc4port.thaumcraft.block.EssentiaTubeBlock.Kind.FILTER && player.isShiftKeyDown() && tube.filter() != null) {
            return dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
        }
        if (this.kind == dev.tc4port.thaumcraft.block.EssentiaTubeBlock.Kind.FILTER && stack.is(dev.tc4port.thaumcraft.registry.TCItems.byId("jar_label").get()) && tube.filter() == null) {
            dev.tc4port.thaumcraft.api.aspect.AspectId labelFilter = (switch(0) {
                default ->
                    {
                        dev.tc4port.thaumcraft.api.data.ItemStateKey<dev.tc4port.thaumcraft.api.aspect.AspectId> native$receiver$400 = dev.tc4port.thaumcraft.state.TCItemState.JAR_FILTER;
                        net.minecraft.world.item.ItemStack native$argument$401 = stack;
                        java.util.Objects.requireNonNull(native$receiver$400);
                        yield dev.tc4port.thaumcraft.api.item.ItemStatePlatform.get(native$argument$401, native$receiver$400);
                    }
            });
            if (labelFilter == null) {
                return dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.CONSUME;
            }
            if (!level.isClientSide && tube.setFilter(labelFilter)) {
                stack.shrink(1);
                level.playSound(null, pos, dev.tc4port.thaumcraft.registry.TCSounds.PAGE.get(), net.minecraft.sounds.SoundSource.BLOCKS, 1.0F, 1.0F);
            }
            return dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.sidedSuccess(level.isClientSide);
        }
        if (stack.getItem() instanceof dev.tc4port.thaumcraft.api.wand.WandCarrierItem) {
            dev.tc4port.thaumcraft.block.EssentiaTubeBlock.TraceTarget target = this.targetedPart(level, pos, hit);
            if (target == null || this.kind == dev.tc4port.thaumcraft.block.EssentiaTubeBlock.Kind.BUFFER && target.arm() == null) {
                return dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.sidedSuccess(level.isClientSide);
            }
            if (!level.isClientSide) {
                net.minecraft.core.Direction side = target.arm();
                boolean core = side == null;
                if (this.kind == dev.tc4port.thaumcraft.block.EssentiaTubeBlock.Kind.BUFFER && player.isShiftKeyDown()) {
                    tube.cycleChoke(side);
                } else if (core && this.kind == dev.tc4port.thaumcraft.block.EssentiaTubeBlock.Kind.VALVE) {
                    tube.cycleValveFacing();
                } else if (core) {
                    /* TileTube used this for every non-buffer core. */
                    tube.cycleDirectionalFacing();
                } else if (!core) {
                    tube.toggleOpen(side);
                }
                level.playSound(null, pos, this.kind == dev.tc4port.thaumcraft.block.EssentiaTubeBlock.Kind.BUFFER && player.isShiftKeyDown() ? dev.tc4port.thaumcraft.registry.TCSounds.SQUEEK.get() : dev.tc4port.thaumcraft.registry.TCSounds.TOOL.get(), net.minecraft.sounds.SoundSource.BLOCKS, this.kind == dev.tc4port.thaumcraft.block.EssentiaTubeBlock.Kind.BUFFER && player.isShiftKeyDown() ? 0.6F : 0.5F, (this.kind == dev.tc4port.thaumcraft.block.EssentiaTubeBlock.Kind.BUFFER && player.isShiftKeyDown() ? 1.1F : 0.9F) + level.random.nextFloat() * 0.2F);
            }
            player.swing(hand);
            return dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.sidedSuccess(level.isClientSide);
        }
        return dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
    }

    private static boolean isTubeFamilyItem(ItemStack stack) {
        return stack.is(TCItems.blockItemById("essentia_tube").get()) || stack.is(TCItems.blockItemById("essentia_valve").get()) || stack.is(TCItems.blockItemById("filtered_essentia_tube").get()) || stack.is(TCItems.blockItemById("essentia_buffer").get()) || stack.is(TCItems.blockItemById("restricted_essentia_tube").get()) || stack.is(TCItems.blockItemById("directional_essentia_tube").get()) || stack.is(TCItems.blockItemById("alchemical_centrifuge").get()) || stack.is(TCItems.blockItemById("essentia_crystallizer").get());
    }

    protected InteractionResult interactWithoutItem(BlockState state, Level level, BlockPos pos, Player player, BlockHitResult hit) {
        if (!(level.getBlockEntity(pos) instanceof dev.tc4port.thaumcraft.block.entity.EssentiaTubeBlockEntity tube)) {
            return net.minecraft.world.InteractionResult.PASS;
        }
        if (this.kind == dev.tc4port.thaumcraft.block.EssentiaTubeBlock.Kind.FILTER && player.isShiftKeyDown() && tube.filter() != null) {
            removeFilter(level, pos, hit.getDirection(), tube);
            return net.minecraft.world.InteractionResult.sidedSuccess(level.isClientSide);
        }
        if (this.kind == dev.tc4port.thaumcraft.block.EssentiaTubeBlock.Kind.VALVE) {
            if (!level.isClientSide) {
                tube.setFlowAllowed(!tube.flowAllowed());
            }
            return net.minecraft.world.InteractionResult.sidedSuccess(level.isClientSide);
        }
        return net.minecraft.world.InteractionResult.PASS;
    }

    private static void removeFilter(Level level, BlockPos pos, Direction side, EssentiaTubeBlockEntity tube) {
        if (level.isClientSide || !tube.clearFilter()) {
            return;
        }
        ((ServerLevel) level).addFreshEntity(new ItemEntity(level, pos.getX() + 0.5 + side.getStepX() / 3.0, pos.getY() + 0.5, pos.getZ() + 0.5 + side.getStepZ() / 3.0, new ItemStack(TCItems.byId("jar_label").get())));
        level.playSound(null, pos, TCSounds.PAGE.get(), SoundSource.BLOCKS, 1.0F, 1.0F);
    }

    @Override
    public boolean hasAnalogOutputSignal(BlockState state) {
        return this.kind == Kind.BUFFER;
    }

    @Override
    public int getAnalogOutputSignal(BlockState state, Level level, BlockPos pos) {
        return level.getBlockEntity(pos) instanceof EssentiaTubeBlockEntity tube ? tube.comparatorOutput() : 0;
    }

    @Override
    public void onRemove(BlockState state, Level level, BlockPos pos, BlockState newState, boolean movedByPiston) {
        if (!state.is(newState.getBlock()) && !level.isClientSide && this.kind == Kind.FILTER && level.getBlockEntity(pos) instanceof EssentiaTubeBlockEntity tube && tube.filter() != null) {
            dev.tc4port.thaumcraft.loot.BlockRemovalLoot.drop((net.minecraft.server.level.ServerLevel) level, pos, state, tube, "tube_label");
        }
        super.onRemove(state, level, pos, newState, movedByPiston);
    }

    @Nullable
    public Direction targetedArm(BlockGetter level, BlockPos pos, BlockHitResult hit) {
        TraceTarget target = this.targetedPart(level, pos, hit);
        return target == null ? null : target.arm();
    }

    @Nullable
    public TraceTarget targetedPart(BlockGetter level, BlockPos pos, BlockHitResult hit) {
        if (!pos.equals(hit.getBlockPos())) {
            return null;
        }
        Vec3 location = hit.getLocation();
        if (contains(this.coreBounds(pos), location)) {
            return new TraceTarget(null);
        }
        for (Direction direction : Direction.values()) {
            if (this.hasSelectableArm(level, pos, direction) && contains(armBounds(pos, direction), location)) {
                return new TraceTarget(direction);
            }
        }
        return null;
    }

    private boolean hasSelectableArm(BlockGetter level, BlockPos pos, Direction direction) {
        if (level.getBlockEntity(pos) instanceof EssentiaTubeBlockEntity own && !own.hasConnectionPort(direction)) {
            return false;
        }
        BlockPos neighborPos = pos.relative(direction);
        if (level instanceof net.minecraft.world.level.LevelReader reader && !reader.hasChunk(neighborPos.getX() >> 4, neighborPos.getZ() >> 4)) {
            return false;
        }
        BlockEntity entity = level.getBlockEntity(neighborPos);
        Direction neighborFace = direction.getOpposite();
        // A wand must still reopen closed tube ports, but cannot create a port
        // on a reservoir's sealed side or a valve's wheel face.
        if (entity instanceof EssentiaTubeBlockEntity tube) {
            return tube.hasConnectionPort(neighborFace);
        }
        EssentiaTransport transport = EssentiaApi.transport(level, neighborPos, neighborFace);
        return transport != null && transport.isConnectable(neighborFace);
    }

    private static boolean contains(AABB bounds, Vec3 location) {
        return location.x >= bounds.minX - HIT_EPSILON && location.x <= bounds.maxX + HIT_EPSILON && location.y >= bounds.minY - HIT_EPSILON && location.y <= bounds.maxY + HIT_EPSILON && location.z >= bounds.minZ - HIT_EPSILON && location.z <= bounds.maxZ + HIT_EPSILON;
    }

    public AABB coreBounds(BlockPos pos) {
        double min = this.kind == Kind.BUFFER ? 0.25 : 0.34375;
        double max = this.kind == Kind.BUFFER ? 0.75 : 0.65625;
        return new AABB(pos.getX() + min, pos.getY() + min, pos.getZ() + min, pos.getX() + max, pos.getY() + max, pos.getZ() + max);
    }

    public static AABB armBounds(BlockPos pos, Direction direction) {
        double minX = pos.getX() + 0.42;
        double minY = pos.getY() + 0.42;
        double minZ = pos.getZ() + 0.42;
        double maxX = pos.getX() + 0.58;
        double maxY = pos.getY() + 0.58;
        double maxZ = pos.getZ() + 0.58;
        return switch(direction) {
            case DOWN ->
                new net.minecraft.world.phys.AABB(minX, pos.getY(), minZ, maxX, pos.getY() + 0.5, maxZ);
            case UP ->
                new net.minecraft.world.phys.AABB(minX, pos.getY() + 0.5, minZ, maxX, pos.getY() + 1.0, maxZ);
            case NORTH ->
                new net.minecraft.world.phys.AABB(minX, minY, pos.getZ(), maxX, maxY, pos.getZ() + 0.5);
            case SOUTH ->
                new net.minecraft.world.phys.AABB(minX, minY, pos.getZ() + 0.5, maxX, maxY, pos.getZ() + 1.0);
            case WEST ->
                new net.minecraft.world.phys.AABB(pos.getX(), minY, minZ, pos.getX() + 0.5, maxY, maxZ);
            case EAST ->
                new net.minecraft.world.phys.AABB(pos.getX() + 0.5, minY, minZ, pos.getX() + 1.0, maxY, maxZ);
        };
    }

    @Override
    public boolean isPathfindable(BlockState state, BlockGetter level, BlockPos pos, PathComputationType pathType) {
        // The tube core floats mid-cell; vanilla treats any non-cube
        // collision as open and plans walking paths straight through it.
        return false;
    }

    private EssentiaTubeBlock(net.minecraft.world.level.block.state.BlockBehaviour.Properties native$NativeEntityBlock$arg0, Kind kind, BlockBehaviour.Properties properties, boolean native$NativeEntityBlock$captured) {
        super(native$NativeEntityBlock$arg0);
        this.kind = kind;
        BlockState state = this.stateDefinition.any().setValue(FACING, Direction.NORTH);
        for (BooleanProperty property : CONNECTIONS.values()) {
            state = state.setValue(property, false);
        }
        this.registerDefaultState(state);
    }

    @Override
    public void initializeClient(java.util.function.Consumer<net.minecraftforge.client.extensions.common.IClientBlockExtensions> installer) {
        platform$clientInstaller = installer;
        super.initializeClient(installer);
    }

    @Override
    public void platform$clientExtension(Object extension) {
        java.util.Objects.requireNonNull(platform$clientInstaller, "Forge initializeClient must run before client extension registration").accept((net.minecraftforge.client.extensions.common.IClientBlockExtensions) extension);
    }

    @Override
    public InteractionResult use(BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
        ItemUseResult result = (switch(0) {
            default ->
                {
                    net.minecraft.world.item.ItemStack native$bodyOperand$4423 = player.getItemInHand(hand);
                    net.minecraft.world.level.block.state.BlockState native$bodyOperand$4424 = state;
                    net.minecraft.world.level.Level native$bodyOperand$4425 = level;
                    net.minecraft.core.BlockPos native$bodyOperand$4426 = pos;
                    net.minecraft.world.entity.player.Player native$bodyOperand$4427 = player;
                    net.minecraft.world.InteractionHand native$bodyOperand$4428 = hand;
                    net.minecraft.world.phys.BlockHitResult native$bodyOperand$4429 = hit;
                    dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult native$bodyResult$4437 = null;
                    native$bodyReturn$4438: {
                        if (true) {
                            if (!(native$bodyOperand$4425.getBlockEntity(native$bodyOperand$4426) instanceof dev.tc4port.thaumcraft.block.entity.EssentiaTubeBlockEntity native$bodyBinding$4430)) {
                                {
                                    native$bodyResult$4437 = dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
                                    break native$bodyReturn$4438;
                                }
                            }
                            if (this.kind == dev.tc4port.thaumcraft.block.EssentiaTubeBlock.Kind.VALVE && (native$bodyOperand$4423.is(dev.tc4port.thaumcraft.registry.TCItems.byId("resonator").get()) || isTubeFamilyItem(native$bodyOperand$4423))) {
                                {
                                    native$bodyResult$4437 = dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.SKIP_DEFAULT_BLOCK_INTERACTION;
                                    break native$bodyReturn$4438;
                                }
                            }
                            if (this.kind == dev.tc4port.thaumcraft.block.EssentiaTubeBlock.Kind.FILTER && native$bodyOperand$4427.isShiftKeyDown() && native$bodyBinding$4430.filter() != null) {
                                {
                                    native$bodyResult$4437 = dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
                                    break native$bodyReturn$4438;
                                }
                            }
                            if (this.kind == dev.tc4port.thaumcraft.block.EssentiaTubeBlock.Kind.FILTER && native$bodyOperand$4423.is(dev.tc4port.thaumcraft.registry.TCItems.byId("jar_label").get()) && native$bodyBinding$4430.filter() == null) {
                                dev.tc4port.thaumcraft.api.aspect.AspectId native$bodyBinding$4431 = (switch(0) {
                                    default ->
                                        {
                                            dev.tc4port.thaumcraft.api.data.ItemStateKey<dev.tc4port.thaumcraft.api.aspect.AspectId> native$bodyBinding$4432 = dev.tc4port.thaumcraft.state.TCItemState.JAR_FILTER;
                                            net.minecraft.world.item.ItemStack native$bodyBinding$4433 = native$bodyOperand$4423;
                                            java.util.Objects.requireNonNull(native$bodyBinding$4432);
                                            yield dev.tc4port.thaumcraft.api.item.ItemStatePlatform.get(native$bodyBinding$4433, native$bodyBinding$4432);
                                        }
                                });
                                if (native$bodyBinding$4431 == null) {
                                    {
                                        native$bodyResult$4437 = dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.CONSUME;
                                        break native$bodyReturn$4438;
                                    }
                                }
                                if (!native$bodyOperand$4425.isClientSide && native$bodyBinding$4430.setFilter(native$bodyBinding$4431)) {
                                    native$bodyOperand$4423.shrink(1);
                                    native$bodyOperand$4425.playSound(null, native$bodyOperand$4426, dev.tc4port.thaumcraft.registry.TCSounds.PAGE.get(), net.minecraft.sounds.SoundSource.BLOCKS, 1.0F, 1.0F);
                                }
                                {
                                    native$bodyResult$4437 = dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.sidedSuccess(native$bodyOperand$4425.isClientSide);
                                    break native$bodyReturn$4438;
                                }
                            }
                            if (native$bodyOperand$4423.getItem() instanceof dev.tc4port.thaumcraft.api.wand.WandCarrierItem) {
                                dev.tc4port.thaumcraft.block.EssentiaTubeBlock.TraceTarget native$bodyBinding$4434 = this.targetedPart(native$bodyOperand$4425, native$bodyOperand$4426, native$bodyOperand$4429);
                                if (native$bodyBinding$4434 == null || this.kind == dev.tc4port.thaumcraft.block.EssentiaTubeBlock.Kind.BUFFER && native$bodyBinding$4434.arm() == null) {
                                    {
                                        native$bodyResult$4437 = dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.sidedSuccess(native$bodyOperand$4425.isClientSide);
                                        break native$bodyReturn$4438;
                                    }
                                }
                                if (!native$bodyOperand$4425.isClientSide) {
                                    net.minecraft.core.Direction native$bodyBinding$4435 = native$bodyBinding$4434.arm();
                                    boolean native$bodyBinding$4436 = native$bodyBinding$4435 == null;
                                    if (this.kind == dev.tc4port.thaumcraft.block.EssentiaTubeBlock.Kind.BUFFER && native$bodyOperand$4427.isShiftKeyDown()) {
                                        native$bodyBinding$4430.cycleChoke(native$bodyBinding$4435);
                                    } else if (native$bodyBinding$4436 && this.kind == dev.tc4port.thaumcraft.block.EssentiaTubeBlock.Kind.VALVE) {
                                        native$bodyBinding$4430.cycleValveFacing();
                                    } else if (native$bodyBinding$4436) {
                                        /* TileTube used this for every non-buffer core. */
                                        native$bodyBinding$4430.cycleDirectionalFacing();
                                    } else if (!native$bodyBinding$4436) {
                                        native$bodyBinding$4430.toggleOpen(native$bodyBinding$4435);
                                    }
                                    native$bodyOperand$4425.playSound(null, native$bodyOperand$4426, this.kind == dev.tc4port.thaumcraft.block.EssentiaTubeBlock.Kind.BUFFER && native$bodyOperand$4427.isShiftKeyDown() ? dev.tc4port.thaumcraft.registry.TCSounds.SQUEEK.get() : dev.tc4port.thaumcraft.registry.TCSounds.TOOL.get(), net.minecraft.sounds.SoundSource.BLOCKS, this.kind == dev.tc4port.thaumcraft.block.EssentiaTubeBlock.Kind.BUFFER && native$bodyOperand$4427.isShiftKeyDown() ? 0.6F : 0.5F, (this.kind == dev.tc4port.thaumcraft.block.EssentiaTubeBlock.Kind.BUFFER && native$bodyOperand$4427.isShiftKeyDown() ? 1.1F : 0.9F) + native$bodyOperand$4425.random.nextFloat() * 0.2F);
                                }
                                native$bodyOperand$4427.swing(native$bodyOperand$4428);
                                {
                                    native$bodyResult$4437 = dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.sidedSuccess(native$bodyOperand$4425.isClientSide);
                                    break native$bodyReturn$4438;
                                }
                            }
                            {
                                native$bodyResult$4437 = dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
                                break native$bodyReturn$4438;
                            }
                        }
                    }
                    yield native$bodyResult$4437;
                }
        });
        return result == ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION ? (hand == InteractionHand.MAIN_HAND ? (switch(0) {
            default ->
                {
                    net.minecraft.world.level.block.state.BlockState native$bodyOperand$3666 = state;
                    net.minecraft.world.level.Level native$bodyOperand$3667 = level;
                    net.minecraft.core.BlockPos native$bodyOperand$3668 = pos;
                    net.minecraft.world.entity.player.Player native$bodyOperand$3669 = player;
                    net.minecraft.world.phys.BlockHitResult native$bodyOperand$3670 = hit;
                    net.minecraft.world.InteractionResult native$bodyResult$3672 = null;
                    native$bodyReturn$3673: {
                        if (true) {
                            if (!(native$bodyOperand$3667.getBlockEntity(native$bodyOperand$3668) instanceof dev.tc4port.thaumcraft.block.entity.EssentiaTubeBlockEntity native$bodyBinding$3671)) {
                                {
                                    native$bodyResult$3672 = net.minecraft.world.InteractionResult.PASS;
                                    break native$bodyReturn$3673;
                                }
                            }
                            if (this.kind == dev.tc4port.thaumcraft.block.EssentiaTubeBlock.Kind.FILTER && native$bodyOperand$3669.isShiftKeyDown() && native$bodyBinding$3671.filter() != null) {
                                removeFilter(native$bodyOperand$3667, native$bodyOperand$3668, native$bodyOperand$3670.getDirection(), native$bodyBinding$3671);
                                {
                                    native$bodyResult$3672 = net.minecraft.world.InteractionResult.sidedSuccess(native$bodyOperand$3667.isClientSide);
                                    break native$bodyReturn$3673;
                                }
                            }
                            if (this.kind == dev.tc4port.thaumcraft.block.EssentiaTubeBlock.Kind.VALVE) {
                                if (!native$bodyOperand$3667.isClientSide) {
                                    native$bodyBinding$3671.setFlowAllowed(!native$bodyBinding$3671.flowAllowed());
                                }
                                {
                                    native$bodyResult$3672 = net.minecraft.world.InteractionResult.sidedSuccess(native$bodyOperand$3667.isClientSide);
                                    break native$bodyReturn$3673;
                                }
                            }
                            {
                                native$bodyResult$3672 = net.minecraft.world.InteractionResult.PASS;
                                break native$bodyReturn$3673;
                            }
                        }
                    }
                    yield native$bodyResult$3672;
                }
        }) : InteractionResult.PASS) : result.result();
    }

    @Override
    public void playerWillDestroy(Level level, BlockPos pos, BlockState state, Player player) {
        {
            net.minecraft.world.level.Level native$bodyOperand$5835 = level;
            net.minecraft.core.BlockPos native$bodyOperand$5836 = pos;
            net.minecraft.world.level.block.state.BlockState native$bodyOperand$5837 = state;
            net.minecraft.world.entity.player.Player native$bodyOperand$5838 = player;
            net.minecraft.world.level.block.state.BlockState native$bodyResult$5839 = null;
            native$bodyReturn$5840: {
                if (true) {
                    super.playerWillDestroy(native$bodyOperand$5835, native$bodyOperand$5836, native$bodyOperand$5837, native$bodyOperand$5838);
                    {
                        native$bodyResult$5839 = native$bodyOperand$5837;
                        break native$bodyReturn$5840;
                    }
                }
            }
        }
    }

    public BlockState beforePlayerDestroy(Level level, BlockPos pos, BlockState state, Player player) {
        super.playerWillDestroy(level, pos, state, player);
        return state;
    }

    protected boolean survivesSharedExplosion() {
        return false;
    }

    public int getExpDrop(net.minecraft.world.level.block.state.BlockState native$callbackInput$1050, net.minecraft.world.level.LevelReader native$callbackInput$1051, net.minecraft.util.RandomSource native$callbackInput$1052, net.minecraft.core.BlockPos native$callbackInput$1053, int native$callbackInput$1054, int native$callbackInput$1055) {
        net.minecraft.world.level.block.state.BlockState state = native$callbackInput$1050;
        net.minecraft.util.RandomSource random = native$callbackInput$1052;
        return 0;
    }

    @Override
    public void onBlockExploded(BlockState state, Level level, BlockPos pos, Explosion explosion) {
        if (!(switch(0) {
            default ->
                {
                    boolean native$bodyResult$5265 = false;
                    native$bodyReturn$5266: {
                        if (true) {
                            {
                                native$bodyResult$5265 = false;
                                break native$bodyReturn$5266;
                            }
                        }
                    }
                    yield native$bodyResult$5265;
                }
        }))
            super.onBlockExploded(state, level, pos, explosion);
    }

    @Override
    public boolean canDropFromExplosion(BlockState state, BlockGetter level, BlockPos pos, Explosion explosion) {
        return !(switch(0) {
            default ->
                {
                    boolean native$bodyResult$4439 = false;
                    native$bodyReturn$4440: {
                        if (true) {
                            {
                                native$bodyResult$4439 = false;
                                break native$bodyReturn$4440;
                            }
                        }
                    }
                    yield native$bodyResult$4439;
                }
        }) && super.canDropFromExplosion(state, level, pos, explosion);
    }

    static private <B extends net.minecraft.world.level.block.Block> com.mojang.serialization.MapCodec<B> native$BlockCodecPlatform$simple(java.util.function.Function<net.minecraft.world.level.block.state.BlockBehaviour.Properties, B> factory) {
        // Vanilla 1.21's Properties codec is a unit codec. Retain that schema for shared block definitions.
        return com.mojang.serialization.codecs.RecordCodecBuilder.mapCodec(instance -> instance.group(com.mojang.serialization.Codec.unit(net.minecraft.world.level.block.state.BlockBehaviour.Properties::of).fieldOf("properties").forGetter((B block) -> net.minecraft.world.level.block.state.BlockBehaviour.Properties.copy(block))).apply(instance, factory));
    }
}
