package dev.tc4port.thaumcraft.api.golem;

import java.util.Objects;
import java.util.Set;
import net.minecraft.core.BlockPos;
import net.minecraft.world.phys.Vec3;

/**
 * Current spatial interpretation of one semantic target.
 *
 * @param routeRevision stable while the navigation topology is unchanged;
 *                      change it when the golem crosses into another space
 * @param interactionPoint world point used for looking and progress display
 * @param navigationTarget primary target in the navigator's current frame
 * @param pathTargets optional exact path candidates; an empty set asks the
 *                    core to derive ordinary collision-checked candidates;
 *                    explicit sets are bounded by {@link #MAX_PATH_TARGETS}
 * @param distanceSqr adapter-aware squared distance to the final interaction
 */
public record GolemTravelFrame(long routeRevision, Vec3 interactionPoint, BlockPos navigationTarget, Set<BlockPos> pathTargets, double distanceSqr) {

    public static final int MAX_PATH_TARGETS = 64;

    public GolemTravelFrame {
        interactionPoint = requireFinite(interactionPoint, "interactionPoint");
        navigationTarget = Objects.requireNonNull(navigationTarget, "navigationTarget").immutable();
        Objects.requireNonNull(pathTargets, "pathTargets");
        if (pathTargets.size() > MAX_PATH_TARGETS) {
            throw new IllegalArgumentException("pathTargets must not exceed " + MAX_PATH_TARGETS);
        }
        pathTargets = pathTargets.stream().map(BlockPos::immutable).collect(java.util.stream.Collectors.toUnmodifiableSet());
        if (!Double.isFinite(distanceSqr) || distanceSqr < 0.0) {
            throw new IllegalArgumentException("distanceSqr must be finite and non-negative");
        }
    }

    public static GolemTravelFrame simple(long routeRevision, Vec3 interactionPoint, BlockPos navigationTarget, double distanceSqr) {
        return new GolemTravelFrame(routeRevision, interactionPoint, navigationTarget, Set.of(), distanceSqr);
    }

    private static Vec3 requireFinite(Vec3 point, String name) {
        Objects.requireNonNull(point, name);
        if (!Double.isFinite(point.x) || !Double.isFinite(point.y) || !Double.isFinite(point.z)) {
            throw new IllegalArgumentException(name + " must be finite");
        }
        return point;
    }
}
