package dev.tc4port.thaumcraft.api.focus;

import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;

/**
 * Owner-class adapter for a component-synchronized, non-stackable focus
 * container. Implementing items must have a maximum stack size of one.
 */
public interface FocusInventorySourceItem {

    /**
     * Opens a view over {@code source}. Mutating operations update only that
     * supplied stack, letting TC transact on a copy before replacing its slot.
     */
    FocusInventoryView focusInventory(ItemStack source);

    /**
     * Opens the authoritative server view for {@code player}. Owners may
     * override this overload to enforce binding or access permissions.
     */
    default FocusInventoryView focusInventory(ServerPlayer player, ItemStack source) {
        return focusInventory(source);
    }
}
