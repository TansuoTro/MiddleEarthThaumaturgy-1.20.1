package dev.tc4port.thaumcraft.api;

import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.entity.BlockEntityType;

/**
 * Native registered content by stable Thaumcraft path. Call after registration.
 */
public final class ThaumcraftContent {

    private ThaumcraftContent() {
    }

    public static Item item(String path) {
        return require(BuiltInRegistries.ITEM, path);
    }

    public static Block block(String path) {
        return require(BuiltInRegistries.BLOCK, path);
    }

    public static SoundEvent sound(String path) {
        return require(BuiltInRegistries.SOUND_EVENT, path);
    }

    public static BlockEntityType<?> blockEntity(String path) {
        return require(BuiltInRegistries.BLOCK_ENTITY_TYPE, path);
    }

    private static <T> T require(Registry<T> registry, String path) {
        ResourceLocation id = net.minecraft.resources.ResourceLocation.fromNamespaceAndPath((java.lang.String) ("thaumcraft"), (java.lang.String) (path));
        return registry.getOptional(id).orElseThrow(() -> new IllegalArgumentException("Unregistered Thaumcraft content: " + id));
    }
}
