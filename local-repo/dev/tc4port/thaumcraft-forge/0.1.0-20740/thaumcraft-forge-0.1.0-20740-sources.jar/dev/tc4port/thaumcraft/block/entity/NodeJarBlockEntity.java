package dev.tc4port.thaumcraft.block.entity;

import dev.tc4port.thaumcraft.nativeimpl.state.ItemFields;
import com.mojang.serialization.DataResult;
import dev.tc4port.thaumcraft.api.aspect.AspectAmounts;
import dev.tc4port.thaumcraft.api.aspect.AspectId;
import dev.tc4port.thaumcraft.api.node.AuraNodeState;
import dev.tc4port.thaumcraft.api.node.AuraNodeView;
import dev.tc4port.thaumcraft.api.node.NodeVis;
import dev.tc4port.thaumcraft.client.InfusionSparkleEffects;
import dev.tc4port.thaumcraft.item.NodeJarItem;
import dev.tc4port.thaumcraft.registry.TCBlockEntities;
import dev.tc4port.thaumcraft.state.TCItemState;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.core.BlockPos;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.NbtOps;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import java.lang.Math;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityType;

/**
 * Persistent node payload for a node in a jar.
 */
public final class NodeJarBlockEntity extends net.minecraft.world.level.block.entity.BlockEntity implements AuraNodeView, ItemFields.Source {

    private static final String NODE_DATA = "NodeData";

    private AuraNodeState nodeState = AuraNodeState.EMPTY;

    public NodeJarBlockEntity(BlockPos pos, BlockState state) {
        super(TCBlockEntities.NODE_JAR.get(), pos, state);
    }

    @Override
    public AuraNodeState nodeState() {
        return this.nodeState;
    }

    @Override
    public AspectAmounts visibleAspects() {
        return this.nodeState.currentVis().positiveAmounts();
    }

    @Override
    public List<dev.tc4port.thaumcraft.api.aspect.AspectId> visibleAspectOrder() {
        return List.copyOf(this.nodeState().currentVis().amounts().keySet());
    }

    public void setNodeState(AuraNodeState data) {
        this.nodeState = data == null ? AuraNodeState.EMPTY : data;
        this.setChanged();
        if (this.level != null && !this.level.isClientSide) {
            this.level.sendBlockUpdated(this.worldPosition, this.getBlockState(), this.getBlockState(), Block.UPDATE_CLIENTS);
        }
    }

    /**
     * IAspectContainer#addToContainer capped the live store at the jar's
     * copied base store and returned the amount it could not accept.
     */
    public int addToContainer(AspectId aspect, int amount) {
        if (amount <= 0 || !this.nodeState.baseVis().amounts().containsKey(aspect)) {
            return amount;
        }
        int current = this.nodeState.currentVis().amount(aspect);
        int capacity = this.nodeState.baseVis().amount(aspect);
        int accepted = Math.min(amount, Math.max(0, capacity - current));
        if (accepted > 0) {
            LinkedHashMap<AspectId, Integer> updated = new LinkedHashMap<>(this.nodeState.currentVis().amounts());
            updated.put(aspect, current + accepted);
            this.setNodeState(this.nodeState.withCurrentVis(new NodeVis(updated)));
        }
        return amount - accepted;
    }

    public boolean takeFromContainer(AspectId aspect, int amount) {
        int current = this.nodeState.currentVis().amount(aspect);
        if (amount < 0 || current < amount) {
            return false;
        }
        LinkedHashMap<AspectId, Integer> updated = new LinkedHashMap<>(this.nodeState.currentVis().amounts());
        updated.put(aspect, current - amount);
        this.setNodeState(this.nodeState.withCurrentVis(new NodeVis(updated)));
        return true;
    }

    public boolean contains(AspectId aspect, int amount) {
        return this.nodeState.currentVis().amount(aspect) >= amount;
    }

    /**
     * Mirrors the remaining IAspectContainer query surface. The source jar
     * reported that it accepted every aspect even though addToContainer
     * returned the entire amount when that aspect had no copied base capacity.
     */
    public boolean accepts(AspectId aspect) {
        return true;
    }

    public int containerContains(AspectId aspect) {
        return this.nodeState.currentVis().amount(aspect);
    }

    public boolean containsAll(Map<AspectId, Integer> aspects) {
        for (Map.Entry<AspectId, Integer> entry : aspects.entrySet()) {
            if (!this.contains(entry.getKey(), entry.getValue())) {
                return false;
            }
        }
        return true;
    }

    /**
     * TileJarNode#takeFromContainer(AspectList) deliberately returned false.
     */
    public boolean takeFromContainer(Map<AspectId, Integer> aspects) {
        return false;
    }

    public void setNodeVisBase(AspectId aspect, int amount) {
        LinkedHashMap<AspectId, Integer> base = new LinkedHashMap<>(this.nodeState.baseVis().amounts());
        if (amount <= 0) {
            base.remove(aspect);
        } else {
            base.put(aspect, amount);
        }
        this.setNodeState(this.nodeState.withVis(new NodeVis(base), this.nodeState.currentVis()));
    }

    @Override
    public boolean triggerEvent(int id, int type) {
        if (id != 9) {
            return super.triggerEvent(id, type);
        }
        if (this.level != null && this.level.isClientSide) {
            /* TileJarNode used the shared blockSparkle source-quality gate. */
            for (int y = -1; y < 3; y++) {
                for (int x = -1; x < 2; x++) {
                    for (int z = -1; z < 2; z++) {
                        InfusionSparkleEffects.blockSparkle(this.level, this.worldPosition.offset(x, y, z), -9999, 5);
                    }
                }
            }
        }
        return true;
    }

    @Override
    public void load(CompoundTag tag) {
        super.load(tag);
        if (tag.contains(NODE_DATA)) {
            DataResult<AuraNodeState> decoded = AuraNodeState.CODEC.parse(NbtOps.INSTANCE, tag.get(NODE_DATA));
            decoded.result().ifPresent(this::setNodeState);
        }
    }

    @Override
    protected void saveAdditional(CompoundTag tag) {
        super.saveAdditional(tag);
        AuraNodeState.CODEC.encodeStart(NbtOps.INSTANCE, this.nodeState).result().ifPresent(encoded -> tag.put(NODE_DATA, encoded));
    }

    protected void readItemFields(ItemFields.Input input) {
        {
            dev.tc4port.thaumcraft.nativeimpl.state.ItemFields.Input native$bodyOperand$6199 = input;
            native$bodyReturn$6201: {
                if (true) {
                }
            }
        }
        this.nodeState = NodeJarItem.normalizeNodeState(input.getOrDefault(TCItemState.NODE, AuraNodeState.EMPTY));
    }

    public void copyItemFields(ItemFields.Output components) {
        {
            dev.tc4port.thaumcraft.nativeimpl.state.ItemFields.Output native$bodyOperand$6202 = components;
            native$bodyReturn$6204: {
                if (true) {
                }
            }
        }
        components.set(TCItemState.NODE, NodeJarItem.normalizeNodeState(this.nodeState));
    }

    public void removeComponentsFromTag(CompoundTag tag) {
        tag.remove(dev.tc4port.thaumcraft.block.entity.NodeJarBlockEntity.NODE_DATA);
    }

    @Override
    public CompoundTag getUpdateTag() {
        return this.saveWithoutMetadata();
    }

    @Override
    public Packet<ClientGamePacketListener> getUpdatePacket() {
        return ClientboundBlockEntityDataPacket.create(this);
    }

    protected final HolderLookup.Provider persistenceRegistries() {
        if (level != null)
            return level.registryAccess();
        var server = net.minecraftforge.server.ServerLifecycleHooks.getCurrentServer();
        return server != null ? server.registryAccess() : net.minecraft.core.RegistryAccess.fromRegistryOfRegistries(net.minecraft.core.registries.BuiltInRegistries.REGISTRY);
    }

    protected static net.minecraft.network.chat.Component parseCustomNameSafe(String value, HolderLookup.Provider registries) {
        try {
            return net.minecraft.network.chat.Component.Serializer.fromJson(value);
        } catch (RuntimeException exception) {
            return null;
        }
    }

    public void applyComponentsFromItemStack(ItemStack stack) {
        readItemFields(ItemFields.from(stack));
    }

    @Override
    public void saveToItem(ItemStack stack) {
        CompoundTag tag = saveWithoutMetadata();
        {
            net.minecraft.nbt.CompoundTag native$bodyOperand$6205 = tag;
            native$bodyReturn$6207: {
                if (true) {
                    native$bodyOperand$6205.remove(dev.tc4port.thaumcraft.block.entity.NodeJarBlockEntity.NODE_DATA);
                }
            }
        }
        net.minecraft.world.item.BlockItem.setBlockEntityData(stack, getType(), tag);
        copyItemFields(ItemFields.to(stack));
    }

    @Override
    public net.minecraft.world.phys.AABB getRenderBoundingBox() {
        return NodeJarBlockEntity.native$ClientBlockEntityBounds$bounds(this);
    }

    @Override()
    public void onDataPacket(net.minecraft.network.Connection connection, net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket packet) {
        handleUpdateTag(packet.getTag());
    }

    @SuppressWarnings({ "rawtypes", "unchecked" })
    static private net.minecraft.world.phys.AABB native$ClientBlockEntityBounds$bounds(net.minecraft.world.level.block.entity.BlockEntity blockEntity) {
        var renderer = net.minecraft.client.Minecraft.getInstance().getBlockEntityRenderDispatcher().getRenderer(blockEntity);
        return renderer instanceof dev.tc4port.thaumcraft.nativeimpl.NativeBlockEntityRenderer shared ? shared.getRenderBoundingBox(blockEntity) : new net.minecraft.world.phys.AABB(blockEntity.getBlockPos());
    }
}
