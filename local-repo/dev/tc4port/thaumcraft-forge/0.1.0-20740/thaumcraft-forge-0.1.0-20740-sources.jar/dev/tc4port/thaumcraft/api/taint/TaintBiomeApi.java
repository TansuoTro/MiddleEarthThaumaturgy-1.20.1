package dev.tc4port.thaumcraft.api.taint;

import dev.tc4port.thaumcraft.block.TaintSpreadLogic;
import java.util.Objects;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;

/**
 * Stable, bounded access to Thaumcraft's synchronized taint biome state.
 */
public final class TaintBiomeApi {

    private TaintBiomeApi() {
    }

    /**
     * Taints the modern biome column containing {@code position} while
     * retaining the restoration history used by ethereal blooms.
     *
     * <p>The mutation must run on the owning server thread and never loads a
     * chunk. One legacy block column maps to one horizontal 4x4 biome quart
     * cell in 1.21; Thaumcraft updates every vertical quart in that cell and
     * sends its normal biome synchronization packet. Reapplying the request
     * is intentional because it can repair absent legacy restoration
     * history.</p>
     */
    public static TaintBiomeChangeResult taintLoadedColumn(ServerLevel level, BlockPos position) {
        Objects.requireNonNull(level, "level");
        Objects.requireNonNull(position, "position");
        if (!level.getServer().isSameThread()) {
            return TaintBiomeChangeResult.OFF_SERVER_THREAD;
        }
        if (!level.hasChunkAt(position)) {
            return TaintBiomeChangeResult.CHUNK_UNLOADED;
        }
        TaintSpreadLogic.setTaintedBiomeColumn(level, position);
        return TaintBiomeChangeResult.APPLIED;
    }
}
