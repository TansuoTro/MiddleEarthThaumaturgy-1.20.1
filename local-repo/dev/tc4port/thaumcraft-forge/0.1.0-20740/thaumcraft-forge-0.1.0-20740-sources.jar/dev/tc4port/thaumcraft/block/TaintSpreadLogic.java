package dev.tc4port.thaumcraft.block;

import dev.tc4port.thaumcraft.common.TCGameplayParameters;
import dev.tc4port.thaumcraft.state.TCObjectState;
import dev.tc4port.thaumcraft.registry.TCBlocks;
import dev.tc4port.thaumcraft.registry.TCSounds;
import dev.tc4port.thaumcraft.registry.TCTags;
import dev.tc4port.thaumcraft.worldgen.TCBiomes;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.Holder;
import net.minecraft.core.QuartPos;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.tags.BlockTags;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.biome.Biome;
import net.minecraft.world.level.biome.Biomes;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.chunk.LevelChunk;
import net.minecraft.world.level.chunk.LevelChunkSection;
import net.minecraft.world.level.chunk.PalettedContainerRO;
import dev.tc4port.thaumcraft.registry.TCEffects;
import dev.tc4port.thaumcraft.common.TCServerConfig;

/**
 * Shared random-tick rules from TC4's BlockTaint and BlockTaintFibres.
 */
public final class TaintSpreadLogic {

    public record SpreadResult(boolean targetTainted, boolean fibresSpread) {
    }

    private TaintSpreadLogic() {
    }

    /**
     * Contact rule shared by every metadata variant of TC4's
     * BlockTaintFibres.
     */
    public static void applyFibrousContact(Level level, Entity entity) {
        if (level.isClientSide || !(entity instanceof LivingEntity livingEntity) || livingEntity.isInvertedHealAndHarm()) {
            return;
        }
        int chance = entity instanceof Player ? TCGameplayParameters.EFFECTS_TAINT_CONTACT_FIBRES_PLAYER_DENOMINATOR.intValue() : TCGameplayParameters.EFFECTS_TAINT_CONTACT_FIBRES_MOB_DENOMINATOR.intValue();
        if (level.random.nextInt(chance) == 0) {
            livingEntity.addEffect((switch(0) {
                default ->
                    {
                        net.minecraft.core.Holder<net.minecraft.world.effect.MobEffect> native$operand$13299 = ((net.minecraft.core.Holder<net.minecraft.world.effect.MobEffect>) (net.minecraft.core.Holder<?>) (TCEffects.FLUX_TAINT).getHolder().orElseThrow());
                        int native$operand$13300 = entity instanceof Player ? TCGameplayParameters.EFFECTS_TAINT_CONTACT_PLAYER_DURATION.intValue() : TCGameplayParameters.EFFECTS_TAINT_CONTACT_MOB_DURATION.intValue();
                        int native$operand$13301 = 0;
                        boolean native$operand$13302 = false;
                        boolean native$operand$13303 = true;
                        net.minecraft.world.effect.MobEffectInstance native$result$13304 = (new net.minecraft.world.effect.MobEffectInstance(native$operand$13299.value(), native$operand$13300, TaintSpreadLogic.native$MobEffectPlatform$safeAmplifier(native$operand$13299, native$operand$13301), native$operand$13302, native$operand$13303));
                        yield native$result$13304;
                    }
            }));
        }
    }

    /**
     * Stronger walking exposure used by TC4's crust and tainted-soil
     * metadata, but deliberately not by tainted flesh.
     */
    public static void applySolidContact(Level level, Entity entity) {
        if (level.isClientSide || !(entity instanceof LivingEntity livingEntity) || livingEntity.isInvertedHealAndHarm()) {
            return;
        }
        int chance = solidContactChance(entity instanceof Player);
        if (level.random.nextInt(chance) == 0) {
            livingEntity.addEffect((switch(0) {
                default ->
                    {
                        net.minecraft.core.Holder<net.minecraft.world.effect.MobEffect> native$operand$13305 = ((net.minecraft.core.Holder<net.minecraft.world.effect.MobEffect>) (net.minecraft.core.Holder<?>) (TCEffects.FLUX_TAINT).getHolder().orElseThrow());
                        int native$operand$13306 = solidContactDuration(entity instanceof Player);
                        int native$operand$13307 = 0;
                        boolean native$operand$13308 = false;
                        boolean native$operand$13309 = true;
                        net.minecraft.world.effect.MobEffectInstance native$result$13310 = (new net.minecraft.world.effect.MobEffectInstance(native$operand$13305.value(), native$operand$13306, TaintSpreadLogic.native$MobEffectPlatform$safeAmplifier(native$operand$13305, native$operand$13307), native$operand$13308, native$operand$13309));
                        yield native$result$13310;
                    }
            }));
        }
    }

    public static int solidContactChance(boolean player) {
        return player ? TCGameplayParameters.EFFECTS_TAINT_CONTACT_SOLID_PLAYER_DENOMINATOR.intValue() : TCGameplayParameters.EFFECTS_TAINT_CONTACT_SOLID_MOB_DENOMINATOR.intValue();
    }

    public static int solidContactDuration(boolean player) {
        return player ? TCGameplayParameters.EFFECTS_TAINT_CONTACT_PLAYER_DURATION.intValue() : TCGameplayParameters.EFFECTS_TAINT_CONTACT_MOB_DURATION.intValue();
    }

    /**
     * Runs the random destination branch after biome spreading/falling has
     * already been handled by the caller.
     */
    public static SpreadResult tickFibreSpreadTarget(ServerLevel level, BlockPos source, RandomSource random) {
        BlockPos target = selectSpreadTarget(source, random);
        if (!isTaintedAt(level, target)) {
            return new SpreadResult(false, false);
        }
        if (spreadFibres(level, target, random)) {
            return new SpreadResult(true, true);
        }
        int adjacentTaint = adjacentTaint(level, target);
        BlockState targetState = level.getBlockState(target);
        if (adjacentTaint >= 2 && isOrganicSolid(targetState)) {
            level.setBlock(target, TCBlocks.CRUSTED_TAINT.get().defaultBlockState(), 3);
        } else if (adjacentTaint >= 3 && !targetState.isAir() && isSoilLike(targetState)) {
            level.setBlock(target, TCBlocks.TAINTED_SOIL.get().defaultBlockState(), 3);
        }
        return new SpreadResult(true, false);
    }

    /**
     * BlockTaint's metadata-zero/one update path calls spreadFibres but never
     * executes BlockTaintFibres' organic/soil conversion tail.
     */
    public static SpreadResult tickSolidSpreadTarget(ServerLevel level, BlockPos source, RandomSource random) {
        BlockPos target = selectSpreadTarget(source, random);
        if (!isTaintedAt(level, target)) {
            return new SpreadResult(false, false);
        }
        return new SpreadResult(true, spreadFibres(level, target, random));
    }

    public static BlockPos selectSpreadTarget(BlockPos source, RandomSource random) {
        return source.offset(random.nextInt(3) - 1, random.nextInt(5) - 3, random.nextInt(3) - 1);
    }

    public static boolean spreadFibres(ServerLevel level, BlockPos target, RandomSource random) {
        BlockState current = level.getBlockState(target);
        if (!touchesSolid(level, target) || isOnlyAdjacentToTaint(level, target) || !current.getFluidState().isEmpty() || current.is(TCTags.TAINT) || !(current.isAir() || current.canBeReplaced() || current.is(BlockTags.FLOWERS) || current.is(BlockTags.LEAVES))) {
            return false;
        }
        BlockState replacement;
        if (random.nextInt(10) != 0 || !level.getBlockState(target.above()).isAir() || !level.getBlockState(target.below()).isFaceSturdy(level, target.below(), Direction.UP)) {
            replacement = TCBlocks.FIBROUS_TAINT.get().stateForPlacement(level, target);
        } else if (random.nextInt(10) < 9) {
            replacement = TCBlocks.TAINTED_GRASS.get().defaultBlockState();
        } else if (random.nextInt(12) < 10) {
            replacement = TCBlocks.TAINTED_PLANT.get().defaultBlockState();
        } else {
            replacement = TCBlocks.SPORE_STALK.get().defaultBlockState();
        }
        level.setBlock(target, replacement, 3);
        level.playSound(null, target, TCSounds.ROOTS.get(), net.minecraft.sounds.SoundSource.BLOCKS, 0.1F, 0.9F + random.nextFloat() * 0.2F);
        return true;
    }

    public static int adjacentTaint(ServerLevel level, BlockPos pos) {
        int count = 0;
        for (Direction direction : Direction.values()) {
            if (level.getBlockState(pos.relative(direction)).is(TCTags.TAINT)) {
                count++;
            }
        }
        return count;
    }

    public static boolean isOnlyAdjacentToTaint(ServerLevel level, BlockPos pos) {
        for (Direction direction : Direction.values()) {
            BlockState neighbor = level.getBlockState(pos.relative(direction));
            if (!neighbor.isAir() && !neighbor.is(TCTags.TAINT)) {
                return false;
            }
        }
        return true;
    }

    private static boolean touchesSolid(ServerLevel level, BlockPos pos) {
        for (Direction direction : Direction.values()) {
            BlockPos neighborPos = pos.relative(direction);
            if (level.getBlockState(neighborPos).isFaceSturdy(level, neighborPos, direction.getOpposite())) {
                return true;
            }
        }
        return false;
    }

    private static boolean isOrganicSolid(BlockState state) {
        return state.is(TCTags.TAINT_CONVERTS_TO_CRUSTED_TAINT);
    }

    private static boolean isSoilLike(BlockState state) {
        return state.is(TCTags.TAINT_CONVERTS_TO_TAINTED_SOIL);
    }

    public static boolean spreadBiome(ServerLevel level, BlockPos source, RandomSource random) {
        int spreadRate = TCServerConfig.taintSpreadRate();
        if (spreadRate <= 0) {
            return false;
        }
        int offsetX = random.nextInt(3) - 1;
        int offsetZ = random.nextInt(3) - 1;
        BlockPos target = source.offset(offsetX, 0, offsetZ);
        if (isTaintedAt(level, target) || random.nextInt(spreadRate * 5) != 0 || adjacentTaint(level, source) < 2) {
            return false;
        }
        setTaintedBiomeColumn(level, target);
        level.playSound(null, source, TCSounds.ROOTS.get(), net.minecraft.sounds.SoundSource.BLOCKS, 0.1F, 0.9F + level.random.nextFloat() * 0.2F);
        return true;
    }

    /**
     * Uses the exact stored 1.21 biome cell. BiomeManager#getBiome applies a
     * fuzzy boundary sampler, which is desirable for ambience but would make
     * a freshly converted taint cell randomly fail its own survival rules.
     */
    public static boolean isTaintedAt(Level level, BlockPos pos) {
        return level.getNoiseBiome(QuartPos.fromBlock(pos.getX()), QuartPos.fromBlock(pos.getY()), QuartPos.fromBlock(pos.getZ())).is(TCBiomes.TAINTED_LAND);
    }

    /**
     * 1.21 stores biomes at 4x4x4 quart resolution rather than TC4's
     * one-column resolution. Changing the complete 4x4 vertical biome cell is
     * the closest stable equivalent and prevents an artificial horizontal
     * seam between underground and surface biome queries.
     */
    public static void setTaintedBiomeColumn(ServerLevel level, BlockPos pos) {
        setSpecialBiomeColumn(level, pos, TCBiomes.TAINTED_LAND);
    }

    /**
     * Modern counterpart to TC4's {@code Utils.setBiomeAt}. A legacy biome
     * column maps to one horizontal quart cell in 1.21, so every vertical
     * quart in that cell is replaced together. The original cells remain in
     * the same history attachment used by ethereal-bloom restoration.
     */
    public static void setSpecialBiomeColumn(ServerLevel level, BlockPos pos, ResourceKey<Biome> replacementKey) {
        Holder<Biome> replacement = level.registryAccess().registryOrThrow(Registries.BIOME).getHolderOrThrow(replacementKey);
        Holder<Biome> plains = level.registryAccess().registryOrThrow(Registries.BIOME).getHolderOrThrow(Biomes.PLAINS);
        LevelChunk chunk = level.getChunkAt(pos);
        int targetQuartX = QuartPos.quartLocal(QuartPos.fromBlock(pos.getX()));
        int targetQuartZ = QuartPos.quartLocal(QuartPos.fromBlock(pos.getZ()));
        int quartChunkX = QuartPos.fromBlock(chunk.getPos().getMinBlockX());
        int quartChunkZ = QuartPos.fromBlock(chunk.getPos().getMinBlockZ());
        var history = TCObjectState.TAINT_BIOME_HISTORY.get(chunk);
        for (int sectionY = chunk.getMinSection(); sectionY < chunk.getMaxSection(); sectionY++) {
            LevelChunkSection section = chunk.getSection(chunk.getSectionIndexFromSectionY(sectionY));
            PalettedContainerRO<Holder<Biome>> oldBiomes = section.getBiomes();
            for (int localY = 0; localY < 4; localY++) {
                Holder<Biome> oldBiome = oldBiomes.get(targetQuartX, localY, targetQuartZ);
                int quartY = QuartPos.fromSection(sectionY) + localY;
                if (history.originalAt(targetQuartX, quartY, targetQuartZ).isBlank()) {
                    Holder<Biome> baseline = oldBiome;
                    if (isSpecialBiome(oldBiome)) {
                        baseline = generatedRestorationBiome(level, quartChunkX + targetQuartX, quartY, quartChunkZ + targetQuartZ, plains);
                    }
                    String baselineId = baseline.unwrapKey().map(key -> key.location().toString()).orElse("");
                    history = history.remember(targetQuartX, quartY, targetQuartZ, baselineId);
                }
            }
            dev.tc4port.thaumcraft.block.TaintSpreadLogic.native$subscription$11235(section, targetQuartX, targetQuartZ, replacement);
        }
        TCObjectState.TAINT_BIOME_HISTORY.set(chunk, history);
        chunk.setUnsaved(true);
        sendBiomeUpdate(level, chunk);
    }

    /**
     * Restores the exact non-special pre-taint quart cells saved by
     * {@link #setTaintedBiomeColumn}. A missing or special history entry is
     * resolved through the unchanged biome source. Generated Tainted Land is
     * then replaced with plains, matching TC4's explicit fallback.
     */
    public static void restoreOriginalBiomeColumn(ServerLevel level, BlockPos pos) {
        var biomeRegistry = level.registryAccess().registryOrThrow(Registries.BIOME);
        Holder<Biome> plains = biomeRegistry.getHolderOrThrow(Biomes.PLAINS);
        LevelChunk chunk = level.getChunkAt(pos);
        int targetQuartX = QuartPos.quartLocal(QuartPos.fromBlock(pos.getX()));
        int targetQuartZ = QuartPos.quartLocal(QuartPos.fromBlock(pos.getZ()));
        int quartChunkX = QuartPos.fromBlock(chunk.getPos().getMinBlockX());
        int quartChunkZ = QuartPos.fromBlock(chunk.getPos().getMinBlockZ());
        var history = TCObjectState.TAINT_BIOME_HISTORY.get(chunk);
        for (int sectionY = chunk.getMinSection(); sectionY < chunk.getMaxSection(); sectionY++) {
            LevelChunkSection section = chunk.getSection(chunk.getSectionIndexFromSectionY(sectionY));
            int sectionQuartY = QuartPos.fromSection(sectionY);
            dev.tc4port.thaumcraft.block.TaintSpreadLogic.native$subscription$11246(section, targetQuartX, targetQuartZ, sectionQuartY, history, targetQuartX, targetQuartZ, biomeRegistry, level, quartChunkX, quartChunkZ, plains);
        }
        TCObjectState.TAINT_BIOME_HISTORY.set(chunk, history.forgetColumn(targetQuartX, targetQuartZ));
        chunk.setUnsaved(true);
        sendBiomeUpdate(level, chunk);
    }

    private static boolean isSpecialBiome(Holder<Biome> biome) {
        return biome.is(TCBiomes.TAINTED_LAND) || biome.is(TCBiomes.EERIE) || biome.is(TCBiomes.MAGICAL_FOREST);
    }

    /**
     * Modern equivalent of TC4's WorldChunkManager#loadBlockGeneratorData:
     * sample the immutable generation biome instead of the biome palette that
     * runtime taint and nodes have already rewritten.
     */
    private static Holder<Biome> generatedRestorationBiome(ServerLevel level, int quartX, int quartY, int quartZ, Holder<Biome> plains) {
        Holder<Biome> generated = level.getChunkSource().getGenerator().getBiomeSource().getNoiseBiome(quartX, quartY, quartZ, level.getChunkSource().randomState().sampler());
        return generated.is(TCBiomes.TAINTED_LAND) ? plains : generated;
    }

    private static void sendBiomeUpdate(ServerLevel level, LevelChunk chunk) {
        level.getChunkSource().chunkMap.resendBiomesForChunks(java.util.List.of(chunk));
    }

    private static net.minecraft.core.Holder<net.minecraft.world.level.biome.Biome> native$listener$11245(int localY, int native$listenerCapture$11236, dev.tc4port.thaumcraft.data.TaintBiomeHistoryData native$listenerCapture$11237, int native$listenerCapture$11238, int native$listenerCapture$11239, net.minecraft.core.Registry<net.minecraft.world.level.biome.Biome> native$listenerCapture$11240, net.minecraft.server.level.ServerLevel native$listenerCapture$11241, int native$listenerCapture$11242, int native$listenerCapture$11243, net.minecraft.core.Holder<net.minecraft.world.level.biome.Biome> native$listenerCapture$11244) {
        int quartY = native$listenerCapture$11236 + localY;
        java.lang.String original = native$listenerCapture$11237.originalAt(native$listenerCapture$11238, quartY, native$listenerCapture$11239);
        net.minecraft.resources.ResourceLocation location = net.minecraft.resources.ResourceLocation.tryParse(original);
        if (location != null) {
            var restored = native$listenerCapture$11240.getHolder(net.minecraft.resources.ResourceKey.create(net.minecraft.core.registries.Registries.BIOME, location)).orElse(null);
            if (restored != null && !isSpecialBiome(restored)) {
                return restored;
            }
        }
        return generatedRestorationBiome(native$listenerCapture$11241, native$listenerCapture$11242 + native$listenerCapture$11238, quartY, native$listenerCapture$11243 + native$listenerCapture$11239, native$listenerCapture$11244);
    }

    static private void native$subscription$11235(net.minecraft.world.level.chunk.LevelChunkSection section, int x, int z, net.minecraft.core.Holder<net.minecraft.world.level.biome.Biome> native$listenerCapture$11233) {
        // Resolve before mutation: callbacks can read the previous column.
        var column = java.util.List.of((net.minecraft.core.Holder<net.minecraft.world.level.biome.Biome>) ((switch(0) {
            default ->
                {
                    int native$operand$16048 = (int) (0);
                    net.minecraft.core.Holder<net.minecraft.world.level.biome.Biome> native$operand$16049 = native$listenerCapture$11233;
                    net.minecraft.core.Holder<net.minecraft.world.level.biome.Biome> native$result$16050 = (native$operand$16049);
                    yield native$result$16050;
                }
        })), (net.minecraft.core.Holder<net.minecraft.world.level.biome.Biome>) ((switch(0) {
            default ->
                {
                    int native$operand$16051 = (int) (1);
                    net.minecraft.core.Holder<net.minecraft.world.level.biome.Biome> native$operand$16052 = native$listenerCapture$11233;
                    net.minecraft.core.Holder<net.minecraft.world.level.biome.Biome> native$result$16053 = (native$operand$16052);
                    yield native$result$16053;
                }
        })), (net.minecraft.core.Holder<net.minecraft.world.level.biome.Biome>) ((switch(0) {
            default ->
                {
                    int native$operand$16054 = (int) (2);
                    net.minecraft.core.Holder<net.minecraft.world.level.biome.Biome> native$operand$16055 = native$listenerCapture$11233;
                    net.minecraft.core.Holder<net.minecraft.world.level.biome.Biome> native$result$16056 = (native$operand$16055);
                    yield native$result$16056;
                }
        })), (net.minecraft.core.Holder<net.minecraft.world.level.biome.Biome>) ((switch(0) {
            default ->
                {
                    int native$operand$16057 = (int) (3);
                    net.minecraft.core.Holder<net.minecraft.world.level.biome.Biome> native$operand$16058 = native$listenerCapture$11233;
                    net.minecraft.core.Holder<net.minecraft.world.level.biome.Biome> native$result$16059 = (native$operand$16058);
                    yield native$result$16059;
                }
        })));
        var previous = section.getBiomes();
        if (previous instanceof net.minecraft.world.level.chunk.PalettedContainer<net.minecraft.core.Holder<net.minecraft.world.level.biome.Biome>> palette) {
            int y = 0;
            for (; y < 4; y++) {
                try {
                    // Native palettes already grow only when their capacity is exhausted.
                    palette.set(x, y, z, column.get(y));
                } catch (java.lang.IllegalArgumentException failedResize) {
                    // A copied palette can resize its former owner, leaving this storage
                    // too small for the returned ID. Rebuild instead of losing the update.
                    break;
                }
                // A stale resize callback can also return an in-range ID for a different
                // biome. Detect that silent failure without scanning the palette.
                if (palette.get(x, y, z) != column.get(y))
                    break;
            }
            if (y == 4)
                return;
        }
        // Recreate and install storage only for read-only or broken containers. Replace
        // the whole target column, including any cells written before a failed resize.
        section.fillBiomesFromNoise((qx, qy, qz, sampler) -> qx == x && qz == z ? column.get(qy) : previous.get(qx, qy, qz), null, 0, 0, 0);
    }

    static private void native$subscription$11246(net.minecraft.world.level.chunk.LevelChunkSection section, int x, int z, int native$listenerCapture$11236, dev.tc4port.thaumcraft.data.TaintBiomeHistoryData native$listenerCapture$11237, int native$listenerCapture$11238, int native$listenerCapture$11239, net.minecraft.core.Registry<net.minecraft.world.level.biome.Biome> native$listenerCapture$11240, net.minecraft.server.level.ServerLevel native$listenerCapture$11241, int native$listenerCapture$11242, int native$listenerCapture$11243, net.minecraft.core.Holder<net.minecraft.world.level.biome.Biome> native$listenerCapture$11244) {
        // Resolve before mutation: callbacks can read the previous column.
        var column = java.util.List.of((net.minecraft.core.Holder<net.minecraft.world.level.biome.Biome>) (dev.tc4port.thaumcraft.block.TaintSpreadLogic.native$listener$11245((int) (0), native$listenerCapture$11236, native$listenerCapture$11237, native$listenerCapture$11238, native$listenerCapture$11239, native$listenerCapture$11240, native$listenerCapture$11241, native$listenerCapture$11242, native$listenerCapture$11243, native$listenerCapture$11244)), (net.minecraft.core.Holder<net.minecraft.world.level.biome.Biome>) (dev.tc4port.thaumcraft.block.TaintSpreadLogic.native$listener$11245((int) (1), native$listenerCapture$11236, native$listenerCapture$11237, native$listenerCapture$11238, native$listenerCapture$11239, native$listenerCapture$11240, native$listenerCapture$11241, native$listenerCapture$11242, native$listenerCapture$11243, native$listenerCapture$11244)), (net.minecraft.core.Holder<net.minecraft.world.level.biome.Biome>) (dev.tc4port.thaumcraft.block.TaintSpreadLogic.native$listener$11245((int) (2), native$listenerCapture$11236, native$listenerCapture$11237, native$listenerCapture$11238, native$listenerCapture$11239, native$listenerCapture$11240, native$listenerCapture$11241, native$listenerCapture$11242, native$listenerCapture$11243, native$listenerCapture$11244)), (net.minecraft.core.Holder<net.minecraft.world.level.biome.Biome>) (dev.tc4port.thaumcraft.block.TaintSpreadLogic.native$listener$11245((int) (3), native$listenerCapture$11236, native$listenerCapture$11237, native$listenerCapture$11238, native$listenerCapture$11239, native$listenerCapture$11240, native$listenerCapture$11241, native$listenerCapture$11242, native$listenerCapture$11243, native$listenerCapture$11244)));
        var previous = section.getBiomes();
        if (previous instanceof net.minecraft.world.level.chunk.PalettedContainer<net.minecraft.core.Holder<net.minecraft.world.level.biome.Biome>> palette) {
            int y = 0;
            for (; y < 4; y++) {
                try {
                    // Native palettes already grow only when their capacity is exhausted.
                    palette.set(x, y, z, column.get(y));
                } catch (java.lang.IllegalArgumentException failedResize) {
                    // A copied palette can resize its former owner, leaving this storage
                    // too small for the returned ID. Rebuild instead of losing the update.
                    break;
                }
                // A stale resize callback can also return an in-range ID for a different
                // biome. Detect that silent failure without scanning the palette.
                if (palette.get(x, y, z) != column.get(y))
                    break;
            }
            if (y == 4)
                return;
        }
        // Recreate and install storage only for read-only or broken containers. Replace
        // the whole target column, including any cells written before a failed resize.
        section.fillBiomesFromNoise((qx, qy, qz, sampler) -> qx == x && qz == z ? column.get(qy) : previous.get(qx, qy, qz), null, 0, 0, 0);
    }

    /**
     * Native shift-based effects need a smaller ceiling than the stored amplifier byte.
     */
    static private int native$MobEffectPlatform$safeAmplifier(net.minecraft.core.Holder<net.minecraft.world.effect.MobEffect> effect, int amplifier) {
        net.minecraft.world.effect.MobEffect type = effect.value();
        int maximum = type == net.minecraft.world.effect.MobEffects.HEAL || type == net.minecraft.world.effect.MobEffects.HARM ? 16 : type == net.minecraft.world.effect.MobEffects.REGENERATION || type == net.minecraft.world.effect.MobEffects.POISON || type == net.minecraft.world.effect.MobEffects.WITHER ? 31 : 127;
        return java.lang.Math.max(0, java.lang.Math.min(maximum, amplifier));
    }
}
