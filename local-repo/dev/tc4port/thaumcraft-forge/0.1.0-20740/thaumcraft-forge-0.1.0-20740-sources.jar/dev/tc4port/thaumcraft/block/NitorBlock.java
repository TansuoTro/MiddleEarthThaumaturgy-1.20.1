package dev.tc4port.thaumcraft.block;

import com.mojang.serialization.MapCodec;
import dev.tc4port.thaumcraft.block.entity.NitorBlockEntity;
import dev.tc4port.thaumcraft.registry.Nitors;
import dev.tc4port.thaumcraft.client.SparkleParticle;
import javax.annotation.Nullable;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.core.BlockPos;
import net.minecraft.util.RandomSource;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityTicker;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.VoxelShape;
import dev.tc4port.thaumcraft.nativeimpl.ClientExtensionTarget;
import dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.level.pathfinder.PathComputationType;
import net.minecraft.world.level.Explosion;

/**
 * ItemResource metadata 1 placed BlockAiry metadata 1: an invisible,
 * non-colliding but selectable 0.4-block light source with a TileNitor.
 */
public final class NitorBlock extends net.minecraft.world.level.block.BaseEntityBlock implements dev.tc4port.thaumcraft.nativeimpl.ClientExtensionTarget {

    // Forge calls initializeClient from the native superclass constructor. Do not add a field initializer.
    private java.util.function.Consumer<net.minecraftforge.client.extensions.common.IClientBlockExtensions> platform$clientInstaller;

    private static final VoxelShape SHAPE = Block.box(4.8, 4.8, 4.8, 11.2, 11.2, 11.2);

    public NitorBlock(BlockBehaviour.Properties properties) {
        this(properties, properties, true);
    }

    @Nullable
    @Override
    public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        return new NitorBlockEntity(pos, state);
    }

    @Nullable
    @Override
    public <T extends BlockEntity> BlockEntityTicker<T> getTicker(Level level, BlockState state, BlockEntityType<T> type) {
        return level.isClientSide ? createTickerHelper(type, Nitors.type(), NitorBlockEntity::clientTick) : null;
    }

    @Override
    public RenderShape getRenderShape(BlockState state) {
        return RenderShape.INVISIBLE;
    }

    @Override
    public VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
        return SHAPE;
    }

    @Override
    public boolean isPathfindable(BlockState state, net.minecraft.world.level.BlockGetter level, BlockPos pos, net.minecraft.world.level.pathfinder.PathComputationType type) {
        return true;
    }

    @Override
    public void animateTick(BlockState state, Level level, BlockPos pos, RandomSource random) {
        SparkleParticle.spawnType(level, pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5, pos.getX() + 0.5 + (random.nextFloat() - random.nextFloat()) / 3.0F, pos.getY() + 0.5 + (random.nextFloat() - random.nextFloat()) / 3.0F, pos.getZ() + 0.5 + (random.nextFloat() - random.nextFloat()) / 3.0F, 1.0F, 6, 3, 0.05F, true);
    }

    public static final MapCodec<NitorBlock> CODEC = NitorBlock.native$BlockCodecPlatform$simple(NitorBlock::new);

    protected MapCodec<? extends NitorBlock> codec() {
        return CODEC;
    }

    @Override
    public ItemStack getCloneItemStack(BlockState state, net.minecraft.world.phys.HitResult hit, net.minecraft.world.level.BlockGetter level, BlockPos pos, net.minecraft.world.entity.player.Player player) {
        return Nitors.stack();
    }

    private NitorBlock(net.minecraft.world.level.block.state.BlockBehaviour.Properties native$NativeEntityBlock$arg0, BlockBehaviour.Properties properties, boolean native$NativeEntityBlock$captured) {
        super(native$NativeEntityBlock$arg0);
    }

    @Override
    public void initializeClient(java.util.function.Consumer<net.minecraftforge.client.extensions.common.IClientBlockExtensions> installer) {
        platform$clientInstaller = installer;
        super.initializeClient(installer);
    }

    @Override
    public void platform$clientExtension(Object extension) {
        java.util.Objects.requireNonNull(platform$clientInstaller, "Forge initializeClient must run before client extension registration").accept((net.minecraftforge.client.extensions.common.IClientBlockExtensions) extension);
    }

    @Override
    public InteractionResult use(BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
        ItemUseResult result = (switch(0) {
            default ->
                {
                    net.minecraft.world.item.ItemStack native$bodyOperand$4617 = player.getItemInHand(hand);
                    net.minecraft.world.level.block.state.BlockState native$bodyOperand$4618 = state;
                    net.minecraft.world.level.Level native$bodyOperand$4619 = level;
                    net.minecraft.core.BlockPos native$bodyOperand$4620 = pos;
                    net.minecraft.world.entity.player.Player native$bodyOperand$4621 = player;
                    net.minecraft.world.InteractionHand native$bodyOperand$4622 = hand;
                    net.minecraft.world.phys.BlockHitResult native$bodyOperand$4623 = hit;
                    dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult native$bodyResult$4624 = null;
                    native$bodyReturn$4625: {
                        if (true) {
                            {
                                native$bodyResult$4624 = dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
                                break native$bodyReturn$4625;
                            }
                        }
                    }
                    yield native$bodyResult$4624;
                }
        });
        return result == ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION ? (hand == InteractionHand.MAIN_HAND ? (switch(0) {
            default ->
                {
                    net.minecraft.world.level.block.state.BlockState native$bodyOperand$3794 = state;
                    net.minecraft.world.level.Level native$bodyOperand$3795 = level;
                    net.minecraft.core.BlockPos native$bodyOperand$3796 = pos;
                    net.minecraft.world.entity.player.Player native$bodyOperand$3797 = player;
                    net.minecraft.world.phys.BlockHitResult native$bodyOperand$3798 = hit;
                    net.minecraft.world.InteractionResult native$bodyResult$3799 = null;
                    native$bodyReturn$3800: {
                        if (true) {
                            {
                                native$bodyResult$3799 = super.use(native$bodyOperand$3794, native$bodyOperand$3795, native$bodyOperand$3796, native$bodyOperand$3797, net.minecraft.world.InteractionHand.MAIN_HAND, native$bodyOperand$3798);
                                break native$bodyReturn$3800;
                            }
                        }
                    }
                    yield native$bodyResult$3799;
                }
        }) : InteractionResult.PASS) : result.result();
    }

    protected ItemUseResult interactWithItem(ItemStack stack, BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
        return dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
    }

    protected InteractionResult interactWithoutItem(BlockState state, Level level, BlockPos pos, Player player, BlockHitResult hit) {
        return super.use(state, level, pos, player, net.minecraft.world.InteractionHand.MAIN_HAND, hit);
    }

    @Override
    public void playerWillDestroy(Level level, BlockPos pos, BlockState state, Player player) {
        {
            net.minecraft.world.level.Level native$bodyOperand$5942 = level;
            net.minecraft.core.BlockPos native$bodyOperand$5943 = pos;
            net.minecraft.world.level.block.state.BlockState native$bodyOperand$5944 = state;
            net.minecraft.world.entity.player.Player native$bodyOperand$5945 = player;
            net.minecraft.world.level.block.state.BlockState native$bodyResult$5946 = null;
            native$bodyReturn$5947: {
                if (true) {
                    super.playerWillDestroy(native$bodyOperand$5942, native$bodyOperand$5943, native$bodyOperand$5944, native$bodyOperand$5945);
                    {
                        native$bodyResult$5946 = native$bodyOperand$5944;
                        break native$bodyReturn$5947;
                    }
                }
            }
        }
    }

    public BlockState beforePlayerDestroy(Level level, BlockPos pos, BlockState state, Player player) {
        super.playerWillDestroy(level, pos, state, player);
        return state;
    }

    protected boolean survivesSharedExplosion() {
        return false;
    }

    public int getExpDrop(net.minecraft.world.level.block.state.BlockState native$callbackInput$1050, net.minecraft.world.level.LevelReader native$callbackInput$1051, net.minecraft.util.RandomSource native$callbackInput$1052, net.minecraft.core.BlockPos native$callbackInput$1053, int native$callbackInput$1054, int native$callbackInput$1055) {
        net.minecraft.world.level.block.state.BlockState state = native$callbackInput$1050;
        net.minecraft.util.RandomSource random = native$callbackInput$1052;
        return 0;
    }

    @Override
    public void onBlockExploded(BlockState state, Level level, BlockPos pos, Explosion explosion) {
        if (!(switch(0) {
            default ->
                {
                    boolean native$bodyResult$5299 = false;
                    native$bodyReturn$5300: {
                        if (true) {
                            {
                                native$bodyResult$5299 = false;
                                break native$bodyReturn$5300;
                            }
                        }
                    }
                    yield native$bodyResult$5299;
                }
        }))
            super.onBlockExploded(state, level, pos, explosion);
    }

    @Override
    public boolean canDropFromExplosion(BlockState state, BlockGetter level, BlockPos pos, Explosion explosion) {
        return !(switch(0) {
            default ->
                {
                    boolean native$bodyResult$4626 = false;
                    native$bodyReturn$4627: {
                        if (true) {
                            {
                                native$bodyResult$4626 = false;
                                break native$bodyReturn$4627;
                            }
                        }
                    }
                    yield native$bodyResult$4626;
                }
        }) && super.canDropFromExplosion(state, level, pos, explosion);
    }

    static private <B extends net.minecraft.world.level.block.Block> com.mojang.serialization.MapCodec<B> native$BlockCodecPlatform$simple(java.util.function.Function<net.minecraft.world.level.block.state.BlockBehaviour.Properties, B> factory) {
        // Vanilla 1.21's Properties codec is a unit codec. Retain that schema for shared block definitions.
        return com.mojang.serialization.codecs.RecordCodecBuilder.mapCodec(instance -> instance.group(com.mojang.serialization.Codec.unit(net.minecraft.world.level.block.state.BlockBehaviour.Properties::of).fieldOf("properties").forGetter((B block) -> net.minecraft.world.level.block.state.BlockBehaviour.Properties.copy(block))).apply(instance, factory));
    }
}
