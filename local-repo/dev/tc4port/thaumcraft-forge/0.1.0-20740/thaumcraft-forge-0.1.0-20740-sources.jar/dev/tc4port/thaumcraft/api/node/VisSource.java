package dev.tc4port.thaumcraft.api.node;

import dev.tc4port.thaumcraft.api.aspect.VisAction;
import dev.tc4port.thaumcraft.api.aspect.VisChannel;
import javax.annotation.Nullable;
import net.minecraft.core.BlockPos;

/**
 * A native capability supplying centivis to the Vis network.
 */
public interface VisSource {

    boolean canSupplyVis();

    /**
     * Host position for a wireless source, or its adjacent physical relay; null disables supply.
     */
    @Nullable
    BlockPos networkEndpoint();

    /**
     * Stable identity of shared storage for one simulation. Sources backed by
     * the same reservoir must return equal identities. Forwarders that drain
     * another public relay inherit its leaf reservations automatically.
     */
    default Object simulationIdentity() {
        return this;
    }

    /**
     * Returns 0..amount centivis. SIMULATE must never change energy, storage or
     * effects. For a leaf store, subtract reservedCentivis from its available
     * balance before applying the per-call transfer limit. EXECUTE always
     * passes zero reservations. Pure forwarders use drainRelay with the same
     * channel/action; its leaf reservations are inherited and unaccepted
     * simulated transfers are released by the caller's scope.
     */
    int takeVis(VisChannel channel, int amount, VisAction action, int reservedCentivis);
}
