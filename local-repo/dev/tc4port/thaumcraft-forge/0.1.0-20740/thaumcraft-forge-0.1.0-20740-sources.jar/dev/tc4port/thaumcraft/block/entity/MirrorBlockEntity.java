package dev.tc4port.thaumcraft.block.entity;

import dev.tc4port.thaumcraft.api.aspect.AspectDefinition;
import dev.tc4port.thaumcraft.block.MirrorBlock;
import dev.tc4port.thaumcraft.aspect.AspectCatalog;
import dev.tc4port.thaumcraft.api.aspect.AspectId;
import dev.tc4port.thaumcraft.api.aspect.VisChannel;
import dev.tc4port.thaumcraft.api.essentia.EssentiaApi;
import dev.tc4port.thaumcraft.api.essentia.EssentiaSearch;
import dev.tc4port.thaumcraft.api.essentia.EssentiaSource;
import dev.tc4port.thaumcraft.api.essentia.EssentiaTransferMode;
import dev.tc4port.thaumcraft.common.VisNetwork;
import dev.tc4port.thaumcraft.data.MirrorLinkData;
import dev.tc4port.thaumcraft.network.EssentiaSourcePayload;
import dev.tc4port.thaumcraft.registry.TCBlockEntities;
import java.util.ArrayList;
import java.util.List;
import javax.annotation.Nullable;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.SectionPos;
import net.minecraft.core.HolderLookup;
import net.minecraft.core.registries.Registries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;
import java.lang.Math;
import dev.tc4port.thaumcraft.nativeimpl.state.ItemFields;
import net.minecraft.world.level.block.entity.BlockEntityType;

/**
 * Complete state machine shared by TileMirror and TileMirrorEssentia.
 *
 * <p>The two registry blocks remain separate, but sharing one block-entity
 * type makes reciprocal validation atomic and prevents metadata-era type
 * confusion. The {@link #essentiaMirror()} check is always made before a
 * link is accepted.</p>
 */
public final class MirrorBlockEntity extends net.minecraft.world.level.block.entity.BlockEntity implements EssentiaSource, ItemFields.Source {

    private static final int INITIAL_RELINK_INTERVAL = 40;

    private static final int MAX_RELINK_INTERVAL = 600;

    private static final int ESSENTIA_REMOTE_RANGE = 8;

    @Nullable
    private MirrorLinkData link;

    // Native player harvest evaluates loot after onRemove has unlinked this endpoint.
    @Nullable
    private MirrorLinkData removedDropLink;

    private boolean linked;

    private int instability;

    private int count;

    private int relinkInterval = INITIAL_RELINK_INTERVAL;

    private final List<ItemStack> outputStacks = new ArrayList<>();

    private int syncedQueueSize;

    public MirrorBlockEntity(BlockPos pos, BlockState state) {
        super(TCBlockEntities.MIRROR.get(), pos, state);
    }

    public static void serverTick(Level level, BlockPos pos, BlockState state, MirrorBlockEntity mirror) {
        mirror.count++;
        if (!mirror.essentiaMirror()) {
            mirror.tickItemMirror();
        }
        if (mirror.count % mirror.relinkInterval == 0) {
            if (!mirror.isLinkValidSimple()) {
                mirror.relinkInterval = Math.min(MAX_RELINK_INTERVAL, mirror.relinkInterval + 20);
                mirror.restoreLink();
            } else {
                mirror.relinkInterval = INITIAL_RELINK_INTERVAL;
            }
        }
    }

    public static void clientTick(Level level, BlockPos pos, BlockState state, MirrorBlockEntity mirror) {
        dev.tc4port.thaumcraft.client.EssentiaSourceEffect.tick(mirror);
    }

    private void tickItemMirror() {
        int tickRate = this.instability / 50;
        if (tickRate == 0 || this.count % (tickRate * tickRate) == 0) {
            this.ejectOne();
        }
        if (this.instability > 0 && this.count % 20 == 0) {
            this.instability--;
            this.changedAndSync();
        }
        if (this.instability > 0 && this.level instanceof ServerLevel serverLevel && VisNetwork.drain(serverLevel, this.worldPosition, VisChannel.ORDO, 1) > 0) {
            this.addInstability(-1, true);
        }
    }

    public boolean essentiaMirror() {
        return this.getBlockState().getBlock() == dev.tc4port.thaumcraft.registry.TCBlocks.ESSENTIA_MIRROR.get();
    }

    public Direction facing() {
        return this.getBlockState().hasProperty(MirrorBlock.FACING) ? this.getBlockState().getValue(MirrorBlock.FACING) : Direction.NORTH;
    }

    @Nullable
    public MirrorLinkData link() {
        return this.link;
    }

    public boolean linked() {
        return this.linked;
    }

    public void copyItemFields(dev.tc4port.thaumcraft.nativeimpl.state.ItemFields.Output output) {
        this.native$NativeBlockEntity$copyItemFields(output);
        MirrorLinkData link = this.linkForDrop();
        if (link != null)
            output.set(dev.tc4port.thaumcraft.state.TCItemState.MIRROR_LINK, link);
    }

    @Nullable
    public MirrorLinkData linkForDrop() {
        return this.linked ? this.link : this.removedDropLink;
    }

    public void unlinkForRemoval() {
        this.removedDropLink = this.linked ? this.link : null;
        this.invalidateLink();
    }

    public int instability() {
        return this.instability;
    }

    public int queuedStackCount() {
        return this.level != null && this.level.isClientSide ? this.syncedQueueSize : this.outputStacks.size();
    }

    /**
     * Installs the coordinates carried by a linked item, then performs the
     * legacy reciprocal restore if the destination chunk is already loaded.
     */
    public void setPendingLink(MirrorLinkData candidate) {
        this.link = candidate;
        this.linked = false;
        this.relinkInterval = INITIAL_RELINK_INTERVAL;
        this.changedAndSync();
        this.restoreLink();
    }

    public void clearLink() {
        this.link = null;
        this.linked = false;
        this.changedAndSync();
    }

    public boolean isLinkValid() {
        if (!this.linked || this.link == null) {
            return false;
        }
        MirrorBlockEntity target = this.loadedTarget();
        if (target == null) {
            // Never force-load a dimension/chunk merely to validate a link.
            return false;
        }
        if (target.essentiaMirror() != this.essentiaMirror() || !target.linked || !target.pointsTo(this)) {
            this.linked = false;
            this.changedAndSync();
            return false;
        }
        return true;
    }

    public boolean isLinkValidSimple() {
        if (!this.linked || this.link == null) {
            return false;
        }
        MirrorBlockEntity target = this.loadedTarget();
        return target != null && target.essentiaMirror() == this.essentiaMirror() && target.linked && target.pointsTo(this);
    }

    public void restoreLink() {
        if (this.link == null || !(this.level instanceof ServerLevel serverLevel)) {
            return;
        }
        MirrorBlockEntity target = this.loadedTarget();
        if (target == null || target.essentiaMirror() != this.essentiaMirror()) {
            return;
        }
        if (target.isLinkValidSimple() && !target.pointsTo(this)) {
            return;
        }
        this.linked = true;
        target.link = new MirrorLinkData(serverLevel.dimension().location(), this.worldPosition, serverLevel.dimension().location().toString());
        target.linked = true;
        target.relinkInterval = INITIAL_RELINK_INTERVAL;
        target.changedAndSync();
        this.changedAndSync();
    }

    public void invalidateLink() {
        MirrorBlockEntity target = this.loadedTarget();
        if (target != null && target.pointsTo(this)) {
            target.linked = false;
            target.changedAndSync();
        }
        this.linked = false;
        this.changedAndSync();
    }

    private boolean pointsTo(MirrorBlockEntity target) {
        if (this.link == null || !(target.level instanceof ServerLevel targetLevel)) {
            return false;
        }
        return this.link.pos().equals(target.worldPosition) && this.link.dimension().equals(targetLevel.dimension().location());
    }

    @Nullable
    public MirrorBlockEntity loadedTarget() {
        if (this.link == null || !(this.level instanceof ServerLevel sourceLevel)) {
            return null;
        }
        ServerLevel targetLevel = sourceLevel.getServer().getLevel(ResourceKey.create(Registries.DIMENSION, this.link.dimension()));
        if (targetLevel == null || !targetLevel.hasChunk(SectionPos.blockToSectionCoord(this.link.pos().getX()), SectionPos.blockToSectionCoord(this.link.pos().getZ()))) {
            return null;
        }
        BlockEntity target = targetLevel.getBlockEntity(this.link.pos());
        return target instanceof MirrorBlockEntity mirror ? mirror : null;
    }

    public boolean transport(ItemEntity itemEntity) {
        if (this.essentiaMirror() || itemEntity.isRemoved() || itemEntity.isOnPortalCooldown() || !this.isLinkValid()) {
            return false;
        }
        MirrorBlockEntity target = this.loadedTarget();
        if (target == null) {
            return false;
        }
        ItemStack transported = itemEntity.getItem().copy();
        target.addStack(transported);
        this.addInstability(transported.getCount(), false);
        itemEntity.discard();
        this.signalTransport();
        target.changedAndSync();
        return true;
    }

    public void addStack(ItemStack stack) {
        if (!stack.isEmpty()) {
            this.outputStacks.add(stack.copy());
            this.changedAndSync();
        }
    }

    private void ejectOne() {
        if (this.outputStacks.isEmpty() || this.count <= 20 || this.level == null) {
            return;
        }
        int selected = this.level.random.nextInt(this.outputStacks.size());
        ItemStack queued = this.outputStacks.get(selected);
        if (queued.isEmpty()) {
            this.outputStacks.remove(selected);
            this.changedAndSync();
            return;
        }
        ItemStack output = queued.copyWithCount(1);
        if (!this.spawnItem(output)) {
            return;
        }
        queued.shrink(1);
        if (queued.isEmpty()) {
            this.outputStacks.remove(selected);
        }
        this.addInstability(1, false);
        this.signalTransport();
        this.changedAndSync();
    }

    public boolean spawnItem(ItemStack stack) {
        if (!(this.level instanceof ServerLevel targetLevel) || stack.isEmpty()) {
            return false;
        }
        Direction face = this.facing();
        Vec3 outwardImpulse = Vec3.atLowerCornerOf(face.getNormal()).scale(0.15);
        double spawnX = this.worldPosition.getX() + 0.5 - face.getStepX() * 0.3;
        double spawnY = this.worldPosition.getY() + 0.5 - face.getStepY() * 0.3;
        double spawnZ = this.worldPosition.getZ() + 0.5 - face.getStepZ() * 0.3;
        ItemEntity entity = new ItemEntity(targetLevel, spawnX, spawnY, spawnZ, stack.copy(), outwardImpulse.x, outwardImpulse.y, outwardImpulse.z);
        if (face == Direction.DOWN) {
            /*
             * A modern ItemEntity's Y position is the bottom of its
             * 0.25-block-tall box. The legacy 0.8 spawn coordinate therefore
             * reaches 0.05 blocks into the ceiling that supports a downward
             * mirror. ItemEntity.tick then calls moveTowardsClosestSpace and
             * picks an apparently random horizontal escape. Preserve the
             * original centre/normal formula on every other face, but move
             * this asymmetric case just below the support boundary.
             */
            double supportBoundary = this.worldPosition.getY() + 1.0;
            double overlap = entity.getBoundingBox().maxY - supportBoundary;
            if (overlap >= 0.0) {
                entity.setPos(spawnX, spawnY - overlap - 1.0E-4, spawnZ);
            }
        }
        // Make the one-shot legacy launch explicit to modern entity tracking.
        // Gravity acts normally after this initial mirror-normal impulse.
        entity.hasImpulse = true;
        entity.setPortalCooldown(20);
        return targetLevel.addFreshEntity(entity);
    }

    private void addInstability(int amount, boolean includeTarget) {
        this.instability = Math.max(0, this.instability + amount);
        this.changedAndSync();
        if (includeTarget) {
            MirrorBlockEntity target = this.loadedTarget();
            if (target != null && !target.essentiaMirror()) {
                target.instability = Math.max(0, target.instability + amount);
                target.changedAndSync();
            }
        }
    }

    public void signalTransport() {
        if (this.level != null) {
            this.level.blockEvent(this.worldPosition, this.getBlockState().getBlock(), 1, 0);
        }
    }

    @Override
    public boolean triggerEvent(int id, int type) {
        if (id != 1) {
            return super.triggerEvent(id, type);
        }
        if (this.level != null && this.level.isClientSide) {
            dev.tc4port.thaumcraft.client.MirrorClientEffects.spawnTransport(this);
        }
        return true;
    }

    /**
     * One-unit, one-way IAspectSource behavior of TileMirrorEssentia.
     */
    @Override
    public int extractEssentia(AspectId aspect, int amount, EssentiaTransferMode mode) {
        if (!this.essentiaMirror() || amount <= 0 || amount > 1 || !(mode.executes() ? this.isLinkValid() : this.isLinkValidSimple())) {
            return 0;
        }
        MirrorBlockEntity target = this.loadedTarget();
        if (target == null || !(target.level instanceof ServerLevel level)) {
            return 0;
        }
        Direction direction = target.facing();
        BlockPos origin = target.worldPosition;
        var extracted = EssentiaApi.extract(level, origin, aspect, 1, EssentiaSearch.ahead(direction, ESSENTIA_REMOTE_RANGE), mode, reference -> !(level.getBlockEntity(reference.position()) instanceof MirrorBlockEntity));
        if (extracted.isPresent()) {
            if (mode.executes()) {
                target.signalTransport();
                sendEssentiaEffect(level, origin, extracted.orElseThrow().position(), aspect);
            }
            return 1;
        }
        return 0;
    }

    private static void sendEssentiaEffect(ServerLevel level, BlockPos target, BlockPos source, AspectId aspect) {
        AspectDefinition definition = AspectCatalog.get(aspect);
        EssentiaSourcePayload payload = new EssentiaSourcePayload(target, source, definition == null ? 0xFFFFFF : definition.color());
        for (ServerPlayer player : level.players()) {
            if (player.distanceToSqr(Vec3.atCenterOf(target)) <= 32.0 * 32.0) {
                dev.tc4port.thaumcraft.network.TCPayloads.CHANNEL.sendToPlayer(player, payload);
            }
        }
    }

    private void changedAndSync() {
        this.setChanged();
        BlockEntitySync.sendToClient(this);
    }

    @Override
    public void load(CompoundTag tag) {
        HolderLookup.Provider registries = persistenceRegistries();
        super.load(tag);
        this.linked = tag.getBoolean("linked");
        if (tag.contains("linkDimension") && tag.contains("linkX")) {
            net.minecraft.resources.ResourceLocation dimension = net.minecraft.resources.ResourceLocation.tryParse(tag.getString("linkDimension"));
            this.link = dimension == null ? null : new MirrorLinkData(dimension, new BlockPos(tag.getInt("linkX"), tag.getInt("linkY"), tag.getInt("linkZ")), tag.getString("dimname"));
        } else {
            this.link = null;
        }
        this.instability = Math.max(0, tag.getInt("instability"));
        this.syncedQueueSize = tag.getInt("queueSize");
        this.outputStacks.clear();
        ListTag items = tag.getList("Items", Tag.TAG_COMPOUND);
        for (int index = 0; index < items.size(); index++) {
            ItemStack stack = (switch(0) {
                default ->
                    {
                        net.minecraft.core.HolderLookup.Provider native$operand$13114 = registries;
                        net.minecraft.nbt.CompoundTag native$operand$13115 = items.getCompound(index);
                        net.minecraft.world.item.ItemStack native$result$13116 = (net.minecraft.world.item.ItemStack.of(native$operand$13115));
                        yield native$result$13116;
                    }
            });
            if (!stack.isEmpty()) {
                this.outputStacks.add(stack);
            }
        }
    }

    @Override
    protected void saveAdditional(CompoundTag tag) {
        HolderLookup.Provider registries = persistenceRegistries();
        super.saveAdditional(tag);
        this.saveVisualState(tag);
        ListTag items = new ListTag();
        for (ItemStack stack : this.outputStacks) {
            if (!stack.isEmpty()) {
                items.add((switch(0) {
                    default ->
                        {
                            net.minecraft.world.item.ItemStack native$operand$12981 = stack;
                            net.minecraft.core.HolderLookup.Provider native$operand$12982 = registries;
                            net.minecraft.nbt.Tag native$result$12983 = (native$operand$12981.save(new net.minecraft.nbt.CompoundTag()));
                            yield native$result$12983;
                        }
                }));
            }
        }
        tag.put("Items", items);
    }

    private void saveVisualState(CompoundTag tag) {
        tag.putInt("queueSize", this.outputStacks.size());
        tag.putBoolean("linked", this.linked);
        if (this.link != null) {
            tag.putString("linkDimension", this.link.dimension().toString());
            tag.putInt("linkX", this.link.pos().getX());
            tag.putInt("linkY", this.link.pos().getY());
            tag.putInt("linkZ", this.link.pos().getZ());
            tag.putString("dimname", this.link.dimensionName());
        }
        tag.putInt("instability", this.instability);
    }

    @Override
    public CompoundTag getUpdateTag() {
        CompoundTag tag = new CompoundTag();
        this.saveVisualState(tag);
        return tag;
    }

    @Override
    public Packet<ClientGamePacketListener> getUpdatePacket() {
        return ClientboundBlockEntityDataPacket.create(this);
    }

    protected final HolderLookup.Provider persistenceRegistries() {
        if (level != null)
            return level.registryAccess();
        var server = net.minecraftforge.server.ServerLifecycleHooks.getCurrentServer();
        return server != null ? server.registryAccess() : net.minecraft.core.RegistryAccess.fromRegistryOfRegistries(net.minecraft.core.registries.BuiltInRegistries.REGISTRY);
    }

    protected static net.minecraft.network.chat.Component parseCustomNameSafe(String value, HolderLookup.Provider registries) {
        try {
            return net.minecraft.network.chat.Component.Serializer.fromJson(value);
        } catch (RuntimeException exception) {
            return null;
        }
    }

    protected void readItemFields(ItemFields.Input input) {
    }

    private void native$NativeBlockEntity$copyItemFields(ItemFields.Output output) {
    }

    public void applyComponentsFromItemStack(ItemStack stack) {
        readItemFields(ItemFields.from(stack));
    }

    public void removeComponentsFromTag(CompoundTag tag) {
    }

    @Override
    public void saveToItem(ItemStack stack) {
        CompoundTag tag = saveWithoutMetadata();
        {
            net.minecraft.nbt.CompoundTag native$bodyOperand$6193 = tag;
            native$bodyReturn$6195: {
                if (true) {
                }
            }
        }
        net.minecraft.world.item.BlockItem.setBlockEntityData(stack, getType(), tag);
        copyItemFields(ItemFields.to(stack));
    }

    @Override
    public net.minecraft.world.phys.AABB getRenderBoundingBox() {
        return MirrorBlockEntity.native$ClientBlockEntityBounds$bounds(this);
    }

    @Override()
    public void onDataPacket(net.minecraft.network.Connection connection, net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket packet) {
        handleUpdateTag(packet.getTag());
    }

    @SuppressWarnings({ "rawtypes", "unchecked" })
    static private net.minecraft.world.phys.AABB native$ClientBlockEntityBounds$bounds(net.minecraft.world.level.block.entity.BlockEntity blockEntity) {
        var renderer = net.minecraft.client.Minecraft.getInstance().getBlockEntityRenderDispatcher().getRenderer(blockEntity);
        return renderer instanceof dev.tc4port.thaumcraft.nativeimpl.NativeBlockEntityRenderer shared ? shared.getRenderBoundingBox(blockEntity) : new net.minecraft.world.phys.AABB(blockEntity.getBlockPos());
    }

    private boolean native$capabilitiesInvalid$16931;

    public boolean native$capabilityActive$16782;

    public net.minecraftforge.common.capabilities.Capability<dev.tc4port.thaumcraft.api.essentia.EssentiaSource> native$capabilityCapture$16781;

    private net.minecraftforge.common.util.LazyOptional<dev.tc4port.thaumcraft.api.essentia.EssentiaSource> native$capabilityHandle$16783;

    @Override
    public <native$capabilityResultType$16932> net.minecraftforge.common.util.LazyOptional<native$capabilityResultType$16932> getCapability(net.minecraftforge.common.capabilities.Capability<native$capabilityResultType$16932> native$requestedCapability$16933, net.minecraft.core.Direction native$requestedFace$16934) {
        getCapabilities();
        synchronized (this) {
            if (native$capabilitiesInvalid$16931)
                return net.minecraftforge.common.util.LazyOptional.empty();
            if (native$capabilityActive$16782 && native$requestedCapability$16933 == (this.native$capabilityCapture$16781)) {
                if (native$capabilityHandle$16783 == null)
                    native$capabilityHandle$16783 = net.minecraftforge.common.util.LazyOptional.of(() -> this);
                return native$capabilityHandle$16783.cast();
            }
        }
        return super.getCapability(native$requestedCapability$16933, native$requestedFace$16934);
    }

    @Override
    public void invalidateCaps() {
        java.util.List<net.minecraftforge.common.util.LazyOptional<?>> native$expiredCapabilities$16935 = new java.util.ArrayList<>();
        synchronized (this) {
            native$capabilitiesInvalid$16931 = true;
            if (native$capabilityHandle$16783 != null) {
                native$expiredCapabilities$16935.add(native$capabilityHandle$16783);
                native$capabilityHandle$16783 = null;
            }
        }
        try {
            super.invalidateCaps();
        } finally {
            native$expiredCapabilities$16935.forEach(net.minecraftforge.common.util.LazyOptional::invalidate);
        }
    }

    @Override
    public void reviveCaps() {
        super.reviveCaps();
        synchronized (this) {
            native$capabilitiesInvalid$16931 = false;
        }
    }
}
