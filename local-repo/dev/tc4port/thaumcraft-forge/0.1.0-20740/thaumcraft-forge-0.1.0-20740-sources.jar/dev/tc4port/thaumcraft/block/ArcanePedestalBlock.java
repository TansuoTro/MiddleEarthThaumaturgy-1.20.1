package dev.tc4port.thaumcraft.block;

import dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult;
import com.mojang.serialization.MapCodec;
import dev.tc4port.thaumcraft.block.entity.ArcanePedestalBlockEntity;
import dev.tc4port.thaumcraft.registry.TCBlockEntities;
import javax.annotation.Nullable;
import net.minecraft.core.BlockPos;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.Containers;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityTicker;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.pathfinder.PathComputationType;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;
import java.lang.Math;
import dev.tc4port.thaumcraft.nativeimpl.ClientExtensionTarget;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.phys.HitResult;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.Explosion;

/**
 * Arcane pedestal interaction remains intentionally direct: right-click an
 * occupied pedestal to take its stack, or an empty one to place one item.
 */
public final class ArcanePedestalBlock extends net.minecraft.world.level.block.BaseEntityBlock implements dev.tc4port.thaumcraft.nativeimpl.ClientExtensionTarget {

    // Forge calls initializeClient from the native superclass constructor. Do not add a field initializer.
    private java.util.function.Consumer<net.minecraftforge.client.extensions.common.IClientBlockExtensions> platform$clientInstaller;

    public static final MapCodec<ArcanePedestalBlock> CODEC = ArcanePedestalBlock.native$BlockCodecPlatform$simple(ArcanePedestalBlock::new);

    /*
     * User-authorized modernization: BlockStoneDevice metadata 1 exposed only
     * a centered 8x15.84x8 column to selection even though the visible
     * pedestal has three wider tiers. Keep the source full-cube collision
     * below, but make targeting and the outline follow the rendered model.
     */
    private static final VoxelShape OUTLINE = Shapes.or(Block.box(0.0, 0.0, 0.0, 16.0, 4.0, 16.0), Block.box(4.0, 4.0, 4.0, 12.0, 12.0, 12.0), Block.box(2.0, 12.0, 2.0, 14.0, 16.0, 14.0));

    public ArcanePedestalBlock(BlockBehaviour.Properties properties) {
        this(properties, properties, true);
    }

    protected MapCodec<ArcanePedestalBlock> codec() {
        return CODEC;
    }

    @Nullable
    @Override
    public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        return new ArcanePedestalBlockEntity(pos, state);
    }

    @Nullable
    @Override
    public <T extends BlockEntity> BlockEntityTicker<T> getTicker(Level level, BlockState state, BlockEntityType<T> type) {
        return level.isClientSide ? createTickerHelper(type, TCBlockEntities.ARCANE_PEDESTAL.get(), (tickLevel, tickPos, tickState, pedestal) -> pedestal.clientTick()) : null;
    }

    @Override
    public RenderShape getRenderShape(BlockState state) {
        return RenderShape.MODEL;
    }

    @Override
    public VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
        return OUTLINE;
    }

    @Override
    public VoxelShape getCollisionShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
        // BlockStoneDevice metadata 1 selected narrowly but collided as a cube.
        return Shapes.block();
    }

    @Override
    public VoxelShape getBlockSupportShape(BlockState state, BlockGetter level, BlockPos pos) {
        return Shapes.empty();
    }

    /**
     * The pedestal intentionally retains TC4's full-cube collision while its
     * three visible cuboids are inset. ModelBlockRenderer otherwise treats
     * every inset quad as if it touched the neighboring block and samples
     * that neighbor's light, turning all equally-oriented faces black.
     *
     * <p>The registration marks this block as dynamicShape so the state cache
     * actually calls this override instead of deriving the answer directly
     * from the collision shape.</p>
     */
    @Override
    public boolean isCollisionShapeFullBlock(BlockState state, BlockGetter level, BlockPos pos) {
        return false;
    }

    @Override
    public boolean isPathfindable(BlockState state, net.minecraft.world.level.BlockGetter level, BlockPos pos, PathComputationType pathType) {
        // Lighting is decoupled from collision; pathfinding is not.
        return false;
    }

    protected ItemUseResult interactWithItem(ItemStack stack, BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
        if (!(level.getBlockEntity(pos) instanceof dev.tc4port.thaumcraft.block.entity.ArcanePedestalBlockEntity pedestal)) {
            return dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
        }
        if (stack.isEmpty() || !pedestal.item().isEmpty()) {
            return dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
        }
        if (!level.isClientSide) {
            pedestal.setItem(0, stack.copyWithCount(1));
            stack.shrink(1);
            level.playSound(null, pos, net.minecraft.sounds.SoundEvents.ITEM_PICKUP, net.minecraft.sounds.SoundSource.BLOCKS, 0.2F, ((level.random.nextFloat() - level.random.nextFloat()) * 0.7F + 1.0F) * 1.6F);
        }
        return dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.sidedSuccess(level.isClientSide);
    }

    protected InteractionResult interactWithoutItem(BlockState state, Level level, BlockPos pos, Player player, BlockHitResult hit) {
        if (!(level.getBlockEntity(pos) instanceof dev.tc4port.thaumcraft.block.entity.ArcanePedestalBlockEntity pedestal) || pedestal.item().isEmpty()) {
            return net.minecraft.world.InteractionResult.PASS;
        }
        if (!level.isClientSide) {
            net.minecraft.world.item.ItemStack removed = pedestal.removeItem(0, pedestal.item().getCount());
            /*
             * Intentional modernisation recorded in known_issues.txt: put
             * the stack straight into the real player inventory.  Inventory
             * insertion mutates removed to the unaccepted remainder, so only
             * that remainder is allowed to become a world entity.  Do not
             * restore TC4's temporary half-eye-height pickup entity here.
             */
            insertWithoutCreativeVoid(player.getInventory(), removed);
            if (!removed.isEmpty()) {
                player.drop(removed, false);
            }
            level.playSound(null, pos, net.minecraft.sounds.SoundEvents.ITEM_PICKUP, net.minecraft.sounds.SoundSource.BLOCKS, 0.2F, ((level.random.nextFloat() - level.random.nextFloat()) * 0.7F + 1.0F) * 1.5F);
        }
        return net.minecraft.world.InteractionResult.sidedSuccess(level.isClientSide);
    }

    /**
     * Inserts only the amount accepted by real inventory slots.
     *
     * <p>Vanilla {@link Inventory#add(ItemStack)} clears an unaccepted
     * remainder for players with infinite materials.  That pickup-specific
     * shortcut would violate the project-owned pedestal modernization by
     * silently deleting the remainder instead of dropping it.  Supplying a
     * slot-sized copy to the indexed overload preserves vanilla's selected,
     * offhand-merge and main-inventory ordering without reaching that
     * creative fallback.</p>
     */
    static void insertWithoutCreativeVoid(Inventory inventory, ItemStack remainder) {
        while (!remainder.isEmpty()) {
            int slot = inventory.getSlotWithRemainingSpace(remainder);
            if (slot < 0) {
                slot = inventory.getFreeSlot();
            }
            if (slot < 0) {
                return;
            }
            ItemStack present = inventory.getItem(slot);
            int capacity = present.isEmpty() ? remainder.getMaxStackSize() : present.getMaxStackSize() - present.getCount();
            int transfer = Math.min(capacity, remainder.getCount());
            if (transfer <= 0) {
                return;
            }
            ItemStack accepted = remainder.copyWithCount(transfer);
            if (!inventory.add(slot, accepted) || !accepted.isEmpty()) {
                return;
            }
            remainder.shrink(transfer);
        }
    }

    @Override
    public void neighborChanged(BlockState state, Level level, BlockPos pos, Block neighborBlock, BlockPos neighborPos, boolean movedByPiston) {
        super.neighborChanged(state, level, pos, neighborBlock, neighborPos, movedByPiston);
        if (!level.isClientSide && !level.getBlockState(pos.above()).isAir() && level.getBlockEntity(pos) instanceof ArcanePedestalBlockEntity pedestal && !pedestal.isEmpty()) {
            Containers.dropContents(level, pos, pedestal);
            pedestal.setChanged();
            level.sendBlockUpdated(pos, state, state, Block.UPDATE_CLIENTS);
        }
    }

    @Override
    public boolean hasAnalogOutputSignal(BlockState state) {
        return true;
    }

    @Override
    public int getAnalogOutputSignal(BlockState state, Level level, BlockPos pos) {
        return level.getBlockEntity(pos) instanceof ArcanePedestalBlockEntity pedestal ? AbstractContainerMenu.getRedstoneSignalFromContainer(pedestal) : 0;
    }

    @Override
    public void onRemove(BlockState state, Level level, BlockPos pos, BlockState newState, boolean movedByPiston) {
        if (!state.is(newState.getBlock()) && level.getBlockEntity(pos) instanceof ArcanePedestalBlockEntity pedestal) {
            Containers.dropContents(level, pos, pedestal);
        }
        super.onRemove(state, level, pos, newState, movedByPiston);
    }

    @Override
    public boolean triggerEvent(BlockState state, Level level, BlockPos pos, int id, int parameter) {
        if (level.getBlockEntity(pos) instanceof ArcanePedestalBlockEntity pedestal && pedestal.triggerEvent(id, parameter)) {
            if (level.isClientSide && (id == 11 || id == 12)) {
                int outer = dev.tc4port.thaumcraft.client.InfusionSparkleEffects.particleCount(id == 11 ? 5 : 10);
                for (int index = 0; index < outer; index++) {
                    dev.tc4port.thaumcraft.client.InfusionSparkleEffects.blockSparkle(level, pos.above(), id == 11 ? 12583104 : -9999, 2);
                }
            }
            return true;
        }
        return super.triggerEvent(state, level, pos, id, parameter);
    }

    private ArcanePedestalBlock(net.minecraft.world.level.block.state.BlockBehaviour.Properties native$NativeEntityBlock$arg0, BlockBehaviour.Properties properties, boolean native$NativeEntityBlock$captured) {
        super(native$NativeEntityBlock$arg0);
    }

    @Override
    public void initializeClient(java.util.function.Consumer<net.minecraftforge.client.extensions.common.IClientBlockExtensions> installer) {
        platform$clientInstaller = installer;
        super.initializeClient(installer);
    }

    @Override
    public void platform$clientExtension(Object extension) {
        java.util.Objects.requireNonNull(platform$clientInstaller, "Forge initializeClient must run before client extension registration").accept((net.minecraftforge.client.extensions.common.IClientBlockExtensions) extension);
    }

    @Override
    public InteractionResult use(BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
        ItemUseResult result = (switch(0) {
            default ->
                {
                    net.minecraft.world.item.ItemStack native$bodyOperand$4167 = player.getItemInHand(hand);
                    net.minecraft.world.level.block.state.BlockState native$bodyOperand$4168 = state;
                    net.minecraft.world.level.Level native$bodyOperand$4169 = level;
                    net.minecraft.core.BlockPos native$bodyOperand$4170 = pos;
                    net.minecraft.world.entity.player.Player native$bodyOperand$4171 = player;
                    net.minecraft.world.InteractionHand native$bodyOperand$4172 = hand;
                    net.minecraft.world.phys.BlockHitResult native$bodyOperand$4173 = hit;
                    dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult native$bodyResult$4175 = null;
                    native$bodyReturn$4176: {
                        if (true) {
                            if (!(native$bodyOperand$4169.getBlockEntity(native$bodyOperand$4170) instanceof dev.tc4port.thaumcraft.block.entity.ArcanePedestalBlockEntity native$bodyBinding$4174)) {
                                {
                                    native$bodyResult$4175 = dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
                                    break native$bodyReturn$4176;
                                }
                            }
                            if (native$bodyOperand$4167.isEmpty() || !native$bodyBinding$4174.item().isEmpty()) {
                                {
                                    native$bodyResult$4175 = dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
                                    break native$bodyReturn$4176;
                                }
                            }
                            if (!native$bodyOperand$4169.isClientSide) {
                                native$bodyBinding$4174.setItem(0, native$bodyOperand$4167.copyWithCount(1));
                                native$bodyOperand$4167.shrink(1);
                                native$bodyOperand$4169.playSound(null, native$bodyOperand$4170, net.minecraft.sounds.SoundEvents.ITEM_PICKUP, net.minecraft.sounds.SoundSource.BLOCKS, 0.2F, ((native$bodyOperand$4169.random.nextFloat() - native$bodyOperand$4169.random.nextFloat()) * 0.7F + 1.0F) * 1.6F);
                            }
                            {
                                native$bodyResult$4175 = dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.sidedSuccess(native$bodyOperand$4169.isClientSide);
                                break native$bodyReturn$4176;
                            }
                        }
                    }
                    yield native$bodyResult$4175;
                }
        });
        return result == ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION ? (hand == InteractionHand.MAIN_HAND ? (switch(0) {
            default ->
                {
                    net.minecraft.world.level.block.state.BlockState native$bodyOperand$3498 = state;
                    net.minecraft.world.level.Level native$bodyOperand$3499 = level;
                    net.minecraft.core.BlockPos native$bodyOperand$3500 = pos;
                    net.minecraft.world.entity.player.Player native$bodyOperand$3501 = player;
                    net.minecraft.world.phys.BlockHitResult native$bodyOperand$3502 = hit;
                    net.minecraft.world.InteractionResult native$bodyResult$3505 = null;
                    native$bodyReturn$3506: {
                        if (true) {
                            if (!(native$bodyOperand$3499.getBlockEntity(native$bodyOperand$3500) instanceof dev.tc4port.thaumcraft.block.entity.ArcanePedestalBlockEntity native$bodyBinding$3503) || native$bodyBinding$3503.item().isEmpty()) {
                                {
                                    native$bodyResult$3505 = net.minecraft.world.InteractionResult.PASS;
                                    break native$bodyReturn$3506;
                                }
                            }
                            if (!native$bodyOperand$3499.isClientSide) {
                                net.minecraft.world.item.ItemStack native$bodyBinding$3504 = native$bodyBinding$3503.removeItem(0, native$bodyBinding$3503.item().getCount());
                                /*
             * Intentional modernisation recorded in known_issues.txt: put
             * the stack straight into the real player inventory.  Inventory
             * insertion mutates removed to the unaccepted remainder, so only
             * that remainder is allowed to become a world entity.  Do not
             * restore TC4's temporary half-eye-height pickup entity here.
             */
                                insertWithoutCreativeVoid(native$bodyOperand$3501.getInventory(), native$bodyBinding$3504);
                                if (!native$bodyBinding$3504.isEmpty()) {
                                    native$bodyOperand$3501.drop(native$bodyBinding$3504, false);
                                }
                                native$bodyOperand$3499.playSound(null, native$bodyOperand$3500, net.minecraft.sounds.SoundEvents.ITEM_PICKUP, net.minecraft.sounds.SoundSource.BLOCKS, 0.2F, ((native$bodyOperand$3499.random.nextFloat() - native$bodyOperand$3499.random.nextFloat()) * 0.7F + 1.0F) * 1.5F);
                            }
                            {
                                native$bodyResult$3505 = net.minecraft.world.InteractionResult.sidedSuccess(native$bodyOperand$3499.isClientSide);
                                break native$bodyReturn$3506;
                            }
                        }
                    }
                    yield native$bodyResult$3505;
                }
        }) : InteractionResult.PASS) : result.result();
    }

    @Override
    public void playerWillDestroy(Level level, BlockPos pos, BlockState state, Player player) {
        {
            net.minecraft.world.level.Level native$bodyOperand$5678 = level;
            net.minecraft.core.BlockPos native$bodyOperand$5679 = pos;
            net.minecraft.world.level.block.state.BlockState native$bodyOperand$5680 = state;
            net.minecraft.world.entity.player.Player native$bodyOperand$5681 = player;
            net.minecraft.world.level.block.state.BlockState native$bodyResult$5682 = null;
            native$bodyReturn$5683: {
                if (true) {
                    super.playerWillDestroy(native$bodyOperand$5678, native$bodyOperand$5679, native$bodyOperand$5680, native$bodyOperand$5681);
                    {
                        native$bodyResult$5682 = native$bodyOperand$5680;
                        break native$bodyReturn$5683;
                    }
                }
            }
        }
    }

    public BlockState beforePlayerDestroy(Level level, BlockPos pos, BlockState state, Player player) {
        super.playerWillDestroy(level, pos, state, player);
        return state;
    }

    protected boolean survivesSharedExplosion() {
        return false;
    }

    public int getExpDrop(net.minecraft.world.level.block.state.BlockState native$callbackInput$1050, net.minecraft.world.level.LevelReader native$callbackInput$1051, net.minecraft.util.RandomSource native$callbackInput$1052, net.minecraft.core.BlockPos native$callbackInput$1053, int native$callbackInput$1054, int native$callbackInput$1055) {
        net.minecraft.world.level.block.state.BlockState state = native$callbackInput$1050;
        net.minecraft.util.RandomSource random = native$callbackInput$1052;
        return 0;
    }

    @Override
    public void onBlockExploded(BlockState state, Level level, BlockPos pos, Explosion explosion) {
        if (!(switch(0) {
            default ->
                {
                    boolean native$bodyResult$5221 = false;
                    native$bodyReturn$5222: {
                        if (true) {
                            {
                                native$bodyResult$5221 = false;
                                break native$bodyReturn$5222;
                            }
                        }
                    }
                    yield native$bodyResult$5221;
                }
        }))
            super.onBlockExploded(state, level, pos, explosion);
    }

    @Override
    public boolean canDropFromExplosion(BlockState state, BlockGetter level, BlockPos pos, Explosion explosion) {
        return !(switch(0) {
            default ->
                {
                    boolean native$bodyResult$4177 = false;
                    native$bodyReturn$4178: {
                        if (true) {
                            {
                                native$bodyResult$4177 = false;
                                break native$bodyReturn$4178;
                            }
                        }
                    }
                    yield native$bodyResult$4177;
                }
        }) && super.canDropFromExplosion(state, level, pos, explosion);
    }

    static private <B extends net.minecraft.world.level.block.Block> com.mojang.serialization.MapCodec<B> native$BlockCodecPlatform$simple(java.util.function.Function<net.minecraft.world.level.block.state.BlockBehaviour.Properties, B> factory) {
        // Vanilla 1.21's Properties codec is a unit codec. Retain that schema for shared block definitions.
        return com.mojang.serialization.codecs.RecordCodecBuilder.mapCodec(instance -> instance.group(com.mojang.serialization.Codec.unit(net.minecraft.world.level.block.state.BlockBehaviour.Properties::of).fieldOf("properties").forGetter((B block) -> net.minecraft.world.level.block.state.BlockBehaviour.Properties.copy(block))).apply(instance, factory));
    }
}
