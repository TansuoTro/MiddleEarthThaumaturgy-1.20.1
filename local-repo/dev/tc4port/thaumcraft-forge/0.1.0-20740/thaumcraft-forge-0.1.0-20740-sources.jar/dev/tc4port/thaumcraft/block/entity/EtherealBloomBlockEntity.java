package dev.tc4port.thaumcraft.block.entity;

import dev.tc4port.thaumcraft.common.TCGameplayParameters;
import dev.tc4port.thaumcraft.block.TaintSpreadLogic;
import dev.tc4port.thaumcraft.registry.TCBlockEntities;
import dev.tc4port.thaumcraft.registry.TCSounds;
import dev.tc4port.thaumcraft.worldgen.TCBiomes;
import net.minecraft.core.BlockPos;
import net.minecraft.core.QuartPos;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import dev.tc4port.thaumcraft.nativeimpl.state.ItemFields;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityType;

/**
 * TC4 TileEtherealBloom timing and nine-block purification radius.
 */
public final class EtherealBloomBlockEntity extends net.minecraft.world.level.block.entity.BlockEntity implements ItemFields.Source {

    private int counter;

    private int growthCounter;

    public EtherealBloomBlockEntity(BlockPos pos, BlockState state) {
        super(TCBlockEntities.ETHEREAL_BLOOM.get(), pos, state);
    }

    public static void tick(Level level, BlockPos pos, BlockState state, EtherealBloomBlockEntity bloom) {
        if (bloom.counter == 0) {
            bloom.counter = level.random.nextInt(100);
        }
        bloom.counter++;
        if (!level.isClientSide && bloom.counter % TCGameplayParameters.MACHINES_ETHEREAL_BLOOM_PURIFY_INTERVAL.intValue() == 0) {
            int offsetX = level.random.nextInt(TCGameplayParameters.MACHINES_ETHEREAL_BLOOM_OFFSET_CHOICES.intValue()) - level.random.nextInt(TCGameplayParameters.MACHINES_ETHEREAL_BLOOM_OFFSET_CHOICES.intValue());
            int offsetZ = level.random.nextInt(TCGameplayParameters.MACHINES_ETHEREAL_BLOOM_OFFSET_CHOICES.intValue()) - level.random.nextInt(TCGameplayParameters.MACHINES_ETHEREAL_BLOOM_OFFSET_CHOICES.intValue());
            purifyColumn(level, pos, pos.offset(offsetX, 0, offsetZ));
        }
        if (level.isClientSide && bloom.growthCounter == 0) {
            level.playLocalSound(pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5, TCSounds.BLOOM_GROW.get(), SoundSource.BLOCKS, 1.0F, 0.6F, false);
        }
        bloom.growthCounter++;
    }

    public static boolean purifyColumn(Level level, BlockPos bloomPos, BlockPos target) {
        if (!(level instanceof net.minecraft.server.level.ServerLevel serverLevel) || bloomPos.distSqr(target) > TCGameplayParameters.MACHINES_ETHEREAL_BLOOM_MAXIMUM_DISTANCE_SQUARED.floatValue()) {
            return false;
        }
        var biome = level.getNoiseBiome(QuartPos.fromBlock(target.getX()), QuartPos.fromBlock(target.getY()), QuartPos.fromBlock(target.getZ()));
        if (!biome.is(TCBiomes.TAINTED_LAND) && !biome.is(TCBiomes.EERIE) && !biome.is(TCBiomes.MAGICAL_FOREST)) {
            return false;
        }
        TaintSpreadLogic.restoreOriginalBiomeColumn(serverLevel, target);
        return true;
    }

    public int counter() {
        return this.counter;
    }

    public int growthCounter() {
        return this.growthCounter;
    }

    protected final HolderLookup.Provider persistenceRegistries() {
        if (level != null)
            return level.registryAccess();
        var server = net.minecraftforge.server.ServerLifecycleHooks.getCurrentServer();
        return server != null ? server.registryAccess() : net.minecraft.core.RegistryAccess.fromRegistryOfRegistries(net.minecraft.core.registries.BuiltInRegistries.REGISTRY);
    }

    protected static net.minecraft.network.chat.Component parseCustomNameSafe(String value, HolderLookup.Provider registries) {
        try {
            return net.minecraft.network.chat.Component.Serializer.fromJson(value);
        } catch (RuntimeException exception) {
            return null;
        }
    }

    protected void readItemFields(ItemFields.Input input) {
    }

    public void copyItemFields(ItemFields.Output output) {
    }

    public void applyComponentsFromItemStack(ItemStack stack) {
        readItemFields(ItemFields.from(stack));
    }

    public void removeComponentsFromTag(CompoundTag tag) {
    }

    @Override
    public void saveToItem(ItemStack stack) {
        CompoundTag tag = saveWithoutMetadata();
        {
            net.minecraft.nbt.CompoundTag native$bodyOperand$6153 = tag;
            native$bodyReturn$6155: {
                if (true) {
                }
            }
        }
        net.minecraft.world.item.BlockItem.setBlockEntityData(stack, getType(), tag);
        copyItemFields(ItemFields.to(stack));
    }

    @Override
    public net.minecraft.world.phys.AABB getRenderBoundingBox() {
        return EtherealBloomBlockEntity.native$ClientBlockEntityBounds$bounds(this);
    }

    @Override()
    public void onDataPacket(net.minecraft.network.Connection connection, net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket packet) {
        handleUpdateTag(packet.getTag());
    }

    @SuppressWarnings({ "rawtypes", "unchecked" })
    static private net.minecraft.world.phys.AABB native$ClientBlockEntityBounds$bounds(net.minecraft.world.level.block.entity.BlockEntity blockEntity) {
        var renderer = net.minecraft.client.Minecraft.getInstance().getBlockEntityRenderDispatcher().getRenderer(blockEntity);
        return renderer instanceof dev.tc4port.thaumcraft.nativeimpl.NativeBlockEntityRenderer shared ? shared.getRenderBoundingBox(blockEntity) : new net.minecraft.world.phys.AABB(blockEntity.getBlockPos());
    }
}
