package dev.tc4port.thaumcraft.block.entity;

import dev.tc4port.thaumcraft.api.aspect.AspectId;
import dev.tc4port.thaumcraft.api.aspect.AspectPoolApi;
import dev.tc4port.thaumcraft.api.aspect.VisAction;
import dev.tc4port.thaumcraft.api.machine.DeconstructionTableView;
import dev.tc4port.thaumcraft.aspect.AspectCatalog;
import dev.tc4port.thaumcraft.api.aspect.AspectList;
import java.util.Optional;
import dev.tc4port.thaumcraft.api.aspect.AspectQueryApi;
import dev.tc4port.thaumcraft.common.PlayerKnowledgeService;
import dev.tc4port.thaumcraft.menu.DeconstructionTableMenu;
import dev.tc4port.thaumcraft.registry.TCBlockEntities;
import java.util.Map;
import javax.annotation.Nullable;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.HolderLookup;
import net.minecraft.core.NonNullList;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.RandomSource;
import net.minecraft.world.WorldlyContainer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.ContainerData;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.entity.BaseContainerBlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityType;

/**
 * Exact one-slot, forty-tick deconstruction loop from TileDeconstructionTable.
 * Progress deliberately is not persisted, matching the source NBT contract.
 */
public final class DeconstructionTableBlockEntity extends net.minecraft.world.level.block.entity.BaseContainerBlockEntity implements WorldlyContainer, DeconstructionTableView {

    // Nominal defaults; runtime behavior reads configured accessors.
    public static final int BREAK_TICKS = 40;

    public static final int INPUT_SLOT = 0;

    public static final int CONTAINER_SIZE = 1;

    public static int configuredBreakTicks() {
        return dev.tc4port.thaumcraft.common.TCGameplayParameters.MACHINES_DECONSTRUCTION_TABLE_BREAK_TICKS.intValue();
    }

    private static final int[] INPUT_SLOT_ARRAY = { INPUT_SLOT };

    private static final int[] NO_SLOTS = {};

    private NonNullList<ItemStack> items = NonNullList.withSize(CONTAINER_SIZE, ItemStack.EMPTY);

    @Nullable
    private AspectId aspect;

    private int breakTime;

    private final ContainerData data = new ContainerData() {

        @Override
        public int get(int index) {
            return index == 0 ? DeconstructionTableBlockEntity.this.breakTime : 0;
        }

        @Override
        public void set(int index, int value) {
            if (index == 0) {
                DeconstructionTableBlockEntity.this.breakTime = value;
            }
        }

        @Override
        public int getCount() {
            return 1;
        }
    };

    public DeconstructionTableBlockEntity(BlockPos pos, BlockState state) {
        super(TCBlockEntities.DECONSTRUCTION_TABLE.get(), pos, state);
    }

    public static void serverTick(net.minecraft.world.level.Level level, BlockPos pos, BlockState state, DeconstructionTableBlockEntity table) {
        if (!(level instanceof ServerLevel serverLevel)) {
            return;
        }
        boolean sync = false;
        Map<AspectId, Integer> inputAspects = table.breakableAspects();
        boolean canBreak = !inputAspects.isEmpty();
        if (table.breakTime == 0 && canBreak) {
            table.breakTime = configuredBreakTicks();
            sync = true;
        }
        if (table.breakTime > 0 && canBreak) {
            table.breakTime--;
            if (table.breakTime == 0) {
                table.breakItem(inputAspects, serverLevel.random);
                sync = true;
            }
        } else {
            table.breakTime = 0;
        }
        if (sync) {
            table.changedAndSync();
        }
    }

    private Map<AspectId, Integer> breakableAspects() {
        ItemStack input = this.items.get(INPUT_SLOT);
        return input.isEmpty() || this.aspect != null ? Map.of() : AspectQueryApi.item(input).amounts();
    }

    public boolean canBreak() {
        return !this.breakableAspects().isEmpty();
    }

    public void breakItem(RandomSource random) {
        this.breakItem(this.breakableAspects(), random);
    }

    private void breakItem(Map<AspectId, Integer> inputAspects, RandomSource random) {
        if (inputAspects.isEmpty()) {
            return;
        }
        this.aspect = rollBreakResult(inputAspects, random);
        this.items.get(INPUT_SLOT).shrink(1);
        if (this.items.get(INPUT_SLOT).isEmpty()) {
            this.items.set(INPUT_SLOT, ItemStack.EMPTY);
        }
    }

    /**
     * Reduces every compound recursively with add (not merge), then applies
     * TC4's {@code nextInt(dev.tc4port.thaumcraft.common.TCGameplayParameters.MACHINES_DECONSTRUCTION_TABLE_LOSS_ROLL_BOUND.intValue()) < total primal vis} loss roll.
     */
    @Nullable
    public static AspectId rollBreakResult(Map<AspectId, Integer> source, RandomSource random) {
        AspectList primals = AspectCatalog.reduceToPrimals(new AspectList(source), false);
        if (primals.size() == 0 || random.nextInt(dev.tc4port.thaumcraft.common.TCGameplayParameters.MACHINES_DECONSTRUCTION_TABLE_LOSS_ROLL_BOUND.intValue()) >= primals.visSize()) {
            return null;
        }
        return primals.aspects().get(random.nextInt(primals.aspects().size()));
    }

    public boolean claimAspect(Player player) {
        if (this.level == null || this.level.isClientSide || !AspectCatalog.contains(this.aspect)) {
            return false;
        }
        if (player instanceof net.minecraft.server.level.ServerPlayer server) {
            AspectPoolApi.add(server, this.aspect, dev.tc4port.thaumcraft.common.TCGameplayParameters.MACHINES_DECONSTRUCTION_TABLE_REWARD_POINTS.intValue(), VisAction.EXECUTE);
        } else {
            // GameTest's logical-server mock is not a ServerPlayer.
            PlayerKnowledgeService.addAspectPoolWithFeedback(player, this.aspect, dev.tc4port.thaumcraft.common.TCGameplayParameters.MACHINES_DECONSTRUCTION_TABLE_REWARD_POINTS.intValue());
        }
        this.aspect = null;
        this.changedAndSync();
        return true;
    }

    @Nullable
    public AspectId aspect() {
        return this.aspect;
    }

    @Override
    public boolean hasItem() {
        return !this.items.get(INPUT_SLOT).isEmpty();
    }

    @Override
    public Optional<AspectId> currentAspect() {
        return this.aspect == null ? Optional.empty() : Optional.of(this.aspect);
    }

    public int breakTime() {
        return this.breakTime;
    }

    public ContainerData data() {
        return this.data;
    }

    private void changedAndSync() {
        super.setChanged();
        BlockEntitySync.sendToClient(this);
    }

    @Nullable
    private static AspectId parseStoredAspect(@Nullable String value) {
        try {
            return value == null || value.isBlank() ? null : AspectId.parse(value);
        } catch (RuntimeException ignored) {
            return null;
        }
    }

    @Override
    public void setChanged() {
        this.changedAndSync();
    }

    @Override
    public int getContainerSize() {
        return CONTAINER_SIZE;
    }

    @Override
    protected Component getDefaultName() {
        return Component.translatable("container.thaumcraft.deconstruction_table");
    }

    protected NonNullList<ItemStack> getItems() {
        return this.items;
    }

    protected void setItems(NonNullList<ItemStack> items) {
        this.items = items;
    }

    @Override
    public boolean canPlaceItem(int slot, ItemStack stack) {
        return slot == INPUT_SLOT && !AspectQueryApi.item(stack).amounts().isEmpty();
    }

    @Override
    public int[] getSlotsForFace(Direction side) {
        return side == Direction.UP ? NO_SLOTS : INPUT_SLOT_ARRAY;
    }

    @Override
    public boolean canPlaceItemThroughFace(int index, ItemStack stack, Direction direction) {
        return direction != Direction.UP && this.canPlaceItem(index, stack);
    }

    @Override
    public boolean canTakeItemThroughFace(int index, ItemStack stack, Direction direction) {
        return direction != Direction.UP && index == INPUT_SLOT;
    }

    @Override
    public void load(CompoundTag tag) {
        HolderLookup.Provider registries = persistenceRegistries();
        super.load(tag);
        this.items = NonNullList.withSize(CONTAINER_SIZE, ItemStack.EMPTY);
        {
            net.minecraft.nbt.CompoundTag native$operand$14349 = tag;
            net.minecraft.core.NonNullList<net.minecraft.world.item.ItemStack> native$operand$14350 = this.items;
            net.minecraft.core.HolderLookup.Provider native$operand$14351 = registries;
            net.minecraft.world.ContainerHelper.loadAllItems(native$operand$14349, native$operand$14350);
        }
        String storedAspect = tag.getString("Aspect");
        this.aspect = parseStoredAspect(storedAspect);
        // breakTime intentionally resets on load.
        this.breakTime = 0;
    }

    @Override
    protected void saveAdditional(CompoundTag tag) {
        HolderLookup.Provider registries = persistenceRegistries();
        super.saveAdditional(tag);
        {
            net.minecraft.nbt.CompoundTag native$operand$14352 = tag;
            net.minecraft.core.NonNullList<net.minecraft.world.item.ItemStack> native$operand$14353 = this.items;
            net.minecraft.core.HolderLookup.Provider native$operand$14354 = registries;
            net.minecraft.nbt.CompoundTag native$result$14355 = (net.minecraft.world.ContainerHelper.saveAllItems(native$operand$14352, native$operand$14353));
        }
        if (this.aspect != null) {
            tag.putString("Aspect", this.aspect.serialized());
        }
    }

    @Override
    public CompoundTag getUpdateTag() {
        return this.saveWithoutMetadata();
    }

    @Override
    public Packet<ClientGamePacketListener> getUpdatePacket() {
        return ClientboundBlockEntityDataPacket.create(this);
    }

    @Override
    protected AbstractContainerMenu createMenu(int containerId, Inventory inventory) {
        // Vanilla spectator opening bypasses our extra-data menu transport.
        if (inventory.player.isSpectator()) {
            return null;
        }
        return new DeconstructionTableMenu(containerId, inventory, this, this.data);
    }

    protected final HolderLookup.Provider persistenceRegistries() {
        if (level != null)
            return level.registryAccess();
        var server = net.minecraftforge.server.ServerLifecycleHooks.getCurrentServer();
        return server != null ? server.registryAccess() : net.minecraft.core.RegistryAccess.fromRegistryOfRegistries(net.minecraft.core.registries.BuiltInRegistries.REGISTRY);
    }

    protected static net.minecraft.network.chat.Component parseCustomNameSafe(String value, HolderLookup.Provider registries) {
        try {
            return net.minecraft.network.chat.Component.Serializer.fromJson(value);
        } catch (RuntimeException exception) {
            return null;
        }
    }

    @Override
    public boolean isEmpty() {
        return (switch(0) {
            default ->
                {
                    net.minecraft.core.NonNullList<net.minecraft.world.item.ItemStack> native$bodyResult$4856 = null;
                    native$bodyReturn$4857: {
                        if (true) {
                            {
                                native$bodyResult$4856 = this.items;
                                break native$bodyReturn$4857;
                            }
                        }
                    }
                    yield native$bodyResult$4856;
                }
        }).stream().allMatch(ItemStack::isEmpty);
    }

    @Override
    public ItemStack getItem(int index) {
        return (switch(0) {
            default ->
                {
                    net.minecraft.core.NonNullList<net.minecraft.world.item.ItemStack> native$bodyResult$5371 = null;
                    native$bodyReturn$5372: {
                        if (true) {
                            {
                                native$bodyResult$5371 = this.items;
                                break native$bodyReturn$5372;
                            }
                        }
                    }
                    yield native$bodyResult$5371;
                }
        }).get(index);
    }

    @Override
    public ItemStack removeItem(int index, int count) {
        ItemStack removed = net.minecraft.world.ContainerHelper.removeItem((switch(0) {
            default ->
                {
                    net.minecraft.core.NonNullList<net.minecraft.world.item.ItemStack> native$bodyResult$3955 = null;
                    native$bodyReturn$3956: {
                        if (true) {
                            {
                                native$bodyResult$3955 = this.items;
                                break native$bodyReturn$3956;
                            }
                        }
                    }
                    yield native$bodyResult$3955;
                }
        }), index, count);
        if (!removed.isEmpty())
            setChanged();
        return removed;
    }

    @Override
    public ItemStack removeItemNoUpdate(int index) {
        return net.minecraft.world.ContainerHelper.takeItem((switch(0) {
            default ->
                {
                    net.minecraft.core.NonNullList<net.minecraft.world.item.ItemStack> native$bodyResult$5373 = null;
                    native$bodyReturn$5374: {
                        if (true) {
                            {
                                native$bodyResult$5373 = this.items;
                                break native$bodyReturn$5374;
                            }
                        }
                    }
                    yield native$bodyResult$5373;
                }
        }), index);
    }

    @Override
    public void setItem(int index, ItemStack stack) {
        (switch(0) {
            default ->
                {
                    net.minecraft.core.NonNullList<net.minecraft.world.item.ItemStack> native$bodyResult$5375 = null;
                    native$bodyReturn$5376: {
                        if (true) {
                            {
                                native$bodyResult$5375 = this.items;
                                break native$bodyReturn$5376;
                            }
                        }
                    }
                    yield native$bodyResult$5375;
                }
        }).set(index, stack);
        int limit = Math.min(getMaxStackSize(), stack.getMaxStackSize());
        if (stack.getCount() > limit)
            stack.setCount(limit);
        setChanged();
    }

    @Override
    public void clearContent() {
        (switch(0) {
            default ->
                {
                    net.minecraft.core.NonNullList<net.minecraft.world.item.ItemStack> native$bodyResult$5377 = null;
                    native$bodyReturn$5378: {
                        if (true) {
                            {
                                native$bodyResult$5377 = this.items;
                                break native$bodyReturn$5378;
                            }
                        }
                    }
                    yield native$bodyResult$5377;
                }
        }).clear();
    }

    @Override
    public boolean stillValid(net.minecraft.world.entity.player.Player player) {
        return net.minecraft.world.Container.stillValidBlockEntity(this, player);
    }

    @Override
    public net.minecraft.world.phys.AABB getRenderBoundingBox() {
        return DeconstructionTableBlockEntity.native$ClientBlockEntityBounds$bounds(this);
    }

    @Override()
    public void onDataPacket(net.minecraft.network.Connection connection, net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket packet) {
        handleUpdateTag(packet.getTag());
    }

    @SuppressWarnings({ "rawtypes", "unchecked" })
    static private net.minecraft.world.phys.AABB native$ClientBlockEntityBounds$bounds(net.minecraft.world.level.block.entity.BlockEntity blockEntity) {
        var renderer = net.minecraft.client.Minecraft.getInstance().getBlockEntityRenderDispatcher().getRenderer(blockEntity);
        return renderer instanceof dev.tc4port.thaumcraft.nativeimpl.NativeBlockEntityRenderer shared ? shared.getRenderBoundingBox(blockEntity) : new net.minecraft.world.phys.AABB(blockEntity.getBlockPos());
    }

    private boolean native$capabilitiesInvalid$16979;

    public boolean native$capabilityActive$16820;

    private java.util.Map<net.minecraft.core.Direction, net.minecraftforge.common.util.LazyOptional<net.minecraftforge.items.IItemHandler>> native$capabilityHandle$16821;

    @Override
    public <native$capabilityResultType$16980> net.minecraftforge.common.util.LazyOptional<native$capabilityResultType$16980> getCapability(net.minecraftforge.common.capabilities.Capability<native$capabilityResultType$16980> native$requestedCapability$16981, net.minecraft.core.Direction native$requestedFace$16982) {
        getCapabilities();
        synchronized (this) {
            if (native$capabilitiesInvalid$16979)
                return net.minecraftforge.common.util.LazyOptional.empty();
            if (native$capabilityActive$16820 && native$requestedCapability$16981 == (net.minecraftforge.common.capabilities.ForgeCapabilities.ITEM_HANDLER)) {
                if (native$capabilityHandle$16821 == null)
                    native$capabilityHandle$16821 = new java.util.HashMap<>();
                net.minecraftforge.common.util.LazyOptional<net.minecraftforge.items.IItemHandler> native$capabilityResult$16984 = native$capabilityHandle$16821.computeIfAbsent(native$requestedFace$16982, native$capabilityFace$16822 -> {
                    net.minecraftforge.items.IItemHandler native$endpoint$181 = (switch(0) {
                        default ->
                            {
                                net.minecraft.world.WorldlyContainer native$operand$12770 = dev.tc4port.thaumcraft.block.entity.DeconstructionTableBlockEntity.this;
                                net.minecraft.core.Direction native$operand$12771 = native$capabilityFace$16822;
                                net.minecraftforge.items.IItemHandler native$result$12772 = (new net.minecraftforge.items.wrapper.SidedInvWrapper(native$operand$12770, native$operand$12771));
                                yield native$result$12772;
                            }
                    });
                    return native$endpoint$181 == null ? net.minecraftforge.common.util.LazyOptional.empty() : net.minecraftforge.common.util.LazyOptional.of(() -> native$endpoint$181);
                });
                if (native$capabilityResult$16984.isPresent())
                    return native$capabilityResult$16984.cast();
            }
        }
        return super.getCapability(native$requestedCapability$16981, native$requestedFace$16982);
    }

    @Override
    public void invalidateCaps() {
        java.util.List<net.minecraftforge.common.util.LazyOptional<?>> native$expiredCapabilities$16983 = new java.util.ArrayList<>();
        synchronized (this) {
            native$capabilitiesInvalid$16979 = true;
            if (native$capabilityHandle$16821 != null) {
                native$expiredCapabilities$16983.addAll(native$capabilityHandle$16821.values());
                native$capabilityHandle$16821 = null;
            }
        }
        try {
            super.invalidateCaps();
        } finally {
            native$expiredCapabilities$16983.forEach(net.minecraftforge.common.util.LazyOptional::invalidate);
        }
    }

    @Override
    public void reviveCaps() {
        super.reviveCaps();
        synchronized (this) {
            native$capabilitiesInvalid$16979 = false;
        }
    }
}
