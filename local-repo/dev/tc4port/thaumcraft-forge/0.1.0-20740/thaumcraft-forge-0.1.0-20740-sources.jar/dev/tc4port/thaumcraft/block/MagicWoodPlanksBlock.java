package dev.tc4port.thaumcraft.block;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import dev.tc4port.thaumcraft.nativeimpl.ClientExtensionTarget;
import dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.level.pathfinder.PathComputationType;
import net.minecraft.world.phys.HitResult;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.Explosion;

/**
 * Shared block behavior for greatwood and silverwood planks.
 *
 * <p>They were metadata six/seven of TC4's wooden-device block. They look
 * and collide like ordinary planks, but the aggregate source
 * block was non-opaque/non-normal, blocked all light explicitly, was destroyed
 * by pistons and supplied its own 5/20 fire values.  A vanilla-planks copy
 * silently loses several of those unusual inherited behaviours.</p>
 */
public final class MagicWoodPlanksBlock extends net.minecraft.world.level.block.Block implements dev.tc4port.thaumcraft.nativeimpl.ClientExtensionTarget {

    // Forge calls initializeClient from the native superclass constructor. Do not add a field initializer.
    private java.util.function.Consumer<net.minecraftforge.client.extensions.common.IClientBlockExtensions> platform$clientInstaller;

    public MagicWoodPlanksBlock(BlockBehaviour.Properties properties) {
        this(properties, properties, true);
    }

    @Override
    public int getLightBlock(BlockState state, BlockGetter level, BlockPos pos) {
        return level.getMaxLightLevel();
    }

    @Override
    public int getFlammability(BlockState state, BlockGetter level, BlockPos pos, Direction direction) {
        return 20;
    }

    @Override
    public int getFireSpreadSpeed(BlockState state, BlockGetter level, BlockPos pos, Direction direction) {
        return 5;
    }

    private MagicWoodPlanksBlock(net.minecraft.world.level.block.state.BlockBehaviour.Properties native$NativeBlock$arg0, BlockBehaviour.Properties properties, boolean native$NativeBlock$captured) {
        super(native$NativeBlock$arg0);
    }

    @Override
    public void initializeClient(java.util.function.Consumer<net.minecraftforge.client.extensions.common.IClientBlockExtensions> installer) {
        platform$clientInstaller = installer;
        super.initializeClient(installer);
    }

    @Override
    public void platform$clientExtension(Object extension) {
        java.util.Objects.requireNonNull(platform$clientInstaller, "Forge initializeClient must run before client extension registration").accept((net.minecraftforge.client.extensions.common.IClientBlockExtensions) extension);
    }

    @Override
    public InteractionResult use(BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
        ItemUseResult result = (switch(0) {
            default ->
                {
                    net.minecraft.world.item.ItemStack native$bodyOperand$4573 = player.getItemInHand(hand);
                    net.minecraft.world.level.block.state.BlockState native$bodyOperand$4574 = state;
                    net.minecraft.world.level.Level native$bodyOperand$4575 = level;
                    net.minecraft.core.BlockPos native$bodyOperand$4576 = pos;
                    net.minecraft.world.entity.player.Player native$bodyOperand$4577 = player;
                    net.minecraft.world.InteractionHand native$bodyOperand$4578 = hand;
                    net.minecraft.world.phys.BlockHitResult native$bodyOperand$4579 = hit;
                    dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult native$bodyResult$4580 = null;
                    native$bodyReturn$4581: {
                        if (true) {
                            {
                                native$bodyResult$4580 = dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
                                break native$bodyReturn$4581;
                            }
                        }
                    }
                    yield native$bodyResult$4580;
                }
        });
        return result == ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION ? (hand == InteractionHand.MAIN_HAND ? (switch(0) {
            default ->
                {
                    net.minecraft.world.level.block.state.BlockState native$bodyOperand$3766 = state;
                    net.minecraft.world.level.Level native$bodyOperand$3767 = level;
                    net.minecraft.core.BlockPos native$bodyOperand$3768 = pos;
                    net.minecraft.world.entity.player.Player native$bodyOperand$3769 = player;
                    net.minecraft.world.phys.BlockHitResult native$bodyOperand$3770 = hit;
                    net.minecraft.world.InteractionResult native$bodyResult$3771 = null;
                    native$bodyReturn$3772: {
                        if (true) {
                            {
                                native$bodyResult$3771 = super.use(native$bodyOperand$3766, native$bodyOperand$3767, native$bodyOperand$3768, native$bodyOperand$3769, net.minecraft.world.InteractionHand.MAIN_HAND, native$bodyOperand$3770);
                                break native$bodyReturn$3772;
                            }
                        }
                    }
                    yield native$bodyResult$3771;
                }
        }) : InteractionResult.PASS) : result.result();
    }

    protected ItemUseResult interactWithItem(ItemStack stack, BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
        return dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
    }

    protected InteractionResult interactWithoutItem(BlockState state, Level level, BlockPos pos, Player player, BlockHitResult hit) {
        return super.use(state, level, pos, player, net.minecraft.world.InteractionHand.MAIN_HAND, hit);
    }

    @Override
    public void playerWillDestroy(Level level, BlockPos pos, BlockState state, Player player) {
        {
            net.minecraft.world.level.Level native$bodyOperand$5918 = level;
            net.minecraft.core.BlockPos native$bodyOperand$5919 = pos;
            net.minecraft.world.level.block.state.BlockState native$bodyOperand$5920 = state;
            net.minecraft.world.entity.player.Player native$bodyOperand$5921 = player;
            net.minecraft.world.level.block.state.BlockState native$bodyResult$5922 = null;
            native$bodyReturn$5923: {
                if (true) {
                    super.playerWillDestroy(native$bodyOperand$5918, native$bodyOperand$5919, native$bodyOperand$5920, native$bodyOperand$5921);
                    {
                        native$bodyResult$5922 = native$bodyOperand$5920;
                        break native$bodyReturn$5923;
                    }
                }
            }
        }
    }

    public BlockState beforePlayerDestroy(Level level, BlockPos pos, BlockState state, Player player) {
        super.playerWillDestroy(level, pos, state, player);
        return state;
    }

    protected boolean survivesSharedExplosion() {
        return false;
    }

    public int getExpDrop(net.minecraft.world.level.block.state.BlockState native$callbackInput$1145, net.minecraft.world.level.LevelReader native$callbackInput$1146, net.minecraft.util.RandomSource native$callbackInput$1147, net.minecraft.core.BlockPos native$callbackInput$1148, int native$callbackInput$1149, int native$callbackInput$1150) {
        net.minecraft.world.level.block.state.BlockState state = native$callbackInput$1145;
        net.minecraft.util.RandomSource random = native$callbackInput$1147;
        return 0;
    }

    @Override
    public void onBlockExploded(BlockState state, Level level, BlockPos pos, Explosion explosion) {
        if (!(switch(0) {
            default ->
                {
                    boolean native$bodyResult$5291 = false;
                    native$bodyReturn$5292: {
                        if (true) {
                            {
                                native$bodyResult$5291 = false;
                                break native$bodyReturn$5292;
                            }
                        }
                    }
                    yield native$bodyResult$5291;
                }
        }))
            super.onBlockExploded(state, level, pos, explosion);
    }

    @Override
    public boolean canDropFromExplosion(BlockState state, BlockGetter level, BlockPos pos, Explosion explosion) {
        return !(switch(0) {
            default ->
                {
                    boolean native$bodyResult$4582 = false;
                    native$bodyReturn$4583: {
                        if (true) {
                            {
                                native$bodyResult$4582 = false;
                                break native$bodyReturn$4583;
                            }
                        }
                    }
                    yield native$bodyResult$4582;
                }
        }) && super.canDropFromExplosion(state, level, pos, explosion);
    }
}
