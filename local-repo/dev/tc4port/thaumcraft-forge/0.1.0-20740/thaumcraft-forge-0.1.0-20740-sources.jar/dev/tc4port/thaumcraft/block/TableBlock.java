package dev.tc4port.thaumcraft.block;

import dev.tc4port.thaumcraft.registry.TCSounds;
import com.mojang.serialization.MapCodec;
import dev.tc4port.thaumcraft.block.entity.ArcaneWorktableBlockEntity;
import dev.tc4port.thaumcraft.common.CompoundBlueprintCatalog;
import dev.tc4port.thaumcraft.api.wand.WandCarrierItem;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.Rotation;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.EnumProperty;
import net.minecraft.world.phys.shapes.VoxelShape;
import dev.tc4port.thaumcraft.nativeimpl.ClientExtensionTarget;
import dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.level.pathfinder.PathComputationType;
import net.minecraft.world.phys.HitResult;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.Explosion;

/**
 * Metadata 0/1 plain table with its source trestle orientation.
 */
public final class TableBlock extends net.minecraft.world.level.block.Block implements dev.tc4port.thaumcraft.nativeimpl.ClientExtensionTarget {

    // Forge calls initializeClient from the native superclass constructor. Do not add a field initializer.
    private java.util.function.Consumer<net.minecraftforge.client.extensions.common.IClientBlockExtensions> platform$clientInstaller;

    public static final MapCodec<TableBlock> CODEC = TableBlock.native$BlockCodecPlatform$simple(TableBlock::new);

    public static final EnumProperty<Direction.Axis> HORIZONTAL_AXIS = BlockStateProperties.HORIZONTAL_AXIS;

    static final VoxelShape TOP_SUPPORT = Block.box(0.0, 15.0, 0.0, 16.0, 16.0, 16.0);

    public TableBlock(BlockBehaviour.Properties properties) {
        this(properties, properties, true);
    }

    protected MapCodec<TableBlock> codec() {
        return CODEC;
    }

    @Override
    public RenderShape getRenderShape(BlockState state) {
        return RenderShape.MODEL;
    }

    @Override
    public VoxelShape getBlockSupportShape(BlockState state, BlockGetter level, BlockPos pos) {
        return TOP_SUPPORT;
    }

    @Override
    public BlockState getStateForPlacement(BlockPlaceContext context) {
        return this.defaultBlockState().setValue(HORIZONTAL_AXIS, context.getHorizontalDirection().getAxis());
    }

    public static InteractionResult tryTransform(UseOnContext context) {
        if (!(context.getItemInHand().getItem() instanceof WandCarrierItem) || !CompoundBlueprintCatalog.isTrigger(CompoundBlueprintCatalog.ARCANE_WORKTABLE, context.getLevel().getBlockState(context.getClickedPos()))) {
            return InteractionResult.PASS;
        }
        Player player = context.getPlayer();
        Block output = CompoundBlueprintCatalog.outputBlock(CompoundBlueprintCatalog.ARCANE_WORKTABLE);
        if (player == null || output == null) {
            return InteractionResult.PASS;
        }
        if (!context.getLevel().isClientSide) {
            BlockPos pos = context.getClickedPos();
            context.getLevel().setBlock(pos, output.defaultBlockState(), Block.UPDATE_ALL);
            if (context.getLevel().getBlockEntity(pos) instanceof ArcaneWorktableBlockEntity worktable && !context.getItemInHand().isEmpty() && !(context.getItemInHand().getItem() instanceof WandCarrierItem wand && wand.requiresBothHands(context.getItemInHand()))) {
                worktable.setItem(ArcaneWorktableBlockEntity.WAND_SLOT, context.getItemInHand().copy());
                /*
                 * BlockTable removed an ordinary wand from the held slot
                 * even for creative players.  This is intentionally not the
                 * usual modern creative-item duplication behaviour.
                 */
                player.setItemInHand(context.getHand(), ItemStack.EMPTY);
            }
            context.getLevel().playSound(null, pos, TCSounds.WORKTABLE_CREATE.get(), SoundSource.BLOCKS, 0.15F, 0.5F);
        }
        player.swing(context.getHand());
        return InteractionResult.sidedSuccess(context.getLevel().isClientSide);
    }

    @Override
    public BlockState rotate(BlockState state, Rotation rotation) {
        if (rotation == Rotation.CLOCKWISE_90 || rotation == Rotation.COUNTERCLOCKWISE_90) {
            return state.cycle(HORIZONTAL_AXIS);
        }
        return state;
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(HORIZONTAL_AXIS);
    }

    private TableBlock(net.minecraft.world.level.block.state.BlockBehaviour.Properties native$NativeBlock$arg0, BlockBehaviour.Properties properties, boolean native$NativeBlock$captured) {
        super(native$NativeBlock$arg0);
        this.registerDefaultState(this.stateDefinition.any().setValue(HORIZONTAL_AXIS, Direction.Axis.Z));
    }

    @Override
    public void initializeClient(java.util.function.Consumer<net.minecraftforge.client.extensions.common.IClientBlockExtensions> installer) {
        platform$clientInstaller = installer;
        super.initializeClient(installer);
    }

    @Override
    public void platform$clientExtension(Object extension) {
        java.util.Objects.requireNonNull(platform$clientInstaller, "Forge initializeClient must run before client extension registration").accept((net.minecraftforge.client.extensions.common.IClientBlockExtensions) extension);
    }

    @Override
    public InteractionResult use(BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
        ItemUseResult result = (switch(0) {
            default ->
                {
                    net.minecraft.world.item.ItemStack native$bodyOperand$4709 = player.getItemInHand(hand);
                    net.minecraft.world.level.block.state.BlockState native$bodyOperand$4710 = state;
                    net.minecraft.world.level.Level native$bodyOperand$4711 = level;
                    net.minecraft.core.BlockPos native$bodyOperand$4712 = pos;
                    net.minecraft.world.entity.player.Player native$bodyOperand$4713 = player;
                    net.minecraft.world.InteractionHand native$bodyOperand$4714 = hand;
                    net.minecraft.world.phys.BlockHitResult native$bodyOperand$4715 = hit;
                    dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult native$bodyResult$4716 = null;
                    native$bodyReturn$4717: {
                        if (true) {
                            {
                                native$bodyResult$4716 = dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
                                break native$bodyReturn$4717;
                            }
                        }
                    }
                    yield native$bodyResult$4716;
                }
        });
        return result == ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION ? (hand == InteractionHand.MAIN_HAND ? (switch(0) {
            default ->
                {
                    net.minecraft.world.level.block.state.BlockState native$bodyOperand$3854 = state;
                    net.minecraft.world.level.Level native$bodyOperand$3855 = level;
                    net.minecraft.core.BlockPos native$bodyOperand$3856 = pos;
                    net.minecraft.world.entity.player.Player native$bodyOperand$3857 = player;
                    net.minecraft.world.phys.BlockHitResult native$bodyOperand$3858 = hit;
                    net.minecraft.world.InteractionResult native$bodyResult$3859 = null;
                    native$bodyReturn$3860: {
                        if (true) {
                            {
                                native$bodyResult$3859 = super.use(native$bodyOperand$3854, native$bodyOperand$3855, native$bodyOperand$3856, native$bodyOperand$3857, net.minecraft.world.InteractionHand.MAIN_HAND, native$bodyOperand$3858);
                                break native$bodyReturn$3860;
                            }
                        }
                    }
                    yield native$bodyResult$3859;
                }
        }) : InteractionResult.PASS) : result.result();
    }

    protected ItemUseResult interactWithItem(ItemStack stack, BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
        return dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
    }

    protected InteractionResult interactWithoutItem(BlockState state, Level level, BlockPos pos, Player player, BlockHitResult hit) {
        return super.use(state, level, pos, player, net.minecraft.world.InteractionHand.MAIN_HAND, hit);
    }

    @Override
    public void playerWillDestroy(Level level, BlockPos pos, BlockState state, Player player) {
        {
            net.minecraft.world.level.Level native$bodyOperand$5998 = level;
            net.minecraft.core.BlockPos native$bodyOperand$5999 = pos;
            net.minecraft.world.level.block.state.BlockState native$bodyOperand$6000 = state;
            net.minecraft.world.entity.player.Player native$bodyOperand$6001 = player;
            net.minecraft.world.level.block.state.BlockState native$bodyResult$6002 = null;
            native$bodyReturn$6003: {
                if (true) {
                    super.playerWillDestroy(native$bodyOperand$5998, native$bodyOperand$5999, native$bodyOperand$6000, native$bodyOperand$6001);
                    {
                        native$bodyResult$6002 = native$bodyOperand$6000;
                        break native$bodyReturn$6003;
                    }
                }
            }
        }
    }

    public BlockState beforePlayerDestroy(Level level, BlockPos pos, BlockState state, Player player) {
        super.playerWillDestroy(level, pos, state, player);
        return state;
    }

    protected boolean survivesSharedExplosion() {
        return false;
    }

    public int getExpDrop(net.minecraft.world.level.block.state.BlockState native$callbackInput$1145, net.minecraft.world.level.LevelReader native$callbackInput$1146, net.minecraft.util.RandomSource native$callbackInput$1147, net.minecraft.core.BlockPos native$callbackInput$1148, int native$callbackInput$1149, int native$callbackInput$1150) {
        net.minecraft.world.level.block.state.BlockState state = native$callbackInput$1145;
        net.minecraft.util.RandomSource random = native$callbackInput$1147;
        return 0;
    }

    @Override
    public void onBlockExploded(BlockState state, Level level, BlockPos pos, Explosion explosion) {
        if (!(switch(0) {
            default ->
                {
                    boolean native$bodyResult$5315 = false;
                    native$bodyReturn$5316: {
                        if (true) {
                            {
                                native$bodyResult$5315 = false;
                                break native$bodyReturn$5316;
                            }
                        }
                    }
                    yield native$bodyResult$5315;
                }
        }))
            super.onBlockExploded(state, level, pos, explosion);
    }

    @Override
    public boolean canDropFromExplosion(BlockState state, BlockGetter level, BlockPos pos, Explosion explosion) {
        return !(switch(0) {
            default ->
                {
                    boolean native$bodyResult$4718 = false;
                    native$bodyReturn$4719: {
                        if (true) {
                            {
                                native$bodyResult$4718 = false;
                                break native$bodyReturn$4719;
                            }
                        }
                    }
                    yield native$bodyResult$4718;
                }
        }) && super.canDropFromExplosion(state, level, pos, explosion);
    }

    static private <B extends net.minecraft.world.level.block.Block> com.mojang.serialization.MapCodec<B> native$BlockCodecPlatform$simple(java.util.function.Function<net.minecraft.world.level.block.state.BlockBehaviour.Properties, B> factory) {
        // Vanilla 1.21's Properties codec is a unit codec. Retain that schema for shared block definitions.
        return com.mojang.serialization.codecs.RecordCodecBuilder.mapCodec(instance -> instance.group(com.mojang.serialization.Codec.unit(net.minecraft.world.level.block.state.BlockBehaviour.Properties::of).fieldOf("properties").forGetter((B block) -> net.minecraft.world.level.block.state.BlockBehaviour.Properties.copy(block))).apply(instance, factory));
    }
}
