package dev.tc4port.thaumcraft.api.client;

import dev.tc4port.thaumcraft.client.FortressArmorClientExtensions;
import java.util.Objects;
import java.util.function.Predicate;
import net.minecraft.world.item.ItemStack;

/**
 * Client-only access to TC4's exact legacy Fortress Armor mesh.
 */
public final class FortressArmorRenderApi {

    private FortressArmorRenderApi() {
    }

    /**
     * Creates an isolated client extension for an addon's fortress family.
     *
     * <p>The predicate must recognize every helmet, chestplate and leggings
     * identity that participates in the addon's visual set counter. Infusion
     * goggles and masks are read through {@code InfusionEquipmentApi}; callers
     * never receive mutable access to Thaumcraft components or models.</p>
     *
     * <p>To share core/addon set counting, extend
     * {@link dev.tc4port.thaumcraft.api.ThaumcraftTags#FORTRESS_ARMOR} and test
     * that tag in the predicate. Its members also inherit the core's covered
     * player-skin overlay hiding through {@code thaumcraft:hides_skin_layers}.</p>
     */
    public static dev.tc4port.thaumcraft.api.client.NativeItemClientExtensions create(Predicate<ItemStack> fortressPiece) {
        return FortressArmorClientExtensions.forItems(Objects.requireNonNull(fortressPiece, "fortressPiece"));
    }
}
