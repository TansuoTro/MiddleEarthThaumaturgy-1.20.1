package dev.tc4port.thaumcraft.api.presentation;

/**
 * Delivery policy for audiovisual action feedback.
 *
 * <p>No policy authorizes gameplay. {@link #PREDICTED} is the low-latency
 * shared-side path: the local actor presents immediately and a successful
 * server execution is sent only to other observers. The confirmed policies
 * never run from a client attempt and are intended for effects whose final
 * target or success is server-owned.</p>
 */
public enum ActionPresentationAudience {

    /**
     * No automatic presentation; explicit transaction events remain available.
     */
    NONE,
    /**
     * Predict locally; an action-specific transport owns observer effects.
     */
    LOCAL_ONLY,
    /**
     * Predict for the local actor and confirm only to other observers.
     */
    PREDICTED,
    /**
     * Send a server-confirmed event to every nearby player.
     */
    CONFIRMED_ALL,
    /**
     * Send a server-confirmed event only to observers other than the actor.
     */
    CONFIRMED_OBSERVERS;

    public boolean predictsLocally() {
        return this == PREDICTED || this == LOCAL_ONLY;
    }

    public boolean sendsConfirmation() {
        return this == PREDICTED || this == CONFIRMED_ALL || this == CONFIRMED_OBSERVERS;
    }
}
