package dev.tc4port.thaumcraft.block;

import com.mojang.serialization.MapCodec;
import net.minecraft.world.level.block.HalfTransparentBlock;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.Explosion;

/**
 * Shared translucent behavior for the two stable amber block identities.
 *
 * <p>These were metadata zero and one of TC4's
 * {@code BlockCosmeticOpaque}.</p>
 */
public final class TranslucentAmberBlock extends HalfTransparentBlock {

    public TranslucentAmberBlock(BlockBehaviour.Properties properties) {
        super(properties);
    }

    @Override
    public int getLightBlock(BlockState state, BlockGetter level, BlockPos pos) {
        return 3;
    }

    @Override
    public boolean canDropFromExplosion(BlockState state, BlockGetter level, BlockPos pos, Explosion explosion) {
        return false;
    }

    public static final MapCodec<TranslucentAmberBlock> CODEC = TranslucentAmberBlock.native$BlockCodecPlatform$simple(TranslucentAmberBlock::new);

    protected MapCodec<? extends TranslucentAmberBlock> codec() {
        return CODEC;
    }

    static private <B extends net.minecraft.world.level.block.Block> com.mojang.serialization.MapCodec<B> native$BlockCodecPlatform$simple(java.util.function.Function<net.minecraft.world.level.block.state.BlockBehaviour.Properties, B> factory) {
        // Vanilla 1.21's Properties codec is a unit codec. Retain that schema for shared block definitions.
        return com.mojang.serialization.codecs.RecordCodecBuilder.mapCodec(instance -> instance.group(com.mojang.serialization.Codec.unit(net.minecraft.world.level.block.state.BlockBehaviour.Properties::of).fieldOf("properties").forGetter((B block) -> net.minecraft.world.level.block.state.BlockBehaviour.Properties.copy(block))).apply(instance, factory));
    }
}
