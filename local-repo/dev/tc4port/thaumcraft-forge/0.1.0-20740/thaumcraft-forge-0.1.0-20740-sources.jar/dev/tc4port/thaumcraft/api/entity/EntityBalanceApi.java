package dev.tc4port.thaumcraft.api.entity;

import dev.tc4port.thaumcraft.registry.TCRegistryDataMaps;
import dev.tc4port.thaumcraft.api.entity.AttributeTypes;
import dev.tc4port.thaumcraft.nativeimpl.AttributeModifiers;
import dev.tc4port.thaumcraft.api.event.AttributeOperation;
import java.util.Map;
import java.util.HashSet;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;

/**
 * Public lookup, configured creation and reconciliation of data-defined mob defaults.
 */
public final class EntityBalanceApi {

    private static Map<?, ?> previousDefinitions = Map.of();

    private EntityBalanceApi() {
    }

    public static EntityBalanceDefinition definition(EntityType<?> type) {
        var value = TCRegistryDataMaps.ENTITY_BALANCE.get(type.builtInRegistryHolder());
        return value == null ? EntityBalanceDefinition.EMPTY : value;
    }

    public static double number(Mob entity, String key, double fallback) {
        return definition(entity.getType()).abilities().getOrDefault(key, fallback);
    }

    public static int integer(Mob entity, String key, int fallback) {
        return (int) number(entity, key, fallback);
    }

    public static <T extends Mob> T create(EntityType<T> type, ServerLevel level) {
        T entity = type.create(level);
        if (entity != null)
            apply(entity);
        return entity;
    }

    /**
     * Apply an explicit individual base value, preserving its priority through save/load.
     */
    public static void setIndividualAttribute(Mob entity, ResourceLocation key, double value) {
        if (!Double.isFinite(value) || value < -1_000_000 || value > 1_000_000)
            throw new IllegalArgumentException("Invalid individual attribute value");
        var attribute = AttributeTypes.resolve(entity, key);
        if (attribute == null)
            throw new IllegalArgumentException("Entity has no attribute " + key);
        var overrides = new java.util.ArrayList<>(dev.tc4port.thaumcraft.state.TCObjectState.INDIVIDUAL_ATTRIBUTES.get(entity));
        if (!overrides.contains(key)) {
            if (overrides.size() >= 64)
                throw new IllegalArgumentException("Too many individual attributes");
            overrides.add(key);
            dev.tc4port.thaumcraft.state.TCObjectState.INDIVIDUAL_ATTRIBUTES.set(entity, java.util.List.copyOf(overrides));
        }
        attribute.setBaseValue(value);
        apply(entity);
    }

    /**
     * Individual base values (for example a summon recipe) take precedence over these defaults.
     */
    public static void apply(Mob entity) {
        if (entity.level().isClientSide())
            return;
        var current = definition(entity.getType());
        var previous = dev.tc4port.thaumcraft.state.TCObjectState.BALANCE_ATTRIBUTES.get(entity);
        float oldMax = entity.getMaxHealth();
        float fraction = oldMax > 0 ? entity.getHealth() / oldMax : 0;
        var overrides = dev.tc4port.thaumcraft.state.TCObjectState.INDIVIDUAL_ATTRIBUTES.get(entity);
        var keys = new HashSet<>(previous);
        keys.addAll(current.attributes().keySet());
        var managed = new java.util.ArrayList<ResourceLocation>();
        for (var key : keys) {
            var attribute = AttributeTypes.resolve(entity, key);
            var baseline = AttributeTypes.registeredBase(entity.getType(), key);
            if (attribute == null || baseline == null)
                continue;
            var id = ResourceLocation.fromNamespaceAndPath("thaumcraft", "entity_balance/" + key.getNamespace() + "/" + key.getPath());
            Double desired = current.attributes().get(key);
            if (!overrides.contains(key) && desired != null && desired.doubleValue() != baseline && attribute.getBaseValue() == baseline) {
                AttributeModifiers.putPermanent(attribute, AttributeModifiers.create(id, desired - baseline, AttributeOperation.ADD_VALUE));
                managed.add(key);
            } else if (AttributeModifiers.has(attribute, id)) {
                AttributeModifiers.remove(attribute, id);
            }
        }
        if (entity.getMaxHealth() != oldMax && entity.isAlive())
            entity.setHealth(Math.min(entity.getMaxHealth(), fraction * entity.getMaxHealth()));
        dev.tc4port.thaumcraft.state.TCObjectState.BALANCE_ATTRIBUTES.set(entity, managed.stream().sorted().toList());
    }

    public static void register() {
        dev.tc4port.thaumcraft.api.entity.EntityBalanceApi.native$subscription$11224();
        dev.tc4port.thaumcraft.api.entity.EntityBalanceApi.native$subscription$11226();
        dev.tc4port.thaumcraft.api.entity.EntityBalanceApi.native$subscription$11228();
    }

    private static void native$listener$11223(net.minecraft.world.entity.Entity entity, net.minecraft.world.level.Level level) {
        if (entity instanceof net.minecraft.world.entity.Mob mob)
            apply(mob);
    }

    private static void native$listener$11225(net.minecraft.server.MinecraftServer server) {
        var current = dev.tc4port.thaumcraft.registry.TCRegistryDataMaps.ENTITY_BALANCE.values();
        if (previousDefinitions.equals(current))
            return;
        previousDefinitions = java.util.Map.copyOf(current);
        for (var level : server.getAllLevels()) for (var entity : level.getAllEntities()) if (entity instanceof net.minecraft.world.entity.Mob mob)
            apply(mob);
    }

    static private void native$subscription$11224() {
        net.minecraftforge.common.MinecraftForge.EVENT_BUS.addListener((net.minecraftforge.event.entity.EntityJoinLevelEvent event) -> {
            dev.tc4port.thaumcraft.api.entity.EntityBalanceApi.native$listener$11223((net.minecraft.world.entity.Entity) (event.getEntity()), (net.minecraft.world.level.Level) (event.getLevel()));
        });
    }

    static private void native$subscription$11226() {
        net.minecraftforge.common.MinecraftForge.EVENT_BUS.addListener((net.minecraftforge.event.TickEvent.ServerTickEvent event) -> {
            if (event.phase != net.minecraftforge.event.TickEvent.Phase.END)
                return;
            dev.tc4port.thaumcraft.api.entity.EntityBalanceApi.native$listener$11225((net.minecraft.server.MinecraftServer) (event.getServer()));
        });
    }

    static private void native$subscription$11228() {
        net.minecraftforge.common.MinecraftForge.EVENT_BUS.addListener((net.minecraftforge.event.server.ServerStoppedEvent event) -> {
            net.minecraft.server.MinecraftServer native$operand$16183 = (net.minecraft.server.MinecraftServer) (event.getServer());
            dev.tc4port.thaumcraft.api.entity.EntityBalanceApi.previousDefinitions = java.util.Map.of();
        });
    }
}
