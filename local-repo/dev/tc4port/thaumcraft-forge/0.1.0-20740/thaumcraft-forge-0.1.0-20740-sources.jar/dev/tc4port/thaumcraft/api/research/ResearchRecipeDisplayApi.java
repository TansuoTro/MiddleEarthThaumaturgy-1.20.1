package dev.tc4port.thaumcraft.api.research;

import dev.tc4port.thaumcraft.api.Registration;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.function.Function;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.crafting.Recipe;

/**
 * Addon presentation for live recipes referenced by PROCESS_CRAFTING pages.
 */
public final class ResearchRecipeDisplayApi {

    private static final Map<ResourceLocation, Provider<?>> PROVIDERS = new LinkedHashMap<>();

    private ResearchRecipeDisplayApi() {
    }

    /**
     * Install on both sides during common setup, behind any optional-mod
     * boundary. Retain the handle for the registration's lifetime. Providers
     * describe the supplied live recipe without retaining recipe instances;
     * they do not create recipes or change crafting/research availability.
     * If recipe classes overlap, the first registered matching provider wins.
     */
    public static synchronized <R extends Recipe<?>> Registration register(ResourceLocation id, Class<R> recipeClass, Function<R, ResearchRecipeDisplay> display) {
        Objects.requireNonNull(id, "id");
        Provider<R> provider = new Provider<>(Objects.requireNonNull(recipeClass, "recipeClass"), Objects.requireNonNull(display, "display"));
        if (PROVIDERS.putIfAbsent(id, provider) != null) {
            throw new IllegalArgumentException("Duplicate recipe display: " + id);
        }
        return Registration.of(() -> {
            synchronized (ResearchRecipeDisplayApi.class) {
                PROVIDERS.remove(id, provider);
            }
        });
    }

    public static synchronized boolean supports(Recipe<?> recipe) {
        return PROVIDERS.values().stream().anyMatch(provider -> provider.recipeClass().isInstance(recipe));
    }

    public static synchronized Optional<ResearchRecipeDisplay> describe(Recipe<?> recipe) {
        for (Provider<?> provider : PROVIDERS.values()) {
            if (provider.recipeClass().isInstance(recipe)) {
                return Optional.of(provider.describe(recipe));
            }
        }
        return Optional.empty();
    }

    private record Provider<R extends Recipe<?>>(Class<R> recipeClass, Function<R, ResearchRecipeDisplay> display) {

        private ResearchRecipeDisplay describe(Recipe<?> recipe) {
            return display.apply(recipeClass.cast(recipe));
        }
    }
}
