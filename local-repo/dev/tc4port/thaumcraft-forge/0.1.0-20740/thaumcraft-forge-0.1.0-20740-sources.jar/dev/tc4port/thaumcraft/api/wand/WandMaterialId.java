package dev.tc4port.thaumcraft.api.wand;

import com.mojang.serialization.Codec;
import com.mojang.serialization.DataResult;
import java.util.Objects;
import net.minecraft.resources.ResourceLocation;

/**
 * Stable namespaced identity shared by data and runtime wand materials.
 */
public record WandMaterialId(ResourceLocation value) implements Comparable<WandMaterialId> {

    private static final String THAUMCRAFT = "thaumcraft";

    public static final WandMaterialId WOOD = thaumcraft("wood");

    public static final WandMaterialId IRON = thaumcraft("iron");

    public static final Codec<WandMaterialId> CODEC = Codec.STRING.comapFlatMap(WandMaterialId::decode, WandMaterialId::serialized);

    public WandMaterialId {
        value = Objects.requireNonNull(value, "value");
        if (value.getPath().isEmpty()) {
            throw new IllegalArgumentException("Wand material id path must not be empty");
        }
        if (value.toString().length() > 256) {
            throw new IllegalArgumentException("Wand material id is longer than 256 characters");
        }
    }

    public static WandMaterialId of(ResourceLocation value) {
        return new WandMaterialId(value);
    }

    private static WandMaterialId thaumcraft(String path) {
        return new WandMaterialId(ResourceLocation.tryBuild(THAUMCRAFT, path));
    }

    /**
     * Bare spellings are persisted Thaumcraft identities.
     */
    public static WandMaterialId parse(String value) {
        if (value == null || value.isBlank()) {
            throw new IllegalArgumentException("Wand material id must not be blank");
        }
        ResourceLocation parsed = value.indexOf(':') >= 0 ? ResourceLocation.tryParse(value) : ResourceLocation.tryBuild(THAUMCRAFT, value);
        if (parsed == null) {
            throw new IllegalArgumentException("Invalid wand material id: " + value);
        }
        return new WandMaterialId(parsed);
    }

    /**
     * Canonical save/data spelling; public equality remains namespaced.
     */
    public String serialized() {
        return THAUMCRAFT.equals(this.value.getNamespace()) ? this.value.getPath() : this.value.toString();
    }

    private static DataResult<WandMaterialId> decode(String value) {
        try {
            return DataResult.success(parse(value));
        } catch (RuntimeException exception) {
            return DataResult.error(() -> "Invalid wand material id '" + value + "': " + exception.getMessage());
        }
    }

    @Override
    public int compareTo(WandMaterialId other) {
        return this.value.compareTo(other.value);
    }

    @Override
    public String toString() {
        return this.value.toString();
    }
}
