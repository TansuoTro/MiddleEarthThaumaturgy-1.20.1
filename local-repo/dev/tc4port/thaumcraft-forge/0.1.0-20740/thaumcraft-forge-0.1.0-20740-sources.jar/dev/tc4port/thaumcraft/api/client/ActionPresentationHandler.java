package dev.tc4port.thaumcraft.api.client;

/**
 * Client-only visual/audio consumer for one action presentation identity.
 */
@FunctionalInterface
public interface ActionPresentationHandler {

    void present(ActionPresentationContext context);
}
