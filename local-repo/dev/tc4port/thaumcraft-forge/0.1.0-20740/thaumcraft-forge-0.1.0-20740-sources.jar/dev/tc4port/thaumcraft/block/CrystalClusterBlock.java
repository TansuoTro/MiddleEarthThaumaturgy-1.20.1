package dev.tc4port.thaumcraft.block;

import com.mojang.serialization.MapCodec;
import com.mojang.serialization.Codec;
import dev.tc4port.thaumcraft.client.ChampionSparkParticle;
import dev.tc4port.thaumcraft.block.entity.CrystalClusterBlockEntity;
import dev.tc4port.thaumcraft.registry.CrystalClusters;
import java.util.List;
import javax.annotation.Nullable;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.util.RandomSource;
import net.minecraft.util.StringRepresentable;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.LevelReader;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Mirror;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.Rotation;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.DirectionProperty;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;
import dev.tc4port.thaumcraft.nativeimpl.ClientExtensionTarget;
import dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.level.pathfinder.PathComputationType;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.level.Explosion;

/**
 * The seven visible TC4 crystal-cluster variants plus the eldritch crystal.
 *
 * <p>The legacy tile stored the face clicked by the player as an orientation
 * short. A block-state direction is the lossless modern equivalent and avoids
 * a synchronization-only tile field. The rendered model still lives in a
 * block entity because the six individual crystals are position-seeded and
 * softly pulse independently.</p>
 */
public final class CrystalClusterBlock extends net.minecraft.world.level.block.BaseEntityBlock implements dev.tc4port.thaumcraft.nativeimpl.ClientExtensionTarget {

    // Forge calls initializeClient from the native superclass constructor. Do not add a field initializer.
    private java.util.function.Consumer<net.minecraftforge.client.extensions.common.IClientBlockExtensions> platform$clientInstaller;

    public static final DirectionProperty ATTACHMENT_FACE = BlockStateProperties.FACING;

    private final Kind kind;

    public CrystalClusterBlock(Kind kind, BlockBehaviour.Properties properties) {
        this(properties, kind, properties, true);
    }

    public Kind kind() {
        return this.kind;
    }

    @Nullable
    @Override
    public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        return new CrystalClusterBlockEntity(pos, state);
    }

    @Override
    public RenderShape getRenderShape(BlockState state) {
        return RenderShape.ENTITYBLOCK_ANIMATED;
    }

    // The source's non-opaque crystals keep a full collision box, but that
    // box must not attenuate skylight or darken neighbouring ambient light.
    @Override
    public boolean propagatesSkylightDown(BlockState state, BlockGetter level, BlockPos pos) {
        return true;
    }

    @Override
    public float getShadeBrightness(BlockState state, BlockGetter level, BlockPos pos) {
        return 1.0F;
    }

    @Override
    public VoxelShape getBlockSupportShape(BlockState state, BlockGetter level, BlockPos pos) {
        // Source isSideSolid returned false despite the full collision box.
        return Shapes.empty();
    }

    @Nullable
    @Override
    public BlockState getStateForPlacement(BlockPlaceContext context) {
        BlockState state = this.defaultBlockState().setValue(ATTACHMENT_FACE, context.getClickedFace());
        BlockPos supportPos = context.getClickedPos().relative(context.getClickedFace().getOpposite());
        // Initial placement required a solid clicked face for every variant;
        // only the eldritch crystal's later survival check accepted any non-air.
        return context.getLevel().getBlockState(supportPos).isFaceSturdy(context.getLevel(), supportPos, context.getClickedFace()) ? state : null;
    }

    @Override
    public boolean canSurvive(BlockState state, LevelReader level, BlockPos pos) {
        Direction face = state.getValue(ATTACHMENT_FACE);
        BlockPos supportPos = pos.relative(face.getOpposite());
        BlockState support = level.getBlockState(supportPos);
        /*
         * BlockCrystal's metadata 7 neighbour check only tested for air after
         * placement. Metadata 0..6 required a genuinely solid face.
         */
        return this.kind == Kind.ELDRITCH ? !support.isAir() : support.isFaceSturdy(level, supportPos, face);
    }

    @Override
    public BlockState updateShape(BlockState state, Direction direction, BlockState neighborState, LevelAccessor level, BlockPos currentPos, BlockPos neighborPos) {
        if (direction == state.getValue(ATTACHMENT_FACE).getOpposite() && !state.canSurvive(level, currentPos)) {
            return net.minecraft.world.level.block.Blocks.AIR.defaultBlockState();
        }
        return super.updateShape(state, direction, neighborState, level, currentPos, neighborPos);
    }

    @Override
    public void animateTick(BlockState state, Level level, BlockPos pos, RandomSource random) {
        if (this.kind == Kind.ELDRITCH || random.nextInt(17) != 0) {
            return;
        }
        if (!(level instanceof ClientLevel client)) {
            return;
        }
        double x = pos.getX() + 0.3 + random.nextFloat() * 0.4F;
        double y = pos.getY() + 0.3 + random.nextFloat() * 0.4F;
        double z = pos.getZ() + 0.3 + random.nextFloat() * 0.4F;
        float scale = 0.2F + random.nextFloat() * 0.1F;
        ChampionSparkParticle.spawnWithDeferredColor(client, x, y, z, scale, () -> {
            int color = this.kind == Kind.MIXED ? Kind.PRIMAL.get(random.nextInt(Kind.PRIMAL.size())).color() : this.kind.color();
            return new float[] { (color >> 16 & 0xFF) / 255.0F, (color >> 8 & 0xFF) / 255.0F, (color & 0xFF) / 255.0F };
        }, 0.8F);
    }

    @Override
    public BlockState rotate(BlockState state, Rotation rotation) {
        return state.setValue(ATTACHMENT_FACE, rotation.rotate(state.getValue(ATTACHMENT_FACE)));
    }

    @Override
    public BlockState mirror(BlockState state, Mirror mirror) {
        return this.rotate(state, mirror.getRotation(state.getValue(ATTACHMENT_FACE)));
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(ATTACHMENT_FACE);
    }

    public enum Kind implements StringRepresentable {

        AIR("air", 0, 0xFFFF7E),
        FIRE("fire", 1, 0xFF3C01),
        WATER("water", 2, 0x0090FF),
        EARTH("earth", 3, 0x00A000),
        ORDER("order", 4, 0xEECCFF),
        ENTROPY("entropy", 5, 0x555577),
        MIXED("mixed", 6, 0xEECCFF),
        ELDRITCH("eldritch", 7, 0xFFFFFF);

        public static final Codec<Kind> CODEC = StringRepresentable.fromEnum(Kind::values);

        public static final List<Kind> PRIMAL = List.of(AIR, FIRE, WATER, EARTH, ORDER, ENTROPY);

        private final String serializedName;

        private final int renderSeed;

        private final int color;

        Kind(String serializedName, int renderSeed, int color) {
            this.serializedName = serializedName;
            this.renderSeed = renderSeed;
            this.color = color;
        }

        @Override
        public String getSerializedName() {
            return this.serializedName;
        }

        public int renderSeed() {
            return this.renderSeed;
        }

        public int color() {
            return this.color;
        }
    }

    public static final MapCodec<CrystalClusterBlock> CODEC = com.mojang.serialization.codecs.RecordCodecBuilder.mapCodec(instance -> instance.group(Kind.CODEC.fieldOf("kind").forGetter(CrystalClusterBlock::kind), CrystalClusterBlock.<CrystalClusterBlock>native$BlockCodecPlatform$properties()).apply(instance, CrystalClusterBlock::new));

    protected MapCodec<? extends CrystalClusterBlock> codec() {
        return CODEC;
    }

    private CrystalClusterBlock(net.minecraft.world.level.block.state.BlockBehaviour.Properties native$NativeEntityBlock$arg0, Kind kind, BlockBehaviour.Properties properties, boolean native$NativeEntityBlock$captured) {
        super(native$NativeEntityBlock$arg0);
        this.kind = kind;
        this.registerDefaultState(this.stateDefinition.any().setValue(ATTACHMENT_FACE, Direction.UP));
    }

    @Override
    public void initializeClient(java.util.function.Consumer<net.minecraftforge.client.extensions.common.IClientBlockExtensions> installer) {
        platform$clientInstaller = installer;
        super.initializeClient(installer);
    }

    @Override
    public void platform$clientExtension(Object extension) {
        java.util.Objects.requireNonNull(platform$clientInstaller, "Forge initializeClient must run before client extension registration").accept((net.minecraftforge.client.extensions.common.IClientBlockExtensions) extension);
    }

    @Override
    public InteractionResult use(BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
        ItemUseResult result = (switch(0) {
            default ->
                {
                    net.minecraft.world.item.ItemStack native$bodyOperand$4299 = player.getItemInHand(hand);
                    net.minecraft.world.level.block.state.BlockState native$bodyOperand$4300 = state;
                    net.minecraft.world.level.Level native$bodyOperand$4301 = level;
                    net.minecraft.core.BlockPos native$bodyOperand$4302 = pos;
                    net.minecraft.world.entity.player.Player native$bodyOperand$4303 = player;
                    net.minecraft.world.InteractionHand native$bodyOperand$4304 = hand;
                    net.minecraft.world.phys.BlockHitResult native$bodyOperand$4305 = hit;
                    dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult native$bodyResult$4306 = null;
                    native$bodyReturn$4307: {
                        if (true) {
                            {
                                native$bodyResult$4306 = dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
                                break native$bodyReturn$4307;
                            }
                        }
                    }
                    yield native$bodyResult$4306;
                }
        });
        return result == ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION ? (hand == InteractionHand.MAIN_HAND ? (switch(0) {
            default ->
                {
                    net.minecraft.world.level.block.state.BlockState native$bodyOperand$3586 = state;
                    net.minecraft.world.level.Level native$bodyOperand$3587 = level;
                    net.minecraft.core.BlockPos native$bodyOperand$3588 = pos;
                    net.minecraft.world.entity.player.Player native$bodyOperand$3589 = player;
                    net.minecraft.world.phys.BlockHitResult native$bodyOperand$3590 = hit;
                    net.minecraft.world.InteractionResult native$bodyResult$3591 = null;
                    native$bodyReturn$3592: {
                        if (true) {
                            {
                                native$bodyResult$3591 = super.use(native$bodyOperand$3586, native$bodyOperand$3587, native$bodyOperand$3588, native$bodyOperand$3589, net.minecraft.world.InteractionHand.MAIN_HAND, native$bodyOperand$3590);
                                break native$bodyReturn$3592;
                            }
                        }
                    }
                    yield native$bodyResult$3591;
                }
        }) : InteractionResult.PASS) : result.result();
    }

    protected ItemUseResult interactWithItem(ItemStack stack, BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
        return dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
    }

    protected InteractionResult interactWithoutItem(BlockState state, Level level, BlockPos pos, Player player, BlockHitResult hit) {
        return super.use(state, level, pos, player, net.minecraft.world.InteractionHand.MAIN_HAND, hit);
    }

    @Override
    public void playerWillDestroy(Level level, BlockPos pos, BlockState state, Player player) {
        {
            net.minecraft.world.level.Level native$bodyOperand$5769 = level;
            net.minecraft.core.BlockPos native$bodyOperand$5770 = pos;
            net.minecraft.world.level.block.state.BlockState native$bodyOperand$5771 = state;
            net.minecraft.world.entity.player.Player native$bodyOperand$5772 = player;
            net.minecraft.world.level.block.state.BlockState native$bodyResult$5773 = null;
            native$bodyReturn$5774: {
                if (true) {
                    super.playerWillDestroy(native$bodyOperand$5769, native$bodyOperand$5770, native$bodyOperand$5771, native$bodyOperand$5772);
                    {
                        native$bodyResult$5773 = native$bodyOperand$5771;
                        break native$bodyReturn$5774;
                    }
                }
            }
        }
    }

    public BlockState beforePlayerDestroy(Level level, BlockPos pos, BlockState state, Player player) {
        super.playerWillDestroy(level, pos, state, player);
        return state;
    }

    protected boolean survivesSharedExplosion() {
        return false;
    }

    public int getExpDrop(net.minecraft.world.level.block.state.BlockState native$callbackInput$1050, net.minecraft.world.level.LevelReader native$callbackInput$1051, net.minecraft.util.RandomSource native$callbackInput$1052, net.minecraft.core.BlockPos native$callbackInput$1053, int native$callbackInput$1054, int native$callbackInput$1055) {
        net.minecraft.world.level.block.state.BlockState state = native$callbackInput$1050;
        net.minecraft.util.RandomSource random = native$callbackInput$1052;
        return 0;
    }

    @Override
    public void onBlockExploded(BlockState state, Level level, BlockPos pos, Explosion explosion) {
        if (!(switch(0) {
            default ->
                {
                    boolean native$bodyResult$5243 = false;
                    native$bodyReturn$5244: {
                        if (true) {
                            {
                                native$bodyResult$5243 = false;
                                break native$bodyReturn$5244;
                            }
                        }
                    }
                    yield native$bodyResult$5243;
                }
        }))
            super.onBlockExploded(state, level, pos, explosion);
    }

    @Override
    public boolean canDropFromExplosion(BlockState state, BlockGetter level, BlockPos pos, Explosion explosion) {
        return !(switch(0) {
            default ->
                {
                    boolean native$bodyResult$4308 = false;
                    native$bodyReturn$4309: {
                        if (true) {
                            {
                                native$bodyResult$4308 = false;
                                break native$bodyReturn$4309;
                            }
                        }
                    }
                    yield native$bodyResult$4308;
                }
        }) && super.canDropFromExplosion(state, level, pos, explosion);
    }

    static private <B extends net.minecraft.world.level.block.Block> com.mojang.serialization.codecs.RecordCodecBuilder<B, net.minecraft.world.level.block.state.BlockBehaviour.Properties> native$BlockCodecPlatform$properties() {
        return com.mojang.serialization.Codec.unit(net.minecraft.world.level.block.state.BlockBehaviour.Properties::of).fieldOf("properties").forGetter(block -> net.minecraft.world.level.block.state.BlockBehaviour.Properties.copy(block));
    }
}
