package dev.tc4port.thaumcraft.api.golem;

import java.util.Objects;
import javax.annotation.Nullable;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.Vec3;

/**
 * Semantic destination requested by a Thaumcraft golem task.
 *
 * <p>The coordinates remain exactly those stored by the task. A spatial
 * adapter may project them into another navigation frame without asking the
 * task to understand that frame.</p>
 */
public sealed interface GolemTravelTarget permits GolemTravelTarget.BlockTarget, GolemTravelTarget.PointTarget, GolemTravelTarget.EntityTarget {

    Vec3 fallbackInteractionPoint();

    static BlockTarget block(BlockPos pos) {
        return block(pos, null, Vec3.atCenterOf(pos));
    }

    static BlockTarget block(BlockPos pos, @Nullable Direction face) {
        return block(pos, face, Vec3.atCenterOf(pos));
    }

    static BlockTarget block(BlockPos pos, @Nullable Direction face, Vec3 interactionPoint) {
        return new BlockTarget(pos, face, interactionPoint);
    }

    static PointTarget point(Vec3 point) {
        return new PointTarget(point);
    }

    static EntityTarget entity(Entity entity) {
        return new EntityTarget(entity);
    }

    record BlockTarget(BlockPos pos, @Nullable Direction face, Vec3 interactionPoint) implements GolemTravelTarget {

        public BlockTarget {
            pos = Objects.requireNonNull(pos, "pos").immutable();
            interactionPoint = requireFinite(interactionPoint, "interactionPoint");
        }

        @Override
        public Vec3 fallbackInteractionPoint() {
            return this.interactionPoint;
        }
    }

    record PointTarget(Vec3 point) implements GolemTravelTarget {

        public PointTarget {
            point = requireFinite(point, "point");
        }

        @Override
        public Vec3 fallbackInteractionPoint() {
            return this.point;
        }
    }

    record EntityTarget(Entity entity) implements GolemTravelTarget {

        public EntityTarget {
            entity = Objects.requireNonNull(entity, "entity");
        }

        @Override
        public Vec3 fallbackInteractionPoint() {
            return this.entity.position();
        }
    }

    private static Vec3 requireFinite(Vec3 point, String name) {
        Objects.requireNonNull(point, name);
        if (!Double.isFinite(point.x) || !Double.isFinite(point.y) || !Double.isFinite(point.z)) {
            throw new IllegalArgumentException(name + " must be finite");
        }
        return point;
    }
}
