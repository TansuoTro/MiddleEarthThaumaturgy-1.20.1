package dev.tc4port.thaumcraft.api.focus;

import java.util.Map;
import java.util.Optional;

/**
 * Read-only, generation-stamped view of the synchronized focus catalog.
 */
public interface FocusRegistryView {

    /**
     * Process-local cache stamp that changes whenever this view is replaced.
     */
    long generation();

    /**
     * Upgrade definitions in deterministic presentation order.
     */
    Map<FocusUpgradeId, FocusUpgradeDefinition> upgrades();

    /**
     * Built-in behavior profiles in deterministic presentation order.
     */
    Map<FocusId, FocusProfileDefinition> profiles();

    default Optional<FocusUpgradeDefinition> upgrade(FocusUpgradeId id) {
        return Optional.ofNullable(this.upgrades().get(id));
    }

    default Optional<FocusProfileDefinition> profile(FocusId id) {
        return Optional.ofNullable(this.profiles().get(id));
    }
}
