package dev.tc4port.thaumcraft.api.item;

import dev.tc4port.thaumcraft.api.event.PlatformIdentity;
import com.google.gson.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import net.minecraft.world.item.*;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.enchantment.*;
import net.minecraft.tags.TagKey;
import net.minecraft.core.registries.*;
import net.minecraft.network.chat.Component;
import net.minecraftforge.registries.*;

/**
 * Forge static registrations read the same authored enchantment definitions as NeoForge's data registry.
 */
public final class NativeEnchantments {

    public static void register(net.minecraftforge.eventbus.api.IEventBus bus, Class<?> resources, String namespace, java.util.List<String> paths, boolean tagPolicy) {
        var register = DeferredRegister.create(ForgeRegistries.ENCHANTMENTS, namespace);
        for (String path : paths) register.register(path, () -> new Definition(read(resources, "/data/" + namespace + "/enchantment/" + path + ".json").getAsJsonObject(), tagPolicy));
        register.register(bus);
    }

    public static void registerIndex(net.minecraftforge.eventbus.api.IEventBus bus, Class<?> resources, String namespace) {
        var paths = new java.util.ArrayList<String>();
        for (var entry : read(resources, "/" + namespace + "/enchantment-index.json").getAsJsonArray()) paths.add(entry.getAsString());
        register(bus, resources, namespace, paths, true);
    }

    private static JsonElement read(Class<?> resources, String path) {
        try (var input = Objects.requireNonNull(resources.getResourceAsStream(path), path);
            var reader = new InputStreamReader(input, StandardCharsets.UTF_8)) {
            return JsonParser.parseReader(reader);
        } catch (IOException exception) {
            throw new UncheckedIOException(exception);
        }
    }

    public static final class Definition extends Enchantment {

        private static final EnchantmentCategory CATEGORY = EnchantmentCategory.create(PlatformIdentity.NAMESPACE.toUpperCase(java.util.Locale.ROOT) + "_DATA", item -> true);

        private final JsonObject definition;

        private final boolean tagPolicy;

        private final TagKey<Item> supported;

        private final TagKey<Enchantment> excluded;

        public Definition(JsonObject definition) {
            this(definition, false);
        }

        public Definition(JsonObject definition, boolean tagPolicy) {
            super(rarity(definition), CATEGORY, slots(definition));
            this.definition = definition;
            this.tagPolicy = tagPolicy;
            supported = TagKey.create(Registries.ITEM, net.minecraft.resources.ResourceLocation.parse((java.lang.String) (definition.get("supported_items").getAsString().substring(1))));
            excluded = definition.has("exclusive_set") ? TagKey.create(Registries.ENCHANTMENT, net.minecraft.resources.ResourceLocation.parse((java.lang.String) (definition.get("exclusive_set").getAsString().substring(1)))) : null;
        }

        private static EquipmentSlot[] slots(JsonObject definition) {
            var slots = new ArrayList<EquipmentSlot>();
            for (JsonElement slot : definition.getAsJsonArray("slots")) {
                if (slot.getAsString().equals("any"))
                    return EquipmentSlot.values();
                slots.add(EquipmentSlot.byName(slot.getAsString()));
            }
            return slots.toArray(EquipmentSlot[]::new);
        }

        private static Rarity rarity(JsonObject data) {
            int weight = data.get("weight").getAsInt();
            for (Rarity rarity : Rarity.values()) if (rarity.getWeight() == weight)
                return rarity;
            // Exact authored weights are supplied at the native weighted-entry hook.
            return Rarity.UNCOMMON;
        }

        private boolean tagged(String path) {
            return net.minecraft.core.registries.BuiltInRegistries.ENCHANTMENT.wrapAsHolder(this).is(net.minecraft.tags.TagKey.create(net.minecraft.core.registries.Registries.ENCHANTMENT, net.minecraft.resources.ResourceLocation.fromNamespaceAndPath((java.lang.String) ("minecraft"), (java.lang.String) (path))));
        }

        @Override
        public boolean isDiscoverable() {
            return tagPolicy ? (switch(0) {
                default ->
                    {
                        java.lang.String native$bodyOperand$3989 = "in_enchanting_table";
                        boolean native$bodyResult$3990 = false;
                        native$bodyReturn$3991: {
                            if (true) {
                                {
                                    native$bodyResult$3990 = net.minecraft.core.registries.BuiltInRegistries.ENCHANTMENT.wrapAsHolder(this).is(net.minecraft.tags.TagKey.create(net.minecraft.core.registries.Registries.ENCHANTMENT, net.minecraft.resources.ResourceLocation.fromNamespaceAndPath((java.lang.String) ("minecraft"), (java.lang.String) (native$bodyOperand$3989))));
                                    break native$bodyReturn$3991;
                                }
                            }
                        }
                        yield native$bodyResult$3990;
                    }
            }) : super.isDiscoverable();
        }

        @Override
        public boolean isTradeable() {
            return tagPolicy ? (switch(0) {
                default ->
                    {
                        java.lang.String native$bodyOperand$3992 = "tradeable";
                        boolean native$bodyResult$3993 = false;
                        native$bodyReturn$3994: {
                            if (true) {
                                {
                                    native$bodyResult$3993 = net.minecraft.core.registries.BuiltInRegistries.ENCHANTMENT.wrapAsHolder(this).is(net.minecraft.tags.TagKey.create(net.minecraft.core.registries.Registries.ENCHANTMENT, net.minecraft.resources.ResourceLocation.fromNamespaceAndPath((java.lang.String) ("minecraft"), (java.lang.String) (native$bodyOperand$3992))));
                                    break native$bodyReturn$3994;
                                }
                            }
                        }
                        yield native$bodyResult$3993;
                    }
            }) : super.isTradeable();
        }

        @Override
        public boolean isTreasureOnly() {
            return tagPolicy ? (switch(0) {
                default ->
                    {
                        java.lang.String native$bodyOperand$3995 = "treasure";
                        boolean native$bodyResult$3996 = false;
                        native$bodyReturn$3997: {
                            if (true) {
                                {
                                    native$bodyResult$3996 = net.minecraft.core.registries.BuiltInRegistries.ENCHANTMENT.wrapAsHolder(this).is(net.minecraft.tags.TagKey.create(net.minecraft.core.registries.Registries.ENCHANTMENT, net.minecraft.resources.ResourceLocation.fromNamespaceAndPath((java.lang.String) ("minecraft"), (java.lang.String) (native$bodyOperand$3995))));
                                    break native$bodyReturn$3997;
                                }
                            }
                        }
                        yield native$bodyResult$3996;
                    }
            }) : super.isTreasureOnly();
        }

        public int weight() {
            return definition.get("weight").getAsInt();
        }

        @Override
        public int getMaxLevel() {
            return definition.get("max_level").getAsInt();
        }

        private int cost(String key, int level) {
            var value = definition.getAsJsonObject(key);
            return value.get("base").getAsInt() + value.get("per_level_above_first").getAsInt() * (level - 1);
        }

        @Override
        public int getMinCost(int level) {
            return (switch(0) {
                default ->
                    {
                        java.lang.String native$bodyOperand$5182 = "min_cost";
                        int native$bodyOperand$5183 = level;
                        int native$bodyResult$5185 = 0;
                        native$bodyReturn$5186: {
                            if (true) {
                                var native$bodyBinding$5184 = definition.getAsJsonObject(native$bodyOperand$5182);
                                {
                                    native$bodyResult$5185 = native$bodyBinding$5184.get("base").getAsInt() + native$bodyBinding$5184.get("per_level_above_first").getAsInt() * (native$bodyOperand$5183 - 1);
                                    break native$bodyReturn$5186;
                                }
                            }
                        }
                        yield native$bodyResult$5185;
                    }
            });
        }

        @Override
        public int getMaxCost(int level) {
            return (switch(0) {
                default ->
                    {
                        java.lang.String native$bodyOperand$5187 = "max_cost";
                        int native$bodyOperand$5188 = level;
                        int native$bodyResult$5190 = 0;
                        native$bodyReturn$5191: {
                            if (true) {
                                var native$bodyBinding$5189 = definition.getAsJsonObject(native$bodyOperand$5187);
                                {
                                    native$bodyResult$5190 = native$bodyBinding$5189.get("base").getAsInt() + native$bodyBinding$5189.get("per_level_above_first").getAsInt() * (native$bodyOperand$5188 - 1);
                                    break native$bodyReturn$5191;
                                }
                            }
                        }
                        yield native$bodyResult$5190;
                    }
            });
        }

        @Override
        public boolean canEnchant(ItemStack stack) {
            return stack.is(supported);
        }

        @Override
        public boolean canApplyAtEnchantingTable(ItemStack stack) {
            return (switch(0) {
                default ->
                    {
                        net.minecraft.world.item.ItemStack native$bodyOperand$5192 = stack;
                        boolean native$bodyResult$5193 = false;
                        native$bodyReturn$5194: {
                            if (true) {
                                {
                                    native$bodyResult$5193 = native$bodyOperand$5192.is(supported);
                                    break native$bodyReturn$5194;
                                }
                            }
                        }
                        yield native$bodyResult$5193;
                    }
            });
        }

        @Override
        protected boolean checkCompatibility(Enchantment other) {
            return super.checkCompatibility(other) && (excluded == null || !BuiltInRegistries.ENCHANTMENT.wrapAsHolder(other).is(excluded));
        }

        // Forge callers can request the bare translation key independently of the
        // full name. Both entrypoints must use the authored description, which need
        // not match the enchantment's registry ID (for example, enchantment.repair).
        @Override
        protected String getOrCreateDescriptionId() {
            return definition.getAsJsonObject("description").get("translate").getAsString();
        }

        @Override
        public Component getFullname(int level) {
            var text = Component.Serializer.fromJson(definition.get("description")).copy();
            if (level != 1 || (switch(0) {
                default ->
                    {
                        int native$bodyResult$3392 = 0;
                        native$bodyReturn$3393: {
                            if (true) {
                                {
                                    native$bodyResult$3392 = definition.get("max_level").getAsInt();
                                    break native$bodyReturn$3393;
                                }
                            }
                        }
                        yield native$bodyResult$3392;
                    }
            }) != 1)
                text.append(" ").append(Component.translatable("enchantment.level." + level));
            return text.withStyle(net.minecraft.ChatFormatting.GRAY);
        }
    }
}
