package dev.tc4port.thaumcraft.api.golem;

import java.util.Objects;
import net.minecraft.core.Direction;
import net.minecraft.core.GlobalPos;

public record GolemMarkerView(GlobalPos position, Direction side, int color) {

    public GolemMarkerView {
        Objects.requireNonNull(position, "position");
        Objects.requireNonNull(side, "side");
        if (color < -1 || color > 15) {
            throw new IllegalArgumentException("marker color must be -1..15");
        }
        position = GlobalPos.of(position.dimension(), position.pos().immutable());
    }
}
