package dev.tc4port.thaumcraft.api.wand;

import dev.tc4port.thaumcraft.api.aspect.VisChannel;
import dev.tc4port.thaumcraft.api.focus.FocusStateView;
import java.util.Map;
import java.util.Optional;

/**
 * Immutable public projection of one valid wand stack.
 */
public interface WandView {

    WandMaterialId rod();

    WandMaterialId cap();

    Map<VisChannel, Integer> visCentivis();

    Map<VisChannel, Integer> capacityCentivis();

    Optional<FocusStateView> installedFocus();

    boolean staff();

    long definitionGeneration();
}
