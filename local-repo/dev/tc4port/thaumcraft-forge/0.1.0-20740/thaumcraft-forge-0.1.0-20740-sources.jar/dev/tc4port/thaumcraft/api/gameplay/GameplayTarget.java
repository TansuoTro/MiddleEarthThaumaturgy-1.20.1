package dev.tc4port.thaumcraft.api.gameplay;

/**
 * The recipient required by an action; the initiator (actor) is a separate input.
 */
public enum GameplayTarget implements java.util.function.Predicate<GameplayContext> {

    NONE, ENTITY, LIVING, PLAYER;

    @Override
    public boolean test(GameplayContext context) {
        if (this == NONE)
            return true;
        var target = context.target().orElse(null);
        return target != null && !target.isRemoved() && target.level() == context.level() && switch(this) {
            case ENTITY ->
                true;
            case LIVING ->
                target instanceof net.minecraft.world.entity.LivingEntity;
            case PLAYER ->
                target instanceof net.minecraft.server.level.ServerPlayer;
            case NONE ->
                true;
        };
    }
}
