package dev.tc4port.thaumcraft.block.entity;

import dev.tc4port.thaumcraft.nativeimpl.NativeFluidTank;
import dev.tc4port.thaumcraft.api.event.GameplayHooks;
import dev.tc4port.thaumcraft.common.TCGameplayParameters;
import dev.tc4port.thaumcraft.api.aspect.AspectDefinition;
import dev.tc4port.thaumcraft.api.aspect.AspectAmounts;
import dev.tc4port.thaumcraft.api.aspect.AspectContainerView;
import dev.tc4port.thaumcraft.api.flux.FluxApi;
import dev.tc4port.thaumcraft.api.aspect.AspectId;
import dev.tc4port.thaumcraft.api.research.ResearchRequirement;
import dev.tc4port.thaumcraft.api.research.ResearchApi;
import dev.tc4port.thaumcraft.aspect.AspectCatalog;
import dev.tc4port.thaumcraft.api.machine.ArcaneBellowsApi;
import dev.tc4port.thaumcraft.api.aspect.AspectQueryApi;
import dev.tc4port.thaumcraft.common.RecipeLookup;
import dev.tc4port.thaumcraft.entity.SpecialItemEntity;
import dev.tc4port.thaumcraft.recipe.CrucibleRecipe;
import dev.tc4port.thaumcraft.recipe.CrucibleRecipeOrdering;
import dev.tc4port.thaumcraft.registry.TCBlockEntities;
import dev.tc4port.thaumcraft.registry.TCBlocks;
import dev.tc4port.thaumcraft.registry.TCFluids;
import dev.tc4port.thaumcraft.registry.TCRecipes;
import dev.tc4port.thaumcraft.registry.TCSounds;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.material.Fluids;
import java.lang.Math;
import dev.tc4port.thaumcraft.nativeimpl.state.ItemFields;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityType;

/**
 * Server-authoritative port of TC4's {@code TileCrucible}.
 */
public final class CrucibleBlockEntity extends net.minecraft.world.level.block.entity.BlockEntity implements AspectContainerView, ItemFields.Source {

    public static final int CAPACITY = 1_000;

    public static int configuredCapacity() {
        return dev.tc4port.thaumcraft.common.TCGameplayParameters.MACHINES_CRUCIBLE_WATER_CAPACITY.intValue();
    }

    public static final int BOILING_HEAT = 151;

    public static int configuredBoilingHeat() {
        return dev.tc4port.thaumcraft.common.TCGameplayParameters.MACHINES_CRUCIBLE_BOILING_HEAT.intValue();
    }

    public static final int MAX_STABLE_ASPECTS = 100;

    public static int configuredStableAspects() {
        return dev.tc4port.thaumcraft.common.TCGameplayParameters.MACHINES_CRUCIBLE_STABLE_ASPECTS.intValue();
    }

    private static final String HEAT_KEY = "Heat";

    private static final String TANK_KEY = "Tank";

    private static final String ASPECTS_KEY = "Aspects";

    private short heat;

    private long counter = -100L;

    private int bellows = -1;

    private final NativeFluidTank tank = new NativeAnonymous1(CrucibleBlockEntity::configuredCapacity, (net.minecraftforge.fluids.FluidStack stack) -> {
        net.minecraftforge.fluids.FluidStack native$operand$13666 = stack;
        net.minecraft.world.level.material.Fluid native$operand$13667 = Fluids.WATER;
        boolean native$result$13668 = (native$operand$13666.getFluid() == native$operand$13667);
        return native$result$13668;
    });

    private final LinkedHashMap<AspectId, Integer> aspects = new LinkedHashMap<>();

    public CrucibleBlockEntity(BlockPos pos, BlockState state) {
        super(TCBlockEntities.CRUCIBLE.get(), pos, state);
    }

    public static void serverTick(Level level, BlockPos pos, BlockState state, CrucibleBlockEntity crucible) {
        if (!(level instanceof ServerLevel serverLevel)) {
            return;
        }
        crucible.counter++;
        int oldHeat = crucible.heat;
        if (crucible.bellows < 0) {
            crucible.recountBellows();
        }
        if (crucible.water() <= 0) {
            if (crucible.heat > 0) {
                crucible.heat--;
            }
        } else if (hasHeatSource(serverLevel, pos.below())) {
            if (crucible.heat < 200) {
                crucible.heat = (short) Math.min(200, crucible.heat + 1 + crucible.bellows * 2);
            }
        } else if (crucible.heat > 0) {
            crucible.heat--;
        }
        if (crucible.totalAspects() > configuredStableAspects() && crucible.counter % TCGameplayParameters.ALCHEMY_CRUCIBLE_OVERFLOW_INTERVAL.intValue() == 0L) {
            crucible.takeRandomAspect(serverLevel);
            crucible.spill(serverLevel);
        }
        if (crucible.counter > TCGameplayParameters.ALCHEMY_CRUCIBLE_DECOMPOSITION_THRESHOLD.intValue() && crucible.heat >= configuredBoilingHeat()) {
            crucible.counter = 0L;
            crucible.decomposeOneAspect(serverLevel);
        }
        if (oldHeat != crucible.heat) {
            crucible.changedAndSync();
        }
    }

    public static void clientTick(Level level, BlockPos pos, BlockState state, CrucibleBlockEntity crucible) {
        if (crucible.water() > 0) {
            dev.tc4port.thaumcraft.client.CrucibleBubbleParticle.tickCrucible(level, pos, crucible);
        }
    }

    public short heat() {
        return this.heat;
    }

    public int water() {
        return this.tank.getFluidAmount();
    }

    public int fillWater(int amount) {
        return this.tank.fill(new net.minecraftforge.fluids.FluidStack(Fluids.WATER, Math.max(0, amount)), net.minecraftforge.fluids.capability.IFluidHandler.FluidAction.EXECUTE);
    }

    public NativeFluidTank tank() {
        return this.tank;
    }

    public boolean boiling() {
        return this.water() > 0 && this.heat >= configuredBoilingHeat();
    }

    public Map<AspectId, Integer> aspects() {
        return Collections.unmodifiableMap(this.aspects);
    }

    @Override
    public AspectAmounts visibleAspects() {
        return new AspectAmounts(this.aspects);
    }

    public int aspectAmount(AspectId aspect) {
        return aspect == null ? 0 : this.aspects.getOrDefault(aspect, 0);
    }

    public void addAspects(Map<AspectId, Integer> additions) {
        additions.forEach((aspect, amount) -> {
            if (AspectCatalog.contains(aspect) && amount > 0) {
                this.aspects.merge(aspect, amount, CrucibleBlockEntity::saturatingAdd);
            }
        });
        this.removeEmptyAspects();
        this.changedAndSync();
    }

    public int totalAspects() {
        return (int) Math.min(Integer.MAX_VALUE, this.aspects.values().stream().mapToLong(Integer::longValue).sum());
    }

    public float fluidHeight() {
        float base = 0.3F + 0.5F * (Math.min(1.0F, this.water() / (float) configuredCapacity()));
        float result = base + this.totalAspects() / 100.0F * (1.0F - base);
        if (result > 1.0F) {
            return 1.001F;
        }
        return result == 1.0F ? 0.9999F : result;
    }

    /**
     * Tries each item in the entity stack, exactly as the old tile did.
     *
     * @return true when at least one item was consumed
     */
    public boolean attemptSmelt(ItemEntity entity) {
        if (!(this.level instanceof ServerLevel serverLevel) || !this.boiling()) {
            return false;
        }
        ItemStack stack = entity.getItem();
        int remaining = stack.getCount();
        boolean dissolved = false;
        boolean crafted = false;
        List<CrucibleRecipe> recipes = null;
        Map<AspectId, Integer> dissolvedAspects = null;
        /*
         * TileCrucible compared the loop index against the same local
         * stacksize that it decremented after every consumed item.  That
         * deliberately processes ceil(n / 2) items per collision callback,
         * leaving the remainder for a later callback.
         */
        for (int index = 0; index < remaining; index++) {
            if (recipes == null) {
                recipes = this.orderedRecipes();
            }
            CrucibleRecipe recipe = this.findRecipe(recipes, stack, entity.getOwner());
            if (recipe != null && this.water() > 0) {
                ItemStack output = recipe.getResultItem(serverLevel.registryAccess()).copy();
                if (entity.getOwner() instanceof ServerPlayer player) {
                    GameplayHooks.firePlayerCraftingEvent(player, output, new SimpleContainer(stack));
                }
                recipe.removeRequiredAspects(this.aspects);
                this.removeEmptyAspects();
                this.drainWaterWithoutSync(TCGameplayParameters.ALCHEMY_CRUCIBLE_CRAFT_WATER.intValue());
                this.ejectItem(output);
                remaining--;
                crafted = true;
                this.counter = -250L;
                // A crafting callback can change recipes, research, the input
                // or aspect providers. Only reuse across pure dissolutions.
                recipes = null;
                dissolvedAspects = null;
                continue;
            }
            if (dissolvedAspects == null) {
                dissolvedAspects = AspectQueryApi.item(stack).amounts();
            }
            if (dissolvedAspects.isEmpty()) {
                entity.setDeltaMovement((serverLevel.random.nextFloat() - serverLevel.random.nextFloat()) * 0.2F, 0.35F, (serverLevel.random.nextFloat() - serverLevel.random.nextFloat()) * 0.2F);
                entity.hasImpulse = true;
                serverLevel.playSound(null, entity.blockPosition(), SoundEvents.ITEM_PICKUP, SoundSource.BLOCKS, 0.2F, (serverLevel.random.nextFloat() - serverLevel.random.nextFloat()) * 0.7F + 1.0F);
                break;
            }
            dissolvedAspects.forEach((aspect, amount) -> this.aspects.merge(aspect, amount, CrucibleBlockEntity::saturatingAdd));
            remaining--;
            dissolved = true;
            this.counter = -150L;
        }
        if (dissolved) {
            serverLevel.playSound(null, this.worldPosition, TCSounds.BUBBLE.get(), SoundSource.BLOCKS, 0.2F, 1.0F + serverLevel.random.nextFloat() * 0.4F);
            serverLevel.blockEvent(this.worldPosition, this.getBlockState().getBlock(), 2, 1);
        }
        if (crafted) {
            serverLevel.playSound(null, this.worldPosition, TCSounds.BUBBLE.get(), SoundSource.BLOCKS, 0.35F, 0.85F + serverLevel.random.nextFloat() * 0.2F);
            serverLevel.blockEvent(this.worldPosition, this.getBlockState().getBlock(), 2, 5);
        }
        if (remaining <= 0) {
            entity.discard();
        } else if (remaining != stack.getCount()) {
            stack.setCount(remaining);
            entity.setItem(stack);
        }
        if (dissolved || crafted) {
            this.changedAndSync();
        }
        return dissolved || crafted;
    }

    public void spillRemnants() {
        if (!(this.level instanceof ServerLevel serverLevel) || this.water() <= 0 && this.totalAspects() <= 0) {
            return;
        }
        this.tank.setFluid(net.minecraftforge.fluids.FluidStack.EMPTY);
        int spillAttempts = this.totalAspects() / 2;
        for (int index = 0; index < spillAttempts; index++) {
            this.spill(serverLevel);
        }
        this.aspects.clear();
        this.changedAndSync();
        serverLevel.blockEvent(this.worldPosition, this.getBlockState().getBlock(), 2, 5);
    }

    public void recountBellows() {
        if (this.level == null) {
            this.bellows = 0;
            return;
        }
        this.bellows = 0;
        for (Direction direction : Direction.Plane.HORIZONTAL) {
            if (ArcaneBellowsApi.blowsToward(this.level, this.worldPosition.relative(direction), this.worldPosition)) {
                this.bellows++;
            }
        }
    }

    /**
     * Crucible recipes in the core selection order.
     */
    public List<CrucibleRecipe> orderedRecipes() {
        return CrucibleRecipeOrdering.forSelection(RecipeLookup.all(this.level.getRecipeManager(), TCRecipes.CRUCIBLE.get()));
    }

    /**
     * The recipe the core crafts from this catalyst against the current contents; null if none.
     */
    @javax.annotation.Nullable
    public CrucibleRecipe findRecipe(List<CrucibleRecipe> recipes, ItemStack stack, Entity owner) {
        CrucibleRecipe selected = null;
        int highestAspectKinds = 0;
        for (CrucibleRecipe holder : recipes) {
            CrucibleRecipe recipe = java.util.Objects.requireNonNull(holder);
            if (recipe.catalystMatches(stack) && recipe.hasRequiredAspects(this.aspects) && this.knowsResearch(owner, recipe.research())) {
                int aspectKinds = recipe.aspects().size();
                // TC4 resolves overlapping catalysts by specificity. Keep the
                // stable selection order as the tie-break by replacing only
                // when a recipe requires strictly more aspect kinds.
                if (aspectKinds > highestAspectKinds) {
                    highestAspectKinds = aspectKinds;
                    selected = recipe;
                }
            }
        }
        return selected;
    }

    private boolean knowsResearch(Entity owner, ResearchRequirement research) {
        return research.key().map(key -> owner instanceof Player player && ResearchApi.isComplete(player, key)).orElse(true);
    }

    /**
     * Ejects items as crafted output is ejected; consumes the stack.
     */
    public void ejectItem(ItemStack items) {
        if (!(this.level instanceof ServerLevel serverLevel)) {
            return;
        }
        boolean first = true;
        while (!items.isEmpty()) {
            int count = Math.min(items.getCount(), items.getMaxStackSize());
            ItemStack output = items.copyWithCount(count);
            items.shrink(count);
            SpecialItemEntity entity = new SpecialItemEntity(serverLevel, this.worldPosition.getX() + 0.5, this.worldPosition.getY() + 0.71, this.worldPosition.getZ() + 0.5, output);
            entity.setDeltaMovement(first ? 0.0 : (serverLevel.random.nextFloat() - serverLevel.random.nextFloat()) * 0.01, 0.1, first ? 0.0 : (serverLevel.random.nextFloat() - serverLevel.random.nextFloat()) * 0.01);
            serverLevel.addFreshEntity(entity);
            first = false;
        }
    }

    /**
     * One core decomposition step; does not check heat or reset its timer.
     */
    public void decomposeOneAspect(ServerLevel level) {
        if (this.aspects.isEmpty()) {
            return;
        }
        AspectId aspect = this.randomAspect(level);
        if (aspect == null) {
            return;
        }
        AspectDefinition definition = AspectCatalog.get(aspect);
        if (definition != null && definition.primal()) {
            aspect = this.randomAspect(level);
            if (aspect == null) {
                return;
            }
            definition = AspectCatalog.get(aspect);
        }
        this.drainWaterWithoutSync(TCGameplayParameters.ALCHEMY_CRUCIBLE_DECOMPOSITION_WATER.intValue());
        this.removeAspect(aspect, 1);
        if (definition != null && !definition.primal()) {
            List<AspectId> components = AspectCatalog.componentIds(definition);
            AspectId component = components.get(level.random.nextBoolean() ? 0 : 1);
            this.aspects.merge(component, 1, CrucibleBlockEntity::saturatingAdd);
        } else {
            this.spill(level);
        }
        this.changedAndSync();
    }

    private AspectId takeRandomAspect(ServerLevel level) {
        if (this.aspects.isEmpty()) {
            return null;
        }
        AspectId aspect = this.randomAspect(level);
        if (aspect == null) {
            return null;
        }
        this.removeAspect(aspect, 1);
        this.changedAndSync();
        return aspect;
    }

    @javax.annotation.Nullable
    private AspectId randomAspect(ServerLevel level) {
        List<AspectId> present = this.aspects.keySet().stream().filter(AspectCatalog::contains).toList();
        if (present.isEmpty()) {
            return null;
        }
        return present.get(level.random.nextInt(present.size()));
    }

    /**
     * Removes up to {@code amount}; no sufficiency check, no sync.
     */
    public void removeAspect(AspectId aspect, int amount) {
        int remaining = this.aspects.getOrDefault(aspect, 0) - amount;
        if (remaining > 0) {
            this.aspects.put(aspect, remaining);
        } else {
            this.aspects.remove(aspect);
        }
    }

    private void removeEmptyAspects() {
        this.aspects.entrySet().removeIf(entry -> entry.getValue() <= 0);
    }

    private void drainWaterWithoutSync(int amount) {
        int drained = Math.min(Math.max(0, amount), this.water());
        if (drained <= 0) {
            return;
        }
        net.minecraftforge.fluids.FluidStack stored = this.tank.getFluid();
        stored.shrink(drained);
        if (stored.isEmpty()) {
            this.tank.setFluid(net.minecraftforge.fluids.FluidStack.EMPTY);
        }
    }

    /**
     * Whether the core treats the block at {@code pos} as a crucible heat source.
     */
    public static boolean hasHeatSource(Level level, BlockPos pos) {
        BlockState source = level.getBlockState(pos);
        return !source.getFluidState().isEmpty() && source.getFluidState().getType() == net.minecraft.world.level.material.Fluids.LAVA || source.is(Blocks.FIRE) || source.is(Blocks.SOUL_FIRE) || source.is(TCBlocks.byId("nitor").get());
    }

    private void spill(ServerLevel level) {
        if (level.random.nextInt(4) != 0) {
            return;
        }
        BlockPos above = this.worldPosition.above();
        if (level.getBlockState(above).isAir()) {
            this.placeFlux(level, above);
            return;
        }
        if (FluxApi.add(level, above, 1)) {
            return;
        }
        BlockPos target = this.worldPosition.offset(level.random.nextInt(3) - 1, level.random.nextInt(3) - 1, level.random.nextInt(3) - 1);
        if (level.getBlockState(target).isAir()) {
            this.placeFlux(level, target);
        }
    }

    private void placeFlux(ServerLevel level, BlockPos pos) {
        FluxApi.place(level, pos, level.random.nextBoolean() ? TCFluids.FLUX_GAS.get() : TCFluids.FLUX_GOO.get(), 1, 3);
    }

    /**
     * Saves and sends the client and comparator updates.
     */
    public void changedAndSync() {
        this.setChanged();
        if (this.level != null) {
            this.level.sendBlockUpdated(this.worldPosition, this.getBlockState(), this.getBlockState(), Block.UPDATE_CLIENTS);
            this.level.updateNeighbourForOutputSignal(this.worldPosition, this.getBlockState().getBlock());
        }
    }

    @Override
    public boolean triggerEvent(int id, int parameter) {
        if (id == 1) {
            if (this.level != null && this.level.isClientSide) {
                dev.tc4port.thaumcraft.client.InfusionSparkleEffects.blockSparkle(this.level, this.worldPosition, -9999, 5);
            }
            return true;
        }
        if (id == 2) {
            if (this.level != null && this.level.isClientSide) {
                dev.tc4port.thaumcraft.client.CrucibleBubbleParticle.boilEvent(this.level, this.worldPosition, this, parameter);
            }
            return true;
        }
        return super.triggerEvent(id, parameter);
    }

    @Override
    protected void saveAdditional(CompoundTag tag) {
        HolderLookup.Provider registries = persistenceRegistries();
        super.saveAdditional(tag);
        tag.putShort(HEAT_KEY, this.heat);
        FluidTankStorage.save(this.tank, tag, TANK_KEY, registries);
        ListTag aspectList = new ListTag();
        this.aspects.forEach((aspect, amount) -> {
            CompoundTag entry = new CompoundTag();
            entry.putString("key", aspect.serialized());
            entry.putInt("amount", amount);
            aspectList.add(entry);
        });
        tag.put(ASPECTS_KEY, aspectList);
    }

    @Override
    public void load(CompoundTag tag) {
        HolderLookup.Provider registries = persistenceRegistries();
        super.load(tag);
        this.heat = (short) Mth.clamp(tag.getShort(HEAT_KEY), 0, 200);
        FluidTankStorage.load(this.tank, tag, TANK_KEY, registries);
        /*
         * TileCrucible deliberately did not persist its counter. A reload
         * therefore restores the original -100-tick settling delay.
         */
        this.counter = -100L;
        this.aspects.clear();
        ListTag aspectList = tag.getList(ASPECTS_KEY, Tag.TAG_COMPOUND);
        for (int index = 0; index < aspectList.size(); index++) {
            CompoundTag entry = aspectList.getCompound(index);
            AspectId aspect = parsePersistedAspect(entry.getString("key"));
            int amount = entry.getInt("amount");
            if (aspect != null && amount > 0) {
                this.aspects.merge(aspect, amount, CrucibleBlockEntity::saturatingAdd);
            }
        }
        this.bellows = -1;
    }

    @javax.annotation.Nullable
    private static AspectId parsePersistedAspect(String value) {
        try {
            return value == null || value.isBlank() ? null : AspectId.parse(value);
        } catch (RuntimeException ignored) {
            return null;
        }
    }

    private static int saturatingAdd(int first, int second) {
        return (int) Math.min(Integer.MAX_VALUE, (long) first + second);
    }

    @Override
    public ClientboundBlockEntityDataPacket getUpdatePacket() {
        return ClientboundBlockEntityDataPacket.create(this);
    }

    @Override
    public CompoundTag getUpdateTag() {
        return this.saveWithoutMetadata();
    }

    private class NativeAnonymous1 extends NativeFluidTank {

        NativeAnonymous1(java.util.function.IntSupplier native$arg0, java.util.function.Predicate<net.minecraftforge.fluids.FluidStack> native$arg1) {
            super(native$arg0, native$arg1);
        }

        @Override
        protected void onContentsChanged() {
            CrucibleBlockEntity.this.changedAndSync();
        }
    }

    protected final HolderLookup.Provider persistenceRegistries() {
        if (level != null)
            return level.registryAccess();
        var server = net.minecraftforge.server.ServerLifecycleHooks.getCurrentServer();
        return server != null ? server.registryAccess() : net.minecraft.core.RegistryAccess.fromRegistryOfRegistries(net.minecraft.core.registries.BuiltInRegistries.REGISTRY);
    }

    protected static net.minecraft.network.chat.Component parseCustomNameSafe(String value, HolderLookup.Provider registries) {
        try {
            return net.minecraft.network.chat.Component.Serializer.fromJson(value);
        } catch (RuntimeException exception) {
            return null;
        }
    }

    protected void readItemFields(ItemFields.Input input) {
    }

    public void copyItemFields(ItemFields.Output output) {
    }

    public void applyComponentsFromItemStack(ItemStack stack) {
        readItemFields(ItemFields.from(stack));
    }

    public void removeComponentsFromTag(CompoundTag tag) {
    }

    @Override
    public void saveToItem(ItemStack stack) {
        CompoundTag tag = saveWithoutMetadata();
        {
            net.minecraft.nbt.CompoundTag native$bodyOperand$6117 = tag;
            native$bodyReturn$6119: {
                if (true) {
                }
            }
        }
        net.minecraft.world.item.BlockItem.setBlockEntityData(stack, getType(), tag);
        copyItemFields(ItemFields.to(stack));
    }

    @Override
    public net.minecraft.world.phys.AABB getRenderBoundingBox() {
        return CrucibleBlockEntity.native$ClientBlockEntityBounds$bounds(this);
    }

    @Override()
    public void onDataPacket(net.minecraft.network.Connection connection, net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket packet) {
        handleUpdateTag(packet.getTag());
    }

    @SuppressWarnings({ "rawtypes", "unchecked" })
    static private net.minecraft.world.phys.AABB native$ClientBlockEntityBounds$bounds(net.minecraft.world.level.block.entity.BlockEntity blockEntity) {
        var renderer = net.minecraft.client.Minecraft.getInstance().getBlockEntityRenderDispatcher().getRenderer(blockEntity);
        return renderer instanceof dev.tc4port.thaumcraft.nativeimpl.NativeBlockEntityRenderer shared ? shared.getRenderBoundingBox(blockEntity) : new net.minecraft.world.phys.AABB(blockEntity.getBlockPos());
    }

    private boolean native$capabilitiesInvalid$16942;

    public boolean native$capabilityActive$16792;

    private java.util.Map<net.minecraft.core.Direction, net.minecraftforge.common.util.LazyOptional<net.minecraftforge.fluids.capability.IFluidHandler>> native$capabilityHandle$16793;

    @Override
    public <native$capabilityResultType$16943> net.minecraftforge.common.util.LazyOptional<native$capabilityResultType$16943> getCapability(net.minecraftforge.common.capabilities.Capability<native$capabilityResultType$16943> native$requestedCapability$16944, net.minecraft.core.Direction native$requestedFace$16945) {
        getCapabilities();
        synchronized (this) {
            if (native$capabilitiesInvalid$16942)
                return net.minecraftforge.common.util.LazyOptional.empty();
            if (native$capabilityActive$16792 && native$requestedCapability$16944 == (net.minecraftforge.common.capabilities.ForgeCapabilities.FLUID_HANDLER)) {
                if (native$capabilityHandle$16793 == null)
                    native$capabilityHandle$16793 = new java.util.HashMap<>();
                net.minecraftforge.common.util.LazyOptional<net.minecraftforge.fluids.capability.IFluidHandler> native$capabilityResult$16947 = native$capabilityHandle$16793.computeIfAbsent(native$requestedFace$16945, native$capabilityFace$16794 -> {
                    net.minecraftforge.fluids.capability.IFluidHandler native$endpoint$76 = (switch(0) {
                        default ->
                            {
                                dev.tc4port.thaumcraft.block.entity.CrucibleBlockEntity crucible = dev.tc4port.thaumcraft.block.entity.CrucibleBlockEntity.this;
                                net.minecraft.core.Direction side = native$capabilityFace$16794;
                                yield crucible.tank();
                            }
                    });
                    return native$endpoint$76 == null ? net.minecraftforge.common.util.LazyOptional.empty() : net.minecraftforge.common.util.LazyOptional.of(() -> native$endpoint$76);
                });
                if (native$capabilityResult$16947.isPresent())
                    return native$capabilityResult$16947.cast();
            }
        }
        return super.getCapability(native$requestedCapability$16944, native$requestedFace$16945);
    }

    @Override
    public void invalidateCaps() {
        java.util.List<net.minecraftforge.common.util.LazyOptional<?>> native$expiredCapabilities$16946 = new java.util.ArrayList<>();
        synchronized (this) {
            native$capabilitiesInvalid$16942 = true;
            if (native$capabilityHandle$16793 != null) {
                native$expiredCapabilities$16946.addAll(native$capabilityHandle$16793.values());
                native$capabilityHandle$16793 = null;
            }
        }
        try {
            super.invalidateCaps();
        } finally {
            native$expiredCapabilities$16946.forEach(net.minecraftforge.common.util.LazyOptional::invalidate);
        }
    }

    @Override
    public void reviveCaps() {
        super.reviveCaps();
        synchronized (this) {
            native$capabilitiesInvalid$16942 = false;
        }
    }
}
