package dev.tc4port.thaumcraft.block;

import com.mojang.serialization.MapCodec;
import dev.tc4port.thaumcraft.block.entity.AlchemicalCentrifugeBlockEntity;
import dev.tc4port.thaumcraft.registry.TCBlockEntities;
import javax.annotation.Nullable;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityTicker;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;
import dev.tc4port.thaumcraft.nativeimpl.ClientExtensionTarget;
import dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.level.pathfinder.PathComputationType;
import net.minecraft.world.phys.HitResult;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.Explosion;

/**
 * Dedicated shell for BlockTube metadata 2.
 */
public final class AlchemicalCentrifugeBlock extends net.minecraft.world.level.block.BaseEntityBlock implements dev.tc4port.thaumcraft.nativeimpl.ClientExtensionTarget {

    // Forge calls initializeClient from the native superclass constructor. Do not add a field initializer.
    private java.util.function.Consumer<net.minecraftforge.client.extensions.common.IClientBlockExtensions> platform$clientInstaller;

    public static final MapCodec<AlchemicalCentrifugeBlock> CODEC = AlchemicalCentrifugeBlock.native$BlockCodecPlatform$simple(AlchemicalCentrifugeBlock::new);

    private static final VoxelShape OUTLINE = Block.box(4, 0, 4, 12, 16, 12);

    public AlchemicalCentrifugeBlock(BlockBehaviour.Properties properties) {
        this(properties, properties, true);
    }

    protected MapCodec<AlchemicalCentrifugeBlock> codec() {
        return CODEC;
    }

    @Nullable
    @Override
    public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        return new AlchemicalCentrifugeBlockEntity(pos, state);
    }

    @Nullable
    @Override
    public <T extends BlockEntity> BlockEntityTicker<T> getTicker(Level level, BlockState state, BlockEntityType<T> type) {
        return createTickerHelper(type, TCBlockEntities.ALCHEMICAL_CENTRIFUGE.get(), level.isClientSide ? AlchemicalCentrifugeBlockEntity::clientTick : AlchemicalCentrifugeBlockEntity::serverTick);
    }

    @Override
    public RenderShape getRenderShape(BlockState state) {
        return RenderShape.MODEL;
    }

    @Override
    public VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
        return OUTLINE;
    }

    @Override
    public VoxelShape getCollisionShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
        // BlockTube metadata 2 used a narrow selection box but the default
        // full-cube collision branch.
        return Shapes.block();
    }

    private AlchemicalCentrifugeBlock(net.minecraft.world.level.block.state.BlockBehaviour.Properties native$NativeEntityBlock$arg0, BlockBehaviour.Properties properties, boolean native$NativeEntityBlock$captured) {
        super(native$NativeEntityBlock$arg0);
    }

    @Override
    public void initializeClient(java.util.function.Consumer<net.minecraftforge.client.extensions.common.IClientBlockExtensions> installer) {
        platform$clientInstaller = installer;
        super.initializeClient(installer);
    }

    @Override
    public void platform$clientExtension(Object extension) {
        java.util.Objects.requireNonNull(platform$clientInstaller, "Forge initializeClient must run before client extension registration").accept((net.minecraftforge.client.extensions.common.IClientBlockExtensions) extension);
    }

    @Override
    public InteractionResult use(BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
        ItemUseResult result = (switch(0) {
            default ->
                {
                    net.minecraft.world.item.ItemStack native$bodyOperand$4034 = player.getItemInHand(hand);
                    net.minecraft.world.level.block.state.BlockState native$bodyOperand$4035 = state;
                    net.minecraft.world.level.Level native$bodyOperand$4036 = level;
                    net.minecraft.core.BlockPos native$bodyOperand$4037 = pos;
                    net.minecraft.world.entity.player.Player native$bodyOperand$4038 = player;
                    net.minecraft.world.InteractionHand native$bodyOperand$4039 = hand;
                    net.minecraft.world.phys.BlockHitResult native$bodyOperand$4040 = hit;
                    dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult native$bodyResult$4041 = null;
                    native$bodyReturn$4042: {
                        if (true) {
                            {
                                native$bodyResult$4041 = dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
                                break native$bodyReturn$4042;
                            }
                        }
                    }
                    yield native$bodyResult$4041;
                }
        });
        return result == ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION ? (hand == InteractionHand.MAIN_HAND ? (switch(0) {
            default ->
                {
                    net.minecraft.world.level.block.state.BlockState native$bodyOperand$3408 = state;
                    net.minecraft.world.level.Level native$bodyOperand$3409 = level;
                    net.minecraft.core.BlockPos native$bodyOperand$3410 = pos;
                    net.minecraft.world.entity.player.Player native$bodyOperand$3411 = player;
                    net.minecraft.world.phys.BlockHitResult native$bodyOperand$3412 = hit;
                    net.minecraft.world.InteractionResult native$bodyResult$3413 = null;
                    native$bodyReturn$3414: {
                        if (true) {
                            {
                                native$bodyResult$3413 = super.use(native$bodyOperand$3408, native$bodyOperand$3409, native$bodyOperand$3410, native$bodyOperand$3411, net.minecraft.world.InteractionHand.MAIN_HAND, native$bodyOperand$3412);
                                break native$bodyReturn$3414;
                            }
                        }
                    }
                    yield native$bodyResult$3413;
                }
        }) : InteractionResult.PASS) : result.result();
    }

    protected ItemUseResult interactWithItem(ItemStack stack, BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
        return dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
    }

    protected InteractionResult interactWithoutItem(BlockState state, Level level, BlockPos pos, Player player, BlockHitResult hit) {
        return super.use(state, level, pos, player, net.minecraft.world.InteractionHand.MAIN_HAND, hit);
    }

    @Override
    public void playerWillDestroy(Level level, BlockPos pos, BlockState state, Player player) {
        {
            net.minecraft.world.level.Level native$bodyOperand$5608 = level;
            net.minecraft.core.BlockPos native$bodyOperand$5609 = pos;
            net.minecraft.world.level.block.state.BlockState native$bodyOperand$5610 = state;
            net.minecraft.world.entity.player.Player native$bodyOperand$5611 = player;
            net.minecraft.world.level.block.state.BlockState native$bodyResult$5612 = null;
            native$bodyReturn$5613: {
                if (true) {
                    super.playerWillDestroy(native$bodyOperand$5608, native$bodyOperand$5609, native$bodyOperand$5610, native$bodyOperand$5611);
                    {
                        native$bodyResult$5612 = native$bodyOperand$5610;
                        break native$bodyReturn$5613;
                    }
                }
            }
        }
    }

    public BlockState beforePlayerDestroy(Level level, BlockPos pos, BlockState state, Player player) {
        super.playerWillDestroy(level, pos, state, player);
        return state;
    }

    protected boolean survivesSharedExplosion() {
        return false;
    }

    public int getExpDrop(net.minecraft.world.level.block.state.BlockState native$callbackInput$1050, net.minecraft.world.level.LevelReader native$callbackInput$1051, net.minecraft.util.RandomSource native$callbackInput$1052, net.minecraft.core.BlockPos native$callbackInput$1053, int native$callbackInput$1054, int native$callbackInput$1055) {
        net.minecraft.world.level.block.state.BlockState state = native$callbackInput$1050;
        net.minecraft.util.RandomSource random = native$callbackInput$1052;
        return 0;
    }

    @Override
    public void onBlockExploded(BlockState state, Level level, BlockPos pos, Explosion explosion) {
        if (!(switch(0) {
            default ->
                {
                    boolean native$bodyResult$5199 = false;
                    native$bodyReturn$5200: {
                        if (true) {
                            {
                                native$bodyResult$5199 = false;
                                break native$bodyReturn$5200;
                            }
                        }
                    }
                    yield native$bodyResult$5199;
                }
        }))
            super.onBlockExploded(state, level, pos, explosion);
    }

    @Override
    public boolean canDropFromExplosion(BlockState state, BlockGetter level, BlockPos pos, Explosion explosion) {
        return !(switch(0) {
            default ->
                {
                    boolean native$bodyResult$4043 = false;
                    native$bodyReturn$4044: {
                        if (true) {
                            {
                                native$bodyResult$4043 = false;
                                break native$bodyReturn$4044;
                            }
                        }
                    }
                    yield native$bodyResult$4043;
                }
        }) && super.canDropFromExplosion(state, level, pos, explosion);
    }

    static private <B extends net.minecraft.world.level.block.Block> com.mojang.serialization.MapCodec<B> native$BlockCodecPlatform$simple(java.util.function.Function<net.minecraft.world.level.block.state.BlockBehaviour.Properties, B> factory) {
        // Vanilla 1.21's Properties codec is a unit codec. Retain that schema for shared block definitions.
        return com.mojang.serialization.codecs.RecordCodecBuilder.mapCodec(instance -> instance.group(com.mojang.serialization.Codec.unit(net.minecraft.world.level.block.state.BlockBehaviour.Properties::of).fieldOf("properties").forGetter((B block) -> net.minecraft.world.level.block.state.BlockBehaviour.Properties.copy(block))).apply(instance, factory));
    }
}
