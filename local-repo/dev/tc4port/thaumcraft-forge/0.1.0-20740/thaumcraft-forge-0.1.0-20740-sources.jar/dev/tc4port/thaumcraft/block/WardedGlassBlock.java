package dev.tc4port.thaumcraft.block;

import com.mojang.serialization.MapCodec;
import dev.tc4port.thaumcraft.block.entity.WardedGlassBlockEntity;
import dev.tc4port.thaumcraft.common.TCServerConfig;
import dev.tc4port.thaumcraft.registry.TCItems;
import javax.annotation.Nullable;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.BlockAndTintGetter;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Explosion;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.LevelEvent;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.material.FluidState;
import net.minecraft.world.level.material.PushReaction;
import dev.tc4port.thaumcraft.nativeimpl.ClientExtensionTarget;
import dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.level.pathfinder.PathComputationType;
import net.minecraft.world.phys.HitResult;
import net.minecraft.util.RandomSource;

/**
 * Metadata two of TC4's BlockCosmeticOpaque.
 */
public final class WardedGlassBlock extends net.minecraft.world.level.block.BaseEntityBlock implements dev.tc4port.thaumcraft.nativeimpl.ClientExtensionTarget {

    // Forge calls initializeClient from the native superclass constructor. Do not add a field initializer.
    private java.util.function.Consumer<net.minecraftforge.client.extensions.common.IClientBlockExtensions> platform$clientInstaller;

    public static final MapCodec<WardedGlassBlock> CODEC = WardedGlassBlock.native$BlockCodecPlatform$simple(WardedGlassBlock::new);

    public WardedGlassBlock(BlockBehaviour.Properties properties) {
        this(properties, properties, true);
    }

    protected MapCodec<WardedGlassBlock> codec() {
        return CODEC;
    }

    @Nullable
    @Override
    public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        return new WardedGlassBlockEntity(pos, state);
    }

    @Override
    public RenderShape getRenderShape(BlockState state) {
        return RenderShape.MODEL;
    }

    @Override
    public boolean shouldDisplayFluidOverlay(BlockState state, BlockAndTintGetter level, BlockPos pos, FluidState fluidState) {
        /*
         * Vanilla HalfTransparentBlock selects the calm fluid overlay for
         * adjacent fluid faces. This block cannot inherit that class because
         * it owns a block entity, so opt into the same rendering contract
         * explicitly instead of showing the animated flowing side texture.
         */
        return true;
    }

    @Override
    public void setPlacedBy(Level level, BlockPos pos, BlockState state, @Nullable LivingEntity placer, ItemStack stack) {
        super.setPlacedBy(level, pos, state, placer, stack);
        if (placer instanceof Player player && level.getBlockEntity(pos) instanceof WardedGlassBlockEntity glass) {
            glass.setOwner(player);
        }
    }

    @Override
    public boolean skipRendering(BlockState state, BlockState adjacentState, net.minecraft.core.Direction direction) {
        return adjacentState.is(this) || super.skipRendering(state, adjacentState, direction);
    }

    @Override
    public int getLightBlock(BlockState state, BlockGetter level, BlockPos pos) {
        return 0;
    }

    // The block entity prevents inheriting vanilla's glass class. Preserve
    // its transparent lighting even though this block has a full collision box.
    @Override
    public boolean propagatesSkylightDown(BlockState state, BlockGetter level, BlockPos pos) {
        return true;
    }

    @Override
    public float getShadeBrightness(BlockState state, BlockGetter level, BlockPos pos) {
        return 1.0F;
    }

    @Override
    public boolean canEntityDestroy(BlockState state, BlockGetter level, BlockPos pos, Entity entity) {
        return false;
    }

    @Override
    public float getExplosionResistance(BlockState state, BlockGetter level, BlockPos pos, Explosion explosion) {
        return 999.0F;
    }

    protected boolean survivesSharedExplosion() {
        return true;
    }

    public boolean canDropFromExplosion(BlockState state, BlockGetter level, BlockPos pos, Explosion explosion) {
        return false;
    }

    @Override
    public float getDestroyProgress(BlockState state, Player player, BlockGetter level, BlockPos pos) {
        return TCServerConfig.wardedStone() ? 0.0F : destroyProgress(state, player, level, pos, 5.0F);
    }

    public static boolean recoverWithWand(Level level, BlockPos pos, Player player) {
        if (!(level.getBlockEntity(pos) instanceof WardedGlassBlockEntity glass) || TCServerConfig.wardedStone() && !glass.isOwner(player)) {
            return false;
        }
        if (!level.isClientSide) {
            level.addFreshEntity(new ItemEntity(level, pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5, new ItemStack(TCItems.blockItemById("warded_glass").get())));
            level.levelEvent(LevelEvent.PARTICLES_DESTROY_BLOCK, pos, Block.getId(level.getBlockState(pos)));
            level.removeBlock(pos, false);
        }
        return true;
    }

    public static BlockBehaviour.Properties sourceProperties() {
        return BlockBehaviour.Properties.of().strength(-1.0F, 999.0F).sound(net.minecraft.world.level.block.SoundType.STONE).requiresCorrectToolForDrops().noOcclusion().pushReaction(PushReaction.BLOCK);
    }

    static float destroyProgress(BlockState state, Player player, BlockGetter level, BlockPos pos, float hardness) {
        int divisor = dev.tc4port.thaumcraft.api.event.GameplayHooks.harvestCheck(player, state, level, pos) ? 30 : 100;
        return player.getDigSpeed(state, pos) / hardness / divisor;
    }

    private WardedGlassBlock(net.minecraft.world.level.block.state.BlockBehaviour.Properties native$NativeEntityBlock$arg0, BlockBehaviour.Properties properties, boolean native$NativeEntityBlock$captured) {
        super(native$NativeEntityBlock$arg0);
    }

    @Override
    public void initializeClient(java.util.function.Consumer<net.minecraftforge.client.extensions.common.IClientBlockExtensions> installer) {
        platform$clientInstaller = installer;
        super.initializeClient(installer);
    }

    @Override
    public void platform$clientExtension(Object extension) {
        java.util.Objects.requireNonNull(platform$clientInstaller, "Forge initializeClient must run before client extension registration").accept((net.minecraftforge.client.extensions.common.IClientBlockExtensions) extension);
    }

    @Override
    public InteractionResult use(BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
        ItemUseResult result = (switch(0) {
            default ->
                {
                    net.minecraft.world.item.ItemStack native$bodyOperand$4813 = player.getItemInHand(hand);
                    net.minecraft.world.level.block.state.BlockState native$bodyOperand$4814 = state;
                    net.minecraft.world.level.Level native$bodyOperand$4815 = level;
                    net.minecraft.core.BlockPos native$bodyOperand$4816 = pos;
                    net.minecraft.world.entity.player.Player native$bodyOperand$4817 = player;
                    net.minecraft.world.InteractionHand native$bodyOperand$4818 = hand;
                    net.minecraft.world.phys.BlockHitResult native$bodyOperand$4819 = hit;
                    dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult native$bodyResult$4820 = null;
                    native$bodyReturn$4821: {
                        if (true) {
                            {
                                native$bodyResult$4820 = dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
                                break native$bodyReturn$4821;
                            }
                        }
                    }
                    yield native$bodyResult$4820;
                }
        });
        return result == ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION ? (hand == InteractionHand.MAIN_HAND ? (switch(0) {
            default ->
                {
                    net.minecraft.world.level.block.state.BlockState native$bodyOperand$3925 = state;
                    net.minecraft.world.level.Level native$bodyOperand$3926 = level;
                    net.minecraft.core.BlockPos native$bodyOperand$3927 = pos;
                    net.minecraft.world.entity.player.Player native$bodyOperand$3928 = player;
                    net.minecraft.world.phys.BlockHitResult native$bodyOperand$3929 = hit;
                    net.minecraft.world.InteractionResult native$bodyResult$3930 = null;
                    native$bodyReturn$3931: {
                        if (true) {
                            {
                                native$bodyResult$3930 = super.use(native$bodyOperand$3925, native$bodyOperand$3926, native$bodyOperand$3927, native$bodyOperand$3928, net.minecraft.world.InteractionHand.MAIN_HAND, native$bodyOperand$3929);
                                break native$bodyReturn$3931;
                            }
                        }
                    }
                    yield native$bodyResult$3930;
                }
        }) : InteractionResult.PASS) : result.result();
    }

    protected ItemUseResult interactWithItem(ItemStack stack, BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
        return dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
    }

    protected InteractionResult interactWithoutItem(BlockState state, Level level, BlockPos pos, Player player, BlockHitResult hit) {
        return super.use(state, level, pos, player, net.minecraft.world.InteractionHand.MAIN_HAND, hit);
    }

    @Override
    public void playerWillDestroy(Level level, BlockPos pos, BlockState state, Player player) {
        {
            net.minecraft.world.level.Level native$bodyOperand$6059 = level;
            net.minecraft.core.BlockPos native$bodyOperand$6060 = pos;
            net.minecraft.world.level.block.state.BlockState native$bodyOperand$6061 = state;
            net.minecraft.world.entity.player.Player native$bodyOperand$6062 = player;
            net.minecraft.world.level.block.state.BlockState native$bodyResult$6063 = null;
            native$bodyReturn$6064: {
                if (true) {
                    super.playerWillDestroy(native$bodyOperand$6059, native$bodyOperand$6060, native$bodyOperand$6061, native$bodyOperand$6062);
                    {
                        native$bodyResult$6063 = native$bodyOperand$6061;
                        break native$bodyReturn$6064;
                    }
                }
            }
        }
    }

    public BlockState beforePlayerDestroy(Level level, BlockPos pos, BlockState state, Player player) {
        super.playerWillDestroy(level, pos, state, player);
        return state;
    }

    public int getExpDrop(net.minecraft.world.level.block.state.BlockState native$callbackInput$1050, net.minecraft.world.level.LevelReader native$callbackInput$1051, net.minecraft.util.RandomSource native$callbackInput$1052, net.minecraft.core.BlockPos native$callbackInput$1053, int native$callbackInput$1054, int native$callbackInput$1055) {
        net.minecraft.world.level.block.state.BlockState state = native$callbackInput$1050;
        net.minecraft.util.RandomSource random = native$callbackInput$1052;
        return 0;
    }

    @Override
    public void onBlockExploded(BlockState state, Level level, BlockPos pos, Explosion explosion) {
        if (!(switch(0) {
            default ->
                {
                    boolean native$bodyResult$5333 = false;
                    native$bodyReturn$5334: {
                        if (true) {
                            {
                                native$bodyResult$5333 = true;
                                break native$bodyReturn$5334;
                            }
                        }
                    }
                    yield native$bodyResult$5333;
                }
        }))
            super.onBlockExploded(state, level, pos, explosion);
    }

    static private <B extends net.minecraft.world.level.block.Block> com.mojang.serialization.MapCodec<B> native$BlockCodecPlatform$simple(java.util.function.Function<net.minecraft.world.level.block.state.BlockBehaviour.Properties, B> factory) {
        // Vanilla 1.21's Properties codec is a unit codec. Retain that schema for shared block definitions.
        return com.mojang.serialization.codecs.RecordCodecBuilder.mapCodec(instance -> instance.group(com.mojang.serialization.Codec.unit(net.minecraft.world.level.block.state.BlockBehaviour.Properties::of).fieldOf("properties").forGetter((B block) -> net.minecraft.world.level.block.state.BlockBehaviour.Properties.copy(block))).apply(instance, factory));
    }
}
