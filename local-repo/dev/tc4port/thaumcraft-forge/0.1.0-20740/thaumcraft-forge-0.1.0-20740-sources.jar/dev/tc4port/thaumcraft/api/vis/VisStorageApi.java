package dev.tc4port.thaumcraft.api.vis;

import dev.tc4port.thaumcraft.api.Registration;
import dev.tc4port.thaumcraft.common.OwnedVisStorageRegistry;
import java.util.Objects;
import net.minecraft.world.item.Item;

/**
 * Runtime item-owner Vis storage registrations.
 */
public final class VisStorageApi {

    private VisStorageApi() {
    }

    public static Registration registerItem(Item item, OwnedVisStorageProvider provider) {
        return Registration.of(OwnedVisStorageRegistry.register(Objects.requireNonNull(item, "item"), Objects.requireNonNull(provider, "provider")));
    }

    public static long generation() {
        return OwnedVisStorageRegistry.generation();
    }
}
