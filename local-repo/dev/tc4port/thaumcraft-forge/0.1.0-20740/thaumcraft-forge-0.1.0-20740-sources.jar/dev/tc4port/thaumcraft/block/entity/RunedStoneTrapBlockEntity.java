package dev.tc4port.thaumcraft.block.entity;

import dev.tc4port.thaumcraft.common.PlayerKnowledgeService;
import dev.tc4port.thaumcraft.network.NodeBoltPayload;
import dev.tc4port.thaumcraft.registry.TCBlockEntities;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;
import dev.tc4port.thaumcraft.nativeimpl.state.ItemFields;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityType;

/**
 * Exact server timer and attack contract of TileEldritchTrap.
 */
public final class RunedStoneTrapBlockEntity extends net.minecraft.world.level.block.entity.BlockEntity implements ItemFields.Source {

    private int countdown = 20;

    public RunedStoneTrapBlockEntity(BlockPos pos, BlockState state) {
        super(TCBlockEntities.RUNED_STONE_TRAP.get(), pos, state);
    }

    public int countdown() {
        return this.countdown;
    }

    public static void serverTick(Level level, BlockPos pos, BlockState state, RunedStoneTrapBlockEntity trap) {
        if (!(level instanceof ServerLevel serverLevel)) {
            return;
        }
        if (trap.countdown-- > 0) {
            return;
        }
        trap.countdown = dev.tc4port.thaumcraft.common.TCGameplayParameters.WARP_TRAP_INTERVAL_MINIMUM.intValue() + serverLevel.random.nextInt(dev.tc4port.thaumcraft.common.TCGameplayParameters.WARP_TRAP_INTERVAL_CHOICES.intValue());
        Player player = serverLevel.getNearestPlayer(pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5, dev.tc4port.thaumcraft.common.TCGameplayParameters.WARP_TRAP_RANGE.value(), false);
        if (player == null) {
            return;
        }
        attackPlayer(serverLevel, pos, player);
    }

    public static void attackPlayer(ServerLevel level, BlockPos pos, Player player) {
        player.hurt(level.damageSources().magic(), dev.tc4port.thaumcraft.common.TCGameplayParameters.WARP_TRAP_DAMAGE.floatValue());
        double warpChance = dev.tc4port.thaumcraft.common.TCGameplayParameters.WARP_TRAP_WARP_CHANCE.value();
        if (warpChance == 0.5D ? level.random.nextBoolean() : level.random.nextDouble() < warpChance) {
            PlayerKnowledgeService.addTemporaryWarp(player, dev.tc4port.thaumcraft.common.TCGameplayParameters.WARP_TRAP_WARP_MINIMUM.intValue() + level.random.nextInt(dev.tc4port.thaumcraft.common.TCGameplayParameters.WARP_TRAP_WARP_CHOICES.intValue()));
        }
        sendBolt(level, pos, player);
    }

    private static void sendBolt(ServerLevel level, BlockPos pos, Player target) {
        Vec3 source = Vec3.atCenterOf(pos);
        Vec3 destination = new Vec3(target.getX(), target.getEyeY(), target.getZ());
        NodeBoltPayload payload = new NodeBoltPayload(source, destination);
        for (ServerPlayer player : level.players()) {
            if (player.distanceToSqr(source) <= 32.0 * 32.0) {
                dev.tc4port.thaumcraft.network.TCPayloads.CHANNEL.sendToPlayer(player, payload);
            }
        }
    }

    protected final HolderLookup.Provider persistenceRegistries() {
        if (level != null)
            return level.registryAccess();
        var server = net.minecraftforge.server.ServerLifecycleHooks.getCurrentServer();
        return server != null ? server.registryAccess() : net.minecraft.core.RegistryAccess.fromRegistryOfRegistries(net.minecraft.core.registries.BuiltInRegistries.REGISTRY);
    }

    protected static net.minecraft.network.chat.Component parseCustomNameSafe(String value, HolderLookup.Provider registries) {
        try {
            return net.minecraft.network.chat.Component.Serializer.fromJson(value);
        } catch (RuntimeException exception) {
            return null;
        }
    }

    protected void readItemFields(ItemFields.Input input) {
    }

    public void copyItemFields(ItemFields.Output output) {
    }

    public void applyComponentsFromItemStack(ItemStack stack) {
        readItemFields(ItemFields.from(stack));
    }

    public void removeComponentsFromTag(CompoundTag tag) {
    }

    @Override
    public void saveToItem(ItemStack stack) {
        CompoundTag tag = saveWithoutMetadata();
        {
            net.minecraft.nbt.CompoundTag native$bodyOperand$6217 = tag;
            native$bodyReturn$6219: {
                if (true) {
                }
            }
        }
        net.minecraft.world.item.BlockItem.setBlockEntityData(stack, getType(), tag);
        copyItemFields(ItemFields.to(stack));
    }

    @Override
    public net.minecraft.world.phys.AABB getRenderBoundingBox() {
        return RunedStoneTrapBlockEntity.native$ClientBlockEntityBounds$bounds(this);
    }

    @Override()
    public void onDataPacket(net.minecraft.network.Connection connection, net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket packet) {
        handleUpdateTag(packet.getTag());
    }

    @SuppressWarnings({ "rawtypes", "unchecked" })
    static private net.minecraft.world.phys.AABB native$ClientBlockEntityBounds$bounds(net.minecraft.world.level.block.entity.BlockEntity blockEntity) {
        var renderer = net.minecraft.client.Minecraft.getInstance().getBlockEntityRenderDispatcher().getRenderer(blockEntity);
        return renderer instanceof dev.tc4port.thaumcraft.nativeimpl.NativeBlockEntityRenderer shared ? shared.getRenderBoundingBox(blockEntity) : new net.minecraft.world.phys.AABB(blockEntity.getBlockPos());
    }
}
