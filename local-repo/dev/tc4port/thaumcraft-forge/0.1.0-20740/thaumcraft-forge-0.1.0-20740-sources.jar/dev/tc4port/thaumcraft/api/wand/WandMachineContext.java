package dev.tc4port.thaumcraft.api.wand;

import java.util.Objects;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;

/**
 * Server-owned location for a wand transfer initiated by a machine.
 */
public record WandMachineContext(ServerLevel level, BlockPos position) {

    public WandMachineContext {
        Objects.requireNonNull(level, "level");
        position = Objects.requireNonNull(position, "position").immutable();
    }
}
