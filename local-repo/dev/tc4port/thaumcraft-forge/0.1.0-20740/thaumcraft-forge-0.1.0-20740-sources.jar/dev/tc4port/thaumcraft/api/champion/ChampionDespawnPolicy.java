package dev.tc4port.thaumcraft.api.champion;

/**
 * Despawn handling requested after a successful champion assignment.
 */
public enum ChampionDespawnPolicy {

    /**
     * Preserve the mob's current persistence-required state.
     */
    UNCHANGED,
    /**
     * Call the vanilla persistence hook so the mob cannot normally despawn.
     */
    PREVENT_DESPAWN
}
