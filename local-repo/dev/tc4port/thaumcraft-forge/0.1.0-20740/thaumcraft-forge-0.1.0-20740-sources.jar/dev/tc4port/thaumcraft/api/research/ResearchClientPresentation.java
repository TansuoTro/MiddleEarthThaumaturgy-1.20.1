package dev.tc4port.thaumcraft.api.research;

import java.util.List;
import java.util.Objects;

/**
 * Public projection of custom client pages for one active research entry.
 */
public record ResearchClientPresentation(List<ResearchClientPage> pages) {

    public ResearchClientPresentation {
        Objects.requireNonNull(pages, "pages");
        pages = List.copyOf(pages);
        if (pages.size() > 1024 || pages.stream().anyMatch(Objects::isNull)) {
            throw new IllegalArgumentException("Research client pages must be bounded and non-null");
        }
    }
}
