package dev.tc4port.thaumcraft.api.golem;

import java.util.Objects;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Entity;

/**
 * Immutable input supplied to registered golem spatial adapters.
 */
public record GolemTravelContext(ServerLevel level, Entity golem, GolemTravelTarget target, double acceptedDistanceSqr, double speed) {

    public GolemTravelContext {
        level = Objects.requireNonNull(level, "level");
        golem = Objects.requireNonNull(golem, "golem");
        target = Objects.requireNonNull(target, "target");
        if (!Double.isFinite(acceptedDistanceSqr) || acceptedDistanceSqr < 0.0) {
            throw new IllegalArgumentException("acceptedDistanceSqr must be finite and non-negative");
        }
        if (!Double.isFinite(speed) || speed < 0.0) {
            throw new IllegalArgumentException("speed must be finite and non-negative");
        }
    }
}
