package dev.tc4port.thaumcraft.api.data;

import com.mojang.serialization.Codec;
import com.mojang.serialization.DataResult;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.Locale;
import java.util.Objects;

/**
 * One explicit source-color slot used when an item tunes a Vis Relay.
 */
public record RelayAttunementDefinition(Attunement attunement) {

    public static final Codec<RelayAttunementDefinition> CODEC = RecordCodecBuilder.create(instance -> instance.group(Attunement.CODEC.fieldOf("attunement").forGetter(RelayAttunementDefinition::attunement)).apply(instance, RelayAttunementDefinition::new));

    public RelayAttunementDefinition {
        attunement = Objects.requireNonNull(attunement, "attunement");
    }

    public int relaySlot() {
        return this.attunement.relaySlot();
    }

    /**
     * Fixed TC4 shard/render order. This deliberately does not use
     * {@code VisChannel.index()}, whose primal order differs in slots 1..3.
     */
    public enum Attunement {

        AIR(0),
        FIRE(1),
        WATER(2),
        EARTH(3),
        ORDER(4),
        ENTROPY(5),
        NEUTRAL(-1);

        public static final Codec<Attunement> CODEC = Codec.STRING.comapFlatMap(Attunement::decode, value -> value.name().toLowerCase(Locale.ROOT));

        private final int relaySlot;

        Attunement(int relaySlot) {
            this.relaySlot = relaySlot;
        }

        public int relaySlot() {
            return this.relaySlot;
        }

        private static DataResult<Attunement> decode(String value) {
            if (!value.equals(value.toLowerCase(Locale.ROOT))) {
                return DataResult.error(() -> "Relay attunement must use canonical lowercase: '" + value + "'");
            }
            try {
                return DataResult.success(valueOf(value.toUpperCase(Locale.ROOT)));
            } catch (IllegalArgumentException exception) {
                return DataResult.error(() -> "Unknown relay attunement '" + value + "'");
            }
        }
    }
}
