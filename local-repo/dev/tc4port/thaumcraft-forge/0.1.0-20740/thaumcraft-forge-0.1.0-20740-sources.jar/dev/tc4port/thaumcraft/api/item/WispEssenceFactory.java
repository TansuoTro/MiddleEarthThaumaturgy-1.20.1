package dev.tc4port.thaumcraft.api.item;

import dev.tc4port.thaumcraft.util.RuntimeWarnings;
import dev.tc4port.thaumcraft.api.aspect.AspectAmounts;
import dev.tc4port.thaumcraft.api.aspect.AspectApi;
import dev.tc4port.thaumcraft.data.AspectStackData;
import dev.tc4port.thaumcraft.state.TCItemState;
import dev.tc4port.thaumcraft.registry.ManaPlants;
import java.util.LinkedHashMap;
import net.minecraft.world.item.ItemStack;

/**
 * Complete bounded current Wisp-essence factory, shared by the public API and real entity drops.
 */
public final class WispEssenceFactory {

    private WispEssenceFactory() {
    }

    public static final int MAX_WISP_ASPECT_TYPES = 64;

    public static final int MAX_WISP_TOTAL_ASPECTS = 16_384;

    public static final int MAX_WISP_ENCODED_BYTES = 4_096;

    /**
     * Invalid contents return EMPTY without constructing or storing a partial essence.
     */
    public static ItemStack create(AspectAmounts aspects) {
        if (aspects == null || aspects.amounts().isEmpty() || aspects.amounts().size() > MAX_WISP_ASPECT_TYPES) {
            return reject("Missing or excessive aspect types");
        }
        LinkedHashMap<dev.tc4port.thaumcraft.api.aspect.AspectId, Integer> encoded = new LinkedHashMap<>();
        long total = 0;
        int encodedBytes = 0;
        for (var entry : aspects.amounts().entrySet()) {
            if (AspectApi.registry().get(entry.getKey()).isEmpty()) {
                return reject("Unknown active aspect");
            }
            if (entry.getValue() <= 0) {
                return reject("Aspect amounts must be positive");
            }
            total += entry.getValue();
            encodedBytes += entry.getKey().serialized().getBytes(java.nio.charset.StandardCharsets.UTF_8).length + Integer.BYTES;
            if (encodedBytes > MAX_WISP_ENCODED_BYTES) {
                return reject("Encoded aspect data is too large");
            }
            if (total > MAX_WISP_TOTAL_ASPECTS) {
                return reject("Total aspect amount is too large");
            }
            encoded.put(entry.getKey(), entry.getValue());
        }
        ItemStack result = new ItemStack(ManaPlants.essence());
        {
            dev.tc4port.thaumcraft.api.data.ItemStateKey<dev.tc4port.thaumcraft.data.AspectStackData> native$receiver$849 = TCItemState.ASPECTS;
            net.minecraft.world.item.ItemStack native$argument$850 = result;
            dev.tc4port.thaumcraft.data.AspectStackData native$argument$851 = new AspectStackData(encoded);
            java.util.Objects.requireNonNull(native$receiver$849);
            dev.tc4port.thaumcraft.api.item.ItemStatePlatform.set(native$argument$850, native$receiver$849, java.util.Objects.requireNonNull(native$argument$851, "value"));
        }
        return result;
    }

    private static ItemStack reject(String reason) {
        RuntimeWarnings.warnOnce("wisp-essence-create", "Ignoring invalid wisp essence request: {}", reason);
        return ItemStack.EMPTY;
    }
}
