package dev.tc4port.thaumcraft.api.research;

import java.util.List;
import java.util.Objects;
import java.util.Optional;
import net.minecraft.resources.ResourceLocation;

/**
 * Immutable presentation order, bounds and active entries for one category.
 */
public record ResearchCategorySummary(ResearchCategoryKey key, Optional<ResourceLocation> icon, Optional<ResourceLocation> background, int sortOrder, int minimumColumn, int minimumRow, int maximumColumn, int maximumRow, List<ResearchKey> entries) {

    /**
     * Default band for addon categories that do not declare an order.
     */
    public static final int DEFAULT_SORT_ORDER = 1000;

    /**
     * Compatibility constructor for callers compiled against the original
     * summary shape. Addon categories created this way use the default band.
     */
    public ResearchCategorySummary(ResearchCategoryKey key, Optional<ResourceLocation> icon, Optional<ResourceLocation> background, int minimumColumn, int minimumRow, int maximumColumn, int maximumRow, List<ResearchKey> entries) {
        this(key, icon, background, DEFAULT_SORT_ORDER, minimumColumn, minimumRow, maximumColumn, maximumRow, entries);
    }

    public ResearchCategorySummary {
        key = Objects.requireNonNull(key, "key");
        icon = Objects.requireNonNull(icon, "icon");
        background = Objects.requireNonNull(background, "background");
        entries = List.copyOf(Objects.requireNonNull(entries, "entries"));
        if (minimumColumn > maximumColumn || minimumRow > maximumRow) {
            throw new IllegalArgumentException("Research category bounds are inverted: " + key);
        }
    }
}
