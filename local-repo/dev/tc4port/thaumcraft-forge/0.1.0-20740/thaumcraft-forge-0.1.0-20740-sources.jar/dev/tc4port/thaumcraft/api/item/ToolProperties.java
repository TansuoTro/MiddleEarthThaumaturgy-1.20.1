package dev.tc4port.thaumcraft.api.item;

import net.minecraft.world.item.*;

public final class ToolProperties {

    public record Values(float damage, float speed) {
    }

    private static final java.util.Map<Item.Properties, Values> VALUES = java.util.Collections.synchronizedMap(new java.util.WeakHashMap<>());

    public static Item.Properties apply(Item.Properties properties, Tier tier, float damage, float speed) {
        VALUES.put(properties, new Values(damage, speed));
        return properties;
    }

    public static Values values(Item.Properties properties) {
        return VALUES.getOrDefault(properties, new Values(0, 0));
    }

    public static com.google.common.collect.Multimap<net.minecraft.world.entity.ai.attributes.Attribute, net.minecraft.world.entity.ai.attributes.AttributeModifier> attributes(Tier tier, Item.Properties props, java.util.UUID damageId, java.util.UUID speedId) {
        var values = values(props);
        return com.google.common.collect.ImmutableMultimap.of(net.minecraft.world.entity.ai.attributes.Attributes.ATTACK_DAMAGE, new net.minecraft.world.entity.ai.attributes.AttributeModifier(damageId, "Tool modifier", tier.getAttackDamageBonus() + values.damage(), net.minecraft.world.entity.ai.attributes.AttributeModifier.Operation.ADDITION), net.minecraft.world.entity.ai.attributes.Attributes.ATTACK_SPEED, new net.minecraft.world.entity.ai.attributes.AttributeModifier(speedId, "Tool modifier", values.speed(), net.minecraft.world.entity.ai.attributes.AttributeModifier.Operation.ADDITION));
    }
}
