package dev.tc4port.thaumcraft.api.event;

import dev.tc4port.thaumcraft.api.gameplay.GameplayContext;
import java.util.Objects;
import net.minecraft.resources.ResourceLocation;

/**
 * Fired on the native game event bus on the server thread, after a Warp behavior
 * is selected and its initial requirements pass, before any of its actions run.
 * Natural rolls, commands and all WarpEventApi trigger methods share this event.
 *
 * <p>Cancel with {@code setCanceled(true)} to skip this behavior. Explicit API
 * dispatch then returns false. Cancellation does not select a replacement, undo
 * the natural activity/temporary-Warp decay, or suppress threshold research.
 * Selection-only queries do not fire this event. It is not a stored-Warp change
 * event. Context values and invocation parameters remain immutable snapshots.</p>
 */
@net.minecraftforge.eventbus.api.Cancelable()
public final class WarpEvent extends net.minecraftforge.eventbus.api.Event {

    private final ResourceLocation eventId;

    private final GameplayContext context;

    public WarpEvent(ResourceLocation eventId, GameplayContext context) {
        this.eventId = Objects.requireNonNull(eventId, "eventId");
        this.context = Objects.requireNonNull(context, "context");
    }

    public ResourceLocation getEventId() {
        return eventId;
    }

    public GameplayContext getContext() {
        return context;
    }
}
