package dev.tc4port.thaumcraft.api.node;

import javax.annotation.Nullable;
import net.minecraft.core.Direction;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import dev.tc4port.thaumcraft.util.RuntimeWarnings;
import dev.tc4port.thaumcraft.api.aspect.VisAction;
import dev.tc4port.thaumcraft.api.aspect.VisChannel;
import dev.tc4port.thaumcraft.common.VisNetwork;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;

/**
 * Server-authoritative consumer boundary for the built-in energized-node and
 * relay network. Amounts are centivis, matching wand/amulet storage. Sources are discovered through VisCapabilities.SOURCE at registered host positions.
 */
public final class VisNetworkApi {

    private static final ThreadLocal<Boolean> DRAINING = ThreadLocal.withInitial(() -> false);

    private VisNetworkApi() {
    }

    /**
     * Returns the amount available/moved in {@code [0, requested]}. SIMULATE
     * does not consume source state, trigger relay pulses or send drain FX.
     * Calls must run on the owning server thread and are not reentrant.
     * Invalid, unloaded, off-thread or reentrant requests return zero without
     * accessing the graph; invalid requests warn once per fixed category.
     */
    public static int drain(ServerLevel level, BlockPos consumer, VisChannel channel, int requestedCentivis, VisAction action) {
        if (consumer == null || channel == null || action == null || requestedCentivis <= 0) {
            RuntimeWarnings.warnOnce("vis-network-request", "Ignoring invalid Vis network drain request");
            return 0;
        }
        if (!requireThread(level))
            return 0;
        if (!level.isLoaded(consumer)) {
            return 0;
        }
        if (DRAINING.get()) {
            RuntimeWarnings.warnOnce("vis-network-reentrant", "Ignoring reentrant Vis network drain request");
            return 0;
        }
        int moved;
        DRAINING.set(true);
        try {
            moved = VisNetwork.drain(level, consumer.immutable(), channel, requestedCentivis, action);
        } finally {
            DRAINING.remove();
        }
        if (moved < 0 || moved > requestedCentivis) {
            RuntimeWarnings.warnOnce("vis-network-result", "Ignoring invalid Vis network moved amount {} for {}", moved, requestedCentivis);
            return 0;
        }
        return moved;
    }

    private record RelayDrain(ServerLevel level, BlockPos position) {
    }

    private static final ThreadLocal<java.util.Set<RelayDrain>> RELAY_DRAINS = ThreadLocal.withInitial(java.util.HashSet::new);

    /**
     * Call on load or supply enable; multiple parts at one position share one graph root.
     */
    public static void registerSource(ServerLevel level, BlockPos source) {
        if (requireThread(level) && source != null && level.isLoaded(source))
            VisNetwork.registerExternalSource(level, source);
    }

    /**
     * Call on unload/removal or after the last part at this position stops supplying.
     * An unloaded source only leaves the runtime index; saved relay edges wait
     * for its chunk to load before validation can disconnect them.
     */
    public static void removeSource(ServerLevel level, BlockPos source) {
        if (requireThread(level) && source != null)
            VisNetwork.removeSource(level, source);
    }

    /**
     * Exact native relay drain, bounded to requested centivis. Simulation emits no effects.
     */
    public static int drainRelay(ServerLevel level, BlockPos relay, VisChannel channel, int amount, VisAction action) {
        if (!requireThread(level))
            return 0;
        if (relay == null || channel == null || action == null || amount <= 0) {
            RuntimeWarnings.warnOnce("vis-relay-request", "Ignoring invalid Vis relay drain request");
            return 0;
        }
        var active = RELAY_DRAINS.get();
        var request = new RelayDrain(level, relay.immutable());
        if (active.size() >= 512 || !active.add(request))
            return 0;
        try {
            return VisNetwork.drainRelay(level, relay, channel, amount, action);
        } finally {
            active.remove(request);
            if (active.isEmpty())
                RELAY_DRAINS.remove();
        }
    }

    @Nullable
    public static BlockPos facingRelay(Level level, BlockPos position, Direction facing) {
        BlockPos relay = position.relative(facing);
        if (!level.isLoaded(relay))
            return null;
        var state = level.getBlockState(relay);
        return state.is(dev.tc4port.thaumcraft.registry.TCBlocks.VIS_RELAY.get()) && state.hasProperty(BlockStateProperties.FACING) && state.getValue(BlockStateProperties.FACING) == facing ? relay : null;
    }

    private static boolean requireThread(ServerLevel level) {
        if (level == null || !level.getServer().isSameThread()) {
            RuntimeWarnings.warnOnce("vis-network-thread", "Ignoring Vis graph access without an owning server thread");
            return false;
        }
        return true;
    }
}
