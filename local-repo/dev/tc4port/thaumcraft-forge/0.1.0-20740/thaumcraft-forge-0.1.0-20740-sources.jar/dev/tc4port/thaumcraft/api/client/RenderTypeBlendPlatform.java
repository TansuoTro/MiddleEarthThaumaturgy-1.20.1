package dev.tc4port.thaumcraft.api.client;

/**
 * Render-thread scope covering setup, shader application, draw and cleanup.
 */
public final class RenderTypeBlendPlatform {

    private static boolean renderTypeOwnsBlend;

    private RenderTypeBlendPlatform() {
    }

    public static boolean enter(boolean enabled) {
        boolean previous = renderTypeOwnsBlend;
        renderTypeOwnsBlend = enabled;
        return previous;
    }

    public static void restore(boolean previous) {
        renderTypeOwnsBlend = previous;
    }

    public static boolean renderTypeOwnsBlend() {
        return renderTypeOwnsBlend;
    }
}
