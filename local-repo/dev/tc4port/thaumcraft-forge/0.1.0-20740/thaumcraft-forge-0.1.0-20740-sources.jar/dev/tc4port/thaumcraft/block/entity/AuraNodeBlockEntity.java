package dev.tc4port.thaumcraft.block.entity;

import dev.tc4port.thaumcraft.api.aspect.AspectAmounts;
import dev.tc4port.thaumcraft.api.aspect.AspectApi;
import dev.tc4port.thaumcraft.api.aspect.AspectId;
import dev.tc4port.thaumcraft.api.aspect.AspectQueryApi;
import dev.tc4port.thaumcraft.api.aspect.VisAction;
import dev.tc4port.thaumcraft.api.aspect.VisChannel;
import dev.tc4port.thaumcraft.api.aspect.VisCost;
import dev.tc4port.thaumcraft.api.node.AuraNodeState;
import dev.tc4port.thaumcraft.api.node.AuraNodeView;
import dev.tc4port.thaumcraft.api.node.NodeModifierId;
import dev.tc4port.thaumcraft.api.node.NodeModifierDefinition;
import dev.tc4port.thaumcraft.api.node.NodeTypeDefinition;
import dev.tc4port.thaumcraft.api.node.NodeTypeId;
import dev.tc4port.thaumcraft.api.node.NodeVis;
import dev.tc4port.thaumcraft.api.wand.WandApi;
import dev.tc4port.thaumcraft.aspect.AspectCatalog;
import dev.tc4port.thaumcraft.api.aspect.AspectList;
import dev.tc4port.thaumcraft.block.NodeStabilizerBlock;
import dev.tc4port.thaumcraft.block.AuraNodeBlock;
import dev.tc4port.thaumcraft.block.TaintSpreadLogic;
import dev.tc4port.thaumcraft.common.NodeEcologyCatalog;
import dev.tc4port.thaumcraft.common.NodeEcologyRules;
import dev.tc4port.thaumcraft.common.PlayerKnowledgeService;
import dev.tc4port.thaumcraft.common.SpawnPlacementRules;
import dev.tc4port.thaumcraft.common.WandVis;
import dev.tc4port.thaumcraft.data.WandData;
import dev.tc4port.thaumcraft.api.entity.AspectOrbApi;
import dev.tc4port.thaumcraft.entity.GiantBrainyZombieEntity;
import dev.tc4port.thaumcraft.item.EldritchCompassItem;
import dev.tc4port.thaumcraft.network.NodeBoltPayload;
import dev.tc4port.thaumcraft.registry.TCBlockEntities;
import dev.tc4port.thaumcraft.registry.TCBlocks;
import dev.tc4port.thaumcraft.state.TCItemState;
import dev.tc4port.thaumcraft.registry.TCEntities;
import dev.tc4port.thaumcraft.worldgen.TCBiomes;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.IdentityHashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import javax.annotation.Nullable;
import net.minecraft.core.BlockPos;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.StringTag;
import net.minecraft.nbt.Tag;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.LevelEvent;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import java.lang.System;
import java.lang.Math;
import java.lang.Float;
import dev.tc4port.thaumcraft.nativeimpl.state.ItemFields;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityType;

/**
 * Persistent server-authoritative state for a TC4 aura node.
 */
public final class AuraNodeBlockEntity extends net.minecraft.world.level.block.entity.BlockEntity implements AuraNodeView, dev.tc4port.thaumcraft.api.node.VisSource, ItemFields.Source {

    private boolean chunkUnloaded;

    private static final String NODE_ID = "node_id";

    private static final String NODE_TYPE = "node_type";

    private static final String NODE_MODIFIER = "node_modifier";

    private static final String BASE_ASPECTS = "base_aspects";

    private static final String CURRENT_ASPECTS = "current_aspects";

    private static final String ENERGIZED_BASE = "energized_base";

    private static final String ENERGIZED_SIGNATURE = "energized_signature";

    private static final String SIGNATURE_TYPE = "type";

    private static final String SIGNATURE_VOLATILE = "volatile";

    private static final String SIGNATURE_MODIFIER = "modifier";

    private static final String SIGNATURE_MULTIPLIER = "multiplier";

    private static final String SIGNATURE_BASE = "base";

    private static final String DRAIN_PLAYER = "drain_player";

    private static final String DRAIN_ASPECT = "drain_aspect";

    private static final String DRAIN_UNTIL = "drain_until";

    private static final String LAST_ACTIVE = "lastActive";

    private static final String STRUCTURE_CHECK_PENDING = "structure_check_pending";

    private static final String ASPECT_ORDER = "_order";

    private static final Set<AuraNodeBlockEntity> CLIENT_LOADED_NODES = Collections.newSetFromMap(new IdentityHashMap<>());

    private static Level trackedClientLevel;

    private AuraNodeState nodeState = AuraNodeState.EMPTY;

    private Map<AspectId, Integer> energizedBase = Map.of();

    private Map<AspectId, Integer> availableVis = Map.of();

    private EnergizedSignature energizedSignature;

    /**
     * Node state the current signature was derived from, compared by identity.
     */
    @Nullable
    private AuraNodeState signatureSource;

    private long validatedNodeGeneration = Long.MIN_VALUE;

    private long validatedAspectGeneration = Long.MIN_VALUE;

    private Optional<UUID> drainPlayerId = Optional.empty();

    private AspectId drainAspect;

    private long drainUntil = Long.MIN_VALUE;

    private int ticks;

    private int rechargeDelay;

    private long lastActive;

    private boolean catchUp;

    private boolean structureCheckPending;

    public AuraNodeBlockEntity(BlockPos pos, BlockState blockState) {
        super(TCBlockEntities.AURA_NODE.get(), pos, blockState);
    }

    /**
     * Loaded-client registry for the revealing renderer. Collecting nodes from
     * the ordinary BER callback is insufficient because section occlusion can
     * skip that callback when a node is completely behind terrain.
     */
    public static List<AuraNodeBlockEntity> clientLoadedNodes(Level level) {
        if (level == null || !level.isClientSide) {
            return List.of();
        }
        if (trackedClientLevel != level) {
            CLIENT_LOADED_NODES.clear();
            trackedClientLevel = level;
        }
        CLIENT_LOADED_NODES.removeIf(node -> node.isRemoved() || node.getLevel() != level);
        return List.copyOf(CLIENT_LOADED_NODES);
    }

    public static void clearClientLoadedNodes() {
        CLIENT_LOADED_NODES.clear();
        trackedClientLevel = null;
    }

    @Override
    public void onLoad() {
        super.onLoad();
        this.chunkUnloaded = false;
        if (this.level != null && this.level.isClientSide) {
            if (trackedClientLevel != this.level) {
                CLIENT_LOADED_NODES.clear();
                trackedClientLevel = this.level;
            }
            CLIENT_LOADED_NODES.add(this);
        }
    }

    @Override
    public void onChunkUnloaded() {
        this.chunkUnloaded = true;
        if (this.level instanceof ServerLevel serverLevel) {
            dev.tc4port.thaumcraft.common.VisNetwork.unloadSource(serverLevel, this.worldPosition);
        }
        super.onChunkUnloaded();
    }

    @Override
    public void setRemoved() {
        if (CLIENT_LOADED_NODES.remove(this) && CLIENT_LOADED_NODES.isEmpty()) {
            trackedClientLevel = null;
        }
        if (!this.chunkUnloaded && this.level instanceof ServerLevel serverLevel && this.getBlockState().is(TCBlocks.ENERGIZED_AURA_NODE.get())) {
            dev.tc4port.thaumcraft.common.VisNetwork.removeSource(serverLevel, this.worldPosition);
        }
        super.setRemoved();
    }

    @Override
    public AuraNodeState nodeState() {
        return this.nodeState;
    }

    public void setNodeState(AuraNodeState nodeState) {
        this.nodeState = nodeState == null ? AuraNodeState.EMPTY : nodeState;
        this.energizedBase = Map.of();
        this.availableVis = Map.of();
        this.energizedSignature = null;
        this.validatedNodeGeneration = Long.MIN_VALUE;
        this.validatedAspectGeneration = Long.MIN_VALUE;
        this.setChanged();
        if (this.level != null) {
            this.level.sendBlockUpdated(this.worldPosition, this.getBlockState(), this.getBlockState(), 3);
        }
    }

    public Optional<UUID> drainPlayerId() {
        return this.drainPlayerId;
    }

    public AspectId drainAspect() {
        return this.drainAspect;
    }

    public boolean hasActiveDrain(long gameTime) {
        return this.drainPlayerId.isPresent() && this.drainAspect != null && gameTime <= this.drainUntil;
    }

    /**
     * TileNode checked the unpowered metadata-9/10 stabilizer directly below
     * it every fifty ticks. Registry-separated blocks let us derive the same
     * lock without persisting stale metadata.
     */
    public int lockStrength() {
        if (this.level == null || !this.getBlockState().is(TCBlocks.AURA_NODE.get())) {
            return 0;
        }
        BlockPos stabilizerPos = this.worldPosition.below();
        if (!this.level.hasChunksAt(stabilizerPos.offset(-2, 0, -2), stabilizerPos.offset(2, 0, 2)) || this.level.hasNeighborSignal(stabilizerPos)) {
            return 0;
        }
        return this.level.getBlockState(stabilizerPos).getBlock() instanceof NodeStabilizerBlock stabilizer ? stabilizer.lockStrength() : 0;
    }

    public int rechargeInterval() {
        int interval = NodeEcologyCatalog.rechargeInterval(this.nodeState().modifier());
        return switch(this.lockStrength()) {
            case 1 ->
                interval * 2;
            case 2 ->
                interval * 20;
            default ->
                interval;
        };
    }

    @Override
    public void load(CompoundTag tag) {
        super.load(tag);
        this.availableVis = Map.of();
        this.validatedNodeGeneration = Long.MIN_VALUE;
        this.validatedAspectGeneration = Long.MIN_VALUE;
        Optional<UUID> id = tag.hasUUID(NODE_ID) ? Optional.of(tag.getUUID(NODE_ID)) : Optional.empty();
        String type = safeNodeType(tag.contains(NODE_TYPE) ? tag.getString(NODE_TYPE) : "normal");
        String modifier = safeNodeModifier(tag.contains(NODE_MODIFIER) ? tag.getString(NODE_MODIFIER) : "none");
        this.nodeState = new AuraNodeState(id, NodeTypeId.parse(type), NodeModifierId.parse(modifier), new NodeVis(readAspectMap(tag.getCompound(BASE_ASPECTS))), new NodeVis(readAspectMap(tag.getCompound(CURRENT_ASPECTS))));
        this.energizedBase = readAspectMap(tag.getCompound(ENERGIZED_BASE));
        this.energizedSignature = tag.contains(ENERGIZED_SIGNATURE, Tag.TAG_COMPOUND) ? readEnergizedSignature(tag.getCompound(ENERGIZED_SIGNATURE)) : null;
        this.drainPlayerId = tag.hasUUID(DRAIN_PLAYER) ? Optional.of(tag.getUUID(DRAIN_PLAYER)) : Optional.empty();
        this.drainAspect = storedAspect(tag.getString(DRAIN_ASPECT));
        this.drainUntil = tag.getLong(DRAIN_UNTIL);
        this.lastActive = tag.getLong(LAST_ACTIVE);
        this.structureCheckPending = tag.getBoolean(STRUCTURE_CHECK_PENDING);
        int unloadedInterval = NodeEcologyCatalog.rechargeInterval(this.nodeState().modifier());
        long now = System.currentTimeMillis();
        long increment = unloadedInterval * 75L;
        this.catchUp = increment > 0 && this.lastActive > 0 && now > this.lastActive + increment;
    }

    @Override
    protected void saveAdditional(CompoundTag tag) {
        super.saveAdditional(tag);
        this.nodeState.instanceId().ifPresent(id -> tag.putUUID(NODE_ID, id));
        tag.putString(NODE_TYPE, this.nodeState().type().toString());
        tag.putString(NODE_MODIFIER, this.nodeState().modifier().toString());
        tag.put(BASE_ASPECTS, writeAspectMap(this.nodeState.baseVis().amounts()));
        tag.put(CURRENT_ASPECTS, writeAspectMap(this.nodeState.currentVis().amounts()));
        tag.put(ENERGIZED_BASE, writeAspectMap(this.energizedBase));
        tag.put(ENERGIZED_SIGNATURE, writeEnergizedSignature(this.energizedSignature == null ? this.currentEnergizedSignature() : this.energizedSignature));
        this.drainPlayerId.ifPresent(id -> tag.putUUID(DRAIN_PLAYER, id));
        if (this.drainAspect != null) {
            tag.putString(DRAIN_ASPECT, this.drainAspect.serialized());
        }
        tag.putLong(DRAIN_UNTIL, this.drainUntil);
        tag.putLong(LAST_ACTIVE, this.lastActive);
        tag.putBoolean(STRUCTURE_CHECK_PENDING, this.structureCheckPending);
    }

    @Override
    public CompoundTag getUpdateTag() {
        return this.saveWithoutMetadata();
    }

    @Override
    public Packet<ClientGamePacketListener> getUpdatePacket() {
        return ClientboundBlockEntityDataPacket.create(this);
    }

    /**
     * TileNodeEnergized copied {@code visBase} into a transient {@code vis}
     * list every tick. Consequently a source replenishes its per-tick output,
     * but multiple drains in the same tick share the same finite pool.
     */
    public int drainEnergizedVis(dev.tc4port.thaumcraft.api.aspect.VisChannel aspect, int requested) {
        return this.drainEnergizedVis(aspect, requested, VisAction.EXECUTE);
    }

    public int drainEnergizedVis(dev.tc4port.thaumcraft.api.aspect.VisChannel aspect, int requested, VisAction action) {
        if (this.level == null || !this.getBlockState().is(TCBlocks.ENERGIZED_AURA_NODE.get()) || requested <= 0) {
            return 0;
        }
        if (this.energizedBase.isEmpty()) {
            return 0;
        }
        if (this.validatedNodeGeneration != NodeEcologyCatalog.apiView().generation() || this.validatedAspectGeneration != AspectApi.registry().generation()) {
            return 0;
        }
        AspectId aspectId = aspect.aspectId();
        int available = this.availableVis.getOrDefault(aspectId, 0);
        int drained = Math.min(available, requested);
        if (drained > 0 && action == VisAction.EXECUTE) {
            HashMap<AspectId, Integer> changed = new HashMap<>(this.availableVis);
            changed.put(aspectId, available - drained);
            this.availableVis = changed;
        }
        return drained;
    }

    @Override
    public boolean canSupplyVis() {
        return !isRemoved() && level instanceof ServerLevel && getBlockState().is(TCBlocks.ENERGIZED_AURA_NODE.get());
    }

    @Override
    public BlockPos networkEndpoint() {
        return worldPosition;
    }

    @Override
    public int takeVis(VisChannel channel, int amount, VisAction action, int reservedCentivis) {
        if (!canSupplyVis() || !((ServerLevel) level).getServer().isSameThread() || channel == null || action == null || amount <= 0 || reservedCentivis < 0)
            return 0;
        int reserved = action == VisAction.SIMULATE ? reservedCentivis : 0;
        return Math.max(0, drainEnergizedVis(channel, (int) Math.min(Integer.MAX_VALUE, (long) amount + reserved), action) - reserved);
    }

    public Map<AspectId, Integer> energizedBase() {
        if (this.energizedBase.isEmpty()) {
            EnergizedSignature signature = this.currentEnergizedSignature();
            this.energizedBase = calculateEnergizedBase(signature.baseAspects());
            this.energizedSignature = signature;
            this.availableVis = Map.of();
            this.setChanged();
            if (this.level instanceof ServerLevel serverLevel) {
                serverLevel.sendBlockUpdated(this.worldPosition, this.getBlockState(), this.getBlockState(), 3);
            }
        }
        return orderedCopy(this.energizedBase);
    }

    /**
     * Mirrors IAspectContainer#getAspects across the two legacy tile types:
     * ordinary nodes expose their live store, while energized nodes expose
     * their derived, sqrt-scaled output rather than the drained ordinary store.
     */
    public Map<AspectId, Integer> observableAspects() {
        return this.getBlockState().is(TCBlocks.ENERGIZED_AURA_NODE.get()) ? orderedCopy(this.energizedBase) : orderedCopy(this.nodeState.currentVis().amounts());
    }

    @Override
    public AspectAmounts inspectionAspects() {
        return new AspectAmounts(this.observableAspects());
    }

    @Override
    public AspectAmounts visibleAspects() {
        return this.inspectionAspects();
    }

    @Override
    public List<dev.tc4port.thaumcraft.api.aspect.AspectId> visibleAspectOrder() {
        if (this.getBlockState().is(TCBlocks.ENERGIZED_AURA_NODE.get())) {
            return List.copyOf(this.inspectionAspects().amounts().keySet());
        }
        return List.copyOf(this.nodeState().currentVis().amounts().keySet());
    }

    /**
     * Free nodes, silverwood knots and charged obsidian totems all hosted
     * TileNode's wand interaction. Only energized nodes lack direct tapping.
     */
    public boolean canTapIntoWand() {
        return !this.getBlockState().is(TCBlocks.ENERGIZED_AURA_NODE.get());
    }

    /**
     * TC4 draws one random compatible primal every five use ticks. Amounts in
     * AuraNodeState are whole vis while WandData stores centivis.
     */
    public boolean tapIntoWand(ServerPlayer player, ItemStack wand) {
        /*
         * TileNode implemented IWandable; TileNodeEnergized did not. The
         * modern port shares one block-entity class, so preserve that type
         * boundary explicitly instead of draining the ordinary-node store.
         */
        if (!this.canTapIntoWand()) {
            return false;
        }
        WandData wandData = (switch(0) {
            default ->
                {
                    dev.tc4port.thaumcraft.api.data.ItemStateKey<dev.tc4port.thaumcraft.data.WandData> native$receiver$536 = TCItemState.WAND;
                    net.minecraft.world.item.ItemStack native$argument$537 = wand;
                    dev.tc4port.thaumcraft.data.WandData native$argument$538 = WandData.DEFAULT;
                    java.util.Objects.requireNonNull(native$receiver$536);
                    yield dev.tc4port.thaumcraft.api.item.ItemStatePlatform.getOrDefault(native$argument$537, native$receiver$536, native$argument$538);
                }
        });
        int tap = 1;
        if (PlayerKnowledgeService.get(player).hasCompletedResearch(dev.tc4port.thaumcraft.api.research.ResearchKey.parse("NODETAPPER1"))) {
            tap++;
        }
        if (PlayerKnowledgeService.get(player).hasCompletedResearch(dev.tc4port.thaumcraft.api.research.ResearchKey.parse("NODETAPPER2"))) {
            tap++;
        }
        boolean preserve = !player.isShiftKeyDown() && PlayerKnowledgeService.get(player).hasCompletedResearch(dev.tc4port.thaumcraft.api.research.ResearchKey.parse("NODEPRESERVE")) && !wandData.rod().equals(dev.tc4port.thaumcraft.api.wand.WandMaterialId.WOOD) && !wandData.cap().equals(dev.tc4port.thaumcraft.api.wand.WandMaterialId.IRON);
        List<dev.tc4port.thaumcraft.api.aspect.VisChannel> eligible = new ArrayList<>();
        int capacity = WandVis.maxVis(wand);
        for (dev.tc4port.thaumcraft.api.aspect.VisChannel aspect : dev.tc4port.thaumcraft.api.aspect.VisChannel.values()) {
            int nodeAmount = this.nodeState.currentVis().amount(aspect.aspectId());
            if (nodeAmount > (preserve ? 1 : 0) && wandData.vis(aspect) < capacity) {
                eligible.add(aspect);
            }
        }
        if (eligible.isEmpty()) {
            return false;
        }
        dev.tc4port.thaumcraft.api.aspect.VisChannel aspect = eligible.get(player.getRandom().nextInt(eligible.size()));
        int available = this.nodeState.currentVis().amount(aspect.aspectId());
        int amount = Math.min(tap, available);
        if (preserve && amount == available) {
            amount--;
        }
        if (amount <= 0) {
            return false;
        }
        int addedCentivis = WandApi.insert(player, wand, VisCost.ofCentivis(aspect, amount * 100), VisAction.EXECUTE).transferred(aspect);
        if (addedCentivis <= 0) {
            return false;
        }
        int drained = Math.min(amount, Math.max(1, (addedCentivis + 99) / 100));
        LinkedHashMap<AspectId, Integer> current = new LinkedHashMap<>(this.nodeState.currentVis().amounts());
        current.put(aspect.aspectId(), Math.max(0, available - drained));
        this.drainPlayerId = Optional.of(player.getUUID());
        this.drainAspect = aspect.aspectId();
        /*
         * A successful pull is refreshed every five use ticks. A small grace
         * window masks packet jitter without leaving a beam after release.
         */
        this.drainUntil = player.level().getGameTime() + 7L;
        this.setNodeState(this.nodeState.withCurrentVis(new NodeVis(current)));
        return true;
    }

    /**
     * Keep a missed safety check across ticks and saves.
     */
    public void deferEnergizedStructureCheck() {
        if (!this.structureCheckPending && this.getBlockState().is(TCBlocks.ENERGIZED_AURA_NODE.get())) {
            this.structureCheckPending = true;
            this.setChanged();
        }
    }

    /**
     * Core recharge portion of TileNode#handleRecharge. Special node hazards
     * remain separate, but a tapped node is once again a renewable vis source.
     */
    public static void serverTick(Level level, BlockPos pos, BlockState state, AuraNodeBlockEntity node) {
        if (!(level instanceof ServerLevel serverLevel)) {
            return;
        }
        if (!level.hasChunksAt(pos.offset(-2, 0, -2), pos.offset(2, 0, 2))) {
            node.deferEnergizedStructureCheck();
            return;
        }
        if (node.structureCheckPending) {
            node.structureCheckPending = false;
            node.setChanged();
            if (state.is(TCBlocks.ENERGIZED_AURA_NODE.get())) {
                AuraNodeBlock.checkEnergizedStructure(serverLevel, pos);
                if (node.isRemoved() || !level.getBlockState(pos).is(TCBlocks.ENERGIZED_AURA_NODE.get())) {
                    return;
                }
            }
        }
        node.ensureIdentity(serverLevel, pos, state);
        if (state.is(TCBlocks.ENERGIZED_AURA_NODE.get())) {
            dev.tc4port.thaumcraft.common.VisNetwork.registerSource(serverLevel, pos);
        }
        if (!state.is(TCBlocks.ENERGIZED_AURA_NODE.get())) {
            if (dev.tc4port.thaumcraft.common.TCServerConfig.hardNode()) {
                node.handleHungryEntities(serverLevel);
            }
        }
        node.ticks++;
        if (state.is(TCBlocks.ENERGIZED_AURA_NODE.get())) {
            boolean changed = node.ensureEnergizedOrdinaryStoreEmpty();
            long nodeGeneration = NodeEcologyCatalog.apiView().generation();
            long aspectGeneration = AspectApi.registry().generation();
            // Reducing base vis to primals walks the aspect registry, so only
            // redo it when the state or either catalog actually changed.
            EnergizedSignature signature = node.energizedSignature != null && node.signatureSource == node.nodeState() && node.validatedNodeGeneration == nodeGeneration && node.validatedAspectGeneration == aspectGeneration ? node.energizedSignature : node.currentEnergizedSignature();
            node.signatureSource = node.nodeState();
            if (!signature.equals(node.energizedSignature)) {
                node.energizedSignature = signature;
                node.energizedBase = Map.of();
                node.availableVis = Map.of();
                changed = true;
            }
            /*
             * TileNodeEnergized exposes a replenished per-tick vis pool
             * instead of running TileNode's slow recharge. Unstable
             * energized nodes rerolled their sqrt-based output with a
             * 1-in-500 chance.
             */
            NodeTypeDefinition typeDefinition = NodeEcologyCatalog.type(node.nodeState().type());
            if (node.energizedBase.isEmpty() || typeDefinition != null && typeDefinition.volatileOutput() && serverLevel.random.nextInt(500) == 1) {
                node.energizedBase = node.calculateEnergizedBase(signature.baseAspects());
                node.availableVis = Map.of();
                changed = true;
            }
            if (changed) {
                node.setChanged();
                serverLevel.sendBlockUpdated(pos, state, state, 3);
            }
            // Draining copies on write, so the pool can share the base map.
            node.availableVis = node.energizedBase;
            node.validatedNodeGeneration = nodeGeneration;
            node.validatedAspectGeneration = aspectGeneration;
            return;
        }
        node.handleDischarge(serverLevel);
        node.handleOfflineCatchUp(serverLevel);
        if (node.handleAspectDecay(serverLevel)) {
            return;
        }
        if (node.rechargeDelay > 0) {
            node.rechargeDelay--;
        }
        int interval = node.rechargeInterval();
        if (interval > 0 && node.rechargeDelay == 0 && node.ticks % interval == 0) {
            node.lastActive = System.currentTimeMillis();
            List<AspectId> depleted = node.nodeState.currentVis().amounts().entrySet().stream().filter(entry -> entry.getValue() < node.nodeState.baseVis().amounts().getOrDefault(entry.getKey(), 0)).map(Map.Entry::getKey).toList();
            if (!depleted.isEmpty() && total(node.nodeState.currentVis().amounts()) < Integer.MAX_VALUE) {
                AspectId aspect = depleted.get(serverLevel.random.nextInt(depleted.size()));
                LinkedHashMap<AspectId, Integer> current = new LinkedHashMap<>(node.nodeState.currentVis().amounts());
                current.merge(aspect, 1, Integer::sum);
                node.setNodeState(node.nodeState.withCurrentVis(new NodeVis(current)));
            }
        }
        node.handleTaintNode(serverLevel);
        node.handleStabilizedRecovery(serverLevel);
        node.handleDarkNode(serverLevel);
        node.handlePureNode(serverLevel);
        node.handleHungryBlock(serverLevel);
    }

    private void handleOfflineCatchUp(ServerLevel level) {
        if (!this.catchUp) {
            return;
        }
        this.catchUp = false;
        int interval = this.rechargeInterval();
        long increment = interval * 75L;
        int amount = increment > 0 ? (int) Math.min(Integer.MAX_VALUE, (System.currentTimeMillis() - this.lastActive) / increment) : 0;
        int limit = Math.min(amount, total(this.nodeState.baseVis().amounts()));
        LinkedHashMap<AspectId, Integer> current = new LinkedHashMap<>(this.nodeState.currentVis().amounts());
        int currentTotal = total(current);
        for (int index = 0; index < limit; index++) {
            List<AspectId> depleted = current.entrySet().stream().filter(entry -> entry.getValue() < this.nodeState.baseVis().amounts().getOrDefault(entry.getKey(), 0)).map(Map.Entry::getKey).toList();
            if (depleted.isEmpty() || currentTotal == Integer.MAX_VALUE) {
                break;
            }
            AspectId aspect = depleted.get(level.random.nextInt(depleted.size()));
            current.merge(aspect, 1, Integer::sum);
            currentTotal++;
        }
        if (!current.equals(this.nodeState.currentVis().amounts())) {
            this.setNodeState(this.nodeState.withCurrentVis(new NodeVis(current)));
        }
    }

    /**
     * Energized nodes expose only their derived per-tick network pool. Other
     * current node mutations can still target the owner, so enforce the empty
     * ordinary store before any energized output is published.
     */
    private boolean ensureEnergizedOrdinaryStoreEmpty() {
        LinkedHashMap<AspectId, Integer> empty = new LinkedHashMap<>();
        this.nodeState.baseVis().amounts().keySet().forEach(aspect -> empty.put(aspect, 0));
        if (this.nodeState.currentVis().amounts().equals(empty)) {
            return false;
        }
        this.nodeState = this.nodeState.withCurrentVis(new NodeVis(empty));
        return true;
    }

    /**
     * Commands and structures may create a node without the UUID normally
     * assigned by placement or world generation. A node's
     * scan record is tied to that UUID, so repair the identity without
     * changing its type, modifier, aspects or energized state.
     */
    private void ensureIdentity(ServerLevel level, BlockPos pos, BlockState state) {
        if (this.nodeState.instanceId().isPresent()) {
            return;
        }
        this.nodeState = this.nodeState.withInstanceId(Optional.of(UUID.randomUUID()));
        this.setChanged();
        level.sendBlockUpdated(pos, state, state, 3);
    }

    public static void clientTick(Level level, BlockPos pos, BlockState state, AuraNodeBlockEntity node) {
        node.ticks++;
        if (!state.is(TCBlocks.ENERGIZED_AURA_NODE.get()) && node.nodeState().type().equals(NodeTypeId.DARK) && node.ticks % 50 == 0) {
            EldritchCompassItem.observeSinisterNode(level, pos);
        }
        if (!state.is(TCBlocks.ENERGIZED_AURA_NODE.get()) && node.nodeState().type().equals(NodeTypeId.HUNGRY)) {
            dev.tc4port.thaumcraft.client.HungryNodeClientEffect.tick(level, pos);
        }
    }

    /**
     * The hard-node half of TileNode#handleHungryNodeFirst. TC4 compared the
     * squared center distance with two (a radius of sqrt(2)), then used the
     * out-of-world damage source so armor and ordinary resistance could not
     * trivialize the hazard.
     */
    private double behaviorNumber(String name, double fallback) {
        var definition = NodeEcologyCatalog.type(this.nodeState().type());
        return definition == null ? fallback : definition.number(name, fallback);
    }

    private int behaviorInteger(String name, int fallback) {
        return (int) behaviorNumber(name, fallback);
    }

    private void handleHungryEntities(ServerLevel level) {
        if (!this.nodeState().type().equals(NodeTypeId.HUNGRY)) {
            return;
        }
        Vec3 center = Vec3.atCenterOf(this.worldPosition);
        AABB range = new AABB(this.worldPosition).inflate(behaviorNumber("hungry_range", 15));
        for (Entity entity : level.getEntities((Entity) null, range, entity -> entity != null && !(entity instanceof Player player && player.getAbilities().invulnerable))) {
            if (entity.isAlive() && !entity.isInvulnerable() && entity.distanceToSqr(center) < behaviorNumber("hungry_damage_distance_squared", 2)) {
                entity.hurt(level.damageSources().fellOutOfWorld(), (float) behaviorNumber("hungry_damage", 1));
                if (!entity.isAlive()) {
                    this.absorbKilledEntity(level, entity);
                }
            }
            double pullX = (center.x - entity.getX()) / behaviorNumber("hungry_range", 15);
            double pullY = (center.y - entity.getY()) / behaviorNumber("hungry_range", 15);
            double pullZ = (center.z - entity.getZ()) / behaviorNumber("hungry_range", 15);
            double normalizedDistance = Math.sqrt(pullX * pullX + pullY * pullY + pullZ * pullZ);
            double strength = 1.0 - normalizedDistance;
            // Loaded entities can be queried while their movement ticks are suspended.
            if (strength > 0.0 && normalizedDistance > 1.0E-7 && level.isPositionEntityTicking(entity.blockPosition())) {
                strength *= strength;
                entity.push(pullX / normalizedDistance * strength * behaviorNumber("hungry_horizontal_pull", .15), pullY / normalizedDistance * strength * behaviorNumber("hungry_vertical_pull", .25), pullZ / normalizedDistance * strength * behaviorNumber("hungry_horizontal_pull", .15));
                /*
                 * TileNode applied this force in both the client and server
                 * worlds. The modern implementation is server-authoritative,
                 * so a ServerPlayer also needs the vanilla owner-motion sync;
                 * hasImpulse alone only updates observers.
                 */
                if (entity instanceof ServerPlayer) {
                    entity.hurtMarked = true;
                }
            }
        }
    }

    private void absorbKilledEntity(ServerLevel level, Entity entity) {
        AspectQueryApi.Consumption consumption = AspectQueryApi.consumption(entity);
        Map<AspectId, Integer> scanned = consumption.perUnit().amounts();
        if (scanned.isEmpty()) {
            return;
        }
        AspectList primals = AspectCatalog.reduceToPrimals(new AspectList(scanned), false);
        List<AspectId> primalAspects = primals.aspects();
        if (primalAspects.isEmpty()) {
            return;
        }
        LinkedHashMap<AspectId, Integer> current = new LinkedHashMap<>(this.nodeState.currentVis().amounts());
        LinkedHashMap<AspectId, Integer> base = new LinkedHashMap<>(this.nodeState.baseVis().amounts());
        int currentTotal = total(current);
        int baseTotal = total(base);
        boolean changed = false;
        for (int unit = 0; unit < consumption.units(); unit++) {
            AspectId aspect = primalAspects.get(level.random.nextInt(primalAspects.size()));
            int baseAmount = base.getOrDefault(aspect, 0);
            if (current.getOrDefault(aspect, 0) < baseAmount) {
                if (currentTotal < Integer.MAX_VALUE) {
                    current.merge(aspect, 1, Integer::sum);
                    currentTotal++;
                    changed = true;
                }
            } else if (baseTotal < Integer.MAX_VALUE && growthRoll(level.random, 1L + baseAmount * 2L) < primals.amount(aspect)) {
                base.merge(aspect, 1, Integer::sum);
                baseTotal++;
                changed = true;
            }
        }
        if (!changed) {
            return;
        }
        this.setNodeState(this.nodeState.withVis(new NodeVis(base), new NodeVis(current)));
    }

    private void handleTaintNode(ServerLevel level) {
        if (this.nodeState().type().equals(NodeTypeId.TAINTED) && this.ticks % 50 == 0) {
            BlockPos biomeTarget = this.worldPosition.offset(level.random.nextInt(8) - level.random.nextInt(8), 0, level.random.nextInt(8) - level.random.nextInt(8));
            if (!TaintSpreadLogic.isTaintedAt(level, biomeTarget)) {
                TaintSpreadLogic.setTaintedBiomeColumn(level, biomeTarget);
            }
            if (dev.tc4port.thaumcraft.common.TCServerConfig.hardNode() && level.random.nextBoolean()) {
                BlockPos fibreTarget = this.worldPosition.offset(level.random.nextInt(5) - level.random.nextInt(5), level.random.nextInt(5) - level.random.nextInt(5), level.random.nextInt(5) - level.random.nextInt(5));
                TaintSpreadLogic.spreadFibres(level, fibreTarget, level.random);
            }
            return;
        }
        if (!this.nodeState().type().equals(NodeTypeId.PURE) && !this.nodeState().type().equals(NodeTypeId.TAINTED) && this.ticks % 100 == 0 && TaintSpreadLogic.isTaintedAt(level, this.worldPosition) && level.random.nextInt(500) == 0) {
            this.setNodeType(NodeTypeId.TAINTED);
        }
    }

    private void handlePureNode(ServerLevel level) {
        if (!this.nodeState().type().equals(NodeTypeId.PURE) || this.ticks % 50 != 0 || !NodeEcologyRules.allowsDimension(level.dimension())) {
            return;
        }
        BlockPos target = this.worldPosition.offset(level.random.nextInt(8) - level.random.nextInt(8), 0, level.random.nextInt(8) - level.random.nextInt(8));
        if (isBiomeAt(level, target, TCBiomes.MAGICAL_FOREST)) {
            return;
        }
        if (!NodeEcologyRules.allowsBiome(level.getNoiseBiome(net.minecraft.core.QuartPos.fromBlock(target.getX()), net.minecraft.core.QuartPos.fromBlock(target.getY()), net.minecraft.core.QuartPos.fromBlock(target.getZ())))) {
            return;
        }
        if (TaintSpreadLogic.isTaintedAt(level, target) || this.getBlockState().is(TCBlocks.SILVERWOOD_NODE_LOG.get())) {
            TaintSpreadLogic.setSpecialBiomeColumn(level, target, TCBiomes.MAGICAL_FOREST);
        }
    }

    private void handleDarkNode(ServerLevel level) {
        if (!this.nodeState().type().equals(NodeTypeId.DARK) || this.ticks % 50 != 0 || !NodeEcologyRules.allowsDimension(level.dimension()) || !NodeEcologyRules.allowsBiome(level.getNoiseBiome(net.minecraft.core.QuartPos.fromBlock(this.worldPosition.getX()), net.minecraft.core.QuartPos.fromBlock(this.worldPosition.getY()), net.minecraft.core.QuartPos.fromBlock(this.worldPosition.getZ())))) {
            return;
        }
        BlockPos target = this.worldPosition.offset(level.random.nextInt(12) - level.random.nextInt(12), 0, level.random.nextInt(12) - level.random.nextInt(12));
        if (!isBiomeAt(level, target, TCBiomes.EERIE)) {
            TaintSpreadLogic.setSpecialBiomeColumn(level, target, TCBiomes.EERIE);
        }
        if (!dev.tc4port.thaumcraft.common.TCServerConfig.hardNode() || !level.random.nextBoolean() || level.getNearestPlayer(this.worldPosition.getX() + 0.5, this.worldPosition.getY() + 0.5, this.worldPosition.getZ() + 0.5, 24.0, false) == null) {
            return;
        }
        AABB populationRange = new AABB(this.worldPosition).inflate(10.0, 6.0, 10.0);
        if (level.getEntitiesOfClass(GiantBrainyZombieEntity.class, populationRange).size() > 3) {
            return;
        }
        GiantBrainyZombieEntity giant = TCEntities.GIANT_BRAINY_ZOMBIE.get().create(level);
        if (giant == null) {
            return;
        }
        giant.moveTo(this.worldPosition.getX() + (level.random.nextDouble() - level.random.nextDouble()) * 5.0, this.worldPosition.getY() + level.random.nextInt(3) - 1, this.worldPosition.getZ() + (level.random.nextDouble() - level.random.nextDouble()) * 5.0, level.random.nextFloat() * 360.0F, 0.0F);
        BlockPos spawnPos = BlockPos.containing(giant.position());
        if (!SpawnPlacementRules.isMonsterLightValid(level, spawnPos, level.random) || !SpawnPlacementRules.hasClearVolume(level, giant)) {
            return;
        }
        level.addFreshEntity(giant);
        level.levelEvent(LevelEvent.PARTICLES_MOBBLOCK_SPAWN, this.worldPosition, 0);
        giant.spawnAnim();
    }

    private void handleHungryBlock(ServerLevel level) {
        if (!this.nodeState().type().equals(NodeTypeId.HUNGRY) || this.ticks % 50 != 0) {
            return;
        }
        BlockHitResult hit = hungryNodeTrace(level);
        if (hit == null || hit.getType() != HitResult.Type.BLOCK || hit.getBlockPos().distSqr(this.worldPosition) >= 256.0) {
            return;
        }
        BlockState target = level.getBlockState(hit.getBlockPos());
        float hardness = target.getDestroySpeed(level, hit.getBlockPos());
        if (!target.isAir() && hardness >= 0.0F && hardness < 5.0F) {
            level.destroyBlock(hit.getBlockPos(), true);
        }
    }

    @Nullable
    private BlockHitResult hungryNodeTrace(Level level) {
        int targetX = this.worldPosition.getX() + level.random.nextInt(16) - level.random.nextInt(16);
        int targetY = this.worldPosition.getY() + level.random.nextInt(16) - level.random.nextInt(16);
        int targetZ = this.worldPosition.getZ() + level.random.nextInt(16) - level.random.nextInt(16);
        if (!level.hasChunksAt(Math.min(this.worldPosition.getX(), targetX), Math.min(this.worldPosition.getZ(), targetZ), Math.max(this.worldPosition.getX(), targetX), Math.max(this.worldPosition.getZ(), targetZ))) {
            return null;
        }
        int surface = level.getHeight(Heightmap.Types.WORLD_SURFACE, targetX, targetZ);
        targetY = Math.min(targetY, surface);
        return level.clip((switch(0) {
            default ->
                {
                    net.minecraft.world.phys.Vec3 native$operand$14121 = Vec3.atCenterOf(this.worldPosition);
                    net.minecraft.world.phys.Vec3 native$operand$14122 = new Vec3(targetX + 0.5, targetY + 0.5, targetZ + 0.5);
                    net.minecraft.world.level.ClipContext.Block native$operand$14123 = ClipContext.Block.COLLIDER;
                    net.minecraft.world.level.ClipContext.Fluid native$operand$14124 = ClipContext.Fluid.ANY;
                    net.minecraft.world.level.ClipContext native$result$14125 = (new net.minecraft.world.level.ClipContext(native$operand$14121, native$operand$14122, native$operand$14123, native$operand$14124, null));
                    yield native$result$14125;
                }
        }));
    }

    private void setNodeType(NodeTypeId type) {
        this.setNodeState(this.nodeState.withType(type));
    }

    private static boolean isBiomeAt(Level level, BlockPos pos, net.minecraft.resources.ResourceKey<net.minecraft.world.level.biome.Biome> biome) {
        return level.getNoiseBiome(net.minecraft.core.QuartPos.fromBlock(pos.getX()), net.minecraft.core.QuartPos.fromBlock(pos.getY()), net.minecraft.core.QuartPos.fromBlock(pos.getZ())).is(biome);
    }

    /**
     * TileNode#handleDischarge, including the unusual rule that a normal
     * stabilizer blocks outgoing discharge while an advanced stabilizer may
     * drain only completely unlocked neighboring nodes.
     */
    private void handleDischarge(ServerLevel level) {
        if (!this.getBlockState().is(TCBlocks.AURA_NODE.get()) || this.lockStrength() == 1 || NodeEcologyCatalog.rechargeInterval(this.nodeState().modifier()) == 0) {
            return;
        }
        boolean shiny = NodeEcologyCatalog.shiny(this.nodeState().type(), this.nodeState().modifier());
        // Defined: an undefined modifier has no recharge and returned above.
        NodeModifierDefinition modifierDefinition = NodeEcologyCatalog.modifier(this.nodeState().modifier());
        if (this.ticks % NodeEcologyCatalog.dischargeInterval(this.nodeState().type(), this.nodeState().modifier()) != 0 || modifierDefinition.halfDischargeChance() && level.random.nextBoolean()) {
            return;
        }
        int offsetX = level.random.nextInt(behaviorInteger("neighbor_offset_choices", 5)) - level.random.nextInt(behaviorInteger("neighbor_offset_choices", 5));
        int offsetY = level.random.nextInt(behaviorInteger("neighbor_offset_choices", 5)) - level.random.nextInt(behaviorInteger("neighbor_offset_choices", 5));
        int offsetZ = level.random.nextInt(behaviorInteger("neighbor_offset_choices", 5)) - level.random.nextInt(behaviorInteger("neighbor_offset_choices", 5));
        if (offsetX == 0 && offsetY == 0 && offsetZ == 0) {
            return;
        }
        BlockPos targetPos = this.worldPosition.offset(offsetX, offsetY, offsetZ);
        if (!level.hasChunksAt(targetPos.offset(-2, 0, -2), targetPos.offset(2, 0, 2)) || !level.getBlockState(targetPos).is(TCBlocks.AURA_NODE.get()) || !(level.getBlockEntity(targetPos) instanceof AuraNodeBlockEntity target) || target.lockStrength() > 0) {
            return;
        }
        int targetAverage = (int) (((long) total(currentAspects(target.nodeState)) + total(baseAspects(target.nodeState))) / 2L);
        int sourceAverage = (int) (((long) total(this.nodeState.currentVis().amounts()) + total(this.nodeState.baseVis().amounts())) / 2L);
        List<AspectId> targetAspects = currentAspects(target.nodeState).entrySet().stream().filter(entry -> entry.getValue() > 0).map(Map.Entry::getKey).toList();
        if (targetAverage >= sourceAverage || targetAspects.isEmpty()) {
            return;
        }
        AspectId aspect = targetAspects.get(level.random.nextInt(targetAspects.size()));
        LinkedHashMap<AspectId, Integer> targetCurrent = new LinkedHashMap<>(currentAspects(target.nodeState));
        targetCurrent.put(aspect, targetCurrent.get(aspect) - 1);
        LinkedHashMap<AspectId, Integer> targetBase = new LinkedHashMap<>(baseAspects(target.nodeState));
        LinkedHashMap<AspectId, Integer> sourceCurrent = new LinkedHashMap<>(this.nodeState.currentVis().amounts());
        LinkedHashMap<AspectId, Integer> sourceBase = new LinkedHashMap<>(this.nodeState.baseVis().amounts());
        NodeModifierId sourceModifier = this.nodeState().modifier();
        if (sourceCurrent.getOrDefault(aspect, 0) < sourceBase.getOrDefault(aspect, 0)) {
            if (total(sourceCurrent) < Integer.MAX_VALUE) {
                sourceCurrent.merge(aspect, 1, Integer::sum);
            }
        } else {
            long divisor = 1L + (int) (sourceBase.getOrDefault(aspect, 0) / (shiny ? (float) behaviorNumber("shiny_growth_divisor", 1.5) : 1.0F));
            if (total(sourceBase) < Integer.MAX_VALUE && growthRoll(level.random, Math.max(1L, divisor)) == 0) {
                sourceBase.merge(aspect, 1, Integer::sum);
                if (sourceModifier.equals(NodeModifierId.PALE) && level.random.nextInt(behaviorInteger("pale_recovery_denominator", 100)) == 0) {
                    sourceModifier = NodeModifierId.NONE;
                }
                if (level.random.nextInt(behaviorInteger("target_erosion_denominator", 3)) == 0) {
                    int reduced = targetBase.getOrDefault(aspect, 0) - 1;
                    if (reduced <= 0) {
                        targetBase.remove(aspect);
                    } else {
                        targetBase.put(aspect, reduced);
                    }
                }
            }
        }
        target.setNodeState(target.nodeState.withVis(new NodeVis(targetBase), new NodeVis(targetCurrent)));
        target.rechargeDelay = Math.max(0, target.rechargeInterval() / 2);
        this.setNodeState(this.nodeState.withState(this.nodeState().type(), sourceModifier, new NodeVis(sourceBase), new NodeVis(sourceCurrent)));
        Vec3 targetCenter = Vec3.atCenterOf(targetPos);
        Vec3 sourceCenter = Vec3.atCenterOf(this.worldPosition);
        NodeBoltPayload payload = new NodeBoltPayload(targetCenter, sourceCenter);
        for (ServerPlayer player : level.players()) {
            if (player.distanceToSqr(sourceCenter) <= 32.0 * 32.0) {
                dev.tc4port.thaumcraft.network.TCPayloads.CHANNEL.sendToPlayer(player, payload);
            }
        }
    }

    /**
     * The 1,200-tick zero-aspect erosion branch is distinct from ordinary
     * recharge: reduce leaves zero entries present, and only this branch may
     * delete one of them and eventually remove the node host.
     */
    private boolean handleAspectDecay(ServerLevel level) {
        if (this.ticks % behaviorInteger("aspect_decay_interval", 1200) != 0) {
            return false;
        }
        AspectId emptyAspect = this.nodeState.currentVis().amounts().entrySet().stream().filter(entry -> entry.getValue() <= 0).map(Map.Entry::getKey).findFirst().orElse(null);
        if (emptyAspect == null) {
            return false;
        }
        LinkedHashMap<AspectId, Integer> base = new LinkedHashMap<>(this.nodeState.baseVis().amounts());
        LinkedHashMap<AspectId, Integer> current = new LinkedHashMap<>(this.nodeState.currentVis().amounts());
        int reducedBase = base.getOrDefault(emptyAspect, 0) - 1;
        boolean removeAspect = level.random.nextInt(behaviorInteger("aspect_removal_denominator", 20)) == 0 || reducedBase <= 0;
        if (reducedBase <= 0) {
            base.remove(emptyAspect);
        } else {
            base.put(emptyAspect, reducedBase);
        }
        NodeModifierId modifier = this.nodeState().modifier();
        if (removeAspect) {
            current.remove(emptyAspect);
            if (level.random.nextInt(behaviorInteger("modifier_decay_denominator", 5)) == 0) {
                if (modifier.equals(NodeModifierId.BRIGHT)) {
                    modifier = NodeModifierId.NONE;
                } else if (modifier.equals(NodeModifierId.NONE)) {
                    modifier = NodeModifierId.PALE;
                }
                if (modifier.equals(NodeModifierId.PALE) && level.random.nextInt(behaviorInteger("fading_decay_denominator", 5)) == 0) {
                    modifier = NodeModifierId.FADING;
                }
            }
        }
        if (current.isEmpty()) {
            if (this.getBlockState().is(TCBlocks.AURA_NODE.get())) {
                level.removeBlock(this.worldPosition, false);
            } else if (this.getBlockState().is(TCBlocks.SILVERWOOD_NODE_LOG.get())) {
                net.minecraft.core.Direction.Axis axis = this.getBlockState().getValue(dev.tc4port.thaumcraft.block.AuraNodeLogBlock.AXIS);
                level.setBlock(this.worldPosition, TCBlocks.SILVERWOOD_LOG.get().defaultBlockState().setValue(net.minecraft.world.level.block.RotatedPillarBlock.AXIS, axis), 3);
            }
            return true;
        }
        this.setNodeState(this.nodeState.withState(this.nodeState().type(), modifier, new NodeVis(base), new NodeVis(current)));
        return false;
    }

    private void handleStabilizedRecovery(ServerLevel level) {
        if (this.ticks % 100 != 0) {
            return;
        }
        int lock = this.lockStrength();
        NodeTypeId type = this.nodeState().type();
        NodeModifierId modifier = this.nodeState().modifier();
        boolean changed = false;
        if (type.equals(NodeTypeId.UNSTABLE) && level.random.nextBoolean()) {
            if (lock == 0) {
                Set<AspectId> availablePrimals = AspectCatalog.primals().stream().filter(aspect -> this.nodeState.currentVis().amounts().getOrDefault(aspect, 0) > 0).collect(java.util.stream.Collectors.toSet());
                if (!availablePrimals.isEmpty()) {
                    AspectId leaked = AspectCatalog.randomKnown(availablePrimals, level.random);
                    LinkedHashMap<AspectId, Integer> current = new LinkedHashMap<>(this.nodeState.currentVis().amounts());
                    current.put(leaked, current.get(leaked) - 1);
                    this.setNodeState(this.nodeState.withState(type, modifier, this.nodeState.baseVis(), new NodeVis(current)));
                    AspectOrbApi.spawn(level, Vec3.atCenterOf(this.worldPosition), leaked, 1);
                }
            } else if (level.random.nextInt(10_000 / lock) == 42) {
                type = NodeTypeId.NORMAL;
                changed = true;
            }
        }
        if (lock > 0 && modifier.equals(NodeModifierId.FADING) && level.random.nextInt(12_500 / lock) == 69) {
            modifier = NodeModifierId.PALE;
            changed = true;
        }
        if (changed) {
            this.setNodeState(this.nodeState.withState(type, modifier, this.nodeState.baseVis(), this.nodeState.currentVis()));
        }
    }

    private Map<AspectId, Integer> calculateEnergizedBase() {
        return this.calculateEnergizedBase(this.reducedEnergizedInput());
    }

    private Map<AspectId, Integer> calculateEnergizedBase(Map<AspectId, Integer> reducedInput) {
        LinkedHashMap<AspectId, Integer> result = new LinkedHashMap<>();
        for (Map.Entry<AspectId, Integer> entry : reducedInput.entrySet()) {
            AspectId aspect = entry.getKey();
            double scaled = (double) entry.getValue() * NodeEcologyCatalog.energizedMultiplier(this.nodeState().modifier());
            int output = (int) Math.floor(Math.sqrt(scaled));
            NodeTypeDefinition typeDefinition = NodeEcologyCatalog.type(this.nodeState().type());
            if (typeDefinition != null && typeDefinition.volatileOutput() && this.level != null) {
                output += this.level.random.nextInt(5) - 2;
            }
            if (output >= 1) {
                result.merge(aspect, output, Math::max);
            }
        }
        return orderedCopy(result);
    }

    private EnergizedSignature currentEnergizedSignature() {
        NodeTypeDefinition type = NodeEcologyCatalog.type(this.nodeState().type());
        return new EnergizedSignature(this.nodeState().type().toString(), type != null && type.volatileOutput(), this.nodeState().modifier().toString(), Float.floatToIntBits(NodeEcologyCatalog.energizedMultiplier(this.nodeState().modifier())), this.reducedEnergizedInput());
    }

    private Map<AspectId, Integer> reducedEnergizedInput() {
        LinkedHashMap<AspectId, Long> expanded = new LinkedHashMap<>();
        this.nodeState().baseVis().amounts().forEach((id, amount) -> mergeMaximum(expanded, reducePrimalVis(id, amount.longValue())));
        LinkedHashMap<AspectId, Integer> reduced = new LinkedHashMap<>();
        for (Map.Entry<AspectId, Long> entry : expanded.entrySet()) {
            reduced.put(entry.getKey(), (int) Math.min(Integer.MAX_VALUE, entry.getValue()));
        }
        return orderedCopy(reduced);
    }

    private static Map<AspectId, Long> reducePrimalVis(AspectId id, long amount) {
        var definition = AspectApi.registry().get(id).orElse(null);
        if (definition == null) {
            return Map.of();
        }
        if (definition.primal()) {
            return Map.of(id, amount);
        }
        LinkedHashMap<AspectId, Long> componentAmounts = new LinkedHashMap<>();
        for (AspectId component : definition.components()) {
            componentAmounts.merge(component, amount, AuraNodeBlockEntity::saturatingAdd);
        }
        LinkedHashMap<AspectId, Long> reduced = new LinkedHashMap<>();
        componentAmounts.forEach((component, componentAmount) -> mergeMaximum(reduced, reducePrimalVis(component, componentAmount)));
        return reduced;
    }

    private static void mergeMaximum(Map<AspectId, Long> target, Map<AspectId, Long> source) {
        source.forEach((id, amount) -> target.merge(id, amount, Math::max));
    }

    private static long saturatingAdd(long first, long second) {
        if (Long.MAX_VALUE - first < second) {
            return Long.MAX_VALUE;
        }
        return first + second;
    }

    private record EnergizedSignature(String type, boolean volatileOutput, String modifier, int multiplierBits, Map<AspectId, Integer> baseAspects) {

        private EnergizedSignature {
            baseAspects = orderedCopy(baseAspects);
        }

        @Override
        public boolean equals(Object other) {
            if (this == other) {
                return true;
            }
            if (!(other instanceof EnergizedSignature signature)) {
                return false;
            }
            return this.volatileOutput == signature.volatileOutput && this.multiplierBits == signature.multiplierBits && this.type.equals(signature.type) && this.modifier.equals(signature.modifier) && List.copyOf(this.baseAspects.entrySet()).equals(List.copyOf(signature.baseAspects.entrySet()));
        }

        @Override
        public int hashCode() {
            int hash = java.util.Objects.hash(this.type, this.volatileOutput, this.modifier, this.multiplierBits);
            for (Map.Entry<AspectId, Integer> entry : this.baseAspects.entrySet()) {
                hash = 31 * hash + entry.hashCode();
            }
            return hash;
        }
    }

    private static <K, V> Map<K, V> orderedCopy(Map<K, V> values) {
        return Collections.unmodifiableMap(new LinkedHashMap<>(values));
    }

    private static EnergizedSignature readEnergizedSignature(CompoundTag tag) {
        return new EnergizedSignature(tag.getString(SIGNATURE_TYPE), tag.getBoolean(SIGNATURE_VOLATILE), tag.getString(SIGNATURE_MODIFIER), tag.getInt(SIGNATURE_MULTIPLIER), readAspectMap(tag.getCompound(SIGNATURE_BASE)));
    }

    private static CompoundTag writeEnergizedSignature(EnergizedSignature signature) {
        CompoundTag tag = new CompoundTag();
        tag.putString(SIGNATURE_TYPE, signature.type());
        tag.putBoolean(SIGNATURE_VOLATILE, signature.volatileOutput());
        tag.putString(SIGNATURE_MODIFIER, signature.modifier());
        tag.putInt(SIGNATURE_MULTIPLIER, signature.multiplierBits());
        tag.put(SIGNATURE_BASE, writeAspectMap(signature.baseAspects()));
        return tag;
    }

    private static Map<AspectId, Integer> readAspectMap(CompoundTag tag) {
        LinkedHashMap<AspectId, Integer> aspects = new LinkedHashMap<>();
        java.util.HashSet<String> consumedKeys = new java.util.HashSet<>();
        ListTag order = tag.getList(ASPECT_ORDER, Tag.TAG_STRING);
        for (int index = 0; index < order.size(); index++) {
            String key = order.getString(index);
            if (!consumedKeys.add(key)) {
                continue;
            }
            int amount = tag.getInt(key);
            AspectId aspect = storedAspect(key);
            if (aspect != null && amount >= 0) {
                mergePersistedAmount(aspects, aspect, amount);
            }
        }
        for (String key : tag.getAllKeys()) {
            if (key.equals(ASPECT_ORDER) || !consumedKeys.add(key)) {
                continue;
            }
            int amount = tag.getInt(key);
            AspectId aspect = storedAspect(key);
            if (aspect != null && amount >= 0) {
                mergePersistedAmount(aspects, aspect, amount);
            }
        }
        return boundedPersistedAmounts(aspects);
    }

    private static void mergePersistedAmount(Map<AspectId, Integer> aspects, AspectId aspect, int amount) {
        long merged = (long) aspects.getOrDefault(aspect, 0) + amount;
        aspects.put(aspect, (int) Math.min(Integer.MAX_VALUE, merged));
    }

    private static Map<AspectId, Integer> boundedPersistedAmounts(Map<AspectId, Integer> aspects) {
        LinkedHashMap<AspectId, Integer> bounded = new LinkedHashMap<>();
        long remaining = Integer.MAX_VALUE;
        for (Map.Entry<AspectId, Integer> entry : aspects.entrySet()) {
            if (bounded.size() >= NodeVis.MAX_ASPECTS) {
                break;
            }
            int amount = (int) Math.min(remaining, entry.getValue());
            bounded.put(entry.getKey(), amount);
            remaining -= amount;
        }
        return bounded;
    }

    private static String safeNodeType(String value) {
        try {
            return NodeTypeId.parse(value).toString();
        } catch (RuntimeException exception) {
            return NodeTypeId.NORMAL.toString();
        }
    }

    private static String safeNodeModifier(String value) {
        try {
            return NodeModifierId.parse(value).toString();
        } catch (RuntimeException exception) {
            return NodeModifierId.NONE.toString();
        }
    }

    private static long growthRoll(RandomSource random, long bound) {
        if (bound <= Integer.MAX_VALUE) {
            return random.nextInt((int) bound);
        }
        long bits;
        long roll;
        do {
            bits = random.nextLong() >>> 1;
            roll = bits % bound;
        } while (bits - roll + (bound - 1) < 0L);
        return roll;
    }

    private static int total(Map<AspectId, Integer> aspects) {
        int total = 0;
        for (int amount : aspects.values()) {
            total = Math.addExact(total, amount);
        }
        return total;
    }

    private static Map<AspectId, Integer> baseAspects(AuraNodeState state) {
        return state.baseVis().amounts();
    }

    private static Map<AspectId, Integer> currentAspects(AuraNodeState state) {
        return state.currentVis().amounts();
    }

    private static CompoundTag writeAspectMap(Map<AspectId, Integer> aspects) {
        CompoundTag tag = new CompoundTag();
        ListTag order = new ListTag();
        aspects.forEach((aspect, amount) -> {
            // Free-node NBT has always used fully namespaced keys; compact
            // spelling belongs to components and other typed projections.
            String canonical = aspect.toString();
            tag.putInt(canonical, amount);
            order.add(StringTag.valueOf(canonical));
        });
        tag.put(ASPECT_ORDER, order);
        return tag;
    }

    private static AspectId storedAspect(String value) {
        try {
            return value == null || value.isEmpty() ? null : AspectId.parse(value);
        } catch (IllegalArgumentException ignored) {
            return null;
        }
    }

    protected final HolderLookup.Provider persistenceRegistries() {
        if (level != null)
            return level.registryAccess();
        var server = net.minecraftforge.server.ServerLifecycleHooks.getCurrentServer();
        return server != null ? server.registryAccess() : net.minecraft.core.RegistryAccess.fromRegistryOfRegistries(net.minecraft.core.registries.BuiltInRegistries.REGISTRY);
    }

    protected static net.minecraft.network.chat.Component parseCustomNameSafe(String value, HolderLookup.Provider registries) {
        try {
            return net.minecraft.network.chat.Component.Serializer.fromJson(value);
        } catch (RuntimeException exception) {
            return null;
        }
    }

    protected void readItemFields(ItemFields.Input input) {
    }

    public void copyItemFields(ItemFields.Output output) {
    }

    public void applyComponentsFromItemStack(ItemStack stack) {
        readItemFields(ItemFields.from(stack));
    }

    public void removeComponentsFromTag(CompoundTag tag) {
    }

    @Override
    public void saveToItem(ItemStack stack) {
        CompoundTag tag = saveWithoutMetadata();
        {
            net.minecraft.nbt.CompoundTag native$bodyOperand$6111 = tag;
            native$bodyReturn$6113: {
                if (true) {
                }
            }
        }
        net.minecraft.world.item.BlockItem.setBlockEntityData(stack, getType(), tag);
        copyItemFields(ItemFields.to(stack));
    }

    @Override
    public net.minecraft.world.phys.AABB getRenderBoundingBox() {
        return AuraNodeBlockEntity.native$ClientBlockEntityBounds$bounds(this);
    }

    @Override()
    public void onDataPacket(net.minecraft.network.Connection connection, net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket packet) {
        handleUpdateTag(packet.getTag());
    }

    @SuppressWarnings({ "rawtypes", "unchecked" })
    static private net.minecraft.world.phys.AABB native$ClientBlockEntityBounds$bounds(net.minecraft.world.level.block.entity.BlockEntity blockEntity) {
        var renderer = net.minecraft.client.Minecraft.getInstance().getBlockEntityRenderDispatcher().getRenderer(blockEntity);
        return renderer instanceof dev.tc4port.thaumcraft.nativeimpl.NativeBlockEntityRenderer shared ? shared.getRenderBoundingBox(blockEntity) : new net.minecraft.world.phys.AABB(blockEntity.getBlockPos());
    }

    private boolean native$capabilitiesInvalid$16856;

    public boolean native$capabilityActive$16760;

    public net.minecraftforge.common.capabilities.Capability<dev.tc4port.thaumcraft.api.node.VisSource> native$capabilityCapture$16759;

    private java.util.Map<net.minecraft.core.Direction, net.minecraftforge.common.util.LazyOptional<dev.tc4port.thaumcraft.api.node.VisSource>> native$capabilityHandle$16761;

    @Override
    public <native$capabilityResultType$16857> net.minecraftforge.common.util.LazyOptional<native$capabilityResultType$16857> getCapability(net.minecraftforge.common.capabilities.Capability<native$capabilityResultType$16857> native$requestedCapability$16858, net.minecraft.core.Direction native$requestedFace$16859) {
        getCapabilities();
        synchronized (this) {
            if (native$capabilitiesInvalid$16856)
                return net.minecraftforge.common.util.LazyOptional.empty();
            if (native$capabilityActive$16760 && native$requestedCapability$16858 == (dev.tc4port.thaumcraft.block.entity.AuraNodeBlockEntity.this.native$capabilityCapture$16759)) {
                if (native$capabilityHandle$16761 == null)
                    native$capabilityHandle$16761 = new java.util.HashMap<>();
                net.minecraftforge.common.util.LazyOptional<dev.tc4port.thaumcraft.api.node.VisSource> native$capabilityResult$16861 = (switch(0) {
                    default ->
                        {
                            net.minecraft.core.Direction native$capabilityFace$16762 = native$requestedFace$16859;
                            net.minecraftforge.common.util.LazyOptional<dev.tc4port.thaumcraft.api.node.VisSource> native$nextCapability$16863 = switch(0) {
                                default ->
                                    {
                                        dev.tc4port.thaumcraft.api.node.VisSource native$endpoint$16 = (switch(0) {
                                            default ->
                                                {
                                                    dev.tc4port.thaumcraft.block.entity.AuraNodeBlockEntity node = dev.tc4port.thaumcraft.block.entity.AuraNodeBlockEntity.this;
                                                    net.minecraft.core.Direction side = native$capabilityFace$16762;
                                                    yield side == null ? node : null;
                                                }
                                        });
                                        yield native$endpoint$16 == null ? net.minecraftforge.common.util.LazyOptional.empty() : net.minecraftforge.common.util.LazyOptional.of(() -> native$endpoint$16);
                                    }
                            };
                            net.minecraftforge.common.util.LazyOptional<dev.tc4port.thaumcraft.api.node.VisSource> native$previousCapability$16862 = native$capabilityHandle$16761.get(native$capabilityFace$16762);
                            if (native$previousCapability$16862 != null && native$previousCapability$16862.isPresent() && native$previousCapability$16862.orElse(null) == native$nextCapability$16863.orElse(null)) {
                                yield native$previousCapability$16862;
                            }
                            native$capabilityHandle$16761.put(native$capabilityFace$16762, native$nextCapability$16863);
                            if (native$previousCapability$16862 != null)
                                native$previousCapability$16862.invalidate();
                            yield native$nextCapability$16863;
                        }
                });
                if (native$capabilityResult$16861.isPresent())
                    return native$capabilityResult$16861.cast();
            }
        }
        return super.getCapability(native$requestedCapability$16858, native$requestedFace$16859);
    }

    @Override
    public void invalidateCaps() {
        java.util.List<net.minecraftforge.common.util.LazyOptional<?>> native$expiredCapabilities$16860 = new java.util.ArrayList<>();
        synchronized (this) {
            native$capabilitiesInvalid$16856 = true;
            if (native$capabilityHandle$16761 != null) {
                native$expiredCapabilities$16860.addAll(native$capabilityHandle$16761.values());
                native$capabilityHandle$16761 = null;
            }
        }
        try {
            super.invalidateCaps();
        } finally {
            native$expiredCapabilities$16860.forEach(net.minecraftforge.common.util.LazyOptional::invalidate);
        }
    }

    @Override
    public void reviveCaps() {
        super.reviveCaps();
        synchronized (this) {
            native$capabilitiesInvalid$16856 = false;
        }
    }
}
