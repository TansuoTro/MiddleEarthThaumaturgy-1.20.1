package dev.tc4port.thaumcraft.api.gameplay;

import java.util.Map;
import java.util.Optional;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.Vec3;

/**
 * An invocation: actor causes the operation, target receives it, position locates it.
 * System events may have no actor. Each step can select its own actor and target in a scoped copy;
 * the next step still resolves role names against the original invocation.
 * Values are caller-owned inputs, including strength, roll and instability.
 * Parameters retain optional typed invocation inputs for event-owned validation.
 */
public record GameplayContext(ServerLevel level, Vec3 position, Optional<Entity> actor, Optional<Entity> target, ItemStack usedItem, Map<String, Double> values, CompoundTag parameters) {

    /**
     * Invocation with no additional typed parameters.
     */
    public GameplayContext(ServerLevel level, Vec3 position, Optional<Entity> actor, Optional<Entity> target, ItemStack usedItem, Map<String, Double> values) {
        this(level, position, actor, target, usedItem, values, new CompoundTag());
    }

    public GameplayContext {
        java.util.Objects.requireNonNull(level);
        java.util.Objects.requireNonNull(position);
        if (!Double.isFinite(position.x) || !Double.isFinite(position.y) || !Double.isFinite(position.z)) {
            throw new IllegalArgumentException("Gameplay context position must be finite");
        }
        actor = java.util.Objects.requireNonNull(actor);
        target = java.util.Objects.requireNonNull(target);
        usedItem = usedItem.copy();
        values = Map.copyOf(values);
        parameters = java.util.Objects.requireNonNull(parameters).copy();
        values.forEach((key, value) -> {
            if (!Double.isFinite(value))
                throw new IllegalArgumentException("Non-finite gameplay context value: " + key);
        });
    }

    public <T extends Entity> Optional<T> actor(Class<T> type) {
        return actor.filter(type::isInstance).map(type::cast);
    }

    public <T extends Entity> Optional<T> target(Class<T> type) {
        return target.filter(type::isInstance).map(type::cast);
    }

    @Override
    public ItemStack usedItem() {
        return usedItem.copy();
    }

    @Override
    public CompoundTag parameters() {
        return parameters.copy();
    }

    public double value(String key) {
        Double value = values.get(key);
        if (value == null)
            throw new IllegalArgumentException("Value unavailable in this action context: " + key);
        return value;
    }
}
