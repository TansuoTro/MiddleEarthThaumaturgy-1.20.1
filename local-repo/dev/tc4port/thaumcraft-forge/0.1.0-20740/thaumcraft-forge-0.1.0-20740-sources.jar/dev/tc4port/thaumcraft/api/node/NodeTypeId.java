package dev.tc4port.thaumcraft.api.node;

import com.mojang.serialization.Codec;
import com.mojang.serialization.DataResult;
import java.util.Objects;
import net.minecraft.resources.ResourceLocation;

/**
 * Stable identity of one aura-node type.
 */
public record NodeTypeId(ResourceLocation value) implements Comparable<NodeTypeId> {

    public static final NodeTypeId NORMAL = parse("normal");

    public static final NodeTypeId UNSTABLE = parse("unstable");

    public static final NodeTypeId DARK = parse("dark");

    public static final NodeTypeId TAINTED = parse("tainted");

    public static final NodeTypeId HUNGRY = parse("hungry");

    public static final NodeTypeId PURE = parse("pure");

    public static final Codec<NodeTypeId> CODEC = Codec.STRING.comapFlatMap(NodeTypeId::decode, NodeTypeId::toString);

    public NodeTypeId {
        value = Objects.requireNonNull(value, "value");
        if (value.toString().length() > 256) {
            throw new IllegalArgumentException("Node type ID is longer than 256 characters: " + value);
        }
    }

    public static NodeTypeId of(ResourceLocation value) {
        return new NodeTypeId(value);
    }

    /**
     * Parses a compact built-in key or a namespaced stable identity.
     */
    public static NodeTypeId parse(String value) {
        Objects.requireNonNull(value, "value");
        ResourceLocation parsed = value.indexOf(':') < 0 ? ResourceLocation.tryBuild("thaumcraft", value) : ResourceLocation.tryParse(value);
        if (parsed == null) {
            throw new IllegalArgumentException("Invalid node type ID: " + value);
        }
        return new NodeTypeId(parsed);
    }

    private static DataResult<NodeTypeId> decode(String value) {
        try {
            return DataResult.success(parse(value));
        } catch (RuntimeException exception) {
            return DataResult.error(() -> "Invalid node type ID '" + value + "': " + exception.getMessage());
        }
    }

    /**
     * Current compact spelling for built-ins; addon identities stay namespaced.
     */
    public String serialized() {
        return this.value.getNamespace().equals("thaumcraft") ? this.value.getPath() : this.value.toString();
    }

    @Override
    public int compareTo(NodeTypeId other) {
        return this.value.compareTo(other.value);
    }

    @Override
    public String toString() {
        return this.value.toString();
    }
}
