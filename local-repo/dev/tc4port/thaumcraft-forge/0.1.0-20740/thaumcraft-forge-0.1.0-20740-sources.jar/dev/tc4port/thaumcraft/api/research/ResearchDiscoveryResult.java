package dev.tc4port.thaumcraft.api.research;

/**
 * Outcome of adding one persisted TC4 {@code @research} discovery marker.
 */
public enum ResearchDiscoveryResult {

    DISCOVERED, ALREADY_DISCOVERED, ALREADY_COMPLETE, OFF_SERVER_THREAD
}
