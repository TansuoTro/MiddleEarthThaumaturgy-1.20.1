package dev.tc4port.thaumcraft.api.node;

import java.util.Objects;

/**
 * Read-only metadata for one of the four built-in node modifiers.
 */
public record NodeModifierDefinition(NodeModifierId id, int generationWeight, int rechargeIntervalTicks, float energizedOutputMultiplier, float renderAlphaMultiplier, float renderAlphaPulse, boolean shiny, int dischargeIntervalTicks, int shinyDischargeIntervalTicks, boolean halfDischargeChance) {

    public NodeModifierDefinition {
        id = Objects.requireNonNull(id, "id");
        if (generationWeight < 0 || rechargeIntervalTicks < 0 || dischargeIntervalTicks <= 0 || shinyDischargeIntervalTicks <= 0 || !Float.isFinite(energizedOutputMultiplier) || energizedOutputMultiplier <= 0.0F || energizedOutputMultiplier > 1_000.0F || !Float.isFinite(renderAlphaMultiplier) || renderAlphaMultiplier <= 0.0F || renderAlphaMultiplier > 1_000.0F || !Float.isFinite(renderAlphaPulse) || renderAlphaPulse < 0.0F || renderAlphaPulse > 1_000.0F) {
            throw new IllegalArgumentException("Invalid node modifier definition " + id);
        }
    }
}
