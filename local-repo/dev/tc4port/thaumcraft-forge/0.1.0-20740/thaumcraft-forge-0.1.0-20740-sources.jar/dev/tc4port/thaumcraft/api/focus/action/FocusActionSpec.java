package dev.tc4port.thaumcraft.api.focus.action;

import dev.tc4port.thaumcraft.api.research.ResearchRequirement;
import dev.tc4port.thaumcraft.api.presentation.ActionPresentationAudience;
import java.util.Objects;
import java.util.Set;
import net.minecraft.resources.ResourceLocation;

public record FocusActionSpec(ResourceLocation actionId, FocusActionTarget target, Set<FocusActivation> activations, ResearchRequirement research, int maximumRange, int priority, FocusCastAnimation castAnimation, ActionPresentationAudience presentation) {

    public static final int HARD_MAXIMUM_RANGE = 128;

    public FocusActionSpec {
        Objects.requireNonNull(actionId, "actionId");
        Objects.requireNonNull(target, "target");
        activations = Set.copyOf(Objects.requireNonNull(activations, "activations"));
        Objects.requireNonNull(research, "research");
        Objects.requireNonNull(castAnimation, "castAnimation");
        Objects.requireNonNull(presentation, "presentation");
        if (activations.isEmpty() || maximumRange < 1 || maximumRange > HARD_MAXIMUM_RANGE) {
            throw new IllegalArgumentException("Invalid focus action spec");
        }
    }
}
