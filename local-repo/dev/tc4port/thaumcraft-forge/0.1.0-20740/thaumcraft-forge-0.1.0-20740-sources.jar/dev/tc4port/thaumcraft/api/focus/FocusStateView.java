package dev.tc4port.thaumcraft.api.focus;

import java.util.List;
import java.util.Objects;
import java.util.Map;
import java.util.LinkedHashMap;
import java.util.Collections;
import net.minecraft.resources.ResourceLocation;

/**
 * Immutable installed focus identity and its five ordered upgrade slots.
 */
public record FocusStateView(FocusId focusId, List<FocusUpgradeId> upgradeSlots, Map<ResourceLocation, String> properties) {

    public FocusStateView(FocusId focusId, List<FocusUpgradeId> upgradeSlots) {
        this(focusId, upgradeSlots, Map.of());
    }

    public FocusStateView {
        Objects.requireNonNull(focusId, "focusId");
        upgradeSlots = List.copyOf(upgradeSlots);
        if (upgradeSlots.size() > FocusProfileDefinition.RANK_COUNT || upgradeSlots.stream().anyMatch(Objects::isNull)) {
            throw new IllegalArgumentException("Focus state may contain at most five non-null upgrades");
        }
        Objects.requireNonNull(properties, "properties");
        LinkedHashMap<ResourceLocation, String> checked = new LinkedHashMap<>();
        properties.forEach((key, value) -> checked.put(Objects.requireNonNull(key, "property key"), Objects.requireNonNull(value, "property value")));
        properties = Collections.unmodifiableMap(checked);
    }

    public int level(FocusUpgradeId upgradeId) {
        Objects.requireNonNull(upgradeId, "upgradeId");
        return (int) this.upgradeSlots.stream().filter(upgradeId::equals).count();
    }

    /**
     * Positive installed levels in stable first-slot order.
     */
    public Map<FocusUpgradeId, Integer> upgradeLevels() {
        LinkedHashMap<FocusUpgradeId, Integer> result = new LinkedHashMap<>();
        upgradeSlots.forEach(upgrade -> result.merge(upgrade, 1, Integer::sum));
        return Collections.unmodifiableMap(result);
    }
}
