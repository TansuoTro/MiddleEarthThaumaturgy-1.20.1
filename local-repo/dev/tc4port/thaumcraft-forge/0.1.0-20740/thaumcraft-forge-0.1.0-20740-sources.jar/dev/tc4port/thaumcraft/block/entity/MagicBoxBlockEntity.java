package dev.tc4port.thaumcraft.block.entity;

import dev.tc4port.thaumcraft.menu.MagicBoxMenu;
import dev.tc4port.thaumcraft.registry.TCBlockEntities;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import javax.annotation.Nullable;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket;
import net.minecraft.world.Container;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import java.lang.Math;
import dev.tc4port.thaumcraft.nativeimpl.state.ItemFields;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityType;

/**
 * Packed-list inventory and dormant linking/sorting behavior of
 * {@code TileMagicBox}.
 */
public final class MagicBoxBlockEntity extends net.minecraft.world.level.block.entity.BlockEntity implements Container, net.minecraft.world.MenuProvider, ItemFields.Source {

    private static final int PAGE_SIZE = 27;

    private static final int LINK_LIMIT = 1_024;

    private final List<ItemStack> boxContents = new ArrayList<>();

    @Nullable
    private BlockPos master;

    private byte sorting = -1;

    private short linkedBoxes = -1;

    private boolean linksIncomplete;

    public MagicBoxBlockEntity(BlockPos pos, BlockState state) {
        super(TCBlockEntities.MAGIC_BOX.get(), pos, state);
    }

    public static void serverTick(Level level, BlockPos pos, BlockState state, MagicBoxBlockEntity box) {
        if (box.master != null && !level.isLoaded(box.master))
            return;
        if (box.inventoryRoot() == box && (box.linkedBoxes < 0 || box.linksIncomplete && level.getGameTime() % 20 == 0)) {
            box.refreshLinks();
        }
    }

    @Override
    public int getContainerSize() {
        if (this.master != null && (this.level == null || !this.level.isLoaded(this.master)))
            return 0;
        return PAGE_SIZE * (this.inventoryRoot().linkedBoxes + 1);
    }

    @Override
    public boolean isEmpty() {
        return this.contents().isEmpty();
    }

    @Override
    public ItemStack getItem(int slot) {
        List<ItemStack> contents = this.contents();
        return slot < 0 || slot >= contents.size() ? ItemStack.EMPTY : contents.get(slot);
    }

    @Override
    public ItemStack removeItem(int slot, int amount) {
        List<ItemStack> contents = this.contents();
        if (slot < 0 || slot >= contents.size() || contents.get(slot).isEmpty()) {
            return ItemStack.EMPTY;
        }
        ItemStack existing = contents.get(slot);
        ItemStack removed;
        if (existing.getCount() <= amount) {
            removed = contents.remove(slot);
        } else {
            removed = existing.split(amount);
            if (existing.isEmpty()) {
                contents.remove(slot);
            }
        }
        this.inventoryRoot().setChanged();
        return removed;
    }

    @Override
    public ItemStack removeItemNoUpdate(int slot) {
        List<ItemStack> contents = this.contents();
        return slot < 0 || slot >= contents.size() ? ItemStack.EMPTY : contents.remove(slot);
    }

    @Override
    public void setItem(int slot, ItemStack stack) {
        List<ItemStack> contents = this.contents();
        ItemStack normalized = stack.copy();
        normalized.setCount(Math.min(normalized.getCount(), Math.min(this.getMaxStackSize(), normalized.getMaxStackSize())));
        if (slot >= contents.size() && !normalized.isEmpty()) {
            contents.add(normalized);
        } else if (slot >= 0 && slot < contents.size() && !normalized.isEmpty()) {
            contents.set(slot, normalized);
        } else if (slot >= 0 && slot < contents.size()) {
            contents.remove(slot);
        }
        this.inventoryRoot().setChanged();
    }

    @Override
    public void setChanged() {
        super.setChanged();
        this.sortContents();
        if (this.level != null && !this.level.isClientSide) {
            this.level.sendBlockUpdated(this.worldPosition, this.getBlockState(), this.getBlockState(), Block.UPDATE_CLIENTS);
        }
    }

    @Override
    public boolean stillValid(Player player) {
        return this.level != null && this.level.getBlockEntity(this.worldPosition) == this && player.distanceToSqr(this.worldPosition.getX() + 0.5, this.worldPosition.getY() + 0.5, this.worldPosition.getZ() + 0.5) <= 64.0;
    }

    @Override
    public void clearContent() {
        this.contents().clear();
        this.inventoryRoot().setChanged();
    }

    @Override
    public Component getDisplayName() {
        return Component.literal("Magic Box");
    }

    @Nullable
    @Override
    public AbstractContainerMenu createMenu(int containerId, Inventory inventory, Player player) {
        // Vanilla spectator opening bypasses our extra-data menu transport.
        if (inventory.player.isSpectator()) {
            return null;
        }
        return new MagicBoxMenu(containerId, inventory, this);
    }

    public void refreshLinks() {
        if (this.level == null || this.master != null && !this.level.isLoaded(this.master))
            return;
        if (this.inventoryRoot() != this) {
            return;
        }
        this.linksIncomplete = false;
        ArrayList<BlockPos> found = new ArrayList<>();
        this.findBoxes(this.worldPosition, found);
        if (this.linksIncomplete) {
            // Keep existing pages until the entire connected group can be observed.
            if (this.linkedBoxes < 0)
                this.linkedBoxes = 0;
            return;
        }
        this.linkedBoxes = (short) found.size();
        this.setChanged();
    }

    private void findBoxes(BlockPos pos, List<BlockPos> found) {
        if (this.level == null || found.size() >= LINK_LIMIT) {
            return;
        }
        for (Direction direction : Direction.values()) {
            BlockPos adjacent = pos.relative(direction);
            if (!this.level.isLoaded(adjacent)) {
                this.linksIncomplete = true;
                continue;
            }
            if (this.level.getBlockEntity(adjacent) instanceof MagicBoxBlockEntity && !found.contains(adjacent)) {
                found.add(adjacent.immutable());
                this.findBoxes(adjacent, found);
            }
        }
    }

    private List<ItemStack> contents() {
        MagicBoxBlockEntity root = this.inventoryRoot();
        return root == this ? this.boxContents : root.boxContents;
    }

    private MagicBoxBlockEntity inventoryRoot() {
        if (this.master == null || this.level == null || !this.level.isLoaded(this.master)) {
            return this;
        }
        return this.level.getBlockEntity(this.master) instanceof MagicBoxBlockEntity box ? box : this;
    }

    private void sortContents() {
        if (this.level == null || this.sorting < 0 || this.sorting > 2 || this.contents().size() < 2) {
            return;
        }
        List<ItemStack> contents = this.contents();
        /*
         * TC4's bubble sort compared mode 2 with both namespaces on one side
         * and stopped after any pass whose last pair was ordered, so it could
         * loop forever or finish unsorted. A total order sorts in one pass;
         * equal stacks then merge into their neighbours.
         */
        Comparator<ItemStack> byName = Comparator.comparing(MagicBoxBlockEntity::stackKey, String.CASE_INSENSITIVE_ORDER);
        contents.sort(switch(this.sorting) {
            case 1 ->
                byName.reversed();
            case 2 ->
                Comparator.comparing(MagicBoxBlockEntity::registryNamespace, String.CASE_INSENSITIVE_ORDER).thenComparing(byName);
            default ->
                byName;
        });
        for (int index = 0; index < contents.size() - 1; ) {
            ItemStack first = contents.get(index);
            ItemStack second = contents.get(index + 1);
            if (first.getCount() < first.getMaxStackSize() && net.minecraft.world.item.ItemStack.isSameItemSameTags((net.minecraft.world.item.ItemStack) (first), (net.minecraft.world.item.ItemStack) (second))) {
                int moved = Math.min(first.getMaxStackSize() - first.getCount(), second.getCount());
                first.grow(moved);
                second.shrink(moved);
                if (second.isEmpty()) {
                    contents.remove(index + 1);
                    continue;
                }
            }
            index++;
        }
    }

    private static String registryNamespace(ItemStack stack) {
        var key = net.minecraft.core.registries.BuiltInRegistries.ITEM.getKey(stack.getItem());
        return key == null ? "" : key.getNamespace();
    }

    private static String stackKey(ItemStack stack) {
        String key = stack.getHoverName().getString();
        if (dev.tc4port.thaumcraft.nativeimpl.ItemStorage.hasStackData(stack)) {
            key += dev.tc4port.thaumcraft.nativeimpl.ItemStorage.dataHash(stack);
        }
        return key;
    }

    public short linkedBoxCount() {
        return this.linkedBoxes;
    }

    public int packedStackCount() {
        return this.contents().size();
    }

    @Override
    public void load(CompoundTag tag) {
        HolderLookup.Provider registries = persistenceRegistries();
        super.load(tag);
        this.boxContents.clear();
        ListTag items = tag.getList("Items", Tag.TAG_COMPOUND);
        for (int index = 0; index < items.size(); index++) {
            ItemStack stack = (switch(0) {
                default ->
                    {
                        net.minecraft.core.HolderLookup.Provider native$operand$13111 = registries;
                        net.minecraft.nbt.CompoundTag native$operand$13112 = items.getCompound(index);
                        net.minecraft.world.item.ItemStack native$result$13113 = (net.minecraft.world.item.ItemStack.of(native$operand$13112));
                        yield native$result$13113;
                    }
            });
            if (!stack.isEmpty()) {
                this.boxContents.add(stack);
            }
        }
        this.sorting = tag.getByte("sort");
        this.master = tag.contains("w_x") ? new BlockPos(tag.getInt("w_x"), tag.getInt("w_y"), tag.getInt("w_z")) : null;
        this.linkedBoxes = -1;
        this.sortContents();
    }

    @Override
    protected void saveAdditional(CompoundTag tag) {
        HolderLookup.Provider registries = persistenceRegistries();
        super.saveAdditional(tag);
        ListTag items = new ListTag();
        for (ItemStack stack : this.boxContents) {
            if (!stack.isEmpty()) {
                items.add((switch(0) {
                    default ->
                        {
                            net.minecraft.world.item.ItemStack native$operand$12978 = stack;
                            net.minecraft.core.HolderLookup.Provider native$operand$12979 = registries;
                            net.minecraft.nbt.Tag native$result$12980 = (native$operand$12978.save(new net.minecraft.nbt.CompoundTag()));
                            yield native$result$12980;
                        }
                }));
            }
        }
        tag.put("Items", items);
        tag.putByte("sort", this.sorting);
        if (this.master != null) {
            tag.putInt("w_x", this.master.getX());
            tag.putInt("w_y", this.master.getY());
            tag.putInt("w_z", this.master.getZ());
        }
    }

    @Override
    public CompoundTag getUpdateTag() {
        return this.saveWithoutMetadata();
    }

    @Nullable
    @Override
    public Packet<ClientGamePacketListener> getUpdatePacket() {
        return ClientboundBlockEntityDataPacket.create(this);
    }

    protected final HolderLookup.Provider persistenceRegistries() {
        if (level != null)
            return level.registryAccess();
        var server = net.minecraftforge.server.ServerLifecycleHooks.getCurrentServer();
        return server != null ? server.registryAccess() : net.minecraft.core.RegistryAccess.fromRegistryOfRegistries(net.minecraft.core.registries.BuiltInRegistries.REGISTRY);
    }

    protected static net.minecraft.network.chat.Component parseCustomNameSafe(String value, HolderLookup.Provider registries) {
        try {
            return net.minecraft.network.chat.Component.Serializer.fromJson(value);
        } catch (RuntimeException exception) {
            return null;
        }
    }

    protected void readItemFields(ItemFields.Input input) {
    }

    public void copyItemFields(ItemFields.Output output) {
    }

    public void applyComponentsFromItemStack(ItemStack stack) {
        readItemFields(ItemFields.from(stack));
    }

    public void removeComponentsFromTag(CompoundTag tag) {
    }

    @Override
    public void saveToItem(ItemStack stack) {
        CompoundTag tag = saveWithoutMetadata();
        {
            net.minecraft.nbt.CompoundTag native$bodyOperand$6179 = tag;
            native$bodyReturn$6181: {
                if (true) {
                }
            }
        }
        net.minecraft.world.item.BlockItem.setBlockEntityData(stack, getType(), tag);
        copyItemFields(ItemFields.to(stack));
    }

    @Override
    public net.minecraft.world.phys.AABB getRenderBoundingBox() {
        return MagicBoxBlockEntity.native$ClientBlockEntityBounds$bounds(this);
    }

    @Override()
    public void onDataPacket(net.minecraft.network.Connection connection, net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket packet) {
        handleUpdateTag(packet.getTag());
    }

    @SuppressWarnings({ "rawtypes", "unchecked" })
    static private net.minecraft.world.phys.AABB native$ClientBlockEntityBounds$bounds(net.minecraft.world.level.block.entity.BlockEntity blockEntity) {
        var renderer = net.minecraft.client.Minecraft.getInstance().getBlockEntityRenderDispatcher().getRenderer(blockEntity);
        return renderer instanceof dev.tc4port.thaumcraft.nativeimpl.NativeBlockEntityRenderer shared ? shared.getRenderBoundingBox(blockEntity) : new net.minecraft.world.phys.AABB(blockEntity.getBlockPos());
    }

    private boolean native$capabilitiesInvalid$16991;

    public boolean native$capabilityActive$16828;

    private java.util.Map<net.minecraft.core.Direction, net.minecraftforge.common.util.LazyOptional<net.minecraftforge.items.IItemHandler>> native$capabilityHandle$16829;

    @Override
    public <native$capabilityResultType$16992> net.minecraftforge.common.util.LazyOptional<native$capabilityResultType$16992> getCapability(net.minecraftforge.common.capabilities.Capability<native$capabilityResultType$16992> native$requestedCapability$16993, net.minecraft.core.Direction native$requestedFace$16994) {
        getCapabilities();
        synchronized (this) {
            if (native$capabilitiesInvalid$16991)
                return net.minecraftforge.common.util.LazyOptional.empty();
            if (native$capabilityActive$16828 && native$requestedCapability$16993 == (net.minecraftforge.common.capabilities.ForgeCapabilities.ITEM_HANDLER)) {
                if (native$capabilityHandle$16829 == null)
                    native$capabilityHandle$16829 = new java.util.HashMap<>();
                net.minecraftforge.common.util.LazyOptional<net.minecraftforge.items.IItemHandler> native$capabilityResult$16996 = native$capabilityHandle$16829.computeIfAbsent(native$requestedFace$16994, native$capabilityFace$16830 -> {
                    net.minecraftforge.items.IItemHandler native$endpoint$211 = (switch(0) {
                        default ->
                            {
                                dev.tc4port.thaumcraft.block.entity.MagicBoxBlockEntity box = dev.tc4port.thaumcraft.block.entity.MagicBoxBlockEntity.this;
                                net.minecraft.core.Direction side = native$capabilityFace$16830;
                                yield (switch(0) {
                                    default ->
                                        {
                                            net.minecraft.world.Container native$operand$12750 = box;
                                            net.minecraftforge.items.IItemHandler native$result$12751 = (new net.minecraftforge.items.wrapper.InvWrapper(native$operand$12750));
                                            yield native$result$12751;
                                        }
                                });
                            }
                    });
                    return native$endpoint$211 == null ? net.minecraftforge.common.util.LazyOptional.empty() : net.minecraftforge.common.util.LazyOptional.of(() -> native$endpoint$211);
                });
                if (native$capabilityResult$16996.isPresent())
                    return native$capabilityResult$16996.cast();
            }
        }
        return super.getCapability(native$requestedCapability$16993, native$requestedFace$16994);
    }

    @Override
    public void invalidateCaps() {
        java.util.List<net.minecraftforge.common.util.LazyOptional<?>> native$expiredCapabilities$16995 = new java.util.ArrayList<>();
        synchronized (this) {
            native$capabilitiesInvalid$16991 = true;
            if (native$capabilityHandle$16829 != null) {
                native$expiredCapabilities$16995.addAll(native$capabilityHandle$16829.values());
                native$capabilityHandle$16829 = null;
            }
        }
        try {
            super.invalidateCaps();
        } finally {
            native$expiredCapabilities$16995.forEach(net.minecraftforge.common.util.LazyOptional::invalidate);
        }
    }

    @Override
    public void reviveCaps() {
        super.reviveCaps();
        synchronized (this) {
            native$capabilitiesInvalid$16991 = false;
        }
    }
}
