package dev.tc4port.thaumcraft.block;

import com.mojang.serialization.MapCodec;
import dev.tc4port.thaumcraft.block.entity.ArcanePressurePlateBlockEntity;
import dev.tc4port.thaumcraft.common.TCServerConfig;
import java.util.List;
import javax.annotation.Nullable;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.RandomSource;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Explosion;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.world.level.block.state.properties.IntegerProperty;
import net.minecraft.world.level.gameevent.GameEvent;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;
import dev.tc4port.thaumcraft.nativeimpl.ClientExtensionTarget;
import dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.level.pathfinder.PathComputationType;
import net.minecraft.world.phys.HitResult;

/**
 * Metadata two/three of BlockWoodenDevice with TileOwned filtering.
 */
public final class ArcanePressurePlateBlock extends net.minecraft.world.level.block.BaseEntityBlock implements dev.tc4port.thaumcraft.nativeimpl.ClientExtensionTarget {

    // Forge calls initializeClient from the native superclass constructor. Do not add a field initializer.
    private java.util.function.Consumer<net.minecraftforge.client.extensions.common.IClientBlockExtensions> platform$clientInstaller;

    public static final MapCodec<ArcanePressurePlateBlock> CODEC = ArcanePressurePlateBlock.native$BlockCodecPlatform$simple(ArcanePressurePlateBlock::new);

    public static final BooleanProperty POWERED = BooleanProperty.create("powered");

    public static final IntegerProperty SETTING = IntegerProperty.create("setting", 0, 2);

    private static final VoxelShape UP_SHAPE = Block.box(1, 0, 1, 15, 1, 15);

    private static final VoxelShape DOWN_SHAPE = Block.box(1, 0, 1, 15, 0.5, 15);

    private static final AABB DETECTION = new AABB(0.125, 0.0, 0.125, 0.875, 0.25, 0.875);

    public ArcanePressurePlateBlock(BlockBehaviour.Properties properties) {
        this(properties, properties, true);
    }

    protected MapCodec<ArcanePressurePlateBlock> codec() {
        return CODEC;
    }

    @Override
    public RenderShape getRenderShape(BlockState state) {
        return RenderShape.MODEL;
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(POWERED, SETTING);
    }

    @Nullable
    @Override
    public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        return new ArcanePressurePlateBlockEntity(pos, state);
    }

    @Override
    public void setPlacedBy(Level level, BlockPos pos, BlockState state, @Nullable LivingEntity placer, ItemStack stack) {
        super.setPlacedBy(level, pos, state, placer, stack);
        if (placer instanceof Player player && level.getBlockEntity(pos) instanceof ArcanePressurePlateBlockEntity plate) {
            plate.setOwner(player);
        }
    }

    @Override
    public VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
        return state.getValue(POWERED) ? DOWN_SHAPE : UP_SHAPE;
    }

    @Override
    public VoxelShape getCollisionShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
        return Shapes.empty();
    }

    @Override
    public void entityInside(BlockState state, Level level, BlockPos pos, Entity entity) {
        if (!level.isClientSide && !state.getValue(POWERED)) {
            updatePressed(level, pos, state, entity);
        }
    }

    @Override
    public void tick(BlockState state, ServerLevel level, BlockPos pos, RandomSource random) {
        if (state.getValue(POWERED)) {
            updatePressed(level, pos, state, null);
        }
    }

    private static void updatePressed(Level level, BlockPos pos, BlockState state, @Nullable Entity activatingEntity) {
        ArcanePressurePlateBlockEntity plate = level.getBlockEntity(pos) instanceof ArcanePressurePlateBlockEntity found ? found : null;
        if (plate == null) {
            return;
        }
        int setting = state.getValue(SETTING);
        List<Entity> entities = level.getEntities((Entity) null, DETECTION.move(pos), entity -> !entity.isIgnoringBlockTriggers() && shouldTrigger(setting, plate, entity));
        boolean pressed = !entities.isEmpty();
        boolean wasPressed = state.getValue(POWERED);
        if (pressed != wasPressed) {
            BlockState updated = state.setValue(POWERED, pressed);
            level.setBlock(pos, updated, Block.UPDATE_CLIENTS);
            level.updateNeighborsAt(pos, state.getBlock());
            level.updateNeighborsAt(pos.below(), state.getBlock());
            level.playSound(null, pos.getX() + 0.5, pos.getY() + 0.1, pos.getZ() + 0.5, pressed ? SoundEvents.WOODEN_PRESSURE_PLATE_CLICK_ON : SoundEvents.WOODEN_PRESSURE_PLATE_CLICK_OFF, SoundSource.BLOCKS, 0.2F, pressed ? 0.6F : 0.5F);
            level.gameEvent(activatingEntity, pressed ? GameEvent.BLOCK_ACTIVATE : GameEvent.BLOCK_DEACTIVATE, pos);
        }
        if (pressed) {
            level.scheduleTick(pos, state.getBlock(), 20);
        }
    }

    public static boolean shouldTrigger(int setting, ArcanePressurePlateBlockEntity plate, Entity entity) {
        return switch(setting) {
            // TC4 skipped the owner and both access lists (iron and gold
            // keys), so setting one ignores every authorized player.
            case 1 ->
                !(entity instanceof Player player) || !plate.isAuthorized(player);
            case 2 ->
                entity instanceof Player player && plate.isAuthorized(player);
            default ->
                true;
        };
    }

    protected InteractionResult interactWithoutItem(BlockState state, Level level, BlockPos pos, Player player, BlockHitResult hitResult) {
        if (!(level.getBlockEntity(pos) instanceof dev.tc4port.thaumcraft.block.entity.ArcanePressurePlateBlockEntity plate) || !plate.canAdminister(player)) {
            return net.minecraft.world.InteractionResult.sidedSuccess(level.isClientSide);
        }
        if (!level.isClientSide) {
            int setting = (state.getValue(dev.tc4port.thaumcraft.block.ArcanePressurePlateBlock.SETTING) + 1) % 3;
            level.setBlock(pos, state.setValue(dev.tc4port.thaumcraft.block.ArcanePressurePlateBlock.SETTING, setting), net.minecraft.world.level.block.Block.UPDATE_CLIENTS);
            player.sendSystemMessage(net.minecraft.network.chat.Component.literal(switch(setting) {
                case 1 ->
                    "It will now trigger on everything except you.";
                case 2 ->
                    "It will now trigger on just you.";
                default ->
                    "It will now trigger on everything.";
            }));
            level.playSound(null, pos.getX() + 0.5, pos.getY() + 0.1, pos.getZ() + 0.5, net.minecraft.sounds.SoundEvents.WOODEN_BUTTON_CLICK_ON, net.minecraft.sounds.SoundSource.BLOCKS, 0.1F, 0.9F);
            plate.setChanged();
        }
        return net.minecraft.world.InteractionResult.sidedSuccess(level.isClientSide);
    }

    @Override
    public boolean isSignalSource(BlockState state) {
        return true;
    }

    @Override
    public int getSignal(BlockState state, BlockGetter level, BlockPos pos, Direction direction) {
        return state.getValue(POWERED) ? 15 : 0;
    }

    @Override
    public int getDirectSignal(BlockState state, BlockGetter level, BlockPos pos, Direction direction) {
        return direction == Direction.UP && state.getValue(POWERED) ? 15 : 0;
    }

    @Override
    public boolean canEntityDestroy(BlockState state, BlockGetter level, BlockPos pos, Entity entity) {
        return false;
    }

    @Override
    public float getDestroyProgress(BlockState state, Player player, BlockGetter level, BlockPos pos) {
        return TCServerConfig.wardedStone() ? 0.0F : WardedGlassBlock.destroyProgress(state, player, level, pos, 2.0F);
    }

    @Override
    public float getExplosionResistance(BlockState state, BlockGetter level, BlockPos pos, Explosion explosion) {
        return 999.0F;
    }

    protected boolean survivesSharedExplosion() {
        return true;
    }

    @Override
    public int getLightBlock(BlockState state, BlockGetter level, BlockPos pos) {
        return 0;
    }

    @Override
    public void onRemove(BlockState state, Level level, BlockPos pos, BlockState newState, boolean movedByPiston) {
        if (!state.is(newState.getBlock()) && state.getValue(POWERED)) {
            level.updateNeighborsAt(pos, this);
            level.updateNeighborsAt(pos.below(), this);
        }
        super.onRemove(state, level, pos, newState, movedByPiston);
    }

    private ArcanePressurePlateBlock(net.minecraft.world.level.block.state.BlockBehaviour.Properties native$NativeEntityBlock$arg0, BlockBehaviour.Properties properties, boolean native$NativeEntityBlock$captured) {
        super(native$NativeEntityBlock$arg0);
        this.registerDefaultState(this.stateDefinition.any().setValue(POWERED, false).setValue(SETTING, 0));
    }

    @Override
    public void initializeClient(java.util.function.Consumer<net.minecraftforge.client.extensions.common.IClientBlockExtensions> installer) {
        platform$clientInstaller = installer;
        super.initializeClient(installer);
    }

    @Override
    public void platform$clientExtension(Object extension) {
        java.util.Objects.requireNonNull(platform$clientInstaller, "Forge initializeClient must run before client extension registration").accept((net.minecraftforge.client.extensions.common.IClientBlockExtensions) extension);
    }

    @Override
    public InteractionResult use(BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
        ItemUseResult result = (switch(0) {
            default ->
                {
                    net.minecraft.world.item.ItemStack native$bodyOperand$4179 = player.getItemInHand(hand);
                    net.minecraft.world.level.block.state.BlockState native$bodyOperand$4180 = state;
                    net.minecraft.world.level.Level native$bodyOperand$4181 = level;
                    net.minecraft.core.BlockPos native$bodyOperand$4182 = pos;
                    net.minecraft.world.entity.player.Player native$bodyOperand$4183 = player;
                    net.minecraft.world.InteractionHand native$bodyOperand$4184 = hand;
                    net.minecraft.world.phys.BlockHitResult native$bodyOperand$4185 = hit;
                    dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult native$bodyResult$4186 = null;
                    native$bodyReturn$4187: {
                        if (true) {
                            {
                                native$bodyResult$4186 = dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
                                break native$bodyReturn$4187;
                            }
                        }
                    }
                    yield native$bodyResult$4186;
                }
        });
        return result == ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION ? (hand == InteractionHand.MAIN_HAND ? (switch(0) {
            default ->
                {
                    net.minecraft.world.level.block.state.BlockState native$bodyOperand$3507 = state;
                    net.minecraft.world.level.Level native$bodyOperand$3508 = level;
                    net.minecraft.core.BlockPos native$bodyOperand$3509 = pos;
                    net.minecraft.world.entity.player.Player native$bodyOperand$3510 = player;
                    net.minecraft.world.phys.BlockHitResult native$bodyOperand$3511 = hit;
                    net.minecraft.world.InteractionResult native$bodyResult$3514 = null;
                    native$bodyReturn$3515: {
                        if (true) {
                            if (!(native$bodyOperand$3508.getBlockEntity(native$bodyOperand$3509) instanceof dev.tc4port.thaumcraft.block.entity.ArcanePressurePlateBlockEntity native$bodyBinding$3512) || !native$bodyBinding$3512.canAdminister(native$bodyOperand$3510)) {
                                {
                                    native$bodyResult$3514 = net.minecraft.world.InteractionResult.sidedSuccess(native$bodyOperand$3508.isClientSide);
                                    break native$bodyReturn$3515;
                                }
                            }
                            if (!native$bodyOperand$3508.isClientSide) {
                                int native$bodyBinding$3513 = (native$bodyOperand$3507.getValue(dev.tc4port.thaumcraft.block.ArcanePressurePlateBlock.SETTING) + 1) % 3;
                                native$bodyOperand$3508.setBlock(native$bodyOperand$3509, native$bodyOperand$3507.setValue(dev.tc4port.thaumcraft.block.ArcanePressurePlateBlock.SETTING, native$bodyBinding$3513), net.minecraft.world.level.block.Block.UPDATE_CLIENTS);
                                native$bodyOperand$3510.sendSystemMessage(net.minecraft.network.chat.Component.literal(switch(native$bodyBinding$3513) {
                                    case 1 ->
                                        "It will now trigger on everything except you.";
                                    case 2 ->
                                        "It will now trigger on just you.";
                                    default ->
                                        "It will now trigger on everything.";
                                }));
                                native$bodyOperand$3508.playSound(null, native$bodyOperand$3509.getX() + 0.5, native$bodyOperand$3509.getY() + 0.1, native$bodyOperand$3509.getZ() + 0.5, net.minecraft.sounds.SoundEvents.WOODEN_BUTTON_CLICK_ON, net.minecraft.sounds.SoundSource.BLOCKS, 0.1F, 0.9F);
                                native$bodyBinding$3512.setChanged();
                            }
                            {
                                native$bodyResult$3514 = net.minecraft.world.InteractionResult.sidedSuccess(native$bodyOperand$3508.isClientSide);
                                break native$bodyReturn$3515;
                            }
                        }
                    }
                    yield native$bodyResult$3514;
                }
        }) : InteractionResult.PASS) : result.result();
    }

    protected ItemUseResult interactWithItem(ItemStack stack, BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
        return dev.tc4port.thaumcraft.nativeimpl.block.ItemUseResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
    }

    @Override
    public void playerWillDestroy(Level level, BlockPos pos, BlockState state, Player player) {
        {
            net.minecraft.world.level.Level native$bodyOperand$5684 = level;
            net.minecraft.core.BlockPos native$bodyOperand$5685 = pos;
            net.minecraft.world.level.block.state.BlockState native$bodyOperand$5686 = state;
            net.minecraft.world.entity.player.Player native$bodyOperand$5687 = player;
            net.minecraft.world.level.block.state.BlockState native$bodyResult$5688 = null;
            native$bodyReturn$5689: {
                if (true) {
                    super.playerWillDestroy(native$bodyOperand$5684, native$bodyOperand$5685, native$bodyOperand$5686, native$bodyOperand$5687);
                    {
                        native$bodyResult$5688 = native$bodyOperand$5686;
                        break native$bodyReturn$5689;
                    }
                }
            }
        }
    }

    public BlockState beforePlayerDestroy(Level level, BlockPos pos, BlockState state, Player player) {
        super.playerWillDestroy(level, pos, state, player);
        return state;
    }

    public int getExpDrop(net.minecraft.world.level.block.state.BlockState native$callbackInput$1050, net.minecraft.world.level.LevelReader native$callbackInput$1051, net.minecraft.util.RandomSource native$callbackInput$1052, net.minecraft.core.BlockPos native$callbackInput$1053, int native$callbackInput$1054, int native$callbackInput$1055) {
        net.minecraft.world.level.block.state.BlockState state = native$callbackInput$1050;
        net.minecraft.util.RandomSource random = native$callbackInput$1052;
        return 0;
    }

    @Override
    public void onBlockExploded(BlockState state, Level level, BlockPos pos, Explosion explosion) {
        if (!(switch(0) {
            default ->
                {
                    boolean native$bodyResult$5223 = false;
                    native$bodyReturn$5224: {
                        if (true) {
                            {
                                native$bodyResult$5223 = true;
                                break native$bodyReturn$5224;
                            }
                        }
                    }
                    yield native$bodyResult$5223;
                }
        }))
            super.onBlockExploded(state, level, pos, explosion);
    }

    @Override
    public boolean canDropFromExplosion(BlockState state, BlockGetter level, BlockPos pos, Explosion explosion) {
        return !(switch(0) {
            default ->
                {
                    boolean native$bodyResult$4188 = false;
                    native$bodyReturn$4189: {
                        if (true) {
                            {
                                native$bodyResult$4188 = true;
                                break native$bodyReturn$4189;
                            }
                        }
                    }
                    yield native$bodyResult$4188;
                }
        }) && super.canDropFromExplosion(state, level, pos, explosion);
    }

    static private <B extends net.minecraft.world.level.block.Block> com.mojang.serialization.MapCodec<B> native$BlockCodecPlatform$simple(java.util.function.Function<net.minecraft.world.level.block.state.BlockBehaviour.Properties, B> factory) {
        // Vanilla 1.21's Properties codec is a unit codec. Retain that schema for shared block definitions.
        return com.mojang.serialization.codecs.RecordCodecBuilder.mapCodec(instance -> instance.group(com.mojang.serialization.Codec.unit(net.minecraft.world.level.block.state.BlockBehaviour.Properties::of).fieldOf("properties").forGetter((B block) -> net.minecraft.world.level.block.state.BlockBehaviour.Properties.copy(block))).apply(instance, factory));
    }
}
