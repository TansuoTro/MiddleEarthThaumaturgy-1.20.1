package dev.tc4port.thaumcraft.api.vis;

import dev.tc4port.thaumcraft.api.aspect.VisAction;
import dev.tc4port.thaumcraft.api.aspect.VisCost;
import dev.tc4port.thaumcraft.api.wand.VisTransferResult;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;

/**
 * Item-owner transaction adapter for a private Vis component.
 */
public interface OwnedVisStorageProvider {

    VisStorageView view(ItemStack stack);

    /**
     * Must be atomic for the entire requested cost: return either a complete
     * transfer or no transfer. TC never combines partial results from owners.
     */
    VisTransferResult extract(ServerPlayer player, ItemStack stack, VisCost amount, VisAction action);
}
