package dev.tc4port.thaumcraft.block.entity;

import dev.tc4port.thaumcraft.Thaumcraft;
import dev.tc4port.thaumcraft.common.PlayerKnowledgeService;
import dev.tc4port.thaumcraft.registry.TCBlockEntities;
import dev.tc4port.thaumcraft.registry.TCBlocks;
import dev.tc4port.thaumcraft.registry.TCSounds;
import dev.tc4port.thaumcraft.worldgen.outer.OuterLandsSystem;
import dev.tc4port.thaumcraft.worldgen.outer.OuterMazeData;
import dev.tc4port.thaumcraft.worldgen.outer.OuterMazePosition;
import dev.tc4port.thaumcraft.worldgen.outer.OuterRoomId;
import java.util.Optional;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.Registries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.Tag;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.chunk.LevelChunk;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import java.lang.Math;
import dev.tc4port.thaumcraft.nativeimpl.state.ItemFields;
import net.minecraft.core.HolderLookup;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.entity.BlockEntityType;

/**
 * Timing, player gate and reciprocal transfer from
 * {@code TileEldritchPortal}.
 */
public final class EldritchPortalBlockEntity extends net.minecraft.world.level.block.entity.BlockEntity implements ItemFields.Source {

    private static final String RETURN_PORTAL_POS = "ThaumcraftOuterReturnPortal";

    private static final int PORTAL_SEARCH_RADIUS_BLOCKS = 128;

    private static final int PORTAL_SEARCH_RADIUS_CHUNKS = 8;

    public static final ResourceKey<Level> OUTER_LANDS = ResourceKey.create(Registries.DIMENSION, net.minecraft.resources.ResourceLocation.fromNamespaceAndPath((java.lang.String) (Thaumcraft.MOD_ID), (java.lang.String) ("outer_lands")));

    private int openCount = -1;

    private int count;

    public EldritchPortalBlockEntity(BlockPos pos, BlockState state) {
        super(TCBlockEntities.ELDRITCH_PORTAL.get(), pos, state);
    }

    public static void clientTick(Level level, BlockPos pos, BlockState state, EldritchPortalBlockEntity portal) {
        portal.count++;
        if (portal.count % 250 == 0) {
            level.playLocalSound(pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5, TCSounds.EVIL_PORTAL.get(), SoundSource.BLOCKS, 1.0F, 1.0F, false);
        }
        if (portal.openCount < 30) {
            portal.openCount++;
        }
    }

    public static void serverTick(Level level, BlockPos pos, BlockState state, EldritchPortalBlockEntity portal) {
        if (!(level instanceof ServerLevel server)) {
            return;
        }
        portal.count++;
        if (portal.count % 5 != 0) {
            return;
        }
        AABB range = new AABB(pos).inflate(0.5, 1.0, 0.5);
        for (ServerPlayer player : server.getEntitiesOfClass(ServerPlayer.class, range)) {
            portal.processPlayer(server, player);
        }
    }

    private void processPlayer(ServerLevel current, ServerPlayer player) {
        if (player.isPassenger() || player.isVehicle()) {
            return;
        }
        if (player.getPortalCooldown() > 0) {
            player.setPortalCooldown(100);
            return;
        }
        ResourceKey<Level> destinationKey = current.dimension().equals(OUTER_LANDS) ? Level.OVERWORLD : OUTER_LANDS;
        ServerLevel destination = current.getServer().getLevel(destinationKey);
        // A disabled or failed datapack must never strand the player.
        if (destination == null) {
            return;
        }
        Optional<BlockPos> destinationPortal;
        if (destinationKey.equals(OUTER_LANDS)) {
            destinationPortal = findOuterPortal(destination, player.position());
            /*
             * The modern generator is deliberately synchronous here.  A
             * missing portal or an incomplete directly-connected apron is
             * a failed transfer, not permission to enter at the player's
             * same coordinates in a half-generated dimension.
             */
            if (destinationPortal.isEmpty()) {
                player.setPortalCooldown(100);
                return;
            }
            player.getPersistentData().putLong(RETURN_PORTAL_POS, this.worldPosition.asLong());
        } else {
            destinationPortal = rememberedReturnPortal(destination, player);
            if (destinationPortal.isEmpty()) {
                destinationPortal = findLoadedPortal(destination, player.position());
            }
        }
        if (destinationPortal.isEmpty()) {
            player.setPortalCooldown(100);
            return;
        }
        player.setPortalCooldown(100);
        Vec3 arrival = arrivalAtPortal(destination, destinationPortal.orElseThrow());
        if (!EldritchPortalBlockEntity.native$DimensionTravel$move(player, destination, arrival)) {
            return;
        }
        if (destinationKey.equals(OUTER_LANDS)) {
            PlayerKnowledgeService.completeResearchSilently(player, dev.tc4port.thaumcraft.api.research.ResearchKey.parse("ENTEROUTER"), 0);
        } else {
            player.getPersistentData().remove(RETURN_PORTAL_POS);
        }
    }

    private static Optional<BlockPos> findOuterPortal(ServerLevel destination, Vec3 source) {
        int sourceBlockX = (int) Math.floor(source.x);
        int sourceBlockZ = (int) Math.floor(source.z);
        Optional<OuterMazePosition> room = OuterMazeData.get(destination).closestRoomInBlockSquare(sourceBlockX, sourceBlockZ, OuterRoomId.PORTAL, PORTAL_SEARCH_RADIUS_BLOCKS);
        if (room.isPresent()) {
            OuterMazePosition cell = room.get();
            if (!OuterLandsSystem.ensureArrivalArea(destination, cell.x(), cell.z())) {
                return Optional.empty();
            }
            BlockPos portalPos = OuterLandsSystem.portalPosition(cell.x(), cell.z());
            if (isPortal(destination, portalPos)) {
                return Optional.of(portalPos);
            }
            return Optional.empty();
        }
        return Optional.empty();
    }

    private static Optional<BlockPos> rememberedReturnPortal(ServerLevel destination, ServerPlayer player) {
        CompoundTag data = player.getPersistentData();
        if (!data.contains(RETURN_PORTAL_POS, Tag.TAG_LONG)) {
            return Optional.empty();
        }
        BlockPos portalPos = BlockPos.of(data.getLong(RETURN_PORTAL_POS));
        if (isPortal(destination, portalPos)) {
            return Optional.of(portalPos);
        }
        data.remove(RETURN_PORTAL_POS);
        return Optional.empty();
    }

    /**
     * Legacy searched every block in a 257 by world-height by 257 volume.
     * Modern portal blocks are block entities, so loaded-chunk block-entity
     * maps provide the same nearest-portal result without tens of millions
     * of synchronous block-state lookups.
     */
    public static Optional<BlockPos> findLoadedPortal(ServerLevel destination, Vec3 source) {
        int centerChunkX = ((int) Math.floor(source.x)) >> 4;
        int centerChunkZ = ((int) Math.floor(source.z)) >> 4;
        BlockPos closest = null;
        double closestDistance = Double.POSITIVE_INFINITY;
        for (int chunkX = centerChunkX - PORTAL_SEARCH_RADIUS_CHUNKS; chunkX <= centerChunkX + PORTAL_SEARCH_RADIUS_CHUNKS; chunkX++) {
            for (int chunkZ = centerChunkZ - PORTAL_SEARCH_RADIUS_CHUNKS; chunkZ <= centerChunkZ + PORTAL_SEARCH_RADIUS_CHUNKS; chunkZ++) {
                LevelChunk chunk = destination.getChunkSource().getChunkNow(chunkX, chunkZ);
                if (chunk == null) {
                    continue;
                }
                for (BlockEntity blockEntity : chunk.getBlockEntities().values()) {
                    if (!(blockEntity instanceof EldritchPortalBlockEntity)) {
                        continue;
                    }
                    BlockPos pos = blockEntity.getBlockPos();
                    double distance = pos.distToCenterSqr(source);
                    if (distance < closestDistance) {
                        closest = pos;
                        closestDistance = distance;
                    }
                }
            }
        }
        return Optional.ofNullable(closest);
    }

    private static Vec3 arrivalAtPortal(ServerLevel destination, BlockPos pos) {
        return new Vec3(pos.getX() + 0.5 + (destination.random.nextBoolean() ? 1.0 : -1.0), pos.getY(), pos.getZ() + 0.5 + (destination.random.nextBoolean() ? 1.0 : -1.0));
    }

    private static boolean isPortal(ServerLevel destination, BlockPos pos) {
        return destination.getBlockState(pos).is(TCBlocks.byId("eldritch_portal").get());
    }

    public int openCount() {
        return this.openCount;
    }

    public int count() {
        return this.count;
    }

    protected final HolderLookup.Provider persistenceRegistries() {
        if (level != null)
            return level.registryAccess();
        var server = net.minecraftforge.server.ServerLifecycleHooks.getCurrentServer();
        return server != null ? server.registryAccess() : net.minecraft.core.RegistryAccess.fromRegistryOfRegistries(net.minecraft.core.registries.BuiltInRegistries.REGISTRY);
    }

    protected static net.minecraft.network.chat.Component parseCustomNameSafe(String value, HolderLookup.Provider registries) {
        try {
            return net.minecraft.network.chat.Component.Serializer.fromJson(value);
        } catch (RuntimeException exception) {
            return null;
        }
    }

    protected void readItemFields(ItemFields.Input input) {
    }

    public void copyItemFields(ItemFields.Output output) {
    }

    public void applyComponentsFromItemStack(ItemStack stack) {
        readItemFields(ItemFields.from(stack));
    }

    public void removeComponentsFromTag(CompoundTag tag) {
    }

    @Override
    public void saveToItem(ItemStack stack) {
        CompoundTag tag = saveWithoutMetadata();
        {
            net.minecraft.nbt.CompoundTag native$bodyOperand$6141 = tag;
            native$bodyReturn$6143: {
                if (true) {
                }
            }
        }
        net.minecraft.world.item.BlockItem.setBlockEntityData(stack, getType(), tag);
        copyItemFields(ItemFields.to(stack));
    }

    @Override
    public net.minecraft.world.phys.AABB getRenderBoundingBox() {
        return EldritchPortalBlockEntity.native$ClientBlockEntityBounds$bounds(this);
    }

    @Override()
    public void onDataPacket(net.minecraft.network.Connection connection, net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket packet) {
        handleUpdateTag(packet.getTag());
    }

    static private boolean native$DimensionTravel$move(net.minecraft.server.level.ServerPlayer player, net.minecraft.server.level.ServerLevel destination, net.minecraft.world.phys.Vec3 arrival) {
        var moved = player.changeDimension(destination, new net.minecraftforge.common.util.ITeleporter() {

            @Override
            public net.minecraft.world.level.portal.PortalInfo getPortalInfo(net.minecraft.world.entity.Entity entity, net.minecraft.server.level.ServerLevel level, java.util.function.Function<net.minecraft.server.level.ServerLevel, net.minecraft.world.level.portal.PortalInfo> ignored) {
                return new net.minecraft.world.level.portal.PortalInfo(arrival, net.minecraft.world.phys.Vec3.ZERO, player.getYRot(), player.getXRot());
            }

            @Override
            public net.minecraft.world.entity.Entity placeEntity(net.minecraft.world.entity.Entity entity, net.minecraft.server.level.ServerLevel oldLevel, net.minecraft.server.level.ServerLevel newLevel, float yaw, java.util.function.Function<java.lang.Boolean, net.minecraft.world.entity.Entity> reposition) {
                var result = reposition.apply(false);
                result.moveTo(arrival.x, arrival.y, arrival.z, yaw, player.getXRot());
                return result;
            }
        });
        if (moved == null)
            return false;
        destination.getChunkSource().addRegionTicket(net.minecraft.server.level.TicketType.PORTAL, new net.minecraft.world.level.ChunkPos(net.minecraft.core.BlockPos.containing(arrival)), 3, net.minecraft.core.BlockPos.containing(arrival));
        return true;
    }

    @SuppressWarnings({ "rawtypes", "unchecked" })
    static private net.minecraft.world.phys.AABB native$ClientBlockEntityBounds$bounds(net.minecraft.world.level.block.entity.BlockEntity blockEntity) {
        var renderer = net.minecraft.client.Minecraft.getInstance().getBlockEntityRenderDispatcher().getRenderer(blockEntity);
        return renderer instanceof dev.tc4port.thaumcraft.nativeimpl.NativeBlockEntityRenderer shared ? shared.getRenderBoundingBox(blockEntity) : new net.minecraft.world.phys.AABB(blockEntity.getBlockPos());
    }
}
