package dev.tc4port.thaumcraft.api.event;

public record CriticalDecision(boolean isCriticalHit, float getDamageMultiplier) {
}
