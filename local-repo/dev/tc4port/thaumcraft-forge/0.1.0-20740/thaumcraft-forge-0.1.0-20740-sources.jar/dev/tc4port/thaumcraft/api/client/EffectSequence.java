package dev.tc4port.thaumcraft.api.client;

import java.util.Objects;
import net.minecraft.resources.ResourceLocation;

/**
 * Frame addresses for native SpriteSets and independent renderer textures.
 * Layout authored from porting/effect-frame-resources.json by extract_effect_frames.py.
 */
public enum EffectSequence {

    CRUCIBLE_BUBBLE(Sheet.CRUCIBLE_BUBBLE, 0, 1, 2),
    SLIMY_BUBBLE(Sheet.SLIMY_BUBBLE, 0, 1, 2, 3, 4, 5, 6),
    SPARKLE(Sheet.SPARKLE, 0, 1, 2, 3),
    ELDRITCH_WISP(Sheet.ELDRITCH_WISP, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12),
    PRIMAL_CORE(Sheet.HARNESS_ACTIVE, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12),
    WISP_MOTE(Sheet.WISP_MOTE, 0),
    SCAN_RUNE(Sheet.SCAN_RUNE, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15),
    NODE_JAR_FORMATION(Sheet.NODE_JAR_FORMATION, 0, 1, 2, 3, 4, 5, 6, 7, 8),
    FIRE_BAT_SPARK(Sheet.EMBER, 0, 1, 2, 3, 4, 5, 6, 7, 8),
    TAINT_SWARM(Sheet.TAINT_SWARM, 0, 1, 2, 3, 4, 5, 6, 7),
    TUBE_VENT(Sheet.TUBE_VENT, 0, 1, 2, 3, 4),
    SMOKE_SPIRAL(Sheet.TUBE_VENT, 0, 1, 2, 3),
    ESSENTIA_TRAIL(Sheet.ESSENTIA_TRAIL, 0),
    PULSE(Sheet.PULSE, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15),
    ASPECT_ORB(Sheet.ASPECT_ORB, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15),
    ORB_RED(Sheet.ORB_RED, 0, 1, 2, 3, 4, 5),
    ORB_BLUE(Sheet.ORB_BLUE, 0, 1, 2, 3, 4, 5),
    EMBER(Sheet.EMBER, 0, 1, 2, 3, 4, 5, 6, 7, 8),
    HARNESS_FILL(Sheet.HARNESS_FILL, 0),
    HARNESS_BORDER(Sheet.HARNESS_BORDER, 0),
    HARNESS_ACTIVE(Sheet.HARNESS_ACTIVE, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13),
    RUNIC_SHIELD(Sheet.RUNIC_SHIELD, 0),
    GENERIC(slot(Sheet.GENERIC, 0), slot(Sheet.TUBE_VENT, 0), slot(Sheet.TUBE_VENT, 1), slot(Sheet.TUBE_VENT, 2), slot(Sheet.TUBE_VENT, 3), slot(Sheet.TUBE_VENT, 4), slot(Sheet.TAINT_SWARM, 0), slot(Sheet.TAINT_SWARM, 0), slot(Sheet.TAINT_SWARM, 0), slot(Sheet.GENERIC, 1), slot(Sheet.GENERIC, 2), slot(Sheet.GENERIC, 3), slot(Sheet.TAINT_SWARM, 0), slot(Sheet.TAINT_SWARM, 0), slot(Sheet.HARNESS_FILL, 0, 0, 0, 16, 16), slot(Sheet.HARNESS_BORDER, 0, 0, 0, 16, 16), slot(Sheet.CRUCIBLE_BUBBLE, 0), slot(Sheet.CRUCIBLE_BUBBLE, 1), slot(Sheet.CRUCIBLE_BUBBLE, 2), slot(Sheet.TAINT_SWARM, 0), slot(Sheet.TAINT_SWARM, 0), slot(Sheet.GENERIC, 4), slot(Sheet.GENERIC, 5), slot(Sheet.GENERIC, 6), slot(Sheet.GENERIC, 7), slot(Sheet.ESSENTIA_TRAIL, 0), slot(Sheet.RUNIC_SHIELD, 0), slot(Sheet.TAINT_SWARM, 0), slot(Sheet.TAINT_SWARM, 0), slot(Sheet.TAINT_SWARM, 0), slot(Sheet.HARNESS_FILL, 0, 0, 16, 16, 16), slot(Sheet.HARNESS_BORDER, 0, 0, 16, 16, 16), slot(Sheet.HARNESS_ACTIVE, 0), slot(Sheet.HARNESS_ACTIVE, 1), slot(Sheet.HARNESS_ACTIVE, 2), slot(Sheet.HARNESS_ACTIVE, 3), slot(Sheet.HARNESS_ACTIVE, 4), slot(Sheet.HARNESS_ACTIVE, 5), slot(Sheet.HARNESS_ACTIVE, 6), slot(Sheet.HARNESS_ACTIVE, 7), slot(Sheet.HARNESS_ACTIVE, 8), slot(Sheet.HARNESS_ACTIVE, 9), slot(Sheet.HARNESS_ACTIVE, 10), slot(Sheet.HARNESS_ACTIVE, 11), slot(Sheet.HARNESS_ACTIVE, 12), slot(Sheet.HARNESS_ACTIVE, 13), slot(Sheet.HARNESS_FILL, 0, 0, 32, 16, 16), slot(Sheet.HARNESS_BORDER, 0, 0, 32, 16, 16), slot(Sheet.ELDRITCH_WISP, 0), slot(Sheet.ELDRITCH_WISP, 1), slot(Sheet.ELDRITCH_WISP, 2), slot(Sheet.ELDRITCH_WISP, 3), slot(Sheet.ELDRITCH_WISP, 4), slot(Sheet.ELDRITCH_WISP, 5), slot(Sheet.ELDRITCH_WISP, 6), slot(Sheet.ELDRITCH_WISP, 7), slot(Sheet.ELDRITCH_WISP, 8), slot(Sheet.ELDRITCH_WISP, 9), slot(Sheet.ELDRITCH_WISP, 10), slot(Sheet.ELDRITCH_WISP, 11), slot(Sheet.ELDRITCH_WISP, 12), slot(Sheet.GENERIC, 8), slot(Sheet.HARNESS_FILL, 0, 0, 48, 16, 16), slot(Sheet.HARNESS_BORDER, 0, 0, 48, 16, 16), slot(Sheet.SPARKLE, 0), slot(Sheet.SPARKLE, 1), slot(Sheet.SPARKLE, 2), slot(Sheet.SPARKLE, 3), slot(Sheet.TAINT_SWARM, 0), slot(Sheet.TAINT_SWARM, 0), slot(Sheet.TAINT_SWARM, 0), slot(Sheet.TAINT_SWARM, 0), slot(Sheet.TAINT_SWARM, 1), slot(Sheet.TAINT_SWARM, 2), slot(Sheet.TAINT_SWARM, 3), slot(Sheet.TAINT_SWARM, 4), slot(Sheet.TAINT_SWARM, 5), slot(Sheet.TAINT_SWARM, 6), slot(Sheet.TAINT_SWARM, 7), slot(Sheet.TAINT_SWARM, 8), slot(Sheet.PULSE, 0), slot(Sheet.PULSE, 1), slot(Sheet.PULSE, 2), slot(Sheet.PULSE, 3), slot(Sheet.PULSE, 4), slot(Sheet.PULSE, 5), slot(Sheet.PULSE, 6), slot(Sheet.PULSE, 7), slot(Sheet.PULSE, 8), slot(Sheet.PULSE, 9), slot(Sheet.PULSE, 10), slot(Sheet.PULSE, 11), slot(Sheet.PULSE, 12), slot(Sheet.PULSE, 13), slot(Sheet.PULSE, 14), slot(Sheet.PULSE, 15), slot(Sheet.SCAN_RUNE, 0), slot(Sheet.SCAN_RUNE, 1), slot(Sheet.SCAN_RUNE, 2), slot(Sheet.SCAN_RUNE, 3), slot(Sheet.SCAN_RUNE, 4), slot(Sheet.SCAN_RUNE, 5), slot(Sheet.SCAN_RUNE, 6), slot(Sheet.SCAN_RUNE, 7), slot(Sheet.SCAN_RUNE, 8), slot(Sheet.SCAN_RUNE, 9), slot(Sheet.SCAN_RUNE, 10), slot(Sheet.SCAN_RUNE, 11), slot(Sheet.SCAN_RUNE, 12), slot(Sheet.SCAN_RUNE, 13), slot(Sheet.SCAN_RUNE, 14), slot(Sheet.SCAN_RUNE, 15), slot(Sheet.NODE_JAR_FORMATION, 0), slot(Sheet.NODE_JAR_FORMATION, 1), slot(Sheet.NODE_JAR_FORMATION, 2), slot(Sheet.NODE_JAR_FORMATION, 3), slot(Sheet.NODE_JAR_FORMATION, 4), slot(Sheet.NODE_JAR_FORMATION, 5), slot(Sheet.NODE_JAR_FORMATION, 6), slot(Sheet.NODE_JAR_FORMATION, 7), slot(Sheet.NODE_JAR_FORMATION, 8), slot(Sheet.TAINT_SWARM, 0), slot(Sheet.TAINT_SWARM, 0), slot(Sheet.TAINT_SWARM, 0), slot(Sheet.TAINT_SWARM, 0), slot(Sheet.TAINT_SWARM, 0), slot(Sheet.TAINT_SWARM, 0), slot(Sheet.TAINT_SWARM, 0), slot(Sheet.ASPECT_ORB, 0), slot(Sheet.ASPECT_ORB, 1), slot(Sheet.ASPECT_ORB, 2), slot(Sheet.ASPECT_ORB, 3), slot(Sheet.ASPECT_ORB, 4), slot(Sheet.ASPECT_ORB, 5), slot(Sheet.ASPECT_ORB, 6), slot(Sheet.ASPECT_ORB, 7), slot(Sheet.ASPECT_ORB, 8), slot(Sheet.ASPECT_ORB, 9), slot(Sheet.ASPECT_ORB, 10), slot(Sheet.ASPECT_ORB, 11), slot(Sheet.ASPECT_ORB, 12), slot(Sheet.ASPECT_ORB, 13), slot(Sheet.ASPECT_ORB, 14), slot(Sheet.ASPECT_ORB, 15), slot(Sheet.SLIMY_BUBBLE, 0), slot(Sheet.SLIMY_BUBBLE, 1), slot(Sheet.SLIMY_BUBBLE, 2), slot(Sheet.SLIMY_BUBBLE, 3), slot(Sheet.SLIMY_BUBBLE, 4), slot(Sheet.SLIMY_BUBBLE, 5), slot(Sheet.SLIMY_BUBBLE, 6), slot(Sheet.EMBER, 0), slot(Sheet.EMBER, 1), slot(Sheet.EMBER, 2), slot(Sheet.EMBER, 3), slot(Sheet.EMBER, 4), slot(Sheet.EMBER, 5), slot(Sheet.EMBER, 6), slot(Sheet.EMBER, 7), slot(Sheet.EMBER, 8), slot(Sheet.GENERIC_SPARK, 0), slot(Sheet.GENERIC_SPARK, 1), slot(Sheet.GENERIC_SPARK, 2), slot(Sheet.GENERIC_SPARK, 3), slot(Sheet.GENERIC_SPARK, 4), slot(Sheet.GENERIC_SPARK, 5), slot(Sheet.GENERIC_SPARK, 6), slot(Sheet.GENERIC_SPARK, 7), slot(Sheet.GENERIC_SPARK, 8), slot(Sheet.GENERIC, 9), slot(Sheet.TAINT_SWARM, 0), slot(Sheet.TAINT_SWARM, 0), slot(Sheet.TAINT_SWARM, 0), slot(Sheet.TAINT_SWARM, 0), slot(Sheet.TAINT_SWARM, 0), slot(Sheet.TAINT_SWARM, 0), slot(Sheet.GENERIC, 10), slot(Sheet.GENERIC, 11), slot(Sheet.GENERIC, 12), slot(Sheet.GENERIC, 13), slot(Sheet.GENERIC, 14), slot(Sheet.GENERIC, 15), slot(Sheet.GENERIC, 16), slot(Sheet.GENERIC, 17), slot(Sheet.GENERIC, 18), slot(Sheet.GENERIC, 19), slot(Sheet.GENERIC, 20), slot(Sheet.GENERIC, 21), slot(Sheet.TAINT_SWARM, 0), slot(Sheet.TAINT_SWARM, 0), slot(Sheet.TAINT_SWARM, 0), slot(Sheet.TAINT_SWARM, 0), slot(Sheet.TAINT_SWARM, 0), slot(Sheet.TAINT_SWARM, 0), slot(Sheet.ORB_RED, 0, 0, 0, 16, 16), slot(Sheet.ORB_RED, 0, 16, 0, 16, 16), slot(Sheet.ORB_RED, 1, 0, 0, 16, 16), slot(Sheet.ORB_RED, 1, 16, 0, 16, 16), slot(Sheet.ORB_RED, 2, 0, 0, 16, 16), slot(Sheet.ORB_RED, 2, 16, 0, 16, 16), slot(Sheet.ORB_RED, 3, 0, 0, 16, 16), slot(Sheet.ORB_RED, 3, 16, 0, 16, 16), slot(Sheet.ORB_RED, 4, 0, 0, 16, 16), slot(Sheet.ORB_RED, 4, 16, 0, 16, 16), slot(Sheet.ORB_RED, 5, 0, 0, 16, 16), slot(Sheet.ORB_RED, 5, 16, 0, 16, 16), slot(Sheet.GENERIC, 22), slot(Sheet.GENERIC, 23), slot(Sheet.TAINT_SWARM, 0), slot(Sheet.TAINT_SWARM, 0), slot(Sheet.ORB_RED, 0, 0, 16, 16, 16), slot(Sheet.ORB_RED, 0, 16, 16, 16, 16), slot(Sheet.ORB_RED, 1, 0, 16, 16, 16), slot(Sheet.ORB_RED, 1, 16, 16, 16, 16), slot(Sheet.ORB_RED, 2, 0, 16, 16, 16), slot(Sheet.ORB_RED, 2, 16, 16, 16, 16), slot(Sheet.ORB_RED, 3, 0, 16, 16, 16), slot(Sheet.ORB_RED, 3, 16, 16, 16, 16), slot(Sheet.ORB_RED, 4, 0, 16, 16, 16), slot(Sheet.ORB_RED, 4, 16, 16, 16, 16), slot(Sheet.ORB_RED, 5, 0, 16, 16, 16), slot(Sheet.ORB_RED, 5, 16, 16, 16, 16), slot(Sheet.GENERIC, 24), slot(Sheet.GENERIC, 25), slot(Sheet.WISP_MOTE, 0, 0, 0, 16, 16), slot(Sheet.WISP_MOTE, 0, 16, 0, 16, 16), slot(Sheet.ORB_BLUE, 0, 0, 0, 16, 16), slot(Sheet.ORB_BLUE, 0, 16, 0, 16, 16), slot(Sheet.ORB_BLUE, 1, 0, 0, 16, 16), slot(Sheet.ORB_BLUE, 1, 16, 0, 16, 16), slot(Sheet.ORB_BLUE, 2, 0, 0, 16, 16), slot(Sheet.ORB_BLUE, 2, 16, 0, 16, 16), slot(Sheet.ORB_BLUE, 3, 0, 0, 16, 16), slot(Sheet.ORB_BLUE, 3, 16, 0, 16, 16), slot(Sheet.ORB_BLUE, 4, 0, 0, 16, 16), slot(Sheet.ORB_BLUE, 4, 16, 0, 16, 16), slot(Sheet.ORB_BLUE, 5, 0, 0, 16, 16), slot(Sheet.ORB_BLUE, 5, 16, 0, 16, 16), slot(Sheet.GENERIC, 26), slot(Sheet.GENERIC, 27), slot(Sheet.WISP_MOTE, 0, 0, 16, 16, 16), slot(Sheet.WISP_MOTE, 0, 16, 16, 16, 16), slot(Sheet.ORB_BLUE, 0, 0, 16, 16, 16), slot(Sheet.ORB_BLUE, 0, 16, 16, 16, 16), slot(Sheet.ORB_BLUE, 1, 0, 16, 16, 16), slot(Sheet.ORB_BLUE, 1, 16, 16, 16, 16), slot(Sheet.ORB_BLUE, 2, 0, 16, 16, 16), slot(Sheet.ORB_BLUE, 2, 16, 16, 16, 16), slot(Sheet.ORB_BLUE, 3, 0, 16, 16, 16), slot(Sheet.ORB_BLUE, 3, 16, 16, 16, 16), slot(Sheet.ORB_BLUE, 4, 0, 16, 16, 16), slot(Sheet.ORB_BLUE, 4, 16, 16, 16, 16), slot(Sheet.ORB_BLUE, 5, 0, 16, 16, 16), slot(Sheet.ORB_BLUE, 5, 16, 16, 16, 16), slot(Sheet.TAINT_SWARM, 0), slot(Sheet.TAINT_SWARM, 0)),
    SPARKS_0(Sheet.SPARKS_0, 0, 1, 2, 3, 4, 5, 6, 7),
    SPARKS_1(Sheet.SPARKS_1, 0, 1, 2, 3, 4, 5, 6, 6),
    SPARKS_2(Sheet.SPARKS_2, 0, 1, 2, 3, 4, 5, 6, 7),
    FIREBALL(Sheet.FIREBALL, 0, 1, 2, 3),
    WISP_BURST(Sheet.WISP_BURST, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31),
    WARD_HIT(Sheet.WARD_HIT, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15),
    TAINT_DROPLET(Sheet.TAINT_DROPLET, 0, 1, 2),
    VIS_SPARKLE(Sheet.ASPECT_ORB, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15);

    private final FrameSlot[] frames;

    EffectSequence(Sheet sheet, int... cells) {
        frames = new FrameSlot[cells.length];
        for (int i = 0; i < cells.length; i++) frames[i] = slot(sheet, cells[i]);
    }

    EffectSequence(FrameSlot... frames) {
        this.frames = frames;
    }

    private static FrameSlot slot(Sheet sheet, int cell) {
        return slot(sheet, cell, 0, 0, sheet.width, sheet.height);
    }

    private static FrameSlot slot(Sheet sheet, int cell, int x, int y, int width, int height) {
        return new FrameSlot(sheet, cell, x, y, width, height);
    }

    private record FrameSlot(Sheet sheet, int cell, int x, int y, int width, int height) {
    }

    public int frames() {
        return frames.length;
    }

    public int width() {
        return frames[0].width;
    }

    public int height() {
        return frames[0].height;
    }

    public int padding() {
        return frames[0].sheet.padding;
    }

    public ResourceLocation texture(int frame) {
        return frames[frame].sheet.texture;
    }

    public int spriteWidth(int frame) {
        return frames[frame].sheet.width;
    }

    public int spriteHeight(int frame) {
        return frames[frame].sheet.height;
    }

    public int spriteTextureWidth(int frame) {
        return frames[frame].sheet.cells[frames[frame].cell].spriteWidth;
    }

    public int spriteTextureHeight(int frame) {
        return frames[frame].sheet.cells[frames[frame].cell].spriteHeight;
    }

    public int spriteX(int frame) {
        return frames[frame].sheet.cells[frames[frame].cell].spriteX;
    }

    public int spriteY(int frame) {
        return frames[frame].sheet.cells[frames[frame].cell].spriteY;
    }

    /**
     * View coordinates inside the complete native sprite's content.
     */
    public float localU(int frame, float fraction) {
        FrameSlot selected = frames[frame];
        return (selected.x + fraction * selected.width) / selected.sheet.width;
    }

    public float localV(int frame, float fraction) {
        FrameSlot selected = frames[frame];
        return (selected.y + fraction * selected.height) / selected.sheet.height;
    }

    /**
     * Native unstitch sprite ID, independent of the direct renderer's texture.
     */
    public ResourceLocation sprite(int frame) {
        FrameSlot selected = frames[frame];
        return selected.sheet.sprites[selected.cell];
    }

    public int x(int frame) {
        FrameSlot selected = frames[frame];
        return selected.sheet.cells[selected.cell].x + selected.x;
    }

    public int y(int frame) {
        return frames[frame].sheet.cells[frames[frame].cell].y + frames[frame].y;
    }

    public int textureWidth(int frame) {
        return frames[frame].sheet.textureWidth;
    }

    public int textureHeight(int frame) {
        return frames[frame].sheet.textureHeight;
    }

    /**
     * Normalized U inside one frame's content on its direct renderer texture.
     */
    public float u(int frame, float contentFraction) {
        return (x(frame) + contentFraction * frames[frame].width) / textureWidth(frame);
    }

    /**
     * Normalized V inside one frame's content on its direct renderer texture.
     */
    public float v(int frame, float contentFraction) {
        return (y(frame) + contentFraction * frames[frame].height) / textureHeight(frame);
    }

    private enum Sheet {

        CRUCIBLE_BUBBLE("crucible_bubble", "misc/particles", 200, 440, 16, 16, 2, cell(178, 114, 20, 20, 2, 2), cell(38, 130, 20, 20, 2, 2), cell(2, 142, 20, 20, 2, 2)),
        SLIMY_BUBBLE("slimy_bubble", "misc/particles", 200, 440, 16, 16, 2, cell(122, 330, 20, 20, 2, 2), cell(142, 330, 20, 20, 2, 2), cell(162, 334, 20, 20, 2, 2), cell(182, 334, 20, 20, 2, 2), cell(22, 350, 20, 20, 2, 2), cell(2, 362, 20, 20, 2, 2), cell(42, 350, 20, 20, 2, 2)),
        SPARKLE("sparkle", "misc/particles", 200, 440, 16, 16, 2, cell(142, 190, 20, 20, 2, 2), cell(162, 194, 20, 20, 2, 2), cell(182, 194, 20, 20, 2, 2), cell(22, 210, 20, 20, 2, 2)),
        ELDRITCH_WISP("eldritch_wisp", "effect/eldritch_wisp", 260, 20, 16, 16, 2, cell(2, 2, 20, 20, 2, 2), cell(22, 2, 20, 20, 2, 2), cell(42, 2, 20, 20, 2, 2), cell(62, 2, 20, 20, 2, 2), cell(82, 2, 20, 20, 2, 2), cell(102, 2, 20, 20, 2, 2), cell(122, 2, 20, 20, 2, 2), cell(142, 2, 20, 20, 2, 2), cell(162, 2, 20, 20, 2, 2), cell(182, 2, 20, 20, 2, 2), cell(202, 2, 20, 20, 2, 2), cell(222, 2, 20, 20, 2, 2), cell(242, 2, 20, 20, 2, 2)),
        HARNESS_ACTIVE("harness_active", "effect/harness_active", 280, 20, 16, 16, 2, cell(2, 2, 20, 20, 2, 2), cell(22, 2, 20, 20, 2, 2), cell(42, 2, 20, 20, 2, 2), cell(62, 2, 20, 20, 2, 2), cell(82, 2, 20, 20, 2, 2), cell(102, 2, 20, 20, 2, 2), cell(122, 2, 20, 20, 2, 2), cell(142, 2, 20, 20, 2, 2), cell(162, 2, 20, 20, 2, 2), cell(182, 2, 20, 20, 2, 2), cell(202, 2, 20, 20, 2, 2), cell(222, 2, 20, 20, 2, 2), cell(242, 2, 20, 20, 2, 2), cell(262, 2, 20, 20, 2, 2)),
        WISP_MOTE("wisp_mote", "misc/particles", 200, 440, 32, 32, 2, cell(114, 38, 36, 36, 2, 2)),
        SCAN_RUNE("scan_rune", "effect/scan_rune", 320, 20, 16, 16, 2, cell(2, 2, 20, 20, 2, 2), cell(22, 2, 20, 20, 2, 2), cell(42, 2, 20, 20, 2, 2), cell(62, 2, 20, 20, 2, 2), cell(82, 2, 20, 20, 2, 2), cell(102, 2, 20, 20, 2, 2), cell(122, 2, 20, 20, 2, 2), cell(142, 2, 20, 20, 2, 2), cell(162, 2, 20, 20, 2, 2), cell(182, 2, 20, 20, 2, 2), cell(202, 2, 20, 20, 2, 2), cell(222, 2, 20, 20, 2, 2), cell(242, 2, 20, 20, 2, 2), cell(262, 2, 20, 20, 2, 2), cell(282, 2, 20, 20, 2, 2), cell(302, 2, 20, 20, 2, 2)),
        NODE_JAR_FORMATION("node_jar_formation", "misc/particles", 200, 440, 16, 16, 2, cell(2, 302, 20, 20, 2, 2), cell(42, 290, 20, 20, 2, 2), cell(62, 290, 20, 20, 2, 2), cell(82, 290, 20, 20, 2, 2), cell(102, 290, 20, 20, 2, 2), cell(122, 290, 20, 20, 2, 2), cell(142, 290, 20, 20, 2, 2), cell(162, 294, 20, 20, 2, 2), cell(182, 294, 20, 20, 2, 2)),
        GENERIC_SPARK("generic_spark", "misc/particles", 200, 440, 16, 16, 2, cell(42, 370, 20, 20, 2, 2), cell(62, 370, 20, 20, 2, 2), cell(82, 370, 20, 20, 2, 2), cell(102, 370, 20, 20, 2, 2), cell(122, 370, 20, 20, 2, 2), cell(142, 370, 20, 20, 2, 2), cell(162, 374, 20, 20, 2, 2), cell(182, 374, 20, 20, 2, 2), cell(22, 390, 20, 20, 2, 2)),
        TAINT_SWARM("taint_swarm", "effect/taint_swarm", 180, 20, 16, 16, 2, cell(2, 2, 20, 20, 2, 2), cell(22, 2, 20, 20, 2, 2), cell(42, 2, 20, 20, 2, 2), cell(62, 2, 20, 20, 2, 2), cell(82, 2, 20, 20, 2, 2), cell(102, 2, 20, 20, 2, 2), cell(122, 2, 20, 20, 2, 2), cell(142, 2, 20, 20, 2, 2), cell(162, 2, 20, 20, 2, 2)),
        TUBE_VENT("tube_vent", "misc/particles", 200, 440, 16, 16, 2, cell(182, 94, 20, 20, 2, 2), cell(38, 110, 20, 20, 2, 2), cell(58, 110, 20, 20, 2, 2), cell(78, 110, 20, 20, 2, 2), cell(98, 110, 20, 20, 2, 2)),
        ESSENTIA_TRAIL("essentia_trail", "misc/particles", 200, 440, 16, 16, 2, cell(138, 130, 20, 20, 2, 2)),
        PULSE("pulse", "effect/pulse", 320, 20, 16, 16, 2, cell(2, 2, 20, 20, 2, 2), cell(22, 2, 20, 20, 2, 2), cell(42, 2, 20, 20, 2, 2), cell(62, 2, 20, 20, 2, 2), cell(82, 2, 20, 20, 2, 2), cell(102, 2, 20, 20, 2, 2), cell(122, 2, 20, 20, 2, 2), cell(142, 2, 20, 20, 2, 2), cell(162, 2, 20, 20, 2, 2), cell(182, 2, 20, 20, 2, 2), cell(202, 2, 20, 20, 2, 2), cell(222, 2, 20, 20, 2, 2), cell(242, 2, 20, 20, 2, 2), cell(262, 2, 20, 20, 2, 2), cell(282, 2, 20, 20, 2, 2), cell(302, 2, 20, 20, 2, 2)),
        ASPECT_ORB("aspect_orb", "effect/aspect_orb", 320, 20, 16, 16, 2, cell(2, 2, 20, 20, 2, 2), cell(22, 2, 20, 20, 2, 2), cell(42, 2, 20, 20, 2, 2), cell(62, 2, 20, 20, 2, 2), cell(82, 2, 20, 20, 2, 2), cell(102, 2, 20, 20, 2, 2), cell(122, 2, 20, 20, 2, 2), cell(142, 2, 20, 20, 2, 2), cell(162, 2, 20, 20, 2, 2), cell(182, 2, 20, 20, 2, 2), cell(202, 2, 20, 20, 2, 2), cell(222, 2, 20, 20, 2, 2), cell(242, 2, 20, 20, 2, 2), cell(262, 2, 20, 20, 2, 2), cell(282, 2, 20, 20, 2, 2), cell(302, 2, 20, 20, 2, 2)),
        ORB_RED("orb_red", "effect/orb_red", 216, 36, 32, 32, 2, cell(2, 2, 36, 36, 2, 2), cell(38, 2, 36, 36, 2, 2), cell(74, 2, 36, 36, 2, 2), cell(110, 2, 36, 36, 2, 2), cell(146, 2, 36, 36, 2, 2), cell(182, 2, 36, 36, 2, 2)),
        ORB_BLUE("orb_blue", "effect/orb_blue", 216, 36, 32, 32, 2, cell(2, 2, 36, 36, 2, 2), cell(38, 2, 36, 36, 2, 2), cell(74, 2, 36, 36, 2, 2), cell(110, 2, 36, 36, 2, 2), cell(146, 2, 36, 36, 2, 2), cell(182, 2, 36, 36, 2, 2)),
        EMBER("ember", "effect/ember", 180, 20, 16, 16, 2, cell(2, 2, 20, 20, 2, 2), cell(22, 2, 20, 20, 2, 2), cell(42, 2, 20, 20, 2, 2), cell(62, 2, 20, 20, 2, 2), cell(82, 2, 20, 20, 2, 2), cell(102, 2, 20, 20, 2, 2), cell(122, 2, 20, 20, 2, 2), cell(142, 2, 20, 20, 2, 2), cell(162, 2, 20, 20, 2, 2)),
        HARNESS_FILL("harness_fill", "misc/particles", 200, 440, 16, 64, 2, cell(2, 2, 20, 68, 2, 2)),
        HARNESS_BORDER("harness_border", "misc/particles", 200, 440, 16, 64, 2, cell(22, 2, 20, 68, 2, 2)),
        RUNIC_SHIELD("runic_shield", "effect/runic_shield", 20, 20, 16, 16, 2, cell(2, 2, 20, 20, 2, 2)),
        GENERIC("generic", "misc/particles", 200, 440, 16, 16, 2, cell(182, 74, 20, 20, 2, 2), cell(118, 110, 20, 20, 2, 2), cell(138, 110, 20, 20, 2, 2), cell(158, 110, 20, 20, 2, 2), cell(58, 130, 20, 20, 2, 2), cell(78, 130, 20, 20, 2, 2), cell(98, 130, 20, 20, 2, 2), cell(118, 130, 20, 20, 2, 2), cell(122, 190, 20, 20, 2, 2), cell(2, 402, 20, 20, 2, 2), cell(42, 390, 20, 20, 2, 2), cell(62, 390, 20, 20, 2, 2), cell(82, 390, 20, 20, 2, 2), cell(102, 390, 20, 20, 2, 2), cell(122, 390, 20, 20, 2, 2), cell(142, 390, 20, 20, 2, 2), cell(162, 394, 20, 20, 2, 2), cell(182, 394, 20, 20, 2, 2), cell(22, 410, 20, 20, 2, 2), cell(2, 422, 20, 20, 2, 2), cell(42, 410, 20, 20, 2, 2), cell(62, 410, 20, 20, 2, 2), cell(82, 410, 20, 20, 2, 2), cell(102, 410, 20, 20, 2, 2), cell(122, 410, 20, 20, 2, 2), cell(142, 410, 20, 20, 2, 2), cell(162, 414, 20, 20, 2, 2), cell(182, 414, 20, 20, 2, 2)),
        SPARKS_0("sparks_0", "misc/particles_secondary", 208, 584, 64, 64, 2, cell(2, 2, 68, 68, 2, 2), cell(70, 2, 68, 68, 2, 2), cell(138, 2, 68, 68, 2, 2), cell(2, 70, 68, 68, 2, 2), cell(70, 70, 68, 68, 2, 2), cell(138, 70, 68, 68, 2, 2), cell(2, 138, 68, 68, 2, 2), cell(70, 138, 68, 68, 2, 2)),
        SPARKS_1("sparks_1", "misc/particles_secondary", 208, 584, 64, 64, 2, cell(138, 138, 68, 68, 2, 2), cell(2, 206, 68, 68, 2, 2), cell(70, 206, 68, 68, 2, 2), cell(138, 206, 68, 68, 2, 2), cell(2, 274, 68, 68, 2, 2), cell(70, 274, 68, 68, 2, 2), cell(138, 274, 68, 68, 2, 2)),
        SPARKS_2("sparks_2", "misc/particles_secondary", 208, 584, 64, 64, 2, cell(2, 342, 68, 68, 2, 2), cell(70, 342, 68, 68, 2, 2), cell(138, 342, 68, 68, 2, 2), cell(2, 410, 68, 68, 2, 2), cell(70, 410, 68, 68, 2, 2), cell(138, 410, 68, 68, 2, 2), cell(2, 478, 68, 68, 2, 2), cell(70, 478, 68, 68, 2, 2)),
        FIREBALL("fireball", "effect/fireball", 144, 36, 32, 32, 2, cell(2, 2, 36, 36, 2, 2), cell(38, 2, 36, 36, 2, 2), cell(74, 2, 36, 36, 2, 2), cell(110, 2, 36, 36, 2, 2)),
        WISP_BURST("wisp_burst", "misc/nodes", 1088, 1088, 64, 64, 2, cell(70, 954, 68, 68, 2, 2), cell(138, 954, 68, 68, 2, 2), cell(206, 954, 68, 68, 2, 2), cell(274, 954, 68, 68, 2, 2), cell(342, 954, 68, 68, 2, 2), cell(410, 954, 68, 68, 2, 2), cell(478, 954, 68, 68, 2, 2), cell(546, 954, 68, 68, 2, 2), cell(614, 954, 68, 68, 2, 2), cell(682, 954, 68, 68, 2, 2), cell(750, 954, 68, 68, 2, 2), cell(818, 954, 68, 68, 2, 2), cell(886, 954, 68, 68, 2, 2), cell(954, 954, 68, 68, 2, 2), cell(1022, 954, 68, 68, 2, 2), cell(2, 1022, 68, 68, 2, 2), cell(70, 1022, 68, 68, 2, 2), cell(138, 1022, 68, 68, 2, 2), cell(206, 1022, 68, 68, 2, 2), cell(274, 1022, 68, 68, 2, 2), cell(342, 1022, 68, 68, 2, 2), cell(410, 1022, 68, 68, 2, 2), cell(478, 1022, 68, 68, 2, 2), cell(546, 1022, 68, 68, 2, 2), cell(614, 1022, 68, 68, 2, 2), cell(682, 1022, 68, 68, 2, 2), cell(750, 1022, 68, 68, 2, 2), cell(818, 1022, 68, 68, 2, 2), cell(886, 1022, 68, 68, 2, 2), cell(954, 1022, 68, 68, 2, 2), cell(1022, 1022, 68, 68, 2, 2), cell(2, 954, 68, 68, 2, 2)),
        WARD_HIT("ward_hit", "effect/ward_hit", 2112, 132, 128, 128, 2, cell(2, 2, 132, 132, 2, 2), cell(134, 2, 132, 132, 2, 2), cell(266, 2, 132, 132, 2, 2), cell(398, 2, 132, 132, 2, 2), cell(530, 2, 132, 132, 2, 2), cell(662, 2, 132, 132, 2, 2), cell(794, 2, 132, 132, 2, 2), cell(926, 2, 132, 132, 2, 2), cell(1058, 2, 132, 132, 2, 2), cell(1190, 2, 132, 132, 2, 2), cell(1322, 2, 132, 132, 2, 2), cell(1454, 2, 132, 132, 2, 2), cell(1586, 2, 132, 132, 2, 2), cell(1718, 2, 132, 132, 2, 2), cell(1850, 2, 132, 132, 2, 2), cell(1982, 2, 132, 132, 2, 2)),
        TAINT_DROPLET("taint_droplet", "particle/taint_droplet_frame_atlas", 128, 128, 8, 8, 2, cell(0, 56, 10, 12, 0, 2), cell(8, 56, 12, 12, 2, 2), cell(16, 56, 12, 12, 2, 2));

        private final int width, height, padding, textureWidth, textureHeight;

        private final ResourceLocation texture;

        private final ResourceLocation[] sprites;

        private final Cell[] cells;

        Sheet(String name, String textureName, int textureWidth, int textureHeight, int width, int height, int padding, Cell... cells) {
            this.width = width;
            this.height = height;
            this.padding = padding;
            this.textureWidth = textureWidth;
            this.textureHeight = textureHeight;
            this.cells = cells;
            texture = id("textures/" + textureName + ".png");
            sprites = new ResourceLocation[cells.length];
            for (int i = 0; i < cells.length; i++) {
                sprites[i] = id("effect/" + name + "/" + String.format(java.util.Locale.ROOT, "%03d", i));
            }
        }
    }

    private record Cell(int x, int y, int spriteWidth, int spriteHeight, int spriteX, int spriteY) {
    }

    private static Cell cell(int x, int y, int width, int height, int contentX, int contentY) {
        return new Cell(x, y, width, height, contentX, contentY);
    }

    private static ResourceLocation id(String path) {
        return Objects.requireNonNull(ResourceLocation.tryBuild("thaumcraft", path));
    }
}
