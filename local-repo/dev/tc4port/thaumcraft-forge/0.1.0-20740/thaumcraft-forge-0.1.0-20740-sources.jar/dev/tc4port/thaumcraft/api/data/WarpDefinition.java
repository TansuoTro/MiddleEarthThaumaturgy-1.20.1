package dev.tc4port.thaumcraft.api.data;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;

/**
 * Reloadable item warp attached through NeoForge item data maps.
 */
public record WarpDefinition(int amount) {

    public static final Codec<WarpDefinition> CODEC = RecordCodecBuilder.create(instance -> instance.group(Codec.intRange(0, Integer.MAX_VALUE).fieldOf("amount").forGetter(WarpDefinition::amount)).apply(instance, WarpDefinition::new));

    public WarpDefinition {
        if (amount < 0) {
            throw new IllegalArgumentException("Warp amount must be non-negative");
        }
    }
}
