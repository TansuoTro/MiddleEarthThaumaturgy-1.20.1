package dev.tc4port.thaumcraft.block.entity;

import dev.tc4port.thaumcraft.registry.TCBlockEntities;
import dev.tc4port.thaumcraft.registry.TCSounds;
import java.util.Comparator;
import java.util.List;
import javax.annotation.Nullable;
import net.minecraft.core.BlockPos;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.ExperienceOrb;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import java.lang.System;
import java.lang.Math;
import dev.tc4port.thaumcraft.nativeimpl.state.ItemFields;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityType;

/**
 * Method-for-method port of TC4's TileJarBrain experience store and gaze.
 */
public final class BrainJarBlockEntity extends net.minecraft.world.level.block.entity.BlockEntity implements dev.tc4port.thaumcraft.api.machine.BrainJarView, ItemFields.Source {

    public static final int MAX_EXPERIENCE = 2_000;

    public static int configuredMaximumExperience() {
        return dev.tc4port.thaumcraft.common.TCGameplayParameters.MACHINES_BRAIN_JAR_CAPACITY.intValue();
    }

    private static final String EXPERIENCE_TAG = "XP";

    private int experience;

    private int observedCapacity = configuredMaximumExperience();

    private boolean retainedSurplus;

    private int eatDelay;

    private float previousRotation;

    private float rotation;

    private float targetRotation;

    private long nextSigh = System.currentTimeMillis() + 1_500L;

    public BrainJarBlockEntity(BlockPos pos, BlockState state) {
        super(TCBlockEntities.BRAIN_JAR.get(), pos, state);
    }

    public int experience() {
        return this.experience;
    }

    public float previousRotation() {
        return this.previousRotation;
    }

    public float rotation() {
        return this.rotation;
    }

    public void setEatDelay(int ticks) {
        this.eatDelay = Math.max(0, ticks);
    }

    public void setExperience(int experience) {
        this.experience = Math.max(0, experience);
        this.changedAndSync();
    }

    public int comparatorOutput() {
        float ratio = (float) this.experience / configuredMaximumExperience();
        return Math.min(15, Mth.floor(ratio * 14.0F) + (this.experience > 0 ? 1 : 0));
    }

    public static void tick(Level level, BlockPos pos, BlockState state, BrainJarBlockEntity jar) {
        int capacity = configuredMaximumExperience();
        boolean capacityChanged = capacity != jar.observedCapacity;
        int previousExperience = jar.experience;
        if (capacity < jar.observedCapacity && jar.experience > capacity)
            jar.retainedSurplus = true;
        jar.observedCapacity = capacity;
        if (jar.experience <= capacity)
            jar.retainedSurplus = false;
        if (!jar.retainedSurplus && jar.experience > capacity)
            jar.experience = capacity;
        if (!level.isClientSide && (capacityChanged || previousExperience != jar.experience))
            jar.changedAndSync();
        ExperienceOrb closest = jar.experience < configuredMaximumExperience() ? jar.closestExperienceOrb() : null;
        if (level instanceof ServerLevel serverLevel && closest != null && jar.eatDelay == 0 && serverLevel.isPositionEntityTicking(closest.blockPosition())) {
            /*
             * TileJarBrain divided these deltas by seven, squared
             * (1-distance), then used 0.15/0.33/0.15 acceleration.
             */
            double x = (pos.getX() + 0.5 - closest.getX()) / 7.0;
            double y = (pos.getY() + 0.5 - closest.getY()) / 7.0;
            double z = (pos.getZ() + 0.5 - closest.getZ()) / 7.0;
            double distance = Math.sqrt(x * x + y * y + z * z);
            double attraction = 1.0 - distance;
            if (attraction > 0.0 && distance > 1.0E-7) {
                attraction *= attraction;
                closest.push(x / distance * attraction * 0.15, y / distance * attraction * 0.33, z / distance * attraction * 0.15);
            }
        }
        if (level.isClientSide) {
            jar.clientRotation(closest);
        } else if (closest == null) {
            jar.serverSigh();
        }
        if (jar.eatDelay > 0) {
            jar.eatDelay--;
        } else if (!level.isClientSide && jar.experience < configuredMaximumExperience()) {
            jar.consumeTouchingOrbs();
        }
    }

    private void serverSigh() {
        long now = System.currentTimeMillis();
        if (this.level.getNearestPlayer(this.worldPosition.getX() + 0.5, this.worldPosition.getY() + 0.5, this.worldPosition.getZ() + 0.5, 6.0, false) != null && this.nextSigh < now) {
            this.level.playSound(null, this.worldPosition.getX() + 0.5, this.worldPosition.getY() + 0.5, this.worldPosition.getZ() + 0.5, TCSounds.BRAIN.get(), SoundSource.BLOCKS, 0.15F, 0.8F + this.level.random.nextFloat() * 0.4F);
            this.nextSigh = now + 5_000L + this.level.random.nextInt(25_000);
        }
    }

    private void clientRotation(@Nullable ExperienceOrb closest) {
        if (this.level == null) {
            return;
        }
        this.previousRotation = this.rotation;
        Entity watched = closest;
        if (watched == null) {
            watched = this.level.getNearestPlayer(this.worldPosition.getX() + 0.5, this.worldPosition.getY() + 0.5, this.worldPosition.getZ() + 0.5, 6.0, false);
        }
        if (watched != null) {
            double x = watched.getX() - (this.worldPosition.getX() + 0.5);
            double z = watched.getZ() - (this.worldPosition.getZ() + 0.5);
            this.targetRotation = (float) Math.atan2(z, x);
        } else {
            this.targetRotation += 0.01F;
        }
        this.rotation = wrapRadians(this.rotation);
        this.targetRotation = wrapRadians(this.targetRotation);
        float delta = wrapRadians(this.targetRotation - this.rotation);
        this.rotation += delta * 0.04F;
    }

    public static float wrapRadians(float angle) {
        while (angle >= Math.PI) {
            angle -= Mth.TWO_PI;
        }
        while (angle < -Math.PI) {
            angle += Mth.TWO_PI;
        }
        return angle;
    }

    @Nullable
    private ExperienceOrb closestExperienceOrb() {
        if (this.level == null) {
            return null;
        }
        AABB range = new AABB(this.worldPosition.getX(), this.worldPosition.getY(), this.worldPosition.getZ(), this.worldPosition.getX() + 1, this.worldPosition.getY() + 1, this.worldPosition.getZ() + 1).inflate(6.0);
        return this.level.getEntitiesOfClass(ExperienceOrb.class, range).stream().min(Comparator.comparingDouble(orb -> orb.distanceToSqr(Vec3.atCenterOf(this.worldPosition)))).orElse(null);
    }

    private void consumeTouchingOrbs() {
        if (this.level == null) {
            return;
        }
        AABB inside = new AABB(this.worldPosition.getX() - 0.1, this.worldPosition.getY() - 0.1, this.worldPosition.getZ() - 0.1, this.worldPosition.getX() + 1.1, this.worldPosition.getY() + 1.1, this.worldPosition.getZ() + 1.1);
        List<ExperienceOrb> orbs = this.level.getEntitiesOfClass(ExperienceOrb.class, inside);
        if (orbs.isEmpty()) {
            return;
        }
        for (ExperienceOrb orb : orbs) {
            /*
             * Modern XP orbs can merge and store a private Count. TC4 had
             * one value per entity, so read the serialized count to avoid
             * deleting merged experience when the jar consumes the entity.
             */
            CompoundTag serialized = new CompoundTag();
            orb.saveWithoutId(serialized);
            int count = Math.max(1, serialized.getInt("Count"));
            this.experience = (int) Math.max(0L, Math.min(Integer.MAX_VALUE, (long) this.experience + (long) orb.getValue() * count));
            this.level.playSound(null, orb.blockPosition(), TCSounds.BRAIN_JAR_ABSORB.get(), SoundSource.BLOCKS, 0.1F, (this.level.random.nextFloat() - this.level.random.nextFloat()) * 0.2F + 1.0F);
            orb.discard();
        }
        this.changedAndSync();
    }

    private void changedAndSync() {
        this.setChanged();
        BlockEntitySync.sendToClientAndUpdateComparator(this);
    }

    @Override
    public void load(CompoundTag tag) {
        super.load(tag);
        this.observedCapacity = Math.max(1, tag.getInt("CapacityAtSave"));
        this.retainedSurplus = tag.getBoolean("RetainedSurplus");
        this.experience = tag.getInt(EXPERIENCE_TAG);
    }

    @Override
    protected void saveAdditional(CompoundTag tag) {
        super.saveAdditional(tag);
        tag.putInt("CapacityAtSave", this.observedCapacity);
        tag.putBoolean("RetainedSurplus", this.retainedSurplus);
        tag.putInt(EXPERIENCE_TAG, this.experience);
    }

    @Override
    public CompoundTag getUpdateTag() {
        return this.saveWithoutMetadata();
    }

    @Override
    public Packet<ClientGamePacketListener> getUpdatePacket() {
        return ClientboundBlockEntityDataPacket.create(this);
    }

    protected final HolderLookup.Provider persistenceRegistries() {
        if (level != null)
            return level.registryAccess();
        var server = net.minecraftforge.server.ServerLifecycleHooks.getCurrentServer();
        return server != null ? server.registryAccess() : net.minecraft.core.RegistryAccess.fromRegistryOfRegistries(net.minecraft.core.registries.BuiltInRegistries.REGISTRY);
    }

    protected static net.minecraft.network.chat.Component parseCustomNameSafe(String value, HolderLookup.Provider registries) {
        try {
            return net.minecraft.network.chat.Component.Serializer.fromJson(value);
        } catch (RuntimeException exception) {
            return null;
        }
    }

    protected void readItemFields(ItemFields.Input input) {
    }

    public void copyItemFields(ItemFields.Output output) {
    }

    public void applyComponentsFromItemStack(ItemStack stack) {
        readItemFields(ItemFields.from(stack));
    }

    public void removeComponentsFromTag(CompoundTag tag) {
    }

    @Override
    public void saveToItem(ItemStack stack) {
        CompoundTag tag = saveWithoutMetadata();
        {
            net.minecraft.nbt.CompoundTag native$bodyOperand$6114 = tag;
            native$bodyReturn$6116: {
                if (true) {
                }
            }
        }
        net.minecraft.world.item.BlockItem.setBlockEntityData(stack, getType(), tag);
        copyItemFields(ItemFields.to(stack));
    }

    @Override
    public net.minecraft.world.phys.AABB getRenderBoundingBox() {
        return BrainJarBlockEntity.native$ClientBlockEntityBounds$bounds(this);
    }

    @Override()
    public void onDataPacket(net.minecraft.network.Connection connection, net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket packet) {
        handleUpdateTag(packet.getTag());
    }

    @SuppressWarnings({ "rawtypes", "unchecked" })
    static private net.minecraft.world.phys.AABB native$ClientBlockEntityBounds$bounds(net.minecraft.world.level.block.entity.BlockEntity blockEntity) {
        var renderer = net.minecraft.client.Minecraft.getInstance().getBlockEntityRenderDispatcher().getRenderer(blockEntity);
        return renderer instanceof dev.tc4port.thaumcraft.nativeimpl.NativeBlockEntityRenderer shared ? shared.getRenderBoundingBox(blockEntity) : new net.minecraft.world.phys.AABB(blockEntity.getBlockPos());
    }
}
