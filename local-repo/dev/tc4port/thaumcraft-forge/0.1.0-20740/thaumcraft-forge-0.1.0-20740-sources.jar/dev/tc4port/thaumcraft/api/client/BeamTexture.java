package dev.tc4port.thaumcraft.api.client;

/**
 * The four native TC beam textures; DEFAULT is also the source type-6 fallback.
 */
public enum BeamTexture {

    DEFAULT("beam"), PRIMARY("beam_primary"), SECONDARY("beam_secondary"), TERTIARY("beam_tertiary");

    private final String path;

    BeamTexture(String path) {
        this.path = path;
    }

    public net.minecraft.resources.ResourceLocation texture() {
        return java.util.Objects.requireNonNull(net.minecraft.resources.ResourceLocation.tryBuild("thaumcraft", "textures/misc/" + path + ".png"));
    }
}
