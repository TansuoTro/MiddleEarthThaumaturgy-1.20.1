package dev.tc4port.thaumcraft.block.entity;

import dev.tc4port.thaumcraft.registry.TCSounds;
import dev.tc4port.thaumcraft.common.MachineItemOutput;
import dev.tc4port.thaumcraft.api.ThaumcraftApiHelper;
import dev.tc4port.thaumcraft.api.aspect.AspectDefinition;
import dev.tc4port.thaumcraft.aspect.AspectCatalog;
import dev.tc4port.thaumcraft.block.EssentiaCrystallizerBlock;
import dev.tc4port.thaumcraft.api.aspect.AspectId;
import dev.tc4port.thaumcraft.api.aspect.VisChannel;
import dev.tc4port.thaumcraft.api.aspect.AspectAmounts;
import dev.tc4port.thaumcraft.api.aspect.AspectContainerView;
import dev.tc4port.thaumcraft.api.essentia.EssentiaApi;
import dev.tc4port.thaumcraft.api.essentia.EssentiaTransferMode;
import dev.tc4port.thaumcraft.api.essentia.EssentiaTransport;
import dev.tc4port.thaumcraft.api.item.ThaumcraftItemApi;
import dev.tc4port.thaumcraft.common.VisNetwork;
import dev.tc4port.thaumcraft.registry.TCBlockEntities;
import dev.tc4port.thaumcraft.registry.TCParticles;
import javax.annotation.Nullable;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import java.lang.Math;
import dev.tc4port.thaumcraft.nativeimpl.state.ItemFields;
import net.minecraft.world.level.block.entity.BlockEntityType;

/**
 * TileEssentiaCrystalizer's one-unit reservoir and 200-step cycle.
 *
 * <p>The original adds one progress every five ticks and another two progress
 * per terra vis drained from VisNet. Both the no-network baseline and the
 * bounded aura-network acceleration are preserved.</p>
 */
public final class EssentiaCrystallizerBlockEntity extends net.minecraft.world.level.block.entity.BlockEntity implements EssentiaTransport, AspectContainerView, ItemFields.Source {

    // Nominal defaults; runtime behavior reads configured accessors.
    public static final int MAX_PROGRESS = 200;

    public static int configuredMaxProgress() {
        return dev.tc4port.thaumcraft.common.TCGameplayParameters.MACHINES_CRYSTALLIZER_WORK_TICKS.intValue();
    }

    private AspectId aspect;

    private int count;

    private int progress;

    private float spin;

    private float spinIncrement;

    private float colorRed = 1.0F;

    private float colorGreen = 1.0F;

    private float colorBlue = 1.0F;

    private int venting;

    public EssentiaCrystallizerBlockEntity(BlockPos pos, BlockState state) {
        super(TCBlockEntities.ESSENTIA_CRYSTALLIZER.get(), pos, state);
    }

    public static void serverTick(Level level, BlockPos pos, BlockState state, EssentiaCrystallizerBlockEntity crystallizer) {
        crystallizer.count++;
        if (crystallizer.count % dev.tc4port.thaumcraft.common.TCGameplayParameters.MACHINES_CRYSTALLIZER_WORK_INTERVAL.intValue() == 0 && level.hasChunksAt(pos.offset(-2, 0, -2), pos.offset(2, 0, 2)) && !level.hasNeighborSignal(pos)) {
            if (crystallizer.aspect == null) {
                crystallizer.fillReservoir();
                crystallizer.progress = 0;
            } else if (AspectCatalog.contains(crystallizer.aspect)) {
                crystallizer.progress = (int) Math.min(Integer.MAX_VALUE, (long) crystallizer.progress + dev.tc4port.thaumcraft.common.TCGameplayParameters.MACHINES_CRYSTALLIZER_BASE_PROGRESS.intValue() + (long) VisNetwork.drain((net.minecraft.server.level.ServerLevel) level, pos, VisChannel.TERRA, Math.min(dev.tc4port.thaumcraft.common.TCGameplayParameters.MACHINES_CRYSTALLIZER_MAXIMUM_VIS_REQUEST.intValue(), Math.max(1, (configuredMaxProgress() - crystallizer.progress) / dev.tc4port.thaumcraft.common.TCGameplayParameters.MACHINES_CRYSTALLIZER_PROGRESS_PER_VIS.intValue()))) * dev.tc4port.thaumcraft.common.TCGameplayParameters.MACHINES_CRYSTALLIZER_PROGRESS_PER_VIS.intValue());
            }
        }
        if (crystallizer.aspect != null && AspectCatalog.contains(crystallizer.aspect) && crystallizer.progress >= configuredMaxProgress()) {
            crystallizer.eject();
            crystallizer.aspect = null;
            crystallizer.progress = 0;
            crystallizer.changedAndSync();
        }
    }

    public static void clientTick(Level level, BlockPos pos, BlockState state, EssentiaCrystallizerBlockEntity crystallizer) {
        float targetRed = 1.0F;
        float targetGreen = 1.0F;
        float targetBlue = 1.0F;
        AspectDefinition definition = AspectCatalog.get(crystallizer.aspect);
        if (definition != null) {
            targetRed = (definition.color() >> 16 & 255) / 220.0F;
            targetGreen = (definition.color() >> 8 & 255) / 220.0F;
            targetBlue = (definition.color() & 255) / 220.0F;
        }
        crystallizer.colorRed = approach(crystallizer.colorRed, targetRed, 0.05F);
        crystallizer.colorGreen = approach(crystallizer.colorGreen, targetGreen, 0.05F);
        crystallizer.colorBlue = approach(crystallizer.colorBlue, targetBlue, 0.05F);
        crystallizer.spin += crystallizer.spinIncrement;
        if (crystallizer.spin > 360.0F) {
            crystallizer.spin -= 360.0F;
        }
        if (crystallizer.aspect != null && !level.hasNeighborSignal(pos) && crystallizer.spinIncrement < 20.0F) {
            crystallizer.spinIncrement = Math.min(20.0F, crystallizer.spinIncrement + 0.1F);
        } else if ((crystallizer.aspect == null || level.hasNeighborSignal(pos)) && crystallizer.spinIncrement > 0.0F) {
            crystallizer.spinIncrement = Math.max(0.0F, crystallizer.spinIncrement - 0.2F);
        }
        if (crystallizer.venting > 0) {
            crystallizer.venting--;
            Direction output = crystallizer.facing().getOpposite();
            double x = pos.getX() + 0.5 + output.getStepX() / 2.1 + level.random.nextDouble() * 0.2 - 0.1;
            double y = pos.getY() + 0.5 + output.getStepY() / 2.1 + level.random.nextDouble() * 0.2 - 0.1;
            double z = pos.getZ() + 0.5 + output.getStepZ() / 2.1 + level.random.nextDouble() * 0.2 - 0.1;
            level.addParticle(TCParticles.TUBE_VENT.get(), x, y, z, output.getStepX() / 4.0 + level.random.nextDouble() * 0.2 - 0.1, output.getStepY() / 4.0 + level.random.nextDouble() * 0.2 - 0.1, output.getStepZ() / 4.0 + level.random.nextDouble() * 0.2 - 0.1);
        }
    }

    @Nullable
    public AspectId aspect() {
        return this.aspect;
    }

    @Override
    public AspectAmounts visibleAspects() {
        return this.aspect == null ? AspectAmounts.EMPTY : AspectAmounts.of(this.aspect, 1);
    }

    public int progress() {
        return this.progress;
    }

    public float spin(float partialTick) {
        return this.spin + this.spinIncrement * partialTick;
    }

    public float colorRed() {
        return this.colorRed;
    }

    public float colorGreen() {
        return this.colorGreen;
    }

    public float colorBlue() {
        return this.colorBlue;
    }

    private Direction facing() {
        return this.getBlockState().getValue(EssentiaCrystallizerBlock.FACING);
    }

    private void fillReservoir() {
        Direction facing = this.facing();
        EssentiaTransport source = this.transportAt(facing);
        if (source == null || !source.canOutputTo(facing.getOpposite())) {
            return;
        }
        Direction sourceFace = facing.getOpposite();
        AspectId candidate = null;
        if (source.essentiaAmount(sourceFace) > 0 && source.suctionAmount(sourceFace) < this.suctionAmount(facing) && this.suctionAmount(facing) >= source.minimumSuction()) {
            candidate = source.essentiaType(sourceFace);
        }
        if (candidate != null && source.suctionAmount(sourceFace) < this.suctionAmount(facing)) {
            this.addToContainer(candidate, EssentiaApi.take(this.level, source, candidate, 1, sourceFace, EssentiaTransferMode.EXECUTE));
        }
    }

    private void eject() {
        Direction output = this.facing().getOpposite();
        ItemStack stack = ThaumcraftItemApi.createCrystalEssence(this.aspect);
        net.minecraftforge.items.IItemHandler destination = MachineItemOutput.destination(this.level, this.worldPosition.relative(output), this.facing());
        if (destination != null) {
            stack = net.minecraftforge.items.ItemHandlerHelper.insertItemStacked((net.minecraftforge.items.IItemHandler) (destination), (net.minecraft.world.item.ItemStack) (stack.copy()), (boolean) (false));
        }
        if (!stack.isEmpty()) {
            ItemEntity entity = new ItemEntity(this.level, this.worldPosition.getX() + 0.5 + output.getStepX() * 0.65, this.worldPosition.getY() + 0.5 + output.getStepY() * 0.65, this.worldPosition.getZ() + 0.5 + output.getStepZ() * 0.65, stack);
            entity.setDeltaMovement(output.getStepX() * 0.04, output.getStepY() * 0.04, output.getStepZ() * 0.04);
            this.level.addFreshEntity(entity);
        }
        this.level.blockEvent(this.worldPosition, this.getBlockState().getBlock(), 0, 0);
        this.level.playSound(null, this.worldPosition, TCSounds.CRYSTALLIZER_FINISH.get(), SoundSource.BLOCKS, 0.25F, 2.6F + (this.level.random.nextFloat() - this.level.random.nextFloat()) * 0.8F);
    }

    private int addToContainer(AspectId candidate, int amount) {
        if (amount == 0 || this.aspect != null || !AspectCatalog.contains(candidate)) {
            return amount;
        }
        this.aspect = candidate;
        this.changedAndSync();
        return amount - 1;
    }

    @Nullable
    private EssentiaTransport transportAt(Direction direction) {
        if (this.level == null) {
            return null;
        }
        return ThaumcraftApiHelper.getConnectableTransport(this.level, this.worldPosition, direction);
    }

    @Override
    public boolean isConnectable(Direction face) {
        return face == this.facing();
    }

    @Override
    public boolean canInputFrom(Direction face) {
        return face == this.facing();
    }

    @Override
    public boolean canOutputTo(Direction face) {
        return false;
    }

    @Nullable
    @Override
    public AspectId suctionType(Direction face) {
        return null;
    }

    @Override
    public int suctionAmount(Direction face) {
        if (this.level != null && (!this.level.hasChunksAt(this.worldPosition.offset(-2, 0, -2), this.worldPosition.offset(2, 0, 2)) || this.level.hasNeighborSignal(this.worldPosition))) {
            return 0;
        }
        return face == this.facing() && this.aspect == null ? 128 : 64;
    }

    @Override
    public int takeEssentia(AspectId aspect, int amount, Direction face, EssentiaTransferMode mode) {
        return 0;
    }

    @Override
    public int addEssentia(AspectId aspect, int amount, Direction face, EssentiaTransferMode mode) {
        if (!this.canInputFrom(face) || amount <= 0 || this.aspect != null || !AspectCatalog.contains(aspect)) {
            return 0;
        }
        if (mode.executes()) {
            this.addToContainer(aspect, 1);
        }
        return 1;
    }

    @Nullable
    @Override
    public AspectId essentiaType(Direction face) {
        return AspectCatalog.contains(this.aspect) ? this.aspect : null;
    }

    @Override
    public int essentiaAmount(Direction face) {
        return AspectCatalog.contains(this.aspect) ? 1 : 0;
    }

    @Override
    public int minimumSuction() {
        return 0;
    }

    @Override
    public boolean renderExtendedTube() {
        return false;
    }

    @Override
    public boolean triggerEvent(int id, int type) {
        if (id >= 0) {
            if (this.level != null && this.level.isClientSide) {
                this.venting = 7;
            }
            return true;
        }
        return super.triggerEvent(id, type);
    }

    private void changedAndSync() {
        this.setChanged();
        BlockEntitySync.sendToClient(this);
    }

    @Override
    public void load(CompoundTag tag) {
        super.load(tag);
        this.aspect = tag.contains("Aspect") ? stored(tag.getString("Aspect")) : null;
        // progress/count were intentionally absent from TC4 NBT.
        this.progress = 0;
    }

    @Override
    protected void saveAdditional(CompoundTag tag) {
        super.saveAdditional(tag);
        if (this.aspect != null) {
            tag.putString("Aspect", this.aspect.serialized());
        }
    }

    @Override
    public CompoundTag getUpdateTag() {
        return this.saveWithoutMetadata();
    }

    @Override
    public Packet<ClientGamePacketListener> getUpdatePacket() {
        return ClientboundBlockEntityDataPacket.create(this);
    }

    private static AspectId stored(String value) {
        try {
            return AspectId.parse(value);
        } catch (IllegalArgumentException ignored) {
            return null;
        }
    }

    private static float approach(float current, float target, float step) {
        if (current < target) {
            return Math.min(target, current + step);
        }
        return Math.max(target, current - step);
    }

    protected final HolderLookup.Provider persistenceRegistries() {
        if (level != null)
            return level.registryAccess();
        var server = net.minecraftforge.server.ServerLifecycleHooks.getCurrentServer();
        return server != null ? server.registryAccess() : net.minecraft.core.RegistryAccess.fromRegistryOfRegistries(net.minecraft.core.registries.BuiltInRegistries.REGISTRY);
    }

    protected static net.minecraft.network.chat.Component parseCustomNameSafe(String value, HolderLookup.Provider registries) {
        try {
            return net.minecraft.network.chat.Component.Serializer.fromJson(value);
        } catch (RuntimeException exception) {
            return null;
        }
    }

    protected void readItemFields(ItemFields.Input input) {
    }

    public void copyItemFields(ItemFields.Output output) {
    }

    public void applyComponentsFromItemStack(ItemStack stack) {
        readItemFields(ItemFields.from(stack));
    }

    public void removeComponentsFromTag(CompoundTag tag) {
    }

    @Override
    public void saveToItem(ItemStack stack) {
        CompoundTag tag = saveWithoutMetadata();
        {
            net.minecraft.nbt.CompoundTag native$bodyOperand$6144 = tag;
            native$bodyReturn$6146: {
                if (true) {
                }
            }
        }
        net.minecraft.world.item.BlockItem.setBlockEntityData(stack, getType(), tag);
        copyItemFields(ItemFields.to(stack));
    }

    @Override
    public net.minecraft.world.phys.AABB getRenderBoundingBox() {
        return EssentiaCrystallizerBlockEntity.native$ClientBlockEntityBounds$bounds(this);
    }

    @Override()
    public void onDataPacket(net.minecraft.network.Connection connection, net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket packet) {
        handleUpdateTag(packet.getTag());
    }

    @SuppressWarnings({ "rawtypes", "unchecked" })
    static private net.minecraft.world.phys.AABB native$ClientBlockEntityBounds$bounds(net.minecraft.world.level.block.entity.BlockEntity blockEntity) {
        var renderer = net.minecraft.client.Minecraft.getInstance().getBlockEntityRenderDispatcher().getRenderer(blockEntity);
        return renderer instanceof dev.tc4port.thaumcraft.nativeimpl.NativeBlockEntityRenderer shared ? shared.getRenderBoundingBox(blockEntity) : new net.minecraft.world.phys.AABB(blockEntity.getBlockPos());
    }

    private boolean native$capabilitiesInvalid$16889;

    public boolean native$capabilityActive$16765;

    public net.minecraftforge.common.capabilities.Capability<dev.tc4port.thaumcraft.api.essentia.EssentiaTransport> native$capabilityCapture$16764;

    private net.minecraftforge.common.util.LazyOptional<dev.tc4port.thaumcraft.api.essentia.EssentiaTransport> native$capabilityHandle$16766;

    @Override
    public <native$capabilityResultType$16890> net.minecraftforge.common.util.LazyOptional<native$capabilityResultType$16890> getCapability(net.minecraftforge.common.capabilities.Capability<native$capabilityResultType$16890> native$requestedCapability$16891, net.minecraft.core.Direction native$requestedFace$16892) {
        getCapabilities();
        synchronized (this) {
            if (native$capabilitiesInvalid$16889)
                return net.minecraftforge.common.util.LazyOptional.empty();
            if (native$capabilityActive$16765 && native$requestedCapability$16891 == (this.native$capabilityCapture$16764)) {
                if (native$capabilityHandle$16766 == null)
                    native$capabilityHandle$16766 = net.minecraftforge.common.util.LazyOptional.of(() -> this);
                return native$capabilityHandle$16766.cast();
            }
        }
        return super.getCapability(native$requestedCapability$16891, native$requestedFace$16892);
    }

    @Override
    public void invalidateCaps() {
        java.util.List<net.minecraftforge.common.util.LazyOptional<?>> native$expiredCapabilities$16893 = new java.util.ArrayList<>();
        synchronized (this) {
            native$capabilitiesInvalid$16889 = true;
            if (native$capabilityHandle$16766 != null) {
                native$expiredCapabilities$16893.add(native$capabilityHandle$16766);
                native$capabilityHandle$16766 = null;
            }
        }
        try {
            super.invalidateCaps();
        } finally {
            native$expiredCapabilities$16893.forEach(net.minecraftforge.common.util.LazyOptional::invalidate);
        }
    }

    @Override
    public void reviveCaps() {
        super.reviveCaps();
        synchronized (this) {
            native$capabilitiesInvalid$16889 = false;
        }
    }
}
