package dev.tc4port.thaumcraft.api.event;

import dev.tc4port.thaumcraft.api.event.OrderedCallbacks;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Function;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.levelgen.structure.PoolElementStructurePiece;
import net.minecraft.world.level.levelgen.structure.pools.StructurePoolElement;
import net.minecraft.world.level.levelgen.structure.pools.StructureTemplatePool;

public final class JigsawSelectionHooks {

    public interface Session {

        void filter(StructureTemplatePool pool, List<StructurePoolElement> candidates, List<? super PoolElementStructurePiece> placed, RandomSource random);
    }

    public static final OrderedCallbacks<Function<RandomSource, Session>> SELECTORS = new OrderedCallbacks<>();

    private JigsawSelectionHooks() {
    }

    public static List<Session> begin(RandomSource random) {
        List<Session> sessions = new ArrayList<>();
        for (Function<RandomSource, Session> factory : SELECTORS.values()) sessions.add(factory.apply(random));
        return sessions;
    }
}
