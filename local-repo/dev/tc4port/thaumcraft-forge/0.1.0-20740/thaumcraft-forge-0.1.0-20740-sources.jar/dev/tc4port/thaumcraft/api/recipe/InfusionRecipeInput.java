package dev.tc4port.thaumcraft.api.recipe;

import dev.tc4port.thaumcraft.api.recipe.RecipeInputView;
import java.util.List;
import net.minecraft.world.item.ItemStack;

/**
 * Logical input to an infusion recipe: one central stack and an unordered
 * multiset of stacks on nearby arcane pedestals.
 */
public record InfusionRecipeInput(ItemStack central, List<ItemStack> components) implements RecipeInputView {

    public InfusionRecipeInput {
        central = central.copy();
        components = components.stream().filter(stack -> !stack.isEmpty()).map(ItemStack::copy).toList();
    }

    @Override
    public ItemStack getItem(int index) {
        if (index == 0) {
            return this.central;
        }
        return this.components.get(index - 1);
    }

    @Override
    public int size() {
        return 1 + this.components.size();
    }
}
