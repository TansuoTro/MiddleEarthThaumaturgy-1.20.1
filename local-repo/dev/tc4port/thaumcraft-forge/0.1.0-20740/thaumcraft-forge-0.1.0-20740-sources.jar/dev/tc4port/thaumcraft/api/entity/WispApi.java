package dev.tc4port.thaumcraft.api.entity;

import dev.tc4port.thaumcraft.api.aspect.AspectApi;
import dev.tc4port.thaumcraft.api.aspect.AspectId;
import dev.tc4port.thaumcraft.entity.WispEntity;
import dev.tc4port.thaumcraft.registry.TCEntities;
import java.util.Objects;
import java.util.Optional;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.Vec3;

/**
 * Controlled public factory for an aspect-aligned hostile wisp.
 */
public final class WispApi {

    private WispApi() {
    }

    /**
     * Spawns one ordinary hostile wisp with an explicit active aspect.
     * Invalid identities, non-finite coordinates, off-thread calls and
     * unloaded/out-of-bounds positions fail without creating an entity.
     */
    public static Optional<LivingEntity> spawn(ServerLevel level, Vec3 position, AspectId aspect) {
        Objects.requireNonNull(level, "level");
        Objects.requireNonNull(position, "position");
        Objects.requireNonNull(aspect, "aspect");
        BlockPos blockPos = BlockPos.containing(position);
        if (!level.getServer().isSameThread() || !Double.isFinite(position.x) || !Double.isFinite(position.y) || !Double.isFinite(position.z) || AspectApi.registry().get(aspect).isEmpty() || !level.hasChunkAt(blockPos) || level.isOutsideBuildHeight(blockPos) || !level.getWorldBorder().isWithinBounds(blockPos)) {
            return Optional.empty();
        }
        WispEntity wisp = TCEntities.WISP.get().create(level);
        if (wisp == null) {
            return Optional.empty();
        }
        wisp.moveTo(position.x, position.y, position.z, 0.0F, 0.0F);
        wisp.setAspect(aspect);
        if (!level.addFreshEntity(wisp)) {
            return Optional.empty();
        }
        return Optional.of(wisp);
    }
}
