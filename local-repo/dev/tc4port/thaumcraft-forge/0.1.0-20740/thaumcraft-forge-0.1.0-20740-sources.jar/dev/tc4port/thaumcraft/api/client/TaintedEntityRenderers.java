package dev.tc4port.thaumcraft.api.client;

import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.world.entity.animal.Sheep;

/**
 * Native renderers for addon variants of the core's tainted creatures. Client use only.
 */
public final class TaintedEntityRenderers {

    public static EntityRenderer<Sheep> sheep(EntityRendererProvider.Context context) {
        return dev.tc4port.thaumcraft.client.TaintedAnimalRenderers.sheep(context);
    }

    private TaintedEntityRenderers() {
    }
}
