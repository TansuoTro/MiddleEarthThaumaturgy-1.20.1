#version 150

uniform sampler2D DiffuseSampler;

in vec2 texCoord;

out vec4 fragColor;

const float blurWidth = 0.002;
const float blurSteps = 0.1;
const float amount = 5.0;

void main() {
    vec4 color = texture(DiffuseSampler, texCoord);
    float brightness = (color.r + color.g + color.b) / 3.0;
    vec4 sum = vec4(0.0);
    const float normalization = 10.0 / (((blurSteps * 2.0) + 1.0) * 4.0);
    for (float offset = -blurSteps; offset < blurSteps; offset += 1.0) {
        sum += texture(
            DiffuseSampler,
            texCoord + vec2(offset, offset) * blurWidth * 0.7
        );
        sum += texture(
            DiffuseSampler,
            texCoord + vec2(offset, -offset) * blurWidth * 0.7
        );
        sum += texture(
            DiffuseSampler,
            texCoord + vec2(0.0, offset) * blurWidth
        );
        sum += texture(
            DiffuseSampler,
            texCoord + vec2(offset, 0.0) * blurWidth
        );
    }
    sum *= normalization;
    vec4 modifier = sum * sum * (0.015 - brightness * 0.01);
    vec4 outputColor = modifier * amount + color;
    fragColor = outputColor * 0.9;
}
