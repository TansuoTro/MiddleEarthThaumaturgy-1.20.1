#version 150

uniform sampler2D DiffuseSampler;

in vec2 texCoord;

out vec4 fragColor;

vec4 rgbToHsl(vec4 color) {
    float minimum = min(min(color.r, color.g), color.b);
    float maximum = max(max(color.r, color.g), color.b);
    float delta = maximum - minimum;
    float luminance = (minimum + maximum) * 0.5;
    float saturation = 0.0;
    float hue = 0.0;
    if (luminance > 0.0 && luminance < 1.0) {
        float scale = luminance < 0.5 ? luminance : 1.0 - luminance;
        saturation = delta / max(scale * 2.0, 0.000001);
    }
    if (delta > 0.0) {
        if (maximum == color.r && maximum != color.g) {
            hue = (color.g - color.b) / delta;
        } else if (maximum == color.g && maximum != color.b) {
            hue = 2.0 + (color.b - color.r) / delta;
        } else {
            hue = 4.0 + (color.r - color.g) / delta;
        }
        hue /= 6.0;
        if (hue < 0.0) {
            hue += 1.0;
        }
    }
    return vec4(hue, saturation, luminance, color.a);
}

vec4 hslToRgb(vec4 color) {
    const float oneThird = 1.0 / 3.0;
    const float twoThirds = 2.0 / 3.0;
    const float reciprocalSixth = 6.0;
    float hue = color.x;
    float saturation = color.y;
    float luminance = color.z;
    vec3 ramp = vec3(
        reciprocalSixth * (hue - twoThirds),
        0.0,
        reciprocalSixth * (1.0 - hue)
    );
    if (hue < twoThirds) {
        ramp.r = 0.0;
        ramp.g = reciprocalSixth * (twoThirds - hue);
        ramp.b = reciprocalSixth * (hue - oneThird);
    }
    if (hue < oneThird) {
        ramp.r = reciprocalSixth * (oneThird - hue);
        ramp.g = reciprocalSixth * hue;
        ramp.b = 0.0;
    }
    ramp = min(ramp, 1.0);
    float doubledSaturation = 2.0 * saturation;
    float inverseSaturation = 1.0 - saturation;
    float inverseLuminance = 1.0 - luminance;
    float doubledLuminanceMinusOne = 2.0 * luminance - 1.0;
    vec3 curve = doubledSaturation * ramp + inverseSaturation;
    vec3 rgb = luminance >= 0.5
        ? inverseLuminance * curve + doubledLuminanceMinusOne
        : luminance * curve;
    return vec4(rgb, color.a);
}

vec4 averageScreenColor() {
    vec4 average = vec4(0.0);
    for (int x = 1; x <= 9; x++) {
        for (int y = 1; y <= 9; y++) {
            average += texture(
                DiffuseSampler,
                vec2(float(x), float(y)) * 0.1
            );
        }
    }
    return average / 81.0;
}

void main() {
    vec4 inputColor = texture(DiffuseSampler, texCoord);
    vec4 inputHsl = rgbToHsl(inputColor);
    float brightness = min(0.2, inputHsl.b) * 5.0;
    vec4 finalHsl = inputHsl * vec4(
        1.0,
        0.5 + brightness * 0.5,
        1.0,
        1.0
    );
    vec4 saturationAdjusted = hslToRgb(finalHsl);
    float averageBrightness = rgbToHsl(averageScreenColor()).b;
    float exposure = min(
        max(0.3 / max(averageBrightness, 0.000001), 0.7),
        4.0
    );
    vec4 exposureAdjusted = saturationAdjusted * exposure;
    fragColor = exposureAdjusted * 0.4 + saturationAdjusted * 0.6;
}
